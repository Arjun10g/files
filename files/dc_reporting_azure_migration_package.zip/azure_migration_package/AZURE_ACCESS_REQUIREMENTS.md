# DC Reporting — Azure / Entra / Graph Access Requirements

**Purpose:** ticket-ready list of access and platform dependencies required to migrate the current AWS Lab architecture to Azure.  
**Important:** these are **proposed minimum scopes**. The Azure, network, identity, security, and API-platform teams should apply the bank's naming/approval standards. Avoid granting subscription-wide Owner/User Access Administrator to the application team.

---

## 1. What We Need Before Development Can Move Cleanly

### P0 — blockers

| # | Dependency | Minimum thing we need | Why it is blocking |
|---|---|---|---|
| 1 | Azure subscription context | Subscription ID/name, tenant ID, approved region, and at least Reader visibility | We cannot target IaC or discover approved shared resources without this. |
| 2 | Project resource group | A dedicated Lab resource group **or** a documented deployment scope in an existing RG | All Azure resources need an approved scope. |
| 3 | Entra security groups | Deployers, Readers, App Users, App Operators | We currently have AWS groups only; Azure RBAC and app authorization need Entra principals. |
| 4 | Entra app registration | Single-tenant web/API registration + enterprise application + app roles | Required for SSO and role-based authorization. |
| 5 | Container Apps approval | `Microsoft.App` enabled/allowed and an approved internal Container Apps environment pattern | Replaces ECS Fargate. |
| 6 | VNet/subnet | Approved VNet + dedicated Container Apps subnet + private DNS/routing plan | Internal-only hosting depends on this. |
| 7 | Remote build path | Azure DevOps/enterprise CI runner and ACR remote-build/push path | Local Docker is unavailable. |
| 8 | Azure Container Registry | Project/shared registry plus runtime pull and CI build/write permissions | Container Apps must pull the image; CI must build it remotely. |
| 9 | Runtime managed identity | User-assigned managed identity and ability for the platform team to grant data-plane roles | Removes cloud credentials from the application. |
| 10 | Cosmos DB | Approved account/database/container and managed-identity data access | Replaces DynamoDB state. |
| 11 | Blob Storage | Approved storage account/containers and managed-identity data access | Replaces S3 artifacts. |
| 12 | AI model access | Microsoft Foundry/Azure OpenAI resource/project, deployed approved model, quota, endpoint, and RBAC | Replaces Bedrock. |
| 13 | Monitoring | Log Analytics + Application Insights access | Required for health/troubleshooting during migration. |
| 14 | Graph decision | Confirm whether any feature actually requires Graph; approve least-privilege scopes if yes | We should not make broad Graph access a hidden runtime dependency. |

### P1 — required for enterprise target state but can follow initial private MVP

| Dependency | Minimum thing we need | Notes |
|---|---|---|
| Enterprise API Management | Backend/API onboarding path and owner/contact | Use shared APIM if available; do not create a dedicated APIM just to unblock Lab. |
| Private endpoints | ACR/Storage/Cosmos/Key Vault/AI private endpoint pattern | Depends on platform/network policy. |
| Private DNS links | Required private DNS zones linked to the VNet and corporate DNS forwarding | Needed for reliable internal resolution. |
| Alerting integration | Alert destination/action group/on-call route | After telemetry is flowing. |
| Resource locks / cleanup policy | Durable-resource protection and Lab cleanup rules | Azure equivalent to the current anti-nuke intent. |

---

## 2. Proposed Microsoft Entra Groups

Use the corporate group naming convention; these names are descriptive placeholders.

| Proposed group | Purpose | Azure/App assignment |
|---|---|---|
| `SG-DCReporting-Azure-Deployers` | Human developers who deploy/manage the Lab resources | Scoped Azure RBAC on the project RG and build resources |
| `SG-DCReporting-Azure-Readers` | Developers/support/business stakeholders who need portal/log visibility | Reader + Monitoring/Log Analytics read roles |
| `SG-DCReporting-App-Users` | Standard application users | Assign to `DCReporting.User` app role |
| `SG-DCReporting-App-Operators` | Application operators/admin users | Assign to `DCReporting.Operator` app role |

### Why separate Azure groups from app groups?

`Azure-Deployers` controls **cloud resource management**. `App-Users` controls **what a signed-in user may do inside the application**. These are different privilege domains and should not be conflated.

---

## 3. Microsoft Entra App Registration Request

Request an app registration/enterprise application for the Azure-hosted DC Reporting service with the following baseline:

```text
Display name:       DC Reporting - Lab   (or corporate naming standard)
Audience:           Single tenant / organization only
Authentication:     Authorization code flow / OIDC
Redirect URI:       final internal app or APIM callback URL
API identifier:     api://<application-client-id> or approved URI
Enterprise app:     created in the tenant
User assignment:    required, if enterprise policy uses explicit assignments
```

### App roles

```text
DCReporting.User
DCReporting.Operator
```

Assignments:

```text
SG-DCReporting-App-Users      -> DCReporting.User
SG-DCReporting-App-Operators  -> DCReporting.Operator
```

### Preferred authorization implementation

The API should authorize based on the `roles` claim in the Entra token. This is more stable than hard-coding tenant group IDs throughout the application and can avoid a Microsoft Graph call for every request.

---

## 4. Microsoft Graph Permission Request — Least-Privilege Tiers

Graph access is **not the same thing as Azure RBAC**. A user can have Azure Contributor and still have no Microsoft Graph permission.

### Tier 0 — recommended default

**No runtime Microsoft Graph permission.**

Use Entra authentication + application roles/group-to-role assignments. This is sufficient for basic sign-in and application authorization.

### Tier 1 — signed-in user's profile is required

Request:

```text
Microsoft Graph
Delegated permission: User.Read
```

Use only if the application explicitly calls Graph for the signed-in user's profile.

### Tier 2 — the application must enumerate group memberships

Request only after the exact API flow is documented:

```text
Microsoft Graph
Permission: GroupMember.Read.All
Type: Delegated or Application, matching the actual call pattern
Admin consent: Required
```

This should be used only when role claims/application-assigned groups are insufficient.

### Tier 3 — arbitrary user profile lookups are required

Potential permission:

```text
Microsoft Graph
User.Read.All
Admin consent: Required
```

Do not request this for normal authentication.

### Avoid by default

```text
Directory.Read.All
Directory.ReadWrite.All
Group.ReadWrite.All
```

These are broad permissions. Request them only if an exact Graph endpoint/use case has been reviewed and no narrower permission works.

### Graph-specific questions the identity team must answer

1. Are delegated Graph calls allowed from this internal web app?
2. Is admin consent required for `User.Read` under the tenant policy even though Microsoft lists it as user-consent capable?
3. If group membership must be read, should we use a delegated user call or an application/background call?
4. Are application-assigned group claims/app roles the preferred corporate pattern?
5. Is there a group-claim limitation/overage standard we must account for?
6. If Graph application permissions are approved, what is the certificate/federated-credential standard? Avoid long-lived client secrets.

---

## 5. Azure Subscription and Resource-Group Access

### Human developer group

Recommended baseline for `SG-DCReporting-Azure-Deployers`:

```text
Subscription scope: Reader
Project resource group: Contributor
```

Why this is useful:

- Subscription Reader lets the team discover allowed shared resources and understand policy failures.
- Resource-group Contributor lets the team deploy normal resources **but does not let it grant Azure RBAC role assignments**.

That separation is desirable. Role assignments can be handled by a privileged platform pipeline or access ticket.

### Reader/support group

For `SG-DCReporting-Azure-Readers`:

```text
Project resource group: Reader
Monitoring scope: Monitoring Reader and/or Log Analytics Reader as required
```

### Do not request as the normal developer baseline

```text
Owner at subscription
User Access Administrator at subscription
Role Based Access Control Administrator at subscription
```

If a deployment pipeline must create role assignments, scope that capability tightly and preferably place RBAC creation in a separate privileged platform pipeline.

---

## 6. Azure Resource Providers / Service Enablement

Ask the platform team to confirm the required resource providers are registered/allowed in the target subscription. At minimum, the architecture can touch:

```text
Microsoft.App
Microsoft.OperationalInsights
Microsoft.Insights
Microsoft.ContainerRegistry
Microsoft.ManagedIdentity
Microsoft.Storage
Microsoft.DocumentDB
Microsoft.KeyVault
Microsoft.CognitiveServices   (depending on the approved AI/Foundry resource type)
Microsoft.ApiManagement      (only if this team is creating APIM resources; shared APIM may be centrally owned)
Microsoft.Network
```

Microsoft documentation explicitly calls out `Microsoft.App` and `Microsoft.OperationalInsights` for Container Apps setup. Enterprise policy may pre-register providers centrally.

---

## 7. Network Access Request

### We need from the Azure/network team

```text
1. Approved region
2. VNet resource ID/name
3. Dedicated Container Apps subnet
4. Subnet CIDR approved for the chosen Container Apps environment type
5. Internal Container Apps environment allowed
6. NSG/firewall ownership and permitted inbound source ranges
7. Corporate/VPN route to the VNet
8. Private DNS ownership and forwarding pattern
9. Private endpoint requirements for ACR, Storage, Cosmos, Key Vault, AI
10. Egress/proxy/firewall rules required to reach Azure platform/model endpoints
11. Approved internal custom DNS name, if any
```

### Permission model

Preferred: the network team owns the VNet/subnet and provides the project with a ready-to-use subnet.

If the project team must manage the subnet, request **Network Contributor only at the relevant VNet/subnet scope**, not subscription-wide.

If the project team must manage private DNS records/zones, request **Private DNS Zone Contributor** at the specific private DNS zone scope.

### Important Container Apps requirement

A custom VNet deployment needs a dedicated subnet for the Container Apps environment. The subnet should be sized before the environment is created because resizing/restructuring later is disruptive.

---

## 8. Azure Container Registry and No-Local-Docker Access

This is a core migration dependency.

### Runtime identity

The Container App's user-assigned managed identity needs:

```text
ACR: AcrPull
Scope: target registry (or narrower repository model if the enterprise uses ACR RBAC+ABAC)
```

### CI/build identity

If the pipeline uses `az acr build`, request permissions appropriate to the registry authorization model.

Microsoft's current role model identifies:

```text
Container Registry Tasks Contributor
    - controls ACR task/quick-build execution, including az acr build

PLUS image repository data-plane write access, for example:
    - Container Registry Repository Writer under RBAC+ABAC mode
      OR
    - AcrPush under the classic registry role model
```

The platform team should confirm which ACR authorization mode is enabled before assigning both old and new roles indiscriminately.

### If ACR is private-only

We also need an approved build executor with network connectivity to the private registry:

- enterprise/self-hosted Azure DevOps agent inside an approved network, **or**
- ACR Tasks networking/agent-pool configuration approved by the platform team.

### CI/CD platform access

We need:

```text
- Repository read/write as appropriate
- Pipeline create/edit/execute permission
- Approved agent pool use permission
- Ability to create/use an Azure service connection
- Workload identity federation preferred for Azure authentication
- Secure variable/configuration library access if enterprise pipeline standards require it
```

Avoid a long-lived service-principal client secret where workload identity federation is available.

---

## 9. Runtime Managed Identity and Azure RBAC Matrix

Create a user-assigned managed identity, for example:

```text
uami-dc-reporting-lab-api
```

Grant it only the following required data-plane permissions.

| Target resource | Runtime role | Scope | Why |
|---|---|---|---|
| Azure Container Registry | `AcrPull` | target registry/repository | Pull application image |
| Cosmos DB for NoSQL | `Cosmos DB Built-in Data Contributor` | target account/database/container per platform pattern | Read/write application state |
| Blob Storage | `Storage Blob Data Contributor` | target storage account or specific containers | Read/write report/import/export artifacts |
| Key Vault | `Key Vault Secrets User` | target vault | Only if a remaining secret must be read |
| Microsoft Foundry | `Foundry User` on the approved Foundry resource/project | smallest supported scope | Invoke/use approved Foundry resources |
| Azure OpenAI resource, if classic/direct Azure OpenAI is used | `Cognitive Services OpenAI User` | specific model resource | Make keyless inference calls |

The managed identity does **not** need project-RG Contributor merely to access these services.

---

## 10. Cosmos DB Access

### Platform resource need

Request:

```text
- Cosmos DB for NoSQL account, existing or project-specific
- database: dc-reporting (proposed)
- container: reporting-state (proposed)
- partition key: /pk (proposed)
- approved backup/restore mode
- private endpoint/DNS if required
```

### Runtime

```text
Cosmos DB Built-in Data Contributor
```

This is a **data-plane** role. A normal ARM `Contributor` assignment on the Cosmos resource is not a replacement for data access.

### Human troubleshooting access

Only if developers must directly inspect Lab data, grant `Cosmos DB Built-in Data Contributor` to the deployer group at the narrow Lab scope. If read-only troubleshooting is sufficient, use a narrower custom/data role per the platform team's standard.

---

## 11. Blob Storage Access

### Resource need

Request:

```text
Storage account with public access disabled
Logical containers:
  imports
  reports
  exports
Blob versioning / soft delete according to policy
Private endpoint + private DNS if required
```

### Runtime

```text
Storage Blob Data Contributor
```

Scope it to the target storage account or containers according to the enterprise standard.

### Human access

Do not grant broad storage-key access just so developers can troubleshoot. Prefer Entra data-plane roles and portal/Storage Explorer access under their user identity if required.

---

## 12. Key Vault Access

### Preferred architecture

Use managed identity so that the application has as few secrets as possible.

### Runtime, only if necessary

```text
Key Vault Secrets User
```

This role reads secret values but does not administer the vault.

### Human developers

Default to no secret-value access. If support requires it, request the narrowest approved Lab-only access and time-bound it where possible.

### Avoid

Do not make the application runtime a Key Vault Administrator/Secrets Officer merely to read a value.

---

## 13. Microsoft Foundry / Azure OpenAI Access

The AI platform team must provide one of the supported patterns below.

### Preferred Foundry pattern

We need:

```text
- Foundry resource/project
- approved model deployment/endpoint
- supported region
- quota/capacity
- network/private endpoint policy
- developer access to test the model
- runtime managed-identity access
```

Current Microsoft role naming includes **Foundry User**; Microsoft notes that Foundry RBAC role names were renamed from the older Azure AI names.

### Direct/classic Azure OpenAI pattern

For inference-only access by the application managed identity:

```text
Cognitive Services OpenAI User
```

If the app team must create/change model deployments, that is a separate control-plane responsibility and should not be granted to the runtime identity.

### Explicit questions for the AI platform team

1. Which model replaces the current Bedrock model for Lab testing?
2. Is the model already deployed, or does our team need deployment rights?
3. What token/request quota is allocated?
4. Is cross-region inference allowed?
5. Is private network access mandatory?
6. Which SDK/API endpoint is the enterprise standard?
7. Is content filtering/RAI policy preconfigured centrally?
8. Does the application managed identity get Foundry User or Cognitive Services OpenAI User on the chosen endpoint?

---

## 14. Monitoring Access

### Resources

We need an existing or project-specific:

```text
Log Analytics Workspace
Application Insights resource / workspace-based Application Insights configuration
```

### Human users

Recommended:

```text
Monitoring Reader
and/or
Log Analytics Reader
```

For people who must create/edit alerts/diagnostic settings:

```text
Monitoring Contributor
```

Keep monitoring-write permissions separate from broad project Contributor when the enterprise monitoring team owns alerts centrally.

---

## 15. API Management Access

### Preferred ownership

Use an existing enterprise/shared APIM owned by the API platform team.

Request:

```text
- API onboarding process
- backend connectivity to the private Container App
- API name/base path
- authentication policy standard
- required headers/correlation IDs
- rate limiting/quota policy
- WebSocket support confirmation for the chat endpoint
- internal hostname/certificate/DNS process
- developer/operator access to view APIM diagnostics
```

### If the app team must edit APIs directly

Ask the APIM owner which workspace/API-level role is required. Do not automatically request APIM Service Contributor over the entire shared service if a narrower workspace/API role is available.

---

## 16. Pipeline Identity — Recommended Pattern

Create/use a non-human CI identity through an Azure service connection with **workload identity federation**.

### Pipeline needs

At the project resource group:

```text
Contributor
```

At ACR:

```text
Container Registry Tasks Contributor
+ repository write/push role appropriate to the registry authorization mode
```

At the user-assigned managed identity:

```text
Managed Identity Operator
```

**only if** the pipeline needs to attach an existing user-assigned identity to the Container App and the platform's deployment model requires that permission.

### RBAC role assignment creation

Prefer one of these patterns:

1. **Platform-managed RBAC:** application pipeline deploys resources; platform pipeline/tickets create role assignments.
2. **Separate privileged IaC stage:** role assignments are applied from an approved identity with narrowly scoped RBAC administration rights.

Avoid giving the ordinary application deployment identity subscription-wide role-assignment permissions.

---

## 17. Suggested Access Matrix by Principal

| Principal | Subscription | Project RG | Network | ACR | Cosmos data | Blob data | Key Vault | Foundry/OpenAI | Monitoring | Graph |
|---|---|---|---|---|---|---|---|---|---|---|
| `SG-DCReporting-Azure-Deployers` | Reader | Contributor | None by default; scoped Network Contributor only if delegated | Build/dev rights if humans run builds | Optional Lab data role | Optional Lab data role | No secret value by default | Foundry User / OpenAI User for testing | Reader/query | Only delegated scopes if the user-facing feature needs them |
| `SG-DCReporting-Azure-Readers` | — | Reader | — | — | — | — | — | — | Monitoring/Log Analytics Reader | — |
| CI federated identity | — | Contributor | Only if IaC owns network | ACR Tasks + repository write | Normally no direct data access | Normally no direct data access | No secret read unless deployment absolutely requires it | Normally no runtime inference access | Can configure diagnostics if owned by project | None |
| `uami-dc-reporting-lab-api` | — | No Contributor | Network path only | AcrPull | Built-in Data Contributor | Storage Blob Data Contributor | Secrets User only if needed | Foundry User or OpenAI User | Telemetry write via platform integration | None by default |
| `SG-DCReporting-App-Users` | — | — | — | — | — | — | — | — | — | No Graph by default; receives app role claim |
| `SG-DCReporting-App-Operators` | — | — | — | — | — | — | — | — | — | No Graph by default; receives operator app role claim |

---

## 18. Copy/Paste Ticket — Azure Landing Zone + Network

**Subject:** DC Reporting Lab — Azure landing zone and private Container Apps prerequisites

**Request:**

We are migrating the DC Reporting Lab application from AWS to Azure. The target is an internal-only Azure Container Apps architecture. Please provide/confirm:

```text
- Azure tenant ID
- target subscription ID/name
- approved Azure region
- project Lab resource group or approved existing RG
- SG-DCReporting-Azure-Deployers: Reader at subscription + Contributor at project RG
- SG-DCReporting-Azure-Readers: Reader at project RG
- approved VNet
- dedicated subnet for an internal Azure Container Apps environment
- private DNS/corporate DNS integration requirements
- NSG/firewall/route requirements for corporate/VPN users
- private endpoint requirements for ACR, Cosmos DB, Blob Storage, Key Vault, and the approved AI model endpoint
- confirmation that Microsoft.App / Container Apps is permitted in the subscription
```

Constraint: developers do **not** have local Docker, so the deployment must support a remote build pipeline.

---

## 19. Copy/Paste Ticket — Entra Groups + App Registration

**Subject:** DC Reporting Lab — Microsoft Entra groups, app registration, and app roles

**Request:**

Please create/approve the Entra principals required for the DC Reporting Azure migration:

```text
Security groups:
- SG-DCReporting-Azure-Deployers
- SG-DCReporting-Azure-Readers
- SG-DCReporting-App-Users
- SG-DCReporting-App-Operators

Application registration / enterprise application:
- DC Reporting - Lab
- single-tenant
- OIDC/OAuth2 web/API authentication
- redirect URI to be finalized after private hostname/APIM URL is assigned

App roles:
- DCReporting.User
- DCReporting.Operator

Assignments:
- SG-DCReporting-App-Users -> DCReporting.User
- SG-DCReporting-App-Operators -> DCReporting.Operator
```

We intend to authorize using token `roles` claims so Microsoft Graph is not required for basic authorization.

---

## 20. Copy/Paste Ticket — Microsoft Graph (Only if Feature Requires It)

**Subject:** DC Reporting Lab — least-privilege Microsoft Graph permission approval

**Request:**

The DC Reporting application will use Entra app-role claims for normal authorization. For the following explicit feature, we need Graph access:

```text
Feature/use case: <describe exact feature>
Graph endpoint(s): <list exact endpoint if known>
Access mode: Delegated / Application
```

Requested permission, starting at the narrowest tier:

```text
User.Read                 - only if signed-in user profile call is required
GroupMember.Read.All      - only if group-membership enumeration is required
User.Read.All             - only if arbitrary user-profile read is required
```

Please do not grant Directory.Read.All/ReadWrite or group write permissions unless the documented endpoint requires them and a narrower permission has been rejected.

---

## 21. Copy/Paste Ticket — Remote Build + ACR

**Subject:** DC Reporting Lab — Azure Container Registry remote build access (no local Docker)

**Request:**

The project cannot use Docker locally. Please provide an approved server-side/CI build path for the DC Reporting container.

Required outcome:

```text
Git push / PR
 -> approved Azure DevOps / enterprise CI runner
 -> remote image build
 -> Azure Container Registry
 -> Container Apps revision deployment
```

Please provide/confirm:

```text
- target ACR name/resource ID
- ACR authorization mode (classic RBAC vs RBAC+ABAC repository permissions)
- CI identity permissions for az acr build / remote build
- CI repository write/push permission
- runtime managed identity AcrPull permission
- approved agent pool / network path if the registry is private-only
- Azure service connection using workload identity federation if supported
```

Current Microsoft guidance identifies Container Registry Tasks Contributor for ACR task/quick-build operations, plus repository write/push data access appropriate to the registry authorization mode.

---

## 22. Copy/Paste Ticket — Microsoft Foundry / Azure OpenAI

**Subject:** DC Reporting Lab — Azure model endpoint access for Bedrock migration

**Request:**

We are replacing the current AWS Bedrock report-synthesis integration with an approved Microsoft Foundry / Azure OpenAI model endpoint.

Please provide/confirm:

```text
- Foundry project/resource or Azure OpenAI resource
- approved model deployment name
- endpoint
- region
- quota/capacity
- private network requirements
- developer test access
- runtime managed identity inference access
- whether Foundry User or Cognitive Services OpenAI User is the approved inference role
```

The application will authenticate using managed identity/keyless access where supported. We do not want model API keys stored in source code or container environment variables.

---

## 23. First-Day Validation Checklist

Before writing Azure-specific migration code, verify all of the following:

```text
[ ] I can see the target Azure subscription.
[ ] I can see the target project resource group.
[ ] The Entra deployer/user groups exist.
[ ] The app registration exists or has an assigned identity-team owner.
[ ] A dedicated Container Apps subnet is identified.
[ ] The internal Container Apps pattern is approved.
[ ] The ACR exists or an owner has committed to creating it.
[ ] A remote build path is selected; no developer laptop Docker is assumed.
[ ] A user-assigned managed identity exists or will be created by IaC/platform team.
[ ] Cosmos DB data access can be granted to that identity.
[ ] Blob data access can be granted to that identity.
[ ] The AI platform has identified the model endpoint and quota.
[ ] Monitoring workspace/application insights path is known.
[ ] Graph is explicitly "not required" or the exact least-privilege scopes are in approval.
[ ] APIM has an onboarding owner, even if it comes after the MVP.
```

If any of the **network, ACR remote-build, runtime identity, or AI endpoint** items are unresolved, they should be treated as architecture blockers rather than application-code problems.

---

## 24. Microsoft References

Role/product names checked against Microsoft documentation on **2026-09-28**.

- Container Apps custom VNet/internal environment:  
  https://learn.microsoft.com/en-us/azure/container-apps/custom-virtual-networks
- Container Apps ACR pull with managed identity:  
  https://learn.microsoft.com/en-us/azure/container-apps/managed-identity-image-pull
- ACR built-in roles and ACR Tasks:  
  https://learn.microsoft.com/azure/container-registry/container-registry-rbac-built-in-roles-overview
- Microsoft Graph permission reference:  
  https://learn.microsoft.com/en-us/graph/permissions-reference
- Entra app roles:  
  https://learn.microsoft.com/en-us/entra/identity-platform/howto-add-app-roles-in-apps
- Entra role/group claims and RBAC:  
  https://learn.microsoft.com/en-us/entra/identity-platform/howto-implement-rbac-for-apps
- Cosmos DB RBAC/data access:  
  https://learn.microsoft.com/en-us/azure/cosmos-db/how-to-connect-role-based-access-control
- Storage Blob Data Contributor:  
  https://learn.microsoft.com/en-us/azure/role-based-access-control/built-in-roles/storage
- Key Vault Secrets User / Container Apps references:  
  https://learn.microsoft.com/en-us/azure/container-apps/manage-secrets
- Foundry RBAC:  
  https://learn.microsoft.com/en-us/azure/foundry/concepts/rbac-foundry
- Azure OpenAI RBAC:  
  https://learn.microsoft.com/en-us/azure/foundry-classic/openai/how-to/role-based-access-control
- Azure Monitor roles:  
  https://learn.microsoft.com/en-us/azure/azure-monitor/fundamentals/roles-permissions-security
- Network Contributor / private DNS built-in roles:  
  https://learn.microsoft.com/en-us/azure/role-based-access-control/built-in-roles/networking

