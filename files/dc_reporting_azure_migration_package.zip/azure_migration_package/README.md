# DC Reporting — AWS to Azure Migration Package

This package was created from the supplied walkthrough of `LAB ARCHITECTURE 2.md` and translates the current AWS Lab design to an Azure target that assumes:

- no Docker on developer workstations
- initially incomplete Azure permissions
- no existing Entra groups for this application
- Microsoft Graph access not yet approved
- internal/private enterprise networking

## Primary deliverables

1. **`azure_target_architecture.png` / `.svg`** — target Azure architecture and remote-build path.
2. **`AZURE_MIGRATION_ARCHITECTURE.md`** — Azure equivalent of the architecture/runbook style shown in the video, including request flow, mapping, deployment, migration, scaling, verification, and troubleshooting.
3. **`AZURE_ACCESS_REQUIREMENTS.md`** — P0/P1 access list, Entra groups, Graph permissions, Azure RBAC matrix, CI/ACR/network/Foundry dependencies, and copy/paste access tickets.

## Diagram source

`azure_target_architecture.dot` is included so the diagram can be edited and rerendered with Graphviz.

## Main architectural choice

The primary target is **Azure Container Apps + Azure Container Registry + remote CI/ACR build + Cosmos DB + Blob Storage + Microsoft Foundry/Azure OpenAI + Entra ID + managed identity + Azure Monitor**.

Azure App Service code deployment is documented only as a fallback if the organization cannot approve a container build/registry path quickly enough.

## Items that still require BMO/Azure platform confirmation

The deliverables intentionally use placeholders for subscription IDs, regions, resource groups, VNets/subnets, private DNS zones, ACR names, APIM instances, and model deployments. These should be filled only after the corresponding platform/identity/network teams provide the approved values.
