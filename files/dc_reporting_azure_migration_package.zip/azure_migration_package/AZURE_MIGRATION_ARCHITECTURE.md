# DC Reporting — Azure Migration Architecture

**Target:** migrate the current AWS Lab deployment to an Azure-native, internal-only architecture while preserving the FastAPI application behavior.  
**Key constraints:** no local Docker, incomplete Azure access, no existing Microsoft Entra ID groups for this application, and Microsoft Graph access is not currently provisioned.  
**Status:** proposed target / access-dependent. Resource names, subscription IDs, VNets, subnets, private DNS zones, model deployments, and enterprise API Management instances must be replaced with the values provided by the Azure platform teams.

---

## Executive Summary

The current AWS design shown in `LAB ARCHITECTURE 2.md` is a private FastAPI service using API Gateway / an internal Network Load Balancer, ECS Fargate, DynamoDB, S3, Bedrock, ECR, CodeBuild/CDK, IAM roles, and CloudWatch. The Azure target keeps that same application shape but replaces the AWS platform layer:

- **Compute:** Azure Container Apps instead of ECS Fargate.
- **Internal load balancing:** Container Apps internal environment + managed ingress instead of the NLB.
- **API front door:** existing enterprise **Azure API Management** when available; private Container Apps ingress can unblock the Lab MVP.
- **Identity:** Microsoft Entra ID + application roles/security groups for users; managed identity + Azure RBAC for service-to-service access.
- **State:** Azure Cosmos DB for NoSQL instead of DynamoDB.
- **Artifacts:** Azure Blob Storage instead of S3.
- **AI:** an approved Microsoft Foundry / Azure AI / Azure OpenAI model endpoint instead of Bedrock.
- **Images:** Azure Container Registry instead of ECR.
- **Build:** remote ACR build or an approved CI build agent instead of local Docker/CodeBuild.
- **Infrastructure as code:** Bicep by default instead of AWS CDK; use the enterprise Terraform standard instead if that is mandated.
- **Observability:** Azure Monitor + Application Insights + Log Analytics instead of CloudWatch.
- **Secrets:** managed identity first; Azure Key Vault only for secrets/certificates that cannot be removed.
- **Network:** internal VNet, dedicated Container Apps subnet, private DNS, and private endpoints where required by policy.

**The developer workstation does not need Docker.** A developer should be able to edit code, push to the repository, and let an approved remote build/deployment path produce and deploy the image.

---

## 1. Constraints and Design Rules

1. **No local Docker dependency.** No build, test, or deployment step may require Docker Desktop on a developer laptop.
2. **Assume Azure permissions are initially incomplete.** Network creation, role assignments, app registrations, Graph consent, and model deployment might require platform/identity teams.
3. **Private by default.** The service should remain BMO-internal and not expose a public application endpoint.
4. **Preserve application behavior first.** Keep the existing FastAPI API contract and move AWS-specific dependencies behind adapters.
5. **Do not make Microsoft Graph a Day-1 dependency unless the application truly needs Graph data.** Authentication and authorization can be handled with Entra tokens, application roles, and assigned groups.
6. **Use managed identities instead of cloud access keys/client secrets wherever Azure supports them.**
7. **Use immutable deployment artifacts.** Container Apps revisions should deploy an ACR image digest, not a mutable `latest` tag.
8. **Separate human access, deployment access, and runtime access.** They require different roles and should not share credentials.

---

## 2. Current AWS Baseline Observed in the Video

The migration below assumes the following current behavior from the supplied `LAB ARCHITECTURE 2.md` walkthrough:

- User request originates from the internal/VPN network.
- API requests include report generation, incidents, workbook import, dashboard/export, change/task submission, and AI synthesis.
- API Gateway routes to an **internal Network Load Balancer**.
- The NLB routes to one or more **ECS Fargate** tasks.
- Runtime is **Python 3.12 + FastAPI**, listening on port **8080**.
- Health endpoint is **`GET /api/health`**.
- Application endpoints include approximately:
  - `GET/POST /api/incidents`
  - `GET/POST /api/changes`
  - `POST /api/tasks/submissions`
  - `POST /api/report/ai`
  - `POST /api/import/excel`
  - `GET /api/dashboard`
  - `GET /api/export`
  - report generation / workbook upload flows
  - WebSocket chat behavior
- DynamoDB stores session/state/report metadata/chat history and uses TTL/PITR concepts.
- S3 stores generated report/export/import artifacts with versioning and blocked public access.
- Bedrock is used for AI report synthesis with a deterministic fallback.
- ECR stores the container image.
- CodeBuild creates the image remotely and CDK deploys the application stacks.
- CloudWatch supplies request logs, metrics, alarms, and health visibility.
- The service is designed to scale horizontally and remain internal-only.

---

## 3. Target Azure Architecture

![Azure target architecture](./azure_target_architecture.png)

### Mermaid source

```mermaid
flowchart LR
    U[BMO user\nVPN / corporate network] --> E[Microsoft Entra ID\nSSO + app roles/groups]
    E --> A[Enterprise API Management\nshared/preferred]
    E -. Lab MVP .-> I[Private Container Apps ingress]

    subgraph VNET[Azure VNet - internal only]
      direction LR
      D[Private DNS + corporate DNS]
      subgraph CAS[Dedicated Container Apps subnet]
        ENV[Azure Container Apps Environment\ninternal VIP / managed ingress]
        APP[Container App\nPython 3.12 + FastAPI\n8080 /api/health\nREST + WebSocket]
        ID[User-assigned managed identity]
        ENV --> APP
        APP <--> ID
      end
      C[(Cosmos DB for NoSQL)]
      B[(Blob Storage)]
      K[Key Vault]
      M[Azure Monitor\nApp Insights + Log Analytics]
      D <--> ENV
      APP --> C
      APP --> B
      APP --> K
      APP --> M
    end

    A --> ENV
    I --> ENV
    APP --> F[Microsoft Foundry / approved model endpoint]
    APP -. only if required .-> G[Microsoft Graph]

    R[Git repository] --> P[Azure DevOps / approved CI runner]
    P --> RB[Remote image build\nACR Tasks or remote BuildKit]
    RB --> ACR[Azure Container Registry]
    ACR --> APP
    P --> ENV
```

---

## 4. End-to-End Request Flow

### 4.1 User authentication

1. User connects through the corporate/VPN network.
2. Microsoft Entra ID authenticates the user.
3. The token contains the application role(s) or the application-assigned security-group information used for authorization.
4. The application should not need to query Graph merely to decide whether the caller is a normal user or operator.

### 4.2 Request routing

**Preferred enterprise path**

`User -> Entra ID -> internal/shared API Management -> private Container Apps ingress -> FastAPI`

**MVP unblock path**

`User -> Entra ID -> private Container Apps ingress -> FastAPI`

The Container Apps environment provides the internal VIP and managed ingress/load balancing. A separate Azure load balancer is not normally needed for the FastAPI replicas.

### 4.3 Application processing

Container Apps selects a healthy revision/replica and forwards the request to the FastAPI process on target port `8080`.

Recommended runtime configuration:

```text
Runtime:              Python 3.12
Framework:            FastAPI
Target port:          8080
Health endpoint:      GET /api/health
Ingress:              HTTPS only
Environment:          Internal Container Apps environment
Replica model:        1 -> N
Identity:             User-assigned managed identity
Deployment artifact:  ACR image digest
```

### 4.4 Data processing

**State / metadata — Cosmos DB for NoSQL**

- Preserve the current logical PK/SK model behind a repository adapter.
- Suggested migration representation:
  - `pk`: Cosmos partition key.
  - `sk`: retained as a normal property.
  - `id`: deterministic unique value such as a normalized `pk#sk` composite.
- Map the current expiry field to Cosmos TTL behavior where practical.
- Use an approved backup mode; continuous backup should be selected where the current PITR requirement must be retained.
- Use Entra/RBAC data access rather than account keys in application configuration.

**Artifacts — Azure Blob Storage**

- Containers can be separated into `imports`, `reports`, and `exports` or follow the enterprise storage convention.
- Enable blob versioning/soft delete where permitted.
- Disable anonymous/public access.
- Prefer private endpoint access from the application VNet.

**AI generation — Microsoft Foundry / Azure model endpoint**

- Introduce an `AIProvider` interface so Bedrock-specific invocation code is not mixed into report logic.
- Configure the approved model deployment by environment variable/configuration, not in code.
- Preserve the current semaphore/concurrency protection.
- Preserve the deterministic report fallback if the AI endpoint is unavailable.
- Use managed identity/RBAC for model invocation when supported by the selected enterprise model endpoint.

**Microsoft Graph — conditional**

- Authentication itself does **not** require application code to call Graph.
- Prefer Entra application roles assigned to groups.
- Use Graph only for features that truly need directory data, such as an explicit user/group lookup, manager lookup, or organization profile enrichment.
- See `AZURE_ACCESS_REQUIREMENTS.md` for the exact least-privilege request tiers.

### 4.5 Response delivery

- JSON responses stay JSON.
- Export/report streams are read from Blob Storage.
- WebSockets remain on the same Container Apps ingress path.
- Enforce HTTPS; do not enable insecure HTTP for the application.

### 4.6 Monitoring and observability

Recommended telemetry:

- FastAPI request logs and structured application logs -> Log Analytics.
- Traces/dependencies/exceptions -> Application Insights/OpenTelemetry.
- Custom metrics:
  - request count by endpoint
  - latency percentiles
  - error count/rate
  - model call count and latency
  - Cosmos request/operation errors
  - export/import processing times
- Infrastructure metrics:
  - replica count
  - CPU/memory
  - restart count
  - ingress errors
- Alerts:
  - sustained 5xx rate
  - no healthy revisions
  - repeated container startup failures
  - AI endpoint throttling/failures
  - Cosmos/Storage authorization failures

---

## 5. AWS-to-Azure Service Mapping

| Current AWS component | Azure target | Notes |
|---|---|---|
| API Gateway | Enterprise Azure API Management, when available | Use shared/internal APIM if the bank already operates it. Do not create a dedicated APIM just for the Lab unless required. |
| Internal Network Load Balancer | Container Apps internal environment + managed ingress | Container Apps provides internal VIP/load balancing. |
| ECS Fargate | Azure Container Apps | Closest managed-container operational model without running Kubernetes. |
| ECS task IAM role | User-assigned managed identity + Azure RBAC | No static cloud credentials in the container. |
| ECR | Azure Container Registry | Runtime identity gets pull only; CI identity gets remote-build/write rights. |
| CodeBuild | Azure DevOps/enterprise CI + ACR Tasks or approved remote BuildKit runner | Removes local Docker dependency. |
| AWS CDK | Bicep (default) | Terraform is acceptable if it is the corporate standard. |
| DynamoDB | Azure Cosmos DB for NoSQL | Migrate PK/SK access behind a data adapter. |
| S3 | Azure Blob Storage | Versioning, soft delete, private access. |
| Bedrock | Microsoft Foundry / approved Azure AI or Azure OpenAI endpoint | Model choice depends on regional/quota/enterprise approval. |
| CloudWatch | Azure Monitor + Application Insights + Log Analytics | Logs, traces, metrics, alerts. |
| Parameter Store / Secrets Manager | App Configuration + Key Vault | Prefer managed identity and non-secret environment configuration first. |
| AWS IAM user/role model | Entra ID + Azure RBAC | Separate human, pipeline, and runtime identities. |
| VPC/private subnets | VNet + dedicated Container Apps subnet | Integrate with corporate routing/DNS. |
| Security groups | NSGs + platform firewall controls | Exact ownership likely remains with the network team. |
| Auto-nuke exemption tags | Resource locks + required tags + controlled cleanup pipeline | Avoid broad delete rights and protect state resources. |

---

## 6. Network Architecture

### 6.1 Required network shape

```text
Corporate/VPN network
       |
       | private route + DNS
       v
Enterprise APIM (preferred) / Private app FQDN
       |
       v
Azure VNet
  └─ Dedicated Container Apps subnet
       └─ Internal Container Apps Environment
            └─ FastAPI Container App

Private endpoints / approved private routes to:
  - Azure Container Registry
  - Cosmos DB
  - Blob Storage
  - Key Vault
  - Foundry/model endpoint (if supported/required by the enterprise design)
```

### 6.2 Network requirements to get from the Azure team

- Approved Azure region.
- Approved VNet name/resource ID.
- A **dedicated subnet for the Container Apps environment** sized to the selected workload-profile model.
- Whether the network team creates the environment/subnet or delegates scoped Network Contributor permissions.
- Private DNS zone ownership and link model.
- Corporate DNS forwarding requirements for the internal application hostname.
- Inbound source ranges that may call the service.
- Outbound firewall/proxy rules for Azure platform dependencies and the selected model endpoint.
- Private endpoint policy for ACR, Storage, Cosmos, Key Vault, and AI endpoints.

### 6.3 APIM dependency

For a Lab migration, APIM should not prevent the application from being deployed and validated. A practical order is:

1. Deploy the Container App with internal ingress.
2. Validate application/data/AI/auth behavior privately.
3. Onboard the private backend into the shared enterprise APIM.
4. Move users/clients to the governed APIM URL.

---

## 7. Identity and Authorization Architecture

### 7.1 Human access

Create Entra security groups instead of assigning developers individually:

```text
SG-DCReporting-Azure-Deployers
SG-DCReporting-Azure-Readers
SG-DCReporting-App-Users
SG-DCReporting-App-Operators
```

The exact naming prefix must follow the BMO Entra group convention.

### 7.2 Application registration

Request a Microsoft Entra application registration/enterprise application for the DC Reporting web/API service with:

- single-tenant audience unless the identity team requires otherwise
- approved redirect URI(s)
- Application ID URI / exposed API scope if other clients call the API directly
- application roles such as:
  - `DCReporting.User`
  - `DCReporting.Operator`
- assignment of `SG-DCReporting-App-Users` to `DCReporting.User`
- assignment of `SG-DCReporting-App-Operators` to `DCReporting.Operator`

Application-role claims are preferable to hard-coding group IDs in business logic.

### 7.3 Runtime identity

Create a dedicated **user-assigned managed identity** for the Container App. It should receive only the data-plane roles required by the application:

- ACR pull access
- Cosmos DB data contributor access on the required account/database/container
- Blob data contributor access on the required storage container/account scope
- Key Vault secret read only when a secret remains unavoidable
- Foundry/model inference access

The runtime identity should **not** receive Contributor on the resource group.

---

## 8. Microsoft Graph Design

Microsoft Graph is a separate permission surface from Azure resource RBAC.

### Preferred design: no runtime Graph dependency for authorization

Use:

- Entra authentication
- app roles
- group-to-app-role assignment
- role claims in the token

This prevents Graph approval from blocking the basic application.

### When Graph is actually required

| Feature | Suggested starting permission | Consent |
|---|---|---|
| Signed-in user's basic Graph profile call | Delegated `User.Read` | Usually user consent may be possible; enterprise policy can still require admin approval |
| Enumerate/read group memberships beyond token claims | `GroupMember.Read.All` only if the implementation requires it | Admin consent |
| Read full profiles for arbitrary users | `User.Read.All` only if required | Admin consent |
| Broad directory read | **Do not request by default** | Request only for a documented endpoint/use case that cannot work with a narrower permission |

If the application has users who belong to very large numbers of Entra groups, group-claim overage can occur. Assigning only application-relevant groups to the enterprise application/app roles reduces this risk and also reduces the need for Graph lookups.

---

## 9. Storage Architecture

### Cosmos DB

Suggested logical container:

```text
Database:  dc-reporting
Container: reporting-state
Partition key: /pk
Properties:
  id
  pk
  sk
  recordType
  createdAt
  updatedAt
  expiresAt / ttl
  ...domain payload...
```

Migration rule: **do not expose Cosmos-specific types throughout the application.** Keep the state repository interface equivalent to the current DynamoDB adapter so local/unit tests remain simple and a rollback path is possible during migration.

### Blob Storage

Suggested logical containers:

```text
imports/   incoming workbooks and validated originals
reports/   generated reports / AI artifacts
exports/   exported files ready for streaming/download
```

Recommended controls:

- private access only
- versioning/soft delete where policy allows
- encryption using the platform standard
- no storage-account keys in the app
- managed identity for data access
- lifecycle policy for old temporary imports/exports

### SQLite from the current container

The current deployment appears to use ephemeral local storage for SQLite/seed data. In Container Apps:

- If the database is **read-only seed/reference data**, package it in the image or load it from Blob Storage during startup.
- If it is **mutable application state**, migrate it to Cosmos DB or another approved durable data service.
- Do not rely on the container filesystem for durable state.

---

## 10. Application Configuration

Recommended environment configuration:

```text
APP_ENV=lab
PORT=8080
STATE_PROVIDER=cosmos
ARTIFACT_PROVIDER=azure_blob
AI_PROVIDER=foundry
COSMOS_DATABASE=dc-reporting
COSMOS_CONTAINER=reporting-state
BLOB_IMPORT_CONTAINER=imports
BLOB_REPORT_CONTAINER=reports
BLOB_EXPORT_CONTAINER=exports
AI_MODEL_DEPLOYMENT=<approved-model-deployment>
AI_MAX_CONCURRENT_REQUESTS=<approved-value>
GRAPH_ENABLED=false   # turn on only if a Graph-backed feature is approved
```

Resource endpoints that are not secrets can be configuration values. Secrets should be eliminated with managed identity; remaining values should be Key Vault references.

---

## 11. No-Local-Docker Build and Deployment Architecture

### Required workflow

```text
Developer workstation
  └─ edit code / tests / Bicep
      └─ git push / PR
          └─ approved remote CI
              ├─ unit tests / lint / dependency checks
              ├─ Bicep lint + what-if
              ├─ remote container build
              │    └─ ACR Tasks (az acr build)
              │       OR approved remote BuildKit/Docker agent
              ├─ vulnerability/image policy checks
              ├─ push immutable image to ACR
              ├─ deploy Container Apps revision by digest
              └─ smoke-test GET /api/health
```

### Why this solves the Docker restriction

The only component that requires a container engine/build service is the **remote** build execution environment. The developer laptop needs only repository access; even Azure CLI can be replaced by Azure Cloud Shell or pipeline actions.

### Important private-ACR caveat

If the enterprise ACR has public access disabled, the build executor must have an approved network path to the registry. That can mean:

- an enterprise/self-hosted CI agent in the Azure network, or
- an ACR Tasks networking pattern/agent pool approved by the platform team.

This must be decided before making the container build pipeline a critical-path dependency.

### Non-container fallback

If ACR/remote container build access cannot be approved in time, a short-term fallback is **Azure App Service for Linux with Python code deployment/Oryx**. FastAPI can run there without a custom image. This is a migration fallback, not the primary design, because Container Apps is a closer operational replacement for Fargate and better preserves the current packaging model.

---

## 12. Infrastructure-as-Code Deployment Order

Recommended Bicep module/deployment order:

1. `foundation` — resource group references, tags, approved region.
2. `monitoring` — Log Analytics / Application Insights.
3. `identity` — user-assigned managed identity.
4. `registry` — ACR or reference to shared ACR.
5. `data` — Cosmos DB, Storage, containers, backup/lifecycle settings.
6. `secrets` — Key Vault if needed.
7. `network` — approved subnet/private DNS/private endpoints, usually coordinated with the network team.
8. `container-apps-environment` — internal Container Apps environment.
9. `container-app` — image digest, ingress, identity, scaling, environment config.
10. `auth` — Container Apps Entra auth / app registration binding.
11. `observability` — diagnostics, alerts, dashboards.
12. `apim-onboarding` — shared APIM backend/API/policy after the private backend is healthy.

**RBAC role assignments are a special case.** If the project pipeline is not allowed to create role assignments, place those assignments in a separate privileged platform deployment or request them through the access process.

---

## 13. Key Architectural Decisions

| Decision | Rationale | Impact |
|---|---|---|
| Azure Container Apps instead of AKS | Closer to Fargate and no cluster administration | Fewer platform permissions and less operational overhead |
| Remote build instead of local Docker | Workstation restriction is explicit | CI/ACR access becomes a hard prerequisite |
| Internal Container Apps environment | Preserves the current internal-only posture | Requires VNet, subnet, DNS, and route coordination |
| APIM is preferred but not an MVP blocker | Central governance without blocking application migration | Direct private ingress may be used temporarily |
| User-assigned managed identity | Eliminates cloud credentials in environment variables | Requires initial RBAC assignments by an authorized team |
| App roles assigned to groups | Keeps authorization app-specific and reduces Graph dependency | Requires Entra app registration and group creation |
| Cosmos DB + Blob | Direct functional mapping from DynamoDB + S3 | Requires data-access adapter and migration script |
| Provider adapter for AI | Avoids tying report logic to Bedrock or one Azure model | Model can change without rewriting report workflows |
| Bicep as default IaC | Native Azure, easy to run from CI/Cloud Shell | Switch to corporate Terraform if required by platform standards |

---

## 14. Migration Plan

### Phase 0 — Access and landing-zone discovery

**Goal:** remove unknowns before changing code.

Required outputs:

- Azure subscription/management-group context.
- Dev/Lab resource group or approved resource-creation path.
- Region.
- VNet/subnet/private DNS ownership.
- Container Apps allowed/registered.
- ACR/build path.
- Foundry/model endpoint and quota.
- Entra groups/app-registration process.
- Graph decision and approval path.
- APIM onboarding path.

**Exit criterion:** every P0 item in `AZURE_ACCESS_REQUIREMENTS.md` has an owner and either approved access or an implementation date.

### Phase 1 — Azure foundation

Deploy/reference:

- Log Analytics + Application Insights
- managed identity
- ACR
- Storage
- Cosmos DB
- Key Vault only if needed
- internal Container Apps environment

No production traffic yet.

### Phase 2 — Remote build pipeline

1. Trigger on PR/main branch.
2. Run application tests.
3. Run Bicep validation/what-if.
4. Build image remotely.
5. Scan/policy-check image.
6. Push image and capture digest.
7. Deploy a Container Apps revision.
8. Verify `/api/health`.

**Exit criterion:** a clean workstation with no Docker can cause a successful deployment by pushing code.

### Phase 3 — Data and artifact migration

- Implement `StateRepository` Cosmos adapter.
- Implement `ArtifactStore` Blob adapter.
- Migrate required Lab seed/state data.
- Verify TTL/backup/versioning behavior.
- Remove mutable local SQLite dependency where it exists.

### Phase 4 — AI migration

- Implement Azure AI/Foundry provider adapter.
- Confirm model deployment, quota, auth, network path, and safety controls.
- Test deterministic fallback.
- Compare output quality/latency with the existing Bedrock path.

### Phase 5 — Entra authentication and Graph

- Configure app registration.
- Configure app roles and assign Entra groups.
- Require authenticated access.
- Turn on Graph only for approved features.
- Validate role-claim behavior with representative users.

### Phase 6 — APIM and enterprise integration

- Onboard the internal backend into shared APIM.
- Apply authentication/rate-limit/header/policy standards.
- Configure governed hostname/DNS.
- Run end-to-end tests from the user network.

### Phase 7 — Cutover and AWS retirement

- Freeze schema-affecting changes during cutover window.
- Move final required data/artifacts.
- Switch clients/DNS/API route.
- Observe both platform and application telemetry.
- Keep a time-bounded rollback path.
- Only after validation, decommission the AWS Lab resources according to the platform cleanup process.

---

## 15. Deployment and Verification Commands

These can be run from **Azure Cloud Shell** or an approved CI agent; local Azure CLI is not a requirement.

```bash
# Confirm Container App and identity
az containerapp show \
  --name <container-app-name> \
  --resource-group <resource-group>

# List deployed revisions
az containerapp revision list \
  --name <container-app-name> \
  --resource-group <resource-group> \
  -o table

# Stream application logs
az containerapp logs show \
  --name <container-app-name> \
  --resource-group <resource-group> \
  --follow

# Remote container build — no local Docker
az acr build \
  --registry <acr-name> \
  --image dc-reporting:${BUILD_ID} \
  .
```

Application verification:

```text
GET /api/health                  -> 200 {"status":"healthy"}
GET /api/incidents               -> authorized state read
POST /api/incidents              -> authorized state write
POST /api/import/excel           -> Blob write + validation
POST /api/report/ai              -> model call or deterministic fallback
GET /api/export                  -> Blob read/stream
WebSocket                        -> authenticated connection survives normal traffic
```

---

## 16. Scaling

Starting Lab configuration should be conservative and policy-driven rather than copied directly from Fargate sizing.

Recommended starting posture:

- min replicas: `1` if interactive latency matters; `0` only if cold start is acceptable
- max replicas: `2-4` for Lab, adjusted after load testing
- scale signal: HTTP concurrency and/or CPU
- AI concurrency: enforce separately in application code to protect model quota
- Cosmos throughput: select serverless/low-throughput/autoscale mode based on the approved account capabilities and expected Lab volume

Do not use replica scaling as the only protection against model-rate limits.

---

## 17. Resource Protection / Lab Cleanup

The AWS architecture uses auto-nuke protection conventions. Azure should implement equivalent intent with:

- required resource tags (`Application`, `Environment`, `Owner`, `CostCenter`, `DataClassification`, etc.)
- resource locks on durable state resources if the platform permits them
- deletion approvals in CI/CD
- soft delete/versioning on supported data services
- backup/restore validation
- time-bounded cleanup automation for explicitly ephemeral resources rather than deleting the entire resource group automatically

State stores and artifact storage should not be casually coupled to application revision deletion.

---

## 18. Troubleshooting Guide

### Issue: Container revision will not start

Likely checks:

1. Image digest/tag exists in ACR.
2. Runtime managed identity has ACR pull permission.
3. Container Apps environment can resolve/reach ACR under the enterprise network policy.
4. Target port is `8080` and the process listens on `0.0.0.0`.
5. Startup command matches the Python/FastAPI image.
6. Required configuration values exist.

### Issue: Remote build fails

1. CI principal has ACR Tasks/build rights and repository write/push rights appropriate to the registry authorization mode.
2. Build executor can reach the source and ACR.
3. If ACR is private-only, use an approved network-connected build executor/agent pool.
4. Base image source is reachable from the build environment.

### Issue: Cosmos returns 401/403

1. Container App is using the intended managed identity.
2. Managed identity has Cosmos DB **data-plane** role assignment, not only resource Contributor.
3. Scope includes the required account/database/container.
4. Private DNS/private endpoint routing is healthy.

### Issue: Blob upload/export fails

1. Runtime identity has Storage Blob Data Contributor at the intended scope.
2. Storage public access is not being relied upon.
3. Private endpoint and DNS resolve correctly.
4. Container name/configuration is correct.

### Issue: AI calls fail

1. Model deployment exists in the approved region/project.
2. Runtime identity has the correct Foundry/model role.
3. Quota/deployment capacity is available.
4. Private/network route is allowed.
5. Application uses the correct endpoint/deployment name/API version for the approved model service.
6. Deterministic fallback still works.

### Issue: User can sign in but is unauthorized

1. User/group is assigned to the enterprise application/app role.
2. Token contains the expected `roles` claim.
3. Application checks the role claim expected by the environment.
4. Do not immediately add Graph permissions to fix a role-assignment problem.

### Issue: Graph call returns 403

1. Confirm the exact Graph endpoint and whether the app is using delegated or application access.
2. Confirm the requested permission matches that endpoint.
3. Confirm admin consent if required.
4. Confirm the token's audience is Microsoft Graph.
5. Avoid escalating to broad directory permissions until the exact narrow permission is proven insufficient.

### Issue: Internal hostname does not resolve

1. Confirm private DNS zone records/links.
2. Confirm corporate DNS forwarding to Azure-private zones.
3. Confirm VPN/corporate route to the VNet.
4. Confirm APIM/private ingress hostname is the one being resolved.

---

## 19. Cost Model

Exact Azure cost should **not** be copied from the AWS Lab estimate. It depends heavily on:

- approved Azure region
- Container Apps workload profile/min replicas
- whether APIM is a shared enterprise service or a new dedicated instance
- private endpoint/network egress architecture
- ACR tier and remote-build approach
- Cosmos DB serverless/provisioned/autoscale mode
- Log Analytics ingestion/retention
- model deployment and token usage

The cost review should be run after the platform team confirms the region, shared services, networking model, and approved model endpoint. APIM and AI capacity can dominate the cost more than the FastAPI container itself.

---

## 20. Definition of Done

The Azure transition is complete when:

- a developer with **no local Docker** can deploy through the approved pipeline
- the service is private/internal only
- Entra-authenticated users can access the application according to app roles
- the FastAPI endpoints and WebSocket functionality behave as before
- Cosmos DB replaces required DynamoDB state
- Blob Storage replaces required S3 artifacts
- the approved Azure AI/Foundry model replaces Bedrock with fallback retained
- no AWS access keys or Azure service secrets are stored in source code/container configuration
- logs, traces, health, and alerts are visible in Azure Monitor/Application Insights
- APIM is onboarded if required by the enterprise target state
- migration rollback and data-retention requirements have been tested
- AWS Lab resources can be retired without losing required data/artifacts

---

## 21. Access Dependencies

The actual access request is intentionally separated into:

**`AZURE_ACCESS_REQUIREMENTS.md`**

That file contains:

- P0/P1 access items
- proposed Entra groups
- Azure RBAC matrix by human/pipeline/runtime identity
- Graph permission tiers
- network/DNS requests
- ACR/remote-build requirements
- Foundry/model access requirements
- copy/paste ticket text

---

## 22. Microsoft Reference Notes

Role names and product names in this document were checked against Microsoft documentation on **2026-09-28**. Enterprise policy can further restrict them.

- Azure Container Apps networking and internal environments:  
  https://learn.microsoft.com/azure/container-apps/networking
- Azure Container Apps ingress:  
  https://learn.microsoft.com/en-us/azure/container-apps/ingress-how-to
- Container Apps ACR pull with managed identity:  
  https://learn.microsoft.com/en-us/azure/container-apps/managed-identity-image-pull
- Container Apps authentication with Microsoft Entra ID:  
  https://learn.microsoft.com/en-us/azure/container-apps/authentication-entra
- Azure Container Registry RBAC roles / ACR Tasks:  
  https://learn.microsoft.com/azure/container-registry/container-registry-rbac-built-in-roles-overview
- Microsoft identity platform app roles:  
  https://learn.microsoft.com/en-us/entra/identity-platform/howto-add-app-roles-in-apps
- Microsoft Graph permissions reference:  
  https://learn.microsoft.com/en-us/graph/permissions-reference
- Cosmos DB Entra/RBAC data access:  
  https://learn.microsoft.com/en-us/azure/cosmos-db/how-to-connect-role-based-access-control
- Storage data roles:  
  https://learn.microsoft.com/en-us/azure/role-based-access-control/built-in-roles/storage
- Container Apps Key Vault secret references:  
  https://learn.microsoft.com/en-us/azure/container-apps/manage-secrets
- Microsoft Foundry RBAC:  
  https://learn.microsoft.com/en-us/azure/foundry/concepts/rbac-foundry

