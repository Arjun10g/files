# Compete on outcomes, not on AI labels
## BMO hackathon — competitive evidence and investment brief
**Research cutoff: 8 September 2026. Currency: CAD unless stated.**

### Executive recommendation

Lead with CreditCompass as a payment-support decision layer on top of BMO's existing risk, customer, and servicing capabilities. Use PaymentShield as the proposed customer completion channel. Keep DecisionOps as a separate, bounded internal-efficiency option.

The commercial proposition is not a new default score, a cluster plot, or the first banking agent. It is more effective support per dollar of available capacity, with an observable outcome, an actual current-practice comparator, and controlled execution. Public evidence already establishes substantial forecasting, automation, and agentic capability at Canadian banks. [B1, R1, R2, T2, S1, C2]

The revised working case is CAD 638,333 in steady-state annual net benefit at a hypothetical 20-basis-point incremental default reduction. Implementation is CAD 478,800; recurring cost is CAD 400,000. First-year net is **negative CAD 100,050**, including a 75% benefit ramp and the full build. The credit-only annual break-even is 9.52 basis points, without assigning any value to released employee time. These are assumptions and arithmetic, not observed BMO outcomes.

## 1. What the competitive review actually establishes

### RBC: forecasting and transaction intelligence are not open territory
NOMI combines personalized insights, budgets, a rolling seven-day payment/deposit forecast, and Find & Save automated savings. RBC Borealis describes ATOM models learning irregular transaction sequences, with applications spanning NOMI and credit capacity. [R1, R2]

**Implication:** PaymentShield cannot distinguish itself merely by forecasting a shortfall, and CreditCompass cannot claim that learning from transaction histories is new. Our proposed difference must be the specific support decision: validate eligibility, prepare an appropriate response, complete the authorized handoff, and establish whether outcomes improved relative to current support. The reviewed material does not establish the absence of a private RBC intervention system.

### TD: multi-step AI is already operational
MySpend supplies cash-flow, spending-category, notification, and savings-goal capabilities. TD's July 2026 description of its mortgage agent covers document inspection, income analysis, policy checks, and underwriting preparation; it describes a deployed workflow. A separate branch knowledge assistant is available at substantial employee scale. [T1, T2, T3]

**Implication:** “An agent calls several tools” is not sufficient differentiation. DecisionOps needs a specific queue, a measured reduction in net preparation/rework, and no deterioration in control completeness. CreditCompass targets a different decision—post-origination payment support—but that difference is an investment hypothesis, not proof of superiority to TD.

### Scotiabank: action, not just alerts, already exists
Scotia Smart Money by Advice+ includes financial insights, upcoming activity, budgets, and automated savings through Pay Yourself First and Savings Finder. [S1]

**Implication:** Do not say competitors merely warn while we act. An own-account transfer is not inherently novel or evidence of better credit performance. PaymentShield's stronger branch is the customer who cannot safely transfer spare funds: preserve the constraint, prepare an eligible specialist handoff, and track whether assistance was actually completed.

### CIBC: the strongest direct overlap with a generic agent workspace
Insights supplies tailored spending tips, bill/subscription alerts, and spending forecasts described in its service terms. CIBC announced CAI 2.0, an enterprise agentic workspace, on 31 July 2026; it was in pilot at announcement. Its public examples include compliance and credit-document work. Separately, CIBC announced AdvisorAssist, and described CRTeX next-best actions and DocuMind document processing. [C1, C2, C3]

**Implication:** A generic employee agent, document summarizer, or next-best-action dashboard is a weak new-product pitch. Differentiate a named operating decision, its eligible action catalogue, its completion controls, and its measured incremental value. Do not attribute the original CAI chat deployment statistics to the CAI 2.0 pilot.

### National Bank: benchmark the documented experience without inventing a maturity ranking
The reviewed online banking material describes payments, transfers, balance/available-credit alerts, and a general virtual assistant. Its stated assistant scope excludes banking transactions and personal monetary-transaction questions. [N1]

**Implication:** A proposed individualized support workflow goes beyond that specifically documented assistant experience. It does not establish that National Bank lacks predictive models, collections technology, or other internal AI. Public internal-system coverage was narrower here and for Scotiabank than for the other banks.

## 2. BMO is the most important overlap check

BMO already describes predictive, causal, and agent layers in its decision-intelligence architecture. Its worked discussion is not a certification of the exact retail support workflow proposed here. Aura supports selected commercial underwriting work; faster underwriting by 2028 is a target, not an already achieved result. Commercial Next Best Offer prioritizes relevant client opportunities. Lumi addresses employee policy/procedure knowledge, while My Financial Progress and Credit Coach cover existing personal financial guidance. [B1–B5]

The first funding gate is therefore an internal owner review. Identify existing retail risk scores, early-warning queues, collections/support decisioning, action catalogues, consent services, and customer-channel capabilities. Reuse approved components wherever possible. If a comparable intervention workflow already exists, propose a bounded extension or experiment rather than a parallel product.

The credible positioning is: **one instrumented application of BMO's existing AI direction, with a Finance-owned outcome and an operating owner.**

## 3. The above-and-beyond product specification

### CreditCompass: from highest risk to greatest preventable loss

A risk score answers who is likely to experience difficulty. It does not by itself answer whose outcome can be improved by a permitted intervention. Descriptive clustering helps explain patterns; it is neither a default label nor evidence of treatment effectiveness.

Illustrative example, with identical CAD 12,000 exposure and 70% loss rate:

| Customer | Default risk | Hypothetical absolute reduction from support | Avoided loss before delivery cost |
|---|---:|---:|---:|
| A: severe difficulty | 30% | 0.5 percentage points | CAD 42 |
| B: solvable timing problem | 12% | 3.0 percentage points | CAD 252 |

Risk-only ranking places A first. An intervention-value approach can prioritize B for an optional proactive action while continuing required and appropriate assistance for A. The response estimates above are invented for explanation; the current demo does not estimate them from causal evidence.

The proposed production decision combines: an approved risk estimate; financial-behaviour cohort context; approved eligibility and customer-protection constraints; evidence on intervention effectiveness; delivery cost and available capacity; and the customer's preferences and required authorization. Its target metric is incremental net loss avoided per unit of support capacity—not cluster separation, model confidence, or messages generated.

**Implemented in the prior synthetic delivery:** fitted clusters, risk scoring, scenario economics, bounded tool orchestration, approval checks, and a synthetic campaign outbox. **Proposed extension:** learned intervention effects, real data/model validation, durable enterprise integration, and observed assignment-to-outcome feedback.

### PaymentShield: make an appropriate response easier to complete

The incremental scope is an embedded assistance journey, not a separate budget product. Validate scheduled commitments, available funds, freshness, consent, and eligibility; then prepare a feasible response. When an own-account movement cannot resolve the issue, do not invent liquidity or automatically grant new credit. Route an eligible support case with the relevant context.

Its success criterion is more completed, appropriate support and better downstream outcomes at an acceptable cost. Transfers, engagement, and customer satisfaction can be useful process measures, but do not independently prove avoided default loss. Moving money between a customer's own accounts does not create wealth or resolve structural financial distress.

The prior CreditCompass and PaymentShield demos are separate simulations. Production connection between campaign assignment and the customer journey remains work to do. Avoid counting the same prevented default once in each application.

### DecisionOps: eliminate one expensive preparation loop

Choose a queue whose preparation work can be timed. The workflow prioritizes a case, gathers evidence, identifies missing artifacts, tests a permitted next step, and routes an accountable decision. It must not close a missing control merely because it created a remediation task.

Measure net hands-on minutes, repeated touches, rework, escalation quality, and evidence completeness. Compare against existing knowledge tools and normal workflow automation. Do not monetize an unspecified avoided outage, regulatory fine, or reputational loss just to enlarge the return.

## 4. Why Bedrock earns a role—and how to test it

The useful agent adapts a plan when facts or constraints change. Examples include a disabled contact channel, insufficient specialist capacity, a stale source snapshot, or an ineligible action. Application code retains permission and execution authority; client-side Bedrock tool use supports that separation. [A4]

The demonstration should expose the read/check/compare/simulate/propose trace, a changed plan after a genuine constraint change, an unsuccessful self-approval attempt, and a repeated request that does not duplicate an effect. Live Bedrock access, request latency, and model routing must be verified in the approved lab. Offline rehearsal must stay visibly labelled.

Test three arms: **A**, current practice; **B**, model plus fixed workflow; **C**, the same model/action catalogue/eligibility and budget plus Bedrock. B minus A measures the model/workflow change. C minus B measures the agent's contribution. Retain the agent only where its net handling or outcome improvement exceeds its added cost and failure/rework burden.

## 5. Approximate cost to implement

These are bottom-up planning allowances, not BMO salaries, supplier quotes, or approved budgets. Existing data platforms, APIs, identity, and an assisted-support channel are assumed reusable. Significant core-system remediation, a new enterprise platform, or bankwide rollout would require a new estimate.

| CreditCompass work package | Person-days | Cost |
|---|---:|---:|
| Workflow discovery and data contracts/integration | 100 | CAD 120,000 |
| Risk/cohort integration and Bedrock approval workflow | 90 | CAD 108,000 |
| Executive/assisted-channel UX, cloud, identity, durable state | 65 | CAD 78,000 |
| Independent validation, privacy, QA, instrumentation, rollout | 75 | CAD 93,000 |
| Direct build | 330 | CAD 399,000 |
| Contingency, 20% | — | CAD 79,800 |
| **Total narrow implementation** | — | **CAD 478,800** |

Allow approximately CAD 480,000–800,000 for this narrow production service. A CAD 180,000–250,000 shadow/pilot phase is a subset of that envelope, not an additional fee; the recommended initial authorization is CAD 200,000. Lab-only demonstration hardening is not equivalent to production implementation.

Annual working cost: Bedrock inference CAD 20,000; cloud/network/storage/logs CAD 40,000; engineering/reliability CAD 120,000; monitoring/validation CAD 75,000; business QA/enablement CAD 55,000; incremental intervention delivery CAD 90,000. Total **CAD 400,000**, with a planning range of CAD 300,000–550,000.

For transparency, the token allowance uses a reference Sonnet 4.6 price of USD 3 per million input tokens and USD 15 per million output tokens. Fifty thousand annual runs at 30,000 total input and 5,000 total output tokens per run cost USD 8,250 before adjustments. A 1.10 regional factor, 1.50 retry/evaluation allowance, and assumed CAD/USD 1.40 produce CAD 19,057.50. These are not the lab's quoted Bedrock rates; replace them with the approved model/profile and measured all-turn token usage. [A1–A3]

Independent validation is substantive delivery work. OSFI's revised E-23 discusses purpose, lifecycle management, independent review and monitoring and becomes effective on 1 May 2027; it is not yet effective at this research cutoff. Privacy principles are another reason to budget controls rather than treat them as free. No compliance certification is implied. [G1, G2]

## 6. Revised incremental business case

The working case assumes 50,000 unique customers assigned per year. The same eligible population receives current support in the comparator. An example change from an 8.00% to a 7.80% default rate is a **20-basis-point absolute incremental improvement**. This intention-to-treat assumption already includes customers who cannot be reached or decline; do not multiply it by reach and uptake again.

Loss benefit: 50,000 × 0.002 × CAD 12,000 × 70% = **CAD 840,000**.

Capacity value: 50,000 × 8 net minutes / 60 × CAD 85/hour × 35% realization = **CAD 198,333**. Net minutes must already deduct new review and rework; released time is not automatically cash saved.

Annual net: CAD 840,000 + CAD 198,333 − CAD 400,000 = **CAD 638,333**. With no labour credit, the same assumed loss improvement still yields CAD 440,000 net annually.

First-year net: 75% × CAD 1,038,333 − CAD 400,000 − CAD 478,800 = **negative CAD 100,050**. Three-year undiscounted net is CAD 1,176,617; the simplified 10% NPV is CAD 872,656. These are pre-tax economic proxies. Charge-off/recovery timing, outcome maturity, actual implementation timing and Finance-approved treatment are needed for a cash-flow forecast. They are not immediate PCL releases.

One basis point of additional default reduction is worth CAD 42,000 at these assumptions. Annual credit-only break-even is 9.52 basis points; with the assumed capacity value it is 4.80 basis points. Including one-third of implementation cost raises the latter hurdle to 8.60 basis points. First-year break-even at 75% ramp is 23.18 basis points.

| Incremental default reduction | Annual net | First-year net including build |
|---:|---:|---:|
| 0 bp | −CAD 201,667 | −CAD 730,050 |
| 5 bp | CAD 8,333 | −CAD 572,550 |
| 10 bp | CAD 218,333 | −CAD 415,050 |
| 20 bp | CAD 638,333 | −CAD 100,050 |
| 40 bp | CAD 1,478,333 | CAD 529,950 |

The old CAD 1.52 million headline depended on unproven improvements in selection and a doubled relative support effect. This workbook removes those embedded assumptions and asks directly what incremental outcome would justify the spend. It does **not** assert that 20 basis points has been demonstrated.

## 7. Separate product cost boundaries

A native PaymentShield add-on is estimated at **CAD 150,000–300,000 additional build** and **CAD 75,000–150,000 additional annual cost**. At CAD 225,000 build and CAD 100,000 annual, it needs CAD 175,000 extra annual benefit to cover operating cost plus three-year build recovery. That is about **4.17 additional basis points** at the same population and severity, absent extra capacity gains. With no incremental benefit, the combined annual net falls to CAD 538,333; the combined first-year net is negative CAD 425,050.

A narrow DecisionOps implementation is estimated at **CAD 150,000–300,000 build** and **CAD 100,000–180,000 annual cost**. An illustrative 40,000 cases, 18 net minutes released, CAD 85/hour and 40% value realization give CAD 408,000 gross annual benefit. At CAD 180,000 run cost, annual net is CAD 228,000. At CAD 200,000 build and 75% ramp, first-year net is negative CAD 74,000. Annual break-even is about **7.94 net minutes per case**. Its denominator is cases, not CreditCompass customers.

## 8. Funding gates and evidence standard

Authorize up to CAD 200,000 within the full build envelope for a named owner to confirm overlap, establish the actual current-support baseline, secure approved data, and complete read-only shadow validation. Introduce governed support and independent approval only after the relevant operational, privacy, model, and security reviews. Maintain mandatory assistance across all experimental arms.

Track eligibility, assignment, delivery, acceptance, completed action, repeated contact, customer harm/complaints, net staff effort, delinquency progression and mature net losses. Compare by assignment, not only among customers who accept help. Do not rename earlier delinquency indicators or simulated ledger improvements “realized savings.”

A modest economic hurdle can require substantial statistical evidence. A simple two-arm normal approximation with 8% baseline default, a 20-basis-point absolute effect, 5% two-sided significance and 80% power gives about **289,000 customers per arm** before attrition, clustering or multiplicity. With 25,000 per arm, the approximate detectable effect is about 68 basis points. These are illustrative calculations, not a finalized trial design. Use the initial pilot to validate operational quality and completion; design and fund the longitudinal outcome study separately within an explicit evidence plan.

### Suggested executive close

> We are not asking BMO to buy another score or chatbot. We are proposing a controlled way to make its existing intelligence more effective: choose an eligible support response, complete it safely, and measure the incremental result. At our stated assumptions, roughly ten basis points of additional default reduction cover annual cost without relying on labour savings. Authorize the next evidence gate, retain the existing support standard, and scale only when Finance and the operating owner can verify the value.

## Use this package correctly

The PowerPoint contains 18 core slides and nine appendix/source slides, with speaker notes and linked primary sources. The nine-sheet workbook is the revised economic source of truth. Existing V2 HTML demos still contain their earlier economics and have not been modified by this research package. Use their workflow screens and the revised workbook/deck for the financial pitch. Existing demos remain synthetic; live Bedrock and BMO system integration are not established by this research delivery.

The review supports public-feature comparisons and specific hypotheses. It does not establish private-system absence, a bank maturity ranking, first-in-market status, achieved savings, or a like-for-like competitor ROI league table.

## Primary-source register

References below are bank/provider/regulator publications, not independent verification of bank-reported operational results. Accessed 8 September 2026 unless otherwise noted.

### B1 — BMO
**Publication/status:** 2026-08-21

Decision intelligence: predictive, causal and agent layers are already BMO's public architecture.

https://ai.bmo.com/our-stories/from-prediction-engines-to-decision-engines-building-an-agentic-decision-intelligence-layer/

### B2 — BMO
**Publication/status:** 2026-08-21

Aura is in selected commercial underwriting workflows; 50% faster underwriting by 2028 is a goal, not a realized result.

https://ai.bmo.com/our-stories/aura-helping-power-bmos-goal-of-50-faster-underwriting-by-2028/

### B3 — BMO
**Publication/status:** 2026-08-06

Commercial Next Best Offer prioritizes leads/offers through CRM; not proof of retail distress intervention coverage.

https://ai.bmo.com/our-stories/next-best-offer-turning-data-into-timely-client-conversations/

### B4 — BMO
**Publication/status:** Undated; accessed 2026-09-08

Lumi retrieves policy/procedure information; public article says no access to client information.

https://www.bmo.com/en-ca/main/about-bmo/news-insights/blog/meet-lumi-assistant-bmos-award-winning-ai-tool-empowering-team-bmo/

### B5 — BMO
**Publication/status:** 2026 awards; accessed 2026-09-08

My Financial Progress and Credit Coach are existing capabilities; do not pitch a generic planner as new.

https://www.bmo.com/en-ca/main/about-bmo/news-insights/blog/bmo-recognized-with-seven-digital-cx-awards/

### R1 — RBC
**Publication/status:** Undated; accessed 2026-09-08

NOMI combines insights, budgets, automated Find & Save, and rolling 7-day payment/deposit forecasts.

https://www.rbcroyalbank.com/mobile/feature/nomi/

### R2 — RBC Borealis
**Publication/status:** Undated; accessed 2026-09-08

ATOM learns transaction sequences; public examples include NOMI and credit capacity. Exact private risk workflow coverage is unknown.

https://rbcborealis.com/applications/atom/

### T1 — TD
**Publication/status:** Undated; accessed 2026-09-08

MySpend offers cash flow, spending categories, notifications and savings-goal support.

https://www.td.com/ca/en/personal-banking/solutions/ways-to-bank/td-myspend

### T2 — TD
**Publication/status:** 2026-07-31

Mortgage agent processes documents/income/policy and prepares underwriting material; TD reports deployment, not merely a concept.

https://stories.td.com/ca/en/article/agentic-ai

### T3 — TD
**Publication/status:** 2026-07-30

Branch knowledge assistant is available to 19,000+ colleagues; bank reports 89% fewer outgoing support calls. Workflow-specific, not comparable savings.

https://stories.td.com/ca/en/article/branch-banking-virtual-assistant

### S1 — Scotiabank
**Publication/status:** Undated; accessed 2026-09-08

Smart Money includes insights, upcoming activity, budgets and automated Pay Yourself First / Savings Finder transfers.

https://www.scotiabank.com/ca/en/personal/bank-your-way/digital-banking-guide/banking-basics/scotia-smart-money.html

### C1 — CIBC
**Publication/status:** Undated; accessed 2026-09-08

Insights includes spend tips, missed-bill/subscription alerts and spending forecasts in its terms.

https://www.cibc.com/en/personal-banking/ways-to-bank/mobile-services/insights.html

### C2 — CIBC
**Publication/status:** 2026-07-31

CAI 2.0 agentic workspace was in pilot at announcement; existing CAI chat reach must not be attributed to the 2.0 rollout.

https://cibc.mediaroom.com/2026-07-31-CIBC-introduces-the-first-enterprise-wide-agentic-AI-workspace-in-Canadian-banking

### C3 — CIBC
**Publication/status:** 2026-07-31

AdvisorAssist national launch; CRTeX next-best actions and DocuMind lending/fraud document processing already exist.

https://cibc.mediaroom.com/2026-07-31-CIBC-launches-new-AI-powered-platform-to-help-advisors-spend-more-time-with-clients

### N1 — National Bank
**Publication/status:** Undated; accessed 2026-09-08

Online banking supports payments, transfers, balance/credit alerts and a general virtual assistant. This is not an inventory of private AI systems.

https://www.nbc.ca/personal/accounts/services/online.html

### A1 — AWS
**Publication/status:** Accessed 2026-09-08

Bedrock pricing varies by provider, model, tier and region; account-specific quote must replace illustrative rates.

https://aws.amazon.com/bedrock/pricing/

### A2 — Anthropic
**Publication/status:** Accessed 2026-09-08

Sonnet 4.6 reference rates: USD 3/M input and 15/M output; regional endpoints have a 10% premium. Reference, not a BMO Bedrock quote.

https://platform.claude.com/docs/en/about-claude/pricing

### A3 — AWS
**Publication/status:** Accessed 2026-09-08

Fargate is metered by compute/memory resources; network, storage, logs and platform operations are separate.

https://aws.amazon.com/fargate/pricing/

### A4 — AWS
**Publication/status:** Accessed 2026-09-08

Client-side tool use lets application code execute model-requested tools; execution authorization stays in application code.

https://docs.aws.amazon.com/bedrock/latest/userguide/tool-use.html

### G1 — OSFI
**Publication/status:** 2025-09-11; effective 2027-05-01

E-23 describes purpose, lifecycle governance, independent review and monitoring. It is not yet effective on the research date.

https://www.osfi-bsif.gc.ca/en/guidance/guidance-library/guideline-e-23-model-risk-management-2027

### G2 — Canadian privacy regulators
**Publication/status:** Accessed 2026-09-08

Generative AI principles cover appropriate purpose, necessity/proportionality, accuracy, transparency and safeguards.

https://www.priv.gc.ca/en/privacy-topics/technology/artificial-intelligence/gd_principles_ai/
