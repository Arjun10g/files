# BMO competitive investment package
Research cutoff: 8 September 2026.

## Contents
- BMO_Competitive_Advantage_Pitch.pptx: editable 27-slide deck; 18 core slides and 9 appendix/source slides. Speaker notes and primary-source links included.
- BMO_Competitive_Advantage_Pitch.pdf: presentation-ready PDF.
- BMO_Competitive_ROI_Model.xlsx: nine formula-based sheets covering assumptions, build/run costs, incremental value, sensitivity, options, trial considerations and evidence.
- BMO_Competitive_Evidence_Brief.html: standalone readable research and investment brief; no server needed.
- BMO_Competitive_Evidence_Brief.md: editable text of the brief.
- sources.json: 21 dated primary-source records.
- VERIFICATION.json: artifact and arithmetic verification record.

## Presenting
Use the first 18 slides for the main investment narrative. The appendix contains alternative cost boundaries, implementation status, statistical-power qualifications, objections, a six-minute demo script, research limits and source links.

Use the existing V2 demos to show workflow behaviour. Use THIS deck and workbook for economics. The prior HTML files were not changed and still contain their earlier CAD 1.52m scenario. This package does not claim a new deployment, a live Bedrock run, a causal model, or demonstrated credit-loss savings.

## Revised base case
50,000 unique assigned customers; 20 bp hypothetical incremental default reduction versus current support; CAD 12,000 exposure; 70% loss rate; 8 net minutes released; CAD 85/hour; 35% capacity-value realization.
Build: CAD 478,800 including a proposed CAD 200,000 pilot authorization.
Annual run: CAD 400,000 including inference, support, validation and intervention delivery.
Annual net: CAD 638,333; year-one net at 75% benefit ramp: negative CAD 100,050.
Credit-only annual break-even, with no labour value: 9.52 bp.

All staffing, volumes, effects and costs are editable assumptions, not BMO data or supplier quotes. Three-year NPV is a simplified pre-tax economic proxy, not a charge-off/recovery cash-flow forecast. Customer-channel benefits must not be added twice to credit-loss benefits.

## Brand and scope
The deck uses the BMO-styled showcase treatment and prior vector logo recreation; it is not an approved private BMO design-system export. Public statements do not establish the absence of comparable private bank systems. Pilot/rollout status is qualified in the sources.
