# V4.1 — Named financial profiles

## What changed

CreditCompass now uses four names grounded in the existing training-centroid features:

| Fixed model ID | Previous label | New presentation name |
|---|---|---|
| 0 | Buffered cash flow | Stable & Buffered |
| 1 | Variable income | Variable-Income Squeeze |
| 2 | Payday mismatch | Payday Timing Gap |
| 3 | Sustained pressure | Sustained Payment Pressure |

The names appear on the chart, profile selectors, evidence screen, agent messages and campaign exports. Each profile has a descriptive feature panel, historical offer outcomes, later holdout effect estimates, appropriate uncertainty, an editorial support starting point, customer-safe example copy, and profile-specific simulated tool responses.

The new “Review profile fit” view exposes 14 unique displayed cases: three with maximum GMM membership below the illustrative 0.80 threshold, twelve where K-means and GMM disagree, with one overlap. This is not a fifth cluster. It does not change scoring, campaign eligibility or any credit treatment.

PaymentShield remains a separate demonstration. Profile links open an appropriate independent scenario. No cluster name or risk score is shown in the customer phone interface. The year-long support offer in the synthetic experiment is not equated with a one-time transfer or support request in the phone fixture.

## What did not change

The 1,600 display rows, eight feature values, fitted assignments, projected centres/contours, risk/response predictions and all numerical model-evaluation results are unchanged. The allocator adds names as explanation metadata but chooses identical customer/action pairs for identical inputs. The cost and savings scenario remains a separately labelled hypothesis, not a transformation of synthetic effect estimates into bank savings.

The four support starting points are editorial interpretations consistent with the earlier 2024 history, not a new learned model or a policy fitted on the 2025 test. The later effects evaluate the offers against usual support; they do not provide direct specialist-versus-digital confidence intervals or individual effect guarantees. The buffered cohort does not show clear extra benefit from either offer, but appropriate, requested and required support remains available.

## Release verification

18 Python artifact-integrity tests passed. 125 browser checks passed with zero browser script errors. Screenshots cover named profiles, Gaussian mixtures, profile details, comparative evidence, ambiguous membership, agents, and desktop/mobile views. Checks also cover unchanged allocation, role separation in the simulator, replay receipts, unchanged economic calculations, bank comparison tabs, and the PaymentShield reserve-change journey.

The browser rendered the exact generated HTML through Playwright `set_content`. Direct `file://` navigation is blocked by the managed browser environment; it is not claimed as tested. Responsive pages were checked at 1440, 390 and 360 pixels. The phone screenshots use a simulated viewport, not a physical device.

This is an offline profile/UI release, not a completed production deployment. The 18 tests here do not replace the previous V4 training/backend test suite or assert that its previously reported failing check has been resolved. Model training was not rerun. No live Bedrock inference, Docker build, AWS deployment, bank authentication, real customer action or measured savings was performed.

## What the agent rehearsal demonstrates

Four named roles inspect the profile, read the intervention evidence, check an illustrative constraint and prepare a review brief. Preferred-channel unavailability produces a capacity-review brief rather than transferring a treatment-effect estimate to an untested fallback. Stale evidence pauses optional preparation. Ordinary/required support remains available.

These are deterministic messages grounded in packaged data and tool outputs. They are not separately deployed agents, private model reasoning or a live LLM test. A real Bedrock pilot must compare the same models and permitted actions with and without agent orchestration.

## Source and design boundary

This update uses the supplied V4 HTML and exported synthetic model evaluation. The original SHA-256 references are in `artifacts/provenance.json`. The original data is preserved in `artifacts/showcase_data_original.json`. Competitor evidence is carried forward from the supplied V4 brief; it was not newly investigated in this profile update.

The interface uses BMO styling and the earlier recreated wordmark. It is a hackathon concept, not an official production BMO application or an export of the private brand-design system.
