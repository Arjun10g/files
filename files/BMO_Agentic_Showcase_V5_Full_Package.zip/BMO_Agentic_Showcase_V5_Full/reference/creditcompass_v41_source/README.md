# BMO — Named Financial Profiles Showcase (V4.1)

Extract the ZIP. Open `START_HERE.html` in a browser. No account, installation or internet connection is required to run the two self-contained demos. External research links naturally require internet access.

## The story

**CreditCompass:** Which customers may benefit from which support? The four financial profiles now explain the patterns and connect them to evidence and an accountable next step.

**PaymentShield:** What does an appropriate, customer-controlled response look like? Its phone journey remains separate and never exposes the internal cluster label.

## Main files

`CreditCompass_V41.html` contains the executive showcase, named clusters, profile details, synthetic model evaluation, agent rehearsals, economics and bank comparison.

`PaymentShield_V41.html` contains the standalone customer showcase. The optional query `?scenario=timing`, `?scenario=income` or `?scenario=limited` selects an independent account fixture.

`docs/PROFILE_GUIDE.html` is a readable profile guide with exact evidence and a short presentation flow. `docs/COMPETITIVE_EVIDENCE.html` preserves the previously supplied bank comparison. `docs/RELEASE_NOTES.md` states the tested scope and limitations.

`artifacts/cluster_profiles.json` contains versioned names, feature bases, historical counts, held-out effects and intended presentation routes. `artifacts/model_validation.json` preserves V4 metrics with the new display names. `artifacts/showcase_data_original.json` allows a numerical comparison with the inherited data.

## Suggested two-minute demonstration

Open CreditCompass on Payday Timing Gap. Read the name, its three defining features and the candidate assistance route. Open the profile and show historical offer outcomes versus later held-out evidence.

Choose Watch agents. Make the preferred channel unavailable, then make the evidence stale. Show that the result changes without approving outreach or inventing a fallback effect.

Compare Stable & Buffered, where neither extra offer has a clearly established benefit. Open the four-profile comparison and highlight why highest risk is not automatically the greatest treatment response.

Open the separate PaymentShield scenario. Raise the protected savings reserve from the initial setting to CAD 1,500. The feasible transfer disappears and an appropriate support request is prepared.

## Rebuild and test

The source rebuild needs only Python's standard library:

```bash
python src/build.py
python -m unittest discover -s tests -v
```

Browser checks additionally need Playwright and a Chromium installation:

```bash
python tests/browser_checks.py
```

Set `CHROMIUM_PATH` to an available Chromium executable when required. The test script otherwise uses `/usr/bin/chromium` when it exists, or Playwright's installed browser.

`src/prepare_data.py` documents the initial profile attachment operation. The packaged data is already prepared; ordinary rebuilding does not need that script or the old V4 files. Its provenance inputs reference the original delivery environment.

## Execution boundary

This ZIP is a focused offline profile update, not the earlier full lab deployment repository. It contains source for the browser demos and checks, but no live Bedrock adapter, training pipeline or production banking integration. Existing trained outputs are preserved; no new clusters or improved predictive performance are claimed. Agent messages are simulated, outcomes are synthetic, and realized savings remain zero.
