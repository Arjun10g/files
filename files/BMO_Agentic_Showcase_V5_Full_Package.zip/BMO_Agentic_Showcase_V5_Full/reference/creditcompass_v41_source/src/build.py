"""Rebuild the self-contained profile showcases using only packaged source files.

No web requests, model training, external package installation or cloud calls.
"""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
data=json.loads((ROOT/'artifacts/showcase_data.json').read_text())
profiles=json.loads((ROOT/'artifacts/cluster_profiles.json').read_text())
css=(ROOT/'src/profiles.css').read_text()
ext=(ROOT/'src/profiles.js').read_text()
common='''\nshowMode=function(){modal('What is running?',`<div class="grid2"><div class="card pad"><h3>Offline profile showcase</h3><p class="small mt12">Fitted V4 cluster assignments, scores and intervention evidence are preloaded. This V4.1 update gives them descriptive names, financial profiles and evidence-grounded rehearsal messages.</p><p class="small mt12"><b>No live LLM, separately hosted agent or banking action runs here.</b> Agent roles use deterministic tool outputs for the presentation.</p></div><div class="card pad"><h3>Lab deployment is separate</h3><p class="small mt12">This focused bundle contains browser source, inputs, inherited evaluation and new UI checks. It does not include a live backend or reproduce model training. Earlier lab deployment packages are separate.</p><p class="small mt12">A live Bedrock integration would need approved identity, credentials, tools and independent execution controls. No live Bedrock call or AWS deployment is claimed.</p></div></div><div class="annotation mt20">The prototype role switch is not authentication. The profile labels do not authorize outreach, change credit terms or deny required support.</div>`)};\n'''
for prefix,product in [('credit','CreditCompass'),('payment','PaymentShield')]:
 template=(ROOT/f'src/{prefix}_template.html').read_text()
 script=(ROOT/f'src/{prefix}_base.js').read_text()
 template=template.replace('</style>',css+'\n</style>')
 script=script.replace('CreditCompass_V4.html','CreditCompass_V41.html').replace('PaymentShield_V4.html','PaymentShield_V41.html')
 script=script.replace('CreditCompass_V4_model_validation.json','CreditCompass_V41_model_validation.json')
 script=script.replace('Production fit restored','Fitted assignments restored')
 script=script.replace('Data, model, audit arrays and reproduction scripts are included.','The inherited model evaluation and display inputs are included. This update does not include or rerun the training pipeline.')
 if prefix=='credit':
  script=script.replace('For payday mismatch,','For ${esc(PROFILES[2].name)},').replace('For variable income,','For ${esc(PROFILES[1].name)},')
  anchor='const hash=location.hash.slice(1);'
  script=script.replace(anchor,'const PROFILE_PACK='+json.dumps(profiles,separators=(',',':'),ensure_ascii=False)+';\n'+common+ext+'\n'+anchor)
 else:
  anchor='renderPayment();window.PAYMENT='
  before="const profileScenario=new URLSearchParams(location.search).get('scenario');if(['timing','limited','income'].includes(profileScenario)){P.fixture=paymentFixture(profileScenario);}\n"
  assert anchor in script
  script=script.replace(anchor,common+before+anchor)
 html=template.replace('__DATA__',json.dumps(data,separators=(',',':'))).replace('__SCRIPT__',script)
 html=html.replace(product+' | BMO focused showcase',product+' | BMO named financial profiles V4.1')
 (ROOT/f'{product}_V41.html').write_text(html)
 (ROOT/f'src/{prefix}_compiled.js').write_text('const DATA='+json.dumps(data,separators=(',',':'))+script)
 print(product,len(html))
