"""Checks for the profile-only update. Run: python -m unittest discover -s tests -v"""
import unittest,json,copy,math
from pathlib import Path
R=Path(__file__).resolve().parents[1]
O=json.loads((R/'artifacts/showcase_data_original.json').read_text())
D=json.loads((R/'artifacts/showcase_data.json').read_text())
P=json.loads((R/'artifacts/cluster_profiles.json').read_text())
class ArtifactChecks(unittest.TestCase):
 def test_display_rows_unchanged(self):self.assertEqual(O['rows'],D['rows'])
 def test_model_version_unchanged(self):self.assertEqual(O['version'],D['version'])
 def test_fit_artifacts_unchanged(self):
  for k in ['features','arms','bounds','ellipses','iterations','centers','pca_loadings']:self.assertEqual(O[k],D[k])
 def test_validation_unchanged_except_names(self):
  d=copy.deepcopy(D['metrics'])
  for k,v in O['metrics']['cluster_summaries'].items():d['cluster_summaries'][k]['name']=v['name']
  self.assertEqual(O['metrics'],d)
 def test_four_names(self):self.assertEqual([D['labels'][str(i)] for i in range(4)],['Stable & Buffered','Variable-Income Squeeze','Payday Timing Gap','Sustained Payment Pressure'])
 def test_unique_ids(self):self.assertEqual(len({r['id'] for r in D['rows']}),1600)
 def test_fixed_cluster_counts(self):
  for k,p in P['profiles'].items():self.assertEqual(p['displayed_kmeans_n'],sum(r['cluster']==int(k) for r in D['rows']))
 def test_mixture_counts(self):
  for k,p in P['profiles'].items():self.assertEqual(p['displayed_gmm_n'],sum(r['gmm']==int(k) for r in D['rows']))
 def test_profile_evidence_provenance(self):
  for k,p in P['profiles'].items():
   m=O['metrics']['cluster_summaries'][k]
   for pk,mk in [('training_centroid_means','means'),('historical_arms','history_arms'),('holdout_effects','test_effects')]:self.assertEqual(p[pk],m[mk])
 def test_history_totals(self):self.assertEqual(sum(p['historical_n'] for p in P['profiles'].values()),12000)
 def test_holdout_totals(self):self.assertEqual(sum(p['holdout_n'] for p in P['profiles'].values()),24000)
 def test_review_fit_counts(self):
  rows=D['rows'];t=P['review_fit']['threshold']
  self.assertEqual(sum(r['membership']<t for r in rows),3)
  self.assertEqual(sum(r['gmm']!=r['cluster'] for r in rows),12)
  self.assertEqual(sum(r['membership']<t or r['gmm']!=r['cluster'] for r in rows),14)
 def test_buffered_uncertainty(self):
  for e in P['profiles']['0']['holdout_effects']:self.assertLessEqual(e['aipw']['low'],0);self.assertGreaterEqual(e['aipw']['high'],0)
 def test_named_candidate_effects_positive(self):
  for k in ['1','2','3']:
   p=P['profiles'][k];e=next(x for x in p['holdout_effects'] if x['arm']==p['arm']);self.assertGreater(e['aipw']['low'],0)
 def test_probability_serialization_tolerance(self):
  # Check display probabilities with numerical tolerances, not decimal-string equality.
  for r in D['rows']:
   for v in r['probabilities']:self.assertTrue(-1e-12<=v<=1+1e-12)
   self.assertTrue(0<=r['membership']<=1+1e-12)
 def test_no_fifth_cluster(self):self.assertEqual(set(r['cluster'] for r in D['rows']),{0,1,2,3})
 def test_names_not_outcome_authority(self):self.assertIn('not a fifth cluster',P['review_fit']['label'])
 def test_html_self_contained(self):
  for p in [R/'CreditCompass_V41.html',R/'PaymentShield_V41.html']:
   s=p.read_text();self.assertNotIn('<script src=',s);self.assertNotIn('__DATA__',s);self.assertNotIn('__SCRIPT__',s);self.assertNotIn('PaymentShield_V4.html',s)
if __name__=='__main__':unittest.main()
