"""Exercise the exact generated HTML without a web server.

Install Playwright and Chromium in a test environment. The optional CHROMIUM_PATH
selects an existing executable. Browser navigation may be restricted by managed
policy; set_content renders the complete delivered document for these checks.
"""
from pathlib import Path
import os,json,math,sys
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];SHOTS=R/'artifacts/screenshots'
checks=[];errors=[]
def check(name,result):
 checks.append({'name':name,'passed':bool(result)})
 if not result: raise AssertionError(name)
def snap(page,name,full=False):page.screenshot(path=str(SHOTS/(name+'.png')),full_page=full)
def no_overflow(page):return page.evaluate('document.documentElement.scrollWidth <= innerWidth+1')
with sync_playwright() as p:
 path=os.environ.get('CHROMIUM_PATH') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None)
 opts={'headless':True,'args':['--no-sandbox']}
 if path:opts['executable_path']=path
 browser=p.chromium.launch(**opts)
 def load(name='CreditCompass_V41.html',width=1440,height=1050,reduce=True):
  page=browser.new_page(viewport={'width':width,'height':height},reduced_motion='reduce' if reduce else 'no-preference',accept_downloads=True)
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content((R/name).read_text(),wait_until='load');page.wait_for_timeout(110)
  return page
 page=load();names=page.evaluate('Object.values(PROFILES).map(p=>p.name)')
 check('initial named chart',page.locator('h1').inner_text()=='Different patterns. The right kind of support.')
 check('four profile cards',page.locator('.profile-mini').count()==4)
 check('1,600 unchanged inputs',page.evaluate('DATA.rows.length')==1600)
 check('desktop no horizontal overflow',no_overflow(page))
 for k in range(4):
  page.evaluate(f'selectCluster({k})');check(f'select profile {k}',page.locator('.profile-panel h2').inner_text()==names[k])
  check(f'profile {k} actual representative',page.evaluate(f'DATA.rows[representativeIndex({k})].cluster')==k)
  page.evaluate(f'openProfile({k})');check(f'profile dossier {k}',page.locator('#modal-title').inner_text()==names[k])
  check(f'profile {k} all three history arms',page.locator('.profile-hist > div').count()==3)
  check(f'profile {k} both effect rows',page.locator('.profile-dossier .data-table tbody tr').count()==2)
  check(f'profile {k} not bank claim','No new model is fitted' in page.locator('.modal').inner_text())
  if k==0:check('buffered uncertainty visible','No clear extra benefit' in page.locator('.modal').inner_text())
  if k==2:snap(page,'02_payday_profile')
  page.get_by_role('button',name='Close',exact=True).click()
  check(f'close profile modal {k}',page.locator('.modal').count()==0)
 page.evaluate('selectCluster(2)');snap(page,'01_named_profiles_desktop',True)
 page.evaluate("setAlgorithm('gmm')");check('GMM toggle',page.evaluate('C.algorithm')=='gmm')
 check('GMM legend count still 1600',page.evaluate("[...document.querySelectorAll('.legend-item b')].reduce((s,b)=>s+Number(b.textContent.replace(/,/g,'')),0)")==1600)
 snap(page,'04_gaussian_mixture')
 page.evaluate("setAlgorithm('kmeans');replayClustering()");check('fit replay restores assignments',page.evaluate('C.replayFrame')==-1)
 page.evaluate('compareProfiles()');check('comparison four rows',page.locator('.profile-comparison tbody tr').count()==4)
 check('comparison interval present','6.17 pp' in page.locator('.modal').inner_text());snap(page,'05_profile_comparison')
 page.evaluate('closeModal();showFitReview()');check('14 ambiguous cases',page.locator('.modal .data-table tbody tr').count()==14)
 check('membership not default disclaimer','not a probability of default' in page.locator('.modal').inner_text());snap(page,'06_fit_review')
 page.evaluate('inspectCustomer(DATA.rows.reduce((a,r,i)=>r.membership<DATA.rows[a].membership?i:a,0))')
 check('ambiguous customer inspection',page.locator('.review-badge').count()>0)
 check('individual no biography','No occupation' in page.locator('.modal').inner_text());page.evaluate('closeModal()')
 for k in range(4):
  for scenario in ['normal','channel','stale']:
   out=page.evaluate('([k,s])=>profileAgentSteps(k,s)',[k,scenario]);check(f'profile {k} {scenario} four tools',len(out)==4)
   check(f'profile {k} {scenario} no action',out[-1]['evidence']['outreach']==0)
   if scenario=='stale':check(f'profile {k} pauses on stale',out[-1]['evidence']['status']=='paused')
   elif scenario=='channel' and k!=0:check(f'profile {k} channel no forced fallback',out[-1]['evidence']['status']=='capacity_review')
 page.evaluate("playProfileAgents(1,'normal')")
 check('animated profile agent steps complete',page.locator('.profile-agent-message').count()==4)
 check('agent brief not approval','no automatic approval' in page.locator('#profile-agent-result').inner_text());snap(page,'03_profile_agents')
 page.get_by_label('Profile agent scenario').select_option('channel');page.wait_for_timeout(100)
 check('interactive channel constraint updates brief','Capacity review' in page.locator('#profile-agent-result').inner_text())
 page.get_by_label('Profile agent scenario').select_option('stale');page.wait_for_timeout(100)
 check('interactive stale stops preparation','Paused for fresh evidence' in page.locator('#profile-agent-result').inner_text())
 with page.expect_download() as dl:page.get_by_role('button',name='Export this rehearsal').click()
 download=dl.value;dest=R/'artifacts/example_profile_agent_trace.json';download.save_as(dest)
 trace=json.loads(dest.read_text());check('export trace carries stale scenario',trace['scenario']=='stale');check('export no claimed savings',trace['realized_savings']==0)
 page.evaluate('closeModal()')
 for k in range(4):
  page.evaluate(f"C.cluster={k};go('evidence')")
  check(f'evidence profile ribbon {k}',page.locator('.profile-ribbon h3').inner_text()==names[k])
  if k==0:check('evidence no forced extra offer','Do not force an extra intervention' in page.locator('.scene').inner_text())
 page.evaluate("C.cluster=2;go('evidence')");snap(page,'07_named_intervention_evidence',True)
 # Names are metadata, never a new selection feature.
 for options in [{},{'digital':False},{'specialists':10},{'stale':True},{'cap':0},{'budget':0}]:
  got=page.evaluate('(o)=>{const a=originalPlanCampaign(o),b=planCampaign(o);return {a:a.assignments,b:b.assignments.map(({profile_name,profile_version,...r})=>r),assigned:b.assigned,cost:b.spend}}',options)
  check('allocator unchanged '+str(options),got['a']==got['b'])
 page.evaluate("go('agents');runAgents('normal')")
 check('campaign 160 contacts',page.evaluate('C.plan.assigned')==160)
 check('campaign CAD 6700',page.evaluate('C.plan.spend')==6700)
 check('campaign named metadata',page.evaluate('C.plan.assignments.every(a=>a.profile_name===PROFILES[a.cluster].name)'))
 page.evaluate("C.role='analyst';approveCampaign()");check('self approval blocked',page.evaluate('C.receipt===null'))
 page.evaluate("C.role='approver';approveCampaign()");receipt=page.evaluate('C.receipt');check('independent approval recorded',bool(receipt))
 page.evaluate('approveCampaign()');check('approval retry no new receipt',page.evaluate('C.receipt')==receipt)
 page.evaluate("runAgents('no_digital')");check('no digital assignments when unavailable',page.evaluate('C.plan.counts[1]')==0)
 page.evaluate("runAgents('stale')");check('campaign stale blocked',page.evaluate('C.plan.blocked && C.plan.assigned===0'))
 page.evaluate("go('value')");e=page.evaluate('economy()');check('annual projection unchanged',math.isclose(e['net'],638333.3333333334));check('no labour scenario unchanged',page.evaluate('economy(20,8,false).net')==440000)
 page.evaluate("go('market')");check('six bank tabs',page.locator('.bank-tab').count()==6)
 for bank in ['RBC','TD','Scotiabank','CIBC','National Bank','BMO']:
  page.get_by_role('button',name=bank,exact=True).click();check('bank evidence '+bank,page.locator('.scene').inner_text().find(bank)>=0)
 # Each small viewport renders from a fresh JS realm.
 for width in [390,360]:
  mobile=load(width=width,height=844)
  check(f'mobile {width} no overflow',no_overflow(mobile));check(f'mobile {width} four profiles',mobile.locator('.profile-mini').count()==4)
  if width==390:snap(mobile,'08_named_profiles_mobile',True)
  mobile.evaluate('openProfile(3)');check(f'mobile {width} modal no body overflow',no_overflow(mobile))
  if width==390:snap(mobile,'09_pressure_profile_mobile')
  mobile.evaluate('closeModal();compareProfiles()');check(f'mobile {width} comparison scroll contained',no_overflow(mobile));mobile.close()
 pay=load('PaymentShield_V41.html',390,844)
 check('phone no horizontal overflow',no_overflow(pay))
 check('customer phone excludes profile names',not any(n in pay.locator('.phone').inner_text() for n in names))
 pay.evaluate('startReview();allowReview()');pay.wait_for_function('P.plan !== null && !P.busy');check('payment initially feasible transfer',pay.evaluate('P.plan.kind')=='transfer');check('payment initial amount 600',pay.evaluate('P.plan.amount')==600)
 snap(pay,'10_paymentshield_mobile',True)
 pay.evaluate('keepReserve()');pay.wait_for_function('P.plan !== null && !P.busy');check('raise reserve changes to support',pay.evaluate('P.plan.kind')=='support')
 pay.evaluate('confirmAction()');receipt=pay.evaluate('P.receipt');check('customer receipt recorded',bool(receipt))
 pay.evaluate('confirmAction()');check('customer retry stable',pay.evaluate('P.receipt')==receipt)
 pay.close()
 start=load('START_HERE.html');check('start page two demos',start.locator('.cards .card').count()==2);check('start no overflow',no_overflow(start));start.close()
 check('no browser script errors',not errors)
 browser.close()
report={'scope':'V4.1 inherited-artifact integrity and browser UI checks only. No live Bedrock, AWS or fresh training.','browser_checks':len(checks),'passed':sum(c['passed'] for c in checks),'script_errors':errors,'checks':checks,'browser_loading':'Exact delivered HTML rendered with Playwright set_content. Direct file navigation is blocked by managed browser policy; file-opening and live deployment are not claimed as tested.'}
(R/'artifacts/browser_verification.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['checks']},indent=2))
