"""Verify every listed packaged file using only the Python standard library.

Run before changing source or regenerating outputs. The manifest detects changes;
it is not a trusted digital signature or production evidence-authenticity proof.
"""
from pathlib import Path
import hashlib
import sys
ROOT = Path(__file__).resolve().parent
failures = []
entries = 0
for line in (ROOT / 'MANIFEST.sha256').read_text().splitlines():
    expected, relative = line.split('  ', 1)
    path = (ROOT / relative).resolve()
    entries += 1
    if not path.is_relative_to(ROOT) or not path.is_file():
        failures.append(f'Missing or unsafe path: {relative}')
    elif hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        failures.append(f'Changed file: {relative}')
if failures:
    print('\n'.join(failures))
    sys.exit(1)
print(f'All {entries} manifest entries verified.')
