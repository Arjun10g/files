"""Reassemble the delivered self-contained demos. No network calls or model fitting."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def build() -> None:
    for prefix, output in [('payment', 'PaymentShield_V5.html'), ('creditcompass', 'CreditCompass_V5.html')]:
        if prefix == 'payment':
            source = ''.join((ROOT / 'src' / name).read_text() for name in ['payment_preamble.js', 'payment_domain.js', 'payment_app.js'])
        else:
            source = (ROOT / 'src/creditcompass_app.js').read_text()
        template = (ROOT / 'src' / f'{prefix}_template.html').read_text()
        assert template.count('__INLINE_APPLICATION__') == 1
        (ROOT / output).write_text(template.replace('__INLINE_APPLICATION__', source))
        print(f'Rebuilt {output}')

if __name__ == '__main__':
    build()
