(function(root,factory){const e=factory();if(typeof module==='object'&&module.exports)module.exports=e;else root.PSEngine=e;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const clone=x=>JSON.parse(JSON.stringify(x));
const money=n=>new Intl.NumberFormat('en-CA',{style:'currency',currency:'CAD',maximumFractionDigits:n%100?2:0}).format(n/100);
const iso=()=>new Date().toISOString();
const ROLES=[
 {id:'conductor',name:'Journey coordinator',short:'Coordinator',initials:'JC',specialty:'Owns the brief. Delegates and reconciles.',tools:['read_brief','assemble_plan'],lane:0},
 {id:'evidence',name:'Account evidence agent',short:'Evidence',initials:'AE',specialty:'Checks the snapshot, bills and provenance.',tools:['read_snapshot'],lane:1},
 {id:'cashflow',name:'Cash-flow analyst',short:'Cash flow',initials:'CF',specialty:'Projects commitments and timing sensitivity.',tools:['project_cashflow'],lane:2},
 {id:'options',name:'Support strategist',short:'Strategy',initials:'SS',specialty:'Compares feasible alternatives with evidence.',tools:['compare_options'],lane:3},
 {id:'critic',name:'Suitability reviewer',short:'Suitability',initials:'SR',specialty:'Challenges the recommendation; can block it.',tools:['review_suitability'],lane:4},
 {id:'communications',name:'Customer advocate',short:'Customer advocate',initials:'CA',specialty:'Prepares the exact ask, alternatives and follow-up.',tools:['draft_customer_brief'],lane:5}
];
function fixture(id='timing'){
 const f={id,customer:'Alex',customerId:'SYN-PS-001',profileId:2,version:1,clock:'2026-09-08T13:30:00-04:00',observedAt:'2026-09-08T13:25:00-04:00',balance:62000,savings:185000,reserve:100000,target:10000,payroll:240000,payday:15,consent:false,fresh:true,digital:true,specialist:true,preferSupport:false,declined:false,failExecution:false,bills:[{id:'BILL-010',day:10,name:'Utility payment',amount:18000},{id:'BILL-011',day:11,name:'Card minimum',amount:25000},{id:'BILL-012',day:12,name:'Housing commitment',amount:69000},{id:'BILL-017',day:17,name:'Insurance payment',amount:16000}]};
 if(id==='limited')Object.assign(f,{customer:'Jordan',customerId:'SYN-PS-002',savings:106000,profileId:3});
 if(id==='income')Object.assign(f,{customer:'Sam',customerId:'SYN-PS-003',balance:42000,savings:128000,payroll:160000,payday:19,profileId:1});
 if(id==='buffered')Object.assign(f,{customer:'Taylor',customerId:'SYN-PS-004',balance:320000,savings:640000,profileId:0});
 if(!['timing','limited','income','buffered'].includes(id))throw Error('Unknown fixture');
 return f;
}
function validate(f){
 for(const k of ['balance','savings','reserve','target','payroll','version','payday'])if(!Number.isSafeInteger(f[k])||f[k]<0)throw Error('Invalid '+k);
 if(f.payday<9||f.payday>24||f.version<1||f.target>100000)throw Error('Fixture out of bounds');
 for(const k of ['consent','fresh','digital','specialist','preferSupport'])if(typeof f[k]!=='boolean')throw Error('Invalid '+k);
 if(!Array.isArray(f.bills)||f.bills.length>30)throw Error('Invalid bill list');
 const ids=new Set();for(const b of f.bills){if(!Number.isSafeInteger(b.amount)||b.amount<0||!Number.isSafeInteger(b.day)||b.day<9||b.day>28||ids.has(b.id))throw Error('Invalid bill');ids.add(b.id);}
 return f;
}
function canonical(o){if(Array.isArray(o))return '['+o.map(canonical).join(',')+']';if(o&&typeof o==='object')return '{'+Object.keys(o).sort().map(k=>JSON.stringify(k)+':'+canonical(o[k])).join(',')+'}';return JSON.stringify(o);}
function fingerprint(f){let h=2166136261;const source=clone(f);delete source.failExecution;const t=canonical(source);for(let i=0;i<t.length;i++){h^=t.charCodeAt(i);h=Math.imul(h,16777619);}return 'snap-'+(h>>>0).toString(16).padStart(8,'0');}
function gate(f){if(!f.consent)return {ok:false,reason:'One-time assistance consent has not been granted.',code:'CONSENT'};if(!f.fresh)return {ok:false,reason:'Refresh the account data before preparing or approving an action.',code:'STALE'};return {ok:true};}
function evidence(f,profiles={}){
 validate(f);const refs=[
 {id:'ACC-v'+f.version,kind:'Account snapshot',owner:'Synthetic account adapter',observedAt:f.observedAt,value:{chequing_cents:f.balance,savings_cents:f.savings},summary:`${money(f.balance)} in chequing; ${money(f.savings)} in savings.`,certainty:'Fixture · observed balance'},
 {id:'PAY-v'+f.version,kind:'Expected deposit',owner:'Synthetic income feed',observedAt:f.observedAt,value:{amount_cents:f.payroll,day:f.payday},summary:`Expected pay ${money(f.payroll)} on September ${f.payday}. Not guaranteed.`,certainty:'Fixture · expected, not settled'},
 {id:'PREF-v'+f.version,kind:'Customer preference',owner:'Customer',observedAt:f.clock,value:{reserve_cents:f.reserve,consent:f.consent,prefer_support:f.preferSupport},summary:`Keep ${money(f.reserve)} in savings; ${f.preferSupport?'customer requests support':'compare available options'}.`,certainty:'Explicit instruction'},
 {id:'POL-001',kind:'Illustrative eligibility rules',owner:'Hackathon policy fixture',observedAt:'2026-09-08',value:{required_consent:true,requires_fresh_data:true,target_cents:f.target,allowed:['own-account transfer','support request','ordinary service'],requires_confirmation:true},summary:'Own-account funds only. Respect the customer reserve. Recheck freshness. Require confirmation.',certainty:'Not BMO policy'},
 {id:'CAP-v'+f.version,kind:'Channel availability',owner:'Synthetic capacity adapter',observedAt:f.clock,value:{digital:f.digital,specialist:f.specialist},summary:`Transfer channel ${f.digital?'available':'unavailable'}; specialist intake ${f.specialist?'available':'unavailable'}.`,certainty:'Fixture · capacity state'},
 ...f.bills.map(b=>({id:b.id,kind:'Scheduled commitment',owner:'Synthetic bill schedule',observedAt:f.observedAt,value:{day:b.day,amount_cents:b.amount},summary:`${b.name}: ${money(b.amount)} on September ${b.day}.`,certainty:'Scheduled, not posted'}))];
 const p=profiles.profiles?.[f.profileId];if(p)refs.push({id:'STUDY-'+f.profileId,kind:'Synthetic cohort evidence',owner:'Inherited V4 randomized experiment',observedAt:'Frozen model artifact V4',value:{name:p.name,holdout_n:p.holdout_n,offers:p.holdout_effects},summary:p.name+': '+p.meaning,certainty:'Cohort context only. Fixture is not model-scored; no individual causal guarantee.'});
 return refs;
}
function projection(f,opts={}){
 validate(f);const pay=opts.payday??f.payday,payAmount=opts.payroll??f.payroll,transfer=opts.transfer??0;
 let bal=f.balance+transfer,min=bal,minBefore=bal;const points=[{day:8,balance:bal,label:'Snapshot'}],events=[];
 for(let day=9;day<=Math.max(21,pay);day++){
  const bills=f.bills.filter(b=>b.day===day);for(const b of bills){bal-=b.amount;events.push({day,label:b.name,delta:-b.amount,balance:bal,evidence:b.id});min=Math.min(min,bal);if(day<=pay)minBefore=Math.min(minBefore,bal);}
  if(day===pay){bal+=payAmount;events.push({day,label:'Expected pay',delta:payAmount,balance:bal,evidence:'PAY-v'+f.version});}
  min=Math.min(min,bal);points.push({day,balance:bal,label:day===pay?'Expected pay':'September '+day});
 }
 const commitments=f.bills.filter(b=>b.day<=pay).reduce((a,b)=>a+b.amount,0);
 return {points,events,min,minBefore,commitments,required:Math.max(0,f.target-minBefore),shortfall:Math.max(0,-minBefore),payday:pay,payroll:payAmount,assumption:'Scheduled debits occur before same-day expected pay; no unlisted transactions. Not a probabilistic forecast.'};
}
function compare(f,profiles={}){
 validate(f);const g=gate(f),base=projection(f),available=Math.max(0,f.savings-f.reserve),n=base.required;
 let reason=n===0?'No funding gap under the current schedule.':n>available?`Needs ${money(n)}, but only ${money(available)} is available above the protected reserve.`:!f.digital?'Transfer channel is unavailable.':f.preferSupport?'Customer prefers a support conversation.':'Meets the current funds, reserve and channel checks.';
 const transferOk=g.ok&&n>0&&n<=available&&f.digital&&!f.preferSupport;
 let kind=!g.ok?'blocked':n===0&&!f.preferSupport?'monitor':transferOk?'transfer':f.specialist?'support':'manual';
 const p=profiles.profiles?.[f.profileId];
 return {kind,gate:g,base,available,required:n,amount:kind==='transfer'?n:0,
  options:[{id:'transfer',name:'Own-account transfer',feasible:g.ok&&n>0&&n<=available&&f.digital,selected:kind==='transfer',amount:n,reason,evidence:['ACC-v'+f.version,'PREF-v'+f.version,'CAP-v'+f.version,'POL-001']},
   {id:'support',name:'Specialist support request',feasible:g.ok&&f.specialist,selected:kind==='support',amount:0,reason:f.specialist?'Prepare a request; a specialist decides any support terms. No callback time is guaranteed.':'Specialist intake unavailable. Prepare a trusted-channel handoff instead.',evidence:['CAP-v'+f.version,'PREF-v'+f.version,'POL-001']},
   {id:'monitor',name:'No new banking action',feasible:g.ok,selected:kind==='monitor'||kind==='manual',amount:0,reason:n===0?'No transfer needed in the nominal schedule; ordinary service remains available.':'Leaves the cash-flow shortfall unresolved. Ordinary service remains available.',evidence:['PAY-v'+f.version,...f.bills.map(b=>b.id)]}],
  context:p?{name:p.name,summary:p.meaning,evidence:'STUDY-'+f.profileId,individual_claim:false}:null};
}
function review(f,c){
 const gates=[{label:'One-time consent',pass:f.consent,ref:'PREF-v'+f.version},{label:'Fresh account evidence',pass:f.fresh,ref:'ACC-v'+f.version},{label:'Savings reserve respected',pass:c.kind!=='transfer'||f.savings-c.amount>=f.reserve,ref:'PREF-v'+f.version},{label:'Permitted action and channel',pass:c.kind==='transfer'?f.digital:c.kind==='support'?f.specialist:true,ref:'CAP-v'+f.version},{label:'Customer confirmation before execution',pass:true,ref:'POL-001'}];
 return {approved:gates.every(x=>x.pass),gates,challenge:c.kind==='support'?`Do not transfer ${money(c.required)}. ${!f.digital?'The transfer channel is unavailable.':f.preferSupport?'The customer requested a support conversation.':c.required>c.available?'The transfer would breach the protected reserve.':'Specialist support was chosen from the eligible alternatives; do not claim a transfer was unaffordable.'} Prepare a support request instead.`:c.kind==='transfer'?`Transfer ${money(c.amount)} passes current checks. Do not describe it as a bill payment, a default prevented, or a guaranteed outcome.`:c.kind==='blocked'?c.gate.reason:c.kind==='manual'?'No executable supported route is available. Give a trusted-channel handoff without claiming a booked appointment.':'No unnecessary transfer. Keep ordinary service and customer-requested support available.',sensitivity:projection(f,{payday:Math.min(24,f.payday+4),payroll:Math.round(f.payroll*.8),transfer:c.amount})};
}
function buildPlan(f,profiles={},runId='local',now=Date.now(),selection=null){
 const c=compare(f,profiles);
 if(selection&&selection!==c.kind){
  const allowed=c.options.filter(o=>o.feasible&&((o.id==='monitor'&&c.required===0)||o.id!=='monitor')).map(o=>o.id);
  if(!c.gate.ok||!allowed.includes(selection)||f.preferSupport&&selection==='transfer')throw Error('Selected action is not admissible');
  c.kind=selection;c.amount=selection==='transfer'?c.required:0;c.options.forEach(o=>o.selected=o.id===selection);
 }
 const r=review(f,c),after=projection(f,{transfer:c.amount});
 const refs=['ACC-v'+f.version,'PAY-v'+f.version,'PREF-v'+f.version,'POL-001','CAP-v'+f.version,...f.bills.filter(b=>b.day<=f.payday).map(b=>b.id)];
 const title={transfer:`Move ${money(c.amount)} to chequing`,support:'Prepare a specialist support request',monitor:'No transfer needed in this schedule',blocked:'Pause the assistance review',manual:'Use a trusted support channel'}[c.kind];
 const explanation=c.kind==='transfer'?`${money(c.base.commitments)} in scheduled commitments falls before expected pay. Moving ${money(c.amount)} leaves a projected ${money(after.minBefore)} buffer and ${money(f.savings-c.amount)} in savings.`:c.kind==='support'?`The current schedule needs ${money(c.required)} to retain a ${money(f.target)} chequing buffer. ${f.preferSupport?'You requested specialist support.':!f.digital?'The transfer channel is unavailable.':c.required>c.available?`Only ${money(c.available)} is available above your savings reserve.`:'Specialist support is the selected eligible alternative.'} A request can be prepared, but it does not resolve the shortfall or guarantee concessions.`:c.kind==='monitor'?`The projected minimum before pay is ${money(c.base.minBefore)}. No extra transfer is needed under the listed commitments.`:c.kind==='manual'?'No digital transfer or specialist-intake route is available. Contact support through your existing banking app. Nothing has been booked.':c.gate.reason;
 const steps=[
  {id:'check',owner:'Account evidence agent',when:'Before recommendation',task:'Verify the snapshot, expected income and commitments.',status:c.gate.ok?'complete':'blocked',refs},
  {id:'compare',owner:'Support strategist',when:'Before customer review',task:'Compare a transfer, specialist intake and no new action.',status:c.gate.ok?'complete':'blocked',refs:['POL-001','PREF-v'+f.version,'CAP-v'+f.version]},
  {id:'confirm',owner:'Customer',when:'After reviewing this plan',task:c.kind==='transfer'?`Confirm the ${money(c.amount)} own-account transfer.`:c.kind==='support'?'Confirm the scope and callback preference for a support request.':'No executable banking action is proposed.',status:['transfer','support'].includes(c.kind)?'awaiting approval':'not applicable',refs:['PREF-v'+f.version,'POL-001']},
  {id:'effect',owner:'Simulated action adapter',when:'Only after explicit confirmation',task:c.kind==='transfer'?'Recheck snapshot and reserve; post one transfer to the local simulator.':c.kind==='support'?'Create one synthetic intake request with the commitments summary.':'Do not execute.',status:['transfer','support'].includes(c.kind)?'locked':'not applicable',refs:['POL-001']},
  {id:'followup',owner:'Customer / future servicing integration',when:'Before the next commitment and after expected pay',task:'Review actual balances and payment status. Monitoring and notifications are not scheduled by this prototype.',status:'proposed only',refs:['PAY-v'+f.version]}
 ];
 return {id:`PS-${f.customerId}-v${f.version}-${runId}`,revision:f.version,runId,createdAt:new Date(now).toISOString(),expiresAt:new Date(now+15*60000).toISOString(),fingerprint:fingerprint(f),status:'proposed',kind:c.kind,title,explanation,amount:c.amount,before:{chequing:f.balance,savings:f.savings,minimum:c.base.minBefore},after:{chequing:f.balance+c.amount,savings:f.savings-c.amount,minimum:after.minBefore},reserve:f.reserve,required:c.required,available:c.available,gate:c.gate,options:c.options,review:r,steps,refs,context:c.context,base:c.base,projection:after,risks:['Expected pay may arrive later or in a different amount.','Unlisted transactions are excluded; scheduled payments are not guaranteed.','A transfer makes funds available; it does not itself pay bills.','Support intake does not guarantee an appointment, concession or avoided default.'],provenance:{mode:'computed demo tools',currency:'CAD',data:'synthetic fixtures',policy:'illustrative, not BMO policy',model:'Cohort evidence is inherited; this account fixture is not model-scored.'}};
}
function tool(name,f,profiles={},context={}){
 if(name!=='read_brief'&&!gate(f).ok)throw Error(gate(f).reason);
 const c=compare(f,profiles);
 switch(name){
 case 'read_brief':return {customer_id:f.customerId,version:f.version,fingerprint:fingerprint(f),goal:'Prepare a feasible customer-controlled response, not credit advice.',consent:f.consent,fresh:f.fresh,gate:gate(f)};
 case 'read_snapshot':return {snapshot_version:f.version,evidence:evidence(f,profiles),balance_cents:f.balance,savings_cents:f.savings,expected_payday:f.payday};
 case 'project_cashflow':return {nominal:c.base,sensitivity:projection(f,{payday:Math.min(24,f.payday+4),payroll:Math.round(f.payroll*.8)}),evidence:['ACC-v'+f.version,'PAY-v'+f.version,...f.bills.map(b=>b.id)]};
 case 'compare_options':return {recommended:c.kind,required_cents:c.required,available_cents:c.available,options:c.options,context:c.context};
 case 'review_suitability':return buildPlan(f,profiles,context.runId,Date.now(),context.selection).review;
 case 'draft_customer_brief':{const p=buildPlan(f,profiles,context.runId,Date.now(),context.selection);return {title:p.title,explanation:p.explanation,customer_decision:p.kind,amount_cents:p.amount,refs:p.refs,caveat:'No action until explicit customer confirmation.'};}
 case 'assemble_plan':return buildPlan(f,profiles,context.runId,Date.now(),context.selection);
 default:throw Error('Tool not allowlisted: '+name);
 }
}
function stepsFor(f,profiles={},runId='local'){
 const p=buildPlan(f,profiles,runId),ref=(...x)=>x;
 const stages=[{agent:'conductor',tool:'read_brief',title:'Accept the customer brief',summary:`Prepare options for ${f.customer}. Preserve the ${money(f.reserve)} savings reserve. Delegate evidence and cash-flow checks.`,refs:ref('PREF-v'+f.version)}];
 if(!p.gate.ok){stages[0].summary=p.gate.reason;return stages;}
 stages.push(
 {agent:'evidence',tool:'read_snapshot',title:'Evidence checked',summary:`Verified ${money(f.balance)} in chequing and ${money(f.savings)} in savings against snapshot v${f.version}. Expected pay is September ${f.payday}; it is not settled income.`,refs:ref('ACC-v'+f.version,'PAY-v'+f.version)},
 {agent:'cashflow',tool:'project_cashflow',title:'The timing gap is quantified',summary:`${money(p.base.commitments)} is scheduled before pay. Projected minimum: ${money(p.base.minBefore)}. ${money(p.required)} would preserve the ${money(f.target)} chequing buffer.`,refs:ref(...p.refs.filter(x=>x.startsWith('BILL')),'ACC-v'+f.version)},
 {agent:'options',tool:'compare_options',title:'Three options compared',summary:p.kind==='transfer'?`Recommend the ${money(p.amount)} own-account transfer, subject to review. ${money(p.available)} is available above the reserve. Specialist intake remains an alternative.`:p.kind==='support'?`A ${money(p.required)} transfer is ${f.preferSupport?'not the customer’s preference':!f.digital?'unavailable through this channel':'not affordable above the reserve'}. Propose specialist intake instead.`:p.kind==='monitor'?'The schedule has enough coverage. Do not recommend a transfer simply because it is available.':'No executable route is available. Prepare a trusted-channel handoff.',refs:ref('PREF-v'+f.version,'CAP-v'+f.version)},
 {agent:'critic',tool:'review_suitability',title:p.kind==='support'?'Challenge accepted · transfer rejected':'Independent suitability review',summary:p.review.challenge,refs:ref('POL-001','PREF-v'+f.version)},
 {agent:'communications',tool:'draft_customer_brief',title:'The customer gets an exact choice',summary:p.explanation,refs:p.refs.slice(0,4)},
 {agent:'conductor',tool:'assemble_plan',title:'Proposed plan ready for review',summary:`${p.title}. Evidence, alternatives, confirmation conditions and follow-up are attached. Nothing has been executed.`,refs:ref('POL-001')});
 return stages;
}
function approve(f,p,store={},now=Date.now()){
 if(store[p.id])return {receipt:clone(store[p.id]),replayed:true,fixture:clone(f)};
 const fail=s=>{throw Error(s);};
 if(!p||!['transfer','support'].includes(p.kind))fail('No executable proposal');
 if(!gate(f).ok)fail(gate(f).reason);
 if(fingerprint(f)!==p.fingerprint)fail('Evidence or preferences changed. Prepare a new plan.');
 if(Date.parse(p.expiresAt)<=now)fail('Proposal expired. Prepare a new plan.');
 const expected=buildPlan(f,{},p.runId,now,p.kind);
 if(expected.kind!==p.kind||expected.amount!==p.amount)fail('Proposal does not match validated domain calculation.');
 if(f.failExecution)fail('Simulated adapter failure. No effect was committed.');
 const next=clone(f);if(p.kind==='transfer'){next.balance+=p.amount;next.savings-=p.amount;}next.version++;
 const receipt={id:'SIM-'+p.id,proposalId:p.id,kind:p.kind,amount_cents:p.amount,status:'simulated '+(p.kind==='transfer'?'transfer posted':'intake request created'),at:new Date(now).toISOString(),before:{chequing:f.balance,savings:f.savings},after:{chequing:next.balance,savings:next.savings},effects:1,bank_action:false,avoided_defaults:0,realized_savings_cents:0};
 store[p.id]=receipt;return {receipt:clone(receipt),fixture:next,replayed:false};
}
return {clone,money,iso,ROLES,fixture,validate,canonical,fingerprint,gate,evidence,projection,compare,review,buildPlan,tool,stepsFor,approve};
});
