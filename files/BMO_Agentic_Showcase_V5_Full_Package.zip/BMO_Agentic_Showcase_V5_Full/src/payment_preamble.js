const PROFILE_PACK={
  "version": "V4.1-2026-09-08",
  "model_version": "V4-2026-09-08",
  "mapping": "Human-authored names attached to existing fixed K-means IDs using training-centroid features. Aligned GMM names reuse the mapping. No refitting or new clusters.",
  "fields": {
    "buffer_days": {
      "label": "Cash buffer",
      "unit": "days"
    },
    "income_volatility": {
      "label": "Income variability",
      "unit": "ratio"
    },
    "payday_gap_days": {
      "label": "Payday gap",
      "unit": "days"
    },
    "obligation_ratio": {
      "label": "Obligations / income",
      "unit": "percent"
    },
    "utilization": {
      "label": "Credit utilization",
      "unit": "percent"
    },
    "income_trend": {
      "label": "Income trend",
      "unit": "ratio"
    },
    "missed_payments": {
      "label": "Prior missed payments",
      "unit": "number"
    },
    "net_flow_ratio": {
      "label": "Net-flow ratio",
      "unit": "ratio"
    }
  },
  "profiles": {
    "0": {
      "code": "SB",
      "name": "Stable & Buffered",
      "short": "Stable & Buffered",
      "tag": "Protect the cushion",
      "subtitle": "Stable inflows. Room between income and commitments.",
      "signal": "A substantial cash buffer, relatively steady income and lower credit utilization.",
      "meaning": "Neither extra offer shows a clear positive effect in this synthetic holdout. More outreach is not automatically better.",
      "route": "Keep ordinary support available",
      "route_short": "Ordinary support",
      "arm": 0,
      "reason": "Avoid unsupported extra outreach while keeping requested and required support available.",
      "action": "Check for a genuine current need before preparing optional outreach. The cluster alone is not a reason to contact someone.",
      "avoid": "Do not call the customer risk-free, stop ordinary service or infer wealth from this label.",
      "customer_copy": "You can review upcoming payments and ask for support whenever you need it.",
      "scenario": null,
      "drivers": [
        "buffer_days",
        "income_volatility",
        "utilization"
      ],
      "id": 0,
      "previous_name": "Buffered cash flow",
      "training_centroid_means": {
        "buffer_days": 28.00715408038349,
        "income_volatility": 0.10251777896469405,
        "payday_gap_days": 0.7274647330927231,
        "obligation_ratio": 0.41843995417299795,
        "utilization": 0.22947586651171253,
        "income_trend": 0.01984143343104615,
        "missed_payments": 0.045322245322255705,
        "net_flow_ratio": 0.581385897347939
      },
      "historical_arms": [
        {
          "arm": 0,
          "n": 1146,
          "events": 28,
          "rate": 0.02443280977312391
        },
        {
          "arm": 1,
          "n": 1217,
          "events": 30,
          "rate": 0.024650780608052588
        },
        {
          "arm": 2,
          "n": 1283,
          "events": 23,
          "rate": 0.017926734216679657
        }
      ],
      "historical_n": 3646,
      "holdout_n": 7173,
      "holdout_effects": [
        {
          "arm": 1,
          "predicted": 0.0027414918592979856,
          "aipw": {
            "estimate": -0.004828555992852757,
            "low": -0.01300910443284891,
            "high": 0.0033519924471433968,
            "n": 7173,
            "method": "normal 95% interval, conditional on fitted models and displayed cohort"
          }
        },
        {
          "arm": 2,
          "predicted": 0.0004137856767473373,
          "aipw": {
            "estimate": -0.002070012048961838,
            "low": -0.010019215883098084,
            "high": 0.005879191785174409,
            "n": 7173,
            "method": "normal 95% interval, conditional on fitted models and displayed cohort"
          }
        }
      ],
      "mean_predicted_usual_support_risk": 0.022829570085555372,
      "displayed_kmeans_n": 500,
      "displayed_gmm_n": 501
    },
    "1": {
      "code": "VI",
      "name": "Variable-Income Squeeze",
      "short": "Income Squeeze",
      "tag": "Plan around the swings",
      "subtitle": "Income changes more than the commitments do.",
      "signal": "Higher income variability combines with a thin cash buffer and sizeable obligations.",
      "meaning": "Specialist review has the larger effect estimate in this synthetic cohort. A direct specialist-versus-digital superiority test is not available.",
      "route": "Evaluate specialist review",
      "route_short": "Specialist review",
      "arm": 2,
      "reason": "Review the income pattern and feasible support rather than assume a generic reminder solves the problem.",
      "action": "Check current income, obligations, consent and specialist capacity; prepare an eligible invitation with evidence attached.",
      "avoid": "Do not infer occupation, employment status, age or unwillingness to pay from volatile income.",
      "customer_copy": "Would you like to review upcoming commitments around changes in your income?",
      "scenario": "income",
      "drivers": [
        "income_volatility",
        "buffer_days",
        "obligation_ratio"
      ],
      "id": 1,
      "previous_name": "Variable income",
      "training_centroid_means": {
        "buffer_days": 5.036366621644789,
        "income_volatility": 0.4883691198898115,
        "payday_gap_days": 2.6951898145838293,
        "obligation_ratio": 0.7496080775879315,
        "utilization": 0.6402250435524214,
        "income_trend": -0.06888252764665126,
        "missed_payments": 0.39474828275802,
        "net_flow_ratio": 0.2505041787293363
      },
      "historical_arms": [
        {
          "arm": 0,
          "n": 1006,
          "events": 250,
          "rate": 0.2485089463220676
        },
        {
          "arm": 1,
          "n": 954,
          "events": 177,
          "rate": 0.18553459119496854
        },
        {
          "arm": 2,
          "n": 935,
          "events": 112,
          "rate": 0.11978609625668449
        }
      ],
      "historical_n": 2895,
      "holdout_n": 5701,
      "holdout_effects": [
        {
          "arm": 1,
          "predicted": 0.0633083212159502,
          "aipw": {
            "estimate": 0.05342744938847997,
            "low": 0.027455690611106837,
            "high": 0.07939920816585311,
            "n": 5701,
            "method": "normal 95% interval, conditional on fitted models and displayed cohort"
          }
        },
        {
          "arm": 2,
          "predicted": 0.12170552009338369,
          "aipw": {
            "estimate": 0.13451687065325685,
            "low": 0.1105904291747854,
            "high": 0.1584433121317283,
            "n": 5701,
            "method": "normal 95% interval, conditional on fitted models and displayed cohort"
          }
        }
      ],
      "mean_predicted_usual_support_risk": 0.24763087939276152,
      "displayed_kmeans_n": 358,
      "displayed_gmm_n": 365
    },
    "2": {
      "code": "PG",
      "name": "Payday Timing Gap",
      "short": "Payday Timing Gap",
      "tag": "Review the timing",
      "subtitle": "Bills and payday are out of step.",
      "signal": "A pronounced payday gap appears alongside relatively steady income and a limited cash buffer.",
      "meaning": "Cash-flow assistance has a positive effect in the synthetic holdout. Specialist review has an uncertain effect versus usual support for this cohort.",
      "route": "Evaluate cash-flow assistance",
      "route_short": "Cash-flow assistance",
      "arm": 1,
      "reason": "Investigate a feasible timing response before assuming a permanent income shortfall.",
      "action": "Recheck the payment schedule, consent and chosen savings reserve. Prepare an affordable own-account option or an eligible support request.",
      "avoid": "Do not change a biller’s due date, create credit or treat an internal transfer as proof of a prevented default.",
      "customer_copy": "Some payments may arrive before your next deposit. Let’s review the options you control.",
      "scenario": "timing",
      "drivers": [
        "payday_gap_days",
        "buffer_days",
        "income_volatility"
      ],
      "id": 2,
      "previous_name": "Payday mismatch",
      "training_centroid_means": {
        "buffer_days": 7.990337441485316,
        "income_volatility": 0.13087442186915788,
        "payday_gap_days": 5.57589892760047,
        "obligation_ratio": 0.6306762556978542,
        "utilization": 0.4691606777733806,
        "income_trend": 0.0007016965624866353,
        "missed_payments": 0.2363003554502438,
        "net_flow_ratio": 0.3688752402889935
      },
      "historical_arms": [
        {
          "arm": 0,
          "n": 1071,
          "events": 139,
          "rate": 0.12978524743230627
        },
        {
          "arm": 1,
          "n": 1096,
          "events": 62,
          "rate": 0.05656934306569343
        },
        {
          "arm": 2,
          "n": 1096,
          "events": 130,
          "rate": 0.11861313868613138
        }
      ],
      "historical_n": 3263,
      "holdout_n": 6810,
      "holdout_effects": [
        {
          "arm": 1,
          "predicted": 0.07633786115112075,
          "aipw": {
            "estimate": 0.07877259327618692,
            "low": 0.06166904799500726,
            "high": 0.09587613855736658,
            "n": 6810,
            "method": "normal 95% interval, conditional on fitted models and displayed cohort"
          }
        },
        {
          "arm": 2,
          "predicted": 0.015379154261009855,
          "aipw": {
            "estimate": 0.017598273999779375,
            "low": -0.0016816701552446918,
            "high": 0.03687821815480344,
            "n": 6810,
            "method": "normal 95% interval, conditional on fitted models and displayed cohort"
          }
        }
      ],
      "mean_predicted_usual_support_risk": 0.14209758887589455,
      "displayed_kmeans_n": 467,
      "displayed_gmm_n": 466
    },
    "3": {
      "code": "PP",
      "name": "Sustained Payment Pressure",
      "short": "Payment Pressure",
      "tag": "Review the whole picture",
      "subtitle": "Commitments leave very little financial room.",
      "signal": "Obligations absorb nearly all income, credit utilization is high and the cash buffer is very small.",
      "meaning": "Specialist review shows a positive effect estimate in the synthetic holdout. A simple cash-flow offer has an uncertain effect for this cohort.",
      "route": "Prepare an assisted review",
      "route_short": "Assisted review",
      "arm": 2,
      "reason": "A quick transfer may not address the broader problem. Preserve access to appropriate and required support.",
      "action": "Collect current evidence and prepare an eligible specialist handoff. Flag uncertainty rather than promise debt relief or a payment holiday.",
      "avoid": "Do not label the customer a defaulter, automatically change credit terms or deny required help because expected value is low.",
      "customer_copy": "Let’s review support options that fit your current commitments.",
      "scenario": "limited",
      "drivers": [
        "obligation_ratio",
        "utilization",
        "buffer_days"
      ],
      "id": 3,
      "previous_name": "Sustained pressure",
      "training_centroid_means": {
        "buffer_days": 2.1577081435111793,
        "income_volatility": 0.2512948178064772,
        "payday_gap_days": 1.2715996553863258,
        "obligation_ratio": 0.9690764178603869,
        "utilization": 0.8901895859659044,
        "income_trend": -0.1986679568574075,
        "missed_payments": 1.066549912434344,
        "net_flow_ratio": 0.03005753269815542
      },
      "historical_arms": [
        {
          "arm": 0,
          "n": 771,
          "events": 376,
          "rate": 0.4876783398184176
        },
        {
          "arm": 1,
          "n": 682,
          "events": 293,
          "rate": 0.42961876832844575
        },
        {
          "arm": 2,
          "n": 743,
          "events": 324,
          "rate": 0.4360699865410498
        }
      ],
      "historical_n": 2196,
      "holdout_n": 4316,
      "holdout_effects": [
        {
          "arm": 1,
          "predicted": 0.0188833643816408,
          "aipw": {
            "estimate": 0.018001947062190053,
            "low": -0.01768176052975001,
            "high": 0.05368565465413011,
            "n": 4316,
            "method": "normal 95% interval, conditional on fitted models and displayed cohort"
          }
        },
        {
          "arm": 2,
          "predicted": 0.05167254791270917,
          "aipw": {
            "estimate": 0.06931352744295513,
            "low": 0.03358721673206355,
            "high": 0.10503983815384671,
            "n": 4316,
            "method": "normal 95% interval, conditional on fitted models and displayed cohort"
          }
        }
      ],
      "mean_predicted_usual_support_risk": 0.47909821808376135,
      "displayed_kmeans_n": 275,
      "displayed_gmm_n": 268
    }
  },
  "review_fit": {
    "threshold": 0.8,
    "label": "Illustrative display flag, not a fifth cluster or an action criterion",
    "low_membership_count": 3,
    "algorithm_disagreement_count": 12,
    "unique_flag_count": 14
  },
  "caveats": [
    "All numerical inputs, predictions and assignments are preserved from V4.",
    "Candidate routes are editorial guidance consistent with 2024 history. The 2025 test is evaluation, not training or allocator retuning.",
    "Treatment effects are versus usual support, not head-to-head comparisons between interventions.",
    "The plot sample, training-centroid means, historical outcomes and 24,000-record test are distinct populations.",
    "Synthetic evidence is not bank validation, an individual guarantee or achieved savings.",
    "Labels are internal. Customer copy describes a support opportunity, not a risk classification.",
    "The 0.80 fit-review threshold is a demonstration choice, not a calibrated confidence cutoff. It never changes campaign eligibility."
  ]
};
const LOGO="<svg class=\"logo\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 286 100\" role=\"img\" aria-label=\"BMO\"><title>BMO showcase wordmark recreation<\/title><text x=\"0\" y=\"74\" fill=\"#0075BE\" font-family=\"Georgia,Times New Roman,serif\" font-weight=\"bold\" font-size=\"78\" letter-spacing=\"-5\">BMO<\/text><circle cx=\"236\" cy=\"50\" r=\"50\" fill=\"#ED1C24\"/><path fill=\"white\" d=\"M212.5 36.3L222.8 23.4Q224.5 21 226.3 23.4L234.1 33.5Q236 35.8 237.9 33.5L245.7 23.4Q247.5 21 249.2 23.4L259.5 36.3V56.5L249.2 43.5Q247.5 41.2 245.7 43.5L237.9 53.6Q236 56 234.1 53.6L226.3 43.5Q224.5 41.2 222.8 43.5L212.5 56.5Z\"/><rect x=\"212.5\" y=\"56.5\" width=\"47\" height=\"15\" fill=\"white\"/><\/svg>";
/* Pure, shared payment domain. All amounts are integer Canadian cents.
   These tools—not an LLM—own balances, permissions and feasibility. */
