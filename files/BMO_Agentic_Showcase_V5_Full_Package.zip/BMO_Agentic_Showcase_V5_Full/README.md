# BMO Agentic Showcase V5 — full focused package

## Start presenting

Extract the entire ZIP, then open **START_HERE.html**. Select **PaymentShield** for the phone journey and six-role developer studio, or **CreditCompass** for named financial profiles and inherited synthetic intervention evidence. No installation or credentials are required for the offline HTML demos.

PaymentShield: review the payment gap, grant one-time consent, inspect the CAD 600 proposal, then protect CAD 1,500 in savings to trigger a support-request plan. Open Agent studio and Proposed plan for the specialist handoffs, tool data, alternatives and approval conditions. Explicit confirmation creates one simulated receipt.

## What is included

- `PaymentShield_V5.html`, `CreditCompass_V5.html`: current self-contained demonstrations.
- `PaymentShield_Walkthrough.mp4`: supplied short rehearsal video.
- `src/`: current editable HTML/JavaScript and a standard-library rebuild script.
- `server/`: role-scoped Bedrock Converse runtime, shared numerical bridge and synthetic lab API.
- `tests/`: current domain, mocked Bedrock, HTTP-contract and browser checks.
- `artifacts/`: source profiles, 1,600-row display dataset, inherited model evaluation, full plan evidence, screenshots and current test reports.
- `docs/`: presenter guide, architecture, lab runbook, bank comparison, profile guide and release boundaries.
- `supporting_materials/`: earlier editable competitive pitch, PDF, financial model, research brief and source records. These retain the earlier broader scope, including references to DecisionOps; they are not newly revised V5 slides.
- `reference/`: the complete earlier V4.1 browser-source package and the three user-supplied context videos. These are provenance, not the current entry point.
- `Dockerfile`, `buildspec.yml`, `deploy/`: lab build and deployment templates.

## Execution modes

**Offline rehearsal:** computed synthetic tools with animated role messages. No LLM call, deployed agent or real account action.

**Configured server:** separate role-scoped Bedrock Converse sessions for PaymentShield. The server performs real inference only when an approved model, AWS credentials/role and lab access are configured. The browser connects to the same origin; AWS credentials remain server-side. Bedrock failures do not become offline successes.

**CreditCompass** remains the inherited fitted-artifact showcase with deterministic agent rehearsals. Do not present its messages as live Bedrock. Its study participants, display cases and PaymentShield account fixtures are distinct.

## Run the local server

Prerequisites: Python 3.12+ and a supported Node.js installation. Local verification used Python 3.13.5 and Node.js 22.16.0; the Dockerfile targets Python 3.12. No Docker build was run here.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m uvicorn server.app:app --host 127.0.0.1 --port 8080 --workers 1
```

On Windows, activate with `.venv\Scripts\Activate.ps1`. Open `http://127.0.0.1:8080/`. The normal HTML continues to work in offline rehearsal mode when served locally.

To enable the live connection, export a randomly generated `LAB_ACCESS_TOKEN` of at least 20 characters, `AWS_REGION`, and an approved `BEDROCK_MODEL_ID` **before starting the server**. Use the normal AWS credential provider chain or an approved task role. Do not put AWS keys into the browser, this archive or the container image. `.env.example` is a reference and is not automatically loaded. Optional approved guardrail identifiers are documented there.

The token only creates a synthetic lab session. It is not enterprise SSO or a production authorization mechanism. An actual live inference call and AWS deployment remain unverified. See `docs/LAB_RUNBOOK.html` and `deploy/README.md`.

## Rebuild and test

```bash
python src/build.py
python -m pip install -r requirements-dev.txt
python -m pytest -q tests/test_package.py
# Install an approved browser for Playwright, or set CHROMIUM_PATH to an existing Chromium.
python -m playwright install chromium
python tests/browser_smoke.py
```

Building reconstructs the same self-contained browser applications from packaged source. It does not train a model. Current verification is in `artifacts/verification/`; older V4.1 test reports are preserved under `reference/` with labelled inherited copies linked from the profile guide.

## Evidence and financial boundaries

All customer data, account policies, default outcomes and banking effects are synthetic. Cluster and intervention outputs are inherited fitted artifacts; this delivery does **not** include the original full 96,000-record randomized-study generator, raw trial data, original training pipeline or newly fitted model weights. It does include the display rows, profile evidence and evaluation outputs used by these demos. Their statistical results were not rerun for packaging.

The CAD 638,333 annual-net-benefit scenario is an editable hypothesis, not an achieved result or this customer's value. Realized savings and prevented defaults in simulated receipts are zero. The financial workbook retains the separately stated 20-basis-point planning assumption, not the synthetic study's estimated effect. No benefit is double-counted between products.

The BMO-styled logo is a showcase recreation. Replace it with an approved master asset before a formal bank release. Public competitor descriptions do not establish what exists in their private systems.

## Release reconstruction

The latest retained V5 HTML, video, agent runtime and architecture documents were preserved. Missing shared-domain and API support modules were reconstructed from the delivered browser's exported calculation engine and documented endpoint contract; they are newly tested here, not represented as recovered originals. The live-runtime agent file itself was preserved unchanged.

Current checks: 34 domain/API/mocked-agent tests and 34 browser assertions. Real Bedrock, Docker, AWS deployment and production banking integration are not verified. Files and integrity checks are listed in `PACKAGE_MANIFEST.json` and `MANIFEST.sha256`.

The reference videos were supplied by the user and may show internal lab details. Review them before sharing this package beyond the approved audience.
