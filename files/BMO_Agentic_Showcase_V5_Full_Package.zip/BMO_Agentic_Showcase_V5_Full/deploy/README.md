# Lab build and deployment inputs

This folder is an integration template, not a provisioned AWS stack. No Docker build, image push or AWS task launch was executed for this release.

1. Obtain an approved Docker-enabled CodeBuild project, ECR repository, task/execution roles, Bedrock model or inference profile and scoped permissions.
2. Build the **repository root** with `buildspec.yml`. Configure `ECR_REPOSITORY` and `AWS_REGION` in the approved build environment.
3. Replace every `REPLACE_WITH_...` value in `task-definition.template.json`. Use approved secret injection for the lab access token; never paste AWS credentials into the page.
4. Run **one task / one worker**. Connect port 8080 to the dedicated approved internal target group. Do not overwrite an existing service. Review the earlier lab routing with its owner rather than creating a public endpoint.
5. Use `ROOT_PATH` only when your proxy strips that prefix. Set the exact public HTTPS origin, without a path, in `LAB_PUBLIC_ORIGIN`. Test same-origin API routing and streaming behavior in the actual lab.
6. Protect the whole lab origin with approved network/access controls. The portable demo pages are not bank SSO. The API requires a lab token to create a session, then session and request tokens.
7. Verify health, an actual Bedrock response, request ID/usage, tools, alternate plans, approval, retry, cancellation and task restart. Disabling buffering and checking gateway timeouts may be required for NDJSON streaming.

In-memory state disappears on restart and is not shared across replicas. No real transactions, customer notifications, appointment bookings or continuous monitoring are implemented. Task IAM must be restricted to explicitly approved model/inference-profile resources; this package deliberately provides no wildcard IAM grant.
