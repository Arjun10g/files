from __future__ import annotations
import copy
import json
import os
from pathlib import Path
import threading
from concurrent.futures import ThreadPoolExecutor
import pytest
from fastapi.testclient import TestClient
from server.domain import domain
from server.agents import AgentRuntime
import server.app as api

ROOT = Path(__file__).resolve().parents[1]

@pytest.fixture
def f():
    x = domain('fixture'); x['consent'] = True; return x

@pytest.mark.parametrize('scenario,kind', [('timing','transfer'),('limited','support'),('income','support'),('buffered','monitor')])
def test_scenarios(scenario,kind):
    f=domain('fixture', scenario=scenario); f['consent']=True
    assert domain('plan',fixture=f)['kind']==kind

@pytest.mark.parametrize('patch,kind', [({'reserve':150000},'support'),({'digital':False},'support'),({'digital':False,'specialist':False},'manual'),({'fresh':False},'blocked'),({'consent':False},'blocked'),({'preferSupport':True},'support')])
def test_constraints(f,patch,kind):
    f.update(patch); assert domain('plan',fixture=f)['kind']==kind

def test_exact_money(f):
    p=domain('plan',fixture=f)
    assert (p['amount'],p['required'],p['available'])==(60000,60000,85000)
    assert p['after']=={'chequing':122000,'savings':125000,'minimum':10000}
    f['payday']=19
    assert domain('plan',fixture=f)['amount']==76000

def test_agent_may_choose_other_eligible_action(f):
    assert domain('plan',fixture=f,selection='support')['kind']=='support'
    f['preferSupport']=True
    with pytest.raises(ValueError): domain('plan',fixture=f,selection='transfer')

def test_approval_replay(f):
    p=domain('plan',fixture=f,runId='TEST')
    a=domain('approve',fixture=f,plan=p)
    b=domain('approve',fixture=a['fixture'],plan=p,store=a['store'])
    assert not a['replayed'] and b['replayed']
    assert a['receipt']==b['receipt']
    assert a['fixture']['savings']==125000
    assert a['receipt']['realized_savings_cents']==0
    assert not a['receipt']['bank_action']

@pytest.mark.parametrize('change', ['expired','tampered','stale','failure','preference'])
def test_reject_invalid_approval(f,change):
    p=domain('plan',fixture=f)
    if change=='expired': p['expiresAt']='2020-01-01T00:00:00Z'
    if change=='tampered': p['amount']+=100
    if change=='stale': f['fresh']=False
    if change=='failure': f['failExecution']=True
    if change=='preference': f['reserve']=150000
    with pytest.raises(ValueError): domain('approve',fixture=f,plan=p)

def test_tool_allowlist(f):
    with pytest.raises(ValueError): domain('tool',fixture=f,name='execute_transfer')
    assert len(domain('roles'))==6

def test_inherited_data():
    p=json.loads((ROOT/'artifacts/cluster_profiles.json').read_text())
    assert len(p['profiles'])==4
    d=json.loads((ROOT/'artifacts/showcase_data.json').read_text())
    assert len(d['rows'])==1600

class MockConverse:
    """Contract fixture, never represented as real Bedrock inference."""
    def __init__(self, support=False): self.support=support; self.calls=[]; self.lock=threading.Lock()
    def converse(self, **kw):
        with self.lock: self.calls.append(kw)
        brief=json.loads(kw['messages'][0]['content'][0]['text'])
        required=brief['required_tools']; tool=required[0]
        already=any('toolResult' in c for m in kw['messages'][1:] for c in m.get('content',[]))
        selected=brief.get('selected_candidate') or ('support' if self.support else 'transfer')
        if already:
            call={'toolUseId':'MOCK-result','name':'submit_role_result','input':{'summary':'Synthetic contract-test decision; no live inference.','refs':['POL-001'],'candidate_kind':selected}}
        else:
            call={'toolUseId':'MOCK-tool','name':tool,'input':{'kind':selected} if tool=='assemble_plan' else {}}
        return {'output':{'message':{'role':'assistant','content':[{'toolUse':call}]}},
                'usage':{'inputTokens':10,'outputTokens':5},'stopReason':'tool_use',
                'ResponseMetadata':{'RequestId':'MOCK-NOT-LIVE'}}

@pytest.mark.parametrize('support',[False,True])
def test_bedrock_contract(f,support):
    events=[]; client=MockConverse(support)
    p=AgentRuntime(f,events.append,client=client,model_id='MOCK-ONLY').run('Prepare eligible support')
    assert p['kind']==('support' if support else 'transfer')
    assert len(client.calls)==14
    assert len({e['agent'] for e in events if e['type']=='agent_start'})==6
    assert not any('reasoningContent' in e for e in events)
    assert all(e['request_id']=='MOCK-NOT-LIVE' for e in events if e['type']=='llm_response')

def test_inference_error_no_fallback(f):
    class Broken:
        def converse(self,**kw): raise RuntimeError('mock failure')
    with pytest.raises(RuntimeError): AgentRuntime(f,lambda e:None,client=Broken(),model_id='MOCK').run('review')

class FakeRuntime:
    def __init__(self,fixture,emit,run_id): self.f=fixture;self.emit=emit;self.run_id=run_id
    def run(self,reason):
        for role in ['conductor','evidence','cashflow','options','critic','communications']:
            self.emit({'type':'agent_start','agent':role,'contract_test':True})
            self.emit({'type':'agent_end','agent':role,'contract_test':True})
        return domain('plan',fixture=self.f,runId=self.run_id)

@pytest.fixture
def client(monkeypatch):
    monkeypatch.setenv('LAB_ACCESS_TOKEN','test-only-token-at-least-20-chars')
    monkeypatch.setenv('BEDROCK_MODEL_ID','MOCK-ONLY')
    monkeypatch.setattr(api,'AgentRuntime',FakeRuntime)
    api.SESSIONS.clear()
    with TestClient(api.app) as c: yield c
    api.SESSIONS.clear()

def connect(c):
    r=c.post('/api/session',headers={'Authorization':'Bearer test-only-token-at-least-20-chars'},json={'scenario':'timing'})
    assert r.status_code==200,r.text
    d=r.json();return {'X-Session-ID':d['session_id'],'X-CSRF-Token':d['csrf']}

def run(c,h,patch=None):
    f=domain('fixture');f['consent']=True
    if patch:f.update(patch)
    r=c.post('/api/run',headers=h,json={'fixture':f,'reason':'Test plan'})
    assert r.status_code==200,r.text
    events=[json.loads(line) for line in r.text.splitlines() if line.strip()]
    assert not any(e['type']=='error' for e in events),events
    return events[-1]['plan']

def test_http_static(client):
    for p in ['/','/PaymentShield_V5.html','/CreditCompass_V5.html','/api/health']:
        assert client.get(p).status_code==200
    for p in ['/server/agents.py','/.env','/api/unknown','/src/payment_domain.js']:
        assert client.get(p).status_code==404

def test_http_auth(client):
    assert client.post('/api/session',json={}).status_code==401
    assert client.post('/api/approve',json={}).status_code==401
    h=connect(client);h['X-CSRF-Token']='wrong'
    assert client.post('/api/reset',headers=h,json={'scenario':'timing'}).status_code==403

def test_cross_origin(client):
    assert client.post('/api/session',headers={'Origin':'https://untrusted.example','Authorization':'Bearer test-only-token-at-least-20-chars'},json={}).status_code==403

def test_http_approval_and_replay(client):
    h=connect(client);p=run(client,h)
    results=[]
    def approve():return client.post('/api/approve',headers=h,json={'proposal_id':p['id']}).json()
    with ThreadPoolExecutor(2) as pool: results=list(pool.map(lambda _:approve(),range(2)))
    assert sorted(r['replayed'] for r in results)==[False,True]
    assert results[0]['receipt']['id']==results[1]['receipt']['id']
    assert all(r['fixture']['savings']==125000 for r in results)

def test_http_foreign_proposal(client):
    a,b=connect(client),connect(client);p=run(client,a)
    assert client.post('/api/approve',headers=b,json={'proposal_id':p['id']}).status_code==409

def test_http_support_revision(client):
    h=connect(client);old=run(client,h)
    new=run(client,h,{'reserve':150000,'version':2})
    assert new['kind']=='support'
    assert client.post('/api/approve',headers=h,json={'proposal_id':old['id']}).status_code==409
    r=client.post('/api/approve',headers=h,json={'proposal_id':new['id'],'callback_preference':'Afternoon'}).json()
    assert r['receipt']['callback_preference']=='Afternoon'
    assert r['fixture']['savings']==185000

def test_http_failed_effect_invalidates(client):
    h=connect(client);p=run(client,h)
    r=client.post('/api/approve',headers=h,json={'proposal_id':p['id'],'fail_execution':True})
    assert r.status_code==409
    assert client.post('/api/approve',headers=h,json={'proposal_id':p['id']}).status_code==409

def test_http_locked_fixture(client):
    h=connect(client);f=domain('fixture');f.update(balance=1,consent=True)
    assert client.post('/api/run',headers=h,json={'fixture':f,'reason':'review'}).status_code==400

def test_http_stale_gate(client):
    h=connect(client);p=run(client,h,{'fresh':False,'version':2})
    assert p['kind']=='blocked'
    assert client.post('/api/approve',headers=h,json={'proposal_id':p['id']}).status_code==409

def test_session_expiry(client):
    h=connect(client);api.SESSIONS[h['X-Session-ID']].created-=api.TTL+1
    assert client.post('/api/reset',headers=h,json={'scenario':'timing'}).status_code==401

def test_model_not_configured(client,monkeypatch):
    h=connect(client);monkeypatch.delenv('BEDROCK_MODEL_ID')
    assert client.post('/api/run',headers=h,json={'fixture':domain('fixture')}).status_code==503
