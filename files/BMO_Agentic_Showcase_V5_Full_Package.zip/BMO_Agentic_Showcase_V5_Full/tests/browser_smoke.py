"""Render and exercise the exact delivered HTML. No AWS calls."""
from pathlib import Path
import json
import os
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]
OUT=R/'artifacts/verification';OUT.mkdir(exist_ok=True)
shots=OUT/'screenshots';shots.mkdir(exist_ok=True)
checks=[];errors=[]
def check(name,value):
    checks.append({'name':name,'passed':bool(value)})
    assert value,name
with sync_playwright() as p:
    opts={'headless':True,'args':['--no-sandbox']}
    executable=os.environ.get('CHROMIUM_PATH')
    if not executable and Path('/usr/bin/chromium').exists():executable='/usr/bin/chromium'
    if executable:opts['executable_path']=executable
    browser=p.chromium.launch(**opts)
    page=browser.new_page(viewport={'width':1440,'height':1100},reduced_motion='reduce')
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content((R/'PaymentShield_V5.html').read_text(),wait_until='load')
    check('PaymentShield loads',page.locator('h1').inner_text()=='A payment gap. A practical plan.')
    check('Desktop no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
    page.get_by_role('button',name='Review my options',exact=False).click()
    page.get_by_role('button',name='Allow one-time review',exact=False).click()
    page.wait_for_function('PAYMENT5.state.plan && !PAYMENT5.state.busy')
    check('Initial transfer 600 CAD',page.evaluate('PAYMENT5.state.plan.amount')==60000)
    check('Six specialist roles',page.evaluate('Object.keys(PAYMENT5.state.states).length')==6)
    check('Evidence-linked source references',page.evaluate('PAYMENT5.state.plan.refs.length')>=8)
    check('Seven domain tool results',page.evaluate("PAYMENT5.state.events.filter(e=>e.type==='tool_result').length")==7)
    check('No invented LLM calls',page.evaluate("PAYMENT5.state.events.filter(e=>e.type==='llm_response').length")==0)
    page.evaluate("PAYMENT5.go('studio')")
    page.screenshot(path=str(shots/'01_payment_agent_studio.png'),full_page=True)
    check('Studio visible','Specialist' in page.locator('main').inner_text() or 'agent' in page.locator('main').inner_text().lower())
    page.evaluate("PAYMENT5.go('plan')")
    page.screenshot(path=str(shots/'02_full_plan.png'),full_page=True)
    check('Full plan shows alternatives','The alternatives were not hidden' in page.locator('main').inner_text())
    page.evaluate("PAYMENT5.patchPreference('reserve')")
    check('Reserve changes action',page.evaluate('PAYMENT5.state.plan.kind')=='support')
    check('Revision history retained',page.evaluate('PAYMENT5.state.history.length')>=1)
    check('Available above reserve 350 CAD',page.evaluate('PAYMENT5.state.plan.available')==35000)
    page.evaluate("PAYMENT5.go('journey');PAYMENT5.confirmAction()")
    check('One simulated receipt',page.evaluate('PAYMENT5.state.receipt.effects')==1)
    check('No realized savings',page.evaluate('PAYMENT5.state.receipt.realized_savings_cents')==0)
    before=page.evaluate('PAYMENT5.state.receipt.id');page.evaluate('PAYMENT5.confirmAction()')
    check('Repeat returns identical receipt',page.evaluate('PAYMENT5.state.receipt.id')==before)
    check('Only one action count',page.evaluate('PAYMENT5.state.executionCount')==1)
    page.set_viewport_size({'width':390,'height':844})
    page.evaluate("document.querySelector('.toast')?.remove()");page.wait_for_timeout(250)
    page.screenshot(path=str(shots/'03_mobile_receipt.png'),full_page=True)
    check('Mobile no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
    for scenario,kind in [('limited','support'),('income','support'),('buffered','monitor')]:
        page.evaluate('(id)=>PAYMENT5.changeScenario(id)',scenario);page.evaluate('PAYMENT5.grantConsent()')
        check(f'{scenario} correct action',page.evaluate('PAYMENT5.state.plan.kind')==kind)
    page.evaluate("PAYMENT5.changeScenario('timing');PAYMENT5.grantConsent()")
    page.evaluate("PAYMENT5.patchPreference('stale')")
    check('Stale blocks actionable proposal',page.evaluate('PAYMENT5.state.plan.kind')=='blocked')
    page.evaluate("PAYMENT5.changeScenario('timing');PAYMENT5.grantConsent()")
    page.evaluate('PAYMENT5.state.f.failExecution=true;PAYMENT5.confirmAction()')
    check('Failed action commits nothing',page.evaluate('PAYMENT5.state.executionCount')==0)
    check('Failure requires replan',page.evaluate('PAYMENT5.state.plan===null'))
    page.evaluate("PAYMENT5.go('value');PAYMENT5.state.economy.bps=0;PAYMENT5.state.economy.capacity=false;PAYMENT5.render()")
    check('Zero benefit shows operating downside','400,000' in page.locator('.value-hero').inner_text())
    page.close()
    page=browser.new_page(viewport={'width':1440,'height':1080},reduced_motion='reduce')
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content((R/'CreditCompass_V5.html').read_text(),wait_until='load')
    check('CreditCompass preloaded portfolio',page.evaluate('DATA.rows.length')==1600)
    check('Four named profile cards',page.locator('.profile-mini').count()==4)
    for k in range(4):
        page.evaluate('(k)=>selectCluster(k)',k)
        check(f'Named cluster {k}',bool(page.locator('.profile-panel h2').inner_text()))
    page.evaluate('selectCluster(2)');page.screenshot(path=str(shots/'04_creditcompass_named_profiles.png'),full_page=True)
    page.evaluate("setAlgorithm('gmm')")
    check('GMM switch',page.evaluate('C.algorithm')=='gmm')
    page.evaluate('openProfile(2)')
    check('Profile evidence opens','Payday Timing Gap' in page.locator('.modal').inner_text())
    page.evaluate('closeModal()');page.set_viewport_size({'width':390,'height':844})
    check('CreditCompass mobile no overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
    check('No browser script exceptions',not errors)
    browser.close()
report={'test_type':'exact HTML rendered with Playwright set_content; no live Bedrock', 'checks':checks,'errors':errors,'passed':sum(x['passed'] for x in checks)}
(OUT/'browser_checks.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'passed':report['passed'],'errors':errors}))
