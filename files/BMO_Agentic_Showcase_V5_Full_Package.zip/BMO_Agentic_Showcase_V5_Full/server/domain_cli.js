'use strict';
// A fresh Node process evaluates each synthetic tool call. No network or shell access.
const fs = require('fs');
const path = require('path');
const E = require('../src/payment_domain.js');
const profiles = JSON.parse(fs.readFileSync(path.join(__dirname, '../artifacts/cluster_profiles.json'), 'utf8'));
let input = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => { input += chunk; if (input.length > 524288) { process.stderr.write('Input too large'); process.exit(1); } });
process.stdin.on('end', () => {
  try {
    const q = JSON.parse(input); let result; const f = q.fixture;
    if (q.op !== 'fixture' && q.op !== 'roles') E.validate(f);
    switch (q.op) {
      case 'fixture': result = E.fixture(q.scenario || 'timing'); break;
      case 'roles': result = E.ROLES; break;
      case 'validate': result = E.validate(f); break;
      case 'fingerprint': result = E.fingerprint(f); break;
      case 'gate': result = E.gate(f); break;
      case 'evidence': result = E.evidence(f, profiles); break;
      case 'projection': result = E.projection(f, q.options || {}); break;
      case 'compare': result = E.compare(f, profiles); break;
      case 'plan': result = E.buildPlan(f, profiles, q.runId || 'local', q.now ?? Date.now(), q.selection || null); break;
      case 'tool': result = E.tool(q.name, f, profiles, q.context || {}); break;
      case 'steps': result = E.stepsFor(f, profiles, q.runId || 'local'); break;
      case 'approve': {
        const store = q.store || {};
        result = E.approve(f, q.plan, store, q.now ?? Date.now());
        result.store = store; break;
      }
      default: throw Error('Operation is not allowlisted');
    }
    process.stdout.write(JSON.stringify({ok: true, result}));
  } catch (e) { process.stdout.write(JSON.stringify({ok: false, error: String(e.message || e)})); process.exitCode = 1; }
});
