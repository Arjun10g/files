"""Synthetic PaymentShield lab backend. Not a production banking service."""
