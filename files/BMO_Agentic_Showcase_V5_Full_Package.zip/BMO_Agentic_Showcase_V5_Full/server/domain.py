"""Use exactly the same integer-cent calculation engine as the browser demo."""
from __future__ import annotations
import json
import os
from pathlib import Path
import shutil
import subprocess
from typing import Any

ROOT = Path(__file__).resolve().parents[1]

def domain(operation: str, **kwargs: Any) -> Any:
    node = os.environ.get('NODE_BINARY') or shutil.which('node')
    if not node:
        raise RuntimeError('Node.js is required for the shared payment domain. Install Node.js or set NODE_BINARY.')
    try:
        payload = json.dumps({'op': operation, **kwargs}, allow_nan=False)
        proc = subprocess.run([node, str(ROOT / 'server/domain_cli.js')], input=payload,
                              text=True, capture_output=True, timeout=10, cwd=ROOT, check=False)
        reply = json.loads(proc.stdout)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError('Synthetic calculation timed out') from exc
    except (ValueError, TypeError) as exc:
        raise ValueError('Invalid calculation input or output') from exc
    if not reply.get('ok'):
        raise ValueError(reply.get('error', 'Domain calculation rejected'))
    if proc.returncode:
        raise RuntimeError('Synthetic calculation process failed')
    return reply['result']
