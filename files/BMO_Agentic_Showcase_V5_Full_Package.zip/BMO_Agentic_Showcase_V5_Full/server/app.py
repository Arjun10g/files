"""Single-process synthetic lab API for the delivered V5 interface.

All account fixtures remain synthetic. Sessions, proposals and receipts live in
memory for at most 30 minutes; restart clears them. No public banking writes.
"""
from __future__ import annotations
import asyncio
from dataclasses import dataclass, field
import hmac
import json
import os
from pathlib import Path
import queue
import secrets
import threading
import time
from typing import Any
from urllib.parse import urlsplit

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, RedirectResponse, StreamingResponse
from .agents import AgentRuntime
from .domain import domain

ROOT = Path(__file__).resolve().parents[1]
TTL = 30 * 60
MAX_SESSIONS = 100
SESSIONS_LOCK = threading.RLock()

@dataclass
class Session:
    csrf: str
    fixture: dict[str, Any]
    created: float = field(default_factory=time.monotonic)
    plan: dict[str, Any] | None = None
    receipts: dict[str, Any] = field(default_factory=dict)
    busy: bool = False
    generation: int = 0
    lock: Any = field(default_factory=threading.RLock)
    cancel: Any = field(default_factory=threading.Event)

SESSIONS: dict[str, Session] = {}
app = FastAPI(title='PaymentShield synthetic lab', docs_url=None, redoc_url=None,
              openapi_url=None, root_path=os.environ.get('ROOT_PATH', '').rstrip('/'))

@app.middleware('http')
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Referrer-Policy'] = 'same-origin'
    response.headers['Cache-Control'] = 'no-store'
    return response

def origin_check(request: Request) -> None:
    origin = request.headers.get('origin')
    if request.headers.get('sec-fetch-site') == 'cross-site':
        raise HTTPException(403, 'Cross-site request rejected')
    if origin:
        approved = os.environ.get('LAB_PUBLIC_ORIGIN', '').rstrip('/')
        if not approved:
            approved = str(request.base_url).rstrip('/')
            p = urlsplit(approved)
            approved = f'{p.scheme}://{p.netloc}'
        if not hmac.compare_digest(origin.rstrip('/'), approved):
            raise HTTPException(403, 'Origin does not match the approved lab origin')

async def body(request: Request, allowed: set[str]) -> dict[str, Any]:
    raw = await request.body()
    if len(raw) > 65536:
        raise HTTPException(413, 'Request too large')
    try:
        value = json.loads(raw)
    except (ValueError, UnicodeError):
        raise HTTPException(400, 'Expected a JSON object')
    if not isinstance(value, dict) or set(value) - allowed:
        raise HTTPException(400, 'Unexpected request fields')
    return value

def session_for(request: Request) -> Session:
    origin_check(request)
    sid = request.headers.get('x-session-id', '')
    csrf = request.headers.get('x-csrf-token', '')
    with SESSIONS_LOCK:
        s = SESSIONS.get(sid)
        if not s or time.monotonic() - s.created >= TTL:
            if s:
                s.cancel.set()
                SESSIONS.pop(sid, None)
            raise HTTPException(401, 'Session expired or missing; reconnect')
        if not csrf or not hmac.compare_digest(csrf, s.csrf):
            raise HTTPException(403, 'Session request token rejected')
        return s

def scenario(value: Any) -> str:
    if value not in ('timing', 'limited', 'income', 'buffered'):
        raise HTTPException(400, 'Unknown synthetic scenario')
    return value

def validated_revision(candidate: Any, s: Session) -> dict[str, Any]:
    if not isinstance(candidate, dict) or set(candidate) != set(s.fixture):
        raise HTTPException(400, 'Expected the complete synthetic fixture schema')
    # Only explicit demo preferences and adapter availability flags are editable.
    editable = {'reserve', 'payday', 'consent', 'fresh', 'digital', 'specialist',
                'preferSupport', 'declined', 'failExecution', 'version'}
    for key in s.fixture.keys() - editable:
        if candidate[key] != s.fixture[key]:
            raise HTTPException(400, f'Server-owned fixture field changed: {key}')
    for key in ('reserve', 'payday', 'version'):
        if type(candidate[key]) is not int:
            raise HTTPException(400, f'Invalid integer: {key}')
    if not 0 <= candidate['reserve'] <= 10000000 or not 9 <= candidate['payday'] <= 24:
        raise HTTPException(400, 'Preference out of demo bounds')
    if not s.fixture['version'] <= candidate['version'] <= s.fixture['version'] + 20:
        raise HTTPException(409, 'Stale or invalid fixture version')
    for key in editable - {'reserve', 'payday', 'version'}:
        if type(candidate[key]) is not bool:
            raise HTTPException(400, f'Invalid flag: {key}')
    substantive = editable - {'consent', 'declined', 'failExecution', 'version'}
    if any(candidate[k] != s.fixture[k] for k in substantive) and candidate['version'] <= s.fixture['version']:
        raise HTTPException(409, 'Changed preferences require a new fixture version')
    try:
        domain('validate', fixture=candidate)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return json.loads(json.dumps(candidate))

@app.get('/api/health')
def health():
    return {'status': 'ok', 'data': 'synthetic', 'storage': 'in-memory single worker',
            'bedrock_configured': bool(os.environ.get('BEDROCK_MODEL_ID')),
            'live_inference_verified': False}

@app.post('/api/session')
async def create_session(request: Request):
    origin_check(request)
    configured = os.environ.get('LAB_ACCESS_TOKEN', '')
    if len(configured) < 20:
        raise HTTPException(503, 'Configure LAB_ACCESS_TOKEN with at least 20 characters')
    header = request.headers.get('authorization', '')
    if not hmac.compare_digest(header, 'Bearer ' + configured):
        raise HTTPException(401, 'Lab access token rejected')
    data = await body(request, {'scenario'})
    f = domain('fixture', scenario=scenario(data.get('scenario', 'timing')))
    with SESSIONS_LOCK:
        expired = [k for k, s in SESSIONS.items() if time.monotonic() - s.created >= TTL]
        for key in expired:
            SESSIONS[key].cancel.set(); del SESSIONS[key]
        if len(SESSIONS) >= MAX_SESSIONS:
            raise HTTPException(429, 'Lab session capacity reached')
        sid, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
        SESSIONS[sid] = Session(csrf, f)
    return {'session_id': sid, 'csrf': csrf,
            'bedrock_configured': bool(os.environ.get('BEDROCK_MODEL_ID')), 'expires_in_seconds': TTL}

@app.post('/api/reset')
async def reset(request: Request):
    s = session_for(request); data = await body(request, {'scenario'})
    new_fixture = domain('fixture', scenario=scenario(data.get('scenario')))
    with s.lock:
        if s.busy: raise HTTPException(409, 'A live run is still active')
        s.cancel.set(); s.generation += 1; s.plan = None; s.receipts = {}; s.fixture = new_fixture
    return {'fixture': new_fixture, 'reset': True}

@app.post('/api/approve')
async def approve(request: Request):
    s = session_for(request)
    data = await body(request, {'proposal_id', 'callback_preference', 'fail_execution'})
    proposal_id = data.get('proposal_id')
    if not isinstance(proposal_id, str): raise HTTPException(400, 'Proposal ID is required')
    callback = data.get('callback_preference', 'Next business day · morning')
    if not isinstance(callback, str) or len(callback) > 160:
        raise HTTPException(400, 'Invalid callback preference')
    failure = data.get('fail_execution', False)
    if type(failure) is not bool: raise HTTPException(400, 'Invalid simulated failure flag')
    with s.lock:
        if s.busy: raise HTTPException(409, 'Wait for the current proposal')
        if proposal_id in s.receipts:
            return {'receipt': s.receipts[proposal_id], 'fixture': s.fixture, 'replayed': True}
        if not s.plan or s.plan['id'] != proposal_id:
            raise HTTPException(409, 'Proposal absent, superseded or belongs to another session')
        f = dict(s.fixture); f['failExecution'] = failure
        try:
            result = domain('approve', fixture=f, plan=s.plan, store=s.receipts)
        except ValueError as exc:
            s.plan = None; s.fixture['failExecution'] = False
            raise HTTPException(409, str(exc))
        s.fixture, s.receipts = result['fixture'], result.pop('store')
        if result['receipt']['kind'] == 'support':
            result['receipt']['callback_preference'] = callback
            s.receipts[proposal_id] = result['receipt']
        return result

@app.post('/api/run')
async def run(request: Request):
    s = session_for(request); data = await body(request, {'fixture', 'reason'})
    if not os.environ.get('BEDROCK_MODEL_ID'):
        raise HTTPException(503, 'An approved BEDROCK_MODEL_ID is not configured; no fallback is used')
    reason = data.get('reason', 'Prepare a customer-controlled support proposal')
    if not isinstance(reason, str) or not 1 <= len(reason) <= 2000:
        raise HTTPException(400, 'Invalid customer brief')
    with s.lock:
        if s.busy: raise HTTPException(409, 'Only one active run per session')
        if s.receipts: raise HTTPException(409, 'Reset the scenario before another independent action')
        snapshot = validated_revision(data.get('fixture'), s)
        s.cancel.set(); s.cancel = threading.Event(); cancel = s.cancel
        s.generation += 1; generation = s.generation; s.fixture = snapshot; s.plan = None; s.busy = True
    events: queue.Queue = queue.Queue(maxsize=512)
    run_id = 'LIVE-' + secrets.token_hex(6).upper()

    def emit(event):
        if cancel.is_set(): raise RuntimeError('Run cancelled')
        events.put(event, timeout=5)

    def worker():
        try:
            runtime = AgentRuntime(snapshot, emit, run_id=run_id)
            plan = runtime.run(reason)
            with s.lock:
                if cancel.is_set() or generation != s.generation or time.monotonic() - s.created >= TTL:
                    raise RuntimeError('Run expired or superseded')
                # Keep the validated domain plan server-side; never accept amounts from the client.
                expected = domain('plan', fixture=snapshot, runId=run_id, selection=plan['kind'])
                if plan['amount'] != expected['amount'] or plan['fingerprint'] != expected['fingerprint']:
                    raise ValueError('Final plan failed domain parity')
                s.plan = plan
                emit({'type': 'proposal_ready', 'mode': 'bedrock', 'runId': run_id, 'plan': plan})
        except Exception as exc:
            with s.lock: s.plan = None
            if not cancel.is_set():
                # No credentials, SDK exception dumps, or model reasoning in user-facing errors.
                try: emit({'type': 'error', 'mode': 'bedrock', 'runId': run_id,
                           'message': f'Live planning failed ({type(exc).__name__}). No action or offline fallback was produced.'})
                except Exception: pass
        finally:
            with s.lock: s.busy = False
            try: events.put(None, timeout=1)
            except queue.Full: pass

    threading.Thread(target=worker, daemon=True).start()
    async def stream():
        completed = False
        try:
            while True:
                if await request.is_disconnected(): break
                try: event = await asyncio.to_thread(events.get, True, 0.3)
                except queue.Empty:
                    yield '\n'; continue
                if event is None: break
                if event.get('type') == 'proposal_ready': completed = True
                yield json.dumps(event, ensure_ascii=False, allow_nan=False) + '\n'
        finally:
            if not completed:
                cancel.set()
                with s.lock: s.plan = None
    return StreamingResponse(stream(), media_type='application/x-ndjson',
                             headers={'X-Accel-Buffering': 'no'})

@app.get('/')
def index():
    return FileResponse(ROOT / 'START_HERE.html', media_type='text/html')

@app.get('/{file_path:path}')
def static_file(file_path: str):
    if file_path.startswith('api/'):
        raise HTTPException(404, 'Unknown API route')
    roots = {'START_HERE.html', 'PaymentShield_V5.html', 'CreditCompass_V5.html',
             'PaymentShield_Walkthrough.mp4', 'README.md'}
    public = file_path in roots or file_path.startswith(('docs/', 'artifacts/', 'supporting_materials/'))
    candidate = (ROOT / file_path).resolve()
    if not public or not candidate.is_relative_to(ROOT) or not candidate.is_file():
        raise HTTPException(404, 'File not available')
    return FileResponse(candidate)
