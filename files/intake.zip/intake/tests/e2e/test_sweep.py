"""L4 sweep (QA E2E-16/17/19): visit every route and initiative tab, click every non-destructive button,
scan the DOM for undefined/NaN/null, check page overflow, in three timezones and two viewports."""
from __future__ import annotations

import re

import pytest

from .helpers import (
    TIMEZONES,
    assert_clean,
    bad_text,
    no_page_overflow,
    shot,
    wait_idle,
)

TOP_ROUTES = ["#/portfolio", "#/search", "#/initiative/new", "#/intake", "#/resources", "#/risks", "#/changes",
              "#/artifacts", "#/outbox", "#/ai-activity", "#/settings"]
TABS = ["pg1", "pg2", "pg3", "pg4", "pg5", "risks", "artifacts"]
# Anything that writes, deletes, sends, approves or leaves the page is skipped.
DENY = re.compile(
    r"^\W*(delete|reset|remove|reject|dismiss|discard|no-go|go|approve|send|accept|save|confirm|run reminders|fast-forward|"
    r"re-baseline|look up|stop|close|cancel|hide|move to next|acknowledge|use this text|\+ add|edit before|regenerate|"
    r"use the calculated|print view|back to tabs|create|ask)\b",
    re.IGNORECASE,
)


def visible_buttons(page):
    return page.locator("#view-host button:visible")


def close_overlays(page):
    """Dismiss any modal a button opened (Escape, then Cancel/Close inside it)."""
    overlay = page.locator(".modal-scrim:visible, .dv-scrim:visible")
    if not overlay.count():
        return
    page.keyboard.press("Escape")
    page.wait_for_timeout(200)
    if overlay.count():
        dialog = page.locator(".modal:visible, .dv-modal:visible").last
        for name in ("Cancel", "Close"):
            btn = dialog.get_by_role("button", name=name)
            if btn.count():
                btn.first.click()
                break
        page.wait_for_timeout(200)


def sweep_route(page, hash_, max_clicks=40):
    page.goto(f"{page.base_url}/{hash_}")
    wait_idle(page, 500)
    clicked = 0
    i = 0
    while clicked < max_clicks:
        buttons = visible_buttons(page)
        if i >= buttons.count():
            break
        b = buttons.nth(i)
        i += 1
        label = (b.inner_text() or b.get_attribute("aria-label") or "").strip()
        if not label or DENY.search(label) or b.is_disabled():
            continue
        before = page.url
        b.click()
        clicked += 1
        page.wait_for_timeout(350)
        close_overlays(page)
        if page.url != before:
            page.goto(f"{page.base_url}/{hash_}")
            wait_idle(page, 300)
    wait_idle(page)
    bad = bad_text(page)
    assert not bad, f"{hash_}: {bad}"


@pytest.fixture(scope="module")
def hero(e2e_live):
    e2e_live.api("POST", "/admin/reset", {})
    return e2e_live.api("POST", "/admin/fast-forward-hero", {})["initiative_id"]


# Full click sweep once (Toronto, 1366); the other timezone/viewport pairs visit every page without clicking.
SWEEP_RUNS = [
    ("America/Toronto", "1366", True),
    ("America/Toronto", "1920", False),
    ("Pacific/Auckland", "1366", False),
    ("America/Los_Angeles", "1920", False),
]


@pytest.mark.parametrize(("tz", "viewport", "click"), SWEEP_RUNS)
def test_sweep_routes_and_tabs(e2e_live, hero, open_page, tz, viewport, click):
    page = open_page(e2e_live.base_url, tz=tz, viewport=viewport)
    routes = TOP_ROUTES + [f"#/initiative/{hero}/{t}" for t in TABS] + [f"#/initiative/2/{t}" for t in TABS]
    for r in routes:
        sweep_route(page, r, max_clicks=40 if click else 0)
        assert no_page_overflow(page), f"{r} overflows at {viewport}"
        assert page.locator("#view-host .error-panel").count() == 0, f"{r} shows an error panel"
    for r in ("#/portfolio", f"#/initiative/{hero}/pg2", f"#/initiative/{hero}/pg5", "#/resources"):
        page.goto(f"{page.base_url}/{r}")
        wait_idle(page, 500)
        shot(page, f"sweep_{r.strip('#/').replace('/', '_')}_{tz.replace('/', '_')}_{viewport}")
    assert_clean(page, f"sweep {tz} {viewport}")


def test_dates_identical_across_timezones(e2e_live, hero, open_page):
    texts = {}
    for tz in TIMEZONES:
        page = open_page(e2e_live.base_url, tz=tz)
        page.goto(f"{page.base_url}/#/initiative/{hero}/pg2")
        wait_idle(page, 600)
        texts[tz] = sorted(set(re.findall(r"\b\d{1,2} [A-Z][a-z]{2} 20\d\d\b", page.locator("#view-host").inner_text())))
        assert_clean(page, tz)
    first = texts[TIMEZONES[0]]
    assert first, "no dates found on Pg 2"
    for tz in TIMEZONES[1:]:
        assert texts[tz] == first, f"dates differ in {tz}"


def test_xss_name_renders_literally(e2e_live, open_page):
    payload = "<img src=x onerror=alert(1)>"
    created = e2e_live.api("POST", "/initiatives", {"name": payload, "lob": "Technology", "priority": 3, "requestor": "Bea Lindqvist"})
    page = open_page(e2e_live.base_url)
    for r in ("#/portfolio", "#/search", "#/intake", f"#/initiative/{created['initiative']['id']}/pg5"):
        page.goto(f"{page.base_url}/{r}")
        wait_idle(page, 400)
        assert page.locator("img[src=x]").count() == 0
    assert_clean(page, "xss")
