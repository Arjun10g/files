"""Operational portal regressions against a fresh database and real browser."""
from __future__ import annotations

import pytest
from playwright.sync_api import expect

from .helpers import assert_clean, no_page_overflow
from .test_portal_intake import PortalApp


@pytest.fixture
def portal():
    app = PortalApp()
    try:
        app.start()
        yield app
    finally:
        app.stop()


def _initiative(portal, name="Operations browser initiative"):
    return portal.api("POST", "/initiatives", {
        "name": name, "lob": "Canadian P&C", "priority": 2,
        "requestor": "Operations Requestor",
    })["initiative"]


def _save(page, label="Save"):
    dialog = page.get_by_role("dialog")
    dialog.get_by_role("button", name=label, exact=True).click()
    expect(dialog).to_have_count(0)


def _assert_layout(page):
    assert page.viewport_size["width"] == 1366
    assert no_page_overflow(page), "The portal must fit the 1366 px browser viewport."


def _confirm_delete(page, endpoint):
    with page.expect_response(lambda response: response.request.method == "DELETE" and response.url.endswith(endpoint)) as response:
        _save(page, "Delete")
    assert response.value.ok


def test_people_capacity_skills_and_monthly_allocation(portal, open_page):
    page = open_page(portal.base_url, viewport="1366")
    page.goto(f"{portal.base_url}/#/resources")
    expect(page.get_by_role("button", name="Add first person", exact=True)).to_be_visible()
    assert portal.api("GET", "/resources")["total"] == 0
    _assert_layout(page)
    # Creating an intake also registers its requestor in the portal roster.
    initiative = _initiative(portal)

    page.get_by_role("button", name="Add person", exact=True).click()
    dialog = page.get_by_role("dialog")
    dialog.get_by_label("Full name", exact=False).fill("Browser Integration Engineer")
    dialog.get_by_label("Role", exact=False).fill("Integration Developer")
    dialog.get_by_label("Team", exact=True).fill("Channels Operations")
    dialog.get_by_label("Email", exact=True).fill("browser.engineer@example.test")
    _assert_layout(page)
    _save(page)
    person = next(person for person in portal.api("GET", "/resources")["items"]
                  if person["name"] == "Browser Integration Engineer")
    assert person["name"] == "Browser Integration Engineer"
    assert person["team"] == "Channels Operations"
    assert person["default_monthly_hours"] == 140

    page.get_by_role("tab", name="People & skills", exact=True).click()
    engineer_row = page.get_by_role("table", name="People and skills", exact=True).get_by_role("row").filter(has_text="Browser Integration Engineer")
    engineer_row.get_by_role("button", name="Capacity", exact=True).click()
    dialog = page.get_by_role("dialog")
    dialog.get_by_label("Oct 2026", exact=False).fill("120")
    dialog.get_by_label("Nov 2026", exact=False).fill("0")
    _save(page)
    availability = portal.api("GET", f"/resources/{person['id']}/availability")["months"]
    assert availability["2026-10"] == 120
    assert availability["2026-11"] == 0

    engineer_row.get_by_role("button", name="Skills", exact=True).click()
    dialog = page.get_by_role("dialog")
    dialog.get_by_role("textbox", name="Skill name", exact=True).fill("Kafka")
    dialog.get_by_role("combobox", name="Skill level", exact=True).select_option("2")
    _save(page)
    person = next(person for person in portal.api("GET", "/resources")["items"]
                  if person["name"] == "Browser Integration Engineer")
    assert person["skills"] == [{"skill": "Kafka", "level": 2}]

    engineer_row.get_by_role("button", name="Edit", exact=True).click()
    page.get_by_role("dialog").get_by_label("Role", exact=False).fill("Senior Integration Developer")
    _save(page)
    assert next(person for person in portal.api("GET", "/resources")["items"]
                if person["name"] == "Browser Integration Engineer")["role"] == "Senior Integration Developer"

    page.get_by_role("button", name="Allocate hours", exact=True).click()
    dialog = page.get_by_role("dialog")
    dialog.get_by_label("Person", exact=False).select_option(str(person["id"]))
    dialog.get_by_label("Initiative", exact=False).select_option(str(initiative["id"]))
    dialog.get_by_label("Allocated hours", exact=False).fill("90")
    dialog.get_by_label("Commitment", exact=True).select_option("confirmed")
    _save(page)
    allocation = portal.api("GET", "/allocations")["items"][0]
    assert (allocation["resource_id"], allocation["initiative_id"], allocation["hours"]) == (person["id"], initiative["id"], 90)
    assert allocation["firmness"] == "confirmed"
    assert allocation["source"] == "manual"

    page.get_by_role("tab", name="Allocations", exact=True).click()
    table = page.get_by_role("table", name="Monthly initiative allocations", exact=True)
    table.get_by_role("button", name="Edit", exact=True).click()
    dialog = page.get_by_role("dialog")
    dialog.get_by_label("Allocated hours", exact=False).fill("-1")
    dialog.get_by_role("button", name="Save", exact=True).click()
    expect(dialog).to_be_visible()
    assert not dialog.locator("form").evaluate("form => form.checkValidity()")
    assert portal.api("GET", "/allocations")["items"][0]["hours"] == 90
    dialog.get_by_label("Allocated hours", exact=False).fill("132")
    _save(page)
    assert portal.api("GET", "/allocations")["items"][0]["hours"] == 132

    page.get_by_role("tab", name="Capacity overview", exact=True).click()
    expect(page.locator(".ch-heatmap svg")).to_be_visible()
    capacity = portal.api("GET", "/capacity?group=resource&from=2026-10&to=2026-11")
    october, november = next(row for row in capacity["rows"] if row["resource_id"] == person["id"])["cells"]
    assert october["available"] == 120 and october["confirmed"] == 132
    assert october["util"] == 1.1
    assert november["available"] == 0
    _assert_layout(page)

    page.get_by_role("tab", name="Allocations", exact=True).click()
    table.get_by_role("button", name="Delete", exact=True).click()
    page.get_by_role("dialog").get_by_role("button", name="Cancel", exact=True).click()
    assert portal.api("GET", "/allocations")["total"] == 1
    table.get_by_role("button", name="Delete", exact=True).click()
    _confirm_delete(page, f"/allocations/{allocation['id']}")
    assert portal.api("GET", "/allocations")["total"] == 0
    page.reload()
    page.get_by_role("tab", name="People & skills", exact=True).click()
    expect(page.get_by_text("Senior Integration Developer", exact=True)).to_be_visible()
    expect(page.get_by_text("Kafka · 2/3", exact=True)).to_be_visible()
    assert_clean(page)


def test_funding_estimates_actuals_links_and_delete(portal, open_page):
    initiative = _initiative(portal)
    page = open_page(portal.base_url, viewport="1366")
    page.goto(f"{portal.base_url}/#/funding")
    expect(page.get_by_role("button", name="Add first budget", exact=True)).to_be_visible()
    assert portal.api("GET", "/funding")["total"] == 0
    _assert_layout(page)

    page.get_by_role("button", name="Add budget", exact=True).click()
    dialog = page.get_by_role("dialog")
    dialog.get_by_label("Funding / PRN code", exact=False).fill("PRN-BROWSER-001")
    dialog.get_by_label("Budget name", exact=False).fill("Browser Channels Funding")
    dialog.get_by_label("Funded hours", exact=True).fill("1000")
    dialog.get_by_label("Blended hourly rate", exact=False).fill("120")
    dialog.get_by_label("Funding decision", exact=True).select_option("Approved")
    dialog.get_by_label("PR charge allocation", exact=True).select_option("POD")
    dialog.get_by_label("End month", exact=True).fill("2027-03")
    dialog.get_by_label("Scope", exact=True).fill("Mobile channels integration and support.")
    dialog.get_by_label("Assumptions", exact=True).fill("One planned release.")
    _assert_layout(page)
    _save(page)
    code = "PRN-BROWSER-001"
    budget = portal.api("GET", f"/funding/{code}")
    assert budget["budget_amount"] == 120000
    assert budget["charge_type"] == "POD" and budget["decision"] == "Approved"
    assert budget["scope"] == "Mobile channels integration and support."

    page.get_by_role("button", name="Add estimate", exact=True).click()
    dialog = page.get_by_role("dialog")
    dialog.get_by_label("Estimated hours", exact=False).fill("600")
    dialog.get_by_role("button", name="Save", exact=True).click()
    expect(dialog.get_by_role("alert")).to_contain_text("Enter an AppCat, team or STO")
    assert portal.api("GET", f"/funding/{code}")["estimates"] == []
    dialog.get_by_label("AppCat / component", exact=True).fill("APPCAT-001")
    dialog.get_by_label("Team", exact=True).fill("Channels Operations")
    dialog.get_by_label("STO", exact=True).fill("Channels STO")
    dialog.get_by_label("Decision", exact=True).select_option("Approved")
    dialog.get_by_label("Scope, assumptions & notes", exact=True).fill("API development; one release.")
    _save(page)
    budget = portal.api("GET", f"/funding/{code}")
    line = budget["estimates"][0]
    assert line["amount"] == 72000 and line["phase"] == "Development"
    assert line["notes"] == "API development; one release."
    estimates = page.get_by_role("table", name="Component funding estimates", exact=True)
    estimates.get_by_role("button", name="Edit", exact=True).click()
    dialog = page.get_by_role("dialog")
    dialog.get_by_label("Estimated hours", exact=False).fill("650")
    dialog.get_by_label("Estimated amount", exact=False).fill("")
    _save(page)
    assert portal.api("GET", f"/funding/{code}")["totals"]["estimated_amount"] == 78000

    page.get_by_role("button", name="Record actuals", exact=True).click()
    dialog = page.get_by_role("dialog")
    dialog.get_by_label("Charged hours", exact=False).fill("80")
    _save(page)
    actuals = page.get_by_role("table", name="Monthly actual funding charges", exact=True)
    actuals.get_by_role("button", name="Edit", exact=True).click()
    dialog = page.get_by_role("dialog")
    dialog.get_by_label("Charged hours", exact=False).fill("85")
    dialog.get_by_label("Actual amount", exact=False).fill("")
    _save(page)
    budget = portal.api("GET", f"/funding/{code}")
    assert budget["totals"]["charged_amount"] == 10200
    assert budget["totals"]["remaining_amount"] == 109800

    page.get_by_role("button", name="Manage links", exact=True).click()
    page.get_by_role("dialog").get_by_role("checkbox").check()
    _save(page, "Save links")
    assert portal.api("GET", f"/initiatives/{initiative['id']}")["initiative"]["prn_code"] == code
    assert portal.api("GET", f"/funding/{code}")["initiatives"][0]["id"] == initiative["id"]
    _assert_layout(page)
    page.reload()
    page.get_by_role("button", name="Open", exact=True).click()
    expect(page.get_by_role("link", name=f"{initiative['rddc']} · {initiative['name']}", exact=True)).to_be_visible()
    expect(page.locator(".ch-burndown svg")).to_be_visible()
    _assert_layout(page)

    actuals.get_by_role("button", name="Delete", exact=True).click()
    page.get_by_role("dialog").get_by_role("button", name="Cancel", exact=True).click()
    assert len(portal.api("GET", f"/funding/{code}")["charges"]) == 1
    actuals.get_by_role("button", name="Delete", exact=True).click()
    _confirm_delete(page, f"/funding/{code}/charges/{budget['charges'][0]['id']}")
    assert portal.api("GET", f"/funding/{code}")["charges"] == []
    estimates.get_by_role("button", name="Delete", exact=True).click()
    _confirm_delete(page, f"/funding/{code}/estimates/{line['id']}")
    assert portal.api("GET", f"/funding/{code}")["estimates"] == []

    page.get_by_role("button", name="Edit budget", exact=True).click()
    page.get_by_role("dialog").get_by_label("Budget name", exact=False).fill("Reviewed Channels Funding")
    _save(page)
    assert portal.api("GET", f"/funding/{code}")["name"] == "Reviewed Channels Funding"
    page.get_by_role("button", name="Manage links", exact=True).click()
    page.get_by_role("dialog").get_by_role("checkbox").uncheck()
    _save(page, "Save links")
    assert portal.api("GET", f"/initiatives/{initiative['id']}")["initiative"]["prn_code"] is None
    page.locator(".op-detail-head").get_by_role("button", name="Delete", exact=True).click()
    _confirm_delete(page, f"/funding/{code}")
    assert portal.api("GET", "/funding")["total"] == 0
    assert_clean(page)
