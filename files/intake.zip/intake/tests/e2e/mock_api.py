"""Contract-shaped mock of /api/* for the UI harness (test_ui_mocked.py).

It lets the B5 dashboards run inside the real shell before the backend is complete. Payload shapes follow
docs/contracts.md; numbers follow the master plan §6 hero values. It is test data only and never shipped.
"""
from __future__ import annotations

import json
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parents[2]
BUNDLE = json.loads((ROOT / "tests" / "fixtures" / "bundle_hero.json").read_text())
TODAY = "2026-10-19"
FY_MONTHS = ["2026-11", "2026-12", "2027-01", "2027-02", "2027-03", "2027-04",
             "2027-05", "2027-06", "2027-07", "2027-08", "2027-09", "2027-10"]
QUARTERS = [
    {"fy": "FY27", "q": "Q1", "label": "Nov–Jan", "months": FY_MONTHS[0:3]},
    {"fy": "FY27", "q": "Q2", "label": "Feb–Apr", "months": FY_MONTHS[3:6]},
    {"fy": "FY27", "q": "Q3", "label": "May–Jul", "months": FY_MONTHS[6:9]},
    {"fy": "FY27", "q": "Q4", "label": "Aug–Oct", "months": FY_MONTHS[9:12]},
]
TRAINS = [
    {"code": "DC-2610", "train_date": "2026-10-17", "status": "Done"},
    {"code": "DC-2611", "train_date": "2026-11-21", "status": "Planned"},
    {"code": "DC-2612", "train_date": "2026-12-12", "status": "Planned"},
    {"code": "DC-2701", "train_date": "2027-01-16", "status": "Planned"},
    {"code": "DC-2702", "train_date": "2027-02-20", "status": "Planned"},
    {"code": "DC-2703", "train_date": "2027-03-20", "status": "Planned"},
]
FREEZE = {"start": "2026-12-14", "end": "2027-01-08"}
DIMS = ("schedule", "resources", "scope", "dependencies", "budget")


def _opts(values, labels=None):
    return [{"value": v, "label": (labels or {}).get(v, str(v))} for v in values]


PROJECTS = [
    (1, "RDDC-24310", "US Business Bill Pay Migration", "US P&C", "Ravi Dunmore", "Closed", "Green", "DC-2610"),
    (2, "RDDC-24412", "e-Transfer Request Money Redesign", "Cards & Payments", "Grace Ellingham", "Release", "Red", "DC-2611"),
    (3, "RDDC-24533", "Mobile Biometric Login Refresh", "Canadian P&C", "Ravi Dunmore", "Build", "Green", "DC-2701"),
    (4, "RDDC-24601", "Step-up MFA for Wire Transfers", "Commercial Banking", "Grace Ellingham", "QA", "Amber", "DC-2612"),
    (5, "RDDC-24688", "Online Statement Download Redesign", "Canadian P&C", "Ravi Dunmore", "Planning", "Green", "DC-2702"),
    (6, "RDDC-24702", "Credit Card Instalment Plan API", "Cards & Payments", "Grace Ellingham", "Estimation", "Amber", "DC-2703"),
    (7, "RDDC-24755", "Wealth Dashboard Accessibility Fixes", "Wealth", "Ravi Dunmore", "Solution", "Amber", "DC-2703"),
    (8, "RDDC-24790", "Digital Channels Observability Uplift", "Technology", "Grace Ellingham", "Grooming", None, None),
    (9, "RDDC-24817", "US API Enhancement", "US P&C", "Grace Ellingham", "Planning", "Amber", "DC-2702"),
]


def lookups():
    resources = [{"id": r["id"], "name": r["name"], "role": r["role"], "team": r["team"], "team_label": r["team_label"],
                  "capacity_eligible": r["capacity_eligible"]} for r in BUNDLE["resources"]]
    return {
        "stage": _opts(["Intake", "Grooming", "Solution", "Estimation", "Planning", "Build", "QA", "Release", "Closed"]),
        "status": _opts(["Backlog", "In progress", "Completed"]),
        "lob": _opts(["Canadian P&C", "US P&C", "Commercial Banking", "Wealth", "Cards & Payments", "Technology"]),
        "priority": _opts([1, 2, 3, 4], {1: "P1", 2: "P2", 3: "P3", 4: "P4"}),
        "risk_category": _opts(["Schedule", "Resource", "Scope", "Dependency", "Budget", "Technical", "Compliance"]),
        "risk_severity": _opts([1, 2, 3, 4], {1: "Low", 2: "Medium", 3: "High", 4: "Critical"}),
        "risk_likelihood": _opts([1, 2, 3, 4], {1: "Rare", 2: "Unlikely", 3: "Possible", 4: "Likely"}),
        "risk_status": _opts(["Open", "Mitigating", "Closed"]),
        "notification_status": _opts(["Queued", "Sent", "Acknowledged", "Dismissed"]),
        "persona": _opts(["DC PM", "Dev Lead", "Requestor", "STO", "Account Manager"]),
        "rag": _opts(["Red", "Amber", "Green"]),
        "components": [{"id": c["id"], "code": c["code"], "name": c["name"], "team": c.get("team")} for c in BUNDLE["component_catalog"]],
        "resources": resources,
        "release_trains": TRAINS,
        "fiscal_quarters": QUARTERS,
        "freeze": FREEZE,
        "holidays": ["2026-11-11", "2026-12-25", "2026-12-28", "2027-01-01", "2027-02-15"],
    }


def _dims(rag):
    if rag is None:
        return None
    if rag == "Red":
        return {"schedule": "Red", "resources": "Amber", "scope": "Green", "dependencies": "Amber", "budget": "Red"}
    if rag == "Amber":
        return {"schedule": "Amber", "resources": "Red", "scope": "Green", "dependencies": "Green", "budget": "Green"}
    return dict.fromkeys(DIMS, "Green")


def portfolio():
    projects = []
    for pid, rddc, name, lob, pm, stage, rag, train in PROJECTS:
        projects.append({
            "id": pid, "rddc": rddc, "name": name, "lob": lob, "dc_pm_name": pm, "stage": stage, "rag": rag,
            "dimensions": _dims(rag), "target_release": train,
            "readiness_date": "2027-02-17" if pid == 9 else ("2026-11-18" if pid == 2 else None),
            "qa_signoff_date": "2026-10-09" if pid == 1 else None,
            "prod_date": "2027-02-20" if pid == 9 else ("2026-10-17" if pid == 1 else None),
            "comments": "STO Tentative No Go; business validation failed" if pid == 2 else None,
            "attention": ["SA capacity constraint affecting WBS-100"] if pid == 9 else (["Overdue critical-path step WBS-500"] if pid == 2 else []),
        })
    return {
        "kpis": {"active": 8, "red": 1, "amber": 4, "green": 3, "crqs_this_week": 2, "overallocated_people": 2},
        "projects": projects,
        "change_mgmt": [
            {"initiative_id": 2, "rddc": "RDDC-24412", "crq_number": "CRQ000418822", "release_train": "DC-2611", "cms_lead_name": "Petra Vallance",
             "rel_lead_name": "Owen Stroud", "resource_name": "Kai Moreau", "implementation_status": "Scheduled", "tech_validation_status": "Completed",
             "biz_validation_status": "Failed", "sto_approval": "Tentative No Go", "compliance_flags": ["Business validation failed"]},
            {"initiative_id": 4, "rddc": "RDDC-24601", "crq_number": "CRQ000419310", "release_train": "DC-2612", "cms_lead_name": "Petra Vallance",
             "rel_lead_name": "Owen Stroud", "resource_name": "Ines Hollowell", "implementation_status": "Not Started", "tech_validation_status": "In progress",
             "biz_validation_status": "Not Started", "sto_approval": "Tentative Go", "compliance_flags": []},
        ],
        "capacity_teams": capacity("team", FY_MONTHS[0], FY_MONTHS[2])["teams"],
    }


def _util_for(rid, month):
    base = {14: 0.96, 15: 0.42, 5: 1.12, 12: 1.04, 1: 0.61, 2: 0.55, 4: 0.78, 6: 0.33}.get(rid, 0.2 + (rid % 5) * 0.12)
    if rid == 14 and month == "2026-11":
        return 1.2833
    if month >= "2027-04":
        base *= 0.4
    return base


def capacity(group, frm, to, initiative_id=None):
    months = [m for m in FY_MONTHS if frm <= m <= to] or FY_MONTHS[:3]
    people = [r for r in BUNDLE["resources"] if r["capacity_eligible"]]
    rows = []
    for r in people:
        cells = []
        for m in months:
            avail = 147.0 if (r["id"] == 1 and m == "2026-12") else (120.0 if r["team"] == "DC SA" else 140.0)
            util = _util_for(r["id"], m)
            demand = round(avail * util, 1)
            confirmed = round(demand * 0.7, 1)
            band = "spare" if util < 0.7 else "ok" if util <= 1.0 else "stretched" if util <= 1.1 else "over"
            cells.append({"month": m, "available": avail, "confirmed": confirmed, "tentative": round(demand - confirmed, 1), "util": util, "band": band})
        rows.append({"key": r["id"], "label": r["name"], "team": r["team"], "cells": cells})
    teams = {}
    for r, row in zip(people, rows):
        label = r["team_label"] if r["team"] == "EAPI" and r["team_label"] != "EAPI" else r["team"]
        if r["team"] == "EAPI" and r["team_label"] == "EAPI":
            label = "EAPI (Dev1)"
        t = teams.setdefault(label, {"team": label, "available": 0.0, "confirmed": 0.0, "tentative": 0.0})
        for c in row["cells"]:
            t["available"] += c["available"]
            t["confirmed"] += c["confirmed"]
            t["tentative"] += c["tentative"]
    team_list = []
    for t in teams.values():
        util = (t["confirmed"] + t["tentative"]) / t["available"] if t["available"] else 0
        team_list.append({**t, "util": util, "band": "over" if util > 1.1 else "stretched" if util > 1 else "ok" if util >= 0.7 else "spare"})
    if initiative_id:
        team_list = [t for t in team_list if t["team"] in ("EAPI (Dev1)", "EAPI (Dev2)", "CIAM", "SRE", "DC SA", "QA")]
    return {"months": months, "rows": rows, "teams": team_list}


def gantt():
    tasks = []
    child_ids = {t["parent_id"] for t in BUNDLE["tasks"] if t["parent_id"]}
    critical = {201, 203, 207, 210, 211, 212, 213}
    for t in BUNDLE["tasks"]:
        tasks.append({
            "id": t["id"], "wbs_code": t["wbs_code"], "parent_id": t["parent_id"], "step": t["step"], "phase": t["phase"],
            "resource_name": t["resource_name"], "planned_start": t["planned_start"], "planned_end": t["planned_end"],
            "baseline_start": t["baseline_start"], "baseline_end": t["baseline_end"], "pct": 10 if t["id"] == 201 else 0,
            "status": "In progress" if t["id"] == 201 else "Backlog", "is_milestone": t["is_milestone"],
            "is_summary": t["id"] in child_ids and not t["est_hours"], "critical": t["id"] in critical,
            "float_bd": 0 if t["id"] in critical else 5, "depends_on": t["depends_on"], "est_hours": t["est_hours"],
        })
    return {"start": "2026-10-20", "end": "2027-03-05", "today": TODAY, "freeze": FREEZE, "trains": TRAINS,
            "readiness_date": "2027-02-17", "qa_date": "2027-02-10", "prod_date": "2027-02-20", "float_bd": 2,
            "critical_path": sorted(critical), "tasks": tasks}


def portfolio_gantt():
    rows = [
        {"initiative_id": 2, "rddc": "RDDC-24412", "name": "e-Transfer Request Money Redesign", "rag": "Red", "stage": "Release", "start": "2026-06-01", "end": "2026-11-27", "readiness_date": "2026-11-18", "prod_date": "2026-11-21"},
        {"initiative_id": 3, "rddc": "RDDC-24533", "name": "Mobile Biometric Login Refresh", "rag": "Green", "stage": "Build", "start": "2026-08-03", "end": "2027-01-22", "readiness_date": "2027-01-13", "prod_date": "2027-01-16"},
        {"initiative_id": 4, "rddc": "RDDC-24601", "name": "Step-up MFA for Wire Transfers", "rag": "Amber", "stage": "QA", "start": "2026-07-06", "end": "2026-12-18", "readiness_date": "2026-12-09", "prod_date": "2026-12-12"},
        {"initiative_id": 5, "rddc": "RDDC-24688", "name": "Online Statement Download Redesign", "rag": "Green", "stage": "Planning", "start": "2026-10-26", "end": "2027-02-26", "readiness_date": "2027-02-17", "prod_date": "2027-02-20"},
        {"initiative_id": 9, "rddc": "RDDC-24817", "name": "US API Enhancement", "rag": "Amber", "stage": "Planning", "start": "2026-10-20", "end": "2027-03-05", "readiness_date": "2027-02-17", "prod_date": "2027-02-20"},
    ]
    return {"start": "2026-06-01", "end": "2027-03-31", "today": TODAY, "freeze": FREEZE, "trains": TRAINS, "rows": rows}


def health(state):
    h = json.loads(json.dumps(BUNDLE["initiative"]["health_cached_json"]))
    if state.get("fixed"):
        h["dimensions"]["resources"] = {"rag": "Green", "reasons": ["Everyone at or under 100% in their months on this initiative"], "metrics": {"peak_util": 0.96}, "overridden": False}
        h["attention"] = []
    for dim, ov in state.get("overrides", {}).items():
        h["dimensions"][dim].update({"rag": ov["rag"], "overridden": True, "override_reason": ov["reason"]})
    return h


def burndown(code):
    months = ["2026-04", "2026-05", "2026-06", "2026-07", "2026-08", "2026-09", "2026-10", "2026-11", "2026-12", "2027-01", "2027-02", "2027-03"]
    if code == "PRN-71840":
        charged = [80, 190, 330, 470, 620, 780, None, None, None, None, None, None]
        forecast = [80, 190, 330, 470, 620, 780, 860, 930, 990, 1040, 1060, 1060]
        return {"prn_code": code, "funded_hours": 900, "months": months, "charged_cum": charged, "forecast_cum": forecast,
                "funded_line": [900] * 12, "exhaust_month": "2026-12", "status": "overrun"}
    charged = [0, 0, 0, 0, 0, 0, None, None, None, None, None, None]
    forecast = [0, 0, 0, 0, 0, 0, 31.5, 180, 420, 650, 820, 859]
    return {"prn_code": "PRN-77310", "funded_hours": 1100, "months": months, "charged_cum": charged, "forecast_cum": forecast,
            "funded_line": [1100] * 12, "exhaust_month": None, "status": "on_track"}


def ai_run(feature, output, run_id, initiative_id=None):
    return {"ai_run_id": run_id, "feature": feature, "initiative_id": initiative_id, "scope": "initiative" if initiative_id else "portfolio",
            "mode": "simulated_fixture", "mode_label": "Simulated · test-agent response", "model": None, "variant_index": 0,
            "confidence": output.get("confidence", 0.8), "sources": output.get("sources", []), "warnings": [], "output": output,
            "status": "generated", "latency_ms": 1300, "minutes_saved": 30, "regen_of": None, "created_at": "2026-10-19T09:44:12-04:00"}


EXEC = {"scope": "portfolio", "period": {"from": "2026-10-13", "to": "2026-10-19"}, "headline": "1 initiative Red, 4 Amber; DC-2702 carries the most risk.",
        "rag": "Amber", "summary_md": "**RDDC-24412** is Red: business validation failed and STO is Tentative No Go.\n\n- RDDC-24817 plan approved at **1,000 h**\n- Sana Whitfield over-allocated in Nov",
        "highlights": ["RDDC-24817 plan baselined for DC-2702"], "concerns": ["RDDC-24412 business validation failed"], "asks": ["Confirm CIAM approval by 18 Nov 2026"],
        "confidence": 0.82, "sources": [{"type": "initiative", "id": "RDDC-24412", "label": "RDDC-24412 health"}], "warnings": []}
REBALANCE = {"problem": {"resource_id": 14, "resource_name": "Sana Whitfield", "month": "2026-11", "util_pct": 128, "wbs_codes": ["WBS-100"],
                         "summary": "Sana Whitfield is at 128% in Nov 2026 (154.0 h of 120 h)."},
             "options": [{"action": "Move WBS-100 from Sana Whitfield to Mateo Brennan", "task_wbs_code": "WBS-100", "from_resource_id": 14,
                          "from_resource_name": "Sana Whitfield", "to_resource_id": 15, "to_resource_name": "Mateo Brennan", "month": "2026-11",
                          "before": {"from_pct": 128, "to_pct": 42}, "after": {"from_pct": 96, "to_pct": 74},
                          "effect": "Resources turns Green; overall health stays Amber because of schedule float.",
                          "health_after": {"resources": "Green", "overall": "Amber"}}],
             "recommended_option_index": 0, "confidence": 0.88, "sources": [], "warnings": []}
SKILLS = {"skills": ["OAuth2/OIDC", "Kafka"], "rows": [{"resource_id": 4, "resource_name": "Mira Castellane", "team": "CIAM",
          "skills": [{"skill": "OAuth2/OIDC", "level": 3, "evidence": ["RDDC-24601 WBS-230 (96 h)"], "source": "both"}], "top_skills": ["OAuth2/OIDC"]}],
          "team_gaps": [{"skill": "Kafka", "holders": 1, "holder_names": ["Lena Oduya"], "note": "Key-person risk for EDP work"}], "confidence": 0.76, "sources": [], "warnings": []}
NUDGES = {"messages": [{"recipient_name": "Sana Whitfield", "recipient_resource_id": 14, "recipient_role": "DC SA", "rule": "sa_action_required",
           "subject": "Action required by 21 Oct 2026: SA inputs for RDDC-24817", "body": "Hi Sana, two items are waiting on you for US API Enhancement.",
           "action_required_by": "2026-10-21", "urgency": "Normal", "escalation_level": 0, "dedupe_key": "x", "items": []}], "confidence": 0.9, "sources": [], "warnings": []}
MEETING = {"summary": "Grooming confirmed scope and target train DC-2702.", "meeting_date": "2026-10-20",
           "decisions": [{"decision": "Target release train DC-2702", "made_by": "Grace Ellingham", "rationale": "DC-2701 is too close to the freeze", "rddc": "RDDC-24817"}],
           "actions": [{"action": "Confirm CIAM scope approval", "owner_name": "Mira Castellane", "owner_resource_id": 4, "due": "2026-10-23", "rddc": "RDDC-24817", "source_line": 7}],
           "risks_raised": [], "open_questions": ["Is data residency confirmation needed before build?"], "confidence": 0.83, "sources": [], "warnings": []}
LESSONS = {"mode": "draft", "initiative_rddc": "RDDC-24310", "lessons": [{"category": "Estimation", "kind": "improve", "what_happened": "QA ran 22% over plan.",
           "lesson": "Partner test data is on the critical path.", "recommendation": "Add a test-data readiness step before SIT.", "evidence": "WBS-400"}],
           "relevant_lessons": [], "estimate_accuracy": {"planned_hours": 820, "actual_hours": 901.5, "variance_pct": 9.9, "worst_phases": ["QA"]},
           "confidence": 0.77, "sources": [], "warnings": []}


class MockApi:
    def __init__(self):
        self.state = {"fixed": False, "overrides": {}}
        self.run_id = 100
        self.unknown: list[str] = []

    def _items(self, items):
        return {"items": items, "total": len(items)}

    def handle(self, method: str, url: str, body: dict | None):
        parsed = urlparse(url)
        path = parsed.path.removeprefix("/api")
        q = {k: v[0] for k, v in parse_qs(parsed.query).items()}
        body = body or {}
        if method == "GET":
            return self._get(path, q)
        return self._post(method, path, body)

    def _get(self, path, q):
        routes = {
            "/health": lambda: {"status": "ok", "db": True, "ai_mode": "simulated", "model": "claude-opus-5-5", "today": TODAY, "version": "1.0.0", "modules": []},
            "/settings": lambda: {"ai_mode": "auto", "ai_speed": "Fast", "demo_today": TODAY, "persona": "DC PM", "live_available": False, "model_heavy": "", "model_fast": ""},
            "/lookups": lookups,
            "/portfolio": portfolio,
            "/portfolio/gantt": portfolio_gantt,
            "/initiatives": lambda: self._items([{"id": p[0], "rddc": p[1], "name": p[2], "lob": p[3], "stage": p[5], "status": "In progress", "priority": 2,
                                                  "dc_pm_name": p[4], "dc_sa_name": "Sana Whitfield", "rag": p[6], "target_release": p[7], "readiness_date": None, "planned_end": None} for p in PROJECTS]),
            "/initiatives/9": lambda: BUNDLE,
            "/initiatives/9/health": lambda: health(self.state),
            "/initiatives/9/gantt": gantt,
            "/initiatives/9/burndown": lambda: burndown("PRN-77310"),
            "/prns": lambda: self._items([{"prn_code": "PRN-77310", "name": "US API Enhancement", "lob": "US P&C", "funded_hours": 1100, "charged_hours": 0, "forecast_hours": 859, "status": "on_track"},
                                          {"prn_code": "PRN-71840", "name": "e-Transfer Request Money", "lob": "Cards & Payments", "funded_hours": 900, "charged_hours": 780, "forecast_hours": 1060, "status": "overrun"}]),
            "/intake-queue": lambda: {"items": [
                {"initiative_id": 8, "rddc": "RDDC-24790", "name": "Digital Channels Observability Uplift", "lob": "Technology", "priority": 3, "stage": "Grooming",
                 "submitted_at": "2026-10-14T10:02:00-04:00", "session": {"id": 3, "session_date": "2026-10-22", "start_time": "10:00"}, "action_required_by": None, "waiting_on": None},
                {"initiative_id": 7, "rddc": "RDDC-24755", "name": "Wealth Dashboard Accessibility Fixes", "lob": "Wealth", "priority": 2, "stage": "Solution",
                 "submitted_at": "2026-09-30T11:00:00-04:00", "session": None, "action_required_by": "2026-10-21", "waiting_on": "Mateo Brennan"}],
                "sessions": self._sessions()},
            "/grooming/sessions": lambda: self._items(self._sessions()),
            "/risks": lambda: self._items([
                {"id": 1, "risk_code": "RSK-001", "initiative_id": 2, "rddc": "RDDC-24412", "title": "Business validation failure delays DC-2611", "category": "Schedule",
                 "severity": 4, "likelihood": 3, "score": 12, "owner_name": "Grace Ellingham", "mitigation": "Rerun business validation with fixed test data", "wbs_code": "WBS-500", "status": "Open", "source": "seed", "due_date": "2026-10-23"},
                {"id": 2, "risk_code": "RSK-002", "initiative_id": 4, "rddc": "RDDC-24601", "title": "Felix over-allocated in December", "category": "Resource",
                 "severity": 3, "likelihood": 3, "score": 9, "owner_name": "Mira Castellane", "mitigation": "Move MFA fallback work to January", "wbs_code": "WBS-230", "status": "Mitigating", "source": "ai"}]),
            "/release-trains": lambda: {"items": [{**t, "in_freeze": False, "initiatives": [{"id": p[0], "rddc": p[1], "name": p[2], "rag": p[6]} for p in PROJECTS if p[7] == t["code"]]} for t in TRAINS],
                                        "freeze": FREEZE, "holidays": []},
            "/governance/weekly": lambda: {"week": q.get("week", "2026-W43"), "from": "2026-10-19", "to": "2026-11-01", "noncompliant_count": 1, "items": [
                {"id": 1, "initiative_id": 2, "rddc": "RDDC-24412", "crq_number": "CRQ000418822", "crq_start": "2026-10-24T02:00:00-04:00", "crq_end": "2026-10-24T06:00:00-04:00",
                 "release_train": "DC-2611", "release_type": "Bundle", "implementation_status": "Scheduled", "sto_approval": "Tentative No Go",
                 "compliance": {"ok": False, "flags": [{"code": "CR-01", "message": "STO not Go by T-2 business days"}]}}]},
            "/governance/approvals": lambda: self._items([
                {"kind": "l2", "initiative_id": 6, "rddc": "RDDC-24702", "name": "Credit Card Instalment Plan API", "entity_id": 6, "title": "L2 estimate 650 h (M)", "requested_at": "2026-10-07", "waiting_days": 8, "approver": "Marcus Thorne"},
                {"kind": "sto", "initiative_id": 2, "rddc": "RDDC-24412", "name": "e-Transfer", "entity_id": 1, "title": "CRQ000418822 STO decision", "requested_at": "2026-10-15", "waiting_days": 2, "approver": "STO Board"}]),
            "/documents": lambda: self._items([{"id": 1, "initiative_id": 9, "rddc": "RDDC-24817", "doc_type": "SA", "title": "SA US API Enhancement", "version": "1.2", "attachment_id": 3, "owner_id": 14, "status": "In review", "components": ["APIP", "EDP"], "updated_at": "2026-10-19T09:50:00-04:00"}]),
            "/decisions": lambda: self._items([{"id": 1, "initiative_id": 1, "rddc": "RDDC-24310", "title": "Release on DC-2610", "decision": "Release on DC-2610", "decided_by": "Ravi Dunmore", "decided_on": "2026-09-14", "status": "Approved", "source": "system"}]),
            "/lessons": lambda: self._items([{"id": 1, "initiative_id": 1, "rddc": "RDDC-24310", "category": "Testing", "what_happened": "Partner test data was late", "lesson": "Book test data early", "recommendation": "Add a readiness step", "source": "seed"}]),
            "/meeting-notes": lambda: self._items([{"id": 1, "initiative_id": 4, "rddc": "RDDC-24601", "meeting_date": "2026-10-14", "title": "Grooming RDDC-24601",
                                                    "attendees": ["Arlo Kingsley", "Grace Ellingham"], "notes_md": "Agreed to move MFA fallback to January.\nAction: Mira to confirm scopes by 23 Oct.",
                                                    "action_items_json": [{"action": "Confirm scopes", "owner": "Mira Castellane", "due": "2026-10-23", "status": "Open"}]}]),
            "/outbox": lambda: {"items": [
                {"id": 1, "rule": "grooming_invite", "trigger_event": "Saved RDDC-24790", "initiative_id": 8, "rddc": "RDDC-24790", "to_name": "Arlo Kingsley", "cc_names": ["Grace Ellingham"],
                 "subject": "Grooming Thu 22 Oct 10:00 · RDDC-24790", "body": "You are invited to grooming.", "action_required_by": None, "due_at": "2026-10-19T09:30:00-04:00", "sent_at": None, "status": "Queued", "escalation_level": 0},
                {"id": 2, "rule": "l2_approval", "trigger_event": "L2 pending 8 business days", "initiative_id": 6, "rddc": "RDDC-24702", "to_name": "Marcus Thorne", "cc_names": [],
                 "subject": "Reminder: approve L2 for RDDC-24702", "body": "The L2 estimate is waiting for you.", "action_required_by": "2026-10-21", "due_at": "2026-10-16T09:30:00-04:00", "sent_at": "2026-10-16T09:30:00-04:00", "status": "Sent", "escalation_level": 1}],
                "total": 2, "counts": {"Queued": 1, "Sent": 1}},
            "/ai-runs": lambda: self._items([{"ai_run_id": 5, "id": 5, "feature": "change_summary", "initiative_id": 9, "scope": "initiative", "mode": "simulated_fixture",
                                             "mode_label": "Simulated · test-agent response", "confidence": 0.86, "status": "accepted", "latency_ms": 1800, "minutes_saved": 45, "created_at": "2026-10-19T09:50:00-04:00"}]),
            "/ai-runs/5": lambda: {**ai_run("change_summary", {"confidence": 0.86}, 5, 9), "status": "accepted"},
            "/ai-runs/stats": lambda: {"runs": 6, "accepted": 4, "rejected": 1, "acceptance_rate": 0.67, "minutes_saved": 185, "by_feature": [{"feature": "change_summary", "runs": 1, "accepted": 1, "minutes_saved": 45}]},
            "/skills/matrix": lambda: {"skills": [{"id": 1, "name": "OAuth2/OIDC", "category": "Security"}, {"id": 2, "name": "Kafka", "category": "Data"}],
                                       "rows": [{"resource_id": 4, "name": "Mira Castellane", "team": "CIAM", "levels": {"OAuth2/OIDC": 3}, "evidence": {"OAuth2/OIDC": "RDDC-24601 WBS-230"}},
                                                {"resource_id": 2, "name": "Lena Oduya", "team": "EAPI", "levels": {"Kafka": 3}, "evidence": {}}]},
            "/resources": lambda: self._items([{**r, "skills": r.get("skills", []), "current_load": 0.6} for r in BUNDLE["resources"] if r["capacity_eligible"]]),
            "/allocations": lambda: self._items([{"id": 1, "resource_id": 14, "resource_name": "Sana Whitfield", "initiative_id": 9, "rddc": "RDDC-24817", "task_id": 201, "wbs_code": "WBS-100", "month": "2026-11", "hours": 38.5, "firmness": "confirmed", "source": "derived"},
                                                 {"id": 2, "resource_id": 14, "resource_name": "Sana Whitfield", "initiative_id": 5, "rddc": "RDDC-24688", "task_id": None, "wbs_code": "WBS-100", "month": "2026-11", "hours": 60.0, "firmness": "confirmed", "source": "seed"}]),
            "/activity": lambda: self._items([]),
            "/initiatives/9/attachments": lambda: self._items([]),
            "/change-requests": lambda: self._items([]),
        }
        if path == "/capacity":
            return 200, capacity(q.get("group", "resource"), q.get("from", FY_MONTHS[0]), q.get("to", FY_MONTHS[-1]), q.get("initiative_id"))
        if path.startswith("/prn/"):
            return 200, burndown(path.split("/")[2])
        fn = routes.get(path)
        if fn is None:
            self.unknown.append(f"GET {path}")
            return 200, {"items": [], "total": 0}
        return 200, fn()

    def _sessions(self):
        return [
            {"id": 2, "session_date": "2026-10-20", "start_time": "10:00", "title": "Grooming", "capacity": 6, "status": "Scheduled",
             "slots": [{"initiative_id": 6, "rddc": "RDDC-24702", "name": "Credit Card Instalment Plan API", "priority": 2, "slot_order": 1, "status": "Confirmed", "recipients": [{"id": 16, "name": "Grace Ellingham"}]}]},
            {"id": 3, "session_date": "2026-10-22", "start_time": "10:00", "title": "Grooming", "capacity": 6, "status": "Scheduled",
             "slots": [{"initiative_id": 8, "rddc": "RDDC-24790", "name": "Digital Channels Observability Uplift", "priority": 3, "slot_order": 1, "status": "Proposed", "recipients": [{"id": 17, "name": "Ravi Dunmore"}]}]},
        ]

    def _post(self, method, path, body):
        self.run_id += 1
        features = {
            "/ai/exec-summary": ("exec_summary", EXEC, None), "/initiatives/9/ai/exec-summary": ("exec_summary", {**EXEC, "scope": "initiative"}, 9),
            "/initiatives/9/ai/rebalance": ("rebalance", REBALANCE, 9), "/ai/skill-matrix": ("skill_matrix", SKILLS, None),
            "/ai/nudges": ("nudges", NUDGES, None), "/ai/meeting-extract": ("meeting_extract", MEETING, None), "/ai/lessons": ("lessons", LESSONS, None),
        }
        if path in features:
            feature, out, iid = features[path]
            return 200, ai_run(feature, out, self.run_id, iid)
        if path.startswith("/ai-runs/") and path.endswith("/apply"):
            if "rebalance" in json.dumps(body) or body.get("selected") == [0]:
                self.state["fixed"] = True
            return 200, {"ai_run_id": int(path.split("/")[2]), "status": "accepted", "initiative_id": 9, "applied": {"tasks": 1}, "minutes_saved": 30, "health": health(self.state)}
        if path.startswith("/ai-runs/") and path.endswith("/reject"):
            return 200, {"ai_run_id": int(path.split("/")[2]), "status": "rejected"}
        if path == "/initiatives/9/health/override":
            if body.get("rag"):
                self.state["overrides"][body["dimension"]] = {"rag": body["rag"], "reason": body.get("reason", "")}
            else:
                self.state["overrides"].pop(body.get("dimension"), None)
            return 200, health(self.state)
        if path == "/assistant/chat":
            return 200, {"conversation_id": "c1", "answer_md": "**2 initiatives** are at risk for DC-2702:\n\n- **RDDC-24817** US API Enhancement: Sana Whitfield at 128% in Nov\n- **RDDC-24688** Online Statement Download Redesign\n\n| RDDC | RAG |\n|---|---|\n| RDDC-24817 | Amber |",
                         "citations": [{"type": "initiative", "id": "RDDC-24817", "label": "RDDC-24817", "route": "#/initiative/9/pg5"}, {"type": "allocation", "id": "14:2026-11", "label": "Sana Whitfield · Nov 2026", "route": "#/resources"}],
                         "suggested_actions": [{"label": "Open Portfolio View", "route": "#/portfolio"}], "follow_ups": ["Who has CIAM capacity in January?"],
                         "ai_run_id": self.run_id, "mode": "simulated_fixture", "mode_label": "Simulated · test-agent response"}
        if path == "/grooming/auto-slot":
            return 200, {"assignments": [{"session_id": 3, "session_date": "2026-10-22", "start_time": "10:00", "initiative_id": 7, "rddc": "RDDC-24755", "recipients": [{"id": 18, "name": "Arlo Kingsley"}]}], "unslotted": []}
        if path == "/reminders/run":
            return 200, {"created": [], "skipped": 2}
        if path.startswith("/outbox/"):
            return 200, {"id": int(path.split("/")[2]), "status": "Sent"}
        if path.startswith("/resources/") and path.endswith("/availability"):
            return 200, {"resource_id": int(path.split("/")[2]), "months": body.get("months", {})}
        self.unknown.append(f"{method} {path}")
        return 200, {"ok": True}
