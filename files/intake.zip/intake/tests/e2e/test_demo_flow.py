"""L4: the master demo script end to end on the real app (PO doc §1, master plan §6.2).

Fresh temp DB, BMO_TODAY=2026-10-19, simulated AI (Fast). Runs in three browser timezones; displayed dates
must not move. Fails on console.error / pageerror / HTTP >= 500 / failed requests (see conftest.open_page).
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest
from playwright.sync_api import TimeoutError as PwTimeout

from .helpers import (
    ARTIFACTS,
    ROOT,
    assert_clean,
    bad_text,
    no_page_overflow,
    shot,
    wait_idle,
)

SA_CANDIDATES = [
    ROOT / "data" / "uploads" / "SA_US_API_Enhancement_v1.2.docx",
    ROOT / "app" / "seed" / "files" / "SA_US_API_Enhancement_v1.2.docx",
]
RUNS = [("America/Toronto", "1366"), ("Pacific/Auckland", "1920"), ("America/Los_Angeles", "1366")]


def sa_doc() -> Path:
    for p in SA_CANDIDATES:
        if p.exists():
            return p
    pytest.fail("Sample SA document SA_US_API_Enhancement_v1.2.docx is missing")
    return SA_CANDIDATES[0]


def button(page, *names, scope=None):
    """First visible button (or link styled as one) whose accessible name matches one of `names`."""
    where = scope or page
    for name in names:
        loc = where.get_by_role("button", name=re.compile(rf"^\W*{re.escape(name)}\W*$", re.IGNORECASE))
        if loc.count() and loc.first.is_visible():
            return loc.first
    for name in names:
        loc = where.get_by_role("button", name=re.compile(re.escape(name), re.IGNORECASE))
        if loc.count():
            return loc.first
    raise AssertionError(f"no button named any of {names}")


def accept_ai(page, feature, timeout=30000, labels=("Accept", "Apply this fix")):
    """Wait for the AI Result Card of `feature`, Accept it, and wait until it is applied."""
    card = page.locator(f".ai-card[data-feature={feature}]").last
    try:
        card.locator(".ai-card-actions").wait_for(timeout=timeout)
    except Exception:
        shot(page, f"FAILED_ai_{feature}")
        raise
    assert "AI-generated — review before use" in card.inner_text()
    button(page, *labels, scope=card).click()
    page.wait_for_function(
        "(f) => !document.querySelector(`.ai-card-result[data-feature=${f}]`)", arg=feature, timeout=timeout)
    wait_idle(page)


def wait_text(page, text, timeout=20000):
    """Wait until visible page text contains `text`."""
    try:
        page.wait_for_function("(t) => document.body.innerText.includes(t)", arg=text, timeout=timeout)
    except Exception:
        shot(page, f"FAILED_wait_{re.sub(r'[^A-Za-z0-9]+', '_', text)}")
        raise


def settle_auto_ai(page, feature, timeout=30000):
    """An AI card that starts by itself (Intake Analysis after save) re-renders the page; wait until it has settled."""
    card = page.locator(f".ai-card[data-feature={feature}]")
    try:
        card.first.wait_for(timeout=3000)
    except PwTimeout:
        return
    page.wait_for_function(
        "(f) => { const c = document.querySelector(`.ai-card[data-feature=${f}]`); return !c || !c.classList.contains('ai-card-thinking'); }",
        arg=feature, timeout=timeout)
    wait_idle(page)


def set_persona(page, persona):
    page.locator("#persona-select").select_option(persona)
    page.get_by_text(f"Acting as {persona}.").first.wait_for()


def go(page, hash_):
    page.goto(f"{page.base_url}/{hash_}")
    wait_idle(page, 500)


@pytest.mark.parametrize(("tz", "viewport"), RUNS)
def test_master_demo_script(e2e_live, open_page, tz, viewport):
    e2e_live.api("POST", "/admin/reset", {})
    page = open_page(e2e_live.base_url, tz=tz, viewport=viewport)
    tag = f"{tz.replace('/', '_')}_{viewport}"

    # 1 · Portfolio View is home
    go(page, "#/")
    page.wait_for_url(re.compile(r"#/portfolio$"))
    kpis = page.locator("[data-testid=kpi-strip]")
    kpis.wait_for()
    assert "Active" in kpis.text_content() and "Over-allocated people" in kpis.text_content()
    assert page.locator("[data-testid=deck-tiles] .ch-teambars svg").count() == 1
    assert not bad_text(page), bad_text(page)
    shot(page, f"flow01_portfolio_{tag}")

    # 2-3 · Add New Initiative from DCI-3391 → save → grooming Tue 20 Oct
    page.get_by_role("link", name="Add New Initiative").click()
    page.get_by_label("DC Intake").fill("DCI-3391")
    button(page, "Look up").click()
    page.wait_for_function("() => [...document.querySelectorAll('input')].some((i) => /US API Enhancement/.test(i.value))")
    button(page, "Save").click()
    page.wait_for_url(re.compile(r"#/initiative/\d+/pg1"))
    hero_id = int(re.search(r"#/initiative/(\d+)/", page.url).group(1))
    page.get_by_text("RDDC-24817").first.wait_for()
    page.get_by_text(re.compile(r"Slotted for grooming Tue 20 Oct")).first.wait_for()
    settle_auto_ai(page, "intake_analysis")
    shot(page, f"flow02_saved_{tag}")

    # 4 · attach the sample SA document → SA Completeness 88%
    page.locator("input[type=file]").first.set_input_files(str(sa_doc()))
    page.get_by_text(re.compile(r"88%")).first.wait_for(timeout=20000)
    wait_idle(page)

    # 4b · grooming held: Pg 1 "Mark as groomed" moves Grooming → Solution (decision 4)
    groomed = button(page, "Mark as groomed")
    groomed.click()
    # explicit state, not a timer: the button goes away and the header stage reads Solution
    page.get_by_role("button", name=re.compile("Mark as groomed")).wait_for(state="detached", timeout=20000)
    page.locator(".ws-stage").filter(has_text="Solution").first.wait_for(timeout=20000)
    wait_idle(page)

    # 5 · Generate Change Summary → Accept → Estimation, L2 1,000 h
    button(page, "Generate Change Summary").click()
    accept_ai(page, "change_summary")
    wait_text(page, "1,000 h")
    assert page.locator("select option:checked", has_text="API Platform").count() + page.get_by_text("API Platform", exact=True).count() >= 1

    # 6 · Dev Lead sends L2, Requestor approves
    set_persona(page, "Dev Lead")
    button(page, "Send L2 to DLR", "Send L2 for approval").click()
    page.get_by_text("Pending approval").first.wait_for()
    wait_idle(page)
    set_persona(page, "Requestor")
    button(page, "Approve L2").click()
    page.locator(".ws-stage").filter(has_text="Planning").first.wait_for(timeout=20000)
    wait_idle(page)
    set_persona(page, "DC PM")
    shot(page, f"flow06_l2_{tag}")

    # 7-8 · Generate Project Plan → Accept → Gantt with critical path, dates unchanged by timezone
    go(page, f"#/initiative/{hero_id}/pg2")
    button(page, "Generate Project Plan").click()
    accept_ai(page, "wbs")
    gantt_btn = page.get_by_role("button", name=re.compile("Generate Gantt view"))
    if gantt_btn.count() and gantt_btn.first.is_enabled():
        gantt_btn.first.click()
    gantt = page.locator(".ch-gantt").first
    gantt.wait_for()
    assert gantt.locator(".ch-bar").count() >= 14
    assert gantt.locator(".ch-today").count() == 1
    assert gantt.locator(".ch-freeze").count() == 1
    assert "Today 19 Oct" in gantt.text_content()
    gantt.get_by_text("Show critical path").click()
    assert gantt.locator(".ch-critical-line").inner_text().startswith("Critical path: WBS-100")
    body = page.locator("body").inner_text()
    assert "17 Feb 2027" in body and "10 Feb 2027" in body and "20 Feb 2027" in body
    assert no_page_overflow(page)
    shot(page, f"flow08_gantt_{tag}")

    # 9-10 · Pg 3 health: Overall Amber, Resources Red → Suggest fix → Accept → Resources Green, Overall Amber
    go(page, f"#/initiative/{hero_id}/pg3")
    health = page.locator(".ch-health").first
    health.wait_for()
    assert "Amber" in health.locator(".ch-health-head").text_content()
    assert "Red" in health.locator("[data-dimension=resources]").text_content()
    assert "WBS-100" in health.text_content()
    button(page, "Suggest fix", scope=health).click()
    page.get_by_text(re.compile("Mateo Brennan")).first.wait_for()
    accept_ai(page, "rebalance")
    page.wait_for_function("() => { const r = document.querySelector('.ch-health [data-dimension=resources]'); return r && r.textContent.includes('Green'); }")
    assert "Amber" in page.locator(".ch-health .ch-health-head").first.text_content()
    shot(page, f"flow10_fixed_{tag}")

    # 11 · Risks tab → predict risks → Accept
    go(page, f"#/initiative/{hero_id}/risks")
    button(page, "Predict risks", "Identify Risks").click()
    accept_ai(page, "risks", labels=("Add selected to Risk Register", "Accept"))

    # 12 · Pg 4 → Create CRQ draft
    go(page, f"#/initiative/{hero_id}/pg4")
    button(page, "Create CRQ draft").click()
    review = page.get_by_role("dialog", name=re.compile("CRQ draft"))
    review.wait_for(timeout=20000)
    assert "CRQ000001052216" in review.inner_text() and "Not requested" in review.inner_text()  # decisions 1-2
    button(page, "Accept", scope=review).click()
    review.wait_for(state="detached", timeout=20000)
    page.get_by_text(re.compile(r"CRQ000001052216")).first.wait_for(timeout=20000)

    # 13 · Portfolio shows RDDC-24817
    go(page, "#/portfolio")
    dash = page.locator("[data-testid=project-dashboard]")
    dash.get_by_text("RDDC-24817").wait_for()
    assert "Planning" in dash.locator("tr", has_text="RDDC-24817").inner_text()
    assert not bad_text(page), bad_text(page)
    shot(page, f"flow13_portfolio_{tag}")

    # 14 · Assistant answers with real RDDC citations, rendered (no raw markdown)
    button(page, "Ask Assistant").click()
    page.locator(".dv-drawer textarea").fill("Which initiatives are at risk for the Feb release and why?")
    button(page, "Ask", scope=page.locator(".dv-drawer")).click()
    answer = page.locator("[data-testid=assistant-answer]").last
    page.wait_for_function("() => { const a = [...document.querySelectorAll('[data-testid=assistant-answer]')].pop(); return a && !a.querySelector('.dv-caret') && /RDDC-\\d{5}/.test(a.innerText); }", timeout=25000)
    text = answer.inner_text()
    cited = set(re.findall(r"RDDC-\d{5}", text))
    known = {i["rddc"] for i in e2e_live.api("GET", "/initiatives")["items"]}
    assert cited and cited <= known, f"assistant cited unknown RDDC numbers: {cited - known}"
    assert "**" not in text
    shot(page, f"flow14_assistant_{tag}")
    page.get_by_role("button", name="Close assistant").click()

    # 15 · exports download and open with openpyxl
    import openpyxl

    go(page, "#/portfolio")
    for testid in ("export-portfolio", "export-demo-view"):
        with page.expect_download() as dl:
            if testid == "export-demo-view":
                page.locator("[data-testid=export-demo-view]").click()
                dialog = page.get_by_role("dialog", name="Initiative Demo View workbook")
                assert "RDDC-24817" in dialog.locator("select option:checked").inner_text()
                dialog.locator("[data-testid=export-demo-view-download]").click()
            else:
                page.locator(f"[data-testid={testid}]").click()
        target = ARTIFACTS / f"{testid}_{tag}.xlsx"
        ARTIFACTS.mkdir(parents=True, exist_ok=True)
        dl.value.save_as(str(target))
        wb = openpyxl.load_workbook(target)
        assert wb.sheetnames, f"{testid} has no sheets"
    with page.expect_download() as dl:
        page.goto(f"{page.base_url}/#/initiative/{hero_id}/pg1")
        wait_idle(page)
        page.get_by_role("link", name=re.compile(r"Export to Excel|Demo View workbook")).first.click()
    hero_xlsx = ARTIFACTS / f"hero_demo_view_{tag}.xlsx"
    dl.value.save_as(str(hero_xlsx))
    assert openpyxl.load_workbook(hero_xlsx).sheetnames

    # reset → hero gone
    go(page, "#/settings")
    button(page, "Reset demo data").click()
    button(page, "Reset demo data", scope=page.locator(".modal")).click()
    page.wait_for_timeout(1500)
    rddcs = {i["rddc"] for i in e2e_live.api("GET", "/initiatives")["items"]}
    assert "RDDC-24817" not in rddcs
    assert_clean(page, f"demo flow {tag}")
