"""People and funding entered once in intake remain usable across the portal."""
from __future__ import annotations

import io
import json

import pytest
from docx import Document
from playwright.sync_api import expect

from .helpers import assert_clean, no_page_overflow
from .test_portal_intake import PortalApp


@pytest.fixture
def portal():
    app = PortalApp()
    try:
        app.start()
        yield app
    finally:
        app.stop()


def _new_intake(page, portal, name, requestor):
    page.goto(f"{portal.base_url}/#/initiative/new")
    expect(page.get_by_role("heading", name="Add initiative", exact=True)).to_be_visible()
    page.get_by_label("Project name", exact=True).fill(name)
    page.get_by_label("Line of business", exact=True).select_option("Canadian P&C")
    page.get_by_label("Requestor name", exact=True).fill(requestor)
    page.get_by_text("People and funding", exact=True).click()


def _create(page):
    page.get_by_role("button", name="Create initiative", exact=True).click()
    page.wait_for_url("**/#/initiative/*/pg1")


def _people_by_name(portal):
    return {person["name"]: person for person in portal.api("GET", "/resources")["items"]}


def _assert_no_invented_capacity(portal):
    people = portal.api("GET", "/resources")["items"]
    assert all(person["default_monthly_hours"] == 0 for person in people)
    assert all(not person["hourly_rate"] for person in people)
    assert portal.api("GET", "/allocations")["total"] == 0


def _save_import(page):
    page.get_by_role("button", name="Save selected records", exact=True).click()
    expect(page.get_by_text("Import saved", exact=True)).to_be_visible()


def test_manual_intakes_reuse_people_and_shared_funding_then_edit(portal, open_page):
    page = open_page(portal.base_url)
    code = "PRN-INTAKE-001"
    _new_intake(page, portal, "Intake connections first", "Intake Requestor")
    page.get_by_label("DC project manager", exact=True).fill("Jamie Porter")
    page.get_by_label("Solution architect", exact=True).fill("Morgan Architect")
    page.get_by_label("Business analyst", exact=True).fill("Avery Analyst")
    page.get_by_label("Funding / PRN", exact=True).fill(code)
    assert no_page_overflow(page)
    _create(page)

    first = portal.api("GET", "/initiatives/1")["initiative"]
    people = _people_by_name(portal)
    assert set(people) == {"Intake Requestor", "Jamie Porter", "Morgan Architect", "Avery Analyst"}
    assert first["requestor_id"] == people["Intake Requestor"]["id"]
    assert first["dc_pm_id"] == people["Jamie Porter"]["id"]
    assert first["dc_sa_id"] == people["Morgan Architect"]["id"]
    assert first["prn_code"] == code
    budget = portal.api("GET", f"/funding/{code}")
    assert budget["funded_hours"] == budget["rate"] == budget["budget_amount"] == 0
    assert budget["decision"] == "Pending"
    _assert_no_invented_capacity(portal)

    # A different intake can reuse roster and budget records without matching exact spelling.
    _new_intake(page, portal, "Intake connections second", "intake   requestor")
    page.get_by_label("DC project manager", exact=True).fill("  JAMIE    PORTER  ")
    page.get_by_label("Solution architect", exact=True).fill("morgan architect")
    page.get_by_label("Business analyst", exact=True).fill("avery analyst")
    page.get_by_label("Funding / PRN", exact=True).fill(code.lower())
    _create(page)
    second = portal.api("GET", "/initiatives/2")["initiative"]
    assert portal.api("GET", "/resources")["total"] == 4
    assert portal.api("GET", "/funding")["total"] == 1
    assert (second["requestor_id"], second["dc_pm_id"], second["dc_sa_id"]) == (
        first["requestor_id"], first["dc_pm_id"], first["dc_sa_id"])

    # Pg 1 uses the same people/funding path when completing an existing intake.
    page.get_by_label("tech_lead_id", exact=True).fill("Taylor Integration")
    page.get_by_text("Funding details (optional)", exact=True).click()
    page.get_by_label("Budget name", exact=True).fill("Intake shared funding")
    page.get_by_label("Budget owner", exact=True).fill("jamie porter")
    page.get_by_label("Funded hours", exact=True).fill("200")
    page.get_by_label("Blended hourly rate", exact=True).fill("110")
    page.get_by_label("Budget amount", exact=True).fill("24000")
    page.get_by_label("Funding decision", exact=True).select_option("Approved")
    page.get_by_label("Update this shared funding record", exact=True).check()
    with page.expect_response(lambda response: response.request.method == "PUT" and response.url.endswith("/api/initiatives/2")) as response:
        page.get_by_role("button", name="Save Pg 1", exact=True).click()
    assert response.value.ok
    updated = portal.api("GET", "/initiatives/2")["initiative"]
    people = _people_by_name(portal)
    assert len(people) == 5
    assert updated["tech_lead_id"] == people["Taylor Integration"]["id"]
    assert updated["dc_pm_id"] == first["dc_pm_id"]
    budget = portal.api("GET", f"/funding/{code}")
    assert budget["owner_id"] == first["dc_pm_id"]
    assert (budget["funded_hours"], budget["rate"], budget["budget_amount"]) == (200, 110, 24000)
    assert budget["decision"] == "Approved"
    assert {initiative["id"] for initiative in budget["initiatives"]} == {1, 2}
    _assert_no_invented_capacity(portal)

    page.goto(f"{portal.base_url}/#/resources")
    page.get_by_role("tab", name="People & skills", exact=True).click()
    expect(page.get_by_role("table", name="People and skills", exact=True).get_by_text("Taylor Integration", exact=True)).to_be_visible()
    page.get_by_role("button", name="Allocate hours", exact=True).click()
    person = page.get_by_role("dialog").get_by_label("Person", exact=False)
    person.select_option(str(people["Taylor Integration"]["id"]))
    expect(person).to_have_value(str(people["Taylor Integration"]["id"]))
    page.get_by_role("dialog").get_by_role("button", name="Cancel", exact=True).click()
    page.goto(f"{portal.base_url}/#/funding")
    expect(page.get_by_role("button", name=code, exact=True)).to_be_visible()
    page.get_by_role("button", name=code, exact=True).click()
    expect(page.get_by_role("heading", name=f"{code} · Intake shared funding", exact=True)).to_be_visible()
    expect(page.get_by_role("link", name=f"{first['rddc']} · {first['name']}", exact=True)).to_be_visible()
    assert no_page_overflow(page)
    assert_clean(page)


def test_word_intake_names_and_funding_are_reviewed_before_roster_changes(portal, open_page):
    document = Document()
    for line in ["Project name: Connected Word intake", "LOB: Canadian P&C", "Requestor: Word Requestor",
                 "DC PM: Word Manager", "Solution architect: Word Architect", "Technical lead: Word Engineer",
                 "Business analyst: Word Analyst", "PRN code: PRN-WORD-010", "Funding owner: Word Manager",
                 "Funded hours: 160", "Hourly rate: 125", "Budget amount: 21000", "Currency: CAD"]:
        document.add_paragraph(line)
    buffer = io.BytesIO()
    document.save(buffer)
    page = open_page(portal.base_url)
    page.goto(f"{portal.base_url}/#/imports?source=document")
    page.get_by_label("Choose workbook or document").set_input_files({
        "name": "Connected-SA.docx", "mimeType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "buffer": buffer.getvalue()})
    page.get_by_role("button", name="Read file", exact=True).click()
    expect(page.get_by_role("heading", name="Review record 1 of 1")).to_be_visible()
    assert portal.api("GET", "/resources")["total"] == 0
    assert portal.api("GET", "/funding")["total"] == 0
    assert portal.api("GET", "/initiatives")["total"] == 0
    expect(page.get_by_label("DC project manager", exact=True)).to_have_value("Word Manager")
    expect(page.get_by_label("Solution architect", exact=True)).to_have_value("Word Architect")
    expect(page.get_by_label("Funding hourly rate", exact=True)).to_have_value("125")
    page.get_by_label("DC project manager", exact=True).fill("Reviewed Word Manager")
    page.get_by_label("Funding owner", exact=True).fill("Reviewed Word Manager")
    page.get_by_label("Budget amount", exact=True).fill("22100")
    _save_import(page)
    initiative = portal.api("GET", "/initiatives/1")["initiative"]
    people = _people_by_name(portal)
    assert set(people) == {"Word Requestor", "Reviewed Word Manager", "Word Architect", "Word Engineer", "Word Analyst"}
    assert initiative["dc_pm_id"] == people["Reviewed Word Manager"]["id"]
    assert initiative["dc_sa_id"] == people["Word Architect"]["id"]
    assert initiative["tech_lead_id"] == people["Word Engineer"]["id"]
    budget = portal.api("GET", "/funding/PRN-WORD-010")
    assert budget["owner_id"] == people["Reviewed Word Manager"]["id"]
    assert (budget["funded_hours"], budget["rate"], budget["budget_amount"]) == (160, 125, 22100)
    assert budget["decision"] == "Pending"
    assert budget["initiatives"][0]["id"] == initiative["id"]
    _assert_no_invented_capacity(portal)
    assert_clean(page)


def test_jira_json_named_people_and_budget_commit_together(portal, open_page):
    page = open_page(portal.base_url)
    page.goto(f"{portal.base_url}/#/experimental")
    page.get_by_label("Integration lab password").fill("test-only-lab-password-2026")
    page.get_by_role("button", name="Create lab password", exact=True).click()
    expect(page.get_by_text("Signed in", exact=True)).to_be_visible()
    payload = {"key": "BIDC-92001", "fields": {
        "summary": "Connected Jira intake", "reporter": {"displayName": "Jira Requestor"},
        "assignee": {"displayName": "Jira Manager"}, "customfield_101": "US P&C",
        "customfield_102": {"displayName": "Jira Manager"}, "customfield_103": {"displayName": "Jira Architect"},
        "customfield_104": "PRN-JIRA-020", "customfield_105": 120, "customfield_106": 100,
        "customfield_107": 15000, "customfield_108": {"displayName": "Jira Manager"}},
        "names": {"customfield_101": "LOB", "customfield_102": "DC PM", "customfield_103": "Solution architect",
                  "customfield_104": "Funding code", "customfield_105": "Funded hours", "customfield_106": "Hourly rate",
                  "customfield_107": "Budget amount", "customfield_108": "Funding owner"}}
    page.get_by_label("Jira JSON", exact=True).fill(json.dumps(payload))
    page.get_by_role("button", name="Preview JSON intake", exact=True).click()
    page.wait_for_url("**/#/imports?batch=*")
    expect(page.get_by_role("heading", name="Review record 1 of 1")).to_be_visible()
    expect(page.get_by_label("DC project manager", exact=True)).to_have_value("Jira Manager")
    expect(page.get_by_label("Solution architect", exact=True)).to_have_value("Jira Architect")
    expect(page.get_by_label("Budget amount", exact=True)).to_have_value("15000")
    assert portal.api("GET", "/resources")["total"] == 0
    assert portal.api("GET", "/funding")["total"] == 0
    page.get_by_role("button", name="Validate changes", exact=True).click()
    expect(page.get_by_text("Validation refreshed. Review warnings before saving.", exact=True)).to_be_visible()
    assert portal.api("GET", "/resources")["total"] == 0
    assert portal.api("GET", "/funding")["total"] == 0
    _save_import(page)
    initiative = portal.api("GET", "/initiatives/1")["initiative"]
    people = _people_by_name(portal)
    assert set(people) == {"Jira Requestor", "Jira Manager", "Jira Architect"}
    assert initiative["dc_pm_id"] == initiative["assigned_to_id"] == people["Jira Manager"]["id"]
    assert initiative["dc_sa_id"] == people["Jira Architect"]["id"]
    budget = portal.api("GET", "/funding/PRN-JIRA-020")
    assert (budget["funded_hours"], budget["rate"], budget["budget_amount"]) == (120, 100, 15000)
    assert budget["owner_id"] == people["Jira Manager"]["id"]
    assert budget["decision"] == "Pending"
    _assert_no_invented_capacity(portal)
    assert_clean(page)
