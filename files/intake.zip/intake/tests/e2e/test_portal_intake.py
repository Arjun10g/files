"""Real browser regressions for the empty operational portal (no demo seed)."""
from __future__ import annotations

import io
import json
import subprocess

import pytest
from docx import Document
from openpyxl import Workbook
from playwright.sync_api import expect

from .conftest import PYTHON, ROOT, LiveApp
from .helpers import assert_clean


class PortalApp(LiveApp):
    def reset(self):
        subprocess.run([PYTHON, "-m", "app.cli", "init-if-missing"], cwd=ROOT, env=self.env,
                       check=True, capture_output=True, timeout=30)


@pytest.fixture
def portal():
    app = PortalApp()
    app.start()
    yield app
    app.stop()


def test_empty_portal_manual_and_jira_workbook(portal, open_page):
    page = open_page(portal.base_url)
    page.goto(f"{portal.base_url}/#/portfolio")
    expect(page.get_by_role("heading", name="Your delivery workspace is ready")).to_be_visible()
    assert portal.api("GET", "/initiatives")["total"] == 0
    assert portal.api("GET", "/resources")["total"] == 0
    page.get_by_role("link", name="01 · Add an initiative").click()
    page.get_by_label("Project name", exact=True).fill("Browser manual request")
    page.get_by_label("Line of business", exact=True).select_option("Canadian P&C")
    page.get_by_label("Requestor name", exact=True).fill("Portal Requestor")
    page.get_by_label("Platform", exact=True).select_option("BBX")
    page.get_by_label("APT number", exact=True).fill("APT-100")
    page.get_by_role("button", name="Create initiative", exact=True).click()
    page.wait_for_url("**/#/initiative/*/pg1")
    expect(page.get_by_role("heading", name="Browser manual request", exact=True)).to_be_visible()
    initiative = portal.api("GET", "/initiatives/1")["initiative"]
    assert initiative["requestor"] == "Portal Requestor"
    assert initiative["platform"] == "BBX"
    assert initiative["apt_number"] == "APT-100"

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "BMO Enterprise Jira"
    sheet.append(["Summary", "Issue key", "Status", "Reporter", "Priority", "Custom field (LOB)", "Labels", "Labels"])
    sheet.append(["Browser Excel request", "BIDC-90001", "On Hold", "Excel Reporter", "High", "US P&C", "api", "delivery"])
    buffer = io.BytesIO()
    workbook.save(buffer)
    page.goto(f"{portal.base_url}/#/imports")
    page.get_by_label("Choose workbook or document").set_input_files({
        "name": "Jira.xlsx", "mimeType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "buffer": buffer.getvalue()})
    page.get_by_role("button", name="Read file", exact=True).click()
    expect(page.get_by_role("heading", name="Review record 1 of 1")).to_be_visible()
    assert page.get_by_label("Jira key", exact=True).input_value() == "BIDC-90001"
    assert portal.api("GET", "/initiatives")["total"] == 1  # preview has no domain writes
    page.get_by_label("Project name", exact=True).fill("Reviewed Excel request")
    page.get_by_role("button", name="Save selected records", exact=True).click()
    expect(page.get_by_text("Import saved", exact=True)).to_be_visible()
    imported = portal.api("GET", "/initiatives/2")["initiative"]
    assert imported["name"] == "Reviewed Excel request"
    assert imported["jira_status"] == "On Hold"
    assert imported["priority"] == 2
    assert set(imported["labels"]) == {"api", "delivery"}
    assert_clean(page)


def test_word_review_full_text_and_explicit_components(portal, open_page):
    document = Document()
    for line in ["Project name: Browser Word request", "LOB: Canadian P&C", "Requestor: Word Reporter",
                 "Priority: P2", "Business context", "Expose an account service safely.", "Scope",
                 "APIP API Platform changes are explicitly in scope."]:
        document.add_paragraph(line)
    table = document.add_table(rows=1, cols=2)
    table.cell(0, 0).text = "Expected TPS"
    table.cell(0, 1).text = "350"
    document.add_paragraph("Final document sentence retained after tables.")
    buffer = io.BytesIO()
    document.save(buffer)
    page = open_page(portal.base_url)
    page.goto(f"{portal.base_url}/#/imports?source=document")
    page.get_by_label("Choose workbook or document").set_input_files({
        "name": "SA.docx", "mimeType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "buffer": buffer.getvalue()})
    page.get_by_role("button", name="Read file", exact=True).click()
    expect(page.get_by_role("heading", name="Review record 1 of 1")).to_be_visible()
    page.get_by_text("Read the full extracted document", exact=True).click()
    expect(page.locator("pre").filter(has_text="Final document sentence retained after tables.")).to_be_visible()
    components = page.locator(".import-component input")
    assert components.count() >= 1
    assert not components.first.is_checked()
    components.first.check()
    page.get_by_role("button", name="Save selected records", exact=True).click()
    expect(page.get_by_text("Import saved", exact=True)).to_be_visible()
    bundle = portal.api("GET", "/initiatives/1")
    assert "Expected TPS | 350" in bundle["sa_doc_text"]
    assert len(bundle["attachments"]) == 1
    assert bundle["components"][0]["code"] == "APIP"
    assert bundle["components"][0]["approval"] == "Pending"
    assert_clean(page)


def test_authenticated_jira_json_review(portal, open_page):
    page = open_page(portal.base_url)
    page.goto(f"{portal.base_url}/#/experimental")
    page.get_by_label("Integration lab password").fill("test-only-lab-password-2026")
    page.get_by_role("button", name="Create lab password", exact=True).click()
    expect(page.get_by_text("Signed in", exact=True)).to_be_visible()
    payload = {"key": "BIDC-90002", "fields": {"summary": "Authenticated JSON request",
               "reporter": {"displayName": "JSON Reporter"}, "customfield_10000": "Canadian P&C",
               "description": {"type": "doc", "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Read rich text"}]}]}},
               "names": {"customfield_10000": "LOB"}}
    page.get_by_label("Jira JSON", exact=True).fill(json.dumps(payload))
    page.get_by_role("button", name="Preview JSON intake", exact=True).click()
    page.wait_for_url("**/#/imports?batch=*")
    expect(page.get_by_role("heading", name="Review record 1 of 1")).to_be_visible()
    assert page.get_by_label("Project name", exact=True).input_value() == "Authenticated JSON request"
    assert portal.api("GET", "/initiatives")["total"] == 0
    page.get_by_role("button", name="Save selected records", exact=True).click()
    expect(page.get_by_text("Import saved", exact=True)).to_be_visible()
    assert portal.api("GET", "/initiatives/1")["initiative"]["description"] == "Read rich text"
    page.goto(f"{portal.base_url}/#/experimental")
    page.get_by_role("button", name="Sign out", exact=True).click()
    expect(page.get_by_role("button", name="Sign in", exact=True)).to_be_visible()
    assert_clean(page)


def test_funding_confirmation_text_review(portal, open_page):
    page = open_page(portal.base_url)
    page.goto(f"{portal.base_url}/#/imports?type=funding")
    page.get_by_label("Document text").fill(
        "PR Code: FUND-900\nProject name: Browser funding confirmation\nFunded hours: 200\n"
        "Hourly rate: 100\nCurrency: CAD\nDecision: Approved\nTeam: EAPI\nAppCat: AC-900\n"
        "Planning: 20 hours @ $100\nDevelopment: 50 hours @ $100\nSupport: 10 hours @ $100\n")
    page.get_by_role("button", name="Read pasted text", exact=True).click()
    expect(page.get_by_role("heading", name="Review record 1 of 3")).to_be_visible()
    assert portal.api("GET", "/funding")["total"] == 0
    page.get_by_role("button", name="Save selected records", exact=True).click()
    expect(page.get_by_text("Import saved", exact=True)).to_be_visible()
    budget = portal.api("GET", "/funding/FUND-900")
    assert budget["funded_hours"] == 200
    assert budget["totals"]["estimated_hours"] == 80
    assert len(budget["estimates"]) == 3
    assert {line["phase"] for line in budget["estimates"]} == {"Planning", "Development", "Support"}
    page.get_by_role("button", name="Open funding", exact=True).click()
    expect(page.get_by_role("heading", name="Funding", exact=True)).to_be_visible()
    assert_clean(page)
