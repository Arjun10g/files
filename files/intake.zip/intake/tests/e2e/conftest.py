"""Playwright fixtures for the browser tests (L4).

* `e2e_live`  starts the real app on a free port with a fresh temp DB (BMO_DB_PATH), resets it, and pins
  BMO_TODAY=2026-10-19, simulated AI and the Fast thinking speed. Skips while the backend is incomplete.
* `e2e_static` serves static/ only; `mock_api.MockApi` answers /api/* (contract-shaped) for the UI harness.
* `open_page(base_url, tz=..., viewport=...)` opens a page that records console errors, page errors,
  responses >= 500 and failed requests; `assert_clean(page)` fails the test on any of them.
"""
from __future__ import annotations

import contextlib
import http.server
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path

import pytest

from .helpers import DEMO_TODAY, ROOT, VIEWPORTS

PYTHON = str(ROOT / ".venv" / "bin" / "python") if (ROOT / ".venv" / "bin" / "python").exists() else sys.executable

try:
    from playwright.sync_api import sync_playwright
except ImportError:  # pragma: no cover
    sync_playwright = None


def free_port() -> int:
    with contextlib.closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def wait_http(url: str, timeout: float = 30.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                if r.status < 500:
                    return True
        except (OSError, ValueError):
            time.sleep(0.25)
    return False


def backend_missing() -> str | None:
    """Reason the full app cannot run yet, or None when every backend module is present."""
    needed = ["app/cli.py", "app/api/core.py", "app/api/initiatives.py", "app/api/plan.py", "app/api/views.py", "app/api/ai.py"]
    missing = [p for p in needed if not (ROOT / p).exists()]
    return f"backend not complete yet: missing {', '.join(missing)}" if missing else None


# ------------------------------------------------------------------ servers
class LiveApp:
    def __init__(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="bmo-e2e-"))
        self.port = free_port()
        self.base_url = f"http://127.0.0.1:{self.port}"
        self.env = {
            **os.environ,
            "BMO_DB_PATH": str(self.tmp / "bmo_e2e.db"),
            "BMO_UPLOAD_DIR": str(self.tmp / "uploads"),
            "BMO_TODAY": DEMO_TODAY,
            "BMO_PORT": str(self.port),
            "BMO_AI_MODE": "simulated",
            "BMO_AI_SPEED": "Fast",
            "BMO_SIM_LATENCY": "0",
            "PYTHONUNBUFFERED": "1",
        }
        self.env.pop("ANTHROPIC_API_KEY", None)
        self.proc = None
        self.log = self.tmp / "server.log"

    def reset(self):
        subprocess.run([PYTHON, "-m", "app.cli", "reset"], cwd=ROOT, env=self.env, check=True, capture_output=True, timeout=120)

    def start(self):
        self.reset()
        code = ("from app import create_app; app = create_app(); "
                f"app.run(host='127.0.0.1', port={self.port}, debug=False, use_reloader=False, threaded=True)")
        self.proc = subprocess.Popen([PYTHON, "-c", code], cwd=ROOT, env=self.env, stdout=self.log.open("w"), stderr=subprocess.STDOUT)
        if not wait_http(f"{self.base_url}/api/health", 40):
            self.stop()
            raise RuntimeError(f"app did not start; see {self.log}")

    def api(self, method: str, path: str, body: dict | None = None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(f"{self.base_url}/api{path}", data=data, method=method, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read() or b"null")

    def stop(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(10)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        shutil.rmtree(self.tmp, ignore_errors=True)


@pytest.fixture(scope="module")
def e2e_live():
    reason = backend_missing()
    if reason:
        pytest.skip(reason)
    app = LiveApp()
    app.start()
    yield app
    app.stop()


class _StaticHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def do_GET(self):
        if self.path in ("/", "/index.html") or self.path.startswith("/?"):
            self.path = "/static/index.html"
        return super().do_GET()

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(self, *args):
        return


@pytest.fixture(scope="session")
def e2e_static():
    port = free_port()
    server = http.server.ThreadingHTTPServer(("127.0.0.1", port), _StaticHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


# ------------------------------------------------------------------ browser
@pytest.fixture(scope="session")
def pw_browser():
    if sync_playwright is None:
        pytest.skip("playwright is not installed")
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=os.environ.get("BMO_HEADED") != "1")
        yield browser
        browser.close()


@pytest.fixture
def open_page(pw_browser):
    contexts = []

    def _open(base_url: str, tz: str = "America/Toronto", viewport: str = "1366"):
        context = pw_browser.new_context(timezone_id=tz, viewport=VIEWPORTS[viewport], accept_downloads=True, locale="en-CA")
        contexts.append(context)
        page = context.new_page()
        page.errors = []

        def on_console(msg):
            if msg.type == "error":
                page.errors.append(f"console.error: {msg.text}")

        def on_response(resp):
            if resp.status >= 500:
                page.errors.append(f"HTTP {resp.status}: {resp.request.method} {resp.url}")

        def on_failed(req):
            failure = req.failure or ""
            if "ERR_ABORTED" in failure and ("/export/" in req.url or "/download" in req.url):
                return
            page.errors.append(f"request failed: {req.method} {req.url} {failure}")

        page.on("console", on_console)
        page.on("pageerror", lambda exc: page.errors.append(f"pageerror: {exc}"))
        page.on("response", on_response)
        page.on("requestfailed", on_failed)
        page.on("dialog", lambda d: (page.errors.append(f"unexpected dialog: {d.message}"), d.dismiss()))
        page.set_default_timeout(15000)
        page.base_url = base_url
        return page

    yield _open
    for c in contexts:
        c.close()


_E2E_DIR = Path(__file__).resolve().parent


def pytest_collection_modifyitems(config, items):
    """Every test in tests/e2e is a browser test: mark it `e2e` so `-m "not e2e"` skips the whole package."""
    for item in items:
        if _E2E_DIR in Path(str(item.fspath)).resolve().parents:
            item.add_marker(pytest.mark.e2e)
