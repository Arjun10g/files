"""Shared helpers for the browser tests (imported by conftest and the test modules)."""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ARTIFACTS = Path(__file__).resolve().parent / "artifacts"
DEMO_TODAY = "2026-10-19"
TIMEZONES = ["America/Toronto", "Pacific/Auckland", "America/Los_Angeles"]
VIEWPORTS = {"1366": {"width": 1366, "height": 768}, "1920": {"width": 1920, "height": 1080}}
BAD_TEXT = re.compile(r"\b(undefined|NaN|null)\b|\[object Object\]")


def assert_clean(page, where: str = ""):
    errors = list(getattr(page, "errors", []))
    assert not errors, f"{where}: browser errors:\n" + "\n".join(errors)


def bad_text(page) -> list[str]:
    """Visible text nodes that read undefined / NaN / null."""
    texts = page.evaluate(
        """() => {
          const out = [];
          const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
          while (w.nextNode()) {
            const n = w.currentNode; const el = n.parentElement;
            if (!el || el.closest('script,style,textarea,noscript')) continue;
            const s = getComputedStyle(el);
            if (s.display === 'none' || s.visibility === 'hidden') continue;
            const t = n.nodeValue.trim(); if (t) out.push(t);
          }
          document.querySelectorAll('input:not([type=hidden]),textarea,select').forEach((i) => { if (i.value) out.push(i.value); });
          return out;
        }"""
    )
    return [t for t in texts if BAD_TEXT.search(t)]


def shot(page, name: str):
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    page.screenshot(path=str(ARTIFACTS / f"{name}.png"), full_page=True)


def no_page_overflow(page) -> bool:
    return page.evaluate("() => document.documentElement.scrollWidth <= document.documentElement.clientWidth + 1")


def wait_idle(page, ms: int = 250):
    page.wait_for_load_state("networkidle")
    page.wait_for_timeout(ms)
