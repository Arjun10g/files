"""UI harness: the real shell + B5 dashboards against a contract-shaped mock API (no backend needed).

Runs at L1 for B5 and keeps working after integration: it pins chart rendering, empty-state handling,
timezone-stable dates, page overflow and the absence of undefined/NaN/null text.
"""
from __future__ import annotations

import json

import pytest

from .helpers import (
    TIMEZONES,
    assert_clean,
    bad_text,
    no_page_overflow,
    shot,
    wait_idle,
)
from .mock_api import MockApi

ROUTES = ["#/portfolio", "#/intake", "#/resources", "#/risks", "#/changes", "#/artifacts", "#/outbox", "#/ai-activity"]


def mocked(open_page, base, tz="America/Toronto", viewport="1366"):
    page = open_page(base, tz=tz, viewport=viewport)
    api = MockApi()

    def handler(route, request):
        body = None
        if request.post_data:
            try:
                body = json.loads(request.post_data)
            except ValueError:
                body = None
        status, payload = api.handle(request.method, request.url, body)
        route.fulfill(status=status, content_type="application/json", body=json.dumps(payload))

    page.route("**/api/**", handler)
    page.mock = api
    return page


def goto(page, hash_):
    page.goto(f"{page.base_url}/{hash_}")
    page.wait_for_selector(".dv-page", timeout=15000)
    wait_idle(page, 400)


@pytest.mark.parametrize("viewport", ["1366", "1920"])
def test_every_b5_route_renders(open_page, e2e_static, viewport):
    page = mocked(open_page, e2e_static, viewport=viewport)
    for route in ROUTES:
        goto(page, route)
        assert page.locator(".error-panel").count() == 0, f"{route} shows an error panel"
        assert not bad_text(page), f"{route}: {bad_text(page)}"
        assert no_page_overflow(page), f"{route} overflows horizontally at {viewport}"
        shot(page, f"mock_{route.strip('#/').replace('/', '_')}_{viewport}")
    assert_clean(page, "routes")


def test_portfolio_tiles_and_tables(open_page, e2e_static):
    page = mocked(open_page, e2e_static)
    goto(page, "#/portfolio")
    kpis = page.locator("[data-testid=kpi-strip]").inner_text()
    for label in ("Active", "Red", "Amber", "CRQs this week", "Over-allocated people"):
        assert label.lower() in kpis.lower()
    tiles = page.locator("[data-testid=deck-tiles]")
    assert tiles.locator(".ch-health").count() == 1
    assert tiles.locator(".ch-teambars svg").count() == 1
    for team in ("EAPI (Dev1)", "EAPI (Dev2)", "CIAM", "SRE"):
        assert tiles.locator(".ch-teambars").get_by_text(team, exact=True).count() >= 1
    assert tiles.locator(".ch-pgantt .ch-bar").count() == 5
    rows = page.locator("[data-testid=project-dashboard] tbody tr")
    assert rows.count() == 9
    tile = page.locator("[data-testid=deck-tiles] .ch-health")
    assert tile.locator(".dv-rag-lg, .pill-lg").count() == 0, "portfolio tile must not show one overall pill"
    assert "Worst: Red" in tile.inner_text()
    assert "SA capacity constraint affecting WBS-100" in tile.inner_text()
    page.locator("[data-kpi=red]").click()
    assert page.locator("[data-testid=project-dashboard] tbody tr").count() == 1
    page.locator("[data-kpi=active]").click()
    assert page.locator("[data-testid=project-dashboard] tbody tr").count() == 9
    assert page.locator("[data-testid=project-dashboard]").get_by_text("RDDC-24817").count() == 1
    page.get_by_label("RAG", exact=True).select_option("Red")
    assert page.locator("[data-testid=project-dashboard] tbody tr").count() == 1
    assert page.locator(".ch-heatmap .ch-cell.h-over").count() >= 1
    # the hero PRN has no charges yet, so the picker opens on the PRN with spend (a real burndown)
    assert page.locator(".ch-burndown .ch-statrow").inner_text().startswith("PRN-71840")
    assert "Overrun risk" in page.locator(".ch-burndown").inner_text()
    page.get_by_role("button", name="Write Executive Summary").click()
    page.get_by_text("AI-generated — review before use").wait_for()
    page.get_by_role("button", name="Accept").click()
    page.get_by_text("Executive summary saved to Artifacts → Meeting Notes.").first.wait_for()
    page.locator("[data-testid=export-demo-view]").click()
    dialog = page.get_by_role("dialog", name="Initiative Demo View workbook")
    assert "RDDC-24817" in dialog.locator("select option:checked").inner_text()
    assert "initiative_id=9" in dialog.locator("[data-testid=export-demo-view-download]").get_attribute("href")
    dialog.get_by_role("button", name="Close").first.click()
    assert_clean(page, "portfolio")


@pytest.mark.parametrize("tz", TIMEZONES)
def test_pg5_health_gantt_and_fix(open_page, e2e_static, tz):
    page = mocked(open_page, e2e_static, tz=tz)
    goto(page, "#/initiative/9/pg5")
    health = page.locator(".ch-health")
    assert "Amber" in health.locator(".ch-health-head").text_content()
    assert "Red" in health.locator("[data-dimension=resources]").inner_text()
    assert "SA capacity constraint affecting WBS-100" in health.inner_text()
    gantt = page.locator(".ch-gantt").first
    labels = [x.strip() for x in gantt.locator(".ch-label").all_text_contents()]
    assert labels == ["Estimation", "Development", "QA", "Production"]
    assert "Today 19 Oct" in gantt.text_content()
    assert "17 Feb 2027" in page.locator(".dv-kv").inner_text()
    page.get_by_role("button", name="Suggest fix").click()
    page.get_by_text("Move WBS-100 from Sana Whitfield to Mateo Brennan").first.wait_for()
    page.get_by_role("button", name="Accept").click()
    page.wait_for_function("() => document.querySelector('[data-dimension=resources]').innerText.includes('Green')")
    assert "Amber" in page.locator(".ch-health .ch-health-head").inner_text()
    shot(page, f"mock_pg5_{tz.replace('/', '_')}")
    assert_clean(page, f"pg5 {tz}")


def test_health_override_requires_reason(open_page, e2e_static):
    page = mocked(open_page, e2e_static)
    goto(page, "#/initiative/9/pg5")
    page.locator("[data-dimension=schedule] .ch-pill-btn").click()
    page.get_by_label("Status").select_option("Green")
    page.get_by_role("button", name="Save override").click()
    page.get_by_text("Enter a reason for the override.").wait_for()
    page.get_by_label("Reason").fill("Release train moved by agreement with the STO")
    page.get_by_role("button", name="Save override").click()
    page.locator("[data-dimension=schedule]").get_by_text("Overridden").wait_for()
    assert_clean(page, "override")


def test_full_gantt_toolbar(open_page, e2e_static):
    """The full Gantt (scale, colour, critical path, deps, milestone, freeze, trains) on a scratch host."""
    page = mocked(open_page, e2e_static, viewport="1920")
    goto(page, "#/portfolio")
    page.evaluate(
        """async () => {
          const [{ renderGantt }, api] = await Promise.all([import('/static/js/charts/gantt.js'), import('/static/js/api.js')]);
          const host = document.createElement('div'); host.id = 'gantt-scratch'; host.style.width = '1200px';
          document.querySelector('.dv-page').prepend(host);
          renderGantt(host, await api.getGantt(9), {});
        }"""
    )
    host = page.locator("#gantt-scratch")
    assert host.locator(".ch-bar").count() == 14
    assert host.locator(".ch-dep").count() >= 14
    assert host.locator(".ch-milestone").count() == 1
    assert host.locator(".ch-freeze").count() == 1
    assert host.get_by_text("DC-2702").count() >= 1
    host.get_by_text("Show critical path").click()
    line = host.locator(".ch-critical-line").inner_text()
    assert line.startswith("Critical path: WBS-100 → WBS-210")
    assert host.locator(".is-critical-mode").count() == 1
    host.get_by_role("button", name="Week").click()
    assert host.locator(".ch-bar").count() == 14
    host.get_by_role("button", name="Status").click()
    assert host.locator(".ch-st-prog").count() >= 1
    assert no_page_overflow(page)
    shot(page, "mock_gantt_full")
    assert_clean(page, "gantt")


def test_assistant_drawer(open_page, e2e_static):
    page = mocked(open_page, e2e_static)
    goto(page, "#/portfolio")
    page.get_by_role("button", name="Ask Assistant").click()
    page.locator(".dv-drawer textarea").fill("Which initiatives are at risk for the Feb release and why?")
    page.locator(".dv-drawer").get_by_role("button", name="Ask").click()
    answer = page.locator("[data-testid=assistant-answer]").last
    answer.locator("[data-testid=assistant-sources]").wait_for()
    text = answer.inner_text()
    assert "RDDC-24817" in text and "**" not in text and "|---" not in text
    assert answer.locator("table").count() == 1
    assert "Checked initiative health and key dates" in text
    answer.get_by_role("link", name="RDDC-24817").click()
    page.wait_for_url("**#/initiative/9/pg5")
    assert_clean(page, "assistant")


def test_ai_buttons_on_other_pages(open_page, e2e_static):
    page = mocked(open_page, e2e_static)
    goto(page, "#/resources")
    page.get_by_role("button", name="Generate Skill Matrix").click()
    page.get_by_text("Key-person risk for EDP work").wait_for()
    page.get_by_role("button", name="Accept").click()
    page.get_by_text("Skill matrix accepted").first.wait_for()
    goto(page, "#/outbox")
    page.get_by_role("button", name="Draft reminders").click()
    page.get_by_text("Action required by 21 Oct 2026: SA inputs for RDDC-24817").wait_for()
    page.get_by_role("button", name="Discard").click()
    page.get_by_role("button", name="Run reminders now").click()
    page.get_by_text("No new reminders are due").first.wait_for()
    goto(page, "#/artifacts")
    page.get_by_role("tab", name="Meeting Notes").click()
    page.get_by_label("Meeting notes").fill("Agreed DC-2702. Mira to confirm CIAM scopes by 23 Oct.")
    page.get_by_role("button", name="Extract actions").first.click()
    page.get_by_text("Confirm CIAM scope approval").wait_for()
    goto(page, "#/intake")
    page.get_by_role("button", name="Auto-slot backlog").click()
    page.get_by_role("button", name="Confirm slots").click()
    page.get_by_text("1 initiative slotted").wait_for()
    assert_clean(page, "ai buttons")
    assert not [u for u in page.mock.unknown if "/ai/" in u], page.mock.unknown
