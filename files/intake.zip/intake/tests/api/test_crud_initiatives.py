"""Initiatives: search, create (RDDC auto-number + DC intake pre-fill), bundle, edit, delete, components, uploads."""
from __future__ import annotations

import io
import json
from pathlib import Path

from app import db

FIXTURE = json.loads((Path(__file__).resolve().parents[1] / "fixtures" / "bundle_hero.json").read_text())
SQLI = "Robert'); DROP TABLE initiatives;--"


def test_list_and_filters(client):
    body = client.get("/api/initiatives").get_json()
    assert body["total"] == 8
    row = body["items"][0]
    for key in ("id", "rddc", "name", "lob", "stage", "status", "priority", "dc_pm_name", "dc_sa_name", "rag",
                "target_release", "readiness_date", "planned_end"):
        assert key in row
    assert client.get("/api/initiatives?q=24412").get_json()["items"][0]["name"] == "e-Transfer Request Money Redesign"
    assert client.get("/api/initiatives?q=zzz").get_json()["total"] == 0
    assert client.get("/api/initiatives?q=' OR 1=1--").get_json()["total"] == 0
    assert client.get("/api/initiatives?q=100%").get_json()["total"] == 0
    assert {r["rddc"] for r in client.get("/api/initiatives?stage=Build,QA").get_json()["items"]} == {"RDDC-24533", "RDDC-24601"}
    assert all(r["lob"] == "Cards & Payments" for r in client.get("/api/initiatives?lob=Cards %26 Payments").get_json()["items"])
    assert {r["rddc"] for r in client.get("/api/initiatives?release=DC-2703").get_json()["items"]} == {"RDDC-24702", "RDDC-24755"}
    assert client.get("/api/initiatives?dc_pm_id=16").get_json()["total"] == 4


def test_create_hero_from_intake(client, hero):
    ini = hero["initiative"]
    assert ini["rddc"] == "RDDC-24817" and ini["id"] == 9
    assert (ini["name"], ini["lob"], ini["requestor"], ini["requestor_id"], ini["priority"]) == (
        "US API Enhancement", "US P&C", "Clara Pemberton", 22, 2)
    assert ini["requested_go_live"] == "2027-02-20" and ini["target_release"] == "DC-2702"
    assert ini["prn_code"] == "PRN-77310" and ini["dc_pm_name"] == "Grace Ellingham" and ini["dc_sa_name"] == "Sana Whitfield"
    assert ini["status"] == "Backlog" and ini["l2_status"] == "Draft"
    if hero["grooming"] is not None:
        assert hero["grooming"]["session_date"] == "2026-10-20" and hero["grooming"]["start_time"] == "10:00"
        assert {n["to_name"] for n in hero["queued_notifications"]} >= {"Arlo Kingsley", "Grace Ellingham", "Sana Whitfield"}
    second = client.post("/api/initiatives", json={"name": "Commercial Card Virtual Numbers", "lob": "Cards & Payments",
                                                   "priority": 2, "requestor": "Marcus Thorne"}).get_json()
    assert second["initiative"]["rddc"] == "RDDC-24818"


def test_create_validation(client):
    resp = client.post("/api/initiatives", json={"lob": "US P&C", "priority": 2, "requestor": "Clara Pemberton"})
    assert resp.status_code == 422 and "name" in resp.get_json()["error"]["details"]["fields"]
    resp = client.post("/api/initiatives", json={"name": "X", "lob": "Retail", "priority": 9, "requestor": "A"})
    fields = resp.get_json()["error"]["details"]["fields"]
    assert resp.status_code == 422 and {"lob", "priority"} <= set(fields)
    assert client.post("/api/initiatives", json={"dc_intake": "DCI-9999"}).status_code == 422
    assert client.post("/api/initiatives", json={"name": "Y", "lob": "Wealth", "priority": 3}).status_code == 422
    assert client.post("/api/initiatives", json={"name": "Y", "lob": "Wealth", "priority": 3, "requestor": "B",
                                                 "requested_go_live": "next week"}).status_code == 422
    assert client.post("/api/initiatives", json={"name": "Y", "lob": "Wealth", "priority": 3, "requestor": "B",
                                                 "dc_pm_id": 999}).status_code == 422
    assert client.post("/api/initiatives", data="[1,2]", content_type="application/json").status_code == 400
    assert client.post("/api/initiatives", json={"name": "Z" * 81, "lob": "Wealth", "priority": 3,
                                                 "requestor": "B"}).status_code == 422
    assert client.get("/api/initiatives").get_json()["total"] == 8


def test_duplicate_intake_conflict(client, hero):
    resp = client.post("/api/initiatives", json={"dc_intake": "DCI-3391"})
    assert resp.status_code == 409 and resp.get_json()["error"]["details"]["rddc"] == "RDDC-24817"


def test_sql_injection_stored_literally(client):
    resp = client.post("/api/initiatives", json={"name": SQLI, "lob": "Wealth", "priority": 3, "requestor": SQLI,
                                                 "labels": ["<img src=x onerror=alert(1)>"]})
    assert resp.status_code == 201
    ini = resp.get_json()["initiative"]
    assert ini["name"] == SQLI and ini["labels"] == ["<img src=x onerror=alert(1)>"]
    assert client.get("/api/initiatives").get_json()["total"] == 9
    assert client.get("/api/initiatives?q=DROP TABLE").get_json()["items"][0]["name"] == SQLI


def test_bundle_shape_matches_fixture(client, hero):
    bundle = client.get("/api/initiatives/9").get_json()
    assert set(FIXTURE) <= set(bundle) and "action_required" in bundle
    assert set(FIXTURE["initiative"]) <= set(bundle["initiative"])
    sana = next(r for r in bundle["resources"] if r["id"] == 14)
    assert set(FIXTURE["resources"][0]) <= set(sana)
    assert sana["committed"]["2026-11"] == 115.5 and sana["availability"]["2026-11"] == 120.0
    assert bundle["target_train"] == {"code": "DC-2702", "train_date": "2027-02-20"}
    assert bundle["prn"]["prn_code"] == "PRN-77310" and bundle["prn"]["charges"] == []
    assert bundle["today"] == "2026-10-19" and bundle["now"].startswith("2026-10-19T09:30:00")
    cat = {c["code"]: c for c in bundle["component_catalog"]}
    assert cat["APIP"]["downstream"] == FIXTURE["component_catalog"][0]["downstream"]
    assert cat["APIP"]["keywords"] == FIXTURE["component_catalog"][0]["keywords"]
    grace = next(r for r in bundle["resources"] if r["id"] == 16)
    assert grace["availability"] == {} and grace["committed"] == {} and grace["capacity_eligible"] == 0


def test_seeded_bundle_tasks(client):
    bundle = client.get("/api/initiatives/2").get_json()
    codes = [t["wbs_code"] for t in bundle["tasks"]]
    assert codes[0] == "WBS-100" and "WBS-700" in codes
    t210 = next(t for t in bundle["tasks"] if t["wbs_code"] == "WBS-210")
    assert t210["depends_on_codes"] == ["WBS-100"] and t210["component_code"] == "PAYHUB"
    assert t210["owner_name"] and t210["resource_name"] == "Tobias Wren"
    assert bundle["change_requests"] and "compliance" in bundle["change_requests"][0]
    assert bundle["risks"][0]["risk_code"].startswith("RSK-")
    assert bundle["sa_doc_text"]


def test_get_unknown_initiative(client):
    resp = client.get("/api/initiatives/999")
    assert resp.status_code == 404 and resp.get_json()["error"]["code"] == "not_found"


def test_update_initiative(client, hero):
    resp = client.put("/api/initiatives/9", json={"comments": "Partner list confirmed", "stage": "Solution"})
    assert resp.status_code == 200
    body = resp.get_json()
    assert body["comments"] == "Partner list confirmed" and body["stage"] == "Solution" and body["status"] == "Backlog"
    assert client.put("/api/initiatives/9", json={"stage": "Done"}).status_code == 422
    assert client.put("/api/initiatives/9", json={"name": ""}).status_code == 422
    assert client.put("/api/initiatives/9", json={"target_release": "DC-9999"}).status_code == 422
    assert client.put("/api/initiatives/999", json={"comments": "x"}).status_code == 404
    assert client.put("/api/initiatives/9", json={"stage": "Closed"}).get_json()["status"] == "Completed"


def test_delete_initiative(client, hero):
    assert client.delete("/api/initiatives/9").get_json() == {"ok": True}
    assert client.get("/api/initiatives/9").status_code == 404
    assert client.delete("/api/initiatives/9").status_code == 404


def test_components_crud(client, hero):
    resp = client.post("/api/initiatives/9/components", json={"component_id": 1, "complexity": "High"})
    assert resp.status_code == 201
    comp = resp.get_json()
    assert comp["est_hours"] == 280 and comp["component_lead_name"] == "Devon Achterberg" and comp["code"] == "APIP"
    assert comp["approval"] == "Pending"
    assert client.post("/api/initiatives/9/components", json={"component_id": 1}).status_code == 409
    assert client.post("/api/initiatives/9/components", json={"component_code": "EDP"}).get_json()["est_hours"] == 120
    assert client.post("/api/initiatives/9/components", json={"component_id": 99}).status_code == 422
    assert client.post("/api/initiatives/9/components", json={"component_id": 4, "complexity": "Huge"}).status_code == 422
    assert client.post("/api/initiatives/999/components", json={"component_id": 4}).status_code == 404
    upd = client.put(f"/api/initiative-components/{comp['id']}", json={"complexity": "Low", "approval": "Approved"})
    assert upd.status_code == 200 and upd.get_json()["est_hours"] == 40 and upd.get_json()["approval"] == "Approved"
    assert client.put(f"/api/initiative-components/{comp['id']}", json={"est_hours": -5}).status_code == 422
    assert client.put("/api/initiative-components/9999", json={"approval": "Approved"}).status_code == 404
    listed = client.get("/api/initiatives/9/components").get_json()
    assert listed["total"] == 2
    assert client.delete(f"/api/initiative-components/{comp['id']}").get_json() == {"ok": True}
    assert client.delete(f"/api/initiative-components/{comp['id']}").status_code == 404


def test_scope_change_logged_after_l2_approval(client, db_conn):
    resp = client.post("/api/initiatives/5/components", json={"component_id": 11, "complexity": "Low"})
    assert resp.status_code == 201
    bundle = client.get("/api/initiatives/5").get_json()
    assert bundle["scope_changes"][-1]["action"] == "insert" and bundle["scope_changes"][-1]["component_code"] == "SRE"


def _upload(client, iid, data, name, kind="sa_doc", **extra):
    form = {"file": (io.BytesIO(data), name), "kind": kind, **extra}
    return client.post(f"/api/initiatives/{iid}/attachments", data=form, content_type="multipart/form-data")


def test_upload_generated_docx_sets_sa_fields(client, hero, make_docx):
    data = make_docx(["Solution Architecture: US API", "Version 1.2 · Author: Sana Whitfield (DC SA)", "1. Business context",
                      "Text.", "2. Scope", "In scope.", "3. Impacted components", "API Platform."],
                     table=[["Component", "Approval"], ["API Platform", "Approved"]])
    resp = _upload(client, 9, data, "SA US API v1.2.docx")
    assert resp.status_code == 201, resp.get_json()
    body = resp.get_json()
    assert body["attachment"]["filename"] == "SA_US_API_v1.2.docx" and body["extracted_chars"] > 50
    assert body["sa"]["author"] == "Sana Whitfield" and body["sa"]["version"] == "1.2"
    ini = client.get("/api/initiatives/9").get_json()
    assert ini["initiative"]["sa_doc_attachment_id"] == body["attachment"]["id"]
    assert ini["initiative"]["sa_version"] == "1.2" and "API Platform | Approved" in ini["sa_doc_text"]
    download = client.get(f"/api/attachments/{body['attachment']['id']}/download")
    assert download.status_code == 200 and download.data == data


def test_upload_generated_pdf(client, hero, make_pdf):
    resp = _upload(client, 9, make_pdf(), "statements.pdf", kind="other")
    assert resp.status_code == 201
    assert resp.get_json()["extracted_chars"] > 20 and resp.get_json()["sa"] is None
    assert client.get("/api/initiatives/9/attachments").get_json()["total"] == 1


def test_sample_sa_document_scores_88(client, hero):
    sample = Path(__file__).resolve().parents[2] / "app" / "seed" / "files" / "SA_US_API_Enhancement_v1.2.docx"
    if not sample.exists():
        return
    body = _upload(client, 9, sample.read_bytes(), sample.name).get_json()
    if body["sa"]["completeness"] is not None:
        assert body["sa"]["completeness"] == 88 and body["sa"]["author"] == "Sana Whitfield"


def test_upload_bad_input(client, hero, app):
    assert _upload(client, 9, b"MZ\x90\x00binary", "tool.exe").status_code == 422
    resp = _upload(client, 9, b"MZ\x90\x00binary", "renamed.pdf")
    assert resp.status_code == 422 and resp.get_json()["error"]["details"]["fallback"] == "paste_text"
    assert _upload(client, 9, b"not a zip", "broken.docx").status_code == 422
    assert _upload(client, 9, b"", "empty.txt").status_code == 422
    assert _upload(client, 9, b"some text here", "ok.txt", kind="poster").status_code == 422
    assert _upload(client, 9, b"some text here", "ok.txt", kind="other", entity_type="change_request",
                   entity_id="1").status_code == 422
    assert client.post("/api/initiatives/9/attachments", data={"kind": "sa_doc"},
                       content_type="multipart/form-data").status_code == 422
    big = _upload(client, 9, b"a" * (10 * 1024 * 1024 + 10), "big.txt")
    assert big.status_code == 413 and big.get_json()["error"]["code"] == "payload_too_large"
    assert _upload(client, 999, b"text", "a.txt").status_code == 404
    uploads = Path(app.config["UPLOAD_DIR"]) / "9"
    assert not uploads.exists() or not any(uploads.iterdir())
    traversal = _upload(client, 9, b"plain text content", "../../app.py.txt", kind="other")
    assert traversal.status_code == 201 and "/" not in traversal.get_json()["attachment"]["filename"]


def test_validation_evidence_links_to_crq(client, db_conn):
    resp = _upload(client, 1, b"Business validation passed on 17 Oct 2026.", "biz.txt", kind="biz_validation",
                   entity_type="change_request", entity_id="5")
    assert resp.status_code == 201
    assert db.scalar("SELECT biz_validation_attachment_id FROM change_requests WHERE id = 5") == resp.get_json()["attachment"]["id"]


def test_sa_text_paste(client, hero):
    text = "Solution Architecture: pasted\nVersion 0.4 · Author: Sana Whitfield\n\n1. Business context\nPartner APIs.\n"
    resp = client.post("/api/initiatives/9/sa-text", json={"text": text, "filename": "pasted.md"})
    assert resp.status_code == 201 and resp.get_json()["sa"]["version"] == "0.4"
    assert client.post("/api/initiatives/9/sa-text", json={"text": "short"}).status_code == 422
    assert client.post("/api/initiatives/9/sa-text", json={}).status_code == 422
    assert client.post("/api/initiatives/999/sa-text", json={"text": text}).status_code == 404


def test_download_unknown(client):
    assert client.get("/api/attachments/9999/download").status_code == 404
