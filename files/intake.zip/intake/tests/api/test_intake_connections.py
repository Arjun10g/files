"""Entered intake context connects to the shared roster and funding atomically."""
import threading

import pytest

from app import create_app, db, errors
from app.workspace import initialize_empty


@pytest.fixture
def portal(tmp_path):
    app = create_app(DB_PATH=str(tmp_path/'portal.db'), UPLOAD_DIR=str(tmp_path/'uploads'),
                     TESTING=True, TODAY='2026-10-21', AI_MODE='simulated', HAS_API_KEY=False)
    with app.app_context():
        initialize_empty(db.get_db(), today='2026-10-21')
    return app, app.test_client()


def intake(**extra):
    return {'name': 'Connected intake', 'lob': 'US P&C', 'priority': 2,
            'requestor': 'Submitted Person', **extra}


def create(client, **extra):
    response = client.post('/api/initiatives', json=intake(**extra))
    assert response.status_code == 201, response.get_json()
    return response.get_json()


def test_entered_people_populate_roster_without_invented_capacity_or_rate(portal):
    _, client = portal
    result = create(client, dc_pm='Delivery Manager', dc_sa='Solution Architect',
                    tech_lead='Engineering Lead', business_analyst='Business Analyst')
    people = client.get('/api/resources').get_json()['items']
    assert len(people) == 5
    assert len(result['connections']['people_created']) == 5
    assert all(p['hourly_rate'] == p['default_monthly_hours'] == 0 for p in people)
    by_name = {p['name']: p for p in people}
    assert by_name['Submitted Person']['capacity_eligible'] == 0
    assert by_name['Business Analyst']['capacity_eligible'] == 0
    assert by_name['Delivery Manager']['capacity_eligible'] == 1
    assert by_name['Solution Architect']['team'] == 'DC SA'
    initiative = result['initiative']
    assert initiative['dc_pm_id'] == initiative['pm_id'] == initiative['assigned_to_id']
    assert initiative['dc_sa_name'] == 'Solution Architect'


def test_normalized_names_reuse_and_preserve_existing_resource_settings(portal):
    _, client = portal
    person = client.post('/api/resources', json={'name': 'Éloïse Manager', 'role': 'Existing role',
        'team': 'Original team', 'hourly_rate': 123, 'default_monthly_hours': 88}).get_json()
    result = create(client, requestor='  ÉLOÏSE    manager ', dc_pm='éloïse manager')
    assert result['initiative']['requestor_id'] == person['id'] == result['initiative']['dc_pm_id']
    resources = client.get('/api/resources').get_json()['items']
    assert len(resources) == 1
    assert resources[0]['role'] == 'Existing role' and resources[0]['team'] == 'Original team'
    assert resources[0]['hourly_rate'] == 123 and resources[0]['default_monthly_hours'] == 88
    assert not result['connections']['people_created']


def test_ambiguous_name_requires_explicit_existing_id(portal):
    app, client = portal
    with app.app_context():
        first = db.insert('resources', {'name': 'Same Name', 'role': 'Requestor', 'capacity_eligible': 0})
        db.insert('resources', {'name': ' SAME   NAME ', 'role': 'Requestor', 'capacity_eligible': 0})
    response = client.post('/api/initiatives', json=intake(requestor='same name'))
    assert response.status_code == 422
    assert 'requestor' in response.get_json()['error']['details']['fields']
    result = create(client, requestor='Same Name', requestor_id=first)
    assert result['initiative']['requestor_id'] == first


def test_mismatched_id_is_rejected_and_prior_connections_rollback(portal):
    app, client = portal
    person = client.post('/api/resources', json={'name': 'Actual Manager', 'role': 'DC PM'}).get_json()
    response = client.post('/api/initiatives', json=intake(dc_pm='Different Manager', dc_pm_id=person['id'],
                                                        prn_code='PRN-NOT-SAVED'))
    assert response.status_code == 422
    with app.app_context():
        assert db.scalar('SELECT COUNT(*) FROM resources') == 1
        assert db.scalar('SELECT COUNT(*) FROM initiatives') == 0
        assert db.scalar('SELECT COUNT(*) FROM prn_budget') == 0


def test_late_initiative_validation_rolls_back_people_and_budget(portal):
    app, client = portal
    response = client.post('/api/initiatives', json=intake(lob='Invalid business', dc_pm='New Manager',
                                                        prn_code='PRN-ATOMIC'))
    assert response.status_code == 422
    with app.app_context():
        assert db.scalar('SELECT COUNT(*) FROM resources') == 0
        assert db.scalar('SELECT COUNT(*) FROM prn_budget') == 0
        assert db.scalar("SELECT value FROM app_settings WHERE key='rddc_next'") == '10001'


def test_editing_intake_connects_people_and_repeated_saves_do_not_duplicate(portal):
    _, client = portal
    initiative = create(client)['initiative']
    body = {'dc_pm': 'Updated Manager', 'dc_sa': 'Updated Architect', 'business_analyst': 'Entered Analyst'}
    for _ in range(2):
        response = client.put(f'/api/initiatives/{initiative["id"]}', json=body)
        assert response.status_code == 200, response.get_json()
    assert len(client.get('/api/resources').get_json()['items']) == 4
    detail = client.get(f'/api/initiatives/{initiative["id"]}').get_json()['initiative']
    assert detail['dc_pm_name'] == 'Updated Manager' and detail['dc_sa_name'] == 'Updated Architect'
    assert detail['business_analyst'] == 'Entered Analyst'


def test_unknown_funding_code_creates_pending_zero_draft(portal):
    _, client = portal
    result = create(client, prn_code='prn-new', platform='BDB')
    budget = client.get('/api/funding/PRN-NEW').get_json()
    assert budget['funded_hours'] == budget['rate'] == budget['budget_amount'] == 0
    assert budget['decision'] == 'Pending' and budget['intake_draft']
    assert budget['platform'] == 'BDB'
    assert budget['source_initiative_id'] == result['initiative']['id']
    assert result['connections']['funding_created'][0]['prn_code'] == 'PRN-NEW'


def test_funding_from_intake_uses_only_explicit_financial_values(portal):
    _, client = portal
    create(client, funding={'prn_code': 'PRN-EXPLICIT', 'funded_hours': 200, 'rate': 80,
                           'owner': 'Funding Owner', 'scope': 'Portal scope'})
    budget = client.get('/api/funding/PRN-EXPLICIT').get_json()
    assert budget['funded_hours'] == 200 and budget['rate'] == 80
    assert budget['budget_amount'] == 16000 and not budget['intake_draft']
    assert budget['owner_name'] == 'Funding Owner' and budget['scope'] == 'Portal scope'
    owner = next(p for p in client.get('/api/resources').get_json()['items'] if p['name'] == 'Funding Owner')
    assert owner['role'] == 'Budget Owner' and owner['capacity_eligible'] == 0


def test_existing_shared_funding_requires_confirmed_update(portal):
    _, client = portal
    initial = create(client, funding={'prn_code': 'PRN-SHARED', 'funded_hours': 100, 'rate': 50,
                                     'budget_amount': 5000, 'name': 'Original budget'})['initiative']
    linked = create(client, name='Second initiative', prn_code='PRN-SHARED')
    assert linked['connections']['funding_reused']
    body = {'dc_pm': 'Must Roll Back', 'funding': {'prn_code': 'PRN-SHARED', 'funded_hours': 300,
                                                 'owner': 'New Owner', 'name': 'Renamed budget'}}
    denied = client.put(f'/api/initiatives/{initial["id"]}', json=body)
    assert denied.status_code == 422
    assert not any(p['name'] in ('Must Roll Back', 'New Owner') for p in client.get('/api/resources').get_json()['items'])
    body['funding']['update_existing'] = True
    saved = client.put(f'/api/initiatives/{initial["id"]}', json=body)
    assert saved.status_code == 200, saved.get_json()
    budget = client.get('/api/funding/PRN-SHARED').get_json()
    assert budget['name'] == 'Renamed budget' and budget['owner_name'] == 'New Owner'
    assert budget['funded_hours'] == 300 and budget['rate'] == 50 and budget['budget_amount'] == 15000


def test_import_preview_proposes_connections_without_domain_writes(portal):
    app, client = portal
    response = client.post('/api/imports/preview', json={'type': 'intake', 'payload': [intake(
        dc_pm='Imported Manager', dc_sa='Imported Architect', business_analyst='Imported Analyst',
        prn_code='PRN-IMPORTED', funded_hours=240, rate=90, budget_amount=21600, owner='Imported Owner',
        funding_name='Imported budget', funding_scope='Imported scope')]})
    assert response.status_code == 201, response.get_json()
    batch = response.get_json()
    assert batch['summary']['invalid'] == 0, batch
    assert any('will be added' in w for w in batch['rows'][0]['warnings'])
    with app.app_context():
        assert db.scalar('SELECT COUNT(*) FROM resources') == db.scalar('SELECT COUNT(*) FROM prn_budget') == 0
    response = client.post(f'/api/imports/{batch["id"]}/commit', json={})
    assert response.status_code == 200, response.get_json()
    result = response.get_json()['result']['items'][0]
    assert len(result['connections']['people_created']) == 5
    assert len(client.get('/api/resources').get_json()['items']) == 5
    budget = client.get('/api/funding/PRN-IMPORTED').get_json()
    assert budget['name'] == 'Imported budget' and budget['funded_hours'] == 240
    assert budget['owner_name'] == 'Imported Owner' and budget['scope'] == 'Imported scope'
    repeat = client.post(f'/api/imports/{batch["id"]}/commit', json={}).get_json()
    assert repeat['idempotent']
    assert len(client.get('/api/resources').get_json()['items']) == 5


def test_import_connections_rollback_when_a_later_row_fails(portal, monkeypatch):
    from app.api import initiatives
    app, client = portal
    batch = client.post('/api/imports/preview', json={'type': 'intake', 'payload': [
        intake(name='First', dc_pm='First Manager', prn_code='PRN-FIRST'),
        intake(name='Second', dc_pm='Second Manager', prn_code='PRN-SECOND')]}).get_json()
    original = initiatives.create_initiative

    def fail_second(data):
        result = original(data)
        if data['name'] == 'Second':
            raise errors.validation('Late failure', {'name': 'Try again.'})
        return result

    monkeypatch.setattr(initiatives, 'create_initiative', fail_second)
    response = client.post(f'/api/imports/{batch["id"]}/commit', json={})
    assert response.status_code == 422
    with app.app_context():
        for table in ('resources', 'prn_budget', 'initiatives', 'import_records'):
            assert db.scalar(f'SELECT COUNT(*) FROM {table}') == 0
        assert db.scalar('SELECT status FROM import_batches WHERE id=?', (batch['id'],)) == 'preview'


def test_funding_import_creates_named_owner_and_retains_zero_missing_finances(portal):
    _, client = portal
    batch = client.post('/api/imports/preview', json={'type': 'funding', 'payload': [
        {'prn_code': 'PRN-OWNER', 'name': 'Funding import', 'owner': 'Named Owner'}]}).get_json()
    assert batch['summary']['invalid'] == 0, batch
    response = client.post(f'/api/imports/{batch["id"]}/commit', json={})
    assert response.status_code == 200, response.get_json()
    budget = client.get('/api/funding/PRN-OWNER').get_json()
    assert budget['owner_name'] == 'Named Owner'
    assert budget['funded_hours'] == budget['rate'] == budget['budget_amount'] == 0


def test_completing_funding_in_its_tab_clears_intake_draft_and_keeps_link(portal):
    _, client = portal
    initiative = create(client, prn_code='PRN-COMPLETE')['initiative']
    response = client.put('/api/funding/PRN-COMPLETE', json={'funded_hours': 320, 'rate': 95})
    assert response.status_code == 200, response.get_json()
    budget = response.get_json()
    assert not budget['intake_draft']
    assert budget['funded_hours'] == 320 and budget['rate'] == 95
    assert budget['initiatives'][0]['id'] == initiative['id']
    detail = client.get(f'/api/initiatives/{initiative["id"]}').get_json()['initiative']
    assert detail['prn_code'] == 'PRN-COMPLETE'


def test_nested_json_funding_is_reviewable_and_does_not_import_update_permission(portal):
    from app.services.intake_parser import map_json_payload

    _, client = portal
    record = intake(dc_pm='JSON Manager', funding={'prn_code': 'PRN-NESTED', 'name': 'Nested budget',
        'owner': 'JSON Owner', 'funded_hours': 125, 'rate': 80, 'budget_amount': 10000,
        'scope': 'Nested scope', 'update_existing': True})
    fields = map_json_payload(record)['rows'][0]['fields']
    assert fields['funding_name'] == 'Nested budget' and fields['funding_scope'] == 'Nested scope'
    assert fields['funded_hours'] == 125 and fields['owner'] == 'JSON Owner'
    assert 'update_existing' not in fields and 'funding' not in fields
    batch = client.post('/api/imports/preview', json={'type': 'intake', 'payload': record}).get_json()
    assert batch['summary']['invalid'] == 0, batch
    response = client.post(f'/api/imports/{batch["id"]}/commit', json={})
    assert response.status_code == 200, response.get_json()
    budget = client.get('/api/funding/PRN-NESTED').get_json()
    assert budget['name'] == 'Nested budget' and budget['scope'] == 'Nested scope'
    assert budget['owner_name'] == 'JSON Owner' and budget['funded_hours'] == 125
    assert len(client.get('/api/resources').get_json()['items']) == 3


def test_import_reuses_matching_existing_funding_and_flags_conflicts(portal):
    _, client = portal
    create(client, funding={'prn_code': 'PRN-REUSE', 'funded_hours': 100, 'rate': 50, 'budget_amount': 5000})
    row = intake(name='Imported reuse', prn_code='PRN-REUSE', funded_hours=100, rate=50, budget_amount=5000)
    batch = client.post('/api/imports/preview', json={'type': 'intake', 'payload': row}).get_json()
    assert batch['summary']['invalid'] == 0, batch
    response = client.post(f'/api/imports/{batch["id"]}/commit', json={})
    assert response.status_code == 200, response.get_json()
    assert len(client.get('/api/funding').get_json()['items']) == 1
    row.update(name='Conflicting reuse', funded_hours=999)
    conflict = client.post('/api/imports/preview', json={'type': 'intake', 'payload': row}).get_json()
    assert conflict['summary']['invalid'] == 1
    assert 'funding.funded_hours' in conflict['rows'][0]['errors']
    assert client.post(f'/api/imports/{conflict["id"]}/commit', json={}).status_code == 422
    assert client.get('/api/funding/PRN-REUSE').get_json()['funded_hours'] == 100


def test_amount_and_explicit_rate_derive_hours_without_assuming_a_rate(portal):
    _, client = portal
    create(client, funding={'prn_code': 'PRN-DERIVED', 'budget_amount': 12000, 'rate': 120})
    budget = client.get('/api/funding/PRN-DERIVED').get_json()
    assert budget['funded_hours'] == 100 and not budget['intake_draft']
    create(client, name='Unknown rate', funding={'prn_code': 'PRN-NO-RATE', 'budget_amount': 12000})
    unknown = client.get('/api/funding/PRN-NO-RATE').get_json()
    assert unknown['funded_hours'] == 0 and unknown['rate'] == 0 and unknown['intake_draft']
    assert unknown['budget_amount'] == 12000


def test_concurrent_intakes_reuse_one_shared_person_and_budget(portal):
    app, _ = portal
    responses = []
    barrier = threading.Barrier(4)

    def submit(index):
        barrier.wait()
        response = app.test_client().post('/api/initiatives', json=intake(
            name=f'Concurrent intake {index}', dc_pm='Shared Manager', prn_code='PRN-CONCURRENT'))
        responses.append((response.status_code, response.get_json()))

    threads = [threading.Thread(target=submit, args=(i,)) for i in range(4)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    assert all(status == 201 for status, _ in responses), responses
    with app.app_context():
        assert db.scalar('SELECT COUNT(*) FROM resources') == 2
        assert db.scalar('SELECT COUNT(*) FROM prn_budget') == 1
        assert db.scalar('SELECT COUNT(DISTINCT dc_pm_id) FROM initiatives') == 1


def test_funding_details_without_code_are_rejected_without_partial_connections(portal):
    app, client = portal
    response = client.post('/api/initiatives', json=intake(dc_pm='Not Saved',
        funding={'funded_hours': 100, 'rate': 50, 'owner': 'Not Saved Owner'}))
    assert response.status_code == 422
    assert 'prn_code' in response.get_json()['error']['details']['fields']
    with app.app_context():
        assert db.scalar('SELECT COUNT(*) FROM resources') == 0
        assert db.scalar('SELECT COUNT(*) FROM initiatives') == 0
    batch = client.post('/api/imports/preview', json={'type': 'intake', 'payload': intake(
        funded_hours=100, rate=50, owner='Imported Owner')}).get_json()
    assert batch['summary']['invalid'] == 1
    assert 'prn_code' in batch['rows'][0]['errors']
    assert client.post(f'/api/imports/{batch["id"]}/commit', json={}).status_code == 422


def test_changing_only_draft_currency_keeps_financial_review_pending(portal):
    _, client = portal
    initiative = create(client, prn_code='PRN-CURRENCY')['initiative']
    response = client.put(f'/api/initiatives/{initiative["id"]}', json={'funding': {
        'prn_code': 'PRN-CURRENCY', 'currency': 'USD', 'update_existing': True}})
    assert response.status_code == 200, response.get_json()
    budget = client.get('/api/funding/PRN-CURRENCY').get_json()
    assert budget['intake_draft'] and budget['currency'] == 'USD'
    response = client.put(f'/api/initiatives/{initiative["id"]}', json={'funding': {
        'prn_code': 'PRN-CURRENCY', 'funded_hours': 100, 'rate': 120, 'update_existing': True}})
    assert response.status_code == 200, response.get_json()
    budget = client.get('/api/funding/PRN-CURRENCY').get_json()
    assert not budget['intake_draft'] and budget['budget_amount'] == 12000


def test_named_person_can_replace_a_dc_intake_default(client):
    response = client.post('/api/initiatives', json={'dc_intake': 'DCI-3391',
        'dc_pm': 'Entered Replacement Manager', 'dc_pm_id': None})
    assert response.status_code == 201, response.get_json()
    assert response.get_json()['initiative']['dc_pm_name'] == 'Entered Replacement Manager'
