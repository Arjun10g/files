"""Round 2 decisions (docs/qa/round2_decisions.md): CRQ numbering, draft STO, stage flow, action required, DLR,
BAU capacity from May 2027, role options."""
from __future__ import annotations

import io

import pytest

from app import db, repo


def test_decision1_crq_sequence(client, db_conn, hero):
    assert db.scalar("SELECT value FROM app_settings WHERE key = 'crq_next'") == "1052216"
    numbers = {r["crq_number"] for r in db.query("SELECT crq_number FROM change_requests")}
    assert numbers == {"CRQ000000417305", "CRQ000000421907", "CRQ000001045902", "CRQ000001045310",
                       "CRQ000001046031", "CRQ000001046488"}
    first = client.post("/api/initiatives/9/change-requests/draft").get_json()
    assert first["crq_number"] == "CRQ000001052216" and len(first["crq_number"]) == 15
    assert client.post("/api/initiatives/9/change-requests/draft").get_json()["id"] == first["id"]
    second = client.post("/api/initiatives/5/change-requests/draft").get_json()
    assert second["crq_number"] == "CRQ000001052217"


def test_decision2_draft_sto_not_requested(client, hero):
    cr = client.post("/api/initiatives/9/change-requests/draft").get_json()
    assert cr["sto_approval"] is None
    seeded = client.get("/api/change-requests/1").get_json()
    assert seeded["sto_approval"] == "Tentative No Go"


def test_decision4_mark_as_groomed(client, hero, db_conn):
    assert hero["initiative"]["id"] == 9
    stage = db.scalar("SELECT stage FROM initiatives WHERE id = 9")
    if hero["grooming"] is None:
        return
    assert stage == "Grooming"
    resp = client.post("/api/initiatives/9/groomed")
    assert resp.status_code == 200
    body = resp.get_json()
    assert body["initiative"]["stage"] == "Solution" and body["initiative"]["status"] == "Backlog"
    assert body["message"] == ("Groomed in an ad-hoc walk-through today (Mon 19 Oct 2026). The Tue 20 Oct slot is free "
                               "again. Stage moved Grooming → Solution.")
    assert db.scalar("SELECT COUNT(*) FROM grooming_slots WHERE initiative_id = 9") == 0
    assert db.scalar("SELECT COUNT(*) FROM notifications WHERE initiative_id = 9 AND rule = 'grooming_invite' "
                     "AND status = 'Queued'") == 0
    feed = client.get("/api/activity?initiative_id=9").get_json()["items"]
    assert any(r["summary"] == "Groomed · ad-hoc walk-through Mon 19 Oct 2026" for r in feed)
    assert any("Grooming → Solution" in r["summary"] for r in feed)
    assert client.post("/api/initiatives/9/groomed").status_code == 409
    assert client.post("/api/initiatives/999/groomed").status_code == 404
    assert client.post("/api/initiatives/2/groomed").status_code == 409


def test_stage_service_only_moves_forward(app, hero):
    from app.services import stage
    with app.app_context():
        with db.transaction():
            assert stage.advance(9, "Estimation", reason="Change Summary accepted") == {"from": "Grooming" if
                                                                                        hero["grooming"] else "Intake",
                                                                                        "to": "Estimation"}
            assert stage.advance(9, "Solution") is None
        assert db.scalar("SELECT stage FROM initiatives WHERE id = 9") == "Estimation"
        with pytest.raises(ValueError):
            stage.advance(9, "Done")


def test_decision5_action_required_after_sa_upload(client, hero):
    if repo.optional_module("app.engines.reminders") is None:
        pytest.skip("reminder engine not installed")
    text = ("Solution Architecture: US API Enhancement\nVersion 1.2 · Author: Sana Whitfield\n\n1. Business context\nx\n"
            "2. Scope\nx\n3. Impacted components\nx\n4. Integration and sequence\nx\n5. Non-functional requirements\nx\n"
            "6. Security\nx\n7. Data\nx\n8. Open questions\nx\n")
    form = {"file": (io.BytesIO(text.encode()), "SA.md"), "kind": "sa_doc"}
    assert client.post("/api/initiatives/9/attachments", data=form, content_type="multipart/form-data").status_code == 201
    action = client.get("/api/initiatives/9").get_json()["action_required"]
    assert action == {"owner_id": 14, "owner_name": "Sana Whitfield", "due": "2026-10-21",
                      "what": "Add the backout plan section to the SA document"}
    pending = client.get("/api/initiatives/6").get_json()["action_required"]
    assert pending["owner_name"] == "Marcus Thorne" and pending["what"].startswith("Approve the L2 estimate")
    assert client.get("/api/initiatives/1").get_json()["action_required"] is None


def test_decision6_dlr_fields(client):
    ini = client.get("/api/initiatives/6").get_json()["initiative"]
    assert ini["dlr_name"] == "Arlo Kingsley" and ini["dlr_shared_at"] == ini["l2_submitted_at"]
    assert client.get("/api/initiatives/7").get_json()["initiative"]["dlr_shared_at"] is None


def test_decision12_bau_capacity_from_may_2027(client, db_conn):
    assert db.scalar("SELECT COUNT(*) FROM allocations WHERE initiative_id = -1 AND month < '2027-04'") == 0
    sana = [r["hours"] for r in db.query("SELECT hours FROM allocations WHERE initiative_id = -1 AND resource_id = 14 "
                                         "ORDER BY month")]
    assert len(sana) == 7 and len(set(sana)) > 3 and all(24 <= h <= 48 for h in sana)
    utils = db.query("SELECT a.hours / v.available_hours AS u FROM allocations a JOIN resource_availability v "
                     "ON v.resource_id = a.resource_id AND v.month = a.month WHERE a.initiative_id = -1")
    assert all(0.195 <= r["u"] <= 0.405 for r in utils)
    tracked = db.scalar("SELECT COUNT(DISTINCT resource_id) FROM allocations WHERE initiative_id = -1")
    assert tracked == 15
    for rid, month, hours in ((14, "2026-11", 115.5), (15, "2026-11", 50.5), (5, "2026-12", 96.0), (12, "2026-12", 145.5)):
        assert db.scalar("SELECT SUM(hours) FROM allocations WHERE resource_id = ? AND month = ?", (rid, month)) == hours
    assert "BAU-FY27" not in {r["rddc"] for r in client.get("/api/initiatives").get_json()["items"]}
    assert client.get("/api/initiatives").get_json()["total"] == 8
    assert client.post("/api/admin/reset").get_json()["counts"]["initiatives"] == 9  # 8 + hidden BAU


def test_bau_survives_rebuild(app, db_conn):
    derive = repo.optional_module("app.services.derive")
    if derive is None:
        pytest.skip("derive service not installed")
    before = db.scalar("SELECT COUNT(*) FROM allocations WHERE initiative_id = -1")
    with db.transaction():
        derive.rebuild_allocations(-1)
    assert db.scalar("SELECT COUNT(*) FROM allocations WHERE initiative_id = -1") == before


def test_finding18_role_options(client):
    body = client.get("/api/lookups").get_json()
    opts = body["role_options"]
    assert opts["dc_sa_id"] == [14, 15] and opts["dc_pm_id"] == [16, 17]
    assert 22 not in opts["tech_lead_id"] and 20 not in opts["tech_lead_id"] and 12 not in opts["tech_lead_id"]
    assert set(opts["requestor_id"]) == {22, 23, 24}
    assert "Solution Architect" in body["roles"]


def test_crq_draft_dry_run_does_not_consume_number(client, db_conn, hero):
    before = db.scalar("SELECT COUNT(*) FROM change_requests")
    preview = client.post("/api/initiatives/9/change-requests/draft", json={"dry_run": True})
    assert preview.status_code == 200
    body = preview.get_json()
    assert body["dry_run"] is True and body["id"] is None and body["crq_number"] == "CRQ000001052216"
    assert body["release_type"] == "Bundle" and body["release_train"] == "DC-2702" and body["sto_approval"] is None
    assert body["crq_start"] == "2027-02-20T02:00:00-05:00" and body["cms_lead_name"] == "Petra Vallance"
    assert "flags" in body["compliance"]
    assert db.scalar("SELECT COUNT(*) FROM change_requests") == before
    assert db.scalar("SELECT value FROM app_settings WHERE key = 'crq_next'") == "1052216"
    assert client.post("/api/initiatives/9/change-requests/draft", json={"dry_run": True}).get_json()["crq_number"] == \
        "CRQ000001052216"
    saved = client.post("/api/initiatives/9/change-requests/draft", json={})
    assert saved.status_code == 201 and saved.get_json()["crq_number"] == "CRQ000001052216"
    assert db.scalar("SELECT value FROM app_settings WHERE key = 'crq_next'") == "1052217"
    again = client.post("/api/initiatives/9/change-requests/draft", json={"dry_run": True}).get_json()
    assert again["id"] == saved.get_json()["id"] and again["dry_run"] is False


def test_n2_groomed_on_session_day_marks_discussed(client, db_conn):
    sid = db.scalar("SELECT session_id FROM grooming_slots s JOIN grooming_sessions g ON g.id = s.session_id "
                    "WHERE s.initiative_id = 8 AND g.session_date = '2026-10-22'")
    assert client.put("/api/settings", json={"demo_today": "2026-10-22"}).status_code == 200
    body = client.post("/api/initiatives/8/groomed").get_json()
    assert body["message"].startswith("Groomed in session Thu 22 Oct, 10:00.") and body["session_id"] == sid
    assert db.scalar("SELECT status FROM grooming_slots WHERE initiative_id = 8 AND session_id = ?", (sid,)) == "Discussed"


def test_n3_action_required_persists_until_sa_complete(client):
    if repo.optional_module("app.ai.provider") is None or repo.optional_module("app.engines.reminders") is None:
        pytest.skip("AI layer or reminder engine not installed")
    steps = client.post("/api/admin/fast-forward-hero").get_json()["steps"]
    assert all(s["ok"] for s in steps)
    bundle = client.get("/api/initiatives/9").get_json()
    assert bundle["initiative"]["stage"] == "Planning"
    assert bundle["action_required"]["what"] == "Add the backout plan section to the SA document"
    assert bundle["action_required"]["owner_name"] == "Sana Whitfield"
    from app import repo as r
    with client.application.app_context():
        assert r.action_required_for(9)["owner_id"] == 14
    full = ("SA v1.3\nVersion 1.3 · Author: Sana Whitfield\n\n1. Business context\nx\n2. Scope\nx\n3. Impacted components\nx\n"
            "4. Integration and sequence\nx\n5. Non-functional requirements\nx\n6. Security\nx\n7. Data\nx\n"
            "8. Backout plan\nx\n9. Open questions\nx\n")
    form = {"file": (io.BytesIO(full.encode()), "SA_v1.3.md"), "kind": "sa_doc"}
    resp = client.post("/api/initiatives/9/attachments", data=form, content_type="multipart/form-data")
    assert resp.get_json()["sa"]["completeness"] == 100
    assert client.get("/api/initiatives/9").get_json()["action_required"] is None
