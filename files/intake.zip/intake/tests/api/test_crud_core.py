"""Core endpoints, seed counts and the pinned seed numbers (master plan §6.2, contracts.md)."""
from __future__ import annotations

import pytest

from app import db


def test_health(client):
    body = client.get("/api/health").get_json()
    assert body["status"] == "ok" and body["db"] is True
    assert body["today"] == "2026-10-19"
    assert body["ai_mode"] == "simulated"
    assert "core" in body["modules"]


def test_lookups_sheet1_lists_verbatim(client):
    body = client.get("/api/lookups").get_json()
    values = {k: [o["value"] for o in v] for k, v in body.items() if isinstance(v, list) and v and isinstance(v[0], dict)
              and set(v[0]) == {"value", "label"}}
    assert values["status"] == ["Backlog", "In progress", "Completed"]
    assert values["release_type"] == ["Bundle", "Independent"]
    assert values["sto_approval"] == ["Tentative Go", "Tentative No Go", "Go", "No-Go"]
    assert values["validation_status"] == ["Not Started", "In progress", "Completed", "Failed"]
    assert values["rag"] == ["Red", "Amber", "Green"]
    assert values["stage"][0] == "Intake" and values["stage"][-1] == "Closed"
    assert values["priority"] == [1, 2, 3, 4]
    assert [o["label"] for o in body["risk_severity"]] == ["Low", "Medium", "High", "Critical"]
    assert body["freeze"] == {"start": "2026-12-14", "end": "2027-01-08"}
    assert "2027-02-15" in body["holidays"]
    assert [q["label"] for q in body["fiscal_quarters"]] == ["Nov–Jan", "Feb–Apr", "May–Jul", "Aug–Oct"]
    assert body["fiscal_quarters"][0]["fy"] == "FY27"
    assert len(body["components"]) == 12 and len(body["resources"]) == 24
    assert "holiday" not in body


def test_settings_roundtrip_and_validation(client):
    body = client.get("/api/settings").get_json()
    assert body["persona"] == "DC PM" and body["demo_today"] == "2026-10-19" and body["live_available"] is False
    resp = client.put("/api/settings", json={"persona": "Requestor", "ai_speed": "Fast"})
    assert resp.status_code == 200 and resp.get_json()["persona"] == "Requestor"
    assert client.put("/api/settings", json={"persona": "CEO"}).status_code == 422
    assert client.put("/api/settings", json={"demo_today": "19/10/2026"}).status_code == 422
    live = client.put("/api/settings", json={"ai_mode": "live"})
    assert live.status_code == 422 and "not configured" in live.get_json()["error"]["message"]
    assert client.put("/api/settings", data="not json", content_type="application/json").status_code == 400
    assert client.put("/api/settings", json={}).status_code == 422


def test_seed_counts_and_settings(client, db_conn):
    counts = {t: db.scalar(f"SELECT COUNT(*) FROM {t}" + (" WHERE id > 0" if t == "initiatives" else "")) for t in ("initiatives", "resources", "dc_components",
                                                                    "release_trains", "dc_intakes", "change_requests")}
    assert counts == {"initiatives": 8, "resources": 24, "dc_components": 12, "release_trains": 6, "dc_intakes": 5,
                      "change_requests": 6}
    assert db.scalar("SELECT value FROM app_settings WHERE key = 'rddc_next'") == "24817"
    assert db.scalar("SELECT COUNT(*) FROM resources WHERE capacity_eligible = 1") == 15
    assert [r["rddc"] for r in db.query("SELECT rddc FROM initiatives WHERE id > 0 ORDER BY id")] == [
        "RDDC-24310", "RDDC-24412", "RDDC-24533", "RDDC-24601", "RDDC-24688", "RDDC-24702", "RDDC-24755", "RDDC-24790"]
    pinned = {1: "Tobias Wren", 5: "Felix Hartwell", 14: "Sana Whitfield", 15: "Mateo Brennan", 22: "Clara Pemberton"}
    for rid, name in pinned.items():
        assert db.scalar("SELECT name FROM resources WHERE id = ?", (rid,)) == name
    assert db.scalar("SELECT code FROM dc_components WHERE id = 4") == "CIAM"


@pytest.mark.parametrize("rid, month, hours, available", [
    (14, "2026-11", 115.5, 120), (15, "2026-11", 50.5, 120), (5, "2026-12", 96.0, 80), (12, "2026-12", 145.5, 140),
    (1, "2026-12", 0.0, 147), (5, "2027-01", 81.5, 140)])
def test_pinned_pre_hero_loads(db_conn, rid, month, hours, available):
    booked = db.scalar("SELECT COALESCE(SUM(hours), 0) FROM allocations WHERE resource_id = ? AND month = ?", (rid, month))
    assert booked == pytest.approx(hours)
    assert db.scalar("SELECT available_hours FROM resource_availability WHERE resource_id = ? AND month = ?",
                     (rid, month)) == available


def test_prn_pins(db_conn):
    hero = db.query_one("SELECT funded_hours FROM prn_budget WHERE prn_code = 'PRN-77310'")
    assert hero["funded_hours"] == 1100
    assert db.scalar("SELECT COUNT(*) FROM prn_charges WHERE prn_code = 'PRN-77310'") == 0
    charged = db.scalar("SELECT SUM(charged_hours) FROM prn_charges WHERE prn_code = 'PRN-71840'")
    funded = db.scalar("SELECT funded_hours FROM prn_budget WHERE prn_code = 'PRN-71840'")
    assert round(charged / funded * 100) == 92


def test_seeded_sa_completeness_matches_engine(db_conn):
    from app import repo
    engine = repo.optional_module("app.engines.sa_completeness")
    if engine is None:
        pytest.skip("SA completeness engine not installed")
    for row in db.query("SELECT i.rddc, i.sa_completeness, a.extracted_text FROM initiatives i "
                        "JOIN attachments a ON a.id = i.sa_doc_attachment_id"):
        assert engine.score(row["extracted_text"])["completeness"] == row["sa_completeness"], row["rddc"]


def test_admin_reset_is_idempotent(client):
    client.post("/api/initiatives", json={"name": "Temporary", "lob": "Wealth", "priority": 3, "requestor": "Bea Lindqvist"})
    first = client.post("/api/admin/reset").get_json()
    second = client.post("/api/admin/reset").get_json()
    assert first["ok"] and first["counts"] == second["counts"]
    assert first["counts"]["initiatives"] == 9 and first["counts"]["ai_runs"] == 0
    assert client.get("/api/settings").get_json()["persona"] == "DC PM"
    created = client.post("/api/initiatives", json={"dc_intake": "DCI-3391"}).get_json()
    assert created["initiative"]["rddc"] == "RDDC-24817" and created["initiative"]["id"] == 9


def test_activity_feed(client, hero):
    body = client.get("/api/activity?initiative_id=9&limit=5").get_json()
    assert body["total"] >= 1 and all(r["initiative_id"] == 9 for r in body["items"])
    assert any("RDDC-24817" in r["summary"] for r in body["items"])
    assert client.get("/api/activity?limit=abc").status_code == 422


def test_release_trains(client):
    body = client.get("/api/release-trains").get_json()
    codes = {t["code"]: t for t in body["items"]}
    assert codes["DC-2610"]["status"] == "Done" and codes["DC-2612"]["train_date"] == "2026-12-12"
    assert not any(t["in_freeze"] for t in body["items"])
    assert {i["rddc"] for i in codes["DC-2703"]["initiatives"]} == {"RDDC-24702", "RDDC-24755"}
    assert body["freeze"]["start"] == "2026-12-14"


def test_dc_intakes(client):
    body = client.get("/api/dc-intakes?q=api").get_json()
    assert any(i["code"] == "DCI-3391" for i in body["items"])
    hero = client.get("/api/dc-intakes/DCI-3391").get_json()
    assert (hero["name"], hero["lob"], hero["requestor"], hero["priority"], hero["requested_go_live"]) == (
        "US API Enhancement", "US P&C", "Clara Pemberton", 2, "2027-02-20")
    assert hero["initiative_id"] is None and hero["prn_code"] == "PRN-77310"
    assert client.get("/api/dc-intakes/DCI-0000").status_code == 404
    assert client.get("/api/dc-intakes?q=' OR 1=1--").get_json()["total"] == 0
    linked = client.get("/api/dc-intakes/DCI-3317").get_json()
    assert linked["initiative_id"] == 8


def test_fast_forward_hero(client):
    from app import repo
    if repo.optional_module("app.ai.provider") is None or repo.optional_module("app.ai.apply") is None:
        pytest.skip("AI layer not installed")
    body = client.post("/api/admin/fast-forward-hero").get_json()
    assert body["rddc"] == "RDDC-24817"
    assert next(s["step"] for s in body["steps"]) == "Create initiative"
    assert all(s["ok"] for s in body["steps"]), body["steps"]
    again = client.post("/api/admin/fast-forward-hero").get_json()
    assert again["initiative_id"] == body["initiative_id"]
    assert all(s["ok"] for s in again["steps"])


def test_seed_narrative_consistent(db_conn):
    missing = db.from_json(db.scalar("SELECT sa_missing_json FROM initiatives WHERE id = 7"), [])
    assert missing == ["Non-functional requirements", "Security", "Backout plan"]
    texts = [r["body"] for r in db.query("SELECT body FROM notifications WHERE initiative_id = 7 "
                                         "AND rule = 'sa_action_required' AND dedupe_key LIKE 'sa_action_required:7:%'")]
    texts += [db.scalar("SELECT mitigation FROM risks WHERE initiative_id = 7 AND title LIKE 'SA gaps%'")]
    for text in texts:
        assert "Integration" not in text and "security" in text.lower()
    task = db.query_one("SELECT est_hours, comments FROM wbs_tasks WHERE initiative_id = 1 AND wbs_code = 'WBS-400'")
    assert task["est_hours"] == 180 and "Planned 180 h" in task["comments"]
    assert db.scalar("SELECT requested_go_live FROM dc_intakes WHERE code = 'DCI-3391'") == "2027-02-20"
    notes = db.scalar("SELECT notes_md FROM meeting_notes WHERE title = 'Weekly DC sync'")
    assert "DC-2701" not in notes.split("RDDC-24412 moves to")[1][:20]
