"""Computed view endpoints (B2) on a temp database holding the hero exactly as tests/fixtures/bundle_hero.json."""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import pytest

from app import db
from app.engines import schedule

_spec = importlib.util.spec_from_file_location(
    "b2_hero_db", Path(__file__).resolve().parents[1] / "engines" / "hero_db.py")
hero_db = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(hero_db)

ROOT = Path(__file__).resolve().parents[1]
GOLD = json.loads((ROOT / "golden" / "hero_health.json").read_text(encoding="utf-8"))
HERO = hero_db.HERO_ID


@pytest.fixture()
def app(tmp_path):
    return hero_db.make_app(tmp_path)


@pytest.fixture()
def client(app):
    return app.test_client()


def _dims(h):
    return {k: v["rag"] for k, v in h["dimensions"].items()}


def _new_initiative(app, iid, **values):
    row = {"id": iid, "rddc": f"RDDC-{24900 + iid}", "name": f"Test intake {iid}", "lob": "US P&C", "priority": 2,
           "stage": "Intake", "status": "Backlog", "dc_pm_id": 16, "dc_sa_id": 14, "requestor_id": 22,
           "requestor": "Clara Pemberton", "created_at": "2026-10-19T09:00:00-04:00"}
    row.update(values)
    with app.app_context():
        db.insert("initiatives", row)
    return iid


# ------------------------------------------------------------------ derive + health
def test_derived_allocations_match_frozen_bundle(app):
    with app.app_context():
        rows = db.query("SELECT resource_id, task_id, month, hours, firmness FROM allocations "
                        "WHERE initiative_id = ? AND source = 'derived'", (HERO,))
    got = sorted((r["resource_id"], r["task_id"], r["month"], r["hours"], r["firmness"]) for r in rows)
    want = sorted((a["resource_id"], a["task_id"], a["month"], a["hours"], a["firmness"])
                  for a in hero_db.BUNDLE["allocations"])
    assert got == want


def test_health_matches_deck(client, app):
    exp = GOLD["as_planned"]
    h = client.get(f"/api/initiatives/{HERO}/health").get_json()
    assert h["overall"] == exp["overall"]
    assert _dims(h) == exp["dimensions"]
    assert h["attention"] == exp["attention"]
    with app.app_context():
        row = db.query_one("SELECT rag_cached, health_cached_json FROM initiatives WHERE id = ?", (HERO,))
    assert row["rag_cached"] == "Amber"
    assert json.loads(row["health_cached_json"])["overall"] == "Amber"


def test_suggest_fix_turns_resources_green(client, app):
    from app.services import derive
    with app.app_context(), db.transaction():
        db.execute("UPDATE wbs_tasks SET resource_id = 15 WHERE id = 201")
        derive.rebuild_allocations(HERO)
        derive.refresh_health(HERO)
    h = client.get(f"/api/initiatives/{HERO}/health").get_json()
    exp = GOLD["after_fix_move_wbs100_to_mateo"]
    assert _dims(h) == exp["dimensions"]
    assert h["overall"] == exp["overall"]
    cap = client.get("/api/capacity?from=2026-11&to=2026-11").get_json()
    cells = {r["label"]: r["cells"][0] for r in cap["rows"]}
    assert int(cells["Sana Whitfield"]["util"] * 100 + 0.5) == exp["sana_nov_pct"]
    assert int(cells["Mateo Brennan"]["util"] * 100 + 0.5) == exp["mateo_nov_pct"]


def _apply_dates(app, code, new_end):
    from app import repo
    from app.services import derive
    with app.app_context():
        tasks = repo.get_initiative_bundle(HERO)["tasks"]
        t = next(x for x in tasks if x["wbs_code"] == code)
        t["planned_end"] = new_end
        moved = schedule.propagate_slip(tasks, t["id"])
        with db.transaction():
            db.execute("UPDATE wbs_tasks SET planned_end = ? WHERE id = ?", (new_end, t["id"]))
            for tid, (s, e) in moved.items():
                db.execute("UPDATE wbs_tasks SET planned_start = ?, planned_end = ? WHERE id = ?", (s, e, tid))
            derive.rebuild_allocations(HERO)
            derive.refresh_health(HERO)


def test_wbs210_slip_red_then_back_to_amber(client, app):
    exp = GOLD["wbs210_plus5"]
    _apply_dates(app, "WBS-210", exp["new_end"])
    h = client.get(f"/api/initiatives/{HERO}/health").get_json()
    assert h["overall"] == "Red" and h["dimensions"]["schedule"]["rag"] == "Red"
    g = client.get(f"/api/initiatives/{HERO}/gantt").get_json()
    assert g["readiness_date"] == exp["readiness_date"] and g["float_bd"] == exp["float_bd"]
    _apply_dates(app, "WBS-210", "2027-01-15")
    h = client.get(f"/api/initiatives/{HERO}/health").get_json()
    assert h["overall"] == "Amber" and h["dimensions"]["schedule"]["metrics"]["float_bd"] == 2


def test_override_requires_reason_and_can_be_cleared(client):
    url = f"/api/initiatives/{HERO}/health/override"
    r = client.put(url, json={"dimension": "resources", "rag": "Green", "reason": ""})
    assert r.status_code == 422 and r.get_json()["error"]["details"]["fields"]["reason"]
    assert client.put(url, json={"dimension": "mood", "rag": "Green", "reason": "x"}).status_code == 422
    assert client.put(url, json={"dimension": "resources", "rag": "Purple", "reason": "x"}).status_code == 422
    h = client.put(url, json={"dimension": "resources", "rag": "Green", "reason": "Mateo covers WBS-100"}).get_json()
    assert h["dimensions"]["resources"]["overridden"] is True
    assert h["dimensions"]["resources"]["rag"] == "Green" and h["overall"] == "Amber"
    assert h["attention"] == ["Readiness float 2 business days to DC-2702 affecting WBS-600"]
    h = client.put(url, json={"dimension": "resources", "rag": None, "reason": ""}).get_json()
    assert h["dimensions"]["resources"]["rag"] == "Red" and not h["dimensions"]["resources"]["overridden"]


def test_unknown_initiative_is_json_404(client):
    for path in ("/api/initiatives/999/health", "/api/initiatives/999/gantt", "/api/initiatives/999/resource-grid",
                 "/api/initiatives/999/burndown"):
        r = client.get(path)
        assert r.status_code == 404, path
        assert r.get_json()["error"]["code"] == "not_found"
    assert client.post("/api/initiatives/999/l2/calculate").status_code == 404


# ------------------------------------------------------------------ gantt, capacity, grid
def test_gantt(client):
    g = client.get(f"/api/initiatives/{HERO}/gantt").get_json()
    assert (g["readiness_date"], g["qa_date"], g["prod_date"], g["float_bd"]) == (
        "2027-02-17", "2027-02-10", "2027-02-20", 2)
    assert g["today"] == "2026-10-19"
    assert 201 in g["critical_path"] and len(g["tasks"]) == 14
    assert {t["code"] for t in g["trains"]} >= {"DC-2702", "DC-2703"}


def test_capacity_groupings_and_validation(client):
    cap = client.get("/api/capacity?from=2026-10&to=2027-03").get_json()
    sana = next(r for r in cap["rows"] if r["label"] == "Sana Whitfield")
    nov = next(c for c in sana["cells"] if c["month"] == "2026-11")
    assert (nov["available"], nov["confirmed"] + nov["tentative"], nov["band"]) == (120.0, 154.0, "over")
    teams = client.get("/api/capacity?group=team&from=2026-11&to=2027-01").get_json()
    assert [r["key"] for r in teams["rows"]][:2] == ["EAPI (Dev1)", "EAPI (Dev2)"]
    q = client.get("/api/capacity?group=quarter&from=2026-10&to=2027-03").get_json()
    assert q["months"] == ["FY26-Q4", "FY27-Q1", "FY27-Q2"]
    only = client.get(f"/api/capacity?initiative_id={HERO}&from=2026-10&to=2027-03").get_json()
    assert "Felix Hartwell" not in {r["label"] for r in only["rows"]}
    assert client.get("/api/capacity?from=2026-13").status_code == 422
    assert client.get("/api/capacity?from=Nov").status_code == 422
    assert client.get("/api/capacity?group=galaxy").status_code == 422
    assert client.get("/api/capacity?from=2027-03&to=2026-10").status_code == 422
    assert client.get("/api/capacity?initiative_id=abc").status_code == 422


def test_resource_grid(client):
    grid = client.get(f"/api/initiatives/{HERO}/resource-grid").get_json()
    assert grid["fy"] == "FY27"
    assert [q["label"] for q in grid["quarters"]] == ["Nov–Jan", "Feb–Apr", "May–Jul", "Aug–Oct"]
    sana = next(r for r in grid["rows"] if r["name"] == "Sana Whitfield")
    q1 = sana["cells"][0]
    assert (q1["peak_month"], q1["peak_band"]) == ("2026-11", "over")
    assert q1["availability"] == 360.0
    names = {r["name"] for r in grid["rows"]}
    assert "Clara Pemberton" not in names and "Tobias Wren" in names
    wbs100 = next(a for a in grid["assignments"] if a["wbs_code"] == "WBS-100")
    assert (wbs100["hours"], wbs100["firmness"], wbs100["from"], wbs100["to"]) == (
        70.0, "confirmed", "2026-10-20", "2026-11-17")


# ------------------------------------------------------------------ portfolio
def test_portfolio(client):
    p = client.get("/api/portfolio").get_json()
    assert p["kpis"]["active"] == 2
    assert (p["kpis"]["amber"], p["kpis"]["red"], p["kpis"]["green"]) == (1, 0, 0)
    assert p["kpis"]["overallocated_people"] == 3  # Sana Nov 128%, Felix Dec 120%, Hana Dec 104%
    hero = next(x for x in p["projects"] if x["rddc"] == "RDDC-24817")
    assert hero["rag"] == "Amber" and hero["dimensions"]["resources"] == "Red"
    other = next(x for x in p["projects"] if x["rddc"] == "RDDC-24688")
    assert other["rag"] is None and other["scored"] is False
    assert p["health_tiles"]["overall"]["rddc"] == "RDDC-24817"
    assert p["capacity_period"]["label"] == "Nov–Jan"
    assert [t["team"] for t in p["capacity_teams"] if t["deck"]] == ["EAPI (Dev1)", "EAPI (Dev2)", "CIAM", "SRE"]
    assert client.get("/api/portfolio?rag=Red").get_json()["projects"] == []
    assert len(client.get("/api/portfolio?lob=US%20P%26C").get_json()["projects"]) == 1
    assert client.get("/api/portfolio?rag=Pink").status_code == 422
    assert client.get("/api/portfolio?dc_pm_id=x").status_code == 422


def test_portfolio_gantt(client):
    g = client.get("/api/portfolio/gantt").get_json()
    row = next(r for r in g["rows"] if r["rddc"] == "RDDC-24817")
    assert (row["start"], row["end"], row["rag"]) == ("2026-10-20", "2027-03-05", "Amber")
    assert g["freeze"]["start"] == "2026-12-14"


# ------------------------------------------------------------------ burndown
def test_burndown(client):
    b = client.get(f"/api/initiatives/{HERO}/burndown").get_json()
    assert (b["prn_code"], b["funded_hours"], b["forecast_hours"], b["status"]) == ("PRN-77310", 1100.0, 859.0,
                                                                                   "on_track")
    assert b["forecast_cum"] == [31.5, 205.0, 500.0, 734.0, 841.5, 859.0]
    assert client.get("/api/prn/PRN-77310/burndown").get_json()["forecast_hours"] == 859.0
    assert client.get("/api/prn/PRN-00000/burndown").status_code == 404
    items = client.get("/api/prns").get_json()["items"]
    assert items[0]["prn_code"] == "PRN-77310" and items[0]["charged_hours"] == 0
    r = client.get(f"/api/initiatives/{hero_db.LOAD_ID}/burndown")
    assert r.status_code == 404 and "PRN" in r.get_json()["error"]["message"]


# ------------------------------------------------------------------ L2 workflow
def test_l2_calculate_hero(client):
    est = client.post(f"/api/initiatives/{HERO}/l2/calculate").get_json()
    assert (est["dev_hours"], est["contingency_hours"], est["total_hours"], est["low_hours"], est["high_hours"],
            est["tshirt"]) == (560, 130, 1000, 750, 1250, "L")
    assert client.post(f"/api/initiatives/{HERO}/l2/submit", json={}).status_code == 409


def test_l2_submit_approve_flow(client, app):
    iid = _new_initiative(app, 20, stage="Estimation", sa_completeness=88, requestor_id=23,
                          requestor="Marcus Thorne")
    with app.app_context():
        db.insert("initiative_components", {"initiative_id": iid, "component_id": 2, "complexity": "Medium",
                                            "approval": "Approved"})
        db.insert("initiative_components", {"initiative_id": iid, "component_id": 7, "complexity": "High",
                                            "approval": "Pending"})
    assert client.post(f"/api/initiatives/{iid}/l2/approve", json={}).status_code == 409
    r = client.post(f"/api/initiatives/{iid}/l2/submit", json={})
    assert r.status_code == 200
    body = r.get_json()
    assert body["initiative"]["l2_status"] == "Pending approval"
    assert (body["initiative"]["l2_hours"], body["initiative"]["l2_tshirt"]) == (650, "M")
    assert body["notifications"][0]["to_name"] == "Marcus Thorne"
    assert "Action required by Thu 22 Oct" in body["notifications"][0]["subject"]
    r = client.post(f"/api/initiatives/{iid}/l2/approve", json={"comment": "Agreed in DLR"})
    body = r.get_json()
    assert body["initiative"]["l2_status"] == "Approved" and body["initiative"]["stage"] == "Planning"
    assert body["initiative"]["l2_baseline_hours"] == 650
    assert body["health"]["scored"] is False  # Planning with no WBS yet (QA-C-29)
    assert body["health"]["dimensions"]["schedule"]["reasons"] == ["Generate the project plan to score health."]
    with app.app_context():
        assert db.scalar("SELECT COUNT(*) FROM decisions WHERE initiative_id = ?", (iid,)) == 1
        assert db.scalar("SELECT COUNT(*) FROM notifications WHERE initiative_id = ? AND status = 'Queued' "
                         "AND rule = 'l2_approval'", (iid,)) == 0
    assert client.post(f"/api/initiatives/{iid}/l2/reject", json={"reason": "late"}).status_code == 409


def test_l2_guards(client, app):
    low = _new_initiative(app, 21, stage="Solution", sa_completeness=60)
    with app.app_context():
        db.insert("initiative_components", {"initiative_id": low, "component_id": 2, "complexity": "Low"})
    r = client.post(f"/api/initiatives/{low}/l2/submit", json={})
    assert r.status_code == 422 and "70%" in r.get_json()["error"]["message"]
    empty = _new_initiative(app, 22, stage="Solution", sa_completeness=90)
    assert client.post(f"/api/initiatives/{empty}/l2/submit", json={}).status_code == 422
    assert client.post(f"/api/initiatives/{empty}/l2/reject", json={}).status_code == 422
    assert client.post(f"/api/initiatives/{empty}/l2/submit", data="[1]",
                       content_type="application/json").status_code == 400


def test_l2_reject(client, app):
    iid = _new_initiative(app, 23, stage="Estimation", sa_completeness=88)
    with app.app_context():
        db.insert("initiative_components", {"initiative_id": iid, "component_id": 11, "complexity": "Low"})
    client.post(f"/api/initiatives/{iid}/l2/submit", json={})
    body = client.post(f"/api/initiatives/{iid}/l2/reject", json={"reason": "Scope unclear"}).get_json()
    assert body["initiative"]["l2_status"] == "Rejected"


# ------------------------------------------------------------------ grooming, reminders, governance
def test_slot_grooming_and_invites(app):
    from app.services import derive
    iid = _new_initiative(app, 30)
    with app.app_context():
        placed = derive.slot_grooming(iid)
        assert (placed["session_id"], placed["session_date"], placed["label"]) == (7, "2026-10-20",
                                                                                 "Tue 20 Oct, 10:00")
        assert [n["to_name"] for n in placed["notifications"]] == [
            "Arlo Kingsley", "Grace Ellingham", "Sana Whitfield", "Clara Pemberton"]
        again = derive.slot_grooming(iid)
        assert again["session_id"] == 7 and again["notifications"] == []
        assert derive.slot_grooming(HERO) is None


def test_auto_slot(client, app):
    _new_initiative(app, 31, priority=3)
    _new_initiative(app, 32, priority=1, created_at="2026-10-19T09:20:00-04:00")
    dry = client.post("/api/grooming/auto-slot", json={"dry_run": True}).get_json()
    assert [a["initiative_id"] for a in dry["assignments"]] == [32, 31]
    assert dry["assignments"][0]["session_date"] == "2026-10-20"
    assert dry["dry_run"] is True
    with app.app_context():
        assert db.scalar("SELECT COUNT(*) FROM grooming_slots") == 0
    done = client.post("/api/grooming/auto-slot", json={}).get_json()
    assert len(done["assignments"]) == 2
    assert client.post("/api/grooming/auto-slot", json={}).get_json()["assignments"] == []
    q = client.get("/api/intake-queue").get_json()
    item = next(i for i in q["items"] if i["initiative_id"] == 32)
    assert item["session"]["label"] == "Tue 20 Oct, 10:00"
    assert q["sessions"][0]["free"] == 4


def test_reminders_run_is_idempotent(client, app):
    # SA waiting since Mon 19 Oct, every 2 bd: Wed 21, Fri 23. Only reminders due on or before "now" are queued.
    _new_initiative(app, 40, stage="Solution", sa_completeness=60, sa_missing_json='["Backout plan"]',
                    dc_sa_id=15)
    first = client.post("/api/reminders/run", json={}).get_json()
    assert not [n for n in first["created"] if n["initiative_id"] == 40]
    on21 = client.post("/api/reminders/run", json={"now": "2026-10-21"}).get_json()
    assert "sa_action_required:initiative:40:2026-10-21" in [n["dedupe_key"] for n in on21["created"]]
    again = client.post("/api/reminders/run", json={"now": "2026-10-21"}).get_json()
    assert again["created"] == [] and again["skipped"] == len(on21["created"])
    on23 = client.post("/api/reminders/run", json={"now": "2026-10-23"}).get_json()
    assert "sa_action_required:initiative:40:2026-10-23" in [n["dedupe_key"] for n in on23["created"]]
    with app.app_context():
        rows = db.query("SELECT due_at, status FROM notifications WHERE initiative_id = 40 "
                        "AND rule = 'sa_action_required' ORDER BY due_at")
    assert [(r["due_at"], r["status"]) for r in rows] == [("2026-10-21", "Dismissed"), ("2026-10-23", "Queued")]
    assert client.post("/api/reminders/run", json={"now": "next week"}).status_code == 422
    assert client.post("/api/reminders/run", json={"now": 5}).status_code == 422


def test_governance_weekly_and_approvals(client, app):
    with app.app_context():
        db.insert("change_requests", {
            "initiative_id": HERO, "crq_number": "CRQ0001040777", "raised_at": "2026-10-12",
            "crq_start": "2026-10-24T02:00:00-04:00", "crq_end": "2026-10-24T06:00:00-04:00",
            "release_type": "Independent", "affected_cis": '["API-PLATFORM"]', "impacted_components": '["APIP"]',
            "cms_lead_id": 19, "rel_lead_id": 20, "sto_approval": "Tentative Go"})
    w = client.get("/api/governance/weekly?week=2026-W43").get_json()
    assert (w["from"], w["to"]) == ("2026-10-19", "2026-11-01")
    assert w["items"][0]["crq_number"] == "CRQ0001040777"
    assert "CR-11" in [f["code"] for f in w["items"][0]["compliance"]["flags"]]
    assert w["noncompliant_count"] == 1
    assert client.get("/api/governance/weekly?week=W43").status_code == 422
    assert client.get("/api/governance/weekly").get_json()["week"] == "2026-W43"
    approvals = client.get("/api/governance/approvals").get_json()["items"]
    kinds = {(a["kind"], a["approver"]) for a in approvals}
    assert ("component", "Mira Castellane") in kinds and ("sto", "STO Board") in kinds
    p = client.get("/api/portfolio").get_json()
    assert p["kpis"]["crqs_this_week"] == 1
    assert p["change_mgmt"][0]["compliance_flags"]


# ------------------------------------------------------------------ round 1 (L5-01, L5-10) on the real demo seed
@pytest.fixture()
def seeded(tmp_path):
    seed = pytest.importorskip("app.seed.seed")
    from app import create_app
    app = create_app(DB_PATH=str(tmp_path / "seed.db"), UPLOAD_DIR=str(tmp_path / "uploads"), TESTING=True,
                     AI_MODE="simulated")
    with app.app_context():
        seed.reset_database(upload_dir=tmp_path / "uploads", today="2026-10-19", ai_mode="simulated")
    return app


def _rags_everywhere(client):
    portfolio = {p["id"]: p["rag"] for p in client.get("/api/portfolio").get_json()["projects"]}
    listed = {r["id"]: r["rag"] for r in client.get("/api/initiatives").get_json()["items"]}
    single = {}
    for iid in portfolio:
        ini = client.get(f"/api/initiatives/{iid}").get_json()["initiative"]
        cached = (ini.get("health_cached_json") or {}).get("overall")
        single[iid] = (ini["rag_cached"], cached)
    trains = {}
    for t in client.get("/api/release-trains").get_json()["items"]:
        for i in t["initiatives"]:
            trains[i["id"]] = i["rag"]
    return portfolio, listed, single, trains


def test_l5_01_rag_identical_everywhere_after_hero(seeded):
    client = seeded.test_client()
    r = client.post("/api/admin/fast-forward-hero", json={})
    assert r.status_code == 200 and all(s["ok"] for s in r.get_json()["steps"])
    portfolio, listed, single, trains = _rags_everywhere(client)
    assert portfolio and all(iid > 0 for iid in portfolio)  # hidden BAU pseudo-initiative never listed
    for iid, rag in portfolio.items():
        assert listed[iid] == rag, iid
        assert single[iid] == (rag, rag), iid
        if iid in trains:
            assert trains[iid] == rag, iid


def test_l5_10_reminders_never_duplicate(seeded):
    client = seeded.test_client()
    client.post("/api/admin/fast-forward-hero", json={})
    client.post("/api/reminders/run", json={})
    second = client.post("/api/reminders/run", json={}).get_json()
    assert second["created"] == []
    with seeded.app_context():
        rows = db.query("SELECT rule, entity_type, entity_id, to_name, substr(due_at, 1, 10) AS due "
                        "FROM notifications WHERE status = 'Queued' AND entity_id IS NOT NULL")
    keys = [(r["rule"], r["entity_type"], r["entity_id"], r["to_name"], r["due"]) for r in rows]
    assert len(keys) == len(set(keys))
    items = [(r["rule"], r["entity_type"], r["entity_id"]) for r in rows
             if r["rule"] in ("sa_action_required", "component_approval", "l2_approval", "l2_escalation")]
    assert len(items) == len(set(items)), "one queued reminder per waiting item"
    assert all(r["due"] <= "2026-10-19" for r in rows if r["rule"] != "grooming_invite")


def test_qa_c13_status_follows_stage(client, app):
    from app.services import derive
    iid = _new_initiative(app, 50, stage="Planning", status="Backlog")
    with app.app_context():
        derive.refresh_health(iid)
        assert db.scalar("SELECT status FROM initiatives WHERE id = ?", (iid,)) == "In progress"
        db.execute("UPDATE initiatives SET stage = 'Closed' WHERE id = ?", (iid,))
        derive.refresh_health(iid)
        assert db.scalar("SELECT status FROM initiatives WHERE id = ?", (iid,)) == "Completed"
        assert db.scalar("SELECT status FROM initiatives WHERE id = ?", (hero_db.LOAD_ID,)) == "Backlog"
    h = client.get(f"/api/initiatives/{iid}/health").get_json()
    assert h["scored"] is False  # Closed but no WBS rows: nothing to score


def test_qa_c11_hero_crq_draft_on_real_seed(seeded):
    from app.services import derive
    client = seeded.test_client()
    client.post("/api/admin/fast-forward-hero", json={})
    with seeded.app_context():
        hero = db.scalar("SELECT id FROM initiatives WHERE rddc = 'RDDC-24817'")
    r = client.post(f"/api/initiatives/{hero}/change-requests/draft", json={})
    assert r.status_code in (200, 201)
    cid = r.get_json()["id"]
    with seeded.app_context():
        cr = derive.change_requests_with_compliance("WHERE cr.id = ?", (cid,))[0]
        assert [f["code"] for f in cr["compliance"]["flags"]] == ["CR-11"]
        assert cr["compliance"]["sto_suggestion"] is None  # round 2 decision 2: no suggestion before T-5
        f12 = next(f for f in cr["compliance"]["findings"] if f["rule_id"] == "CR-12")
        assert (f12["status"], f12["detail"]) == ("Pass", "Window matches WBS-700 on Sat 20 Feb 2027.")
    t210 = None
    with seeded.app_context():
        t210 = db.scalar("SELECT id FROM wbs_tasks WHERE initiative_id = ? AND wbs_code = 'WBS-210'", (hero,))
    assert client.put(f"/api/tasks/{t210}", json={"planned_end": "2027-01-22"}).status_code == 200
    with seeded.app_context():
        assert derive.production_date(hero) == "2027-03-20"
        cr = derive.change_requests_with_compliance("WHERE cr.id = ?", (cid,))[0]
        assert {"CR-11", "CR-12", "CR-13"} <= {f["code"] for f in cr["compliance"]["flags"]}


def test_r2_portfolio_comment_fallback_and_shared_attention(client):
    p = client.get("/api/portfolio").get_json()
    hero = next(x for x in p["projects"] if x["rddc"] == "RDDC-24817")
    assert hero["comments"] == "Planned for DC-2702; L2 1,000 h approved; 2 business days float"
    assert hero["comments_auto"] is True
    h = client.get(f"/api/initiatives/{HERO}/health").get_json()
    assert hero["attention"] == h["attention"]
    cap = client.get("/api/capacity?from=2026-10&to=2026-11").get_json()
    assert [c["quarter"] for c in cap["columns"]] == ["Q4 FY26", "Q1 FY27"]
    teams = client.get("/api/capacity?group=team&from=2026-11&to=2026-11").get_json()
    assert "EAPI Tech Lead" in [r["key"] for r in teams["rows"]] and "EAPI" not in [r["key"] for r in teams["rows"]]


def test_r3_portfolio_rule_text_and_export_action_line(client):
    p = client.get("/api/portfolio").get_json()
    assert p["rule_text"] == ("Overall is Red if Schedule is Red or two or more dimensions are Red; Amber if any "
                              "dimension is Red or Amber; otherwise Green.")
    from app.api import export
    line = export._action_text({"owner_name": "Sana Whitfield", "due": "2026-10-21",
                                "what": "Add the Backout plan section to the SA document"})
    assert line == "Sana Whitfield · Wed 21 Oct 2026 · Add the Backout plan section to the SA document"
