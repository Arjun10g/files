"""Regression tests for QA round 1 (docs/qa/round1_L5_redteam.md): L5-05, L5-07, L5-09, L5-11, L5-15."""
from __future__ import annotations

import io
import threading

import pytest

from app import db, repo


def _needs_engines():
    if repo.optional_module("app.engines.schedule") is None or repo.optional_module("app.engines.calendar") is None:
        pytest.skip("schedule engine not installed")


def _plan(client):
    a = client.post("/api/initiatives/9/tasks", json={
        "wbs_code": "WBS-100", "step": "Estimation", "phase": "Estimation", "resource_id": 14,
        "planned_start": "2026-10-20", "planned_end": "2026-11-17", "est_hours": 70, "allocation_pct": 50}).get_json()["task"]
    b = client.post("/api/initiatives/9/tasks", json={
        "wbs_code": "WBS-210", "step": "API Platform", "phase": "Development", "resource_id": 1,
        "planned_start": "2026-11-18", "planned_end": "2027-01-15", "est_hours": 280, "allocation_pct": 100,
        "depends_on": [a["id"]]}).get_json()["task"]
    return a, b


def _end(start, hours, pct):
    from app.engines import calendar as cal
    from app.engines import schedule
    return cal.end_after_business_days(start, schedule.duration_from_hours(hours, pct)).isoformat()


def test_l5_05_alloc_pct_edit_moves_end_and_dependants(client, hero):
    _needs_engines()
    a, _b = _plan(client)
    resp = client.put(f"/api/tasks/{a['id']}", json={"allocation_pct": 25}).get_json()
    assert resp["task"]["planned_end"] == _end("2026-10-20", 70, 25)
    moved = {t["wbs_code"]: t for t in resp["shifted_tasks"]}
    assert moved["WBS-210"]["planned_start"] > "2026-11-18"
    back = client.put(f"/api/tasks/{a['id']}", json={"allocation_pct": 50}).get_json()
    assert back["task"]["planned_end"] == "2026-11-17"


def test_l5_05_hours_edit_in_bulk_and_explicit_end_wins(client, hero, db_conn):
    _needs_engines()
    _, b = _plan(client)
    resp = client.put("/api/initiatives/9/tasks/bulk", json={"tasks": [{"id": b["id"], "allocation_pct": 50}]})
    item = next(t for t in resp.get_json()["items"] if t["wbs_code"] == "WBS-210")
    assert item["planned_end"] == _end("2026-11-18", 280, 50)
    explicit = client.put(f"/api/tasks/{b['id']}", json={"est_hours": 300, "planned_end": "2027-01-22"}).get_json()
    assert explicit["task"]["planned_end"] == "2027-01-22" and explicit["task"]["est_hours"] == 300


def test_l5_05_milestone_keeps_its_date(client, hero):
    _needs_engines()
    ms = client.post("/api/initiatives/9/tasks", json={
        "wbs_code": "WBS-700", "step": "Production", "phase": "Production", "is_milestone": 1, "resource_id": 20,
        "planned_start": "2027-02-20", "planned_end": "2027-02-20", "est_hours": 6}).get_json()["task"]
    resp = client.put(f"/api/tasks/{ms['id']}", json={"est_hours": 12}).get_json()
    assert resp["task"]["planned_end"] == "2027-02-20"


def test_l5_07_concurrent_creates_of_one_intake(app):
    results = []

    def create():
        results.append(app.test_client().post("/api/initiatives", json={"dc_intake": "DCI-3391"}).status_code)

    threads = [threading.Thread(target=create) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert sorted(results) == [201, 409, 409, 409]
    with app.app_context():
        assert db.scalar("SELECT COUNT(*) FROM initiatives WHERE dc_intake = 'DCI-3391'") == 1


def test_l5_09_reset_never_500s_concurrent_requests(app):
    statuses, stop = [], threading.Event()

    def poll(path):
        client = app.test_client()
        while not stop.is_set():
            statuses.append(client.get(path).status_code)

    threads = [threading.Thread(target=poll, args=(p,)) for p in
               ("/api/initiatives", "/api/outbox", "/api/initiatives/2", "/api/change-requests")]
    for t in threads:
        t.start()
    client = app.test_client()
    try:
        for _ in range(4):
            assert client.post("/api/admin/reset").status_code == 200
    finally:
        stop.set()
        for t in threads:
            t.join()
    assert statuses and 500 not in statuses
    assert set(statuses) <= {200, 503}


def test_l5_15_non_ascii_file_name(client, hero):
    form = {"file": (io.BytesIO("设计文档 text for the upload".encode()), "设计.txt"), "kind": "other"}
    resp = client.post("/api/initiatives/9/attachments", data=form, content_type="multipart/form-data")
    assert resp.status_code == 201
    assert resp.get_json()["attachment"]["filename"] == "upload.txt"
    bad = {"file": (io.BytesIO(b"text"), "设计.exe"), "kind": "other"}
    assert client.post("/api/initiatives/9/attachments", data=bad, content_type="multipart/form-data").status_code == 422


def test_l5_11_crq_read_model_keeps_ai_review(client, db_conn):
    review = {"ok": False, "flags": [], "ai": {"score": 72, "reviewer_note": "Attach the backout plan.", "ai_run_id": None,
                                               "sto_readiness": "Tentative", "findings": []}}
    db.execute("UPDATE change_requests SET compliance_json = ? WHERE id = 4", (db.to_json(review),))
    body = client.get("/api/change-requests/4").get_json()
    assert body["compliance"]["ai"]["reviewer_note"] == "Attach the backout plan."
    assert body["compliance_json"]["ai"]["score"] == 72
    assert "flags" in body["compliance"]
    client.put("/api/change-requests/4", json={"crq_approval_status": "Approved"})
    after = client.get("/api/change-requests?initiative_id=4").get_json()["items"][0]
    assert after["compliance"]["ai"]["score"] == 72 and after["crq_approval_status"] == "Approved"


def test_qa_a_07_invalid_list_filters(client):
    assert client.get("/api/initiatives?dc_pm_id=abc").status_code == 422
    assert client.get("/api/initiatives?priority=abc").status_code == 422
    assert client.get("/api/initiatives?rag=Purple").status_code == 422
    assert client.get("/api/initiatives?stage=Done").status_code == 422
    assert client.get("/api/initiatives?rag=Red,none&dc_pm_id=16").status_code == 200


def test_qa_a_08_upload_of_exactly_10_mb(client, hero, app):
    limit = app.config.get("MAX_UPLOAD_BYTES", 10 * 1024 * 1024)
    form = {"file": (io.BytesIO(b"a" * limit), "notes.txt"), "kind": "other"}
    assert client.post("/api/initiatives/9/attachments", data=form, content_type="multipart/form-data").status_code == 201
    form = {"file": (io.BytesIO(b"a" * (limit + 1)), "notes.txt"), "kind": "other"}
    resp = client.post("/api/initiatives/9/attachments", data=form, content_type="multipart/form-data")
    assert resp.status_code == 413 and "10 MB" in resp.get_json()["error"]["message"]


def test_qa_c_02_intake_people_prefill(client, db_conn):
    intake = client.get("/api/dc-intakes/DCI-3391").get_json()
    assert (intake["dc_pm_id"], intake["dc_sa_id"], intake["tech_lead_id"], intake["pm_id"]) == (16, 14, 3, 16)
    assert intake["dc_sa_name"] == "Sana Whitfield" and intake["tech_lead_name"] == "Devon Achterberg"
    created = client.post("/api/initiatives", json={"dc_intake": "DCI-3391"}).get_json()
    ini = created["initiative"]
    assert (ini["dc_pm_name"], ini["dc_sa_name"], ini["tech_lead_name"], ini["pm_name"]) == (
        "Grace Ellingham", "Sana Whitfield", "Devon Achterberg", "Grace Ellingham")
    if created["grooming"] is not None:
        assert "Sana Whitfield" in {n["to_name"] for n in created["queued_notifications"]}
    form = {"file": (io.BytesIO(b"Solution Architecture\nVersion 1.2 Author: Sana Whitfield\n\n1. Business context\nAPIs.\n"),
                     "sa.txt"), "kind": "sa_doc"}
    assert client.post(f"/api/initiatives/{ini['id']}/attachments", data=form,
                       content_type="multipart/form-data").status_code == 201
    queue = client.get("/api/intake-queue")
    if queue.status_code == 200:
        item = next(i for i in queue.get_json()["items"] if i["rddc"] == "RDDC-24817")
        assert item["action_required_by"] == "2026-10-21" and "Sana Whitfield" in (item["waiting_on"] or "")
    explicit = client.post("/api/initiatives", json={"dc_intake": "DCI-3402", "dc_sa_id": 14}).get_json()["initiative"]
    assert explicit["dc_sa_id"] == 14 and explicit["dc_pm_id"] == 17


def test_qa_c_20_blank_crq_without_plan(client):
    resp = client.post("/api/initiatives/8/change-requests",
                       json={"release_type": "Bundle", "target_release": None, "release_train": None})
    assert resp.status_code == 201
    cr = resp.get_json()
    assert cr["crq_number"] is None and cr["release_train"] is None and "compliance" in cr
    bad = client.post("/api/initiatives/8/change-requests", json={"release_type": "Monthly"})
    assert bad.status_code == 422 and "release_type" in bad.get_json()["error"]["details"]["fields"]


def _fast_forward(client):
    if repo.optional_module("app.ai.provider") is None or repo.optional_module("app.services.derive") is None:
        pytest.skip("AI layer or derive service not installed")
    body = client.post("/api/admin/fast-forward-hero").get_json()
    assert all(s["ok"] for s in body["steps"]), body["steps"]
    return body["initiative_id"]


def test_qa_c_11_hero_draft_unslipped_has_one_flag(client):
    iid = _fast_forward(client)
    cr = client.post(f"/api/initiatives/{iid}/change-requests/draft").get_json()
    assert cr["crq_start"] == "2027-02-20T02:00:00-05:00" and cr["release_train"] == "DC-2702"
    assert cr["sto_approval"] is None and cr["crq_number"] == "CRQ000001052216"
    assert [f["code"] for f in cr["compliance"]["flags"]] == ["CR-11"]


def test_qa_c_11_draft_window_follows_wbs_700_after_slip(client, db_conn):
    iid = _fast_forward(client)
    t210 = db.query_one("SELECT id, planned_end FROM wbs_tasks WHERE initiative_id = ? AND wbs_code = 'WBS-210'", (iid,))
    from app.engines import calendar as cal
    new_end = cal.add_business_days(t210["planned_end"], 5).isoformat()
    assert client.put(f"/api/tasks/{t210['id']}", json={"planned_end": new_end}).status_code == 200
    prod = db.scalar("SELECT planned_start FROM wbs_tasks WHERE initiative_id = ? AND wbs_code = 'WBS-700'", (iid,))
    assert prod > "2027-02-20"
    cr = client.post(f"/api/initiatives/{iid}/change-requests/draft").get_json()
    assert cr["crq_start"].startswith(prod)
    codes = {f["code"] for f in cr["compliance"]["flags"]}
    assert "CR-13" in codes and cr["sto_approval"] is None
    listed = client.get(f"/api/change-requests?initiative_id={iid}").get_json()["items"][0]
    assert "CR-13" in {f["code"] for f in listed["compliance"]["flags"]}


def test_independent_crq_skips_plan_alignment(client):
    crs = {c["crq_number"]: c for c in client.get("/api/change-requests").get_json()["items"]}
    assert crs["CRQ000001045902"]["compliance"]["ok"] is True
