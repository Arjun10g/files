"""Project plan: WBS steps CRUD, date and dependency validation, slip propagation, bulk save, re-baseline."""
from __future__ import annotations

from app import db


def _task(client, iid, **body):
    base = {"wbs_code": "WBS-100", "step": "Estimation & solution finalization", "phase": "Estimation",
            "resource_id": 14, "owner_id": 14, "planned_start": "2026-10-20", "planned_end": "2026-11-17",
            "est_hours": 70, "allocation_pct": 50}
    base.update(body)
    return client.post(f"/api/initiatives/{iid}/tasks", json=base)


def test_create_list_update_delete(client, hero):
    resp = _task(client, 9)
    assert resp.status_code == 201
    body = resp.get_json()
    task = body["task"]
    assert task["wbs_code"] == "WBS-100" and task["resource_name"] == "Sana Whitfield" and task["depends_on"] == []
    assert set(body) == {"task", "shifted_tasks", "health"}
    dev = _task(client, 9, wbs_code="WBS-210", step="API Platform", phase="Development", resource_id=1,
                planned_start="2026-11-18", planned_end="2027-01-15", est_hours=280, allocation_pct=100,
                depends_on=[task["id"]]).get_json()["task"]
    assert dev["depends_on_codes"] == ["WBS-100"]
    listed = client.get("/api/initiatives/9/tasks").get_json()
    assert [t["wbs_code"] for t in listed["items"]] == ["WBS-100", "WBS-210"]
    upd = client.put(f"/api/tasks/{task['id']}", json={"status": "Completed", "comments": "SA signed off"})
    assert upd.status_code == 200 and upd.get_json()["task"]["pct"] == 100
    ini = client.get("/api/initiatives/9").get_json()["initiative"]
    assert ini["planned_start"] == "2026-10-20" and ini["planned_end"] == "2027-01-15"
    assert client.delete(f"/api/tasks/{dev['id']}").get_json()["ok"] is True
    assert client.delete(f"/api/tasks/{dev['id']}").status_code == 404


def test_hero_task_allocations(client, hero, db_conn):
    _task(client, 9)
    from app import repo
    if repo.optional_module("app.services.derive") is None:
        return
    hours = {r["month"]: r["hours"] for r in db.query(
        "SELECT month, SUM(hours) AS hours FROM allocations WHERE initiative_id = 9 GROUP BY month")}
    assert hours == {"2026-10": 31.5, "2026-11": 38.5}
    sana = db.scalar("SELECT SUM(hours) FROM allocations WHERE resource_id = 14 AND month = '2026-11'")
    assert sana == 154.0


def test_validation_errors(client, hero):
    bad = _task(client, 9, planned_start="2026-11-17", planned_end="2026-10-20")
    assert bad.status_code == 422 and "planned_end" in bad.get_json()["error"]["details"]["fields"]
    assert _task(client, 9, wbs_code="100").status_code == 422
    assert _task(client, 9, phase="Coding").status_code == 422
    assert _task(client, 9, allocation_pct=150).status_code == 422
    assert _task(client, 9, est_hours="lots").status_code == 422
    assert _task(client, 9, resource_id=999).status_code == 422
    assert _task(client, 9, depends_on=[1]).status_code == 422
    assert _task(client, 9, depends_on="WBS-100").status_code == 422
    assert _task(client, 9, step="").status_code == 422
    assert _task(client, 999).status_code == 404
    first = _task(client, 9).get_json()["task"]
    assert _task(client, 9).status_code == 409
    assert client.put(f"/api/tasks/{first['id']}", json={"planned_end": "2026-10-01"}).status_code == 422
    assert client.put(f"/api/tasks/{first['id']}", json={"depends_on": [first["id"]]}).status_code == 422
    assert client.put(f"/api/tasks/{first['id']}", json={"parent_id": first["id"]}).status_code == 422
    assert client.put("/api/tasks/99999", json={"pct": 10}).status_code == 404


def test_dependency_cycle_rejected(client, hero):
    a = _task(client, 9).get_json()["task"]
    b = _task(client, 9, wbs_code="WBS-210", step="Build", depends_on=[a["id"]]).get_json()["task"]
    resp = client.put(f"/api/tasks/{a['id']}", json={"depends_on": [b["id"]]})
    assert resp.status_code == 422 and "loop" in resp.get_json()["error"]["message"]
    assert client.get("/api/initiatives/9/tasks").get_json()["items"][0]["depends_on"] == []


def test_slip_propagates_to_dependants(client, hero):
    from app import repo
    a = _task(client, 9).get_json()["task"]
    b = _task(client, 9, wbs_code="WBS-210", step="Build", phase="Development", resource_id=1,
              planned_start="2026-11-18", planned_end="2026-11-24", depends_on=[a["id"]]).get_json()["task"]
    resp = client.put(f"/api/tasks/{a['id']}", json={"planned_end": "2026-11-24"}).get_json()
    if repo.optional_module("app.engines.schedule") is None:
        return
    shifted = {t["wbs_code"]: t for t in resp["shifted_tasks"]}
    assert shifted["WBS-210"]["planned_start"] == "2026-11-25"
    assert client.get("/api/initiatives/9/tasks").get_json()["items"][1]["id"] == b["id"]


def test_bulk_save(client, hero):
    a = _task(client, 9).get_json()["task"]
    resp = client.put("/api/initiatives/9/tasks/bulk", json={"tasks": [
        {"id": a["id"], "pct": 40, "status": "In progress"},
        {"wbs_code": "WBS-400", "step": "QA", "phase": "QA", "resource_id": 12, "planned_start": "2027-02-01",
         "planned_end": "2027-02-10", "est_hours": 56, "allocation_pct": 100}]})
    assert resp.status_code == 200
    items = {t["wbs_code"]: t for t in resp.get_json()["items"]}
    assert items["WBS-100"]["pct"] == 40 and items["WBS-400"]["resource_name"] == "Hana Brightwater"
    bad = client.put("/api/initiatives/9/tasks/bulk", json={"tasks": [{"id": a["id"], "planned_end": "2026-01-01"}]})
    assert bad.status_code == 422 and "tasks[0].planned_end" in bad.get_json()["error"]["details"]["fields"]
    assert client.put("/api/initiatives/9/tasks/bulk", json={"tasks": []}).status_code == 422
    assert client.put("/api/initiatives/9/tasks/bulk", json={"tasks": [{"id": 1, "pct": 5}]}).status_code == 422
    assert client.put("/api/initiatives/999/tasks/bulk", json={"tasks": [{"id": 1}]}).status_code == 404


def test_rebaseline(client, hero, db_conn):
    assert client.post("/api/initiatives/9/baseline", json={"reason": "No plan yet"}).status_code == 422
    a = _task(client, 9).get_json()["task"]
    client.put(f"/api/tasks/{a['id']}", json={"planned_end": "2026-11-20"})
    assert client.post("/api/initiatives/9/baseline", json={}).status_code == 422
    resp = client.post("/api/initiatives/9/baseline", json={"reason": "Partner SLA moved"})
    assert resp.status_code == 200 and resp.get_json()["ok"] is True
    assert db.scalar("SELECT baseline_end FROM wbs_tasks WHERE id = ?", (a["id"],)) == "2026-11-20"
    assert db.scalar("SELECT COUNT(*) FROM decisions WHERE initiative_id = 9 AND title = 'Plan re-baselined'") == 1
    assert client.post("/api/initiatives/999/baseline", json={"reason": "x"}).status_code == 404


def test_list_tasks_unknown(client):
    assert client.get("/api/initiatives/999/tasks").status_code == 404
