"""Change requests (with compliance and the deterministic draft), risks, grooming sessions/slots and the Outbox."""
from __future__ import annotations

from app import repo


def test_list_change_requests(client):
    body = client.get("/api/change-requests").get_json()
    assert body["total"] == 6
    assert all("compliance" in cr and "flags" in cr["compliance"] for cr in body["items"])
    numbers = {cr["crq_number"]: cr for cr in body["items"]}
    assert numbers["CRQ000001045310"]["sto_approval"] == "Tentative No Go"
    assert numbers["CRQ000001045310"]["affected_cis"][0] == "PAYMENTS-HUB"
    week = client.get("/api/change-requests?week=2026-W43").get_json()
    assert {cr["crq_number"] for cr in week["items"]} == {"CRQ000001045902", "CRQ000001046031"}
    assert client.get("/api/change-requests?initiative_id=3").get_json()["total"] == 2
    assert client.get("/api/change-requests?from=2026-12-01&to=2026-12-31").get_json()["total"] == 2
    assert client.get("/api/change-requests?week=43").status_code == 422
    assert client.get("/api/change-requests?from=Dec").status_code == 422


def test_seeded_compliance_mix(client):
    if repo.optional_module("app.engines.compliance") is None:
        return
    crs = {cr["crq_number"]: cr["compliance"] for cr in client.get("/api/change-requests").get_json()["items"]}
    assert crs["CRQ000001045902"]["ok"] is True
    flagged = {code: {f["code"] for f in c["flags"]} for code, c in crs.items()}
    assert "CR-06" in flagged["CRQ000001046488"]
    assert "CR-05" in flagged["CRQ000000417305"]
    assert "CR-11" in flagged["CRQ000000421907"]


def test_get_create_update_delete_change_request(client):
    assert client.get("/api/change-requests/1").get_json()["crq_number"] == "CRQ000001045310"
    assert client.get("/api/change-requests/999").status_code == 404
    resp = client.post("/api/initiatives/5/change-requests", json={
        "crq_number": "CRQ0001050100", "crq_start": "2027-02-20T02:00", "crq_end": "2027-02-20T06:00",
        "release_type": "Bundle", "release_train": "DC-2702", "affected_cis": ["STATEMENTS"],
        "impacted_components": ["STMT"], "cms_lead_id": 19, "rel_lead_id": 20})
    assert resp.status_code == 201
    cr = resp.get_json()
    assert cr["crq_start"] == "2027-02-20T02:00:00-05:00" and cr["target_release"] == "DC-2702"
    assert cr["implementation_status"] == "Not Started" and "compliance" in cr
    upd = client.put(f"/api/change-requests/{cr['id']}", json={"sto_approval": "Go"})
    assert upd.status_code == 200 and upd.get_json()["sto_approval"] == "Go"
    assert client.put(f"/api/change-requests/{cr['id']}", json={"crq_end": "2027-02-19T06:00"}).status_code == 422
    assert client.delete(f"/api/change-requests/{cr['id']}").get_json() == {"ok": True}


def test_change_request_bad_input(client):
    post = lambda body: client.post("/api/initiatives/5/change-requests", json=body)
    assert post({"crq_start": "2027-02-20T06:00", "crq_end": "2027-02-20T02:00"}).status_code == 422
    assert post({"sto_approval": "Maybe"}).status_code == 422
    assert post({"crq_number": "12345"}).status_code == 422
    assert post({"impacted_components": ["NOPE"]}).status_code == 422
    assert post({"release_train": "DC-9999"}).status_code == 422
    assert post({"crq_start": "tomorrow"}).status_code == 422
    assert post({"crq_number": "CRQ000001045310"}).status_code == 409
    assert client.post("/api/initiatives/999/change-requests", json={}).status_code == 404


def test_crq_draft_for_hero(client, hero):
    for code, complexity in (("APIP", "High"), ("EDP", "Medium"), ("CIAM", "Medium"), ("SRE", "Low")):
        client.post("/api/initiatives/9/components", json={"component_code": code, "complexity": complexity})
    resp = client.post("/api/initiatives/9/change-requests/draft")
    assert resp.status_code == 201
    cr = resp.get_json()
    assert cr["crq_number"] == "CRQ000001052216"
    assert cr["crq_start"] == "2027-02-20T02:00:00-05:00" and cr["crq_end"] == "2027-02-20T06:00:00-05:00"
    assert cr["release_type"] == "Bundle" and cr["release_train"] == "DC-2702"
    assert cr["affected_cis"] == ["API-PLATFORM", "EDP", "CIAM", "OBSERVABILITY"]
    assert cr["cms_lead_name"] == "Petra Vallance" and cr["rel_lead_name"] == "Owen Stroud"
    assert cr["sto_approval"] is None
    if repo.optional_module("app.engines.compliance") is not None:
        assert [f["message"] for f in cr["compliance"]["flags"]] == ["Backout plan not attached"]
    again = client.post("/api/initiatives/9/change-requests/draft")
    assert again.status_code == 200 and again.get_json()["id"] == cr["id"]


def test_crq_draft_needs_target_release(client):
    resp = client.post("/api/initiatives/8/change-requests/draft")
    assert resp.status_code == 422
    assert client.post("/api/initiatives/999/change-requests/draft").status_code == 404


def test_risks_crud(client):
    body = client.get("/api/risks?initiative_id=2").get_json()
    assert body["total"] == 3 and body["items"][0]["score"] == 12
    assert client.get("/api/risks?status=Closed").get_json()["total"] == 1
    assert all(r["score"] >= 9 for r in client.get("/api/risks?min_score=9").get_json()["items"])
    resp = client.post("/api/initiatives/9/risks", json={})
    assert resp.status_code in (404, 422)
    resp = client.post("/api/initiatives/5/risks", json={"title": "Archive backfill overruns", "category": "Schedule",
                                                         "severity": 3, "likelihood": 2, "owner_id": 2})
    assert resp.status_code == 201
    risk = resp.get_json()
    assert risk["risk_code"] == "RSK-013" and risk["score"] == 6 and risk["owner_name"] == "Lena Oduya"
    upd = client.put(f"/api/risks/{risk['id']}", json={"status": "Mitigating", "likelihood": 4})
    assert upd.get_json()["score"] == 12 and upd.get_json()["status"] == "Mitigating"
    assert client.post("/api/initiatives/5/risks", json={"title": "x", "category": "Weather", "severity": 5,
                                                         "likelihood": 0}).status_code == 422
    assert client.put(f"/api/risks/{risk['id']}", json={"task_id": 1}).status_code == 422
    assert client.delete(f"/api/risks/{risk['id']}").get_json() == {"ok": True}
    assert client.put(f"/api/risks/{risk['id']}", json={"status": "Open"}).status_code == 404
    assert client.get("/api/risks?min_score=abc").status_code == 422


def test_grooming_sessions_and_slots(client):
    body = client.get("/api/grooming/sessions?from=2026-10-20&to=2026-10-22").get_json()
    assert [s["session_date"] for s in body["items"]] == ["2026-10-20", "2026-10-22"]
    tue = body["items"][0]
    assert len(tue["slots"]) <= 5 and tue["start_time"] == "10:00" and tue["capacity"] == 6
    thu = body["items"][1]
    assert thu["slots"][0]["rddc"] == "RDDC-24790"
    assert {p["name"] for p in thu["slots"][0]["recipients"]} >= {"Arlo Kingsley", "Grace Ellingham"}
    resp = client.post("/api/grooming/sessions", json={"session_date": "2026-12-15", "start_time": "14:00"})
    assert resp.status_code == 201 and resp.get_json()["slots"] == []
    assert client.post("/api/grooming/sessions", json={"session_date": "2026-12-15", "start_time": "14:00"}).status_code == 409
    assert client.post("/api/grooming/sessions", json={"session_date": "2026-12-19"}).status_code == 422
    assert client.post("/api/grooming/sessions", json={"session_date": "2026-12-16", "start_time": "25:00"}).status_code == 422
    moved = client.put("/api/grooming/slots", json={"session_id": thu["id"], "initiative_id": 8,
                                                    "new_session_id": tue["id"]})
    assert moved.status_code == 200 and moved.get_json()["session_id"] == tue["id"]
    confirm = client.put("/api/grooming/slots", json={"session_id": tue["id"], "initiative_id": 8, "status": "Confirmed"})
    assert confirm.get_json()["status"] == "Confirmed"
    assert client.put("/api/grooming/slots", json={"session_id": tue["id"], "initiative_id": 8,
                                                   "status": "Maybe"}).status_code == 422
    assert client.put("/api/grooming/slots", json={"session_id": 999, "initiative_id": 8}).status_code == 422
    assert client.get("/api/grooming/sessions?from=20-10-2026").status_code == 422


def test_grooming_session_full(client):
    sid = client.post("/api/grooming/sessions", json={"session_date": "2026-12-16", "capacity": 1}).get_json()["id"]
    assert client.put("/api/grooming/slots", json={"session_id": sid, "initiative_id": 7}).status_code == 200
    resp = client.put("/api/grooming/slots", json={"session_id": sid, "initiative_id": 6})
    assert resp.status_code == 409 and "full" in resp.get_json()["error"]["message"]


def test_outbox(client):
    body = client.get("/api/outbox").get_json()
    assert body["total"] >= 7 and set(body["counts"]) >= {"Queued", "Sent"}
    queued = client.get("/api/outbox?status=Queued").get_json()["items"]
    assert queued and all(n["status"] == "Queued" for n in queued)
    nid = queued[0]["id"]
    sent = client.post(f"/api/outbox/{nid}/send").get_json()
    assert sent["status"] == "Sent" and sent["sent_at"] and isinstance(sent["cc_names"], list)
    assert client.post(f"/api/outbox/{nid}/ack").get_json()["status"] == "Acknowledged"
    assert client.post(f"/api/outbox/{nid}/dismiss").get_json()["status"] == "Dismissed"
    assert client.post("/api/outbox/99999/send").status_code == 404
    assert all(n["rule"] == "l2_approval" for n in client.get("/api/outbox?rule=l2_approval").get_json()["items"])
    assert client.get("/api/outbox?initiative_id=x").status_code == 422
