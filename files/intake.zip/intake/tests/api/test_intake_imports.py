"""Real files and database transactions exercise the offline import workflow."""
import io

from openpyxl import Workbook, load_workbook

from app import db
from app.services.intake_parser import map_json_payload, parse_spreadsheet


def excel(sheets):
    book = Workbook()
    book.remove(book.active)
    for name,rows in sheets.items():
        sheet = book.create_sheet(name)
        for row in rows:
            sheet.append(row)
    stream = io.BytesIO()
    book.save(stream)
    return stream.getvalue()


def intake(name='Offline project', **extra):
    return {'name':name,'lob':'US P&C','requestor':'External Reporter','priority':2,**extra}


def preview(client, records, kind='intake'):
    response = client.post('/api/imports/preview',json={'type':kind,'payload':records})
    assert response.status_code == 201, response.get_json()
    return response.get_json()


def test_excel_header_detection_duplicate_columns_and_custom_jira_fields():
    data = excel({'BMO Enterprise Jira':[
        ['Jira export, generated today'],
        ['Summary','Issue key','Custom field (Line of business)','Reporter','Description','Custom field (Platform)','Custom field (Platform)','Status'],
        ['Payroll API','BIDC-123','US','New Reporter','Full description','BDB','BBX','Awaiting Architecture'],
    ],'Second team':[['Project name','LOB','Requestor'],['Second project','CA','Another Person']]})
    parsed = parse_spreadsheet(data,'jira.xlsx')
    assert len(parsed['rows']) == 2
    row = parsed['rows'][0]
    assert row['fields']['name'] == 'Payroll API'
    assert row['fields']['external_key'] == 'BIDC-123'
    assert row['fields']['platform'] == 'BDB'
    assert row['fields']['jira_status'] == 'Awaiting Architecture'
    assert row['raw']['Custom field (Platform) #2'] == 'BBX'
    assert row['warnings'] and row['source']['row'] == 3


def test_jira_adf_json_maps_nested_text_and_preserves_external_status():
    parsed = map_json_payload({'issues':[{'key':'BIDC-7','fields':{'summary':'Payments',
        'description':{'type':'doc','content':[{'type':'paragraph','content':[{'type':'text','text':'First '},{'type':'text','text':'paragraph'}]},
         {'type':'paragraph','content':[{'type':'text','text':'Second paragraph'}]}]},
        'reporter':{'displayName':'A Reporter'},'priority':{'name':'High'},'status':{'name':'Under review'},
        'customfield_1001':'US'}}], 'names':{'customfield_1001':'Line of business'}})
    fields = parsed['rows'][0]['fields']
    assert fields['description'] == 'First paragraph\nSecond paragraph'
    assert fields['requestor'] == 'A Reporter'
    assert fields['priority'] == 2
    assert fields['jira_status'] == 'Under review'
    assert fields['lob'] == 'US'


def test_review_commit_idempotency_provenance_and_duplicates(client, app):
    batch = preview(client,[intake(external_key='BIDC-101',platform='BDB',region='US',channel='SS')])
    assert not batch['rows'][0]['errors'],batch
    bid = batch['id']
    edited = client.put(f'/api/imports/{bid}',json={'rows':[{'row_id':'json:1','fields':{'name':'Reviewed project'}}]})
    assert edited.status_code == 200
    result = client.post(f'/api/imports/{bid}/commit',json={})
    assert result.status_code == 200,result.get_json()
    body = result.get_json()
    iid = body['result']['items'][0]['initiative_id']
    assert body['result']['created'] == 1
    repeat = client.post(f'/api/imports/{bid}/commit',json={}).get_json()
    assert repeat['idempotent'] and repeat['result'] == body['result']
    detail = client.get(f'/api/initiatives/{iid}').get_json()['initiative']
    assert detail['name'] == 'Reviewed project'
    assert detail['requestor'] == 'External Reporter'
    assert detail['requestor_id'] is None
    assert detail['platform'] == 'BDB' and detail['jira_key'] == 'BIDC-101'
    with app.app_context():
        evidence = db.query_one('SELECT * FROM import_records WHERE batch_id=?',(bid,))
        assert evidence['initiative_id'] == iid and 'External Reporter' in evidence['source_json']
    again = preview(client,[intake('Different title',external_key='BIDC-101')])
    assert again['rows'][0]['duplicate']['id'] == iid
    rejected = client.post(f'/api/imports/{again["id"]}/commit',json={})
    assert rejected.status_code == 422
    assert client.get(f'/api/imports/{bid}/source').status_code == 200


def test_required_fields_server_revalidation_and_selective_commit(client):
    batch = preview(client,[{'name':'Missing people and LOB'},intake('Good selected row')])
    assert batch['rows'][0]['errors']['lob']
    assert batch['summary']['invalid'] == 1
    assert client.post(f'/api/imports/{batch["id"]}/commit',json={}).status_code == 422
    result = client.post(f'/api/imports/{batch["id"]}/commit',json={
        'rows':[{'row_id':'json:1','selected':False}]}).get_json()
    assert result['result']['created'] == 1 and result['result']['skipped'] == 1


def test_mapping_review_applies_to_original_columns(client):
    batch = preview(client,[{'Mystery title':'Mapped title','Business area':'US P&C','Submitted by':'Jane Doe'}])
    assert batch['summary']['invalid'] == 1
    response = client.put(f'/api/imports/{batch["id"]}',json={'mapping':{
        'Mystery title':'name','Business area':'lob','Submitted by':'requestor'}})
    assert response.status_code == 200,response.get_json()
    result = response.get_json()
    assert result['rows'][0]['fields']['requestor'] == 'Jane Doe'
    assert result['summary']['invalid'] == 0
    assert client.post(f'/api/imports/{batch["id"]}/commit',json={}).status_code == 200


def test_document_word_tables_full_text_and_original_attachment(client, make_docx):
    data = make_docx(['Solution Architecture: Offline SA project','Version 1.7 · Author: Architect Person',
        'Line of business: US P&C','Requestor: Document Reporter','1. Business context','Build safe payment APIs.',
        '2. Architecture','Use APIP and CIAM components.'],
        [['Field','Value'],['Platform','BDB'],['Region','US'],['Channel','Assisted'],['APT number','12345'],
         ['Technical notes','Preserve this late table text.']])
    response = client.post('/api/imports/preview',data={'type':'intake','file':(io.BytesIO(data),'SA.docx')},content_type='multipart/form-data')
    assert response.status_code == 201,response.get_json()
    batch = response.get_json()
    assert 'Preserve this late table text.' in batch['document']['text']
    assert batch['rows'][0]['fields']['platform'] == 'BDB'
    assert batch['document']['metadata']['sa_version'] == '1.7'
    assert batch['document']['sections']
    assert {c['code'] for c in batch['document']['components']} >= {'APIP','CIAM'}
    commit = client.post(f'/api/imports/{batch["id"]}/commit',json={})
    assert commit.status_code == 200,commit.get_json()
    iid = commit.get_json()['result']['items'][0]['initiative_id']
    attachments = client.get(f'/api/initiatives/{iid}/attachments').get_json()['items']
    assert len(attachments) == 1 and attachments[0]['filename']=='SA.docx'
    downloaded = client.get(f'/api/attachments/{attachments[0]["id"]}/download')
    assert downloaded.data == data


def test_commit_is_atomic_on_late_failure(client,app):
    with app.app_context():
        before = db.scalar('SELECT COUNT(*) FROM initiatives')
    batch = preview(client,[intake('Atomic first'),intake('Atomic later',comments='x'*3980,pm='An unknown manager with a long name')])
    assert batch['summary']['invalid'] == 0
    response = client.post(f'/api/imports/{batch["id"]}/commit',json={})
    assert response.status_code == 422,response.get_json()
    with app.app_context():
        assert db.scalar('SELECT COUNT(*) FROM initiatives') == before
        assert not db.scalar('SELECT COUNT(*) FROM import_records WHERE batch_id=?',(batch['id'],))
        assert db.scalar('SELECT status FROM import_batches WHERE id=?',(batch['id'],)) == 'preview'


def test_funding_import_new_budget_months_and_estimates(client):
    rows = [{'prn_code':'PRN-999900','name':'Offline Funding','funded_hours':100,'rate':120,'currency':'CAD',
             'month':'2026-10','charged_hours':10,'decision':'Approved','charge_type':'POD'},
            {'prn_code':'PRN-999900','month':'2026-11','charged_amount':2400},
            {'prn_code':'PRN-999900','appcat':'AC-21','team':'Payments','sto':'STO1','phase':'Planning','hours':15,'rate':120}]
    batch = preview(client,rows,'funding')
    assert batch['summary']['invalid']==0,batch
    response = client.post(f'/api/imports/{batch["id"]}/commit',json={})
    assert response.status_code==200,response.get_json()
    funding = client.get('/api/funding/PRN-999900').get_json()
    assert funding['decision']=='Approved' and funding['charge_type']=='POD'
    assert len(funding['charges'])==2 and len(funding['estimates'])==1
    assert funding['totals']['charged_hours']==30
    assert funding['totals']['charged_amount']==3600
    duplicate = preview(client,[rows[0]],'funding')
    assert duplicate['rows'][0]['duplicate']['kind']=='charge'
    assert client.post(f'/api/imports/{duplicate["id"]}/commit',json={}).status_code==422


def test_funding_budget_crud_actual_validation_and_currency_summary(client):
    body = {'prn_code':'PRN-999901','name':'Direct funding','budget_amount':12000,'rate':120,'currency':'USD'}
    response = client.post('/api/funding',json=body)
    assert response.status_code==201,response.get_json()
    assert response.get_json()['funded_hours']==100
    code = body['prn_code']
    charge = client.post(f'/api/funding/{code}/charges',json={'month':'2026-10','charged_hours':10}).get_json()
    assert charge['charged_amount']==1200
    assert client.post(f'/api/funding/{code}/charges',json={'month':'2026-10','charged_hours':10}).status_code==409
    assert client.post(f'/api/funding/{code}/charges',json={'month':'2026-13','charged_hours':10}).status_code==422
    assert client.put(f'/api/funding/{code}/charges/{charge["id"]}',json={'charged_hours':15}).get_json()['charged_amount']==1800
    assert client.post('/api/funding',json={**body,'prn_code':'PRN-999902','funded_hours':float('inf')}).status_code==422
    summary = client.get('/api/funding/summary').get_json()
    assert summary['budget_amount'] is None # seeded CAD budgets and new USD budget cannot be added
    assert 'USD' in summary['currencies']
    assert client.delete(f'/api/funding/{code}/charges/{charge["id"]}').status_code==200
    assert client.delete(f'/api/funding/{code}').status_code==200


def test_templates_are_blank_and_supported_formats_checked(client):
    response = client.get('/api/imports/templates/intake.xlsx')
    assert response.status_code == 200
    workbook = load_workbook(io.BytesIO(response.data))
    assert workbook.worksheets[0].max_row == 1
    assert 'Instructions' in workbook.sheetnames
    assert client.get('/api/imports/templates/funding.csv').status_code == 200
    response = client.post('/api/imports/preview',data={'file':(io.BytesIO(b'bad'),'old.xls')},content_type='multipart/form-data')
    assert response.status_code==422


def test_empty_portal_lifecycle_uses_only_entered_people_and_data(tmp_path):
    from app import create_app
    from app.workspace import initialize_empty

    app = create_app(DB_PATH=str(tmp_path/'portal.db'),UPLOAD_DIR=str(tmp_path/'uploads'),
                     TESTING=True,TODAY='2026-10-21',AI_MODE='simulated',AI_SPEED='Fast',HAS_API_KEY=False)
    with app.app_context():
        initialize_empty(db.get_db(),today='2026-10-21')
    client = app.test_client()
    assert client.get('/api/initiatives').get_json()['total']==0
    assert client.get('/api/resources').get_json()['total']==0
    assert client.get('/api/funding').get_json()['total']==0
    people = {}
    for name,role,team in [('Portal Requestor','Requestor','Business'),('Portal Architect','Solution Architect','DC SA'),
                           ('Portal Developer','API Developer','EAPI'),('Portal PM','DC PM','DC PM')]:
        response = client.post('/api/resources',json={'name':name,'role':role,'team':team,'default_monthly_hours':140})
        assert response.status_code==201,response.get_json()
        people[role] = response.get_json()['id']
    fund = client.post('/api/funding',json={'prn_code':'PRN-123456','name':'Entered budget','funded_hours':5000,'rate':100})
    assert fund.status_code==201,fund.get_json()
    created = client.post('/api/initiatives',json=intake('Fresh portal lifecycle',requestor='Portal Requestor',
        requestor_id=people['Requestor'],dc_sa_id=people['Solution Architect'],tech_lead_id=people['API Developer'],
        dc_pm_id=people['DC PM'],prn_code='PRN-123456',requested_go_live='2027-02-20',target_release='DC-2702'))
    assert created.status_code==201,created.get_json()
    iid = created.get_json()['initiative']['id']
    assert client.post(f'/api/initiatives/{iid}/groomed').status_code==200
    component = client.post(f'/api/initiatives/{iid}/components',json={'component_code':'APIP','complexity':'Medium',
                                                                 'change_summary':'New account endpoint','component_lead_id':people['API Developer']})
    assert component.status_code==201,component.get_json()
    text = ('Solution Architecture: Fresh portal lifecycle\nVersion 1.0 Author: Portal Architect\n\n'+
            '\n'.join(f'{i}. {heading}\nExplicit documented requirements for this section.\n' for i,heading in enumerate(
             ['Business context','Scope','Impacted components','Integration and sequence','Non-functional requirements',
              'Security','Data','Backout plan','Open questions'],1)))
    attachment = client.post(f'/api/initiatives/{iid}/sa-text',json={'text':text})
    assert attachment.status_code==201,attachment.get_json()
    assert attachment.get_json()['sa']['completeness']==100
    calculate = client.post(f'/api/initiatives/{iid}/l2/calculate')
    assert calculate.status_code==200 and calculate.get_json()['total_hours']>0
    client.put('/api/settings',json={'persona':'Dev Lead'})
    submitted = client.post(f'/api/initiatives/{iid}/l2/submit',json={})
    assert submitted.status_code==200,submitted.get_json()
    client.put('/api/settings',json={'persona':'Requestor'})
    approved = client.post(f'/api/initiatives/{iid}/l2/approve',json={'approved_by':'Portal Requestor','comment':'Approved in portal'})
    assert approved.status_code==200,approved.get_json()
    assert approved.get_json()['initiative']['l2_status']=='Approved'
    client.put('/api/settings',json={'persona':'DC PM'})
    draft = client.post(f'/api/initiatives/{iid}/ai/wbs',json={})
    assert draft.status_code==200,draft.get_json()
    assert draft.get_json()['deterministic']
    applied = client.post(f'/api/ai-runs/{draft.get_json()["ai_run_id"]}/apply',json={})
    assert applied.status_code==200,applied.get_json()
    tasks = client.get(f'/api/initiatives/{iid}/tasks').get_json()['items']
    assert len(tasks)>5
    entered_ids = set(people.values())
    assert all(task.get('resource_id') is None or task['resource_id'] in entered_ids for task in tasks)
    allocation = client.post('/api/allocations',json={'resource_id':people['API Developer'],'initiative_id':iid,
                                                     'month':'2026-11','hours':8})
    assert allocation.status_code==201,allocation.get_json()
    assert allocation.get_json()['firmness']=='confirmed'
    assert client.get(f'/api/initiatives/{iid}/resource-grid').status_code==200
    assert client.get(f'/api/initiatives/{iid}/health').status_code==200
    assert client.get('/api/capacity?from=2026-11&to=2027-01').status_code==200
    governance = client.post(f'/api/initiatives/{iid}/change-requests/draft',json={})
    assert governance.status_code==201,governance.get_json()
    assert governance.get_json().get('cms_lead_id') is None
    assert governance.get_json().get('rel_lead_id') is None
    assert client.get('/api/export/portfolio.xlsx').status_code==200
    exported = client.get(f'/api/export/demo-view.xlsx?initiative_id={iid}')
    assert exported.status_code==200
    book = load_workbook(io.BytesIO(exported.data))
    values = [cell.value for row in book['Demo View'] for cell in row if cell.value is not None]
    assert 'Fresh portal lifecycle' in values
    with app.app_context():
        assert db.scalar('SELECT COUNT(*) FROM resources')==4
        assert db.scalar('SELECT COUNT(*) FROM initiatives')==1


def test_funding_estimates_and_initiative_links_are_atomic(client):
    code = 'PRN-999903'
    assert client.post('/api/funding',json={'prn_code':code,'name':'Linked budget','funded_hours':200}).status_code==201
    linked = client.put(f'/api/funding/{code}/initiatives',json={'initiative_ids':[1,2]})
    assert linked.status_code==200,linked.get_json()
    assert {i['id'] for i in linked.get_json()['initiatives']}=={1,2}
    failed = client.put(f'/api/funding/{code}/initiatives',json={'initiative_ids':[3,999999]})
    assert failed.status_code==422
    assert {i['id'] for i in client.get(f'/api/funding/{code}').get_json()['initiatives']}=={1,2}
    assert client.delete(f'/api/funding/{code}').status_code==409
    estimate = client.post(f'/api/funding/{code}/estimates',json={'appcat':'App-42','team':'Portal Team','sto':'Architecture',
        'phase':'Support','hours':25,'rate':100,'decision':'Approved','notes':'Maintenance funding'})
    assert estimate.status_code==201,estimate.get_json()
    eid = estimate.get_json()['id']
    assert estimate.get_json()['amount']==2500
    edited = client.put(f'/api/funding/{code}/estimates/{eid}',json={'hours':30})
    assert edited.status_code==200 and edited.get_json()['amount']==3000
    assert client.delete(f'/api/funding/{code}/estimates/{eid}').status_code==200
    assert client.put(f'/api/funding/{code}/initiatives',json={'initiative_ids':[]}).status_code==200
    assert client.delete(f'/api/funding/{code}').status_code==200


def test_funding_word_document_table_import_and_original_source(client, make_docx):
    data = make_docx(['Funding estimate: Payment initiative','PRN code: PRN-999904','Project name: Document funding',
                     'Funded hours: 200','Hourly rate: 100','Currency: CAD','Decision: Approved','Charge type: Project',
                     'Scope: Deliver the account API.','Assumptions: Existing integration contracts remain available.'],
                    [['AppCat','Team','STO','Phase','Hours','Rate','Amount','Decision'],
                     ['AC-101','EAPI','Architecture','Planning','20','100','2000','Approved'],
                     ['AC-102','Web','Delivery','Development','80','100','8000','Pending']])
    response = client.post('/api/imports/preview',data={'type':'funding','file':(io.BytesIO(data),'Funding.docx')},content_type='multipart/form-data')
    assert response.status_code==201,response.get_json()
    batch = response.get_json()
    assert len(batch['rows'])==2 and batch['summary']['invalid']==0,batch
    assert batch['document']['estimate_rows']==2
    assert 'integration contracts' in batch['document']['text']
    assert batch['rows'][0]['fields']['prn_code']=='PRN-999904'
    assert batch['rows'][0]['fields']['appcat']=='AC-101'
    committed = client.post(f'/api/imports/{batch["id"]}/commit',json={})
    assert committed.status_code==200,committed.get_json()
    budget = client.get('/api/funding/PRN-999904').get_json()
    assert len(budget['estimates'])==2 and budget['totals']['estimated_amount']==10000
    assert budget['scope']=='Deliver the account API.'
    assert client.get(f'/api/imports/{batch["id"]}/source').data==data


def test_funding_pasted_email_estimate_lines_and_pdf_labels(client,make_pdf):
    text = ('Subject: Payment API estimate\nPRN: PRN-999905\nProject name: Email funding\nFunded hours: 200\n'
            'Hourly rate: 100\nTeam: EAPI\nAppCat: AC-501\nSTO: Architecture\n'
            'Planning: 20 hours @ $100\nDevelopment: 50 hours @ $100\nSupport: 10 hours @ $100\n')
    response = client.post('/api/imports/preview',json={'type':'funding','text':text,'filename':'Funding email.txt'})
    assert response.status_code==201,response.get_json()
    batch = response.get_json()
    assert len(batch['rows'])==3 and batch['summary']['invalid']==0,batch
    assert {r['fields']['phase'] for r in batch['rows']}=={'Planning','Development','Support'}
    assert client.post(f'/api/imports/{batch["id"]}/commit',json={}).status_code==200
    assert client.get('/api/funding/PRN-999905').get_json()['totals']['estimated_hours']==80
    pdf = make_pdf(['Project name: PDF budget','PRN code: PRN-999906','Funded hours: 60','Rate: 100','Currency: CAD'])
    response = client.post('/api/imports/preview',data={'type':'funding','file':(io.BytesIO(pdf),'Budget.pdf')},content_type='multipart/form-data')
    assert response.status_code==201,response.get_json()
    batch = response.get_json()
    assert batch['summary']['invalid']==0,batch
    assert any('No structured estimate table' in w for w in batch['rows'][0]['warnings'])
    assert client.post(f'/api/imports/{batch["id"]}/commit',json={}).status_code==200


def test_financial_fields_are_never_silently_discarded(client):
    response = preview(client,[{'prn_code':'PRN-999907','name':'Missing actual month','funded_hours':100,'charged_hours':10}],kind='funding')
    assert 'month' in response['rows'][0]['errors']
    response = preview(client,[{'prn_code':'PRN-999907','name':'Missing estimate team','funded_hours':100,'hours':10}],kind='funding')
    assert 'appcat' in response['rows'][0]['errors']


def test_repeated_jira_label_columns_are_merged_and_deduplicated():
    data = excel({'Jira':[['Summary','Labels','Labels','Labels','Reporter','LOB'],
                          ['Many labels','api','delivery','api','Reporter','US P&C']]})
    parsed = parse_spreadsheet(data,'jira.xlsx')
    row = parsed['rows'][0]
    assert row['fields']['labels']==['api','delivery']
    assert len(row['evidence']['labels'])==3


def test_funding_pr_code_is_the_charge_code_while_intake_retains_external_pr():
    from app.services.intake_parser import field_for_header
    assert field_for_header('PR Code','funding')=='prn_code'
    assert field_for_header('POD PR code','funding')=='prn_code'
    assert field_for_header('PR Code','intake')=='external_pr_code'
    assert field_for_header('DC External Team PR Code','funding')=='external_pr_code'


def test_document_commit_rollback_cleans_created_attachment_files(client,app,monkeypatch):
    from pathlib import Path

    from app import errors
    from app.api import initiatives

    batch = client.post('/api/imports/preview',json={'text':
        'Solution Architecture: Attachment rollback\nLine of business: US P&C\nRequestor: Reporter\n1. Business context\nDocument body.'}).get_json()
    with app.app_context():
        before = db.scalar('SELECT COUNT(*) FROM initiatives')
        next_id = db.scalar('SELECT MAX(id)+1 FROM initiatives')
        attachments_before = db.scalar('SELECT COUNT(*) FROM attachments')
    real_store = initiatives.store_upload

    def fail_after_file(*args,**kwargs):
        real_store(*args,**kwargs)
        raise errors.validation('Injected post-attachment failure.',{'document':'Review again.'})

    monkeypatch.setattr(initiatives,'store_upload',fail_after_file)
    response = client.post(f'/api/imports/{batch["id"]}/commit',json={})
    assert response.status_code==422
    with app.app_context():
        assert db.scalar('SELECT COUNT(*) FROM initiatives')==before
        assert db.scalar('SELECT COUNT(*) FROM attachments')==attachments_before
        assert db.scalar('SELECT status FROM import_batches WHERE id=?',(batch['id'],))=='preview'
    assert not (Path(app.config['UPLOAD_DIR'])/str(next_id)).exists()
    assert client.get(f'/api/imports/{batch["id"]}/source').status_code==200
