"""Decision Log, Lessons Learned, Meeting Notes and Documents."""
from __future__ import annotations

import pytest

SQLI = "x'); DELETE FROM decisions;--"


def test_seeded_artifacts(client):
    assert client.get("/api/decisions").get_json()["total"] == 11
    lessons = client.get("/api/lessons?initiative_id=1").get_json()
    assert lessons["total"] == 5 and lessons["items"][0]["rddc"] == "RDDC-24310"
    assert isinstance(lessons["items"][0]["tags"], list)
    notes = client.get("/api/meeting-notes").get_json()
    assert notes["total"] == 4 and isinstance(notes["items"][0]["attendees"], list)
    assert isinstance(notes["items"][0]["action_items_json"], list)
    docs = client.get("/api/documents?component=CIAM").get_json()
    assert docs["total"] >= 2 and all("CIAM" in d["components"] for d in docs["items"])
    assert client.get("/api/documents?doc_type=SA").get_json()["total"] == 7


@pytest.mark.parametrize("kind, body, field", [
    ("decisions", {"initiative_id": 5, "title": "Use EDP backfill", "decision": "Backfill monthly"}, "title"),
    ("lessons", {"initiative_id": 1, "lesson": "Book biller test data early", "tags": ["PAYHUB"]}, "lesson"),
    ("meeting-notes", {"initiative_id": 7, "title": "Accessibility review", "attendees": ["Bea Lindqvist"],
                       "action_items_json": [{"action": "Share audit", "owner": "Bea Lindqvist", "due": "2026-10-23",
                                              "status": "Open"}]}, "title"),
    ("documents", {"initiative_id": 5, "doc_type": "Runbook", "title": "Statements runbook", "components": ["STMT"],
                   "url": "https://confluence.example/statements"}, "title"),
])
def test_artifact_crud(client, kind, body, field):
    resp = client.post(f"/api/{kind}", json=body)
    assert resp.status_code == 201, resp.get_json()
    row = resp.get_json()
    assert row[field] == body[field] and row["rddc"]
    upd = client.put(f"/api/{kind}/{row['id']}", json={field: SQLI})
    assert upd.status_code == 200 and upd.get_json()[field] == SQLI
    assert client.put(f"/api/{kind}/{row['id']}", json={field: ""}).status_code == 422
    assert client.delete(f"/api/{kind}/{row['id']}").get_json() == {"ok": True}
    assert client.delete(f"/api/{kind}/{row['id']}").status_code == 404
    assert client.put(f"/api/{kind}/99999", json={field: "x"}).status_code == 404


def test_artifact_bad_input(client):
    assert client.post("/api/decisions", json={"title": "No decision"}).status_code == 422
    assert client.post("/api/decisions", json={"title": "t", "decision": "d", "initiative_id": 999}).status_code == 422
    assert client.post("/api/decisions", json={"title": "t", "decision": "d", "status": "Done"}).status_code == 422
    assert client.post("/api/lessons", json={"lesson": "x", "tags": "a" * 50}).status_code == 422
    assert client.post("/api/meeting-notes", json={"title": "t", "action_items_json": "call Bob"}).status_code == 422
    assert client.post("/api/documents", json={"doc_type": "Poster", "title": "t"}).status_code == 422
    assert client.post("/api/documents", json={"doc_type": "SA", "title": "t", "url": "javascript:alert(1)"}).status_code == 422
    assert client.post("/api/documents", json={"doc_type": "SA", "title": "t", "components": ["XYZ"]}).status_code == 422
    assert client.get("/api/decisions?initiative_id=abc").status_code == 422
    assert client.get("/api/posters").status_code == 404


def test_sql_injection_in_search(client):
    assert client.get("/api/decisions?q=' OR 1=1--").get_json()["total"] == 0
    client.post("/api/decisions", json={"title": SQLI, "decision": SQLI})
    assert client.get("/api/decisions").get_json()["total"] == 12
