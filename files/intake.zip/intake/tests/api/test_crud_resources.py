"""Resources, availability, allocations and skills."""
from __future__ import annotations


def test_list_resources(client):
    body = client.get("/api/resources?tracked=1").get_json()
    assert body["total"] == 15
    tobias = next(r for r in body["items"] if r["id"] == 1)
    assert tobias["team_label"] == "EAPI (Dev1)" and tobias["availability"]["2026-12"] == 147.0
    assert {"skill": "OpenAPI", "level": 3} in tobias["skills"]
    assert tobias["current_load"]["month"] == "2026-10" and tobias["current_load"]["available"] == 140.0
    assert client.get("/api/resources?tracked=0").get_json()["total"] == 9
    assert {r["team"] for r in client.get("/api/resources?team=CIAM").get_json()["items"]} == {"CIAM"}
    assert client.get("/api/resources?tracked=yes").status_code == 422


def test_create_and_update_resource(client):
    resp = client.post("/api/resources", json={"name": "Priya Raman", "role": "API Developer", "team": "EAPI",
                                               "default_monthly_hours": 126})
    assert resp.status_code == 201
    person = resp.get_json()
    assert person["availability"]["2026-11"] == 126.0 and person["team_label"] == "EAPI"
    assert client.post("/api/resources", json={"name": "Priya Raman", "role": "Dev"}).status_code == 409
    assert client.post("/api/resources", json={"role": "Dev"}).status_code == 422
    assert client.post("/api/resources", json={"name": "A", "role": "B", "default_monthly_hours": 900}).status_code == 422
    upd = client.put(f"/api/resources/{person['id']}", json={"location": "Chicago"})
    assert upd.status_code == 200 and upd.get_json()["location"] == "Chicago"
    assert client.put(f"/api/resources/{person['id']}", json={"name": ""}).status_code == 422
    assert client.put("/api/resources/999", json={"location": "x"}).status_code == 404


def test_availability(client):
    body = client.get("/api/resources/5/availability?from=2026-11&to=2027-01").get_json()
    assert body == {"resource_id": 5, "months": {"2026-11": 140.0, "2026-12": 80.0, "2027-01": 140.0}}
    resp = client.put("/api/resources/5/availability", json={"months": {"2026-12": 112}})
    assert resp.status_code == 200 and resp.get_json()["months"]["2026-12"] == 112.0
    assert client.put("/api/resources/5/availability", json={"months": {"Dec": 10}}).status_code == 422
    assert client.put("/api/resources/5/availability", json={"months": {"2026-12": -1}}).status_code == 422
    assert client.put("/api/resources/5/availability", json={}).status_code == 422
    assert client.get("/api/resources/5/availability?from=2026").status_code == 422
    assert client.get("/api/resources/999/availability").status_code == 404


def test_allocations(client):
    body = client.get("/api/allocations?resource_id=14&month=2026-11").get_json()
    assert round(sum(a["hours"] for a in body["items"]), 1) == 115.5
    assert {a["rddc"] for a in body["items"]} == {"RDDC-24412", "RDDC-24688", "RDDC-24702"}
    derived = body["items"][0]
    assert client.put(f"/api/allocations/{derived['id']}", json={"hours": 1}).status_code == 409
    assert client.delete(f"/api/allocations/{derived['id']}").status_code == 409
    resp = client.post("/api/allocations", json={"resource_id": 15, "initiative_id": 7, "month": "2026-11", "hours": 12.5})
    assert resp.status_code == 201
    manual = resp.get_json()
    assert manual["source"] == "manual" and manual["firmness"] == "tentative" and manual["rddc"] == "RDDC-24755"
    assert client.put(f"/api/allocations/{manual['id']}", json={"hours": 14}).get_json()["hours"] == 14
    assert client.post("/api/allocations", json={"resource_id": 15, "initiative_id": 7, "month": "11-2026",
                                                 "hours": 1}).status_code == 422
    assert client.post("/api/allocations", json={"resource_id": 15, "initiative_id": 7, "month": "2026-11", "hours": 1,
                                                 "task_id": 1}).status_code == 422
    assert client.post("/api/allocations", json={"resource_id": 15}).status_code == 422
    assert client.delete(f"/api/allocations/{manual['id']}").get_json() == {"ok": True}
    assert client.put("/api/allocations/99999", json={"hours": 1}).status_code == 404
    assert client.get("/api/allocations?month=Nov").status_code == 422


def test_resource_calendar(client):
    body = client.get("/api/resources/14/calendar?from=2026-11&to=2026-11").get_json()
    cell = body["months"][0]
    assert cell["allocated"] == 115.5 and cell["available"] == 120.0
    assert client.get("/api/resources/999/calendar").status_code == 404


def test_skill_matrix_and_update(client):
    matrix = client.get("/api/skills/matrix").get_json()
    assert len(matrix["rows"]) == 15 and any(s["name"] == "Kafka" for s in matrix["skills"])
    lena = next(r for r in matrix["rows"] if r["resource_id"] == 2)
    assert lena["levels"]["Kafka"] == 3 and lena["evidence"]["Kafka"].startswith("RDDC-")
    resp = client.put("/api/resources/2/skills", json={"skills": {"Kafka": 2, "Payments APIs": 1, "EDP feeds": None}})
    assert resp.status_code == 200
    skills = {s["skill"]: s["level"] for s in resp.get_json()["skills"]}
    assert skills["Kafka"] == 2 and skills["Payments APIs"] == 1 and "EDP feeds" not in skills
    assert client.put("/api/resources/2/skills", json={"skills": {"Kafka": 5}}).status_code == 422
    assert client.put("/api/resources/2/skills", json={"skills": []}).status_code == 422
    assert client.put("/api/resources/999/skills", json={"skills": {"Kafka": 1}}).status_code == 404
