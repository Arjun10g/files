"""Excel and CSV exports (B2): workbook structure, real dates, validations, formula-injection escaping."""
from __future__ import annotations

import csv
import importlib.util
import io
from datetime import datetime
from pathlib import Path

import pytest
from openpyxl import load_workbook

from app import db

_spec = importlib.util.spec_from_file_location(
    "b2_hero_db_export", Path(__file__).resolve().parents[1] / "engines" / "hero_db.py")
hero_db = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(hero_db)

HERO = hero_db.HERO_ID
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
DEMO_SHEETS = ["Mission Statement", "Demo View", "Portfolio View", "Gantt", "Capacity", "Risk Register", "Lists"]


@pytest.fixture()
def app(tmp_path):
    return hero_db.make_app(tmp_path)


@pytest.fixture()
def client(app):
    return app.test_client()


def _book(resp):
    assert resp.status_code == 200, resp.get_data(as_text=True)[:300]
    assert resp.mimetype == XLSX
    assert "attachment" in resp.headers["Content-Disposition"]
    return load_workbook(io.BytesIO(resp.data))


def _cells(ws):
    for row in ws.iter_rows():
        for c in row:
            if c.value is not None:
                yield c


def test_demo_view_workbook_structure(client):
    wb = _book(client.get(f"/api/export/demo-view.xlsx?initiative_id={HERO}"))
    assert wb.sheetnames == DEMO_SHEETS
    assert all(len(n) <= 31 for n in wb.sheetnames)
    demo = wb["Demo View"]
    values = {c.value for c in _cells(demo)}
    for text in ("Pg 1 – General Details", "Pg 2 – Project Plan", "Pg 3 – Resource Management",
                 "Pg 4 – Change Governance", "RDDC-24817", "88%", "1,000 h", "Generate Change Summary",
                 "Generate Gantt view"):
        assert text in values, text
    assert any(isinstance(v, str) and "SA capacity constraint affecting WBS-100" in v for v in values)
    yellow = [c for c in _cells(demo) if c.fill and c.fill.fgColor and c.fill.fgColor.rgb == "00FFFF00"]
    assert len(yellow) >= 10
    readiness = next(c for c in _cells(demo) if c.value == "Readiness Date")
    date_cell = demo.cell(row=readiness.row, column=readiness.column + 1)
    assert isinstance(date_cell.value, datetime) and date_cell.value.date().isoformat() == "2027-02-17"
    assert date_cell.number_format == "dd mmm yyyy"
    formulas = [dv.formula1 for dv in demo.data_validations.dataValidation]
    assert any(f.startswith("=Lists!$") for f in formulas)
    wbs200 = next(c for c in _cells(demo) if c.value == "WBS-200")
    assert demo.cell(row=wbs200.row, column=12).value == 560  # summary row rolls up its children
    sheet1 = wb["Lists"]
    assert [c.value for c in sheet1[1]][:5] == ["Status", "Release Type", "STO Approval", "Validation Status", "RAG"]
    assert [sheet1.cell(row=r, column=3).value for r in range(2, 6)] == [
        "Tentative Go", "Tentative No Go", "Go", "No-Go"]


def test_gantt_and_capacity_sheets(client):
    wb = _book(client.get(f"/api/export/demo-view.xlsx?initiative_id={HERO}"))
    g = wb["Gantt"]
    codes = [g.cell(row=r, column=1).value for r in range(4, 18)]
    assert codes[0] == "WBS-100" and "WBS-800" in codes
    critical = [c for c in _cells(g) if c.fill and c.fill.fgColor and c.fill.fgColor.rgb == "00C00000"]
    assert critical
    milestone = [c for c in _cells(g) if c.value == "◆"]
    assert len(milestone) == 1
    cap = wb["Capacity"]
    assert len(cap.conditional_formatting) >= 1
    names = {c.value for c in _cells(cap)}
    assert "Sana Whitfield" in names and "Q1 FY27 (Nov–Jan)" in names
    util = [c for c in _cells(cap) if c.value == "Util"]
    assert util and all(cap.cell(row=c.row + 1, column=c.column).number_format == "0%" for c in util)


def test_formula_injection_is_escaped(client, app):
    with app.app_context():
        db.execute("UPDATE initiative_components SET change_summary = ? WHERE id = 31",
                   ('=HYPERLINK("http://example.invalid","click")',))
        db.execute("UPDATE initiatives SET comments = ? WHERE id = ?", ("@SUM(1+1)", HERO))
        db.insert("risks", {"risk_code": "RSK-001", "initiative_id": HERO, "title": "+cmd|' /C calc'!A0",
                            "category": "Technical", "severity": 3, "likelihood": 2, "status": "Open"})
    wb = _book(client.get(f"/api/export/demo-view.xlsx?initiative_id={HERO}"))
    for ws in wb.worksheets:
        for c in _cells(ws):
            assert c.data_type != "f", f"{ws.title}!{c.coordinate} is a formula"
    demo_values = {c.value for c in _cells(wb["Demo View"])}
    assert "'=HYPERLINK(\"http://example.invalid\",\"click\")" in demo_values
    risk_values = {c.value for c in _cells(wb["Risk Register"])}
    assert "'+cmd|' /C calc'!A0" in risk_values
    portfolio = {c.value for c in _cells(wb["Portfolio View"])}
    assert "'@SUM(1+1)" in portfolio


def test_demo_view_errors(client):
    r = client.get("/api/export/demo-view.xlsx")
    assert r.status_code == 422 and r.get_json()["error"]["code"] == "validation"
    assert client.get("/api/export/demo-view.xlsx?initiative_id=abc").status_code == 422
    assert client.get("/api/export/demo-view.xlsx?initiative_id=999").status_code == 404


def test_portfolio_workbook(client):
    wb = _book(client.get("/api/export/portfolio.xlsx"))
    assert wb.sheetnames == ["Mission Statement", "Portfolio View", "Capacity", "Risk Register", "Lists"]
    values = {c.value for c in _cells(wb["Portfolio View"])}
    assert "RDDC-24817" in values and "Amber" in values
    assert client.get("/api/export/portfolio.xlsx?rag=Pink").status_code == 422


def test_portfolio_csv(client, app):
    with app.app_context():
        db.execute("UPDATE initiatives SET comments = ? WHERE id = ?", ("=1+1", HERO))
    r = client.get("/api/export/portfolio.csv")
    assert r.status_code == 200 and r.mimetype == "text/csv"
    rows = list(csv.reader(io.StringIO(r.get_data(as_text=True).lstrip("﻿"))))
    assert rows[0][0] == "Intake/RDDC #"
    hero = next(x for x in rows if x[0] == "RDDC-24817")
    assert hero[5] == "Amber" and hero[7] == "Red"
    assert hero[-1] == "'=1+1"
    filtered = list(csv.reader(io.StringIO(client.get("/api/export/portfolio.csv?stage=Closed")
                                           .get_data(as_text=True).lstrip("﻿"))))
    assert len(filtered) == 1
