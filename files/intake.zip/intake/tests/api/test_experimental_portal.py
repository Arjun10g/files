"""Empty workspace and authenticated Jira/JSON lab behavior, with no external calls."""
from __future__ import annotations

import base64
import io
import json
import stat
import time
from pathlib import Path
from types import SimpleNamespace
from urllib.error import HTTPError, URLError
from zipfile import ZipFile

import pytest
from werkzeug.security import check_password_hash

from app import create_app, db, textract
from app.api import experimental
from app.workspace import initialize_empty

PASSWORD = "local-lab-test-password-2026"
DOMAIN_TABLES = ("initiatives", "resources", "resource_availability", "resource_skills", "allocations", "dc_intakes",
                 "initiative_components", "wbs_tasks", "wbs_dependencies", "prn_budget", "prn_charges", "risks",
                 "attachments", "change_requests", "grooming_sessions", "grooming_slots", "notifications", "decisions",
                 "lessons_learned", "meeting_notes", "documents", "assistant_messages", "activity_log", "ai_runs")


@pytest.fixture
def portal_app(tmp_path, monkeypatch):
    for name in ("BMO_JIRA_BASE_URL", "BMO_JIRA_TOKEN", "BMO_JIRA_EMAIL", "BMO_JIRA_API_VERSION", "BMO_SESSION_SECRET",
                 "BMO_BEDROCK_ENABLED", "BMO_AI_PROVIDER", "BMO_SECURE_COOKIES"):
        monkeypatch.delenv(name, raising=False)
    application = create_app(DB_PATH=str(tmp_path / "portal.db"), UPLOAD_DIR=str(tmp_path / "uploads"),
                             TODAY="2026-10-21", TESTING=True, AI_MODE="simulated")
    with application.app_context():
        initialize_empty(db.get_db(), today="2026-10-21")
    yield application


@pytest.fixture
def portal_client(portal_app):
    return portal_app.test_client()


def csrf(client):
    result = client.get("/api/experimental/status")
    assert result.status_code == 200
    return result.get_json()["csrf"]


def setup(client):
    response = client.post("/api/experimental/setup", json={"password": PASSWORD},
                           headers={"X-Portal-CSRF": csrf(client)})
    assert response.status_code == 200, response.get_json()
    return response.get_json()


def test_fresh_start_has_reference_catalogues_and_no_operational_data(portal_app):
    with portal_app.app_context():
        for table in DOMAIN_TABLES:
            assert db.scalar(f"SELECT COUNT(*) FROM {table}") == 0, table
        assert db.scalar("SELECT COUNT(*) FROM dc_components") > 0
        assert db.scalar("SELECT COUNT(*) FROM component_dependencies") > 0
        assert db.scalar("SELECT COUNT(*) FROM skills") > 0
        assert db.scalar("SELECT value FROM app_settings WHERE key='workspace_mode'") == "portal"
        assert db.scalar("SELECT value FROM app_settings WHERE key='ai_mode'") == "simulated"
        assert db.scalar("SELECT value FROM app_settings WHERE key='demo_today'") == "2026-10-21"


def test_normal_startup_command_initializes_empty_instead_of_seeding(tmp_path, monkeypatch):
    from app import cli

    application = create_app(DB_PATH=str(tmp_path / "startup.db"), UPLOAD_DIR=str(tmp_path / "uploads"), TESTING=True)
    monkeypatch.setattr(cli, "_app", lambda: application)
    monkeypatch.setenv("BMO_TODAY", "2026-10-21")
    assert cli.cmd_init_if_missing(None) == 0
    assert cli.cmd_init_if_missing(None) == 0
    with application.app_context():
        assert db.db_ready()
        assert all(db.scalar(f"SELECT COUNT(*) FROM {table}") == 0 for table in DOMAIN_TABLES)
        assert db.scalar("SELECT value FROM app_settings WHERE key='workspace_mode'") == "portal"


def test_empty_initialization_is_idempotent_and_preserves_entered_data(portal_app):
    with portal_app.app_context():
        db.execute("INSERT INTO resources(name,role,team) VALUES ('Entered User','Developer','API')")
        before = {row["name"]: db.scalar(f"SELECT COUNT(*) FROM {row['name']}")
                  for row in db.query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
        initialize_empty(db.get_db(), today="2030-01-01")
        after = {table: db.scalar(f"SELECT COUNT(*) FROM {table}") for table in before}
        assert before == after
        assert db.scalar("SELECT name FROM resources") == "Entered User"
        assert db.scalar("SELECT value FROM app_settings WHERE key='demo_today'") == "2026-10-21"


def test_session_secret_survives_restart_and_cookie_is_private(portal_app, portal_client):
    status = setup(portal_client)
    assert status["authenticated"] and status["configured"]
    secret_path = Path(portal_app.config["DB_PATH"]).parent / ".portal-session-secret"
    assert stat.S_IMODE(secret_path.stat().st_mode) == 0o600
    restarted = create_app(DB_PATH=portal_app.config["DB_PATH"], UPLOAD_DIR=portal_app.config["UPLOAD_DIR"], TESTING=True)
    assert restarted.secret_key == portal_app.secret_key
    response = portal_client.get("/api/experimental/status")
    assert portal_app.config["SESSION_COOKIE_HTTPONLY"] is True
    assert portal_app.config["SESSION_COOKIE_SAMESITE"] == "Strict"
    assert "private" not in json.dumps(response.get_json())


def test_first_time_setup_requires_local_origin_session_csrf_and_strong_password(portal_app, portal_client):
    # A sentinel header cannot substitute for having opened a session.
    assert portal_client.post("/api/experimental/setup", json={"password": PASSWORD},
                              headers={"X-Portal-CSRF": "missing"}).status_code == 403
    token = csrf(portal_client)
    headers = {"X-Portal-CSRF": token}
    assert portal_client.post("/api/experimental/setup", json={"password": PASSWORD}, headers=headers,
                              environ_overrides={"REMOTE_ADDR": "192.0.2.10"}).status_code == 403
    assert portal_client.post("/api/experimental/setup", json={"password": "short"}, headers=headers).status_code == 422
    assert portal_client.post("/api/experimental/setup", json={"password": PASSWORD},
                              headers={**headers, "Origin": "https://another.example"}).status_code == 403
    status = setup(portal_client)
    assert status["csrf"] != token
    with portal_app.app_context():
        stored = db.scalar("SELECT value FROM app_settings WHERE key='lab_password_hash'")
        assert stored != PASSWORD and check_password_hash(stored, PASSWORD)
    assert portal_client.post("/api/experimental/setup", json={"password": PASSWORD},
                              headers={"X-Portal-CSRF": status["csrf"]}).status_code == 409


@pytest.mark.parametrize("endpoint", ["jira-fetch", "json-preview", "logout"])
def test_lab_actions_require_authenticated_cookie(portal_client, endpoint):
    response = portal_client.post(f"/api/experimental/{endpoint}", json={"issue_key": "BIDC-123"})
    assert response.status_code == 401 and response.get_json()["error"]["code"] == "unauthorized"


def test_csrf_same_origin_expiry_and_logout(portal_client):
    status = setup(portal_client)
    for bad_token in ("", "wrong", "é"):
        response = portal_client.post("/api/experimental/jira-fetch", json={"issue_key": "BIDC-123"},
                                      headers={"X-Portal-CSRF": bad_token})
        assert response.status_code == 403
    headers = {"X-Portal-CSRF": status["csrf"]}
    assert portal_client.post("/api/experimental/logout", json={},
                              headers={**headers, "Origin": "https://another.example"}).status_code == 403
    with portal_client.session_transaction() as session:
        session["lab_expires"] = time.time() - 1
    assert portal_client.get("/api/experimental/status").get_json()["authenticated"] is False
    assert portal_client.post("/api/experimental/jira-fetch", json={"issue_key": "BIDC-123"}, headers=headers).status_code == 401
    logged_in = portal_client.post("/api/experimental/login", json={"password": PASSWORD},
                                   headers={"X-Portal-CSRF": csrf(portal_client)})
    assert logged_in.status_code == 200
    rotated = logged_in.get_json()["csrf"]
    assert rotated != status["csrf"]
    assert portal_client.post("/api/experimental/logout", json={}, headers={"X-Portal-CSRF": rotated}).status_code == 200
    assert portal_client.get("/api/experimental/status").get_json()["authenticated"] is False


def test_login_throttling_persists_new_sessions_and_restart(portal_app, portal_client):
    setup(portal_client)
    outsider = portal_app.test_client()
    token = csrf(outsider)
    for _ in range(5):
        failed = outsider.post("/api/experimental/login", json={"password": "incorrect"}, headers={"X-Portal-CSRF": token})
        assert failed.status_code == 401
    restarted = create_app(DB_PATH=portal_app.config["DB_PATH"], UPLOAD_DIR=portal_app.config["UPLOAD_DIR"], TESTING=True)
    new_client = restarted.test_client()
    throttled = new_client.post("/api/experimental/login", json={"password": PASSWORD},
                               headers={"X-Portal-CSRF": csrf(new_client)})
    assert throttled.status_code == 429
    with portal_app.app_context():
        assert db.scalar("SELECT attempts FROM lab_attempts WHERE address='127.0.0.1'") == 5
        db.execute("UPDATE lab_attempts SET started=started-901")
    success = new_client.post("/api/experimental/login", json={"password": PASSWORD},
                             headers={"X-Portal-CSRF": csrf(new_client)})
    assert success.status_code == 200 and success.get_json()["authenticated"]
    with portal_app.app_context():
        assert db.scalar("SELECT COUNT(*) FROM lab_attempts") == 0


def test_unconfigured_jira_and_invalid_keys_are_controlled(portal_client, monkeypatch):
    status = setup(portal_client)
    headers = {"X-Portal-CSRF": status["csrf"]}
    monkeypatch.setattr(experimental, "build_opener", lambda *_args: pytest.fail("unconfigured Jira called network"))
    response = portal_client.post("/api/experimental/jira-fetch", json={"issue_key": "BIDC-123"}, headers=headers)
    assert response.status_code == 422 and response.get_json()["error"]["code"] == "not_configured"
    for key in ("https://evil.example", "BIDC-123/other", "BIDC-123?url=evil", "BIDC-0"):
        assert portal_client.post("/api/experimental/jira-fetch", json={"issue_key": key}, headers=headers).status_code == 422


@pytest.mark.parametrize("base", ["http://jira.example", "https://user:secret@jira.example", "https://jira.example?token=secret",
                                  "https://jira.example/#secret", "https://jira.example:99999", "https://[bad"])
def test_jira_status_hides_invalid_base_urls_and_fetch_refuses_them(portal_client, monkeypatch, base):
    status = setup(portal_client)
    monkeypatch.setenv("BMO_JIRA_BASE_URL", base)
    monkeypatch.setenv("BMO_JIRA_TOKEN", "private-server-token")
    monkeypatch.setattr(experimental, "build_opener", lambda *_args: pytest.fail("invalid Jira base called network"))
    public = portal_client.get("/api/experimental/status").get_json()
    assert public["jira_configured"] is False and public["jira_base_url"] == ""
    assert "secret" not in json.dumps(public) and "private-server-token" not in json.dumps(public)
    assert portal_client.post("/api/experimental/jira-fetch", json={"issue_key": "BIDC-123"},
                              headers={"X-Portal-CSRF": status["csrf"]}).status_code == 422


def test_jira_fetch_uses_fixed_server_https_host_and_credentials(portal_client, monkeypatch):
    status = setup(portal_client)
    monkeypatch.setenv("BMO_JIRA_BASE_URL", "https://jira.example.test/context/")
    monkeypatch.setenv("BMO_JIRA_TOKEN", "private-server-token")
    monkeypatch.setenv("BMO_JIRA_EMAIL", "reader@example.test")
    monkeypatch.setenv("BMO_JIRA_API_VERSION", "2")
    payload = {"key": "BIDC-123", "fields": {"summary": "Entered initiative", "status": {"name": "In Progress"}}}
    calls = []

    def open_mock(request, timeout):
        calls.append((request, timeout))
        return io.BytesIO(json.dumps(payload).encode())

    def opener_mock(handler):
        assert isinstance(handler, experimental.NoRedirect)
        return SimpleNamespace(open=open_mock)

    monkeypatch.setattr(experimental, "build_opener", opener_mock)
    fetched = portal_client.post("/api/experimental/jira-fetch", headers={"X-Portal-CSRF": status["csrf"]},
                                 json={"issue_key": "bidc-123", "url": "https://untrusted.example/", "token": "untrusted"})
    assert fetched.status_code == 200 and fetched.get_json()["payload"] == payload
    req, timeout = calls[0]
    assert req.full_url == "https://jira.example.test/context/rest/api/2/issue/BIDC-123?expand=names" and timeout == 12
    assert req.get_header("Authorization") == "Basic " + base64.b64encode(b"reader@example.test:private-server-token").decode()
    assert "private-server-token" not in fetched.get_data(as_text=True)
    assert fetched.get_json()["source"] == "https://jira.example.test/context/browse/BIDC-123"


@pytest.mark.parametrize("result", ["html", "wrong_key", "network", "redirect", "too_large"])
def test_jira_error_responses_are_bounded_and_do_not_leak_credentials(portal_client, monkeypatch, result):
    status = setup(portal_client)
    monkeypatch.setenv("BMO_JIRA_BASE_URL", "https://jira.example.test")
    monkeypatch.setenv("BMO_JIRA_TOKEN", "private-server-token")

    def open_mock(_request, timeout):
        if result == "network":
            raise URLError("private-server-token")
        if result == "redirect":
            raise HTTPError("https://other.example/", 302, "private-server-token", {}, None)
        if result == "too_large":
            return io.BytesIO(b"x" * (10 * 1024 * 1024 + 1))
        return io.BytesIO(b"<html>login</html>" if result == "html" else b'{"key":"OTHER-1","fields":{}}')

    monkeypatch.setattr(experimental, "build_opener", lambda *_args: SimpleNamespace(open=open_mock))
    response = portal_client.post("/api/experimental/jira-fetch", json={"issue_key": "BIDC-123"},
                                  headers={"X-Portal-CSRF": status["csrf"]})
    assert response.status_code == (413 if result == "too_large" else 502)
    assert "private-server-token" not in response.get_data(as_text=True)


def test_authenticated_json_preview_is_review_only(portal_app, portal_client):
    status = setup(portal_client)
    payload = {"key": "BIDC-123", "fields": {"summary": "Entered initiative", "reporter": {"displayName": "Entered Owner"},
               "description": {"type": "doc", "version": 1, "content": [{"type": "paragraph", "content": [
                   {"type": "text", "text": "API scope from the authenticated JSON export"}]}]}}}
    response = portal_client.post("/api/experimental/json-preview", json={"payload": payload},
                                  headers={"X-Portal-CSRF": status["csrf"]})
    assert response.status_code == 201, response.get_json()
    preview = response.get_json()
    assert preview["status"] == "preview" and preview["rows"][0]["fields"]["name"] == "Entered initiative"
    assert preview["rows"][0]["fields"]["external_key"] == "BIDC-123"
    assert "authenticated JSON export" in preview["rows"][0]["fields"]["description"]
    with portal_app.app_context():
        assert db.scalar("SELECT COUNT(*) FROM initiatives") == 0


def test_full_docx_reads_headers_nested_tables_comments_and_footnotes(tmp_path):
    from docx import Document

    document = Document()
    document.sections[0].header.paragraphs[0].text = "Architecture header evidence"
    document.add_paragraph("Business requirement before table")
    table = document.add_table(rows=1, cols=2)
    table.cell(0, 0).text = "DC Component changes"
    table.cell(0, 1).text = "AppCat 26771 API change summary"
    nested = table.cell(0, 1).add_table(rows=1, cols=1)
    nested.cell(0, 0).text = "Nested technical requirement: 25 TPS"
    document.add_paragraph("Next steps after table")
    document.sections[0].footer.paragraphs[0].text = "Architecture footer evidence"
    path = tmp_path / "complete-sa.docx"
    document.save(path)
    with ZipFile(path, "a") as archive:
        for name, text in (("comments", "SA concurrence comment evidence"), ("footnotes", "Footnote requirement evidence"),
                           ("endnotes", "Endnote requirement evidence")):
            archive.writestr(f"word/{name}.xml", '<w:root xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
                             f'<w:p><w:r><w:t>{text}</w:t></w:r></w:p></w:root>')
    text = textract.extract_text(path)
    for phrase in ("Architecture header evidence", "DC Component changes", "AppCat 26771 API change summary",
                   "Nested technical requirement: 25 TPS", "Architecture footer evidence", "SA concurrence comment evidence",
                   "Footnote requirement evidence", "Endnote requirement evidence"):
        assert phrase in text
    assert text.index("before table") < text.index("AppCat 26771") < text.index("after table")
