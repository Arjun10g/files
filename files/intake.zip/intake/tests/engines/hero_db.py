"""Test helper (not a test module): a temp database holding the hero RDDC-24817 exactly as in
tests/fixtures/bundle_hero.json, so B2's API tests do not depend on the full demo seed.

Pre-hero bookings (committed minus the hero's own allocations) sit on a separate Solution-stage initiative,
RDDC-24688, as 'seed' allocations. The hero's allocations are produced by derive.rebuild_allocations.
"""
from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

from app import create_app, db
from app.engines import calendar as cal

ROOT = Path(__file__).resolve().parents[1]
BUNDLE = json.loads((ROOT / "fixtures" / "bundle_hero.json").read_text(encoding="utf-8"))
HERO_ID = 9
LOAD_ID = 5

EXTRA_PEOPLE = [
    {"id": 18, "name": "Arlo Kingsley", "role": "Delivery Lead", "team": "Delivery", "team_label": "Delivery"},
    {"id": 19, "name": "Petra Vallance", "role": "CMS Lead", "team": "Change", "team_label": "Change"},
    {"id": 23, "name": "Marcus Thorne", "role": "Requestor", "team": "Business", "team_label": "Cards & Payments"},
]


def _columns(table: str) -> set:
    return {r["name"] for r in db.query(f"PRAGMA table_info({table})")}


def _row(table: str, data: dict) -> dict:
    cols = _columns(table)
    out = {}
    for k, v in data.items():
        if k not in cols or k == "ai_run_id":
            continue
        out[k] = db.to_json(v) if isinstance(v, (list, dict)) else v
    return out


def seed_hero() -> None:
    b = BUNDLE
    for key, value in (("demo_today", "2026-10-19"), ("persona", "DC PM"), ("ai_mode", "simulated"),
                       ("ai_speed", "Fast"), ("rddc_next", "24818")):
        db.execute("INSERT INTO app_settings (key, value) VALUES (?, ?)", (key, value))
    for t in cal.release_trains("2026-10-19"):
        db.execute("INSERT INTO release_trains (code, train_date, status) VALUES (?, ?, ?)",
                   (t["code"], t["train_date"], t["status"]))
    for c in b["component_catalog"]:
        db.insert("dc_components", _row("dc_components", {**c, "component_lead_id": None}))
    people = [dict(r) for r in b["resources"]] + [
        {**p, "component_id": None, "capacity_eligible": 0, "default_monthly_hours": 0} for p in EXTRA_PEOPLE]
    for r in people:
        db.insert("resources", _row("resources", r))
        for m, h in (r.get("availability") or {}).items():
            db.execute("INSERT INTO resource_availability (resource_id, month, available_hours) VALUES (?, ?, ?)",
                       (r["id"], m, h))
    for c in b["component_catalog"]:
        db.execute("UPDATE dc_components SET component_lead_id = ? WHERE id = ?", (c["component_lead_id"], c["id"]))
    by_code = {c["code"]: c["id"] for c in b["component_catalog"]}
    for c in b["component_catalog"]:
        for d in c["downstream"]:
            db.execute("INSERT INTO component_dependencies (from_component_id, to_component_id) VALUES (?, ?)",
                       (c["id"], by_code[d]))
    prn = b["prn"]
    db.insert("prn_budget", _row("prn_budget", prn))

    db.execute("INSERT INTO dc_intakes (code, name, lob, requestor, priority, requested_go_live) "
               "VALUES ('DCI-3391', 'US API Enhancement', 'US P&C', 'Clara Pemberton', 2, '2027-02-26')")
    ini = dict(b["initiative"])
    ini.update({"sa_doc_attachment_id": None, "health_cached_json": None, "rag_cached": None})
    db.insert("initiatives", _row("initiatives", ini))
    db.insert("initiatives", {"id": LOAD_ID, "rddc": "RDDC-24688", "name": "Online Statement Download Redesign",
                              "lob": "Canadian P&C", "priority": 3, "stage": "Solution", "status": "Backlog",
                              "dc_pm_id": 16, "dc_sa_id": 14, "created_at": "2026-09-01T10:00:00-04:00"})
    for a in b["attachments"]:
        db.insert("attachments", _row("attachments", {**a, "extracted_text": b["sa_doc_text"]}))
    db.execute("UPDATE initiatives SET sa_doc_attachment_id = ? WHERE id = ?", (b["attachments"][0]["id"], HERO_ID))
    for c in b["components"]:
        db.insert("initiative_components", _row("initiative_components", c))
    for t in b["tasks"]:
        db.insert("wbs_tasks", _row("wbs_tasks", t))
    for t in b["tasks"]:
        for d in t["depends_on"]:
            db.execute("INSERT INTO wbs_dependencies (task_id, depends_on_task_id) VALUES (?, ?)", (t["id"], d))

    own = defaultdict(float)
    for a in b["allocations"]:
        own[(a["resource_id"], a["month"])] += a["hours"]
    for r in b["resources"]:
        for m, total in (r.get("committed") or {}).items():
            pre = round(total - own[(r["id"], m)], 1)
            if pre > 0:
                db.execute("INSERT INTO allocations (resource_id, initiative_id, task_id, month, hours, firmness, "
                           "source) VALUES (?, ?, NULL, ?, ?, 'confirmed', 'seed')", (r["id"], LOAD_ID, m, pre))
    db.execute("INSERT INTO grooming_sessions (id, session_date, start_time, title, capacity, status) "
               "VALUES (7, '2026-10-20', '10:00', 'DC grooming', 6, 'Scheduled')")


def make_app(tmp_path):
    """Flask app on a fresh temp database with the hero seeded and its allocations derived."""
    app = create_app(DB_PATH=str(tmp_path / "b2_hero.db"), UPLOAD_DIR=str(tmp_path / "uploads"), TESTING=True)
    with app.app_context():
        db.init_schema()
        with db.transaction():
            seed_hero()
        from app.services import derive
        derive.rebuild_allocations(HERO_ID)
        derive.refresh_health(HERO_ID)
    return app
