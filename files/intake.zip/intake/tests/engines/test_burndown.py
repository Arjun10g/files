"""PRN burndown against tests/golden/burndown.json."""
import json
from pathlib import Path

import pytest

from app.engines import burndown

G = json.loads((Path(__file__).resolve().parents[1] / "golden" / "burndown.json").read_text(encoding="utf-8"))


@pytest.mark.parametrize("case", G["cases"], ids=lambda c: c["name"])
def test_burndown(case):
    got = burndown.burndown(case["prn"], case["charges"], case["planned"], case["today"])
    for key, value in case["expected"].items():
        assert got[key] == value, key
    assert len(got["months"]) == len(got["charged_cum"]) == len(got["forecast_cum"]) == len(got["funded_line"])
