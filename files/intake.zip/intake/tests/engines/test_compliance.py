"""CRQ compliance rules against tests/golden/compliance.json."""
import json
from pathlib import Path

import pytest

from app.engines import compliance

G = json.loads((Path(__file__).resolve().parents[1] / "golden" / "compliance.json").read_text(encoding="utf-8"))


@pytest.mark.parametrize("case", G["cases"], ids=lambda c: c["name"])
def test_check_cr(case):
    ctx = {"now": case["now"]} if case.get("now") else None
    got = compliance.check_cr(case["cr"], case["today"], ctx)
    assert [f["code"] for f in got["flags"]] == case["expected_codes"]
    assert got["ok"] is case["ok"]
    assert got["sto_suggestion"] == case["sto_suggestion"]
    if "expected_messages" in case:
        assert [f["message"] for f in got["flags"]] == case["expected_messages"]
    assert len(got["findings"]) == 13
    for code, due in (case.get("not_due") or {}).items():
        f = next(x for x in got["findings"] if x["rule_id"] == code)
        assert (f["status"], f["due_date"]) == ("Not due yet", due), code
        assert f["reason"].startswith("Due by ")
    checked = [f for f in got["findings"] if f["status"] in ("Pass", "Fail", "Warn")]
    assert got["score"] == round(sum(f["status"] == "Pass" for f in checked) / len(checked) * 100)
    for f in got["flags"]:
        assert f["fix"] and f["message"]


def test_crq_window_is_saturday_train_slot():
    start, end = compliance.crq_window("2027-02-20")
    assert start == "2027-02-20T02:00:00-05:00"
    assert end == "2027-02-20T06:00:00-05:00"
