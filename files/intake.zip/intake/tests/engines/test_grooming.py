"""Grooming slotter against tests/golden/grooming.json."""
import json
from datetime import datetime
from pathlib import Path

import pytest

from app.engines import grooming

G = json.loads((Path(__file__).resolve().parents[1] / "golden" / "grooming.json").read_text(encoding="utf-8"))


@pytest.mark.parametrize("case", G["next_session"], ids=lambda c: c["now"])
def test_next_session(case):
    assert grooming.next_session_date(datetime.fromisoformat(case["now"])).isoformat() == case["expected"]


def test_hero_save_with_tz_aware_demo_now():
    from zoneinfo import ZoneInfo
    now = datetime(2026, 10, 19, 9, 30, tzinfo=ZoneInfo("America/Toronto"))
    placed = grooming.slot_one({"priority": 2}, [], now)
    assert placed["session_date"] == "2026-10-20"
    assert placed["label"] == G["label"]["expected"]


def test_full_session_overflows_and_p1_bumps():
    c = G["full_session"]
    now = datetime.fromisoformat(c["now"])
    p2 = grooming.slot_one({"priority": 2}, [c["session"]], now)
    assert p2["session_date"] == c["p2_expected"]
    assert p2["bumped"] is None
    p1 = grooming.slot_one({"priority": 1}, [c["session"]], now)
    assert p1["session_date"] == c["p1_expected"]
    assert p1["session_id"] == 7
    assert p1["bumped"]["initiative_id"] == c["p1_bumped_initiative"]
    assert p1["bumped"]["to_session_date"] == c["p1_bumped_to"]


def test_auto_slot_orders_p1_first():
    c = G["auto_slot"]
    result = grooming.auto_slot(c["candidates"], [c["session"]], datetime.fromisoformat(c["now"]))
    got = [{k: a[k] for k in ("initiative_id", "session_date", "session_id", "slot_order")}
           for a in result["assignments"]]
    assert got == c["expected"]
    assert result["unslotted"] == []


def test_cancelled_sessions_are_skipped():
    s = {"id": 9, "session_date": "2026-10-20", "start_time": "10:00", "capacity": 6, "status": "Cancelled",
         "slots": []}
    placed = grooming.slot_one({"priority": 3}, [s], datetime(2026, 10, 19, 9, 30))
    assert placed["session_id"] is None
    assert placed["session_date"] == "2026-10-22"
