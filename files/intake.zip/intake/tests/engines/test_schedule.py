"""Scheduler, CPM and slip propagation against tests/golden/schedule.json."""
import copy
import json
from pathlib import Path

import pytest

from app.engines import schedule

ROOT = Path(__file__).resolve().parents[1]
G = json.loads((ROOT / "golden" / "schedule.json").read_text(encoding="utf-8"))
BUNDLE = json.loads((ROOT / "fixtures" / "bundle_hero.json").read_text(encoding="utf-8"))


def _dated(plan_tasks, dates):
    ids = {t["wbs_code"]: i + 1 for i, t in enumerate(plan_tasks)}
    out = []
    for t in plan_tasks:
        s, e = dates[t["wbs_code"]]["planned_start"], dates[t["wbs_code"]]["planned_end"]
        out.append({"id": ids[t["wbs_code"]], "wbs_code": t["wbs_code"], "parent_id": ids.get(t.get("parent_code")),
                    "planned_start": s, "planned_end": e, "est_hours": t.get("est_hours", 1),
                    "is_milestone": t.get("is_milestone"), "phase": t.get("phase"),
                    "depends_on": [ids[d] for d in t["depends_on"]]})
    return out, {v: k for k, v in ids.items()}


def test_cpm_example():
    c = G["cpm_example"]
    dates = schedule.schedule_plan(c["tasks"], c["plan_start"])
    assert {k: [v["planned_start"], v["planned_end"]] for k, v in dates.items()} == c["expected_dates"]
    tasks, code_of = _dated(c["tasks"], dates)
    net = schedule.cpm(tasks)
    assert {code_of[i]: r["float_bd"] for i, r in net.items()} == c["float"]
    assert [code_of[i] for i in schedule.critical_path(tasks)] == c["critical"]


def test_cycle_raises_schedule_error():
    with pytest.raises(schedule.ScheduleError) as err:
        schedule.schedule_plan(G["cycle"]["tasks"], "2026-11-02")
    for code in G["cycle"]["cycle_contains"]:
        assert code in err.value.cycle
    assert "loop" in str(err.value)


def test_cycle_in_dated_tasks():
    tasks = [{"id": 1, "wbs_code": "WBS-100", "planned_start": "2026-11-02", "planned_end": "2026-11-03",
              "est_hours": 7, "depends_on": [2]},
             {"id": 2, "wbs_code": "WBS-200", "planned_start": "2026-11-04", "planned_end": "2026-11-05",
              "est_hours": 7, "depends_on": [1]}]
    with pytest.raises(schedule.ScheduleError):
        schedule.critical_path(tasks)
    g = schedule.build_gantt(tasks, "2026-10-19")
    assert g["critical_path"] == [] and g["dependency_loop"]


@pytest.mark.parametrize("case", G["durations"], ids=lambda c: f"{c['est_hours']}h@{c['allocation_pct']}")
def test_duration_from_hours(case):
    assert schedule.duration_from_hours(case["est_hours"], case["allocation_pct"]) == case["expected"]


def test_hero_forward_pass_matches_section_6_2():
    c = G["hero_plan"]
    dates = schedule.schedule_plan(c["tasks"], c["plan_start"], target_train=c["target_train"])
    assert {k: [v["planned_start"], v["planned_end"]] for k, v in dates.items()} == c["expected"]
    tasks, _ = _dated(c["tasks"], dates)
    kd = schedule.key_dates(tasks)
    assert (kd["readiness_date"], kd["qa_date"], kd["prod_date"]) == (c["readiness_date"], c["qa_date"], c["prod_date"])
    assert schedule.readiness_float(kd["readiness_date"], c["target_train"]["train_date"]) == c["float_bd"]


def test_hero_gantt_from_bundle():
    c = G["hero_gantt_from_bundle"]
    g = schedule.build_gantt(BUNDLE["tasks"], "2026-10-19", target_train=BUNDLE["target_train"])
    by_code = {t["wbs_code"]: t for t in g["tasks"]}
    assert sorted(code for code, t in by_code.items() if t["critical"]) == sorted(c["critical_codes"])
    for code, fl in c["float"].items():
        assert by_code[code]["float_bd"] == fl
    assert by_code["WBS-200"]["is_summary"] and not by_code["WBS-200"]["critical"]
    assert (g["readiness_date"], g["qa_date"], g["prod_date"], g["float_bd"]) == (
        "2027-02-17", "2027-02-10", "2027-02-20", 2)
    assert g["freeze"] == {"start": "2026-12-14", "end": "2027-01-08"}


def _slip(tasks, code, new_end):
    tasks = copy.deepcopy(tasks)
    t = next(x for x in tasks if x["wbs_code"] == code)
    t["planned_end"] = new_end
    moved = schedule.propagate_slip(tasks, t["id"])
    for x in tasks:
        if x["id"] in moved:
            x["planned_start"], x["planned_end"] = moved[x["id"]]
    return tasks, moved


def test_slip_wbs210_plus5_and_back():
    c = G["slip_wbs210_plus5"]
    slipped, moved = _slip(BUNDLE["tasks"], "WBS-210", c["new_end"])
    by_code = {t["wbs_code"]: t for t in slipped}
    code_of = {t["id"]: t["wbs_code"] for t in slipped}
    assert {code_of[i] for i in moved} == set(c["expected"])
    for code, (s, e) in c["expected"].items():
        assert [by_code[code]["planned_start"], by_code[code]["planned_end"]] == [s, e], code
    kd = schedule.key_dates(slipped)
    assert schedule.readiness_float(kd["readiness_date"], "2027-02-20") == c["readiness_float"]
    # untouched rows stay put
    assert by_code["WBS-220"]["planned_end"] == "2027-01-15"
    assert by_code["WBS-100"]["planned_end"] == "2026-11-17"

    restored, _ = _slip(slipped, "WBS-210", "2027-01-15")
    original = {t["wbs_code"]: (t["planned_start"], t["planned_end"]) for t in BUNDLE["tasks"]}
    assert {t["wbs_code"]: (t["planned_start"], t["planned_end"]) for t in restored} == original
