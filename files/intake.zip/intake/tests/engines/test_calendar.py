"""Calendar engine against hand-computed goldens (tests/golden/calendar.json)."""
import json
from datetime import date
from pathlib import Path

import pytest

from app.engines import calendar as cal

G = json.loads((Path(__file__).resolve().parents[1] / "golden" / "calendar.json").read_text(encoding="utf-8"))


@pytest.mark.parametrize("case", G["fiscal"], ids=lambda c: c["date"])
def test_fiscal_quarter(case):
    q = cal.fiscal_quarter(date.fromisoformat(case["date"]))
    assert (q["fy"], q["q"], q["label"]) == (case["fy"], case["q"], case["label"])
    assert cal.fiscal_quarter(case["date"][:7])["q"] == case["q"]


def test_quarter_months():
    c = G["quarter_months"]
    assert cal.quarter(c["fy"], c["q"])["months"] == c["months"]
    assert [q["label"] for q in cal.fiscal_quarters("FY27")] == ["Nov–Jan", "Feb–Apr", "May–Jul", "Aug–Oct"]


@pytest.mark.parametrize("case", G["count_business_days"], ids=lambda c: f"{c['start']}..{c['end']}")
def test_count_business_days(case):
    assert cal.count_business_days(case["start"], case["end"]) == case["expected"]


@pytest.mark.parametrize("case", G["end_after_business_days"], ids=lambda c: f"{c['start']}+{c['n']}")
def test_end_after_business_days(case):
    assert cal.end_after_business_days(case["start"], case["n"]).isoformat() == case["expected"]


@pytest.mark.parametrize("case", G["next_business_day"], ids=lambda c: c["date"])
def test_next_business_day(case):
    assert cal.next_business_day(case["date"]).isoformat() == case["expected"]


@pytest.mark.parametrize("case", G["add_business_days"], ids=lambda c: f"{c['date']}{c['n']:+d}")
def test_add_business_days(case):
    assert cal.add_business_days(case["date"], case["n"]).isoformat() == case["expected"]


@pytest.mark.parametrize("case", G["strictly_between"], ids=lambda c: f"{c['a']}..{c['b']}")
def test_strictly_between(case):
    assert cal.business_days_strictly_between(case["a"], case["b"]) == case["expected"]


@pytest.mark.parametrize("case", G["business_days_after"], ids=lambda c: f"{c['a']}..{c['b']}")
def test_business_days_after(case):
    assert cal.business_days_after(case["a"], case["b"]) == case["expected"]


@pytest.mark.parametrize("case", G["in_freeze"], ids=lambda c: c["date"])
def test_in_freeze(case):
    assert cal.in_freeze(case["date"]) is case["expected"]


@pytest.mark.parametrize("case", G["next_train_after"], ids=lambda c: c["date"])
def test_next_train_after(case):
    code, d = cal.next_train_after(case["date"])
    assert (code, d.isoformat()) == (case["code"], case["train_date"])


def test_iso_week_and_errors():
    assert cal.parse_iso_week(G["iso_week"]["week"]).isoformat() == G["iso_week"]["monday"]
    assert cal.iso_week("2026-10-19") == "2026-W43"
    with pytest.raises(ValueError):
        cal.parse_iso_week("2026-43")


def test_holidays_are_not_business_days():
    for d in ("2026-11-11", "2026-12-25", "2026-12-28", "2027-01-01", "2027-02-15"):
        assert not cal.is_business_day(d)
    assert cal.is_business_day("2026-10-19")
    assert not cal.is_business_day("2027-02-20")


def test_display_formats():
    assert cal.fmt_date("2026-10-19") == "19 Oct 2026"
    assert cal.fmt_day("2026-10-20") == "Tue 20 Oct"
    assert cal.fmt_day_long("2027-02-20") == "Sat 20 Feb 2027"
    assert cal.fmt_hours(1100) == "1,100"
    assert cal.fmt_hours(137.5) == "137.5"
    assert cal.month_label("2026-11") == "Nov 2026"
