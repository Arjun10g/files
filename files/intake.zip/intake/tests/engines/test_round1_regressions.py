"""Regression tests for QA round 1 (QA-B-01..08). Expected values are hand-computed in the comments."""
import copy
import json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import pytest

from app.engines import (
    burndown,
    compliance,
    grooming,
    health,
    l2,
    sa_completeness,
    schedule,
)

ROOT = Path(__file__).resolve().parents[1]
BUNDLE = json.loads((ROOT / "fixtures" / "bundle_hero.json").read_text(encoding="utf-8"))
CATALOG = BUNDLE["component_catalog"]


def test_qa_b01_one_contingency_figure():
    # 868 x 0.15 = 130.2 -> 130 contingency; 868 + 130 = 998 -> nearest 50 = 1,000, so rounding is +2.
    est = l2.estimate_l2([{"code": "APIP", "complexity": "High"}, {"code": "EDP", "complexity": "Medium"},
                          {"code": "CIAM", "complexity": "Medium"}, {"code": "SRE", "complexity": "Low"}], CATALOG)
    phases = {p["phase"]: p["hours"] for p in est["by_phase"]}
    assert est["contingency_hours"] == phases["Contingency"] == 130
    assert est["rounding_hours"] == phases["Rounding"] == 2
    assert sum(phases.values()) == est["total_hours"] == 1000


def test_qa_b02_grooming_converts_utc_now():
    # 20:30Z on 19 Oct is 16:30 EDT, before the 17:00 cut-off for Tue 20 Oct; 21:30Z is 17:30 EDT, after it.
    assert grooming.next_session_date(datetime(2026, 10, 19, 20, 30, tzinfo=ZoneInfo("UTC"))).isoformat() == "2026-10-20"
    assert grooming.next_session_date(datetime(2026, 10, 19, 21, 30, tzinfo=ZoneInfo("UTC"))).isoformat() == "2026-10-22"


def test_qa_b03_slip_reaches_child_through_inherited_dependency():
    # A ends 10 Nov -> Q 12-13 Nov (11 Nov holiday) -> P 16-17 Nov; X (child of P, no own deps) inherits Q -> 16-17.
    tasks = [
        {"id": 4, "wbs_code": "X", "parent_id": 3, "est_hours": 7, "planned_start": "2026-11-12",
         "planned_end": "2026-11-13", "depends_on": []},
        {"id": 1, "wbs_code": "A", "planned_start": "2026-11-02", "planned_end": "2026-11-10", "depends_on": []},
        {"id": 2, "wbs_code": "Q", "est_hours": 7, "planned_start": "2026-11-09", "planned_end": "2026-11-10",
         "depends_on": [1]},
        {"id": 3, "wbs_code": "P", "est_hours": 14, "planned_start": "2026-11-12", "planned_end": "2026-11-13",
         "depends_on": [2]},
    ]
    moved = schedule.propagate_slip(tasks, 1)
    assert moved == {2: ("2026-11-12", "2026-11-13"), 3: ("2026-11-16", "2026-11-17"),
                     4: ("2026-11-16", "2026-11-17")}


def _cr(**kw):
    cr = {"id": 1, "raised_at": "2026-10-30", "crq_start": "2026-11-21T02:00:00-05:00",
          "crq_end": "2026-11-21T06:00:00-05:00", "release_type": "Bundle", "release_train": "DC-2611",
          "affected_cis": ["OLB-WEB"], "impacted_components": ["OLB"], "crq_approval_status": "Approved",
          "sto_approval": "Tentative Go", "cms_lead_id": 19, "rel_lead_id": 20, "backout_attachment_id": 5}
    cr.update(kw)
    return cr


@pytest.mark.parametrize("today,expected", [
    ("2026-11-09", None),               # T-9: no suggestion before T-5 (round 2 decision 2)
    ("2026-11-13", "Tentative No Go"),  # T-5 (16..20 Nov): any open flag holds it
])
def test_qa_b04_sto_suggestion_from_t5(today, expected):
    r = compliance.check_cr(_cr(cms_lead_id=None), today)
    assert [f["code"] for f in r["flags"]] == ["CR-07"]
    assert r["sto_suggestion"] == expected


def test_qa_b04_hero_draft_has_one_flag_and_no_suggestion_on_19_oct():
    r = compliance.check_cr(_cr(crq_start="2027-02-20T02:00:00-05:00", crq_end="2027-02-20T06:00:00-05:00",
                                release_train="DC-2702", raised_at="2026-10-19", backout_attachment_id=None),
                            "2026-10-19")
    assert [f["code"] for f in r["flags"]] == ["CR-11"] and r["sto_suggestion"] is None


def test_qa_b05_utc_window_judged_in_toronto_time():
    # 03:00Z-05:00Z on 14 Dec is 22:00-00:00 EST on Sun 13 Dec: outside the freeze that starts 14 Dec.
    outside = compliance.check_cr(_cr(crq_start="2026-12-14T03:00:00+00:00", crq_end="2026-12-14T05:00:00+00:00",
                                      release_type="Independent", release_train=None), "2026-11-02")
    assert "CR-06" not in {f["code"] for f in outside["flags"]}
    # 06:00Z-08:00Z on 14 Dec is 01:00-03:00 EST on 14 Dec: inside the freeze.
    inside = compliance.check_cr(_cr(crq_start="2026-12-14T06:00:00+00:00", crq_end="2026-12-14T08:00:00+00:00",
                                     release_type="Independent", release_train=None), "2026-11-02")
    assert "CR-06" in {f["code"] for f in inside["flags"]}


@pytest.mark.parametrize("line", ["Rollback is not defined yet.", "Security is via mTLS.", "Data stays in Canada.",
                                  "questions go to sana"])
def test_qa_b06_body_sentences_are_not_headings(line):
    text = BUNDLE["sa_doc_text"] + "\n" + line + "\n"
    assert sa_completeness.score(text)["completeness"] == 88


@pytest.mark.parametrize("name", ["SA_US_API_Enhancement_v1.2.md", "SA_US_API_Enhancement_v1.2.docx",
                                  "SA_US_API_Enhancement_v1.2.pdf"])
def test_qa_b06_hero_sample_files_score_88(name):
    path = ROOT.parent / "app" / "seed" / "files" / name
    if not path.exists():
        pytest.skip("sample SA file not shipped yet")
    from app.textract import extract_text
    r = sa_completeness.score(extract_text(path))
    assert (r["completeness"], r["missing"]) == (88, ["Backout plan"])


@pytest.mark.parametrize("current_hours,rag", [(1250, "Red"), (750, "Red"), (1100, "Amber"), (1000, "Green")])
def test_qa_b07_scope_delta_is_relative_to_baseline(current_hours, rag):
    # Baseline 1,000 h: 1,250 -> +25% Red; 750 -> -25% Red; 1,100 -> +10% Amber; 1,000 -> 0% Green.
    b = copy.deepcopy(BUNDLE)
    b["components"] = []
    b["initiative"]["l2_hours"] = current_hours
    assert health.scope_dimension(b, "2026-10-19")["rag"] == rag


def test_qa_b08_current_month_charges_not_double_counted():
    # Oct charged 40 h of a 50 h Oct plan: forecast for Oct = 40 + (50 - 40) = 50, then Nov +30 = 80.
    r = burndown.burndown({"prn_code": "P", "funded_hours": 100, "start_month": "2026-10", "end_month": "2026-11"},
                          [{"month": "2026-10", "charged_hours": 40}], {"2026-10": 50, "2026-11": 30}, "2026-10-19")
    assert r["forecast_cum"] == [50.0, 80.0] and r["status"] == "on_track"


# ------------------------------------------------------------------ round 1b (QA-C-11, QA-C-29)
def test_qa_c11_crq_window_follows_production_milestone():
    hero = _cr(crq_start="2027-02-20T02:00:00-05:00", crq_end="2027-02-20T06:00:00-05:00", release_train="DC-2702",
               raised_at="2026-10-19", backout_attachment_id=None)
    ctx = {"plan_prod_date": "2027-02-20", "target_train": {"code": "DC-2702", "train_date": "2027-02-20"}}
    assert [f["code"] for f in compliance.check_cr(hero, "2026-10-19", ctx)["flags"]] == ["CR-11"]
    # WBS-210 +5 bd pushes WBS-700 to DC-2703 (Sat 20 Mar 2027); the Feb window no longer matches the plan.
    slipped = dict(ctx, plan_prod_date="2027-03-20")
    r = compliance.check_cr(hero, "2026-10-19", slipped)
    msgs = {f["code"]: f["message"] for f in r["flags"]}
    assert set(msgs) == {"CR-11", "CR-12", "CR-13"}
    assert msgs["CR-12"].startswith("CRQ window doesn't match the plan's production date (Sat 20 Mar 2027)")
    assert msgs["CR-13"].startswith("Production date is after target release DC-2702")
    assert {f["code"] for f in r["flags"] if f["blocking"]} == {"CR-12", "CR-13"}


def test_qa_c29_planning_without_plan_is_not_scored():
    b = copy.deepcopy(BUNDLE)
    b["tasks"], b["allocations"] = [], []
    h = health.compute_health(b, "2026-10-19")
    assert h["scored"] is False and h["overall"] is None
    assert all(d["rag"] is None for d in h["dimensions"].values())
    assert h["dimensions"]["schedule"]["reasons"] == ["Generate the project plan to score health."]


def test_qa_c11_independent_crqs_are_exempt_from_plan_alignment():
    ind = _cr(crq_start="2027-02-13T02:00:00-05:00", crq_end="2027-02-13T06:00:00-05:00",
              release_type="Independent", release_train=None, raised_at="2026-10-19")
    ctx = {"plan_prod_date": "2027-03-20", "target_train": {"code": "DC-2702", "train_date": "2027-02-20"}}
    codes = {f["code"] for f in compliance.check_cr(ind, "2026-10-19", ctx)["flags"]}
    assert not codes & {"CR-12", "CR-13"}


# ------------------------------------------------------------------ round 2 (decisions 2, 3, 7, 13)
def test_r2_compliance_reads_plan_from_bundle_and_not_due_yet():
    hero = _cr(crq_start="2027-02-20T02:00:00-05:00", crq_end="2027-02-20T06:00:00-05:00", release_train="DC-2702",
               raised_at="2026-10-19", backout_attachment_id=None, sto_approval=None, crq_approval_status="Draft")
    r = compliance.check_cr(hero, "2026-10-19", {"bundle": BUNDLE})
    by = {f["rule_id"]: f for f in r["findings"]}
    assert [f["code"] for f in r["flags"]] == ["CR-11"]
    assert by["CR-12"]["detail"] == "Window matches WBS-700 on Sat 20 Feb 2027."
    assert by["CR-13"]["status"] == "Pass"
    # T-2 for Sat 20 Feb is Wed 17 Feb (Thu 18, Fri 19 left); validation evidence is due the day after the window.
    assert (by["CR-01"]["status"], by["CR-01"]["due_date"]) == ("Not due yet", "2027-02-17")
    assert by["CR-01"]["reason"] == "Due by Wed 17 Feb 2027 (T-2 business days)."
    assert by["CR-02"]["due_date"] == "2027-02-17" and by["CR-04"]["due_date"] == "2027-02-21"
    # 13 rules: 4 not due, 1 fail (CR-11), 8 pass -> 8 / 9 = 89%
    assert (r["not_due"], r["checked"], r["passed"], r["score"]) == (4, 9, 8, 89)
    assert r["sto_suggestion"] is None


def test_r2_attention_lists_tight_schedule_amber():
    h = health.compute_health(copy.deepcopy(BUNDLE), "2026-10-19")
    assert h["attention"] == ["SA capacity constraint affecting WBS-100",
                              "Readiness float 2 business days to DC-2702 affecting WBS-600"]
    b = copy.deepcopy(BUNDLE)
    b["initiative"]["rag_overrides_json"] = {"schedule": {"rag": "Green", "reason": "Train confirmed"}}
    assert "Readiness float 2 business days to DC-2702 affecting WBS-600" not in \
        health.compute_health(b, "2026-10-19")["attention"]


def test_r2_quarter_labels_and_team_label():
    from app.engines import calendar as cal
    from app.engines import capacity
    assert cal.quarter_short(cal.fiscal_quarter("2026-10")) == "Q4 FY26"
    cols = capacity.month_columns(["2026-10", "2026-11"])
    assert [c["quarter"] for c in cols] == ["Q4 FY26", "Q1 FY27"]
    assert capacity.team_label({"team": "EAPI", "team_label": "EAPI"}) == "EAPI Tech Lead"
    assert capacity.team_label({"team": "EAPI", "team_label": "EAPI (Dev1)"}) == "EAPI (Dev1)"


@pytest.mark.parametrize("today,status", [("2027-02-16", "Not due yet"), ("2027-02-17", "Not due yet"),
                                          ("2027-02-18", "Fail")])
def test_qa_b09_due_date_is_inclusive(today, status):
    # Window Sat 20 Feb 2027: due by Wed 17 Feb (T-2); Fail only from Thu 18 Feb.
    cr = _cr(crq_start="2027-02-20T02:00:00-05:00", crq_end="2027-02-20T06:00:00-05:00", release_train="DC-2702",
             raised_at="2026-10-19", sto_approval=None, crq_approval_status="Draft")
    by = {f["rule_id"]: f["status"] for f in compliance.check_cr(cr, today)["findings"]}
    assert by["CR-01"] == by["CR-02"] == status


# ------------------------------------------------------------------ round 3 (N4, N6)
def test_r3_sto_not_requested_before_t5():
    # Sat 20 Feb 2027: Fri 19, Thu 18, Wed 17, Tue 16 (Mon 15 Feb is Family Day), Fri 12, Thu 11 -> T-5 = Thu 11 Feb.
    cr = _cr(crq_start="2027-02-20T02:00:00-05:00", crq_end="2027-02-20T06:00:00-05:00", release_train="DC-2702",
             raised_at="2026-10-19", sto_approval=None, crq_approval_status="Draft", backout_attachment_id=None)
    full = compliance.check_cr(cr, "2026-10-19")
    assert full["sto_readiness"] == "Not requested"
    r = full["sto_readiness_detail"]
    assert r == {"status": "Not requested", "suggest_from": "2027-02-11",
                 "label": "Not requested · auto-suggest from T-5 business days (Thu 11 Feb 2027)"}
    inside = compliance.check_cr(cr, "2027-02-11")["sto_readiness_detail"]
    assert inside["status"] == "Not ready" and inside["label"] == "Not ready · suggested Tentative No Go"
    asked = compliance.check_cr(dict(cr, sto_approval="Tentative Go"), "2026-10-19")
    assert asked["sto_readiness"] == "Tentative"


def test_r3_burn_rate_is_three_month_average_of_charged_months():
    # charged Jun 100, Jul 200, Aug 300, Sep 400 -> last three charged months (Jul-Sep) = 900 / 3 = 300 h/month
    r = burndown.burndown({"prn_code": "P", "funded_hours": 2000, "start_month": "2026-06", "end_month": "2026-12"},
                          [{"month": m, "charged_hours": h} for m, h in
                           (("2026-06", 100), ("2026-07", 200), ("2026-08", 300), ("2026-09", 400))], {}, "2026-10-19")
    assert (r["burn_rate"], r["burn_rate_window"], r["burn_rate_months"]) == (
        300.0, "3-month average", ["2026-07", "2026-08", "2026-09"])
