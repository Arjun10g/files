"""L2 estimate against hand-computed goldens (tests/golden/l2.json)."""
import json
from pathlib import Path

import pytest

from app.engines import l2

G = json.loads((Path(__file__).resolve().parents[1] / "golden" / "l2.json").read_text(encoding="utf-8"))


@pytest.mark.parametrize("case", G["cases"], ids=lambda c: c["name"])
def test_estimate(case):
    est = l2.estimate_l2(case["components"], G["catalog"])
    for key, value in case["expected"].items():
        assert est[key] == value, key
    if case["components"]:
        assert sum(r["hours"] for r in est["by_component"]) == est["dev_hours"]
        assert sum(p["hours"] for p in est["by_phase"]) == est["total_hours"]
    else:
        assert est["warnings"]


@pytest.mark.parametrize("hours,size", G["tshirt"])
def test_tshirt(hours, size):
    assert l2.tshirt(hours) == size


def test_hero_by_component_and_rule_text():
    est = l2.estimate_l2(G["cases"][0]["components"], G["catalog"])
    assert [(r["code"], r["complexity"], r["hours"]) for r in est["by_component"]] == [
        ("APIP", "High", 280), ("EDP", "Medium", 120), ("CIAM", "Medium", 120), ("SRE", "Low", 40)]
    assert "nearest 50" in est["rule"]
    assert any("1,000 h" in s for s in est["steps"])
