"""Capacity engine against tests/golden/capacity.json."""
import json
from pathlib import Path

import pytest

from app.engines import capacity

G = json.loads((Path(__file__).resolve().parents[1] / "golden" / "capacity.json").read_text(encoding="utf-8"))


@pytest.mark.parametrize("case", G["spread"], ids=lambda c: c["name"])
def test_spread_hours(case):
    got = capacity.spread_hours(case["start"], case["end"], case["hours"])
    assert got == case["expected"]
    if case["hours"]:
        assert round(sum(got.values()), 6) == case["hours"]


@pytest.mark.parametrize("util,band", G["bands"])
def test_bands(util, band):
    assert capacity.band(util) == band


def test_no_availability_never_divides_by_zero():
    assert capacity.utilisation(10, 0) is None
    assert capacity.band(None, 10) == G["no_availability"]["with_demand"]
    assert capacity.band(None, 0) == G["no_availability"]["without_demand"]


@pytest.mark.parametrize("case", G["hero_people"], ids=lambda c: c["name"])
def test_hero_people(case):
    util = capacity.utilisation(case["demand"], case["available"])
    assert int(util * 100 + 0.5) == case["pct"]
    assert capacity.band(util) == case["band"]


def test_team_totals():
    c = G["team_case"]
    teams = capacity.team_totals(c["resources"], c["allocations"], c["months"])
    got = [{k: t[k] for k in ("team", "available", "confirmed", "tentative", "band")} for t in teams]
    assert got == c["expected_teams"]


def test_compute_capacity_groupings():
    c = G["team_case"]
    by_res = capacity.compute_capacity(c["resources"], c["allocations"], c["months"], "resource")
    assert [r["label"] for r in by_res["rows"]] == ["A", "B", "C"]
    assert by_res["rows"][2]["cells"][0]["band"] == "over"
    by_team = capacity.compute_capacity(c["resources"], c["allocations"], c["months"], "team")
    assert [r["key"] for r in by_team["rows"]] == ["EAPI (Dev1)", "CIAM"]
    by_q = capacity.compute_capacity(c["resources"], c["allocations"], ["2026-11", "2026-12", "2027-01"], "quarter")
    assert by_q["months"] == ["FY27-Q1"]
    cell = by_q["rows"][2]["cells"][0]
    assert (cell["label"], cell["available"], cell["confirmed"]) == ("Nov–Jan", 100.0, 115.0)
