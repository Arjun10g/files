"""SA completeness checklist against tests/golden/sa_completeness.json."""
import json
from pathlib import Path

import pytest

from app.engines import sa_completeness

ROOT = Path(__file__).resolve().parents[1]
G = json.loads((ROOT / "golden" / "sa_completeness.json").read_text(encoding="utf-8"))
BUNDLE = json.loads((ROOT / "fixtures" / "bundle_hero.json").read_text(encoding="utf-8"))


def _check(got, exp):
    for key in ("completeness", "sections_found", "missing", "author", "version"):
        assert got[key] == exp[key], key


def test_hero_sa_floors_to_88():
    _check(sa_completeness.score(BUNDLE["sa_doc_text"]), G["hero_from_bundle"])


@pytest.mark.parametrize("case", G["cases"], ids=lambda c: c["name"])
def test_cases(case):
    _check(sa_completeness.score(case["text"]), case)
