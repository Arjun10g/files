"""Reminder scheduler against tests/golden/reminders.json."""
import json
from pathlib import Path

import pytest

from app.engines import reminders

G = json.loads((Path(__file__).resolve().parents[1] / "golden" / "reminders.json").read_text(encoding="utf-8"))


@pytest.mark.parametrize("case", G["next_reminder"], ids=lambda c: f"{c['since']}@{c['today']}")
def test_next_reminder(case):
    assert reminders.next_reminder(case["since"], case["every"], case["today"]).isoformat() == case["expected"]


def test_l2_due_dates():
    c = G["l2_due_dates"]
    past, _ = reminders.due_dates(c["since"], c["every"], c["today"])
    assert [d.isoformat() for d in past] == c["past"]


def test_hero_sa_reminder_next_wednesday():
    c = G["hero_sa"]
    out = reminders.due_reminders({"initiatives": [c["initiative"]]}, c["today"])
    assert [n["dedupe_key"] for n in out] == c["expected_keys"]
    assert out[0]["to_name"] == c["expected_to"]
    assert out[0]["action_required_by"] == c["expected_action_by"]
    assert out[0]["rule"] == "sa_action_required"


def test_third_reminder_copies_dc_pm():
    c = G["hero_sa"]
    third = G["third_reminder_cc"]
    out = reminders.due_reminders({"initiatives": [c["initiative"]]}, third["today"])
    n = next(x for x in out if x["dedupe_key"] == third["expected_key"])
    assert n["cc_names"] == third["cc"]


def test_l2_reminders_and_escalation():
    c = G["l2_pending"]
    state = {"initiatives": [c["initiative"]], "delivery_lead": c["delivery_lead"]}
    out = reminders.due_reminders(state, "2026-10-19")
    assert [n["dedupe_key"] for n in out] == c["on_2026_10_19"]["keys"]
    assert reminders.l2_reminder_count(c["initiative"], "2026-10-19") == c["on_2026_10_19"]["count"]
    out = reminders.due_reminders(state, "2026-10-20")
    assert [n["dedupe_key"] for n in out] == c["on_2026_10_20"]["keys"]
    esc = out[-1]
    assert esc["rule"] == "l2_escalation" and esc["to_name"] == c["on_2026_10_20"]["escalation_to"]


def test_no_reminder_when_sa_complete_or_after_planning():
    ini = dict(G["hero_sa"]["initiative"], sa_completeness=100)
    assert reminders.due_reminders({"initiatives": [ini]}, "2026-10-19") == []
    ini = dict(G["hero_sa"]["initiative"], stage="Planning")
    assert reminders.due_reminders({"initiatives": [ini]}, "2026-10-19") == []
