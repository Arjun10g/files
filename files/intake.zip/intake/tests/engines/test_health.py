"""Hero deck parity (tests/golden/hero_health.json): health from tests/fixtures/bundle_hero.json."""
import copy
import json
from collections import defaultdict
from pathlib import Path

import pytest

from app.engines import capacity, health, schedule

ROOT = Path(__file__).resolve().parents[1]
G = json.loads((ROOT / "golden" / "hero_health.json").read_text(encoding="utf-8"))
BUNDLE = json.loads((ROOT / "fixtures" / "bundle_hero.json").read_text(encoding="utf-8"))
TODAY = G["today"]


def _reallocate(bundle):
    """Re-spread task hours after a plan edit and update each person's committed hours to match."""
    old = defaultdict(float)
    for a in bundle["allocations"]:
        old[(a["resource_id"], a["month"])] += a["hours"]
    allocs = []
    parents = {t["parent_id"] for t in bundle["tasks"] if t.get("parent_id")}
    for t in bundle["tasks"]:
        if t["id"] in parents and not t["est_hours"]:
            continue
        if not t.get("resource_id"):
            continue
        for m, h in capacity.spread_hours(t["planned_start"], t["planned_end"], t["est_hours"]).items():
            allocs.append({"resource_id": t["resource_id"], "task_id": t["id"], "month": m, "hours": h,
                           "firmness": "confirmed"})
    new = defaultdict(float)
    for a in allocs:
        new[(a["resource_id"], a["month"])] += a["hours"]
    for r in bundle["resources"]:
        committed = dict(r.get("committed") or {})
        for (rid, m) in set(old) | set(new):
            if rid == r["id"]:
                committed[m] = round(committed.get(m, 0.0) - old[(rid, m)] + new[(rid, m)], 1)
        r["committed"] = committed
    bundle["allocations"] = allocs
    return bundle


def _dims(h):
    return {k: v["rag"] for k, v in h["dimensions"].items()}


def test_as_planned_matches_deck():
    exp = G["as_planned"]
    h = health.compute_health(copy.deepcopy(BUNDLE), TODAY)
    assert h["scored"] is True
    assert h["overall"] == exp["overall"]
    assert _dims(h) == exp["dimensions"]
    assert h["attention"] == exp["attention"]
    s = h["dimensions"]["schedule"]
    assert (s["metrics"]["readiness_date"], s["metrics"]["train_date"], s["metrics"]["float_bd"]) == (
        exp["schedule"]["readiness_date"], exp["schedule"]["train_date"], exp["schedule"]["float_bd"])
    assert s["reasons"][0] == exp["schedule"]["reason"]
    r = h["dimensions"]["resources"]
    assert r["metrics"]["peak_resource_id"] == exp["resources"]["peak_resource_id"]
    assert r["metrics"]["peak_month"] == exp["resources"]["peak_month"]
    assert int(r["metrics"]["peak_util"] * 100 + 0.5) == exp["resources"]["peak_pct"]
    assert r["reasons"][0] == exp["resources"]["reason"]
    assert h["dimensions"]["scope"]["metrics"]["sa_completeness"] == exp["scope"]["sa_completeness"]
    d = h["dimensions"]["dependencies"]
    assert d["metrics"]["min_need_by_bd"] == exp["dependencies"]["min_need_by_bd"]
    assert d["reasons"][0] == exp["dependencies"]["reason"]
    b = h["dimensions"]["budget"]
    assert b["reasons"][0] == exp["budget"]["reason"]
    assert b["metrics"]["planned_hours"] == exp["budget"]["planned_hours"]
    for dim in h["dimensions"].values():
        assert dim["rule"] and dim["explanation"]


def test_suggest_fix_moves_wbs100_to_mateo():
    exp = G["after_fix_move_wbs100_to_mateo"]
    b = copy.deepcopy(BUNDLE)
    t = next(x for x in b["tasks"] if x["wbs_code"] == "WBS-100")
    t["resource_id"], t["resource_name"] = exp["to_resource_id"], "Mateo Brennan"
    _reallocate(b)
    people = {r["id"]: r for r in b["resources"]}
    sana, mateo = people[14], people[15]
    assert int(sana["committed"]["2026-11"] / sana["availability"]["2026-11"] * 100 + 0.5) == exp["sana_nov_pct"]
    assert int(mateo["committed"]["2026-11"] / mateo["availability"]["2026-11"] * 100 + 0.5) == exp["mateo_nov_pct"]
    h = health.compute_health(b, TODAY)
    assert _dims(h) == exp["dimensions"]
    assert h["overall"] == exp["overall"]
    assert h["attention"] == exp["attention"]
    m = h["dimensions"]["resources"]["metrics"]
    assert (m["peak_resource_id"], m["peak_month"], int(m["peak_util"] * 100 + 0.5)) == (
        exp["peak_resource_id"], exp["peak_month"], exp["peak_pct"])


def _slip(bundle, new_end):
    t = next(x for x in bundle["tasks"] if x["wbs_code"] == "WBS-210")
    t["planned_end"] = new_end
    for tid, (s, e) in schedule.propagate_slip(bundle["tasks"], t["id"]).items():
        row = next(x for x in bundle["tasks"] if x["id"] == tid)
        row["planned_start"], row["planned_end"] = s, e
    return _reallocate(bundle)


def test_wbs210_slip_turns_overall_red_and_back():
    exp = G["wbs210_plus5"]
    b = _slip(copy.deepcopy(BUNDLE), exp["new_end"])
    h = health.compute_health(b, TODAY)
    assert _dims(h) == exp["dimensions"]
    assert h["overall"] == exp["overall"]
    assert h["dimensions"]["schedule"]["metrics"]["readiness_date"] == exp["readiness_date"]
    assert h["dimensions"]["schedule"]["metrics"]["float_bd"] == exp["float_bd"]
    for line in exp["attention_contains"]:
        assert line in h["attention"]

    back = G["wbs210_reverted"]
    b = _slip(b, "2027-01-15")
    h = health.compute_health(b, TODAY)
    assert h["overall"] == back["overall"]
    assert h["dimensions"]["schedule"]["rag"] == back["schedule"]
    assert h["dimensions"]["schedule"]["metrics"]["float_bd"] == back["float_bd"]


def test_not_scored_before_planning():
    exp = G["not_scored"]
    b = copy.deepcopy(BUNDLE)
    b["initiative"]["stage"] = exp["stage"]
    h = health.compute_health(b, TODAY)
    assert h["scored"] is exp["scored"]
    assert h["overall"] is exp["overall"]
    assert h["attention"] == []


def test_override_resources_green():
    exp = G["override_resources_green"]
    b = copy.deepcopy(BUNDLE)
    b["initiative"]["rag_overrides_json"] = {"resources": exp["override"]}
    h = health.compute_health(b, TODAY)
    r = h["dimensions"]["resources"]
    assert (r["rag"], r["computed_rag"], r["overridden"]) == (exp["resources"], exp["computed_rag"], True)
    assert r["override_reason"] == exp["override"]["reason"]
    assert h["overall"] == exp["overall"]
    assert h["attention"] == exp["attention"]


@pytest.mark.parametrize("case", G["rollup"], ids=lambda c: "-".join(v[0] for v in c["dims"].values()))
def test_rollup(case):
    assert health.overall_rag(case["dims"]) == case["overall"]


def test_scope_and_dependency_triggers():
    b = copy.deepcopy(BUNDLE)
    b["initiative"]["sa_completeness"] = 55
    b["components"][2]["approval"] = "Rejected"
    h = health.compute_health(b, TODAY)
    assert h["dimensions"]["scope"]["rag"] == "Red"
    assert h["dimensions"]["dependencies"]["rag"] == "Red"
    assert "CIAM / Security approval rejected affecting WBS-230" in h["attention"]
    assert h["overall"] == "Red"


def test_dependency_need_by_within_15_bd_is_amber():
    h = health.compute_health(copy.deepcopy(BUNDLE), "2026-10-29")
    assert h["dimensions"]["dependencies"]["rag"] == "Amber"


def test_budget_gap_and_no_prn():
    b = copy.deepcopy(BUNDLE)
    b["prn"]["charges"] = [{"month": "2026-09", "charged_hours": 330.0}]
    h = health.compute_health(b, TODAY)
    assert h["dimensions"]["budget"]["rag"] == "Red"
    b["prn"] = None
    h = health.compute_health(b, TODAY)
    assert h["dimensions"]["budget"]["rag"] == "Amber"
