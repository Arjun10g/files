"""Shared pytest fixtures (owner B1).

The demo seed is built once per session into a template database; every test gets its own copy (fast and isolated).
Fixtures: app, client, db_conn (a connection inside an app context), hero (RDDC-24817 created through the API),
make_docx / make_pdf (generated upload files).
"""
from __future__ import annotations

import io
import os
import shutil
import sqlite3

import pytest

os.environ["BMO_TODAY"] = "2026-10-19"
os.environ.setdefault("BMO_AI_MODE", "simulated")
os.environ.setdefault("BMO_AI_SPEED", "Fast")

from app import create_app, db


def _make_app(db_path, upload_dir):
    return create_app(DB_PATH=str(db_path), UPLOAD_DIR=str(upload_dir), TESTING=True, TODAY="2026-10-19",
                      AI_MODE="simulated", HAS_API_KEY=False)


@pytest.fixture(scope="session")
def seeded_template(tmp_path_factory):
    from app.seed.seed import reset_database

    root = tmp_path_factory.mktemp("seed")
    db_path, upload_dir = root / "template.db", root / "uploads"
    app = _make_app(db_path, upload_dir)
    with app.app_context():
        reset_database(db.get_db(), upload_dir=str(upload_dir), today="2026-10-19", ai_mode="simulated")
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    conn.execute("PRAGMA journal_mode = DELETE")
    conn.close()
    return db_path, upload_dir


@pytest.fixture
def app(seeded_template, tmp_path):
    template_db, template_uploads = seeded_template
    db_path, upload_dir = tmp_path / "bmo.db", tmp_path / "uploads"
    shutil.copyfile(template_db, db_path)
    shutil.copytree(template_uploads, upload_dir)
    application = _make_app(db_path, upload_dir)
    yield application
    db.close_standalone()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def db_conn(app):
    with app.app_context():
        yield db.get_db()


@pytest.fixture
def hero(client):
    """Create RDDC-24817 from DCI-3391 the way the presenter does; returns the create response JSON."""
    resp = client.post("/api/initiatives", json={"dc_intake": "DCI-3391", "dc_pm_id": 16, "dc_sa_id": 14,
                                                 "tech_lead_id": 3})
    assert resp.status_code == 201, resp.get_json()
    return resp.get_json()


@pytest.fixture
def make_docx():
    def build(paragraphs=None, table=None) -> bytes:
        from docx import Document

        doc = Document()
        for text in paragraphs or ["Solution Architecture: Sample", "Version 1.0 · Author: Sana Whitfield (DC SA)",
                                   "1. Business context", "Expose account APIs to US digital channels."]:
            doc.add_paragraph(text)
        if table:
            grid = doc.add_table(rows=len(table), cols=len(table[0]))
            for r, row in enumerate(table):
                for c, value in enumerate(row):
                    grid.cell(r, c).text = value
        buf = io.BytesIO()
        doc.save(buf)
        return buf.getvalue()
    return build


@pytest.fixture
def make_pdf():
    def build(lines=None) -> bytes:
        lines = lines or ["Solution Architecture: Sample PDF", "Version 2.1 Author: Mateo Brennan",
                          "1. Business context", "Statement downloads for Online Banking."]
        ops = ["BT", "/F1 12 Tf", "72 720 Td", "14 TL"]
        for line in lines:
            safe = line.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
            ops.append(f"({safe}) Tj T*")
        ops.append("ET")
        stream = "\n".join(ops).encode("latin-1")
        objects = [b"<< /Type /Catalog /Pages 2 0 R >>",
                   b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
                   (b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R "
                   b"/Resources << /Font << /F1 5 0 R >> >> >>"),
                   b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream",
                   b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"]
        out = io.BytesIO()
        out.write(b"%PDF-1.4\n")
        offsets = []
        for i, body in enumerate(objects, start=1):
            offsets.append(out.tell())
            out.write(f"{i} 0 obj\n".encode() + body + b"\nendobj\n")
        xref = out.tell()
        out.write(f"xref\n0 {len(objects) + 1}\n0000000000 65535 f \n".encode())
        for off in offsets:
            out.write(f"{off:010d} 00000 n \n".encode())
        out.write(f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode())
        return out.getvalue()
    return build
