"""QA-B (L3) independent engine & business-rule verification.

Every expected value here is computed by hand (arithmetic shown in comments) or with the small plain-Python helpers
in this file, which re-implement the *rule* from docs/00_MASTER_PLAN.md (§1, §6) and PO §5 without calling the code
under test. The goldens in tests/golden are NOT used as an oracle.
"""
from __future__ import annotations

import copy
import itertools
import json
import math
from datetime import date, datetime, timedelta
from pathlib import Path

import pytest

from app.engines import burndown as bd_engine
from app.engines import calendar as cal
from app.engines import (
    capacity,
    compliance,
    grooming,
    health,
    l2,
    reminders,
    sa_completeness,
    schedule,
)

ROOT = Path(__file__).resolve().parents[2]

# ------------------------------------------------------------------ independent oracle helpers (spec, not code)
QA_HOLIDAYS = {date(2026, 11, 11), date(2026, 12, 25), date(2026, 12, 28), date(2027, 1, 1), date(2027, 2, 15)}
QA_FREEZE = (date(2026, 12, 14), date(2027, 1, 8))


def D(s: str) -> date:
    y, m, d = (int(x) for x in s.split("-"))
    return date(y, m, d)


def qa_is_bd(d: date) -> bool:
    return d.weekday() < 5 and d not in QA_HOLIDAYS


def qa_bd_list(a: date, b: date) -> list[date]:
    out, d = [], a
    while d <= b:
        if qa_is_bd(d):
            out.append(d)
        d += timedelta(days=1)
    return out


def qa_add_bd(d: date, n: int) -> date:
    step = 1 if n > 0 else -1
    k = abs(n)
    while k:
        d += timedelta(days=step)
        if qa_is_bd(d):
            k -= 1
    return d


def qa_overall(dims: dict) -> str:
    """Master §1: Red if Schedule Red or >=2 dims Red; else Amber if any Red/Amber; else Green."""
    reds = [k for k, v in dims.items() if v == "Red"]
    if dims["schedule"] == "Red" or len(reds) >= 2:
        return "Red"
    if any(v != "Green" for v in dims.values()):
        return "Amber"
    return "Green"


# ================================================================== CALENDAR
@pytest.mark.parametrize("d, fy, q, label", [
    ("2026-10-31", "FY26", "Q4", "Aug–Oct"),
    ("2026-11-01", "FY27", "Q1", "Nov–Jan"),
    ("2027-01-31", "FY27", "Q1", "Nov–Jan"),
    ("2027-02-01", "FY27", "Q2", "Feb–Apr"),
    ("2027-04-30", "FY27", "Q2", "Feb–Apr"),
    ("2027-05-01", "FY27", "Q3", "May–Jul"),
    ("2027-07-31", "FY27", "Q3", "May–Jul"),
    ("2027-08-01", "FY27", "Q4", "Aug–Oct"),
    ("2027-10-31", "FY27", "Q4", "Aug–Oct"),
    ("2027-11-01", "FY28", "Q1", "Nov–Jan"),
])
def test_fiscal_quarter_boundaries(d, fy, q, label):
    got = cal.fiscal_quarter(D(d))
    assert (got["fy"], got["q"], got["label"]) == (fy, q, label)
    assert "–" in got["label"] and "-" not in got["label"]  # en dash, not hyphen


def test_fiscal_quarter_months_fy27():
    qs = cal.fiscal_quarters("FY27")
    assert [x["months"] for x in qs] == [
        ["2026-11", "2026-12", "2027-01"], ["2027-02", "2027-03", "2027-04"],
        ["2027-05", "2027-06", "2027-07"], ["2027-08", "2027-09", "2027-10"]]
    assert [x["label"] for x in qs] == ["Nov–Jan", "Feb–Apr", "May–Jul", "Aug–Oct"]


@pytest.mark.parametrize("h", ["2026-11-11", "2026-12-25", "2026-12-28", "2027-01-01", "2027-02-15"])
def test_stat_holidays_are_not_business_days(h):
    assert D(h).weekday() < 5  # each is a weekday, so only the holiday rule can exclude it
    assert cal.is_business_day(D(h)) is False


@pytest.mark.parametrize("a, b, expected", [
    # Mon 9 Nov .. Fri 13 Nov: 5 weekdays minus Wed 11 Nov = 4
    ("2026-11-09", "2026-11-13", 4),
    # Mon 21 Dec .. Fri 8 Jan: 15 weekdays minus 25 Dec, 28 Dec, 1 Jan = 12
    ("2026-12-21", "2027-01-08", 12),
    # Feb 2027 has 20 weekdays minus 15 Feb = 19
    ("2027-02-01", "2027-02-28", 19),
    # Nov 2026: 21 weekdays minus 11 Nov = 20
    ("2026-11-01", "2026-11-30", 20),
    # Dec 2026: 23 weekdays minus 25, 28 = 21
    ("2026-12-01", "2026-12-31", 21),
    # Jan 2027: 21 weekdays minus 1 Jan = 20
    ("2027-01-01", "2027-01-31", 20),
    # end < start
    ("2026-11-20", "2026-11-19", 0),
    # single Saturday
    ("2027-02-20", "2027-02-20", 0),
])
def test_count_business_days_hand(a, b, expected):
    assert cal.count_business_days(D(a), D(b)) == expected
    if expected:
        assert len(qa_bd_list(D(a), D(b))) == expected  # sanity of my own oracle


def test_count_business_days_matches_oracle_over_whole_fy27():
    start = D("2026-10-01")
    for i in range(0, 400, 7):
        a = start + timedelta(days=i)
        for span in (0, 1, 4, 13, 45):
            b = a + timedelta(days=span)
            assert cal.count_business_days(a, b) == len(qa_bd_list(a, b)), (a, b)


@pytest.mark.parametrize("d, n, expected", [
    ("2026-11-10", 1, "2026-11-12"),   # skips Wed 11 Nov
    ("2026-12-24", 1, "2026-12-29"),   # skips 25 (Fri), weekend, 28 (Mon)
    ("2026-12-31", 1, "2027-01-04"),   # skips 1 Jan + weekend
    ("2027-02-12", 1, "2027-02-16"),   # skips weekend + 15 Feb
    ("2027-02-16", -1, "2027-02-12"),
    ("2026-10-19", 2, "2026-10-21"),
])
def test_add_business_days_hand(d, n, expected):
    assert cal.add_business_days(D(d), n) == D(expected)
    assert qa_add_bd(D(d), n) == D(expected)


def test_freeze_is_not_a_business_day_rule():
    # 15 Dec 2026 is a Tuesday inside the freeze: still a working day for dev/QA.
    assert cal.in_freeze(D("2026-12-15"))
    assert cal.is_business_day(D("2026-12-15"))
    assert cal.in_freeze(D("2026-12-14")) and cal.in_freeze(D("2027-01-08"))
    assert not cal.in_freeze(D("2026-12-13")) and not cal.in_freeze(D("2027-01-09"))


def test_freeze_blocks_only_production_milestone_in_forward_pass():
    # A 30-bd dev task starting Mon 30 Nov runs straight through the freeze.
    # 30 Nov-4 Dec 5, 7-11 10, 14-18 15, 21-24 19, 29-31 22, 4-8 Jan 27, 11-13 Jan 30 -> ends Wed 13 Jan.
    trains = [("DC-X", "2026-12-19"), ("DC-2701", "2027-01-16"), ("DC-2702", "2027-02-20")]
    tasks = [
        {"wbs_code": "D", "duration_days": 30, "depends_on": [], "is_milestone": False},
        {"wbs_code": "P", "duration_days": 0, "depends_on": [], "is_milestone": True},
    ]
    out = schedule.schedule_plan(tasks, D("2026-11-30"), target_train={"code": "DC-X", "train_date": "2026-12-19"},
                                 trains=trains)
    assert out["D"]["planned_start"] == "2026-11-30"
    assert out["D"]["planned_end"] == "2027-01-13"
    # P has no predecessors; target DC-X (19 Dec) is in the freeze, so it must go to the first train outside: 16 Jan.
    assert out["P"]["planned_start"] == "2027-01-16"


# ================================================================== L2
CATALOG = [
    {"id": 1, "code": "APIP", "name": "API Platform", "base_hours_low": 40, "base_hours_medium": 120, "base_hours_high": 280},
    {"id": 3, "code": "EDP", "name": "Enterprise Data Platform", "base_hours_low": 40, "base_hours_medium": 120, "base_hours_high": 240},
    {"id": 4, "code": "CIAM", "name": "CIAM / Security", "base_hours_low": 40, "base_hours_medium": 120, "base_hours_high": 280},
    {"id": 11, "code": "SRE", "name": "SRE / Observability", "base_hours_low": 40, "base_hours_medium": 80, "base_hours_high": 160},
]


def test_l2_hero_hand():
    comps = [{"code": "APIP", "complexity": "High"}, {"code": "EDP", "complexity": "Medium"},
             {"code": "CIAM", "complexity": "Medium"}, {"code": "SRE", "complexity": "Low"}]
    r = l2.estimate_l2(comps, CATALOG)
    # dev 280+120+120+40 = 560; arch 56; QA 196; PM 56; subtotal 868; x1.15 = 998.2 -> 1000 (nearest 50)
    assert r["dev_hours"] == 560
    assert (r["architecture_hours"], r["qa_hours"], r["pm_release_hours"]) == (56, 196, 56)
    assert r["subtotal"] == 868
    assert r["total_hours"] == 1000
    assert r["tshirt"] == "L"
    # range from the ROUNDED total: 750-1250
    assert (r["low_hours"], r["high_hours"]) == (750, 1250)
    assert r["contingency_hours"] == 130  # 868 x 0.15 = 130.2 -> 130 (PO "+130")


def test_l2_contingency_reported_consistently():
    """One payload should not show two different contingency figures (steps/`contingency_hours` vs `by_phase`)."""
    comps = [{"code": "APIP", "complexity": "High"}, {"code": "EDP", "complexity": "Medium"},
             {"code": "CIAM", "complexity": "Medium"}, {"code": "SRE", "complexity": "Low"}]
    r = l2.estimate_l2(comps, CATALOG)
    by_phase = {p["phase"]: p["hours"] for p in r["by_phase"]}
    assert by_phase["Contingency"] == r["contingency_hours"], (
        f"by_phase Contingency {by_phase['Contingency']} h vs contingency_hours {r['contingency_hours']} h")


@pytest.mark.parametrize("hours, size", [
    (0, "XS"), (99, "XS"), (100, "S"), (300, "S"), (301, "M"), (700, "M"), (701, "L"), (1500, "L"), (1501, "XL"),
])
def test_tshirt_boundaries(hours, size):
    assert l2.tshirt(hours) == size


def test_l2_zero_components_no_exception():
    r = l2.estimate_l2([], CATALOG)
    assert r["total_hours"] == 0 and r["dev_hours"] == 0
    assert r["low_hours"] == 0 and r["high_hours"] == 0
    assert r["tshirt"] == "XS"
    assert r["warnings"], "zero components must carry a warning"
    r2 = l2.estimate_l2(None, None)
    assert r2["total_hours"] == 0


def test_l2_other_hand_cases():
    # APIP Medium 120 + EDP High 240 = 360 dev; arch 36, qa 126, pm 36 -> 558; x1.15 = 641.7 -> 650 (M)
    # range 487.5 -> 488 (half up), 812.5 -> 813
    r = l2.estimate_l2([{"code": "APIP", "complexity": "Medium"}, {"code": "EDP", "complexity": "High"}], CATALOG)
    assert (r["dev_hours"], r["subtotal"], r["total_hours"], r["tshirt"]) == (360, 558, 650, "M")
    assert (r["low_hours"], r["high_hours"]) == (488, 813)
    # Small: SRE Low 40 -> 4 + 14 + 4 = 62 -> 71.3 -> 50 (nearest 50) -> XS; range 37.5->38, 62.5->63
    r = l2.estimate_l2([{"code": "SRE", "complexity": "Low"}], CATALOG)
    assert (r["subtotal"], r["total_hours"], r["tshirt"]) == (62, 50, "XS")
    # Large: 2x APIP High + CIAM High = 840 -> 84+294+84 = 1302 -> 1497.3 -> 1500 (L, not XL)
    r = l2.estimate_l2([{"code": "APIP", "complexity": "High"}, {"code": "APIP", "complexity": "High"},
                        {"code": "CIAM", "complexity": "High"}], CATALOG)
    assert (r["subtotal"], r["total_hours"], r["tshirt"]) == (1302, 1500, "L")


# ================================================================== GROOMING
@pytest.mark.parametrize("now, expected", [
    ("2026-10-19T09:30:00", "2026-10-20"),   # hero: Mon 09:30, cut-off for Tue is Mon 17:00
    ("2026-10-19T17:30:00", "2026-10-22"),   # Mon after cut-off -> Thu 22 Oct
    ("2026-10-23T17:30:00", "2026-10-27"),   # Fri after cut-off: Tue 27 cut-off is Mon 26 17:00 -> Tue 27
    ("2026-10-24T11:00:00", "2026-10-27"),   # Saturday
    ("2026-10-26T17:30:00", "2026-10-29"),   # Mon 26 after cut-off -> Thu 29
    ("2026-10-21T18:00:00", "2026-10-27"),   # Wed after cut-off misses Thu 22 -> Tue 27
    ("2026-11-10T16:00:00", "2026-11-12"),   # Thu 12 Nov cut-off is Tue 10 Nov 17:00 (Wed 11 is a holiday)
    ("2026-11-10T17:30:00", "2026-11-17"),
])
def test_next_grooming_session(now, expected):
    assert grooming.next_session_date(datetime.fromisoformat(now)) == D(expected)


def test_hero_grooming_label_and_date():
    p = grooming.slot_one({"priority": 2}, [], datetime(2026, 10, 19, 9, 30))
    assert p["session_date"] == "2026-10-20" and p["start_time"] == "10:00"
    assert p["label"] == "Tue 20 Oct, 10:00"


def test_grooming_timezone_aware_now_is_converted():
    """A UTC-aware `now` of 20:30Z on 19 Oct is 16:30 in Toronto (EDT, UTC-4): still before the 17:00 cut-off."""
    from zoneinfo import ZoneInfo
    now = datetime(2026, 10, 19, 20, 30, tzinfo=ZoneInfo("UTC"))
    assert now.astimezone(ZoneInfo("America/Toronto")).hour == 16
    assert grooming.next_session_date(now) == D("2026-10-20")


def _full_session(statuses=None):
    prios = [3, 3, 2, 3, 4, 3]
    statuses = statuses or ["Proposed"] * 6
    return {"id": 7, "session_date": "2026-10-20", "start_time": "10:00", "capacity": 6, "status": "Scheduled",
            "slots": [{"initiative_id": 100 + i, "priority": prios[i - 1], "slot_order": i, "status": statuses[i - 1],
                       "submitted_at": f"2026-10-0{i}"} for i in range(1, 7)]}


def test_full_session_overflow_and_p1_jump():
    now = datetime(2026, 10, 19, 9, 30)
    sess = [_full_session()]
    # P2 finds Tue 20 full (6/6) -> overflows to Thu 22
    p2 = grooming.slot_one({"priority": 2}, copy.deepcopy(sess), now)
    assert p2["session_date"] == "2026-10-22" and p2["bumped"] is None
    # P1 jumps the queue: takes Tue 20; the lowest-priority proposed slot (105, P4) moves to Thu 22
    p1 = grooming.slot_one({"priority": 1}, copy.deepcopy(sess), now)
    assert p1["session_date"] == "2026-10-20"
    assert p1["bumped"]["initiative_id"] == 105
    assert p1["bumped"]["to_session_date"] == "2026-10-22"
    assert p1["slot_order"] == 5


def test_auto_slot_p1_first_and_capacity():
    now = datetime(2026, 10, 19, 9, 30)
    sess = [{"id": 7, "session_date": "2026-10-20", "start_time": "10:00", "capacity": 6, "status": "Scheduled",
             "slots": [{"initiative_id": i} for i in range(1, 6)]}]  # 5 taken, 1 free
    cands = [{"initiative_id": 50, "priority": 3, "submitted_at": "2026-10-01"},
             {"initiative_id": 51, "priority": 1, "submitted_at": "2026-10-18"}]
    out = grooming.auto_slot(cands, sess, now)
    by = {a["initiative_id"]: a for a in out["assignments"]}
    assert by[51]["session_date"] == "2026-10-20" and by[51]["slot_order"] == 6  # P1 gets the last seat
    assert by[50]["session_date"] == "2026-10-22"


# ================================================================== CAPACITY
def test_spread_hours_cross_month_with_holiday():
    # Mon 9 Nov .. Fri 4 Dec 2026. Nov bd: 9,10,12,13 (11 holiday) =4, 16-20 =5, 23-27 =5, 30 =1 -> 15; Dec 1-4 = 4.
    # 19 bd, 95 h -> 5 h/day -> Nov 75.0, Dec 20.0
    assert len(qa_bd_list(D("2026-11-09"), D("2026-12-04"))) == 19
    assert capacity.spread_hours(D("2026-11-09"), D("2026-12-04"), 95) == {"2026-11": 75.0, "2026-12": 20.0}


def test_spread_hours_over_xmas_holidays_uneven():
    # Mon 21 Dec 2026 .. Fri 8 Jan 2027. Dec bd: 21,22,23,24,29,30,31 = 7 (25, 28 holidays); Jan: 4-8 = 5 (1 Jan hol)
    # 70 h / 12 bd = 5.8333; Dec 7 x 5.8333 = 40.83 -> 40.8; Jan = 70 - 40.8 = 29.2
    out = capacity.spread_hours(D("2026-12-21"), D("2027-01-08"), 70)
    assert out == {"2026-12": 40.8, "2027-01": 29.2}
    assert round(sum(out.values()), 6) == 70


def test_spread_hours_hero_wbs100():
    # Tue 20 Oct .. Tue 17 Nov: Oct 20-23 (4) + 26-30 (5) = 9; Nov 2-6 (5) + 9,10,12,13 (4) + 16,17 (2) = 11; 20 bd
    # 70 / 20 = 3.5 -> Oct 31.5, Nov 38.5 (master §6.2 pin 4)
    assert capacity.spread_hours("2026-10-20", "2026-11-17", 70) == {"2026-10": 31.5, "2026-11": 38.5}


@pytest.mark.parametrize("util, band", [
    (0.69, "spare"), (0.6999, "spare"), (0.70, "ok"), (1.00, "ok"), (1.0001, "stretched"),
    (1.10, "stretched"), (1.1001, "over"), (84 / 120, "ok"), (132 / 120, "stretched"), (154 / 140, "stretched"),
    (154 / 120, "over"),
])
def test_capacity_bands(util, band):
    assert capacity.band(util, 1.0) == band


def test_capacity_zero_availability():
    assert capacity.utilisation(10, 0) is None
    res = [{"id": 1, "name": "Z", "team": "QA", "availability": {"2026-11": 0}, "default_monthly_hours": 0}]
    alloc = [{"resource_id": 1, "month": "2026-11", "hours": 12, "firmness": "confirmed"}]
    out = capacity.compute_capacity(res, alloc, ["2026-11"])  # must not raise ZeroDivisionError
    cell = out["rows"][0]["cells"][0]
    assert cell["util"] is None
    assert cell["band"] == "over"  # demand with no availability
    assert out["teams"][0]["util"] is None
    for g in ("team", "quarter"):
        capacity.compute_capacity(res, alloc, ["2026-11"], group=g)


def test_capacity_tentative_and_confirmed_both_count():
    res = [{"id": 1, "name": "A", "team": "CIAM", "availability": {"2026-11": 140}}]
    alloc = [{"resource_id": 1, "month": "2026-11", "hours": 70, "firmness": "confirmed"},
             {"resource_id": 1, "month": "2026-11", "hours": 84, "firmness": "tentative"}]
    cell = capacity.compute_capacity(res, alloc, ["2026-11"])["rows"][0]["cells"][0]
    # (70 + 84) / 140 = 1.10 -> stretched (<= 1.10)
    assert (cell["confirmed"], cell["tentative"]) == (70.0, 84.0)
    assert math.isclose(cell["util"], 1.10)
    assert cell["band"] == "stretched"


# ================================================================== SCHEDULE
def _net():
    # A 2-6 Nov (5 bd) -> B 9,10,12 Nov (3 bd, 11 Nov holiday) and C 9-10 Nov (2 bd) -> D 13,16,17,18 Nov (4 bd)
    # -> E Production milestone Sat 21 Nov (DC-2611)
    return [
        {"id": 1, "wbs_code": "A", "planned_start": "2026-11-02", "planned_end": "2026-11-06", "depends_on": [],
         "baseline_start": "2026-11-02", "baseline_end": "2026-11-06"},
        {"id": 2, "wbs_code": "B", "planned_start": "2026-11-09", "planned_end": "2026-11-12", "depends_on": [1],
         "baseline_start": "2026-11-09", "baseline_end": "2026-11-12"},
        {"id": 3, "wbs_code": "C", "planned_start": "2026-11-09", "planned_end": "2026-11-10", "depends_on": [1],
         "baseline_start": "2026-11-09", "baseline_end": "2026-11-10"},
        {"id": 4, "wbs_code": "D", "planned_start": "2026-11-13", "planned_end": "2026-11-18", "depends_on": [2, 3],
         "baseline_start": "2026-11-13", "baseline_end": "2026-11-18"},
        {"id": 5, "wbs_code": "E", "planned_start": "2026-11-21", "planned_end": "2026-11-21", "depends_on": [4],
         "is_milestone": 1, "phase": "Production", "baseline_start": "2026-11-21", "baseline_end": "2026-11-21"},
    ]


def test_cpm_hand_network():
    r = schedule.cpm(_net())
    # index: A 0-4, B 5-7, C 5-6, D 8-11, E milestone (dur 0) es 12 ef 11; project end 11
    assert (r[1]["es"], r[1]["ef"]) == (0, 4)
    assert (r[2]["es"], r[2]["ef"], r[2]["duration_bd"]) == (5, 7, 3)
    assert (r[3]["es"], r[3]["ef"]) == (5, 6)
    assert (r[4]["es"], r[4]["ef"]) == (8, 11)
    # C: lf = ls(D) - 1 = 7, ls = 6 -> float 1
    assert {k: v["float_bd"] for k, v in r.items()} == {1: 0, 2: 0, 3: 1, 4: 0, 5: 0}
    assert set(schedule.critical_path(_net())) == {1, 2, 4, 5}


def test_cycle_raises_and_gantt_reports_loop():
    tasks = _net()
    tasks[0]["depends_on"] = [4]  # A depends on D -> loop A->B->D->A
    with pytest.raises(schedule.ScheduleError):
        schedule.cpm(tasks)
    g = schedule.build_gantt(tasks, D("2026-10-19"))
    assert g["dependency_loop"] and g["critical_path"] == []
    with pytest.raises(schedule.ScheduleError):
        schedule.schedule_plan([{"wbs_code": "X", "depends_on": ["Y"]}, {"wbs_code": "Y", "depends_on": ["X"]}],
                               D("2026-10-20"))


def _apply(tasks, moves):
    for t in tasks:
        if t["id"] in moves:
            t["planned_start"], t["planned_end"] = moves[t["id"]]
    return tasks


def test_slip_propagation_and_undo():
    tasks = _net()
    tasks[0]["planned_end"] = "2026-11-10"  # A now 2-10 Nov (7 bd), +2 bd
    moves = schedule.propagate_slip(tasks, 1)
    # B: next bd after 10 Nov = 12 Nov (11 hol); 3 bd -> 12, 13, 16 -> ends 16 Nov
    # C: 12-13 Nov. D: after max(16, 13) -> 17 Nov, 4 bd -> 17,18,19,20 -> ends 20 Nov. E: next train after 20 Nov = 21 Nov
    assert moves[2] == ("2026-11-12", "2026-11-16")
    assert moves[3] == ("2026-11-12", "2026-11-13")
    assert moves[4] == ("2026-11-17", "2026-11-20")
    assert 5 not in moves  # milestone stays on Sat 21 Nov
    _apply(tasks, moves)
    # undo
    tasks[0]["planned_end"] = "2026-11-06"
    back = schedule.propagate_slip(tasks, 1)
    _apply(tasks, back)
    assert [(t["planned_start"], t["planned_end"]) for t in tasks] == \
           [(t["planned_start"], t["planned_end"]) for t in _net()]


def test_slip_propagation_through_inherited_parent_dependency():
    """A child with no own dependency inherits its parent's (docstring: effective_preds walks up parents).
    A -> Q -> P(has hours) ; X is a child of P with no explicit deps. Slip A by 2 bd:
    Q 9-10 Nov -> 12-13 Nov; P 12-13 -> 16-17; X (inherits P's pred Q) must also start after Q ends -> 16-17."""
    tasks = [
        {"id": 1, "wbs_code": "A", "planned_start": "2026-11-02", "planned_end": "2026-11-06", "depends_on": []},
        {"id": 4, "wbs_code": "X", "parent_id": 3, "est_hours": 7, "planned_start": "2026-11-12",
         "planned_end": "2026-11-13", "depends_on": []},
        {"id": 2, "wbs_code": "Q", "est_hours": 7, "planned_start": "2026-11-09", "planned_end": "2026-11-10",
         "depends_on": [1]},
        {"id": 3, "wbs_code": "P", "est_hours": 14, "planned_start": "2026-11-12", "planned_end": "2026-11-13",
         "depends_on": [2]},
    ]
    tasks[0]["planned_end"] = "2026-11-10"
    moves = schedule.propagate_slip(tasks, 1)
    assert moves[2] == ("2026-11-12", "2026-11-13")
    assert moves[3] == ("2026-11-16", "2026-11-17")
    assert moves.get(4) == ("2026-11-16", "2026-11-17"), f"X not pushed past Q's new end: {moves.get(4)}"


def _hero_bundle():
    return json.loads((ROOT / "tests" / "fixtures" / "bundle_hero.json").read_text())


HERO_PLAN = [  # codes/hours/allocation from the hero WBS fixture; durations derived by schedule_plan
    {"wbs_code": "WBS-100", "est_hours": 70, "allocation_pct": 50, "depends_on": []},
    {"wbs_code": "WBS-200", "est_hours": 0, "depends_on": []},
    {"wbs_code": "WBS-210", "parent_code": "WBS-200", "est_hours": 280, "allocation_pct": 100, "depends_on": ["WBS-100"]},
    {"wbs_code": "WBS-220", "parent_code": "WBS-200", "est_hours": 120, "allocation_pct": 43, "depends_on": ["WBS-100"]},
    {"wbs_code": "WBS-230", "parent_code": "WBS-200", "est_hours": 120, "allocation_pct": 43, "depends_on": ["WBS-100"]},
    {"wbs_code": "WBS-240", "parent_code": "WBS-200", "est_hours": 40, "allocation_pct": 29, "depends_on": ["WBS-100"]},
    {"wbs_code": "WBS-300", "est_hours": 56, "allocation_pct": 80, "depends_on": ["WBS-210", "WBS-220", "WBS-230", "WBS-240"]},
    {"wbs_code": "WBS-310", "parent_code": "WBS-300", "est_hours": 24, "allocation_pct": 70, "depends_on": ["WBS-210"]},
    {"wbs_code": "WBS-400", "est_hours": 56, "allocation_pct": 100, "depends_on": ["WBS-300", "WBS-310"]},
    {"wbs_code": "WBS-500", "est_hours": 14, "allocation_pct": 100, "depends_on": ["WBS-400"]},
    {"wbs_code": "WBS-600", "est_hours": 14, "allocation_pct": 100, "depends_on": ["WBS-500"]},
    {"wbs_code": "WBS-700", "est_hours": 6, "allocation_pct": 100, "depends_on": ["WBS-600"], "is_milestone": True},
    {"wbs_code": "WBS-800", "est_hours": 35, "allocation_pct": 50, "depends_on": ["WBS-700"]},
]


def test_hero_forward_pass_hand():
    out = schedule.schedule_plan(copy.deepcopy(HERO_PLAN), D("2026-10-20"),
                                 target_train={"code": "DC-2702", "train_date": "2027-02-20"})
    # durations: 70/(7*.5)=20; 280/7=40; 120/(7*.43)=39.87->40; 40/(7*.29)=19.70->20; 56/5.6=10; 24/4.9=4.9->5;
    # 56/7=8; 14/7=2; 14/7=2; 35/3.5=10
    exp = {
        "WBS-100": ("2026-10-20", "2026-11-17"),
        "WBS-210": ("2026-11-18", "2027-01-15"),
        "WBS-220": ("2026-11-18", "2027-01-15"),
        "WBS-240": ("2026-11-18", "2026-12-15"),
        "WBS-200": ("2026-11-18", "2027-01-15"),
        "WBS-300": ("2027-01-18", "2027-01-29"),
        "WBS-310": ("2027-01-18", "2027-01-22"),
        "WBS-400": ("2027-02-01", "2027-02-10"),   # QA Date
        "WBS-500": ("2027-02-11", "2027-02-12"),
        "WBS-600": ("2027-02-16", "2027-02-17"),   # Readiness (15 Feb holiday)
        "WBS-700": ("2027-02-20", "2027-02-20"),   # Sat train
        "WBS-800": ("2027-02-22", "2027-03-05"),
    }
    for code, (s, e) in exp.items():
        assert (out[code]["planned_start"], out[code]["planned_end"]) == (s, e), code
    # independent check of dev end: 40 bd from 18 Nov
    assert qa_add_bd(D("2026-11-18"), 39) == D("2027-01-15")
    # float: bd strictly between Wed 17 Feb and Sat 20 Feb = Thu 18, Fri 19 = 2
    assert schedule.readiness_float("2027-02-17", "2027-02-20") == 2


def test_hero_gantt_key_dates_and_cpm():
    b = _hero_bundle()
    g = schedule.build_gantt(b["tasks"], D("2026-10-19"), target_train=b["target_train"])
    assert (g["qa_date"], g["readiness_date"], g["prod_date"], g["float_bd"]) == \
           ("2027-02-10", "2027-02-17", "2027-02-20", 2)
    fl = {t["wbs_code"]: t["float_bd"] for t in g["tasks"]}
    # hand CPM (bd index from 20 Oct): 100 0-19; 210/220/230 20-59; 240 20-39; 300 60-69; 310/320 60-64; 400 70-77;
    # 500 78-79; 600 80-81; 700 ms; 800 82-91. 240 float = 59-39 = 20; 310/320 float = 69-64 = 5
    assert fl["WBS-240"] == 20 and fl["WBS-310"] == 5 and fl["WBS-320"] == 5
    crit = {t["wbs_code"] for t in g["tasks"] if t["critical"]}
    assert crit == {"WBS-100", "WBS-210", "WBS-220", "WBS-230", "WBS-300", "WBS-400", "WBS-500", "WBS-600",
                    "WBS-700", "WBS-800"}


@pytest.mark.parametrize("r, t, fl", [
    ("2027-02-11", "2027-02-20", 5),   # 12, 16, 17, 18, 19 (15 hol)
    ("2027-02-12", "2027-02-20", 4),
    ("2027-02-19", "2027-02-20", 0),
    ("2027-02-22", "2027-02-20", -1),
    ("2027-02-24", "2027-02-20", -3),  # 22, 23, 24
])
def test_readiness_float(r, t, fl):
    assert schedule.readiness_float(r, t) == fl


# ================================================================== HEALTH: minimal bundles
def mk_bundle(**kw):
    b = {
        "initiative": {"id": 1, "rddc": "RDDC-1", "name": "T", "stage": "Planning", "target_release": "DC-2702",
                       "sa_completeness": 100, "l2_status": "Approved", "l2_approved_at": "2026-10-01T10:00:00-04:00",
                       "l2_baseline_hours": None, "rag_overrides_json": {}},
        "tasks": [
            {"id": 1, "wbs_code": "WBS-600", "phase": "Readiness", "resource_id": 1, "est_hours": 14,
             "planned_start": "2027-02-10", "planned_end": "2027-02-11", "depends_on": [], "status": "Backlog", "pct": 0},
            {"id": 2, "wbs_code": "WBS-700", "phase": "Production", "resource_id": 1, "est_hours": 0, "is_milestone": 1,
             "planned_start": "2027-02-20", "planned_end": "2027-02-20", "depends_on": [1], "status": "Backlog", "pct": 0},
        ],
        "resources": [{"id": 1, "name": "Pat", "team": "QA", "capacity_eligible": 1,
                       "availability": {"2026-11": 120}, "default_monthly_hours": 120, "committed": {}}],
        "allocations": [],
        "components": [],
        "scope_changes": [],
        "prn": {"prn_code": "PRN-1", "funded_hours": 1000, "charges": []},
        "target_train": {"code": "DC-2702", "train_date": "2027-02-20"},
        "component_catalog": [],
    }
    for k, v in kw.items():
        if k == "ini":
            b["initiative"].update(v)
        else:
            b[k] = v
    return b


def rag(bundle, dim, today="2026-10-19"):
    return health.compute_health(bundle, D(today))["dimensions"][dim]["rag"]


@pytest.mark.parametrize("readiness_end, expected", [
    ("2027-02-11", "Green"),   # float 5
    ("2027-02-12", "Amber"),   # float 4
    ("2027-02-19", "Amber"),   # float 0
    ("2027-02-22", "Red"),     # misses train by 1 bd
])
def test_schedule_float_edges(readiness_end, expected):
    b = mk_bundle()
    b["tasks"][0]["planned_end"] = readiness_end
    b["tasks"][0]["planned_start"] = readiness_end
    assert rag(b, "schedule") == expected


def _overdue_bundle():
    b = mk_bundle()
    # A (critical) 20-23 Oct -> R (Readiness) 26 Oct .. 11 Feb (float 5) -> M Sat 20 Feb. C non-critical 20-23 Oct.
    b["tasks"] = [
        {"id": 10, "wbs_code": "WBS-A", "phase": "Development", "resource_id": 1, "est_hours": 28,
         "planned_start": "2026-10-20", "planned_end": "2026-10-23", "depends_on": [], "status": "In progress", "pct": 50},
        {"id": 1, "wbs_code": "WBS-600", "phase": "Readiness", "resource_id": 1, "est_hours": 14,
         "planned_start": "2026-10-26", "planned_end": "2027-02-11", "depends_on": [10], "status": "Backlog", "pct": 0},
        {"id": 2, "wbs_code": "WBS-700", "phase": "Production", "resource_id": 1, "est_hours": 0, "is_milestone": 1,
         "planned_start": "2027-02-20", "planned_end": "2027-02-20", "depends_on": [1], "status": "Backlog", "pct": 0},
    ]
    return b


def test_schedule_overdue_edges():
    b = _overdue_bundle()
    # overdue bd after Fri 23 Oct: to Fri 30 Oct = 26,27,28,29,30 = 5 ; to Mon 2 Nov = 6
    assert rag(b, "schedule", "2026-10-30") == "Amber"   # critical, 5 bd overdue
    assert rag(b, "schedule", "2026-11-02") == "Red"     # critical, 6 bd overdue
    b["tasks"][0]["status"], b["tasks"][0]["pct"] = "Completed", 100
    assert rag(b, "schedule", "2026-11-02") == "Green"   # closed task is not overdue
    # non-critical overdue 6 bd -> Amber only
    b = _overdue_bundle()
    b["tasks"][0]["status"], b["tasks"][0]["pct"] = "Completed", 100
    b["tasks"].append({"id": 11, "wbs_code": "WBS-C", "phase": "Development", "resource_id": 1, "est_hours": 7,
                       "planned_start": "2026-10-20", "planned_end": "2026-10-23", "depends_on": [],
                       "status": "In progress", "pct": 0})
    assert rag(b, "schedule", "2026-11-02") == "Amber"


def test_schedule_production_in_freeze_red():
    b = mk_bundle(target_train={"code": "DC-X", "train_date": "2026-12-19"})
    b["tasks"][0].update(planned_start="2026-12-01", planned_end="2026-12-02")
    b["tasks"][1].update(planned_start="2026-12-19", planned_end="2026-12-19")
    assert rag(b, "schedule") == "Red"


def _res_bundle(nov_committed, unassigned_start=None):
    b = mk_bundle()
    b["resources"][0]["committed"] = {"2026-11": nov_committed}
    b["allocations"] = [{"resource_id": 1, "task_id": 1, "month": "2026-11", "hours": 10, "firmness": "confirmed"}]
    if unassigned_start:
        b["tasks"].append({"id": 20, "wbs_code": "WBS-U", "phase": "Development", "resource_id": None, "est_hours": 10,
                           "planned_start": unassigned_start, "planned_end": unassigned_start, "depends_on": [],
                           "status": "Backlog", "pct": 0})
    return b


@pytest.mark.parametrize("booked, expected", [
    (120, "Green"),    # 100%
    (121, "Amber"),    # 100.8%
    (132, "Amber"),    # 110% exactly
    (132.1, "Red"),    # 110.08%
])
def test_resources_util_edges(booked, expected):
    assert rag(_res_bundle(booked), "resources") == expected


@pytest.mark.parametrize("start, expected", [
    ("2026-10-26", "Red"),     # 5 bd after Mon 19 Oct
    ("2026-10-27", "Amber"),   # 6
    ("2026-11-02", "Amber"),   # 10
    ("2026-11-03", "Green"),   # 11
])
def test_resources_unassigned_edges(start, expected):
    assert rag(_res_bundle(60, start), "resources") == expected


@pytest.mark.parametrize("sa, expected", [(100, "Green"), (80, "Green"), (79, "Amber"), (60, "Amber"), (59, "Red")])
def test_scope_sa_edges(sa, expected):
    assert rag(mk_bundle(ini={"sa_completeness": sa}), "scope") == expected


def test_scope_change_counts_and_delta():
    after = {"ts": "2026-10-05T10:00:00-04:00", "component_code": "APIP"}
    before = {"ts": "2026-09-30T10:00:00-04:00", "component_code": "APIP"}
    assert rag(mk_bundle(scope_changes=[before]), "scope") == "Green"       # before approval: ignored
    assert rag(mk_bundle(scope_changes=[after]), "scope") == "Amber"        # 1 change
    assert rag(mk_bundle(scope_changes=[after, dict(after)]), "scope") == "Red"  # 2 changes
    # delta: baseline 1000; current 1200 -> +20% Amber; 1250 -> +25% Red; 1000 -> Green
    assert rag(mk_bundle(ini={"l2_baseline_hours": 1000, "l2_hours": 1000}), "scope") == "Green"
    assert rag(mk_bundle(ini={"l2_baseline_hours": 1000, "l2_hours": 1200}), "scope") == "Amber"
    assert rag(mk_bundle(ini={"l2_baseline_hours": 1000, "l2_hours": 1250}), "scope") == "Red"


def _dep_bundle(approval, need_by):
    b = mk_bundle(components=[{"id": 33, "code": "CIAM", "name": "CIAM / Security", "approval": approval}])
    b["tasks"].append({"id": 30, "wbs_code": "WBS-230", "phase": "Development", "resource_id": 1, "est_hours": 7,
                       "component_code": "CIAM", "initiative_component_id": 33, "planned_start": need_by,
                       "planned_end": need_by, "depends_on": [], "status": "Backlog", "pct": 0})
    return b


def test_dependencies_edges():
    # Mon 19 Oct + 15 bd = Mon 9 Nov ; 10 Nov = 16 bd
    assert qa_add_bd(D("2026-10-19"), 15) == D("2026-11-09")
    assert rag(_dep_bundle("Pending", "2026-11-09"), "dependencies") == "Amber"
    assert rag(_dep_bundle("Pending", "2026-11-10"), "dependencies") == "Green"
    assert rag(_dep_bundle("Approved", "2026-10-20"), "dependencies") == "Green"
    assert rag(_dep_bundle("Rejected", "2027-01-20"), "dependencies") == "Red"
    # L2 pending: submitted Mon 5 Oct -> 10 bd by 19 Oct (Green); Fri 2 Oct -> 11 bd (Amber)
    assert rag(mk_bundle(ini={"l2_status": "Pending approval", "l2_submitted_at": "2026-10-05T10:00:00-04:00"}),
               "dependencies") == "Green"
    assert rag(mk_bundle(ini={"l2_status": "Pending approval", "l2_submitted_at": "2026-10-02T10:00:00-04:00"}),
               "dependencies") == "Amber"
    # an overdue step that others depend on -> Red
    assert rag(_overdue_bundle(), "dependencies", "2026-10-26") == "Red"
    b = mk_bundle()
    b["tasks"][0]["status"] = "Blocked"
    assert rag(b, "dependencies") == "Amber"


@pytest.mark.parametrize("charged, planned, expected", [
    (100, 500, "Green"),   # burn 10% - complete 0% = 10 pts
    (110, 500, "Amber"),   # 11 pts
    (200, 500, "Amber"),   # 20 pts
    (210, 500, "Red"),     # 21 pts
    (0, 1000, "Green"),    # forecast 1000 = funded
    (0, 1001, "Red"),      # forecast 1001 > 1000 funded
])
def test_budget_edges(charged, planned, expected):
    b = mk_bundle(prn={"prn_code": "PRN-1", "funded_hours": 1000,
                       "charges": [{"month": "2026-09", "charged_hours": charged}] if charged else []})
    b["tasks"][0]["est_hours"] = planned
    assert rag(b, "budget") == expected


def test_overall_rollup_truth_table_all_243():
    dims = ("schedule", "resources", "scope", "dependencies", "budget")
    for combo in itertools.product(("Green", "Amber", "Red"), repeat=5):
        d = dict(zip(dims, combo))
        assert health.overall_rag(d) == qa_overall(d), d


def test_overall_rollup_key_rows():
    g = dict.fromkeys(("schedule", "resources", "scope", "dependencies", "budget"), "Green")
    assert health.overall_rag(g) == "Green"
    assert health.overall_rag({**g, "schedule": "Red"}) == "Red"
    assert health.overall_rag({**g, "resources": "Red", "budget": "Red"}) == "Red"
    assert health.overall_rag({**g, "resources": "Red"}) == "Amber"
    assert health.overall_rag({**g, "scope": "Amber"}) == "Amber"


def test_not_scored_before_planning():
    for stage in ("Intake", "Grooming", "Solution", "Estimation"):
        h = health.compute_health(mk_bundle(ini={"stage": stage}), D("2026-10-19"))
        assert h["scored"] is False and h["overall"] is None


# ================================================================== HEALTH: hero
def _hero_peaks(b):
    out = {}
    for a in b["allocations"]:
        if a["month"] < "2026-10":
            continue
        r = next(x for x in b["resources"] if x["id"] == a["resource_id"])
        if not r["capacity_eligible"]:
            continue
        out[(r["name"], a["month"])] = r["committed"][a["month"]] / r["availability"][a["month"]]
    return out


def test_hero_health_as_planned():
    b = _hero_bundle()
    peaks = _hero_peaks(b)
    over = {k: v for k, v in peaks.items() if v > 1.0}
    assert set(over) == {("Sana Whitfield", "2026-11")}            # 154 / 120 = 1.2833
    assert round(over[("Sana Whitfield", "2026-11")] * 100) == 128
    h = health.compute_health(b, D("2026-10-19"))
    dims = {k: v["rag"] for k, v in h["dimensions"].items()}
    assert dims == {"schedule": "Amber", "resources": "Red", "scope": "Green", "dependencies": "Green",
                    "budget": "Green"}
    assert h["overall"] == "Amber"
    assert h["dimensions"]["schedule"]["metrics"]["float_bd"] == 2
    # Round 2 decision 7: every Red dimension + Schedule Amber with float <= 2 (hero float = 2)
    assert set(h["attention"]) == {"SA capacity constraint affecting WBS-100",
                                   "Readiness float 2 business days to DC-2702 affecting WBS-600"}
    assert len(h["attention"]) == 2
    # budget: plan sum 70+280+120+120+40+56+24+24+56+14+14+6+35 = 859 <= 1100 funded
    assert h["dimensions"]["budget"]["metrics"]["planned_hours"] == 859
    # dependencies: CIAM need-by Wed 18 Nov = 21 bd after Mon 19 Oct (Nov 11 holiday)
    assert len(qa_bd_list(D("2026-10-20"), D("2026-11-18"))) == 21
    assert h["dimensions"]["dependencies"]["metrics"]["min_need_by_bd"] == 21


def test_hero_health_after_fix_move_wbs100_to_mateo():
    b = _hero_bundle()
    sana, mateo = 14, 15
    for t in b["tasks"]:
        if t["wbs_code"] == "WBS-100":
            t["resource_id"] = mateo
    for a in b["allocations"]:
        if a["task_id"] == 201:
            a["resource_id"] = mateo
    rs = {r["id"]: r for r in b["resources"]}
    for m, h in (("2026-10", 31.5), ("2026-11", 38.5)):
        rs[sana]["committed"][m] -= h
        rs[mateo]["committed"][m] += h
    # Sana Nov 154 - 38.5 = 115.5 / 120 = 96.25% ; Mateo Nov 50.5 + 38.5 = 89 / 120 = 74.2%
    assert round(rs[sana]["committed"]["2026-11"] / 120 * 100) == 96
    assert round(rs[mateo]["committed"]["2026-11"] / 120 * 100) == 74
    h = health.compute_health(b, D("2026-10-19"))
    assert h["dimensions"]["resources"]["rag"] == "Green"
    assert h["overall"] == "Amber"
    # Resources no longer Red; Schedule is still Amber with float 2 -> only the float line remains
    assert h["attention"] == ["Readiness float 2 business days to DC-2702 affecting WBS-600"]


def test_hero_wbs210_plus5_red_then_revert():
    b = _hero_bundle()
    orig = {t["id"]: (t["planned_start"], t["planned_end"]) for t in b["tasks"]}
    t210 = next(t for t in b["tasks"] if t["wbs_code"] == "WBS-210")
    # Fri 15 Jan + 5 bd = Fri 22 Jan
    assert qa_add_bd(D("2027-01-15"), 5) == D("2027-01-22")
    t210["planned_end"] = "2027-01-22"
    _apply(b["tasks"], schedule.propagate_slip(b["tasks"], t210["id"]))
    by = {t["wbs_code"]: t for t in b["tasks"]}
    # 300: 25 Jan +10bd -> 5 Feb; 400: 8 Feb +8bd (15 hol) -> 18 Feb; 500: 19,22 Feb; 600: 23,24 Feb
    assert (by["WBS-300"]["planned_start"], by["WBS-300"]["planned_end"]) == ("2027-01-25", "2027-02-05")
    assert (by["WBS-400"]["planned_start"], by["WBS-400"]["planned_end"]) == ("2027-02-08", "2027-02-18")
    assert by["WBS-600"]["planned_end"] == "2027-02-24"
    h = health.compute_health(b, D("2026-10-19"))
    assert h["dimensions"]["schedule"]["rag"] == "Red"
    assert h["dimensions"]["schedule"]["metrics"]["float_bd"] == -3   # 22, 23, 24 Feb after the Sat train
    assert h["overall"] == "Red"
    assert "Schedule slip affecting WBS-210" in h["attention"]
    assert "SA capacity constraint affecting WBS-100" in h["attention"]
    assert not any(a.startswith("Readiness float") for a in h["attention"])  # Red, not the Amber watch line
    # revert
    t210["planned_end"] = "2027-01-15"
    _apply(b["tasks"], schedule.propagate_slip(b["tasks"], t210["id"]))
    assert {t["id"]: (t["planned_start"], t["planned_end"]) for t in b["tasks"]} == orig
    h = health.compute_health(b, D("2026-10-19"))
    assert h["overall"] == "Amber" and h["dimensions"]["schedule"]["rag"] == "Amber"


# ================================================================== BURNDOWN
def test_burndown_hand():
    prn = {"prn_code": "PRN-9", "funded_hours": 1000, "start_month": "2026-08", "end_month": "2026-12"}
    charges = [{"month": "2026-08", "charged_hours": 100}, {"month": "2026-09", "charged_hours": 150}]
    planned = {"2026-09": 999, "2026-10": 80, "2026-11": 300, "2026-12": 400}
    r = bd_engine.burndown(prn, charges, planned, D("2026-10-19"))
    # months Aug..Dec; charged cum 100, 250, 250 (Oct, no charge), None, None
    # forecast: 100, 250, 250+80=330, 630, 1030 -> exceeds 1000 in Dec -> overrun
    assert r["months"] == ["2026-08", "2026-09", "2026-10", "2026-11", "2026-12"]
    assert r["charged_cum"] == [100.0, 250.0, 250.0, None, None]
    assert r["forecast_cum"] == [100.0, 250.0, 330.0, 630.0, 1030.0]
    assert r["exhaust_month"] == "2026-12" and r["status"] == "overrun"
    assert r["budget_amount"] == 110000.0  # 1000 h x CAD 110


@pytest.mark.parametrize("planned, status", [(900, "on_track"), (901, "at_risk"), (1000, "at_risk"),
                                             (1000.5, "overrun")])
def test_burndown_status_edges(planned, status):
    prn = {"prn_code": "P", "funded_hours": 1000, "start_month": "2026-10", "end_month": "2026-10"}
    assert bd_engine.burndown(prn, [], {"2026-10": planned}, D("2026-10-19"))["status"] == status


# ================================================================== COMPLIANCE
def _cr(**kw):
    cr = {"id": 3, "crq_number": "CRQ1", "raised_at": "2026-10-30",
          "crq_start": "2026-11-21T02:00:00-05:00", "crq_end": "2026-11-21T06:00:00-05:00",
          "release_type": "Bundle", "release_train": "DC-2611", "affected_cis": ["OLB-WEB"], "impacted_components": ["OLB"],
          "implementation_status": "Scheduled", "crq_approval_status": "Approved", "sto_approval": "Go",
          "cms_lead_id": 19, "rel_lead_id": 20, "backout_attachment_id": 5,
          "tech_validation_status": "Not Started", "biz_validation_status": "Not Started"}
    cr.update(kw)
    return cr


def codes(cr, today="2026-11-16", now=None):
    r = compliance.check_cr(cr, D(today), {"now": now} if now else None)
    return {f["code"] for f in r["flags"]}


def test_compliance_clean_baseline():
    # raised Fri 30 Oct -> bd in (30 Oct, 21 Nov] = 5 + 4 (11 hol) + 5 = 14 >= 10
    assert len(qa_bd_list(D("2026-10-31"), D("2026-11-21"))) == 14
    assert codes(_cr()) == set()


def test_compliance_each_flag_fires_and_clears():
    # STO not Go by T-2: due Wed 18 Nov (Fri 20 - 2 bd); QA-B-09 ruling: inclusive -> Fail from Thu 19 Nov
    assert "CR-01" in codes(_cr(sto_approval="Tentative Go"), "2026-11-19")
    assert "CR-01" not in codes(_cr(sto_approval="Tentative Go"), "2026-11-18")
    assert "CR-01" not in codes(_cr(sto_approval="Go"), "2026-11-19")
    assert "CR-01" in codes(_cr(sto_approval="No-Go"), "2026-11-02")
    # CRQ approval
    assert "CR-02" in codes(_cr(crq_approval_status="Submitted"), "2026-11-19")
    assert "CR-02" not in codes(_cr(crq_approval_status="Submitted"), "2026-11-18")
    # CIs empty
    assert "CR-03" in codes(_cr(affected_cis=[]))
    assert "CR-03" not in codes(_cr(affected_cis="OLB-WEB"))
    # validation failed / attachment missing 24 h after Implemented
    assert "CR-04" in codes(_cr(tech_validation_status="Failed"))
    impl = {"implementation_status": "Implemented", "implemented_at": "2026-11-21T05:00:00-05:00"}
    assert "CR-05" not in codes(_cr(**impl), "2026-11-22", "2026-11-22T04:59:00-05:00")   # 23h59 after
    assert "CR-05" in codes(_cr(**impl), "2026-11-22", "2026-11-22T05:01:00-05:00")       # 24h01 after
    assert "CR-05" not in codes(_cr(**impl, tech_validation_status="Completed", tech_validation_attachment_id=1,
                                    biz_validation_status="Completed", biz_validation_attachment_id=2),
                                "2026-11-23", "2026-11-23T10:00:00-05:00")
    # window in freeze / longer than 8 h
    assert "CR-06" in codes(_cr(crq_start="2026-12-19T02:00:00-05:00", crq_end="2026-12-19T06:00:00-05:00",
                                raised_at="2026-11-01"))
    assert "CR-06" in codes(_cr(crq_end="2026-11-21T11:00:00-05:00"))       # 9 h
    assert "CR-06" not in codes(_cr(crq_end="2026-11-21T10:00:00-05:00"))   # 8 h exactly
    # leads, release type, status vs dates
    assert "CR-07" in codes(_cr(cms_lead_id=None))
    assert "CR-08" in codes(_cr(release_train=None))
    assert "CR-08" not in codes(_cr(release_type="Independent", release_train=None))
    assert "CR-09" in codes(_cr(), "2026-11-23", "2026-11-23T09:30:00-05:00")
    # lead time: raised Thu 5 Nov -> (5 Nov, 21 Nov] = 6,9,10,12,13,16..20 = 10 bd (pass); Fri 6 Nov -> 9 (fail)
    assert "CR-10" not in codes(_cr(raised_at="2026-11-05"))
    assert "CR-10" in codes(_cr(raised_at="2026-11-06"))
    assert "CR-10" not in codes(_cr(raised_at="2026-11-13", release_type="Independent", release_train=None))  # 5 bd
    assert "CR-10" in codes(_cr(raised_at="2026-11-16", release_type="Independent", release_train=None))      # 4 bd
    # backout
    assert "CR-11" in codes(_cr(backout_attachment_id=None))


def test_compliance_sto_suggestion_any_open_flag_at_t5_is_no_go():
    """PO §5: STO Approval auto-sets Tentative Go when all flags clear at T-5, Tentative No Go if any open."""
    # 16 Nov is T-4 (17..20 Nov) for the 21 Nov window; CMS Lead missing is an open flag.
    r = compliance.check_cr(_cr(cms_lead_id=None, sto_approval="Tentative Go"), D("2026-11-16"))
    assert r["flags"]
    assert r["sto_suggestion"] == "Tentative No Go"


def test_compliance_utc_window_freeze_boundary():
    """22:00 ET Sun 13 Dec is 03:00Z Mon 14 Dec; the window is before the freeze (starts 14 Dec ET)."""
    r = compliance.check_cr(_cr(crq_start="2026-12-14T03:00:00+00:00", crq_end="2026-12-14T05:00:00+00:00",
                                raised_at="2026-11-01", release_type="Independent", release_train=None), D("2026-12-01"))
    assert "CR-06" not in {f["code"] for f in r["flags"]}


# ================================================================== REMINDERS
@pytest.mark.parametrize("since, every, today, nxt", [
    ("2026-10-19", 2, "2026-10-19", "2026-10-21"),
    ("2026-10-19", 2, "2026-10-21", "2026-10-23"),
    ("2026-10-19", 2, "2026-10-23", "2026-10-27"),   # Fri + 2 bd = Tue
    ("2026-11-09", 2, "2026-11-09", "2026-11-12"),   # 10, 12 (11 holiday)
    ("2026-12-23", 2, "2026-12-23", "2026-12-29"),   # 24, 29 (25, 28 holidays)
    ("2026-10-07", 3, "2026-10-19", "2026-10-20"),   # 12, 15, 20
])
def test_reminder_cadence(since, every, today, nxt):
    assert reminders.next_reminder(since, every, today) == D(nxt)


def _l2_state(today_lead=True):
    return {"initiatives": [{"id": 6, "rddc": "RDDC-24702", "name": "X", "stage": "Estimation",
                             "requestor_id": 23, "requestor_name": "Marcus Thorne", "dc_pm_name": "Grace Ellingham",
                             "l2_status": "Pending approval", "l2_submitted_at": "2026-10-07T10:00:00-04:00",
                             "l2_hours": 650, "l2_tshirt": "M", "sa_completeness": 100, "components": []}],
            "change_requests": [], "delivery_lead": {"id": 18, "name": "Arlo Kingsley"} if today_lead else None}


def test_l2_reminders_escalate_after_third():
    # since Wed 7 Oct, every 3 bd: #1 Mon 12, #2 Thu 15, #3 Tue 20, #4 Fri 23 (-> Delivery Lead)
    st = _l2_state()
    on20 = {n["dedupe_key"]: n for n in reminders.due_reminders(st, D("2026-10-20"))}
    assert on20["l2_approval:initiative:6:2026-10-20"]["to_name"] == "Marcus Thorne"
    esc = on20["l2_escalation:initiative:6:2026-10-23"]
    assert esc["to_name"] == "Arlo Kingsley"
    on15 = {n["dedupe_key"] for n in reminders.due_reminders(st, D("2026-10-15"))}
    assert on15 == {"l2_approval:initiative:6:2026-10-15", "l2_approval:initiative:6:2026-10-20"}
    assert reminders.l2_reminder_count(st["initiatives"][0], D("2026-10-20")) == 3


def test_sa_reminder_third_copies_pm_and_dedupe():
    ini = {"id": 9, "rddc": "RDDC-24817", "name": "US API Enhancement", "stage": "Solution", "dc_sa_id": 14,
           "dc_sa_name": "Sana Whitfield", "dc_pm_name": "Grace Ellingham", "sa_completeness": 88,
           "sa_missing": ["Backout plan"], "sa_attached": True, "sa_since": "2026-10-19T09:40:05-04:00",
           "components": []}
    st = {"initiatives": [ini, dict(ini)], "change_requests": [], "delivery_lead": None}  # duplicate on purpose
    first = reminders.due_reminders(st, D("2026-10-19"))
    assert [n["dedupe_key"] for n in first] == ["sa_action_required:initiative:9:2026-10-21"]  # deduped
    # #1 21 Oct, #2 23 Oct, #3 27 Oct -> cc DC PM
    third = {n["dedupe_key"]: n for n in reminders.due_reminders(st, D("2026-10-27"))}
    assert third["sa_action_required:initiative:9:2026-10-27"]["cc_names"] == ["Grace Ellingham"]
    assert third["sa_action_required:initiative:9:2026-10-29"]["cc_names"] == ["Grace Ellingham"]
    # idempotent: same day twice -> same keys
    assert [n["dedupe_key"] for n in reminders.due_reminders(st, D("2026-10-27"))] == list(third)


# ================================================================== SA COMPLETENESS
def _doc(sections):
    names = {"ctx": "Business context", "scope": "Scope", "comp": "Impacted components",
             "int": "Integration and sequence", "nfr": "Non-functional requirements", "sec": "Security",
             "data": "Data", "back": "Backout plan", "oq": "Open questions"}
    body = ["# Solution Architecture: Test", "Version: 1.2 | Author: Sana Whitfield", ""]
    for i, k in enumerate(sections, 1):
        body += [f"## {i}. {names[k]}",
                 ("This paragraph is deliberately long enough that it can never be mistaken for a heading line by "
                 "the section detector, because it runs well past ninety characters of text.")]
    return "\n".join(body)


ALL9 = ["ctx", "scope", "comp", "int", "nfr", "sec", "data", "back", "oq"]


@pytest.mark.parametrize("n, expected", [(9, 100), (8, 88), (7, 77), (6, 66), (5, 55), (1, 11), (0, 0)])
def test_sa_floor(n, expected):
    # floor(n/9*100): 8 -> 88.88 -> 88 (not 89); 7 -> 77.7 -> 77; 5 -> 55.5 -> 55
    assert math.floor(n / 9 * 100) == expected
    r = sa_completeness.score(_doc(ALL9[:n]))
    assert r["sections_found"] == n
    assert r["completeness"] == expected


def test_sa_hero_missing_backout():
    r = sa_completeness.score(_doc([s for s in ALL9 if s != "back"]))
    assert r["completeness"] == 88 and r["missing"] == ["Backout plan"]
    assert r["author"] == "Sana Whitfield" and r["version"] == "1.2"


def test_sa_body_sentence_is_not_a_heading():
    """A short body sentence that merely starts with a section word must not count as that section."""
    doc = _doc([s for s in ALL9 if s != "back"]) + "\nRollback is not defined yet.\n"
    assert sa_completeness.score(doc)["completeness"] == 88


# ================================================================== ROUND 2 (docs/qa/round2_decisions.md)
FLOAT_LINE = "Readiness float {} business day{} to DC-2702 affecting WBS-600"


@pytest.mark.parametrize("readiness_end, fl, sched, attention", [
    # strictly between readiness and Sat 20 Feb (15 Feb holiday):
    ("2027-02-12", 4, "Amber", []),                                  # 16,17,18,19
    ("2027-02-16", 3, "Amber", []),                                  # 17,18,19 -> no attention
    ("2027-02-17", 2, "Amber", [FLOAT_LINE.format(2, "s")]),         # 18,19 -> attention
    ("2027-02-18", 1, "Amber", [FLOAT_LINE.format(1, "")]),
    ("2027-02-19", 0, "Amber", [FLOAT_LINE.format(0, "s")]),
])
def test_r2_attention_float_edges(readiness_end, fl, sched, attention):
    b = mk_bundle()
    b["tasks"][0].update(planned_start=readiness_end, planned_end=readiness_end)
    h = health.compute_health(b, D("2026-10-19"))
    assert h["dimensions"]["schedule"]["metrics"]["float_bd"] == fl
    assert h["dimensions"]["schedule"]["rag"] == sched
    assert h["attention"] == attention
    assert h["overall"] == "Amber"


def test_r2_attention_float_minus3_is_schedule_red():
    b = mk_bundle()
    b["tasks"][0].update(planned_start="2027-02-24", planned_end="2027-02-24")  # 22,23,24 after the train -> -3
    h = health.compute_health(b, D("2026-10-19"))
    assert h["dimensions"]["schedule"]["metrics"]["float_bd"] == -3
    assert h["dimensions"]["schedule"]["rag"] == "Red" and h["overall"] == "Red"
    assert h["attention"] and all("WBS-600" in a or "WBS-700" in a for a in h["attention"])
    assert not any(a.startswith("Readiness float") for a in h["attention"])


def test_r2_attention_float2_with_green_override_drops_line():
    """Attention follows the shown RAG: a DC PM Green override on Schedule removes the Amber watch line."""
    b = mk_bundle(ini={"rag_overrides_json": {"schedule": {"rag": "Green", "reason": "Train confirmed"}}})
    b["tasks"][0].update(planned_start="2027-02-17", planned_end="2027-02-17")
    h = health.compute_health(b, D("2026-10-19"))
    assert h["dimensions"]["schedule"]["rag"] == "Green"
    assert h["attention"] == []


def _hero_draft(**kw):
    cr = {"id": 1, "crq_number": "CRQ000001052216", "raised_at": "2026-10-19",
          "crq_start": "2027-02-20T02:00:00-05:00", "crq_end": "2027-02-20T06:00:00-05:00",
          "release_type": "Bundle", "release_train": "DC-2702", "target_release": "DC-2702",
          "affected_cis": ["API-PLATFORM", "EDP", "CIAM", "OBSERVABILITY"],
          "impacted_components": ["APIP", "EDP", "CIAM", "SRE"],
          "implementation_status": "Not Started", "crq_approval_status": "Draft", "sto_approval": None,
          "cms_lead_id": 19, "rel_lead_id": 20, "resource_id": 1,
          "tech_validation_status": "Not Started", "biz_validation_status": "Not Started"}
    cr.update(kw)
    return cr


HERO_CTX = {"plan_prod_date": "2027-02-20", "target_train": {"code": "DC-2702", "train_date": "2027-02-20"}}


def _by_rule(r):
    return {f["rule_id"]: f for f in r["findings"]}


@pytest.mark.parametrize("ctx", ["explicit", "bundle"])
def test_r2_hero_draft_19oct_one_flag_score_89(ctx):
    context = HERO_CTX if ctx == "explicit" else {"bundle": _hero_bundle()}
    r = compliance.check_cr(_hero_draft(), D("2026-10-19"), context)
    f = _by_rule(r)
    # Not due yet: CR-01, CR-02 (T-2), CR-04, CR-05 (24 h after the window)
    assert {k for k, v in f.items() if v["status"] == "Not due yet"} == {"CR-01", "CR-02", "CR-04", "CR-05"}
    # T-2 for Sat 20 Feb: last bd before the window Fri 19 Feb, minus 2 bd -> Wed 17 Feb 2027
    assert f["CR-01"]["due_date"] == f["CR-02"]["due_date"] == "2027-02-17"
    assert f["CR-01"]["reason"] == "Due by Wed 17 Feb 2027 (T-2 business days)."
    # window ends Sat 20 Feb 06:00 -> evidence due 24 h later, Sun 21 Feb
    assert f["CR-04"]["due_date"] == f["CR-05"]["due_date"] == "2027-02-21"
    # Checked = 13 rules - 4 not due = 9: Pass 03,06,07,08,09,10,12,13 = 8; Fail 11 = 1. 8/9 = 88.9 -> 89
    assert [x["code"] for x in r["flags"]] == ["CR-11"]
    assert (r["passed"], r["checked"], r["not_due"]) == (8, 9, 4)
    assert r["score"] == round(8 / 9 * 100) == 89
    assert f["CR-12"]["status"] == "Pass" and f["CR-12"]["detail"] == "Window matches WBS-700 on Sat 20 Feb 2027."
    assert f["CR-13"]["status"] == "Pass"
    assert r["sto_suggestion"] is None  # decision 2: no suggestion before T-5 ("Not requested")


def test_r2_t2_boundary_sto_and_crq_approval():
    # QA-B-09 ruling: "Due by Wed 17 Feb" is inclusive -> Not due yet on 16 and 17 Feb, Fail from Thu 18 Feb
    for day in ("2027-02-16", "2027-02-17"):
        f = _by_rule(compliance.check_cr(_hero_draft(backout_attachment_id=9), D(day), HERO_CTX))
        assert f["CR-01"]["status"] == "Not due yet" and f["CR-02"]["status"] == "Not due yet", day
        assert f["CR-01"]["due_date"] == "2027-02-17"
    f18 = _by_rule(compliance.check_cr(_hero_draft(backout_attachment_id=9), D("2027-02-18"), HERO_CTX))
    assert f18["CR-01"]["status"] == "Fail" and f18["CR-02"]["status"] == "Fail"
    ok = _by_rule(compliance.check_cr(_hero_draft(backout_attachment_id=9, sto_approval="Go",
                                                  crq_approval_status="Approved"), D("2027-02-17"), HERO_CTX))
    assert ok["CR-01"]["status"] == "Pass" and ok["CR-02"]["status"] == "Pass"


def test_r2_validation_not_due_until_24h_after_implementation():
    impl = {"implementation_status": "Implemented", "implemented_at": "2027-02-20T05:40:00-05:00",
                "backout_attachment_id": 9, "sto_approval": "Go", "crq_approval_status": "Approved"}
    a = _by_rule(compliance.check_cr(_hero_draft(**impl), D("2027-02-21"),
                                     {**HERO_CTX, "now": "2027-02-21T05:39:00-05:00"}))   # 23 h 59 m
    assert a["CR-04"]["status"] == "Not due yet" and a["CR-04"]["due_date"] == "2027-02-21"
    b = _by_rule(compliance.check_cr(_hero_draft(**impl), D("2027-02-21"),
                                     {**HERO_CTX, "now": "2027-02-21T05:41:00-05:00"}))   # 24 h 01 m
    assert b["CR-04"]["status"] == "Fail" and b["CR-05"]["status"] == "Fail"


def test_r2_score_excludes_not_due():
    # Nov 16 baseline: STO Go, Approved -> Pass; validation Not Started, not implemented -> 2 Not due.
    # 13 - 2 = 11 checked, all pass -> 100; drop the CMS Lead -> 10/11 = 90.9 -> 91
    r = compliance.check_cr(_cr(), D("2026-11-16"))
    assert (r["checked"], r["not_due"], r["score"]) == (11, 2, 100)
    r = compliance.check_cr(_cr(cms_lead_id=None), D("2026-11-16"))
    assert (r["passed"], r["checked"], r["score"]) == (10, 11, 91)


def test_r2_sto_suggestion_from_t5():
    # Wed 10 Feb: 11,12,16,17,18,19 = 6 bd -> None; Thu 11 Feb: 12,16,17,18,19 = 5 -> decision window
    clean = _hero_draft(backout_attachment_id=9)
    assert compliance.check_cr(clean, D("2027-02-10"), HERO_CTX)["sto_suggestion"] is None
    assert compliance.check_cr(clean, D("2027-02-11"), HERO_CTX)["sto_suggestion"] == "Tentative Go"
    assert compliance.check_cr(_hero_draft(), D("2027-02-11"), HERO_CTX)["sto_suggestion"] == "Tentative No Go"


def test_r2_cr12_cr13_bundle_only():
    late = {"plan_prod_date": "2027-03-20", "target_train": {"code": "DC-2702", "train_date": "2027-02-20"}}
    f = _by_rule(compliance.check_cr(_hero_draft(), D("2026-10-19"), late))
    assert f["CR-12"]["status"] == "Fail"   # window 20 Feb != WBS-700 20 Mar
    assert f["CR-13"]["status"] == "Fail"   # 20 Mar after DC-2702 20 Feb
    f = _by_rule(compliance.check_cr(_hero_draft(release_type="Independent", release_train=None),
                                     D("2026-10-19"), late))
    assert f["CR-12"]["status"] == "Pass" and f["CR-13"]["status"] == "Pass"


def test_r2_capacity_quarter_labels_include_fy():
    res = [{"id": 1, "name": "A", "team": "CIAM", "availability": {}, "default_monthly_hours": 140}]
    out = capacity.compute_capacity(res, [], ["2026-10", "2026-11"])
    assert [c["quarter"] for c in out["columns"]] == ["Q4 FY26", "Q1 FY27"]
    assert [c["quarter_range"] for c in out["columns"]] == ["Aug–Oct", "Nov–Jan"]
    q = capacity.compute_capacity(res, [], ["2026-10", "2026-11"], group="quarter")
    assert [c["label"] for c in q["columns"]] == ["Q4 FY26 (Aug–Oct)", "Q1 FY27 (Nov–Jan)"]
