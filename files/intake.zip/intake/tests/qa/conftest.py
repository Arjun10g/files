"""QA-A (L2 API contract) fixtures. Reuses the session seed template from tests/conftest.py.

`qa_app_factory()` builds a fresh, isolated app (own DB copy + own uploads dir) with optional config overrides,
so module-scoped flows (hero end-to-end) and multi-app checks (determinism) do not share state.
"""
from __future__ import annotations

import shutil

import pytest

from app import create_app, db

DEFAULTS = {"TESTING": True, "TODAY": "2026-10-19", "AI_MODE": "simulated", "HAS_API_KEY": False}


@pytest.fixture(scope="session")
def qa_app_factory(seeded_template, tmp_path_factory):
    template_db, template_uploads = seeded_template

    def build(**overrides):
        root = tmp_path_factory.mktemp("qa_app")
        db_path, upload_dir = root / "bmo.db", root / "uploads"
        shutil.copyfile(template_db, db_path)
        shutil.copytree(template_uploads, upload_dir)
        cfg = {**DEFAULTS, "DB_PATH": str(db_path), "UPLOAD_DIR": str(upload_dir), **overrides}
        return create_app(**cfg)

    yield build
    db.close_standalone()
