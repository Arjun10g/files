# ruff: noqa: BLE001, B023, SIM102  -- a sweep harness: it records every failure and keeps going by design
"""QA-C · L4 independent end-to-end browser & UX audit.

Walks the PO §1 demo script click-by-click through the UI only (as a presenter would), screenshots every step at
1366×768 and 1920×1080, sweeps every route and visible button (non-destructive), checks copy rules (UX §6) and
compares displayed dates across America/Toronto and Pacific/Auckland.

Run under pytest (starts its own server on a free port with its own temp DB):
    .venv/bin/python -m pytest tests/qa/test_e2e_audit.py -q -s
Or standalone against a running server (writes screenshots + findings JSON to docs/qa/shots/round1/):
    .venv/bin/python tests/qa/test_e2e_audit.py --base-url http://127.0.0.1:5091
"""
from __future__ import annotations

import contextlib
import datetime as dt
import json
import os
import re
import socket
import subprocess
import sys
import time
import traceback
import urllib.request
from pathlib import Path

import pytest

pytestmark = pytest.mark.e2e

ROOT = Path(__file__).resolve().parents[2]
SHOTS = Path(os.environ.get("QA_C_SHOTS") or ROOT / "docs" / "qa" / "shots" / "round1")
PYTHON = str(ROOT / ".venv" / "bin" / "python") if (ROOT / ".venv" / "bin" / "python").exists() else sys.executable
SA_DOC = ROOT / "app" / "seed" / "files" / "SA_US_API_Enhancement_v1.2.docx"
VIEWPORTS = {"1366": {"width": 1366, "height": 768}, "1920": {"width": 1920, "height": 1080}}
HOLIDAYS = {dt.date(2026, 11, 11), dt.date(2026, 12, 25), dt.date(2026, 12, 28), dt.date(2027, 1, 1), dt.date(2027, 2, 15)}

BAD_TEXT = re.compile(r"\b(undefined|NaN|null)\b|\[object Object\]|\bInvalid Date\b|^(\[value\] )?None$")
JARGON = re.compile(r"\b(JSON|API key|endpoint|LLM|tokens?|payload|stack trace|exception|traceback|fixture|"
                    r"simulated_fixture|simulated_generated|live_fallback|ai_run|error 500|HTTP \d{3}|Internal Server Error|"
                    r"Bad Request|Not Found|KeyError|TypeError|sqlite)\b", re.IGNORECASE)
ISO_DATE = re.compile(r"\b20\d\d-\d\d-\d\d\b")
US_DATE = re.compile(r"\b\d{1,2}/\d{1,2}/\d{2,4}\b|\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \d{1,2}, \d{4}\b")
HOURS_BAD = re.compile(r"\b\d[\d,.]*h\b|\b\d[\d,.]* ?hrs?\b")
SNAKE = re.compile(r"\b[a-z]+_[a-z_]+\b")

ROUTES = ["#/portfolio", "#/search", "#/initiative/new", "#/intake", "#/resources", "#/risks", "#/changes",
          "#/artifacts", "#/outbox", "#/ai-activity", "#/settings"]
TABS = ["pg1", "pg2", "pg3", "pg4", "pg5", "risks", "artifacts", "print"]
# Buttons the sweep never clicks (destructive, or writes data / changes global state).
SKIP_BUTTON = re.compile(r"reset|delete|remove|reject|fast-forward|load sample|approve|send|accept|apply|assign|save|"
                         r"add selected|re-baseline|undo|override|discard|log ?out|submit|create crq|mark|archive|close initiative|"
                         r"import|upload|attach|browse|print|^go$|no-go|acknowledge|dismiss|move to next|^confirm$|"
                         r"run reminders|auto-slot|\+ add", re.IGNORECASE)

# --------------------------------------------------------------------------------------------- page instrumentation
JS_SCAN = r"""() => {
  const vis = (el) => { if (!el) return false; const s = getComputedStyle(el); if (s.display==='none'||s.visibility==='hidden'||+s.opacity===0) return false;
                        const r = el.getBoundingClientRect(); return r.width>0 && r.height>0; };
  const texts = [];
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while (w.nextNode()) { const n = w.currentNode; const el = n.parentElement;
    if (!el || el.closest('script,style,noscript,svg title')) continue; if (!vis(el)) continue;
    const t = n.nodeValue.replace(/\s+/g,' ').trim(); if (t) texts.push(t); }
  document.querySelectorAll('input:not([type=hidden]):not([type=file]),textarea,select').forEach(i => { if (vis(i) && i.value) texts.push('[value] '+i.value); });
  const de = document.documentElement;
  const overflowX = de.scrollWidth > de.clientWidth + 1 ? de.scrollWidth - de.clientWidth : 0;
  // truncated cells (ellipsis / clipped)
  const clipped = [];
  document.querySelectorAll('td,th,.lv-value,.lv-label,.pill,.chip,button,.btn,label,h1,h2,h3,.kpi,.dv-kpi').forEach(el => {
    if (!vis(el)) return; const s = getComputedStyle(el);
    if ((s.textOverflow==='ellipsis' || s.overflow==='hidden' || s.overflowX==='hidden') && el.scrollWidth > el.clientWidth + 2 && el.textContent.trim())
      clipped.push(el.tagName.toLowerCase()+'.'+[...el.classList].join('.')+': '+el.textContent.trim().slice(0,60));
  });
  // inner horizontal scrollers (tables wider than box)
  const scrollers = [];
  document.querySelectorAll('*').forEach(el => { const s = getComputedStyle(el);
    if ((s.overflowX==='auto'||s.overflowX==='scroll') && el.scrollWidth > el.clientWidth + 4 && vis(el) && el !== de && el !== document.body)
      scrollers.push(el.tagName.toLowerCase()+'.'+[...el.classList].join('.')+' '+el.clientWidth+'/'+el.scrollWidth); });
  // overlapping interactive elements
  const inter = [...document.querySelectorAll('button,a.btn,input:not([type=hidden]):not([type=file]),select,.pill,.rag-pill')].filter(vis).slice(0,400);
  const rects = inter.map(e => e.getBoundingClientRect());
  const overlaps = [];
  for (let i=0;i<inter.length;i++) for (let j=i+1;j<inter.length;j++) {
    if (inter[i].contains(inter[j]) || inter[j].contains(inter[i])) continue;
    const a=rects[i], b=rects[j]; const x=Math.min(a.right,b.right)-Math.max(a.left,b.left), y=Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top);
    if (x>4 && y>4) overlaps.push((inter[i].textContent||inter[i].getAttribute('aria-label')||inter[i].tagName).trim().slice(0,30)+' ✕ '+(inter[j].textContent||inter[j].getAttribute('aria-label')||inter[j].tagName).trim().slice(0,30));
  }
  const spinners = [...document.querySelectorAll('.spinner,.loading,.loading-line,.skeleton,[aria-busy=true],.thinking-step.is-running,.is-busy')].filter(vis).map(e => e.className.toString().slice(0,60));
  const buttons = [...document.querySelectorAll('button,a.btn')].filter(vis).map(b => (b.textContent||b.getAttribute('aria-label')||'').replace(/\s+/g,' ').trim()).filter(Boolean);
  const headings = [...document.querySelectorAll('h1,h2,h3,h4,.page-title,.card-title,.dv-section-title,.eyebrow,th')].filter(vis).map(e => e.textContent.replace(/\s+/g,' ').trim()).filter(Boolean);
  return {texts, overflowX, clipped: clipped.slice(0,40), scrollers: scrollers.slice(0,20), overlaps: overlaps.slice(0,20), spinners, buttons, headings, title: document.title};
}"""


def free_port() -> int:
    with contextlib.closing(socket.socket()) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def add_bd(d: dt.date, n: int) -> dt.date:
    while n:
        d += dt.timedelta(days=1)
        if d.weekday() < 5 and d not in HOLIDAYS:
            n -= 1
    return d


class Audit:
    """Collects findings across one browser page."""

    def __init__(self, browser, base_url: str, tz: str, vp: str, tag: str):
        self.base_url = base_url.rstrip("/")
        self.tz, self.vp, self.tag = tz, vp, tag
        self.ctx = browser.new_context(timezone_id=tz, viewport=VIEWPORTS[vp], accept_downloads=True, locale="en-CA",
                                       permissions=["clipboard-read", "clipboard-write"])
        self.page = self.ctx.new_page()
        self.page.set_default_timeout(15000)
        self.events: list[dict] = []
        self.steps: list[dict] = []
        self.n = 0
        self.cur = "start"
        p = self.page
        p.on("console", lambda m: self.ev("console." + m.type, m.text) if m.type in ("error", "warning") else None)
        p.on("pageerror", lambda e: self.ev("pageerror", str(e)))
        p.on("requestfailed", lambda r: self.ev("requestfailed", f"{r.method} {r.url} {r.failure}"))
        p.on("response", lambda r: self.ev(f"http{r.status}", f"{r.request.method} {r.url}") if r.status >= 400 else None)
        p.on("dialog", lambda d: (self.ev("dialog", d.message), d.dismiss()))

    def ev(self, kind, text):
        self.events.append({"step": self.cur, "kind": kind, "text": text[:500]})

    # ------------------------------------------------------------------ helpers
    def close_dialogs(self):
        """A dialog left open by a failed step must not cascade into later steps."""
        with contextlib.suppress(Exception):
            for _ in range(3):
                dlg = self.page.get_by_role("dialog")
                if not dlg.count() or not dlg.last.is_visible():
                    return
                self.page.keyboard.press("Escape")
                self.page.wait_for_timeout(200)
                if dlg.count() and dlg.last.is_visible():
                    dlg.last.get_by_role("button", name=re.compile(r"^\W*(Close|Cancel)\W*$", re.IGNORECASE)).last.click(timeout=2000)

    def go(self, hash_: str, wait=600):
        self.close_dialogs()
        self.page.goto(f"{self.base_url}/{hash_}")
        self.idle(wait)

    def idle(self, ms=400):
        with contextlib.suppress(Exception):
            self.page.wait_for_load_state("networkidle", timeout=8000)
        self.page.wait_for_timeout(ms)

    def btn(self, *names, scope=None, exact_first=True):
        where = scope or self.page
        for name in names:
            loc = where.get_by_role("button", name=re.compile(rf"^\W*{re.escape(name)}\W*$", re.IGNORECASE))
            for i in range(loc.count()):
                if loc.nth(i).is_visible():
                    return loc.nth(i)
        for name in names:
            loc = where.get_by_role("button", name=re.compile(re.escape(name), re.IGNORECASE))
            for i in range(loc.count()):
                if loc.nth(i).is_visible():
                    return loc.nth(i)
        raise AssertionError(f"no visible button named any of {names}")

    def wait_text(self, text, timeout=20000):
        if isinstance(text, re.Pattern):
            self.page.wait_for_function("(src) => new RegExp(src).test(document.body.innerText)", arg=text.pattern, timeout=timeout)
        else:
            self.page.wait_for_function("(t) => document.body.innerText.includes(t)", arg=text, timeout=timeout)

    def ai_card(self, feature, timeout=30000):
        card = self.page.locator(f".ai-card[data-feature={feature}]").last
        card.locator(".ai-card-actions").wait_for(timeout=timeout)
        return card

    def accept(self, feature, labels=("Accept", "Apply this fix", "Add selected to Risk Register")):
        card = self.ai_card(feature)
        self.btn(*labels, scope=card).click()
        with contextlib.suppress(Exception):
            self.page.wait_for_function("(f) => !document.querySelector(`.ai-card-result[data-feature=${f}]`)", arg=feature, timeout=20000)
        self.idle()

    def persona(self, name):
        self.page.locator("#persona-select").select_option(name)
        with contextlib.suppress(Exception):
            self.page.get_by_text(f"Acting as {name}.").first.wait_for(timeout=5000)
        self.idle(200)

    def scan(self) -> dict:
        try:
            return self.page.evaluate(JS_SCAN)
        except Exception as exc:  # page navigated mid-scan
            return {"texts": [], "error": str(exc), "overflowX": 0, "clipped": [], "scrollers": [], "overlaps": [],
                    "spinners": [], "buttons": [], "headings": []}

    def copy_issues(self, scan: dict) -> dict:
        texts = scan.get("texts", [])
        return {
            "bad_text": sorted({t[:120] for t in texts if BAD_TEXT.search(t)}),
            "jargon": sorted({t[:120] for t in texts if JARGON.search(t)}),
            "iso_dates": sorted({t[:120] for t in texts if ISO_DATE.search(t) and not t.startswith("[value]")}),
            "us_dates": sorted({t[:120] for t in texts if US_DATE.search(t)}),
            "hours_fmt": sorted({t[:120] for t in texts if HOURS_BAD.search(t)}),
            "snake_case": sorted({t[:120] for t in texts if SNAKE.search(t) and not t.startswith("[value]")}),
        }

    def shot(self, slug: str, full=False, ok=True, note="", err=""):
        self.n += 1
        name = f"{self.tag}_{self.n:02d}_{re.sub(r'^[0-9]+[a-z]?_', '', slug)}.png"
        SHOTS.mkdir(parents=True, exist_ok=True)
        with contextlib.suppress(Exception):
            if full:  # sticky shell would otherwise be painted mid-page
                self.page.evaluate("() => window.scrollTo(0, 0)")
                self.page.wait_for_timeout(150)
            self.page.screenshot(path=str(SHOTS / name), full_page=full)
        sc = self.scan()
        rec = {"n": self.n, "step": slug, "shot": f"docs/qa/shots/round1/{name}", "ok": ok, "note": note, "error": err,
               "url": self.page.url, "overflowX": sc.get("overflowX"), "clipped": sc.get("clipped"),
               "scrollers": sc.get("scrollers"), "overlaps": sc.get("overlaps"), "spinners": sc.get("spinners"),
               "copy": self.copy_issues(sc), "buttons": sc.get("buttons", [])[:80], "headings": sc.get("headings", [])[:60]}
        self.steps.append(rec)
        return rec

    @contextlib.contextmanager
    def step(self, slug, full=False):
        self.cur = slug
        try:
            yield
        except Exception as exc:  # record, screenshot, carry on
            self.shot(slug + "_FAILED", full=True, ok=False, err=f"{type(exc).__name__}: {str(exc)[:400]}")
            traceback.print_exc()
        else:
            self.shot(slug, full=full)

    def close(self):
        with contextlib.suppress(Exception):
            self.ctx.close()


# --------------------------------------------------------------------------------------------------- demo walk
def demo_walk(a: Audit, api) -> dict:
    p = a.page
    facts: dict = {}
    api("POST", "/admin/reset", {})
    api("PUT", "/settings", {"ai_speed": "Fast", "persona": "DC PM"})
    with a.step("01_portfolio_home", full=True):
        a.go("#/", 1200)
        p.wait_for_url(re.compile(r"#/portfolio$"))
        p.locator("[data-testid=kpi-strip]").wait_for()
        facts["kpi"] = p.locator("[data-testid=kpi-strip]").inner_text()
    with a.step("02_add_new_initiative"):
        p.get_by_role("link", name="Add New Initiative").click()
        a.idle()
    with a.step("03_dci_lookup_prefill", full=True):
        p.get_by_label("DC Intake").fill("DCI-3391")
        a.btn("Look up").click()
        p.wait_for_function("() => [...document.querySelectorAll('input')].some((i) => /US API Enhancement/.test(i.value))")
        a.idle()
    with a.step("04_saved_grooming_toast"):
        a.btn("Save").click()
        p.wait_for_url(re.compile(r"#/initiative/\d+/pg1"))
        facts["hero_id"] = int(re.search(r"#/initiative/(\d+)/", p.url).group(1))
        a.wait_text(re.compile(r"Slotted for grooming"))
        p.wait_for_timeout(300)
        facts["toast"] = " | ".join(t.strip() for t in p.locator(".toast").all_inner_texts())
    hid = facts.get("hero_id")
    with a.step("05_intake_analysis_card", full=True):
        a.ai_card("intake_analysis")
        facts["intake_card"] = a.page.locator(".ai-card[data-feature=intake_analysis]").last.inner_text()[:1500]
    with a.step("06_sa_attached_88", full=True):
        p.locator("input[type=file]").first.set_input_files(str(SA_DOC))
        a.wait_text("88%")
        a.idle()
    with a.step("06b_mark_as_groomed"):
        a.btn("Mark as groomed").click()
        a.wait_text("Solution")
        a.idle()
        facts["action_required_chip"] = "Action required by Sana Whitfield" in p.locator("body").inner_text()
    with a.step("07_change_summary_card", full=True):
        a.btn("Generate Change Summary").click()
        card = a.ai_card("change_summary")
        facts["cs_card"] = card.inner_text()[:1500]
    with a.step("08_change_summary_accepted_l2", full=True):
        a.accept("change_summary")
        a.wait_text("1,000 h")
    with a.step("09_persona_dev_lead_send_l2"):
        a.persona("Dev Lead")
        a.btn("Send L2 to DLR", "Send L2 for approval").click()
        a.wait_text("Pending approval")
        a.idle()
    with a.step("10_persona_requestor_approve_l2", full=True):
        a.persona("Requestor")
        a.btn("Approve L2").click()
        a.wait_text("Planning")
        a.idle()
        a.persona("DC PM")
        facts["header_after_l2"] = p.locator(".ws-header, .initiative-header, header.ws-head").first.inner_text()[:400] if p.locator(".ws-header, .initiative-header, header.ws-head").count() else ""
    with a.step("11_pg2_empty"):
        p.get_by_role("tab", name=re.compile("Pg 2")).first.click() if p.get_by_role("tab", name=re.compile("Pg 2")).count() else a.go(f"#/initiative/{hid}/pg2")
        a.idle()
    with a.step("12_plan_card", full=True):
        a.btn("Generate Project Plan").click()
        card = a.ai_card("wbs")
        facts["wbs_card"] = card.inner_text()[:800]
    with a.step("13_plan_accepted", full=True):
        a.accept("wbs")
        body = p.locator("body").inner_text()
        facts["pg2_dates"] = {k: (k in body) for k in ("17 Feb 2027", "10 Feb 2027", "20 Feb 2027", "560 h")}
    with a.step("14_gantt_view", full=True):
        g = p.get_by_role("button", name=re.compile("Generate Gantt view"))
        if g.count() and g.first.is_enabled():
            g.first.click()
        p.locator(".ch-gantt").first.wait_for()
        p.locator(".ch-gantt").first.scroll_into_view_if_needed()
        a.idle()
    with a.step("15_gantt_critical_path"):
        p.locator(".ch-gantt").first.get_by_text("Show critical path").click()
        a.idle(300)
    with a.step("16_edit_wbs210_end_plus5", full=True):
        row = p.locator("tr", has=p.locator("td", has_text=re.compile(r"^\s*WBS-210\s*$"))).first
        row.scroll_into_view_if_needed()
        # find End column index from header
        headers = [t.strip() for t in p.locator("table:has(td:text-is('WBS-210')) thead th").all_inner_texts()]
        if not headers:
            headers = [t.strip() for t in row.locator("xpath=ancestor::table[1]").locator("th").all_inner_texts()]
        end_idx = next(i for i, t in enumerate(headers) if t.lower().startswith("end"))
        cell = row.locator("td").nth(end_idx)
        facts["wbs210_end_before_txt"] = cell.inner_text().strip()
        cell.click()
        inp = cell.locator("input[type=date]")
        inp.wait_for(timeout=5000)
        before = inp.input_value()
        facts["wbs210_end_before"] = before
        new = add_bd(dt.date.fromisoformat(before), 5).isoformat()
        facts["wbs210_end_after"] = new
        inp.fill(new)
        inp.press("Enter")
        a.wait_text(re.compile(r"moved"), timeout=15000)
        a.idle(800)
        facts["toast_after_edit"] = " | ".join(t.strip() for t in p.locator(".toast").all_inner_texts())
        facts["header_after_edit"] = p.locator("body").inner_text()[:600]
    with a.step("17_undo_edit", full=True):
        a.btn("Undo last change", "Undo").click()  # persistent Pg 2 toolbar button (round 2 #29)
        with contextlib.suppress(Exception):
            a.wait_text("17 Feb 2027", timeout=10000)
        a.idle(1000)
        facts["after_undo_body"] = ("17 Feb 2027" in p.locator("body").inner_text())
    with a.step("18_pg3_health", full=True):
        a.go(f"#/initiative/{hid}/pg3", 1000)
        h = p.locator(".ch-health").first
        h.wait_for()
        facts["health_before"] = h.inner_text()[:600]
    with a.step("18b_ask_why_resources_red_before_fix"):
        a.btn("Ask about this initiative").click()
        p.locator(".dv-drawer textarea").wait_for()
        n_before = p.locator("[data-testid=assistant-answer]").count()
        p.locator(".dv-drawer textarea").fill("Why is Resources red?")
        a.btn("Ask", scope=p.locator(".dv-drawer")).click()
        p.wait_for_function("(n) => { const a = [...document.querySelectorAll('[data-testid=assistant-answer]')]; return a.length > n && !a[a.length-1].querySelector('.dv-caret'); }", arg=n_before, timeout=30000)
        a.idle(300)
        facts["why_red_before_fix"] = p.locator("[data-testid=assistant-answer]").last.inner_text()[:1500]
    with contextlib.suppress(Exception):
        p.get_by_role("button", name="Close assistant").click()
        a.idle(200)
    with a.step("19_suggest_resources", full=True):
        a.btn("Suggest Resources").click()
        card = a.ai_card("resources")
        card.scroll_into_view_if_needed()
        facts["resources_card"] = card.inner_text()[:1200]
    with a.step("19b_resources_discard"):
        card = p.locator(".ai-card[data-feature=resources]").last
        a.btn("Discard", scope=card).click()
        a.idle()
        facts["resources_card_dismissed"] = p.locator(".ai-card-result[data-feature=resources]").count() == 0
    with a.step("20_suggest_fix_card", full=True):
        h = p.locator(".ch-health").first
        h.scroll_into_view_if_needed()
        direct = h.get_by_role("button", name=re.compile(r"Suggest fix"))
        if direct.count() and direct.first.is_visible():
            direct.first.click()
        else:  # round 2: click the Red Resources pill -> choice dialog -> Suggest fix
            h.locator("[data-dimension=resources]").get_by_text("Red").first.click()
            a.btn("Suggest fix", scope=p.get_by_role("dialog").last).click()
        card = a.ai_card("rebalance")
        card.scroll_into_view_if_needed()
        facts["rebalance_card"] = card.inner_text()[:1200]
    with a.step("21_fix_applied", full=True):
        a.accept("rebalance")
        p.wait_for_function("() => { const r = document.querySelector('.ch-health [data-dimension=resources]'); return r && r.textContent.includes('Green'); }", timeout=15000)
        facts["health_after"] = p.locator(".ch-health").first.inner_text()[:600]
    with a.step("22_risks_predict_card", full=True):
        a.go(f"#/initiative/{hid}/risks")
        a.btn("Predict risks", "Identify Risks").click()
        card = a.ai_card("risks")
        facts["risks_card"] = card.inner_text()[:1500]
    with a.step("23_risks_accepted", full=True):
        a.accept("risks")
    with a.step("24_pg4_empty"):
        a.go(f"#/initiative/{hid}/pg4")
    with a.step("25_crq_draft", full=True):
        a.btn("Create CRQ draft").click()
        review = p.get_by_role("dialog", name=re.compile("CRQ draft"))
        review.wait_for(timeout=20000)
        facts["crq_review"] = review.inner_text()[:800]
        a.btn("Accept", scope=review).click()
        review.wait_for(state="detached", timeout=20000)
        a.wait_text("CRQ000001052216")
        a.idle()
    with a.step("26_cr_compliance", full=True):
        a.btn("Check CR Compliance").click()
        card = a.ai_card("cr_compliance")
        facts["compliance_card"] = card.inner_text()[:1500]
    with a.step("27_pg5", full=True):
        a.go(f"#/initiative/{hid}/pg5", 1200)
    with a.step("28_portfolio_after", full=True):
        p.get_by_role("link", name="Portfolio View").first.click()
        a.idle(1200)
        dash = p.locator("[data-testid=project-dashboard]")
        dash.get_by_text("RDDC-24817").first.wait_for()
        facts["portfolio_hero_row"] = dash.locator("tr", has_text="RDDC-24817").first.inner_text()
        facts["kpi_after"] = p.locator("[data-testid=kpi-strip]").inner_text()
    questions = [
        ("29_ask_feb_release", "Which initiatives are at risk for the Feb release and why?"),
        ("30_ask_exec_summary", "Draft this week's exec summary"),
        ("31_ask_ciam_jan", "Who has CIAM capacity in January?"),
        ("32_ask_resources_red", "Why is Resources red?"),
        ("33_ask_mgmt_attention", "What needs management attention this week?"),
    ]
    facts["assistant"] = {}
    with a.step("28b_assistant_open"):
        a.btn("Ask Assistant").click()
        p.locator(".dv-drawer textarea").wait_for()
        a.idle(300)
    for slug, q in questions:
        with a.step(slug):
            n_before = p.locator("[data-testid=assistant-answer]").count()
            p.locator(".dv-drawer textarea").fill(q)
            a.btn("Ask", scope=p.locator(".dv-drawer")).click()
            p.wait_for_function("(n) => { const a = [...document.querySelectorAll('[data-testid=assistant-answer]')]; return a.length > n && !a[a.length-1].querySelector('.dv-caret'); }", arg=n_before, timeout=30000)
            a.idle(400)
            ans = p.locator("[data-testid=assistant-answer]").last
            ans.scroll_into_view_if_needed()
            facts["assistant"][q] = ans.inner_text()[:2000]
    with a.step("34_assistant_copy_email"):
        ce = p.locator("[data-testid=assistant-answer]").last.get_by_role("button", name=re.compile("Copy to email"))
        if ce.count():
            ce.first.click()
            a.idle(300)
        facts["copy_email_present"] = ce.count() > 0
    with a.step("35_assistant_closed"):
        p.get_by_role("button", name="Close assistant").click()
        a.idle(300)
    facts["downloads"] = {}
    with a.step("36_export"):
        a.go("#/portfolio")
        for testid in ("export-portfolio", "export-demo-view"):
            loc = p.locator(f"[data-testid={testid}]")
            if not loc.count() or not loc.first.is_visible():
                facts["downloads"][testid] = "not visible"
                continue
            if testid == "export-demo-view" and loc.first.evaluate("(el) => !el.getAttribute('href') || el.getAttribute('href').startsWith('#')"):
                loc.first.click()  # portfolio scope: opens a "choose initiative" dialog
                modal = p.get_by_role("dialog").last
                modal.wait_for(timeout=8000)
                with contextlib.suppress(Exception):
                    modal.locator("select").first.select_option(modal.locator("select option", has_text="RDDC-24817").first.get_attribute("value"))
                with p.expect_download(timeout=20000) as dl:
                    modal.locator("[data-testid=export-demo-view-download], a:has-text('Download'), button:has-text('Download')").first.click()
                with contextlib.suppress(Exception):
                    p.keyboard.press("Escape")
                    if modal.count() and modal.is_visible():
                        a.btn("Close", scope=modal).click()
            else:
                with p.expect_download(timeout=20000) as dl:
                    loc.first.click()
            target = SHOTS / f"{a.tag}_{testid}.xlsx"
            dl.value.save_as(str(target))
            facts["downloads"][testid] = dl.value.suggested_filename
        a.go(f"#/initiative/{hid}/pg1")
        link = p.get_by_role("link", name=re.compile(r"Export to Excel|Demo View workbook"))
        if link.count():
            with p.expect_download(timeout=20000) as dl:
                link.first.click()
            dl.value.save_as(str(SHOTS / f"{a.tag}_hero_demo_view.xlsx"))
            facts["downloads"]["hero"] = dl.value.suggested_filename
    with a.step("37_settings"):
        a.go("#/settings")
    with a.step("38_fast_forward_confirm"):
        a.btn("Fast-forward RDDC-24817").click()
        p.locator(".modal").wait_for()
    with a.step("39_fast_forward_done", full=True):
        a.btn("Fast-forward", scope=p.locator(".modal")).click()
        p.locator(".ff-steps li").first.wait_for(timeout=30000)
        a.idle(500)
        facts["ff_steps"] = p.locator(".ff-steps").inner_text()
    with a.step("40_reset_confirm"):
        a.btn("Reset demo data").click()
        p.locator(".modal").wait_for()
        facts["reset_modal"] = p.locator(".modal").inner_text()
    with a.step("41_reset_done", full=True):
        a.btn("Reset demo data", scope=p.locator(".modal")).click()
        p.wait_for_url(re.compile(r"#/portfolio"), timeout=20000)
        a.idle(1000)
        facts["after_reset_has_hero"] = "RDDC-24817" in p.locator("body").inner_text()
    return facts


# ----------------------------------------------------------------------------------------------------- sweep
BTN_SEL = "main button, main a.btn, main [role=tab], main th[aria-sort], main th button"
VISIBLE_BTNS = """(sel) => [...document.querySelectorAll(sel)].map((b, i) => [b, i]).filter(([b]) => { const r = b.getBoundingClientRect(); const s = getComputedStyle(b);
      return r.width>0 && r.height>0 && s.visibility!=='hidden' && !b.closest('.ai-card'); })
    .map(([b, i]) => ({i, t: (b.getAttribute('aria-label') || b.textContent || b.title || '').replace(/[\\s\\u2726]+/g,' ').trim(),
                     dis: !!b.disabled || b.getAttribute('aria-disabled')==='true', dl: b.hasAttribute('download'), href: b.getAttribute('href')}))"""


def _fingerprint(page):
    return page.evaluate("""() => { const t = document.body.innerText; let h = 0; for (let i = 0; i < t.length; i++) h = (h * 31 + t.charCodeAt(i)) | 0;
        return [location.hash, h, document.querySelectorAll('*').length, document.activeElement && document.activeElement.tagName,
                document.querySelectorAll('.modal,.toast,.ai-card,[role=dialog],.is-open,[aria-expanded=true]').length].join('|'); }""")


def sweep(a: Audit, api, hero_id: int | None) -> dict:
    p = a.page
    res: dict = {"routes": {}, "dead_buttons": [], "empty_states": {}, "ai_cards": {}, "toasts": [], "downloads": {}}
    inits = api("GET", "/initiatives")["items"]
    targets = list(ROUTES)
    ids = [i["id"] for i in inits]
    if hero_id:
        ids = [hero_id] + [i for i in ids if i != hero_id]
    for iid in ids[:2]:
        targets += [f"#/initiative/{iid}/{t}" for t in TABS]
    for route in targets:
        a.cur = "sweep " + route
        a.go(route, 1500)
        p.wait_for_timeout(2500)  # spinners must be gone by now
        rec = a.shot("sweep_" + re.sub(r"[^a-z0-9]+", "_", route.lower()).strip("_"), full=True)
        res["routes"][route] = rec["n"]
        btns = p.evaluate(VISIBLE_BTNS, BTN_SEL)
        seen = set()
        for b in btns[:60]:
            t = b["t"]
            if not t or t in seen or SKIP_BUTTON.search(t) or b["dis"]:
                continue
            seen.add(t)
            try:
                a.go(route, 300)
                loc = p.locator(BTN_SEL).nth(b["i"])
                if not loc.is_visible():
                    continue
                now_t = loc.evaluate("(b) => (b.getAttribute('aria-label') || b.textContent || b.title || '').replace(/[\\s\\u2726]+/g,' ').trim()")
                if now_t != t:  # re-render changed the order; never click the wrong thing
                    res.setdefault("skipped_mismatch", []).append({"route": route, "want": t, "got": now_t})
                    continue
                if b["dl"] or (b["href"] or "").startswith("/api/"):
                    try:
                        with p.expect_download(timeout=15000) as dl:
                            loc.click(timeout=4000)
                        res["downloads"][f"{route} · {t}"] = dl.value.suggested_filename
                    except Exception as exc:
                        res["dead_buttons"].append({"route": route, "button": t, "why": "no download: " + str(exc)[:80]})
                    continue
                before = _fingerprint(p)
                reqs = []
                handler = lambda r: reqs.append(r.url)
                p.on("request", handler)
                loc.click(timeout=4000)
                p.wait_for_timeout(1800)
                p.remove_listener("request", handler)
                after = _fingerprint(p)
                if before == after and not reqs:
                    res["dead_buttons"].append({"route": route, "button": t})
                toasts = [x.strip().replace("\n", " ") for x in p.locator(".toast").all_inner_texts()]
                if toasts:
                    res["toasts"].append({"route": route, "button": t, "toasts": toasts})
                cards = p.locator(".ai-card")
                if cards.count():
                    with contextlib.suppress(Exception):
                        cards.last.locator(".ai-card-actions").wait_for(timeout=25000)
                    feat = cards.last.get_attribute("data-feature")
                    disc = cards.last.get_by_role("button", name=re.compile(r"^\W*(Discard|Dismiss|Close)\W*$", re.IGNORECASE))
                    ok = False
                    if disc.count():
                        disc.first.click()
                        p.wait_for_timeout(600)
                        ok = p.locator(f".ai-card-result[data-feature={feat}]").count() == 0
                    res["ai_cards"][f"{route} · {t}"] = {"feature": feat, "dismissible": ok}
                sc = a.scan()
                if sc.get("spinners"):
                    p.wait_for_timeout(25000)
                    sc2 = a.scan()
                    if sc2.get("spinners"):
                        res.setdefault("stuck_spinners", []).append({"route": route, "button": t, "spinners": sc2["spinners"]})
                with contextlib.suppress(Exception):
                    p.keyboard.press("Escape")
            except Exception as exc:
                res.setdefault("click_errors", []).append({"route": route, "button": t, "error": str(exc)[:200]})
    # Empty states: a bare initiative + search miss
    a.cur = "empty states"
    with a.step("sweep_empty_new_initiative", full=True):
        a.go("#/initiative/new")
        p.get_by_label("Project Name").fill("Branch locator refresh")
        with contextlib.suppress(Exception):
            p.get_by_label("LOB").select_option("Canadian P&C")
            p.get_by_label("Priority").select_option(index=3)
            p.get_by_label("Requestor").select_option(index=2)
            p.get_by_label("Requested Go-live").fill("2027-03-20")
            p.get_by_label("Description of Change").fill("Refresh the branch locator in Online Banking and the mobile app.")
        a.btn("Save").click()
        p.wait_for_url(re.compile(r"#/initiative/\d+/pg1"))
        a.idle(1000)
        res["empty_id"] = int(re.search(r"#/initiative/(\d+)/", p.url).group(1))
    if res.get("empty_id"):
        for t in ("pg2", "pg3", "pg4", "pg5", "risks", "artifacts"):
            with a.step(f"sweep_empty_{t}", full=True):
                a.go(f"#/initiative/{res['empty_id']}/{t}", 1000)
                res["empty_states"][t] = p.locator("main, #app").first.inner_text()[:700]
    with a.step("sweep_search_miss", full=True):
        a.go("#/search")
        box = p.get_by_role("searchbox")
        if not box.count():
            box = p.locator("main input[type=search], main input[type=text]")
        box.first.fill("xyz")
        a.idle(800)
        res["empty_states"]["search"] = p.locator("main, #app").first.inner_text()[:500]
    with a.step("sweep_unknown_initiative", full=True):
        a.go("#/initiative/99999/pg1", 1000)
    with a.step("sweep_unknown_route", full=True):
        a.go("#/nope", 800)
    return res


# ------------------------------------------------------------------------------------------------- timezones
DATE_RX = re.compile(r"\b(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)?\s?\d{1,2} (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)(?: \d{4})?(?:, \d{1,2}:\d\d)?")


def tz_dates(browser, base_url, hero_id, tz):
    a = Audit(browser, base_url, tz, "1366", "tz_" + tz.split("/")[1].lower())
    out = {}
    try:
        for route in ["#/portfolio", f"#/initiative/{hero_id}/pg1", f"#/initiative/{hero_id}/pg2",
                      f"#/initiative/{hero_id}/pg4", "#/intake", "#/changes", "#/outbox"]:
            a.go(route, 1500)
            out[route] = DATE_RX.findall(a.page.locator("body").inner_text())
    finally:
        a.close()
    return out, a.events


# --------------------------------------------------------------------------------------------------- runner
def make_api(base_url):
    def api(method, path, body=None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(f"{base_url}/api{path}", data=data, method=method, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read() or b"null")
    return api


def run_all(base_url: str, out_json: Path, parts=("demo1366", "demo1920", "sweep", "tz")) -> dict:
    from playwright.sync_api import sync_playwright

    api = make_api(base_url)
    api("PUT", "/settings", {"ai_speed": "Fast"})
    report: dict = {"base_url": base_url, "runs": {}}
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        try:
            for tag, tz, vp in [("demo1366", "America/Toronto", "1366"), ("demo1920", "Pacific/Auckland", "1920")]:
                if f"demo{vp}" not in parts:
                    continue
                a = Audit(browser, base_url, tz, vp, tag)
                try:
                    facts = demo_walk(a, api)
                finally:
                    a.close()
                report["runs"][tag] = {"facts": facts, "steps": a.steps, "events": a.events}
                out_json.write_text(json.dumps(report, indent=1, default=str))
            if "sweep" in parts or "tz" in parts:
                # leave the hero in place (fast-forward through the API is fine for sweep set-up)
                api("POST", "/admin/reset", {})
                api("PUT", "/settings", {"ai_speed": "Fast", "persona": "DC PM"})
                ff = api("POST", "/admin/fast-forward-hero", {}) if True else {}
                hero_id = (ff or {}).get("initiative_id")
            if "sweep" in parts:
                for vp in ("1366", "1920"):
                    a = Audit(browser, base_url, "America/Toronto", vp, f"s{vp}")
                    try:
                        res = sweep(a, api, hero_id) if vp == "1366" else _light_sweep(a, hero_id)
                    finally:
                        a.close()
                    report["runs"][f"sweep{vp}"] = {"result": res, "steps": a.steps, "events": a.events}
                    out_json.write_text(json.dumps(report, indent=1, default=str))
            if "tz" in parts:
                tor, ev1 = tz_dates(browser, base_url, hero_id, "America/Toronto")
                akl, ev2 = tz_dates(browser, base_url, hero_id, "Pacific/Auckland")
                diffs = {r: {"toronto": tor[r], "auckland": akl[r]} for r in tor if tor[r] != akl.get(r)}
                report["runs"]["tz"] = {"diffs": diffs, "toronto": tor, "events": ev1 + ev2}
        finally:
            browser.close()
    out_json.write_text(json.dumps(report, indent=1, default=str))
    return report


def _light_sweep(a: Audit, hero_id):
    """1920 pass: screenshot every route and tab, scan layout (no clicking)."""
    targets = list(ROUTES) + [f"#/initiative/{hero_id}/{t}" for t in TABS]
    for route in targets:
        a.cur = "sweep " + route
        a.go(route, 1500)
        a.page.wait_for_timeout(1500)
        a.shot("sweep_" + re.sub(r"[^a-z0-9]+", "_", route.lower()).strip("_"), full=True)
    return {}


# ------------------------------------------------------------------------------------------------- pytest
EXPECTED_HTTP = re.compile(r"/api/initiatives/99999|/api/.*/99999")


def _hard_failures(report):
    fails = []
    for tag, run in report["runs"].items():
        for s in run.get("steps", []):
            if not s["ok"]:
                fails.append(f"{tag} step {s['step']}: {s['error']}")
            if s["copy"]["bad_text"]:
                fails.append(f"{tag} {s['step']}: bad text {s['copy']['bad_text'][:3]}")
            if s.get("overflowX"):
                fails.append(f"{tag} {s['step']}: horizontal page overflow {s['overflowX']} px")
        for e in run.get("events", []):
            if e["kind"] in ("pageerror", "console.error") or (e["kind"].startswith("http5")):
                if not EXPECTED_HTTP.search(e["text"]):
                    fails.append(f"{tag} [{e['step']}] {e['kind']}: {e['text'][:200]}")
    # demo-script beats (PO §1 / master plan §6.2) that must hold
    for tag in ("demo1366", "demo1920"):
        f = report["runs"].get(tag, {}).get("facts", {})
        if not f:
            continue
        if f.get("after_undo_body") is False:
            fails.append(f"{tag}: Undo after the WBS-210 +5 bd edit did not restore Readiness 17 Feb 2027 (QA-C-01)")
        if "Sana Whitfield" not in (f.get("toast") or ""):
            fails.append(f"{tag}: grooming toast does not name the DC SA Sana Whitfield (QA-C-02): {f.get('toast')!r}")
        why = f.get("why_red_before_fix") or ""
        if "17 business days" in why:
            fails.append(f"{tag}: assistant states 17 business days of readiness float while Schedule is Red (QA-C-03)")
    if report["runs"].get("tz", {}).get("diffs"):
        fails.append(f"timezone date drift: {list(report['runs']['tz']['diffs'])}")
    return fails


SERVER_BOOT_TIMEOUT = 40          # s: server must answer /api/health by then
AUDIT_TIMEOUT = int(os.environ.get("QA_C_TIMEOUT", "1800"))   # s: hard cap on the browser run
DEFAULT_PYTEST_PARTS = "demo1366,demo1920,tz"                # add ",sweep" via QA_C_PARTS for the full sweep (~15 min)


def _stop(proc: subprocess.Popen | None) -> None:
    if proc is None or proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(10)
    except subprocess.TimeoutExpired:
        proc.kill()
        with contextlib.suppress(subprocess.TimeoutExpired):
            proc.wait(5)


def _start_server(tmp: Path) -> tuple[subprocess.Popen, str]:
    """Own server on a free port with its own DB + uploads; raises (after killing it) if it never comes up."""
    port = free_port()
    env = {**os.environ, "BMO_DB_PATH": str(tmp / "qa.db"), "BMO_UPLOAD_DIR": str(tmp / "uploads"), "BMO_PORT": str(port),
           "BMO_TODAY": "2026-10-19", "BMO_AI_MODE": "simulated", "PYTHONUNBUFFERED": "1"}
    env.pop("ANTHROPIC_API_KEY", None)
    subprocess.run([PYTHON, "-m", "app.cli", "reset"], cwd=ROOT, env=env, check=True, capture_output=True, timeout=120)
    log = (tmp / "server.log").open("w")
    # Launched via -c (not "app.cli run") so a teammate's `pkill -f "app.cli run"` cleanup cannot kill this audit's server.
    code = ("import sys; sys.argv[0] = 'qa_c_audit_server'; from app import create_app; "
            f"create_app().run(host='127.0.0.1', port={port}, debug=False, threaded=True, use_reloader=False)")
    proc = subprocess.Popen([PYTHON, "-c", code], cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                            stdin=subprocess.DEVNULL)
    base = f"http://127.0.0.1:{port}"
    deadline = time.time() + SERVER_BOOT_TIMEOUT
    while time.time() < deadline:
        if proc.poll() is not None:
            break
        try:
            with urllib.request.urlopen(base + "/api/health", timeout=2):
                return proc, base
        except OSError:
            time.sleep(0.3)
    _stop(proc)
    raise RuntimeError(f"QA-C server did not start within {SERVER_BOOT_TIMEOUT}s; see {tmp / 'server.log'}")


def test_e2e_audit(tmp_path):
    """Runs the audit in a *separate Python process* so Playwright's sync API never shares an event loop (or a
    browser) with tests/e2e or any other test in the session; the server and the browser run are both time-boxed."""
    pytest.importorskip("playwright")
    proc, base = _start_server(tmp_path)
    out = tmp_path / "qa_c_report.json"
    parts = os.environ.get("QA_C_PARTS", DEFAULT_PYTEST_PARTS)
    try:
        run = subprocess.run(check=False, args=[PYTHON, "-I", str(Path(__file__).resolve()), "--base-url", base, "--parts", parts, "--out", str(out)],
                             cwd=ROOT, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=AUDIT_TIMEOUT,
                             env={**os.environ, "QA_C_SHOTS": os.environ.get("QA_C_SHOTS") or str(tmp_path / "shots")})
    except subprocess.TimeoutExpired:
        pytest.fail(f"QA-C audit exceeded {AUDIT_TIMEOUT}s and was killed")
    finally:
        _stop(proc)
    if not out.exists():
        pytest.fail(f"QA-C audit produced no report (exit {run.returncode}):\n{run.stdout[-2000:]}\n{run.stderr[-3000:]}")
    fails = _hard_failures(json.loads(out.read_text()))
    assert not fails, "\n".join(fails[:60])


if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://127.0.0.1:5091")
    ap.add_argument("--parts", default="demo1366,demo1920,sweep,tz")
    ap.add_argument("--out", default=str(SHOTS / "qa_c_report.json"))
    ns = ap.parse_args()
    SHOTS.mkdir(parents=True, exist_ok=True)
    rep = run_all(ns.base_url, Path(ns.out), tuple(ns.parts.split(",")))
    for f in _hard_failures(rep):
        print("FAIL", f)
