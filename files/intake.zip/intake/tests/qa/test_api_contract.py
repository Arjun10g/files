"""QA-A · Line of Defense L2 · independent API contract tests.

Written by QA (not a builder). Expected values come from docs/00_MASTER_PLAN.md §1/§6 and docs/contracts.md, never
from the code under test. A failing test here is a finding; see docs/qa/round1_QA-A_api.md.

Sections
  1. Meta: every /api rule is referenced by some test source, and the route table below covers every rule+method
     with at least one happy-path and one bad-input case.
  2. Route table: happy + bad per route, with response-shape checks against contracts.md.
  3. Sweeps: unknown id -> 404 JSON, malformed JSON -> 400, wrong types -> never 500.
  4. Hero end-to-end via the API only (simulated AI).
  5. Robustness: SQLi, XSS, uploads, cycles, end<start, concurrent apply, live-AI fallback.
  6. Determinism of the simulated AI tier.
"""
from __future__ import annotations

import glob
import hashlib
import io
import json
import os
import re
import sqlite3
import subprocess
import sys
import threading
import time
import types
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, ClassVar

import pytest

ROOT = Path(__file__).resolve().parents[2]
TESTS = ROOT / "tests"
SEED_FILES = ROOT / "app" / "seed" / "files"
HERO_DOCX = SEED_FILES / "SA_US_API_Enhancement_v1.2.docx"
HERO_PDF = SEED_FILES / "SA_US_API_Enhancement_v1.2.pdf"
HERO_MD = SEED_FILES / "SA_US_API_Enhancement_v1.2.md"

ISO_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
ISO_DT_OFFSET = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?[+-]\d{2}:\d{2}$")
MONTH = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")
RAGS = {"Red", "Amber", "Green"}
DIMS = ("schedule", "resources", "scope", "dependencies", "budget")
# Round 2 (coordinator-confirmed intended change): new mode_label wording.
MODES = {"simulated_fixture": "Simulated AI · prepared response", "simulated_generated": "Simulated AI · rules engine",
         "live": "Live Claude", "live_fallback": "Live → Simulated"}
XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


# ===================================================================== helpers
def _fail(detail) -> None:
    pytest.fail(detail if isinstance(detail, str) else repr(detail)[:600])


def has_keys(obj: Any, keys, where: str = "") -> None:
    assert isinstance(obj, dict), f"{where}: expected an object, got {type(obj).__name__}"
    missing = set(keys) - set(obj)
    assert not missing, f"{where}: missing keys {sorted(missing)}"


def check_list(j: Any, item_keys=(), where: str = "", nonempty: bool = False, exact_total: bool = True) -> list:
    has_keys(j, {"items", "total"}, where)
    assert isinstance(j["items"], list), f"{where}: items is not a list"
    assert isinstance(j["total"], int), f"{where}: total is not an int"
    if exact_total:
        assert j["total"] == len(j["items"]), f"{where}: total {j['total']} != len(items) {len(j['items'])}"
    if nonempty:
        assert j["items"], f"{where}: expected at least one item"
    for item in j["items"][:5]:
        has_keys(item, item_keys, f"{where} item")
    return j["items"]


def assert_error(resp, status: int, code: str | None = None) -> dict:
    """Contract §0: errors are always {"error":{code,message,details}} JSON, never HTML."""
    assert resp.status_code == status, f"expected {status}, got {resp.status_code}: {resp.get_data(as_text=True)[:300]}"
    assert resp.content_type.startswith("application/json"), f"error is not JSON: {resp.content_type}"
    body = resp.get_json()
    has_keys(body, {"error"}, "error body")
    has_keys(body["error"], {"code", "message", "details"}, "error")
    assert isinstance(body["error"]["message"], str) and body["error"]["message"]
    assert isinstance(body["error"]["details"], dict)
    if code:
        assert body["error"]["code"] == code, body
    if body["error"]["code"] == "validation":
        assert isinstance(body["error"]["details"].get("fields"), dict), body
    return body


def check_airun(j: dict, feature: str | None = None) -> None:
    has_keys(j, {"ai_run_id", "feature", "initiative_id", "scope", "mode", "mode_label", "model", "variant_index",
                 "confidence", "sources", "warnings", "output", "status", "latency_ms", "minutes_saved", "regen_of",
                 "created_at"}, "AiRun")
    assert j["mode"] in MODES, j["mode"]
    if j["feature"] == "cr_compliance":  # Round 3 N10: rules output is labelled "Rules check" and deterministic
        assert j["mode_label"] == "Rules check" and j.get("deterministic") is True, (j["mode_label"], j.get("deterministic"))
    else:
        assert j["mode_label"] == MODES[j["mode"]]
    assert j["status"] == "generated"
    assert j["scope"] in ("initiative", "portfolio", "draft")
    assert 0 <= j["confidence"] <= 1
    assert isinstance(j["sources"], list) and isinstance(j["warnings"], list) and isinstance(j["output"], dict)
    assert ISO_DT_OFFSET.match(j["created_at"]), j["created_at"]
    if feature:
        assert j["feature"] == feature


def check_health(j: dict, scored: bool | None = None) -> None:
    has_keys(j, {"scored", "overall", "dimensions", "attention", "as_of"}, "Health")
    assert set(DIMS) <= set(j["dimensions"]), j["dimensions"].keys()
    for d in DIMS:
        has_keys(j["dimensions"][d], {"rag", "reasons", "metrics", "overridden"}, f"Health.{d}")
        assert isinstance(j["dimensions"][d]["reasons"], list)
        assert isinstance(j["dimensions"][d]["overridden"], bool)
    assert isinstance(j["attention"], list)
    if j["scored"]:
        assert j["overall"] in RAGS
    else:
        assert j["overall"] is None
    if scored is not None:
        assert j["scored"] is scored


def check_gantt(j: dict) -> None:
    has_keys(j, {"start", "end", "today", "freeze", "trains", "readiness_date", "qa_date", "prod_date", "float_bd",
                 "critical_path", "tasks"}, "Gantt")
    has_keys(j["freeze"], {"start", "end"}, "Gantt.freeze")
    for t in j["tasks"][:5]:
        has_keys(t, {"id", "wbs_code", "parent_id", "step", "phase", "resource_name", "planned_start", "planned_end",
                     "baseline_start", "baseline_end", "pct", "status", "is_milestone", "is_summary", "critical",
                     "float_bd", "depends_on"}, "Gantt.task")
        assert isinstance(t["critical"], bool) and isinstance(t["depends_on"], list)
    ids = {t["id"] for t in j["tasks"]}
    assert set(j["critical_path"]) <= ids, "critical_path references unknown task ids"


def check_capacity(j: dict) -> None:
    has_keys(j, {"months", "rows", "teams"}, "Capacity")
    assert all(MONTH.match(m) for m in j["months"])
    for r in j["rows"][:5]:
        has_keys(r, {"key", "label", "team", "cells"}, "Capacity.row")
        for cell in r["cells"][:3]:
            has_keys(cell, {"month", "available", "confirmed", "tentative", "util", "band"}, "Capacity.cell")
            assert cell["band"] in ("spare", "ok", "stretched", "over")
    for t in j["teams"][:5]:
        has_keys(t, {"team", "available", "confirmed", "tentative", "util", "band"}, "Capacity.team")


def check_burndown(j: dict) -> None:
    has_keys(j, {"prn_code", "funded_hours", "months", "charged_cum", "forecast_cum", "funded_line", "exhaust_month",
                 "status"}, "Burndown")
    assert j["status"] in ("on_track", "at_risk", "overrun")


L2_KEYS = {"dev_hours", "architecture_hours", "qa_hours", "pm_release_hours", "subtotal", "contingency_hours",
           "total_hours", "low_hours", "high_hours", "tshirt", "by_component", "rule"}


def check_l2(j: dict) -> None:
    has_keys(j, L2_KEYS, "L2Estimate")
    assert j["tshirt"] in ("XS", "S", "M", "L", "XL")
    for c in j["by_component"][:5]:
        has_keys(c, {"code", "name", "complexity", "hours"}, "L2.by_component")


def check_bundle(j: dict) -> None:
    has_keys(j, {"initiative", "components", "tasks", "allocations", "resources", "risks", "change_requests", "prn",
                 "attachments", "grooming", "scope_changes", "target_train", "component_catalog", "sa_doc_text",
                 "today", "now"}, "Bundle")
    has_keys(j["initiative"], {"id", "rddc", "name", "requestor_name", "assigned_to_name", "pm_name", "tech_lead_name",
                               "dc_pm_name", "dc_sa_name"}, "Bundle.initiative")
    assert isinstance(j["initiative"]["labels"], list), "labels must be returned parsed"
    for t in j["tasks"][:3]:
        has_keys(t, {"owner_name", "resource_name", "component_code", "depends_on", "depends_on_codes"}, "Bundle.task")
    for a in j["allocations"][:3]:
        has_keys(a, {"resource_id", "task_id", "month", "hours", "firmness"}, "Bundle.allocation")
    for r in j["resources"][:3]:
        has_keys(r, {"id", "name", "role", "team", "team_label", "component_id", "capacity_eligible",
                     "default_monthly_hours", "availability", "committed", "skills"}, "Bundle.resource")
    for cr in j["change_requests"][:3]:
        has_keys(cr, {"compliance"}, "Bundle.change_request")
    for c in j["component_catalog"][:3]:
        assert isinstance(c["keywords"], list) and isinstance(c["downstream"], list)
    assert ISO_DATE.match(j["today"]) and ISO_DT_OFFSET.match(j["now"]), (j["today"], j["now"])


def check_cr(j: dict) -> None:
    has_keys(j, {"id", "initiative_id", "crq_number", "crq_start", "crq_end", "release_type", "sto_approval",
                 "affected_cis", "impacted_components", "compliance"}, "ChangeRequest")
    has_keys(j["compliance"], {"ok", "flags"}, "ChangeRequest.compliance")
    assert isinstance(j["affected_cis"], list) and isinstance(j["impacted_components"], list)
    for f in j["compliance"]["flags"]:
        has_keys(f, {"code", "message"}, "compliance.flag")


def table_counts(db_path: str) -> dict:
    con = sqlite3.connect(db_path)
    try:
        names = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' "
                                           "AND name NOT LIKE 'sqlite_%'")]
        return {n: con.execute(f'SELECT COUNT(*) FROM "{n}"').fetchone()[0] for n in names}
    finally:
        con.close()


def queued_notification_id(c) -> int:
    return c.get("/api/outbox?status=Queued").get_json()["items"][0]["id"]


def resource_ids(c) -> dict:
    return {r["name"]: r["id"] for r in c.get("/api/resources?active=all").get_json()["items"]}


def create_plain_initiative(c, name="QA Card Controls Refresh") -> int:
    resp = c.post("/api/initiatives", json={"name": name, "lob": "US P&C", "priority": 2,
                                            "requestor": "Clara Pemberton"})
    assert resp.status_code == 201, resp.get_json()
    return resp.get_json()["initiative"]["id"]


# ===================================================================== 2. route table
@dataclass
class Case:
    route: tuple[str, str]                 # (METHOD, url_map rule) this case covers
    kind: str                              # happy | bad
    status: int
    path: str                              # str.format(**ctx)
    method: str | None = None              # request method when it differs from the route (405 cases)
    body: Any = None                       # dict or callable(ctx) -> dict
    raw: str | None = None                 # raw JSON text
    files: Callable | None = None          # callable(ctx) -> multipart dict
    prep: Callable | None = None           # callable(client, ctx)
    check: Callable | None = None          # callable(json, ctx)
    code: str | None = None                # expected error code for bad cases
    note: str = ""

    @property
    def id(self) -> str:
        return f"{self.kind}:{self.route[0]} {self.route[1]}{(' ' + self.note) if self.note else ''}"


def build_ctx(c) -> dict:
    lk = c.get("/api/lookups").get_json()
    tasks = c.get("/api/initiatives/4/tasks").get_json()["items"]
    ctx = {
        "_client": c, "lk": lk, "iid": 4, "rid": 14, "cid": 4,
        "tid": next(t["id"] for t in tasks if (t.get("est_hours") or 0) > 0),
        "icid": c.get("/api/initiatives/4/components").get_json()["items"][0]["id"],
        "risk_id": c.get("/api/risks").get_json()["items"][0]["id"],
        "nid": queued_notification_id(c),
        "decisions_id": c.get("/api/decisions").get_json()["items"][0]["id"],
        "lessons_id": c.get("/api/lessons").get_json()["items"][0]["id"],
        "meeting-notes_id": c.get("/api/meeting-notes").get_json()["items"][0]["id"],
        "documents_id": c.get("/api/documents").get_json()["items"][0]["id"],
    }
    sessions = c.get("/api/grooming/sessions?from=2026-10-19&to=2026-10-31").get_json()["items"]
    ctx["session_id"] = next(s["id"] for s in sessions if any(sl["initiative_id"] == 8 for sl in s["slots"]))
    return ctx


def p_run(feature_slug: str, iid: int = 4):
    def prep(c, ctx):
        r = c.post(f"/api/initiatives/{iid}/ai/{feature_slug}", json={})
        assert r.status_code == 200, r.get_json()
        ctx["run_id"] = r.get_json()["ai_run_id"]
    return prep


def p_new_initiative(c, ctx):
    ctx["new_iid"] = create_plain_initiative(c)


def p_manual_alloc(c, ctx):
    r = c.post("/api/allocations", json={"resource_id": 15, "initiative_id": 4, "month": "2027-03", "hours": 12.5})
    assert r.status_code == 201, r.get_json()
    ctx["alloc_id"] = r.get_json()["id"]


def p_derived_alloc(c, ctx):
    ctx["derived_alloc_id"] = c.get("/api/allocations?initiative_id=4").get_json()["items"][0]["id"]


def p_upload(c, ctx):
    ctx["upload_bytes"] = b"# QA notes\n\nUploaded by QA-A for the download round trip.\n"
    r = c.post("/api/initiatives/4/attachments", data={"file": (io.BytesIO(ctx["upload_bytes"]), "qa_notes.md"),
                                                        "kind": "other"}, content_type="multipart/form-data")
    assert r.status_code == 201, r.get_json()
    ctx["aid"] = r.get_json()["attachment"]["id"]


def p_new_task(c, ctx):
    r = c.post("/api/initiatives/4/tasks", json={"wbs_code": "WBS-955", "step": "QA scratch step",
                                                 "planned_start": "2026-11-02", "planned_end": "2026-11-03"})
    assert r.status_code == 201, r.get_json()
    ctx["new_tid"] = r.get_json()["task"]["id"]


def p_new_cr(c, ctx):
    r = c.post("/api/initiatives/5/change-requests", json={"release_type": "Independent"})
    assert r.status_code == 201, r.get_json()
    ctx["new_cid"] = r.get_json()["id"]


def p_new_risk(c, ctx):
    r = c.post("/api/initiatives/4/risks", json={"title": "QA scratch risk", "category": "Technical", "severity": 2,
                                                 "likelihood": 2})
    assert r.status_code == 201, r.get_json()
    ctx["new_risk_id"] = r.get_json()["id"]


def p_new_component(c, ctx):
    iid = create_plain_initiative(c)
    r = c.post(f"/api/initiatives/{iid}/components", json={"component_id": 1})
    assert r.status_code == 201, r.get_json()
    ctx["new_icid"] = r.get_json()["id"]


def p_l2_ready(c, ctx):
    iid = create_plain_initiative(c, "QA Wire Limits Uplift")
    assert c.post(f"/api/initiatives/{iid}/sa-text", json={"text": HERO_MD.read_text(encoding="utf-8")}).status_code == 201
    assert c.post(f"/api/initiatives/{iid}/components", json={"component_id": 1, "complexity": "Low"}).status_code == 201
    ctx["l2_iid"] = iid


def p_chat(c, ctx):
    r = c.post("/api/assistant/chat", json={"message": "Which projects are red?"})
    assert r.status_code == 200, r.get_json()
    ctx["conv_id"] = r.get_json()["conversation_id"]


def k_ok(j, ctx):
    assert j == {"ok": True} or j.get("ok") is True


def k_settings(j, ctx):
    has_keys(j, {"ai_mode", "ai_speed", "demo_today", "persona", "live_available", "model_heavy", "model_fast"}, "settings")
    assert j["ai_mode"] in ("auto", "simulated", "live") and j["ai_speed"] in ("Realistic", "Fast")
    assert ISO_DATE.match(j["demo_today"])


def k_lookups(j, ctx):
    cats = ["stage", "status", "l2_status", "approval", "complexity", "task_status", "phase", "priority", "lob",
            "release_type", "sto_approval", "validation_status", "implementation_status", "crq_approval_status", "rag",
            "risk_category", "risk_severity", "risk_likelihood", "risk_status", "l2_tshirt", "attachment_kind",
            "doc_type", "notification_status", "grooming_slot_status", "ai_mode", "ai_speed", "persona", "skill_level"]
    has_keys(j, cats + ["components", "resources", "release_trains", "fiscal_quarters", "freeze", "holidays"], "lookups")
    for cat in cats:
        assert j[cat] and all(set(o) == {"value", "label"} for o in j[cat]), cat
    for cat in ("priority", "risk_severity", "risk_likelihood", "skill_level"):
        assert all(isinstance(o["value"], int) for o in j[cat]), f"{cat} values must be integers"
    assert [o["value"] for o in j["complexity"]] == ["Low", "Medium", "High"]
    has_keys(j["components"][0], {"id", "code", "name", "team", "component_lead_id", "component_lead_name"})
    has_keys(j["resources"][0], {"id", "name", "role", "team", "team_label", "capacity_eligible"})
    assert [q["label"] for q in j["fiscal_quarters"]] == ["Nov–Jan", "Feb–Apr", "May–Jul", "Aug–Oct"]
    assert all(q["fy"] == "FY27" for q in j["fiscal_quarters"])


def k_initiative_row(j, ctx):
    has_keys(j, {"id", "rddc", "name", "lob", "stage", "status", "priority", "labels"}, "initiative")
    assert isinstance(j["labels"], list)


def k_component_row(j, ctx):
    has_keys(j, {"id", "initiative_id", "component_id", "approval", "complexity", "est_hours", "code", "name",
                 "component_lead_name"}, "initiative component")
    assert j["complexity"] in ("Low", "Medium", "High")


def k_task_write(j, ctx):
    has_keys(j, {"task", "shifted_tasks", "health"}, "task write")
    assert isinstance(j["shifted_tasks"], list)
    for s in j["shifted_tasks"]:
        has_keys(s, {"id", "wbs_code", "planned_start", "planned_end"})


def k_resource_row(j, ctx):
    has_keys(j, {"id", "name", "role", "team", "skills", "current_load"}, "resource")
    assert isinstance(j["skills"], list)
    for s in j["skills"][:3]:
        has_keys(s, {"skill", "level"})


def k_risk_row(j, ctx):
    has_keys(j, {"id", "risk_code", "initiative_id", "title", "category", "severity", "likelihood", "status"}, "risk")
    assert re.match(r"^RSK-\d{3,}$", j["risk_code"]), j["risk_code"]
    assert 1 <= j["severity"] <= 4 and 1 <= j["likelihood"] <= 4


def k_notification(status):
    def check(j, ctx):
        has_keys(j, {"id", "status", "subject"}, "notification")
        assert j["status"] == status
    return check


def k_session(j, ctx):
    has_keys(j, {"id", "session_date", "start_time", "capacity", "status", "slots"}, "grooming session")
    for s in j["slots"][:3]:
        has_keys(s, {"initiative_id", "rddc", "name", "priority", "slot_order", "status", "recipients"}, "slot")
        for p in s["recipients"]:
            has_keys(p, {"id", "name"})


def k_artifact(kind):
    def check(j, ctx):
        if "items" in j:
            check_list(j, {"id", "rddc"}, f"/api/{kind}")
        else:
            has_keys(j, {"id", "rddc"}, kind)
    return check


def k_apply(j, ctx):
    has_keys(j, {"ai_run_id", "status", "initiative_id", "applied", "minutes_saved"}, "apply")
    assert j["status"] == "accepted" and j["ai_run_id"] == ctx["run_id"]
    assert isinstance(j["applied"], dict) and all(isinstance(v, int) for v in j["applied"].values())


def k_regen(j, ctx):
    check_airun(j)
    assert j["regen_of"] == ctx["run_id"]
    prev = ctx["_client"].get(f"/api/ai-runs/{ctx['run_id']}").get_json()
    assert prev["status"] == "superseded", prev["status"]


def k_chat(j, ctx):
    has_keys(j, {"conversation_id", "answer_md", "citations", "suggested_actions", "follow_ups", "ai_run_id", "mode",
                 "mode_label"}, "chat")
    assert j["mode"] in MODES and j["mode_label"] == MODES[j["mode"]]
    for cit in j["citations"]:
        has_keys(cit, {"type", "id", "label", "route"}, "citation")
    for a in j["suggested_actions"]:
        has_keys(a, {"label"}, "suggested_action")
    assert all(isinstance(f, str) for f in j["follow_ups"])


def k_portfolio(j, ctx):
    has_keys(j, {"kpis", "projects", "change_mgmt", "capacity_teams"}, "portfolio")
    has_keys(j["kpis"], {"active", "red", "amber", "green", "crqs_this_week", "overallocated_people"}, "kpis")
    for p in j["projects"][:3]:
        has_keys(p, {"id", "rddc", "name", "lob", "dc_pm_name", "stage", "rag", "dimensions", "target_release",
                     "readiness_date", "qa_signoff_date", "prod_date", "comments"}, "portfolio.project")
    for cm in j["change_mgmt"][:3]:
        has_keys(cm, {"initiative_id", "rddc", "crq_number", "release_train", "cms_lead_name", "rel_lead_name",
                      "resource_name", "implementation_status", "tech_validation_status", "biz_validation_status",
                      "sto_approval", "compliance_flags"}, "portfolio.change_mgmt")
    for t in j["capacity_teams"][:3]:
        has_keys(t, {"team", "available", "confirmed", "tentative", "util"}, "portfolio.capacity_team")


def k_xlsx(sheets):
    def check(resp, ctx):
        import openpyxl
        assert resp.content_type.startswith(XLSX_MIME), resp.content_type
        wb = openpyxl.load_workbook(io.BytesIO(resp.data))
        missing = set(sheets) - set(wb.sheetnames)
        assert not missing, f"missing sheets {missing}; have {wb.sheetnames}"
    return check


INIT_FEATURE_IID = {"intake-analysis": 8, "change-summary": 7, "l2-estimate": 6, "wbs": 5, "resources": 4,
                    "rebalance": 5, "risks": 4, "exec-summary": 2, "cr-compliance": 4}
GLOBAL_FEATURE_BODY = {
    "intake-analysis": {"options": {"name": "Commercial cash sweep alerts", "description": "Real-time sweep alerts for "
                                    "commercial clients in Online Banking.", "lob": "Commercial Banking"}},
    "intake-autofill": {"options": {"text": "Solution Architecture: Wire Limits\nVersion 0.4 · Author: Sana Whitfield\n"
                                    "1. Business context\nRaise wire limits for US commercial clients via API Platform."}},
    "skill-matrix": {}, "exec-summary": {}, "nudges": {},
    "meeting-extract": {"options": {"meeting_note_id": 1}},
    "lessons": {"options": {"initiative_id": 1}},
}

ART = "/api/<any(decisions, lessons, 'meeting-notes', documents):kind>"
ART_ID = ART + "/<int:row_id>"
ART_BODIES = {"decisions": {"title": "QA decision", "decision": "Proceed with DC-2702."},
              "lessons": {"lesson": "Book CIAM reviewers before L2 approval."},
              "meeting-notes": {"title": "QA sync", "attendees": ["Grace Ellingham"]},
              "documents": {"doc_type": "Runbook", "title": "QA runbook"}}
ART_MISSING = {"decisions": {"title": "No decision text"}, "lessons": {"category": "Process"},
               "meeting-notes": {"notes_md": "no title"}, "documents": {"title": "No type"}}

CASES: list[Case] = [
    # ---------------------------------------------------------------- core
    Case(("GET", "/api/health"), "happy", 200, "/api/health", check=lambda j, c: (
        has_keys(j, {"status", "db", "ai_mode", "model", "today", "version", "modules"}),
        j["ai_mode"] in ("simulated", "live") or _fail(j["ai_mode"]))),
    Case(("GET", "/api/health"), "bad", 405, "/api/health", method="DELETE", code="method_not_allowed"),
    Case(("GET", "/api/lookups"), "happy", 200, "/api/lookups", check=k_lookups),
    Case(("GET", "/api/lookups"), "bad", 405, "/api/lookups", method="POST", body={}, code="method_not_allowed"),
    Case(("GET", "/api/settings"), "happy", 200, "/api/settings", check=k_settings),
    Case(("GET", "/api/settings"), "bad", 405, "/api/settings", method="DELETE"),
    Case(("PUT", "/api/settings"), "happy", 200, "/api/settings", body={"persona": "Dev Lead"},
         check=lambda j, c: (k_settings(j, c), j["persona"] == "Dev Lead" or _fail(j))),
    Case(("PUT", "/api/settings"), "bad", 422, "/api/settings", body={"ai_speed": "Ludicrous"}, code="validation"),
    Case(("POST", "/api/admin/reset"), "happy", 200, "/api/admin/reset",
         check=lambda j, c: (has_keys(j, {"ok", "counts"}),
                             # R2 decision 12: counts are raw table counts (8 seeded + hidden BAU-FY27 id -1)
                             j["counts"]["initiatives"] == 9 or _fail(j),
                             c["_client"].get("/api/initiatives").get_json()["total"] == 8 or _fail("BAU visible"))),
    Case(("POST", "/api/admin/reset"), "bad", 405, "/api/admin/reset", method="GET"),
    Case(("POST", "/api/admin/fast-forward-hero"), "happy", 200, "/api/admin/fast-forward-hero",
         check=lambda j, c: (has_keys(j, {"initiative_id", "rddc", "steps"}), j["rddc"] == "RDDC-24817" or _fail(j),
                             all(s["ok"] for s in j["steps"]) or _fail(j["steps"]),
                             [has_keys(s, {"step", "ok"}) for s in j["steps"]])),
    Case(("POST", "/api/admin/fast-forward-hero"), "bad", 405, "/api/admin/fast-forward-hero", method="GET"),
    Case(("GET", "/api/activity"), "happy", 200, "/api/activity?limit=5", check=lambda j, c: check_list(
        j, {"id", "ts", "actor", "persona", "entity_type", "entity_id", "initiative_id", "action", "detail_json",
            "summary"}, "activity")),
    Case(("GET", "/api/activity"), "bad", 422, "/api/activity?limit=abc", code="validation"),
    Case(("GET", "/api/release-trains"), "happy", 200, "/api/release-trains", check=lambda j, c: (
        check_list(j, {"code", "train_date", "status", "in_freeze", "initiatives"}, "release-trains", nonempty=True),
        j["freeze"] == {"start": "2026-12-14", "end": "2027-01-08"} or _fail(j["freeze"]),
        isinstance(j["holidays"], list) or _fail("holidays"))),
    Case(("GET", "/api/release-trains"), "bad", 405, "/api/release-trains", method="POST", body={}),
    Case(("GET", "/api/dc-intakes"), "happy", 200, "/api/dc-intakes?q=DCI",
         check=lambda j, c: check_list(j, {"code", "name", "lob", "requestor", "priority"}, "dc-intakes", nonempty=True)),
    Case(("GET", "/api/dc-intakes"), "bad", 405, "/api/dc-intakes", method="POST", body={}),
    Case(("GET", "/api/dc-intakes/<code>"), "happy", 200, "/api/dc-intakes/DCI-3391", check=lambda j, c: (
        has_keys(j, {"code", "name", "lob", "requestor", "priority", "requested_go_live", "description", "initiative_id"}),
        j["name"] == "US API Enhancement" or _fail(j))),
    Case(("GET", "/api/dc-intakes/<code>"), "bad", 404, "/api/dc-intakes/DCI-0000", code="not_found"),
    # ---------------------------------------------------------------- initiatives
    Case(("GET", "/api/initiatives"), "happy", 200, "/api/initiatives", check=lambda j, c: check_list(
        j, {"id", "rddc", "name", "lob", "stage", "status", "priority", "dc_pm_name", "dc_sa_name", "rag",
            "target_release", "readiness_date", "planned_end"}, "initiatives", nonempty=True)),
    Case(("GET", "/api/initiatives"), "bad", 422, "/api/initiatives?dc_pm_id=abc", code="validation",
         note="non-numeric dc_pm_id filter"),
    Case(("POST", "/api/initiatives"), "happy", 201, "/api/initiatives",
         body={"name": "QA Card Controls Refresh", "lob": "US P&C", "priority": 3, "requestor": "Clara Pemberton"},
         check=lambda j, c: (has_keys(j, {"initiative", "grooming", "queued_notifications"}),
                             re.match(r"^RDDC-\d{5}$", j["initiative"]["rddc"]) or _fail(j))),
    Case(("POST", "/api/initiatives"), "bad", 422, "/api/initiatives",
         body={"lob": "US P&C", "priority": 3, "requestor": "Clara Pemberton"}, code="validation", note="missing name"),
    Case(("GET", "/api/initiatives/<int:iid>"), "happy", 200, "/api/initiatives/{iid}",
         check=lambda j, c: check_bundle(j)),
    Case(("GET", "/api/initiatives/<int:iid>"), "bad", 404, "/api/initiatives/999999", code="not_found"),
    Case(("PUT", "/api/initiatives/<int:iid>"), "happy", 200, "/api/initiatives/{iid}",
         body={"comments": "QA: reviewed"}, check=lambda j, c: (k_initiative_row(j, c),
                                                               j["comments"] == "QA: reviewed" or _fail(j))),
    Case(("PUT", "/api/initiatives/<int:iid>"), "bad", 422, "/api/initiatives/{iid}", body={"stage": "Nope"},
         code="validation"),
    Case(("DELETE", "/api/initiatives/<int:iid>"), "happy", 200, "/api/initiatives/{new_iid}", prep=p_new_initiative,
         check=lambda j, c: (k_ok(j, c), c["_client"].get(f"/api/initiatives/{c['new_iid']}").status_code == 404
                             or _fail("deleted initiative still readable"))),
    Case(("DELETE", "/api/initiatives/<int:iid>"), "bad", 404, "/api/initiatives/999999", code="not_found"),
    Case(("GET", "/api/initiatives/<int:iid>/components"), "happy", 200, "/api/initiatives/{iid}/components",
         check=lambda j, c: [k_component_row(x, c) for x in check_list(j, (), "components", nonempty=True)]),
    Case(("GET", "/api/initiatives/<int:iid>/components"), "bad", 404, "/api/initiatives/999999/components"),
    Case(("POST", "/api/initiatives/<int:iid>/components"), "happy", 201, "/api/initiatives/8/components",
         body={"component_id": 1, "complexity": "Low"}, check=k_component_row),
    Case(("POST", "/api/initiatives/<int:iid>/components"), "bad", 422, "/api/initiatives/8/components",
         body={"component_id": 1, "complexity": "Huge"}, code="validation", note="invalid complexity enum"),
    Case(("PUT", "/api/initiative-components/<int:icid>"), "happy", 200, "/api/initiative-components/{icid}",
         body={"change_summary": "QA wording"}, check=k_component_row),
    Case(("PUT", "/api/initiative-components/<int:icid>"), "bad", 404, "/api/initiative-components/999999",
         body={"approval": "Approved"}),
    Case(("DELETE", "/api/initiative-components/<int:icid>"), "happy", 200, "/api/initiative-components/{new_icid}",
         prep=p_new_component, check=k_ok),
    Case(("DELETE", "/api/initiative-components/<int:icid>"), "bad", 404, "/api/initiative-components/999999"),
    Case(("GET", "/api/initiatives/<int:iid>/attachments"), "happy", 200, "/api/initiatives/{iid}/attachments",
         check=lambda j, c: check_list(j, {"id", "filename", "kind"}, "attachments", nonempty=True)),
    Case(("GET", "/api/initiatives/<int:iid>/attachments"), "bad", 404, "/api/initiatives/999999/attachments"),
    Case(("POST", "/api/initiatives/<int:iid>/attachments"), "happy", 201, "/api/initiatives/{iid}/attachments",
         files=lambda c: {"file": (io.BytesIO(b"# Runbook\nSteps for the QA window.\n"), "qa_runbook.md"),
                          "kind": "other"},
         check=lambda j, c: (has_keys(j, {"attachment", "extracted_chars", "sa"}), j["sa"] is None or _fail(j))),
    Case(("POST", "/api/initiatives/<int:iid>/attachments"), "bad", 422, "/api/initiatives/{iid}/attachments",
         files=lambda c: {"file": (io.BytesIO(b"# notes\nbody text here\n"), "qa.md"), "kind": "selfie"},
         code="validation", note="invalid kind"),
    Case(("POST", "/api/initiatives/<int:iid>/sa-text"), "happy", 201, "/api/initiatives/{iid}/sa-text",
         body=lambda c: {"text": HERO_MD.read_text(encoding="utf-8"), "filename": "pasted.md"},
         check=lambda j, c: (has_keys(j, {"attachment", "extracted_chars", "sa"}),
                             has_keys(j["sa"], {"author", "version", "completeness", "missing"}))),
    Case(("POST", "/api/initiatives/<int:iid>/sa-text"), "bad", 422, "/api/initiatives/{iid}/sa-text", body={},
         code="validation"),
    Case(("GET", "/api/attachments/<int:aid>/download"), "happy", 200, "/api/attachments/{aid}/download",
         prep=p_upload, check=None),
    Case(("GET", "/api/attachments/<int:aid>/download"), "bad", 404, "/api/attachments/999999/download"),
    Case(("POST", "/api/initiatives/<int:iid>/groomed"), "happy", 200, "/api/initiatives/8/groomed",
         check=lambda j, c: (has_keys(j, {"initiative", "session_id", "message"}),
                             j["initiative"]["stage"] == "Solution" or _fail(j["initiative"]),
                             "Groomed" in j["message"] or _fail(j))),  # R3 N2: ad-hoc walk-through before slot
    Case(("POST", "/api/initiatives/<int:iid>/groomed"), "bad", 409, "/api/initiatives/{iid}/groomed",
         code="conflict", note="already past grooming (QA stage)"),
    # ---------------------------------------------------------------- plan
    Case(("GET", "/api/initiatives/<int:iid>/tasks"), "happy", 200, "/api/initiatives/{iid}/tasks",
         check=lambda j, c: check_list(j, {"id", "wbs_code", "step", "phase", "planned_start", "planned_end",
                                           "est_hours", "depends_on"}, "tasks", nonempty=True)),
    Case(("GET", "/api/initiatives/<int:iid>/tasks"), "bad", 404, "/api/initiatives/999999/tasks"),
    Case(("POST", "/api/initiatives/<int:iid>/tasks"), "happy", 201, "/api/initiatives/{iid}/tasks",
         body={"wbs_code": "WBS-950", "step": "Accessibility retest", "phase": "QA", "planned_start": "2026-11-02",
               "planned_end": "2026-11-06", "est_hours": 21.5}, check=k_task_write),
    Case(("POST", "/api/initiatives/<int:iid>/tasks"), "bad", 422, "/api/initiatives/{iid}/tasks",
         body={"wbs_code": "WBS-951", "step": "Backwards", "planned_start": "2026-11-10", "planned_end": "2026-11-02"},
         code="validation", note="end before start"),
    Case(("PUT", "/api/tasks/<int:tid>"), "happy", 200, "/api/tasks/{tid}", body={"pct": 40}, check=k_task_write),
    Case(("PUT", "/api/tasks/<int:tid>"), "bad", 404, "/api/tasks/999999", body={"pct": 40}),
    Case(("DELETE", "/api/tasks/<int:tid>"), "happy", 200, "/api/tasks/{new_tid}", prep=p_new_task, check=k_ok),
    Case(("DELETE", "/api/tasks/<int:tid>"), "bad", 404, "/api/tasks/999999"),
    Case(("PUT", "/api/initiatives/<int:iid>/tasks/bulk"), "happy", 200, "/api/initiatives/{iid}/tasks/bulk",
         body=lambda c: {"tasks": [{"id": c["tid"], "pct": 55}]},
         check=lambda j, c: (has_keys(j, {"items", "health"}), isinstance(j["items"], list) or _fail(j))),
    Case(("PUT", "/api/initiatives/<int:iid>/tasks/bulk"), "bad", 422, "/api/initiatives/{iid}/tasks/bulk",
         body={"tasks": []}, code="validation"),
    Case(("POST", "/api/initiatives/<int:iid>/baseline"), "happy", 200, "/api/initiatives/{iid}/baseline",
         body={"reason": "QA re-baseline after scope review"},
         check=lambda j, c: (has_keys(j, {"ok", "baseline_set_at"}), ISO_DT_OFFSET.match(j["baseline_set_at"])
                             or _fail(j))),
    Case(("POST", "/api/initiatives/<int:iid>/baseline"), "bad", 422, "/api/initiatives/{iid}/baseline", body={},
         code="validation"),
    # ---------------------------------------------------------------- resources
    Case(("GET", "/api/resources"), "happy", 200, "/api/resources?tracked=1",
         check=lambda j, c: [k_resource_row(x, c) for x in check_list(j, (), "resources", nonempty=True)]),
    Case(("GET", "/api/resources"), "bad", 422, "/api/resources?tracked=maybe", code="validation"),
    Case(("POST", "/api/resources"), "happy", 201, "/api/resources",
         body={"name": "Quinn Ashdown", "role": "Developer", "team": "EAPI"}, check=k_resource_row),
    Case(("POST", "/api/resources"), "bad", 422, "/api/resources", body={"name": "No Role Person"}, code="validation"),
    Case(("PUT", "/api/resources/<int:rid>"), "happy", 200, "/api/resources/{rid}", body={"location": "Toronto"},
         check=k_resource_row),
    Case(("PUT", "/api/resources/<int:rid>"), "bad", 404, "/api/resources/999999", body={"location": "Toronto"}),
    Case(("GET", "/api/resources/<int:rid>/availability"), "happy", 200, "/api/resources/{rid}/availability",
         check=lambda j, c: (has_keys(j, {"resource_id", "months"}),
                             all(MONTH.match(m) and isinstance(h, (int, float)) for m, h in j["months"].items())
                             or _fail(j))),
    Case(("GET", "/api/resources/<int:rid>/availability"), "bad", 404, "/api/resources/999999/availability"),
    Case(("PUT", "/api/resources/<int:rid>/availability"), "happy", 200, "/api/resources/{rid}/availability",
         body={"months": {"2027-03": 101.5}},
         check=lambda j, c: j["months"].get("2027-03") == 101.5 or _fail(j)),
    Case(("PUT", "/api/resources/<int:rid>/availability"), "bad", 422, "/api/resources/{rid}/availability",
         body={"months": {"March": 100}}, code="validation"),
    Case(("GET", "/api/resources/<int:rid>/calendar"), "happy", 200, "/api/resources/{rid}/calendar",
         check=lambda j, c: has_keys(j, {"resource_id", "months"})),
    Case(("GET", "/api/resources/<int:rid>/calendar"), "bad", 404, "/api/resources/999999/calendar"),
    Case(("GET", "/api/allocations"), "happy", 200, "/api/allocations?initiative_id=4",
         check=lambda j, c: check_list(j, {"id", "resource_id", "initiative_id", "task_id", "month", "hours",
                                           "firmness"}, "allocations", nonempty=True)),
    Case(("GET", "/api/allocations"), "bad", 422, "/api/allocations?month=2026-13", code="validation"),
    Case(("POST", "/api/allocations"), "happy", 201, "/api/allocations",
         body={"resource_id": 15, "initiative_id": 4, "month": "2027-03", "hours": 7.5},
         check=lambda j, c: (has_keys(j, {"id", "source", "firmness"}), j["source"] == "manual" or _fail(j))),
    Case(("POST", "/api/allocations"), "bad", 422, "/api/allocations",
         body={"resource_id": 15, "initiative_id": 4, "month": "2027-03", "hours": -1}, code="validation"),
    Case(("PUT", "/api/allocations/<int:aid>"), "happy", 200, "/api/allocations/{alloc_id}", prep=p_manual_alloc,
         body={"hours": 9.5}, check=lambda j, c: j["hours"] == 9.5 or _fail(j)),
    Case(("PUT", "/api/allocations/<int:aid>"), "bad", 404, "/api/allocations/999999", body={"hours": 1}),
    Case(("DELETE", "/api/allocations/<int:aid>"), "happy", 200, "/api/allocations/{alloc_id}", prep=p_manual_alloc,
         check=k_ok),
    Case(("DELETE", "/api/allocations/<int:aid>"), "bad", 409, "/api/allocations/{derived_alloc_id}",
         prep=p_derived_alloc, code="conflict", note="plan-derived row"),
    Case(("GET", "/api/skills/matrix"), "happy", 200, "/api/skills/matrix", check=lambda j, c: (
        has_keys(j, {"skills", "rows"}), has_keys(j["skills"][0], {"id", "name", "category"}),
        has_keys(j["rows"][0], {"resource_id", "name", "team", "levels", "evidence"}))),
    Case(("GET", "/api/skills/matrix"), "bad", 405, "/api/skills/matrix", method="POST", body={}),
    Case(("PUT", "/api/resources/<int:rid>/skills"), "happy", 200, "/api/resources/{rid}/skills",
         body={"skills": {"Kafka": 2}}, check=lambda j, c: has_keys(j, {"resource_id", "skills"})),
    Case(("PUT", "/api/resources/<int:rid>/skills"), "bad", 422, "/api/resources/{rid}/skills",
         body={"skills": {"Kafka": 7}}, code="validation"),
    # ---------------------------------------------------------------- governance
    Case(("GET", "/api/change-requests"), "happy", 200, "/api/change-requests",
         check=lambda j, c: [check_cr(x) for x in check_list(j, (), "change-requests", nonempty=True)]),
    Case(("GET", "/api/change-requests"), "bad", 422, "/api/change-requests?week=last-week", code="validation"),
    Case(("GET", "/api/change-requests/<int:cid>"), "happy", 200, "/api/change-requests/{cid}",
         check=lambda j, c: check_cr(j)),
    Case(("GET", "/api/change-requests/<int:cid>"), "bad", 404, "/api/change-requests/999999"),
    Case(("POST", "/api/initiatives/<int:iid>/change-requests"), "happy", 201, "/api/initiatives/5/change-requests",
         body={"crq_number": "CRQ0001049999", "crq_start": "2027-02-20T02:00", "crq_end": "2027-02-20T06:00",
               "release_type": "Bundle", "release_train": "DC-2702", "impacted_components": ["APIP"]},
         check=lambda j, c: check_cr(j)),
    Case(("POST", "/api/initiatives/<int:iid>/change-requests"), "bad", 422, "/api/initiatives/5/change-requests",
         body={"sto_approval": "Maybe"}, code="validation", note="invalid STO enum"),
    Case(("POST", "/api/initiatives/<int:iid>/change-requests/draft"), "happy", 201,
         "/api/initiatives/5/change-requests/draft",
         check=lambda j, c: (check_cr(j), re.match(r"^CRQ\d{12}$", j["crq_number"]) or _fail(j),  # R2 decision 1
                             j["sto_approval"] is None or _fail(j))),  # R2 decision 2: "Not requested"
    Case(("POST", "/api/initiatives/<int:iid>/change-requests/draft"), "bad", 404,
         "/api/initiatives/999999/change-requests/draft"),
    Case(("PUT", "/api/change-requests/<int:cid>"), "happy", 200, "/api/change-requests/{cid}",
         body={"tech_validation_status": "In progress"}, check=lambda j, c: check_cr(j)),
    Case(("PUT", "/api/change-requests/<int:cid>"), "bad", 404, "/api/change-requests/999999",
         body={"tech_validation_status": "In progress"}),
    Case(("DELETE", "/api/change-requests/<int:cid>"), "happy", 200, "/api/change-requests/{new_cid}", prep=p_new_cr,
         check=k_ok),
    Case(("DELETE", "/api/change-requests/<int:cid>"), "bad", 404, "/api/change-requests/999999"),
    Case(("GET", "/api/risks"), "happy", 200, "/api/risks?min_score=1",
         check=lambda j, c: [k_risk_row(x, c) for x in check_list(j, (), "risks", nonempty=True)]),
    Case(("GET", "/api/risks"), "bad", 422, "/api/risks?min_score=high", code="validation"),
    Case(("POST", "/api/initiatives/<int:iid>/risks"), "happy", 201, "/api/initiatives/{iid}/risks",
         body={"title": "Vendor SDK late", "category": "Dependency", "severity": 3, "likelihood": 2}, check=k_risk_row),
    Case(("POST", "/api/initiatives/<int:iid>/risks"), "bad", 422, "/api/initiatives/{iid}/risks",
         body={"title": "x", "category": "Weather", "severity": 3, "likelihood": 2}, code="validation"),
    Case(("PUT", "/api/risks/<int:rid>"), "happy", 200, "/api/risks/{risk_id}", body={"status": "Mitigating"},
         check=k_risk_row),
    Case(("PUT", "/api/risks/<int:rid>"), "bad", 404, "/api/risks/999999", body={"status": "Mitigating"}),
    Case(("DELETE", "/api/risks/<int:rid>"), "happy", 200, "/api/risks/{new_risk_id}", prep=p_new_risk, check=k_ok),
    Case(("DELETE", "/api/risks/<int:rid>"), "bad", 404, "/api/risks/999999"),
    Case(("GET", "/api/grooming/sessions"), "happy", 200, "/api/grooming/sessions?from=2026-10-19&to=2026-11-30",
         check=lambda j, c: [k_session(x, c) for x in check_list(j, (), "sessions", nonempty=True)]),
    Case(("GET", "/api/grooming/sessions"), "bad", 422, "/api/grooming/sessions?from=19-10-2026", code="validation"),
    Case(("POST", "/api/grooming/sessions"), "happy", 201, "/api/grooming/sessions",
         body={"session_date": "2026-12-01", "start_time": "14:00"}, check=k_session),
    Case(("POST", "/api/grooming/sessions"), "bad", 422, "/api/grooming/sessions", body={"session_date": "2026-10-24"},
         code="validation", note="Saturday"),
    Case(("PUT", "/api/grooming/slots"), "happy", 200, "/api/grooming/slots",
         body=lambda c: {"session_id": c["session_id"], "initiative_id": 8, "status": "Discussed"},
         check=lambda j, c: (has_keys(j, {"session_id", "initiative_id", "status"}),
                             j["status"] == "Discussed" or _fail(j))),
    Case(("PUT", "/api/grooming/slots"), "bad", 422, "/api/grooming/slots",
         body={"session_id": 999999, "initiative_id": 8}, code="validation"),
    Case(("GET", "/api/outbox"), "happy", 200, "/api/outbox", check=lambda j, c: (
        check_list(j, {"id", "status", "subject", "to_name"}, "outbox", nonempty=True),
        has_keys(j["counts"], {"Queued", "Sent"}))),
    Case(("GET", "/api/outbox"), "bad", 422, "/api/outbox?initiative_id=x", code="validation"),
    Case(("POST", "/api/outbox/<int:nid>/send"), "happy", 200, "/api/outbox/{nid}/send", check=k_notification("Sent")),
    Case(("POST", "/api/outbox/<int:nid>/send"), "bad", 404, "/api/outbox/999999/send"),
    Case(("POST", "/api/outbox/<int:nid>/ack"), "happy", 200, "/api/outbox/{nid}/ack",
         check=k_notification("Acknowledged")),
    Case(("POST", "/api/outbox/<int:nid>/ack"), "bad", 404, "/api/outbox/999999/ack"),
    Case(("POST", "/api/outbox/<int:nid>/dismiss"), "happy", 200, "/api/outbox/{nid}/dismiss",
         check=k_notification("Dismissed")),
    Case(("POST", "/api/outbox/<int:nid>/dismiss"), "bad", 404, "/api/outbox/999999/dismiss"),
    # ---------------------------------------------------------------- views
    Case(("GET", "/api/portfolio"), "happy", 200, "/api/portfolio", check=k_portfolio),
    Case(("GET", "/api/portfolio"), "bad", 422, "/api/portfolio?rag=Purple", code="validation"),
    Case(("GET", "/api/portfolio/gantt"), "happy", 200, "/api/portfolio/gantt", check=lambda j, c: (
        has_keys(j, {"start", "end", "today", "freeze", "trains", "rows"}),
        [has_keys(r, {"initiative_id", "rddc", "name", "rag", "stage", "start", "end", "readiness_date", "prod_date"})
         for r in j["rows"][:3]])),
    Case(("GET", "/api/portfolio/gantt"), "bad", 405, "/api/portfolio/gantt", method="POST", body={}),
    Case(("GET", "/api/intake-queue"), "happy", 200, "/api/intake-queue", check=lambda j, c: (
        has_keys(j, {"items", "sessions"}),
        [has_keys(i, {"initiative_id", "rddc", "name", "lob", "priority", "stage", "submitted_at", "session",
                      "action_required_by", "waiting_on"}) for i in j["items"][:3]])),
    Case(("GET", "/api/intake-queue"), "bad", 405, "/api/intake-queue", method="DELETE"),
    Case(("GET", "/api/initiatives/<int:initiative_id>/health"), "happy", 200, "/api/initiatives/{iid}/health",
         check=lambda j, c: check_health(j, scored=True)),
    Case(("GET", "/api/initiatives/<int:initiative_id>/health"), "bad", 404, "/api/initiatives/999999/health"),
    Case(("PUT", "/api/initiatives/<int:initiative_id>/health/override"), "happy", 200,
         "/api/initiatives/{iid}/health/override",
         body={"dimension": "budget", "rag": "Amber", "reason": "Vendor invoice pending"},
         check=lambda j, c: (check_health(j), j["dimensions"]["budget"]["rag"] == "Amber" or _fail(j),
                             j["dimensions"]["budget"]["overridden"] is True or _fail(j))),
    Case(("PUT", "/api/initiatives/<int:initiative_id>/health/override"), "bad", 422,
         "/api/initiatives/{iid}/health/override", body={"dimension": "budget", "rag": "Amber"},
         code="validation", note="rag without reason"),
    Case(("GET", "/api/initiatives/<int:initiative_id>/gantt"), "happy", 200, "/api/initiatives/{iid}/gantt",
         check=lambda j, c: check_gantt(j)),
    Case(("GET", "/api/initiatives/<int:initiative_id>/gantt"), "bad", 404, "/api/initiatives/999999/gantt"),
    Case(("GET", "/api/capacity"), "happy", 200, "/api/capacity?from=2026-11&to=2027-01&group=team",
         check=lambda j, c: check_capacity(j)),
    Case(("GET", "/api/capacity"), "bad", 422, "/api/capacity?group=planet", code="validation"),
    Case(("GET", "/api/initiatives/<int:initiative_id>/resource-grid"), "happy", 200,
         "/api/initiatives/{iid}/resource-grid", check=lambda j, c: (
             has_keys(j, {"fy", "quarters", "rows", "assignments"}),
             [has_keys(q, {"fy", "q", "label", "months"}) for q in j["quarters"]],
             [has_keys(r, {"resource_id", "name", "team", "role", "cells"}) for r in j["rows"][:3]],
             [has_keys(cell, {"quarter", "availability", "allocation", "confirmed", "tentative", "util", "band"})
              for r in j["rows"][:3] for cell in r["cells"][:2]],
             [has_keys(a, {"resource_id", "resource_name", "wbs_code", "hours", "allocation_pct", "from", "to",
                           "firmness"}) for a in j["assignments"][:3]])),
    Case(("GET", "/api/initiatives/<int:initiative_id>/resource-grid"), "bad", 404,
         "/api/initiatives/999999/resource-grid"),
    Case(("GET", "/api/prns"), "happy", 200, "/api/prns", check=lambda j, c: check_list(
        j, {"prn_code", "name", "lob", "funded_hours", "charged_hours", "forecast_hours", "status"}, "prns",
        nonempty=True)),
    Case(("GET", "/api/prns"), "bad", 405, "/api/prns", method="POST", body={}),
    Case(("GET", "/api/prn/<path:prn_code>/burndown"), "happy", 200, "/api/prn/PRN-71840/burndown",
         check=lambda j, c: check_burndown(j)),
    Case(("GET", "/api/prn/<path:prn_code>/burndown"), "bad", 404, "/api/prn/PRN-00000/burndown"),
    Case(("GET", "/api/initiatives/<int:initiative_id>/burndown"), "happy", 200, "/api/initiatives/2/burndown",
         check=lambda j, c: check_burndown(j)),
    Case(("GET", "/api/initiatives/<int:initiative_id>/burndown"), "bad", 404, "/api/initiatives/999999/burndown"),
    Case(("POST", "/api/initiatives/<int:initiative_id>/l2/calculate"), "happy", 200,
         "/api/initiatives/{iid}/l2/calculate", check=lambda j, c: check_l2(j)),
    Case(("POST", "/api/initiatives/<int:initiative_id>/l2/calculate"), "bad", 404,
         "/api/initiatives/999999/l2/calculate"),
    Case(("POST", "/api/initiatives/<int:initiative_id>/l2/submit"), "happy", 200,
         "/api/initiatives/{l2_iid}/l2/submit", prep=p_l2_ready, check=lambda j, c: (
             has_keys(j, {"initiative", "notifications"}),
             j["initiative"]["l2_status"] == "Pending approval" or _fail(j["initiative"]))),
    Case(("POST", "/api/initiatives/<int:initiative_id>/l2/submit"), "bad", 422, "/api/initiatives/7/l2/submit",
         code="validation", note="SA completeness 66 < 70"),
    Case(("POST", "/api/initiatives/<int:initiative_id>/l2/approve"), "happy", 200, "/api/initiatives/6/l2/approve",
         body={"comment": "Approved for DC-2703."}, check=lambda j, c: (
             has_keys(j, {"initiative", "health"}),
             j["initiative"]["l2_status"] == "Approved" or _fail(j["initiative"]))),
    Case(("POST", "/api/initiatives/<int:initiative_id>/l2/approve"), "bad", 409, "/api/initiatives/7/l2/approve",
         body={}, code="conflict", note="not submitted"),
    Case(("POST", "/api/initiatives/<int:initiative_id>/l2/reject"), "happy", 200, "/api/initiatives/6/l2/reject",
         body={"reason": "Re-estimate CIAM scope"}, check=lambda j, c: (
             has_keys(j, {"initiative"}), j["initiative"]["l2_status"] == "Rejected" or _fail(j))),
    Case(("POST", "/api/initiatives/<int:initiative_id>/l2/reject"), "bad", 422, "/api/initiatives/6/l2/reject",
         body={}, code="validation", note="no reason"),
    Case(("POST", "/api/grooming/auto-slot"), "happy", 200, "/api/grooming/auto-slot", body={"dry_run": True},
         check=lambda j, c: has_keys(j, {"assignments", "unslotted"})),
    Case(("POST", "/api/grooming/auto-slot"), "bad", 400, "/api/grooming/auto-slot", raw="[1, 2]",
         code="bad_request", note="JSON array body"),
    Case(("POST", "/api/reminders/run"), "happy", 200, "/api/reminders/run", body={},
         check=lambda j, c: has_keys(j, {"created", "skipped"})),
    Case(("POST", "/api/reminders/run"), "bad", 422, "/api/reminders/run", body={"now": "tomorrow-ish"},
         code="validation"),
    Case(("GET", "/api/governance/weekly"), "happy", 200, "/api/governance/weekly?week=2026-W43",
         check=lambda j, c: (has_keys(j, {"week", "from", "to", "items", "noncompliant_count"}),
                             j["from"] == "2026-10-19" or _fail(j))),
    Case(("GET", "/api/governance/weekly"), "bad", 422, "/api/governance/weekly?week=2026-W60", code="validation"),
    Case(("GET", "/api/governance/approvals"), "happy", 200, "/api/governance/approvals", check=lambda j, c: [
        has_keys(i, {"kind", "initiative_id", "rddc", "name", "entity_id", "title", "requested_at", "waiting_days",
                     "approver"}) and (i["kind"] in ("l2", "component", "sto") or _fail(i))
        for i in check_list(j, (), "approvals", nonempty=True)]),
    Case(("GET", "/api/governance/approvals"), "bad", 405, "/api/governance/approvals", method="POST", body={}),
    # ---------------------------------------------------------------- export
    Case(("GET", "/api/export/demo-view.xlsx"), "happy", 200, "/api/export/demo-view.xlsx?initiative_id={iid}",
         check=k_xlsx({"Mission Statement", "Demo View", "Portfolio View", "Gantt", "Capacity", "Risk Register",
                       "Lists"})),  # R2 decision 13: lookup sheet "Lists"
    Case(("GET", "/api/export/demo-view.xlsx"), "bad", 422, "/api/export/demo-view.xlsx", code="validation"),
    Case(("GET", "/api/export/portfolio.xlsx"), "happy", 200, "/api/export/portfolio.xlsx",
         check=k_xlsx({"Portfolio View", "Capacity", "Risk Register", "Lists"})),
    Case(("GET", "/api/export/portfolio.xlsx"), "bad", 422, "/api/export/portfolio.xlsx?rag=Purple", code="validation"),
    Case(("GET", "/api/export/portfolio.csv"), "happy", 200, "/api/export/portfolio.csv", check=None),
    Case(("GET", "/api/export/portfolio.csv"), "bad", 422, "/api/export/portfolio.csv?rag=Purple", code="validation"),
    # ---------------------------------------------------------------- ai
    Case(("POST", "/api/initiatives/<int:iid>/ai/<slug>"), "happy", 200, "/api/initiatives/4/ai/risks", body={},
         check=lambda j, c: check_airun(j, "risks")),
    Case(("POST", "/api/initiatives/<int:iid>/ai/<slug>"), "bad", 404, "/api/initiatives/4/ai/horoscope", body={},
         code="not_found"),
    Case(("POST", "/api/ai/<slug>"), "happy", 200, "/api/ai/skill-matrix", body={},
         check=lambda j, c: check_airun(j, "skill_matrix")),
    Case(("POST", "/api/ai/<slug>"), "bad", 422, "/api/ai/intake-autofill", body={}, code="validation",
         note="no text/attachment"),
    Case(("GET", "/api/ai/features"), "happy", 200, "/api/ai/features",
         check=lambda j, c: check_list(j, {"feature"}, "ai features", nonempty=True)),
    Case(("GET", "/api/ai/features"), "bad", 405, "/api/ai/features", method="DELETE"),
    Case(("POST", "/api/ai-runs/<int:run_id>/apply"), "happy", 200, "/api/ai-runs/{run_id}/apply", prep=p_run("risks"),
         body={}, check=k_apply),
    Case(("POST", "/api/ai-runs/<int:run_id>/apply"), "bad", 404, "/api/ai-runs/999999/apply", body={}),
    Case(("POST", "/api/ai-runs/<int:run_id>/reject"), "happy", 200, "/api/ai-runs/{run_id}/reject",
         prep=p_run("risks"), body={"reason": "Duplicates the register"},
         check=lambda j, c: j == {"ai_run_id": c["run_id"], "status": "rejected"} or _fail(j)),
    Case(("POST", "/api/ai-runs/<int:run_id>/reject"), "bad", 404, "/api/ai-runs/999999/reject", body={}),
    Case(("POST", "/api/ai-runs/<int:run_id>/regenerate"), "happy", 200, "/api/ai-runs/{run_id}/regenerate",
         prep=p_run("risks"), body={}, check=k_regen),
    Case(("POST", "/api/ai-runs/<int:run_id>/regenerate"), "bad", 404, "/api/ai-runs/999999/regenerate", body={}),
    Case(("GET", "/api/ai-runs"), "happy", 200, "/api/ai-runs?limit=5", prep=p_run("risks"),
         check=lambda j, c: check_list(j, {"feature", "initiative_id", "mode", "status"}, "ai-runs", nonempty=True,
                                       exact_total=False)),
    Case(("GET", "/api/ai-runs"), "bad", 422, "/api/ai-runs?limit=lots", code="validation"),
    Case(("GET", "/api/ai-runs/<int:run_id>"), "happy", 200, "/api/ai-runs/{run_id}", prep=p_run("risks"),
         check=lambda j, c: check_airun(j, "risks")),
    Case(("GET", "/api/ai-runs/<int:run_id>"), "bad", 404, "/api/ai-runs/999999"),
    Case(("GET", "/api/ai-runs/stats"), "happy", 200, "/api/ai-runs/stats", check=lambda j, c: (
        has_keys(j, {"runs", "accepted", "rejected", "acceptance_rate", "minutes_saved", "by_feature"}),
        [has_keys(f, {"feature", "runs", "accepted", "minutes_saved"}) for f in j["by_feature"]])),
    Case(("GET", "/api/ai-runs/stats"), "bad", 405, "/api/ai-runs/stats", method="POST", body={}),
    Case(("POST", "/api/assistant/chat"), "happy", 200, "/api/assistant/chat",
         body={"message": "Who is over-allocated?"}, check=k_chat),
    Case(("POST", "/api/assistant/chat"), "bad", 422, "/api/assistant/chat", body={"message": "   "},
         code="validation"),
    Case(("GET", "/api/assistant/conversations/<cid>"), "happy", 200, "/api/assistant/conversations/{conv_id}",
         prep=p_chat, check=lambda j, c: (has_keys(j, {"conversation_id", "messages"}),
                                          len(j["messages"]) == 2 or _fail(j))),
    Case(("GET", "/api/assistant/conversations/<cid>"), "bad", 404, "/api/assistant/conversations/conv-9999"),
]

for _kind in ("decisions", "lessons", "meeting-notes", "documents"):
    CASES += [
        Case(("GET", ART), "happy", 200, f"/api/{_kind}?initiative_id=4", check=k_artifact(_kind), note=_kind),
        Case(("GET", ART), "bad", 422, f"/api/{_kind}?initiative_id=four", code="validation", note=_kind),
        Case(("POST", ART), "happy", 201, f"/api/{_kind}", body=ART_BODIES[_kind], check=k_artifact(_kind), note=_kind),
        Case(("POST", ART), "bad", 422, f"/api/{_kind}", body=ART_MISSING[_kind], code="validation", note=_kind),
        Case(("PUT", ART_ID), "happy", 200, f"/api/{_kind}/{{{_kind}_id}}", body={"title": "QA retitled"}
             if _kind != "lessons" else {"lesson": "QA lesson text"}, check=k_artifact(_kind), note=_kind),
        Case(("PUT", ART_ID), "bad", 404, f"/api/{_kind}/999999", body={"title": "x"}, note=_kind),
        Case(("DELETE", ART_ID), "happy", 200, f"/api/{_kind}/{{{_kind}_id}}", check=k_ok, note=_kind),
        Case(("DELETE", ART_ID), "bad", 404, f"/api/{_kind}/999999", note=_kind),
    ]


def api_routes(app) -> set[tuple[str, str]]:
    out = set()
    for rule in app.url_map.iter_rules():
        if rule.rule.startswith("/api/"):
            for m in rule.methods - {"HEAD", "OPTIONS"}:
                out.add((m, rule.rule))
    return out


# ===================================================================== 1. meta-tests
def _rule_regex(rule: str) -> re.Pattern:
    out, pos = "", 0
    for m in re.finditer(r"<(?:(\w+)(?:\(([^)]*)\))?:)?(\w+)>", rule):
        out += re.escape(rule[pos:m.start()])
        if m.group(1) == "any":
            opts = [o.strip().strip("'\"") for o in m.group(2).split(",")]
            out += "(?:" + "|".join(re.escape(o) for o in opts) + r"|\{[^}]*\})"
        else:
            out += r"(?:\{[^}]*\}|[^/\"'\s?{}]+)"
        pos = m.end()
    out += re.escape(rule[pos:])
    return re.compile(out + r"(?=[\"'?]|$)", re.MULTILINE)


def test_meta_every_api_rule_is_exercised_by_some_test(app):
    """Scan test sources (all of tests/, excluding the Playwright mock server) for each /api rule's path pattern."""
    sources = "\n".join(p.read_text(encoding="utf-8") for p in TESTS.rglob("*.py")
                        if p.name != "mock_api.py" and "__pycache__" not in p.parts)
    rules = sorted({r.rule for r in app.url_map.iter_rules() if r.rule.startswith("/api/")})
    untested = [r for r in rules if not _rule_regex(r).search(sources)]
    assert not untested, f"/api rules with no test referencing them: {untested}"


def test_meta_route_table_has_happy_and_bad_case_per_route(app):
    routes = api_routes(app)
    happy = {c.route for c in CASES if c.kind == "happy"}
    bad = {c.route for c in CASES if c.kind == "bad"}
    unknown = (happy | bad) - routes
    assert not unknown, f"table names routes that do not exist: {sorted(unknown)}"
    assert not routes - happy, f"routes without a happy-path case: {sorted(routes - happy)}"
    assert not routes - bad, f"routes without a bad-input case: {sorted(routes - bad)}"


def test_meta_route_table_paths_resolve_to_declared_rule(app):
    adapter = app.url_map.bind("localhost")
    endpoint_rule = {r.endpoint: r.rule for r in app.url_map.iter_rules()}
    sample = {"iid": 4, "new_iid": 9, "icid": 1, "new_icid": 1, "tid": 1, "new_tid": 1, "rid": 14, "aid": 1,
              "alloc_id": 1, "derived_alloc_id": 1, "cid": 4, "new_cid": 1, "risk_id": 1, "new_risk_id": 1, "nid": 1,
              "l2_iid": 9, "run_id": 1, "conv_id": "conv-0001", "session_id": 6, "decisions_id": 1, "lessons_id": 1,
              "meeting-notes_id": 1, "documents_id": 1}
    for case in CASES:
        path = case.path.format(**sample).split("?")[0]
        endpoint, _ = adapter.match(path, method=case.route[0])
        assert endpoint_rule[endpoint] == case.route[1], f"{case.id}: {path} resolves to {endpoint_rule[endpoint]}"


# ===================================================================== 2. route table runner
@pytest.mark.parametrize("case", CASES, ids=[c.id for c in CASES])
def test_route_contract(client, case: Case):
    ctx = build_ctx(client)
    if case.prep:
        case.prep(client, ctx)
    path = case.path.format(**ctx)
    kwargs: dict = {}
    if case.files is not None:
        kwargs.update(data=case.files(ctx), content_type="multipart/form-data")
    elif case.raw is not None:
        kwargs.update(data=case.raw, content_type="application/json")
    elif case.body is not None:
        kwargs["json"] = case.body(ctx) if callable(case.body) else case.body
    resp = client.open(path, method=case.method or case.route[0], **kwargs)
    if case.kind == "bad":
        assert_error(resp, case.status, case.code)
        return
    assert resp.status_code == case.status, f"{resp.status_code}: {resp.get_data(as_text=True)[:400]}"
    assert resp.headers.get("Cache-Control") == "no-store", "contract §0: /api/* must be Cache-Control: no-store"
    if case.route == ("GET", "/api/attachments/<int:aid>/download"):
        assert resp.data == ctx["upload_bytes"]
        return
    if case.route == ("GET", "/api/export/portfolio.csv"):
        assert resp.mimetype == "text/csv"
        text = resp.data.decode("utf-8-sig")
        assert text.splitlines()[0].startswith("Intake/RDDC #")
        return
    if case.route[1].endswith(".xlsx"):
        case.check(resp, ctx)
        return
    assert resp.content_type.startswith("application/json")
    if case.check:
        case.check(resp.get_json(), ctx)


@pytest.mark.parametrize("slug", sorted(INIT_FEATURE_IID))
def test_every_initiative_ai_feature_returns_airun_and_writes_nothing(client, slug):
    iid = INIT_FEATURE_IID[slug]
    before = client.get(f"/api/initiatives/{iid}").get_json()
    resp = client.post(f"/api/initiatives/{iid}/ai/{slug}", json={})
    assert resp.status_code == 200, resp.get_json()
    check_airun(resp.get_json(), slug.replace("-", "_"))
    after = client.get(f"/api/initiatives/{iid}").get_json()
    for key in ("components", "tasks", "risks", "change_requests", "allocations"):
        assert before[key] == after[key], f"AI endpoint {slug} wrote {key} before Accept"


@pytest.mark.parametrize("slug", sorted(GLOBAL_FEATURE_BODY))
def test_every_global_ai_feature_returns_airun(client, slug):
    resp = client.post(f"/api/ai/{slug}", json=GLOBAL_FEATURE_BODY[slug])
    assert resp.status_code == 200, resp.get_json()
    check_airun(resp.get_json(), slug.replace("-", "_"))


def test_apply_twice_sequentially_is_409(client):
    run = client.post("/api/initiatives/4/ai/risks", json={}).get_json()["ai_run_id"]
    assert client.post(f"/api/ai-runs/{run}/apply", json={}).status_code == 200
    assert_error(client.post(f"/api/ai-runs/{run}/apply", json={}), 409, "conflict")


# ===================================================================== 3. sweeps
# A valid body per write route, so that a sweep request differs from a good one only in the thing under test.
WRITE_BODIES: dict[tuple[str, str], dict] = {
    ("PUT", "/api/settings"): {"persona": "Dev Lead"},
    ("POST", "/api/initiatives"): {"name": "QA Sweep", "lob": "US P&C", "priority": 2, "requestor": "Clara Pemberton"},
    ("PUT", "/api/initiatives/<int:iid>"): {"comments": "x"},
    ("POST", "/api/initiatives/<int:iid>/components"): {"component_id": 2},
    ("PUT", "/api/initiative-components/<int:icid>"): {"change_summary": "x"},
    ("POST", "/api/initiatives/<int:iid>/sa-text"): {"text": "Solution Architecture text that is long enough."},
    ("POST", "/api/initiatives/<int:iid>/tasks"): {"wbs_code": "WBS-960", "step": "Sweep step"},
    ("PUT", "/api/tasks/<int:tid>"): {"pct": 10},
    ("PUT", "/api/initiatives/<int:iid>/tasks/bulk"): {"tasks": [{"wbs_code": "WBS-961", "step": "Sweep bulk"}]},
    ("POST", "/api/initiatives/<int:iid>/baseline"): {"reason": "Sweep"},
    ("POST", "/api/resources"): {"name": "Sweep Person", "role": "Developer"},
    ("PUT", "/api/resources/<int:rid>"): {"location": "Toronto"},
    ("PUT", "/api/resources/<int:rid>/availability"): {"months": {"2027-04": 100}},
    ("POST", "/api/allocations"): {"resource_id": 15, "initiative_id": 4, "month": "2027-03", "hours": 5},
    ("PUT", "/api/allocations/<int:aid>"): {"hours": 6},
    ("PUT", "/api/resources/<int:rid>/skills"): {"skills": {"Kafka": 2}},
    ("POST", "/api/initiatives/<int:iid>/change-requests"): {"release_type": "Independent"},
    ("POST", "/api/initiatives/<int:iid>/change-requests/draft"): {},
    ("PUT", "/api/change-requests/<int:cid>"): {"tech_validation_status": "In progress"},
    ("POST", "/api/initiatives/<int:iid>/risks"): {"title": "Sweep risk", "category": "Technical", "severity": 2,
                                                   "likelihood": 2},
    ("PUT", "/api/risks/<int:rid>"): {"status": "Mitigating"},
    ("POST", "/api/grooming/sessions"): {"session_date": "2026-12-02", "start_time": "15:00"},
    ("PUT", "/api/grooming/slots"): {"session_id": 6, "initiative_id": 8, "status": "Discussed"},
    ("POST", ART): {"title": "Sweep decision", "decision": "Go"},
    ("PUT", ART_ID): {"title": "Sweep retitle"},
    ("PUT", "/api/initiatives/<int:initiative_id>/health/override"): {"dimension": "budget", "rag": "Amber",
                                                                      "reason": "Sweep"},
    ("POST", "/api/initiatives/<int:initiative_id>/l2/approve"): {"comment": "ok"},
    ("POST", "/api/initiatives/<int:initiative_id>/l2/reject"): {"reason": "re-estimate"},
    ("POST", "/api/grooming/auto-slot"): {"dry_run": True},
    ("POST", "/api/reminders/run"): {"now": "2026-10-21"},
    ("POST", "/api/initiatives/<int:iid>/ai/<slug>"): {"instruction": "Keep it short"},
    ("POST", "/api/ai/<slug>"): {"instruction": "Keep it short"},
    ("POST", "/api/ai-runs/<int:run_id>/apply"): {"selected": [0]},
    ("POST", "/api/ai-runs/<int:run_id>/reject"): {"reason": "no"},
    ("POST", "/api/ai-runs/<int:run_id>/regenerate"): {"instruction": "Shorter"},
    ("POST", "/api/assistant/chat"): {"message": "Who is over-allocated?"},
}

# Concrete paths used by the sweeps (ids are seed ids; 999999 never exists).
SWEEP_PATHS: dict[tuple[str, str], str] = {
    ("PUT", "/api/settings"): "/api/settings",
    ("POST", "/api/initiatives"): "/api/initiatives",
    ("PUT", "/api/initiatives/<int:iid>"): "/api/initiatives/{i}",
    ("POST", "/api/initiatives/<int:iid>/components"): "/api/initiatives/{i}/components",
    ("PUT", "/api/initiative-components/<int:icid>"): "/api/initiative-components/{icid}",
    ("POST", "/api/initiatives/<int:iid>/sa-text"): "/api/initiatives/{i}/sa-text",
    ("POST", "/api/initiatives/<int:iid>/tasks"): "/api/initiatives/{i}/tasks",
    ("PUT", "/api/tasks/<int:tid>"): "/api/tasks/{tid}",
    ("PUT", "/api/initiatives/<int:iid>/tasks/bulk"): "/api/initiatives/{i}/tasks/bulk",
    ("POST", "/api/initiatives/<int:iid>/baseline"): "/api/initiatives/{i}/baseline",
    ("POST", "/api/resources"): "/api/resources",
    ("PUT", "/api/resources/<int:rid>"): "/api/resources/{rid}",
    ("PUT", "/api/resources/<int:rid>/availability"): "/api/resources/{rid}/availability",
    ("POST", "/api/allocations"): "/api/allocations",
    ("PUT", "/api/allocations/<int:aid>"): "/api/allocations/{alloc}",
    ("PUT", "/api/resources/<int:rid>/skills"): "/api/resources/{rid}/skills",
    ("POST", "/api/initiatives/<int:iid>/change-requests"): "/api/initiatives/{i}/change-requests",
    ("POST", "/api/initiatives/<int:iid>/change-requests/draft"): "/api/initiatives/{i5}/change-requests/draft",
    ("PUT", "/api/change-requests/<int:cid>"): "/api/change-requests/{cid}",
    ("POST", "/api/initiatives/<int:iid>/risks"): "/api/initiatives/{i}/risks",
    ("PUT", "/api/risks/<int:rid>"): "/api/risks/{risk}",
    ("POST", "/api/grooming/sessions"): "/api/grooming/sessions",
    ("PUT", "/api/grooming/slots"): "/api/grooming/slots",
    ("POST", ART): "/api/decisions",
    ("PUT", ART_ID): "/api/decisions/{dec}",
    ("PUT", "/api/initiatives/<int:initiative_id>/health/override"): "/api/initiatives/{i}/health/override",
    ("POST", "/api/initiatives/<int:initiative_id>/l2/approve"): "/api/initiatives/{i6}/l2/approve",
    ("POST", "/api/initiatives/<int:initiative_id>/l2/reject"): "/api/initiatives/{i6}/l2/reject",
    ("POST", "/api/grooming/auto-slot"): "/api/grooming/auto-slot",
    ("POST", "/api/reminders/run"): "/api/reminders/run",
    ("POST", "/api/initiatives/<int:iid>/ai/<slug>"): "/api/initiatives/{i}/ai/risks",
    ("POST", "/api/ai/<slug>"): "/api/ai/exec-summary",
    ("POST", "/api/ai-runs/<int:run_id>/apply"): "/api/ai-runs/{run}/apply",
    ("POST", "/api/ai-runs/<int:run_id>/reject"): "/api/ai-runs/{run}/reject",
    ("POST", "/api/ai-runs/<int:run_id>/regenerate"): "/api/ai-runs/{run}/regenerate",
    ("POST", "/api/assistant/chat"): "/api/assistant/chat",
}


def sweep_ids(c, unknown: bool = False) -> dict:
    if unknown:
        n = 999999
        return {"i": n, "i5": n, "i6": n, "icid": n, "tid": n, "rid": n, "alloc": n, "cid": n, "risk": n, "dec": n,
                "run": n}
    alloc = c.post("/api/allocations", json={"resource_id": 15, "initiative_id": 4, "month": "2027-02",
                                             "hours": 3}).get_json()["id"]
    run = c.post("/api/initiatives/4/ai/risks", json={}).get_json()["ai_run_id"]
    ctx = build_ctx(c)
    return {"i": 4, "i5": 5, "i6": 6, "icid": ctx["icid"], "tid": ctx["tid"], "rid": 14, "alloc": alloc, "cid": 4,
            "risk": ctx["risk_id"], "dec": ctx["decisions_id"], "run": run}


# Routes whose request body the contract defines. Malformed JSON on these must be 400 bad_request.
# (The CRQ draft takes no body per contracts §2, so it may ignore one.)
BODY_ROUTES = sorted(r for r in SWEEP_PATHS if r != ("POST", "/api/initiatives/<int:iid>/change-requests/draft"))


@pytest.mark.parametrize("route", BODY_ROUTES, ids=[f"{m} {r}" for m, r in BODY_ROUTES])
def test_malformed_json_body_is_400(client, route):
    path = SWEEP_PATHS[route].format(**sweep_ids(client))
    resp = client.open(path, method=route[0], data='{"name": "unterminated', content_type="application/json")
    assert_error(resp, 400, "bad_request")


# Every route that takes an id in its URL: an unknown id must be 404 JSON (not HTML, not 422/500).
UNKNOWN_ID_PATHS: dict[tuple[str, str], str] = {
    ("GET", "/api/dc-intakes/<code>"): "/api/dc-intakes/DCI-999999",
    ("GET", "/api/initiatives/<int:iid>"): "/api/initiatives/999999",
    ("DELETE", "/api/initiatives/<int:iid>"): "/api/initiatives/999999",
    ("GET", "/api/initiatives/<int:iid>/components"): "/api/initiatives/999999/components",
    ("DELETE", "/api/initiative-components/<int:icid>"): "/api/initiative-components/999999",
    ("GET", "/api/initiatives/<int:iid>/attachments"): "/api/initiatives/999999/attachments",
    ("POST", "/api/initiatives/<int:iid>/attachments"): "/api/initiatives/999999/attachments",
    ("GET", "/api/attachments/<int:aid>/download"): "/api/attachments/999999/download",
    ("GET", "/api/initiatives/<int:iid>/tasks"): "/api/initiatives/999999/tasks",
    ("DELETE", "/api/tasks/<int:tid>"): "/api/tasks/999999",
    ("GET", "/api/resources/<int:rid>/availability"): "/api/resources/999999/availability",
    ("GET", "/api/resources/<int:rid>/calendar"): "/api/resources/999999/calendar",
    ("DELETE", "/api/allocations/<int:aid>"): "/api/allocations/999999",
    ("GET", "/api/change-requests/<int:cid>"): "/api/change-requests/999999",
    ("DELETE", "/api/change-requests/<int:cid>"): "/api/change-requests/999999",
    ("DELETE", "/api/risks/<int:rid>"): "/api/risks/999999",
    ("POST", "/api/outbox/<int:nid>/send"): "/api/outbox/999999/send",
    ("POST", "/api/outbox/<int:nid>/ack"): "/api/outbox/999999/ack",
    ("POST", "/api/outbox/<int:nid>/dismiss"): "/api/outbox/999999/dismiss",
    ("DELETE", ART_ID): "/api/lessons/999999",
    ("GET", "/api/initiatives/<int:initiative_id>/health"): "/api/initiatives/999999/health",
    ("GET", "/api/initiatives/<int:initiative_id>/gantt"): "/api/initiatives/999999/gantt",
    ("GET", "/api/initiatives/<int:initiative_id>/resource-grid"): "/api/initiatives/999999/resource-grid",
    ("GET", "/api/prn/<path:prn_code>/burndown"): "/api/prn/PRN-999999/burndown",
    ("GET", "/api/initiatives/<int:initiative_id>/burndown"): "/api/initiatives/999999/burndown",
    ("POST", "/api/initiatives/<int:initiative_id>/l2/calculate"): "/api/initiatives/999999/l2/calculate",
    ("POST", "/api/initiatives/<int:initiative_id>/l2/submit"): "/api/initiatives/999999/l2/submit",
    ("GET", "/api/ai-runs/<int:run_id>"): "/api/ai-runs/999999",
    ("GET", "/api/assistant/conversations/<cid>"): "/api/assistant/conversations/conv-999999",
    ("POST", "/api/ai/<slug>"): "/api/ai/horoscope",
    ("POST", "/api/initiatives/<int:iid>/groomed"): "/api/initiatives/999999/groomed",
}
for _route, _path in SWEEP_PATHS.items():
    if "{" in _path:
        UNKNOWN_ID_PATHS[_route] = _path


def test_unknown_id_sweep_covers_every_id_route(app):
    with_ids = {r for r in api_routes(app) if "<" in r[1]} - {("GET", ART), ("POST", ART)}
    missing = with_ids - set(UNKNOWN_ID_PATHS)
    assert not missing, f"id routes missing from the unknown-id sweep: {sorted(missing)}"


@pytest.mark.parametrize("route", sorted(UNKNOWN_ID_PATHS), ids=[f"{m} {r}" for m, r in sorted(UNKNOWN_ID_PATHS)])
def test_unknown_id_is_404_json(client, route):
    path = UNKNOWN_ID_PATHS[route].format(**sweep_ids(client, unknown=True))
    kwargs = {}
    if route == ("POST", "/api/initiatives/<int:iid>/attachments"):
        kwargs = {"data": {"file": (io.BytesIO(b"# x\nlong enough body text\n"), "x.md"), "kind": "other"},
                  "content_type": "multipart/form-data"}
    elif route in WRITE_BODIES:
        kwargs["json"] = WRITE_BODIES[route]
    resp = client.open(path, method=route[0], **kwargs)
    assert_error(resp, 404, "not_found")


# Wrong-typed values per field. None of them may produce a 500 (contract: 400/404/409/422 with JSON {error}).
BAD_VALUES = [12345, ["x"], {"a": 1}, True, "x" * 5000]
FIELD_SWEEP: dict[tuple[str, str], list[str]] = {
    ("PUT", "/api/settings"): ["ai_mode", "ai_speed", "persona", "demo_today"],
    ("POST", "/api/initiatives"): ["name", "lob", "priority", "requestor", "requestor_id", "dc_intake", "description",
                                   "requested_go_live", "dc_pm_id", "labels", "target_release", "prn_code"],
    ("PUT", "/api/initiatives/<int:iid>"): ["name", "stage", "status", "planned_start", "sa_version", "labels",
                                            "comments", "priority"],
    ("POST", "/api/initiatives/<int:iid>/components"): ["component_id", "component_code", "approval", "complexity",
                                                        "est_hours", "component_lead_id", "sort"],
    ("PUT", "/api/initiative-components/<int:icid>"): ["approval", "complexity", "est_hours", "component_id"],
    ("POST", "/api/initiatives/<int:iid>/sa-text"): ["text", "filename"],
    ("POST", "/api/initiatives/<int:iid>/tasks"): ["wbs_code", "step", "phase", "owner_id", "planned_start",
                                                   "planned_end", "est_hours", "allocation_pct", "status", "pct",
                                                   "at_risk", "is_milestone", "parent_id", "depends_on"],
    ("PUT", "/api/tasks/<int:tid>"): ["planned_start", "planned_end", "est_hours", "allocation_pct", "status",
                                      "depends_on", "resource_id", "parent_id"],
    ("PUT", "/api/initiatives/<int:iid>/tasks/bulk"): ["tasks"],
    ("POST", "/api/initiatives/<int:iid>/baseline"): ["reason"],
    ("POST", "/api/resources"): ["name", "role", "email", "team", "component_id", "hourly_rate",
                                 "default_monthly_hours", "capacity_eligible"],
    ("PUT", "/api/resources/<int:rid>"): ["name", "active", "default_monthly_hours"],
    ("PUT", "/api/resources/<int:rid>/availability"): ["months", "note"],
    ("POST", "/api/allocations"): ["resource_id", "initiative_id", "task_id", "month", "hours", "firmness"],
    ("PUT", "/api/allocations/<int:aid>"): ["hours", "month", "task_id", "firmness"],
    ("PUT", "/api/resources/<int:rid>/skills"): ["skills"],
    ("POST", "/api/initiatives/<int:iid>/change-requests"): ["crq_number", "raised_at", "crq_start", "crq_end",
                                                             "release_type", "release_train", "affected_cis",
                                                             "impacted_components", "sto_approval", "cms_lead_id",
                                                             "backout_attachment_id"],
    ("PUT", "/api/change-requests/<int:cid>"): ["crq_start", "crq_end", "sto_approval", "implementation_status"],
    ("POST", "/api/initiatives/<int:iid>/risks"): ["title", "category", "severity", "likelihood", "owner_id",
                                                   "status", "due_date", "task_id"],
    ("PUT", "/api/risks/<int:rid>"): ["severity", "status", "task_id", "title"],
    ("POST", "/api/grooming/sessions"): ["session_date", "start_time", "title", "capacity", "status"],
    ("PUT", "/api/grooming/slots"): ["session_id", "initiative_id", "new_session_id", "status"],
    ("POST", ART): ["title", "decision", "decided_on", "status", "initiative_id"],
    ("PUT", ART_ID): ["title", "status", "decided_on"],
    ("PUT", "/api/initiatives/<int:initiative_id>/health/override"): ["dimension", "rag", "reason"],
    ("POST", "/api/initiatives/<int:initiative_id>/l2/approve"): ["comment", "approved_by"],
    ("POST", "/api/initiatives/<int:initiative_id>/l2/reject"): ["reason"],
    ("POST", "/api/grooming/auto-slot"): ["dry_run"],
    ("POST", "/api/reminders/run"): ["now"],
    ("POST", "/api/initiatives/<int:iid>/ai/<slug>"): ["instruction", "regen_of", "options"],
    ("POST", "/api/ai/<slug>"): ["instruction", "regen_of", "options"],
    ("POST", "/api/ai-runs/<int:run_id>/apply"): ["selected", "edited_output"],
    ("POST", "/api/ai-runs/<int:run_id>/reject"): ["reason"],
    ("POST", "/api/assistant/chat"): ["message", "conversation_id", "initiative_id", "page", "regen_of"],
}
# AI option fields that take ids/text (contracts.md §2 ai): (path, option)
AI_OPTION_SWEEP = [
    ("/api/initiatives/4/ai/cr-compliance", "change_request_id"),
    ("/api/initiatives/4/ai/resources", "wbs_code"),
    ("/api/initiatives/4/ai/resources", "resource_id"),
    ("/api/initiatives/5/ai/rebalance", "wbs_code"),
    ("/api/ai/meeting-extract", "meeting_note_id"),
    ("/api/ai/meeting-extract", "text"),
    ("/api/ai/intake-autofill", "attachment_id"),
    ("/api/ai/intake-autofill", "text"),
    ("/api/ai/intake-analysis", "name"),
    ("/api/ai/intake-analysis", "description"),
    ("/api/ai/intake-analysis", "lob"),
    ("/api/ai/lessons", "initiative_id"),
    ("/api/ai/exec-summary", "initiative_id"),
]


def _wrong_type_failures(client, method, path, base, fields) -> list[str]:
    failures = []
    for fld in fields:
        for bad in BAD_VALUES:
            body = {**base, fld: bad}
            resp = client.open(path, method=method, json=body)
            label = f"{method} {path} {fld}={json.dumps(bad)[:20]}"
            if resp.status_code >= 500:
                failures.append(f"{label} -> {resp.status_code}")
            elif resp.status_code >= 400:
                body_json = resp.get_json(silent=True)
                if not (isinstance(body_json, dict) and "error" in body_json):
                    failures.append(f"{label} -> {resp.status_code} non-JSON error")
    return failures


@pytest.mark.parametrize("route", sorted(FIELD_SWEEP), ids=[f"{m} {r}" for m, r in sorted(FIELD_SWEEP)])
def test_wrong_types_never_500(client, route):
    path = SWEEP_PATHS[route].format(**sweep_ids(client))
    failures = _wrong_type_failures(client, route[0], path, WRITE_BODIES.get(route, {}), FIELD_SWEEP[route])
    assert not failures, "server errors on wrong-typed input:\n" + "\n".join(failures)


@pytest.mark.parametrize("path, option", AI_OPTION_SWEEP, ids=[f"{p} options.{o}" for p, o in AI_OPTION_SWEEP])
def test_ai_option_wrong_types_never_500(client, path, option):
    failures = []
    for bad in BAD_VALUES + ["not-a-number"]:
        resp = client.post(path, json={"options": {option: bad}})
        if resp.status_code >= 500:
            failures.append(f"options.{option}={json.dumps(bad)[:20]} -> {resp.status_code}")
    assert not failures, "server errors on wrong-typed AI options:\n" + "\n".join(failures)


@pytest.mark.parametrize("path, option, value", [
    ("/api/initiatives/4/ai/cr-compliance", "change_request_id", 999999),
    ("/api/ai/meeting-extract", "meeting_note_id", 999999),
    ("/api/ai/intake-autofill", "attachment_id", 999999),
])
def test_ai_option_unknown_record_id_is_404(client, path, option, value):
    """contracts §0: an unknown id is not_found; an AI proposal about a record that does not exist is misleading."""
    assert_error(client.post(path, json={"options": {option: value}}), 404, "not_found")


def test_non_api_unknown_path_under_api_is_json_404(client):
    assert_error(client.get("/api/definitely-not-a-route"), 404, "not_found")
    assert_error(client.get("/api/initiatives/abc"), 404, "not_found")


# ===================================================================== 4. hero end-to-end (API only, simulated AI)
@pytest.fixture(scope="module")
def hero_flow(qa_app_factory):
    """Run the demo hero pipeline once through the API, recording every response. Tests below assert on it."""
    app = qa_app_factory()
    c = app.test_client()
    rec: dict[str, Any] = {"app": app, "client": c}

    def call(name, method, path, **kw):
        resp = c.open(path, method=method, **kw)
        rec[name] = {"status": resp.status_code, "json": resp.get_json(silent=True), "resp": resp}
        return rec[name]["json"] or {}

    try:
        people = resource_ids(c)
        rec["people"] = people
        call("intake", "GET", "/api/dc-intakes/DCI-3391")
        created = call("create", "POST", "/api/initiatives", json={
            "dc_intake": "DCI-3391", "dc_pm_id": people["Grace Ellingham"], "dc_sa_id": people["Sana Whitfield"],
            "tech_lead_id": people["Devon Achterberg"]})
        iid = rec["iid"] = created["initiative"]["id"]
        for ext, src in (("docx", HERO_DOCX), ("pdf", HERO_PDF)):
            call(f"upload_{ext}", "POST", f"/api/initiatives/{iid}/attachments",
                 data={"file": (io.BytesIO(src.read_bytes()), src.name), "kind": "sa_doc"},
                 content_type="multipart/form-data")
        cs = call("cs_run", "POST", f"/api/initiatives/{iid}/ai/change-summary", json={})
        call("cs_apply", "POST", f"/api/ai-runs/{cs['ai_run_id']}/apply", json={})
        call("components", "GET", f"/api/initiatives/{iid}/components")
        call("l2_calc", "POST", f"/api/initiatives/{iid}/l2/calculate")
        call("l2_submit", "POST", f"/api/initiatives/{iid}/l2/submit", json={})
        call("l2_approve", "POST", f"/api/initiatives/{iid}/l2/approve", json={"comment": "Approved for DC-2702."})
        wbs = call("wbs_run", "POST", f"/api/initiatives/{iid}/ai/wbs", json={})
        call("wbs_apply", "POST", f"/api/ai-runs/{wbs['ai_run_id']}/apply", json={})
        res = call("res_run", "POST", f"/api/initiatives/{iid}/ai/resources", json={})
        call("res_apply", "POST", f"/api/ai-runs/{res['ai_run_id']}/apply", json={})
        call("tasks", "GET", f"/api/initiatives/{iid}/tasks")
        call("gantt", "GET", f"/api/initiatives/{iid}/gantt")
        call("health_before", "GET", f"/api/initiatives/{iid}/health")
        call("capacity_sana", "GET", "/api/capacity?from=2026-11&to=2026-11&group=resource")
        reb = call("rebal_run", "POST", f"/api/initiatives/{iid}/ai/rebalance", json={})
        call("rebal_apply", "POST", f"/api/ai-runs/{reb['ai_run_id']}/apply", json={})
        call("health_after", "GET", f"/api/initiatives/{iid}/health")
        rk = call("risks_run", "POST", f"/api/initiatives/{iid}/ai/risks", json={})
        call("risks_apply", "POST", f"/api/ai-runs/{rk['ai_run_id']}/apply", json={})
        call("risks", "GET", f"/api/risks?initiative_id={iid}")
        call("crq_draft", "POST", f"/api/initiatives/{iid}/change-requests/draft", json={})
        call("crq_ai", "POST", f"/api/initiatives/{iid}/ai/cr-compliance", json={})
        call("portfolio", "GET", "/api/portfolio")
        call("xlsx_demo", "GET", f"/api/export/demo-view.xlsx?initiative_id={iid}")
        call("xlsx_portfolio", "GET", "/api/export/portfolio.xlsx")
    except Exception as exc:  # noqa: BLE001 - recorded so each test reports which step was reached
        rec["_error"] = f"{type(exc).__name__}: {exc}"
    return rec


def step(flow, name, status=200):
    assert name in flow, f"hero pipeline stopped before '{name}': {flow.get('_error')}"
    got = flow[name]
    assert got["status"] == status, f"{name}: {got['status']} {str(got['json'])[:400]}"
    return got["json"]


def test_hero_01_create_from_dci_3391(hero_flow):
    intake = step(hero_flow, "intake")
    assert intake["name"] == "US API Enhancement" and intake["lob"] == "US P&C" and intake["priority"] == 2
    created = step(hero_flow, "create", 201)
    ini = created["initiative"]
    assert ini["rddc"] == "RDDC-24817"
    assert ini["name"] == "US API Enhancement" and ini["dc_intake"] == "DCI-3391"
    assert ini["prn_code"] == "PRN-77310" and ini["target_release"] == "DC-2702"
    assert created["grooming"]["session_date"] == "2026-10-20" and created["grooming"]["start_time"] == "10:00"
    to = {n["to_name"] for n in created["queued_notifications"]}
    assert {"Arlo Kingsley", "Grace Ellingham", "Sana Whitfield", "Clara Pemberton"} <= to, to


@pytest.mark.parametrize("ext", ["docx", "pdf"])
def test_hero_02_sa_upload_scores_88(hero_flow, ext):
    up = step(hero_flow, f"upload_{ext}", 201)
    assert up["extracted_chars"] > 200
    assert up["sa"]["completeness"] == 88, up["sa"]
    assert up["sa"]["missing"] == ["Backout plan"]
    assert up["sa"]["author"] == "Sana Whitfield" and up["sa"]["version"] == "1.2"


def test_hero_03_change_summary_apply_gives_four_components(hero_flow):
    check_airun(step(hero_flow, "cs_run"), "change_summary")
    applied = step(hero_flow, "cs_apply")
    assert applied["applied"].get("initiative_components") == 4
    rows = {r["code"]: (r["complexity"], r["approval"]) for r in step(hero_flow, "components")["items"]}
    assert rows == {"APIP": ("High", "Approved"), "EDP": ("Medium", "Approved"), "CIAM": ("Medium", "Pending"),
                    "SRE": ("Low", "Not required")}


def test_hero_04_l2_numbers_and_approval(hero_flow):
    est = step(hero_flow, "l2_calc")
    got = {k: est[k] for k in ("dev_hours", "architecture_hours", "qa_hours", "pm_release_hours", "subtotal",
                               "contingency_hours", "total_hours", "low_hours", "high_hours", "tshirt")}
    assert got == {"dev_hours": 560, "architecture_hours": 56, "qa_hours": 196, "pm_release_hours": 56,
                   "subtotal": 868, "contingency_hours": 130, "total_hours": 1000, "low_hours": 750,
                   "high_hours": 1250, "tshirt": "L"}
    assert step(hero_flow, "l2_submit")["initiative"]["l2_status"] == "Pending approval"
    ini = step(hero_flow, "l2_approve")["initiative"]
    assert ini["l2_status"] == "Approved" and ini["stage"] == "Planning"
    assert (ini["l2_hours"], ini["l2_tshirt"], ini["l2_low_hours"], ini["l2_high_hours"]) == (1000, "L", 750, 1250)


def test_hero_05_wbs_apply_14_rows_dev_560(hero_flow):
    check_airun(step(hero_flow, "wbs_run"), "wbs")
    assert step(hero_flow, "wbs_apply")["applied"].get("wbs_tasks") == 14
    tasks = step(hero_flow, "tasks")["items"]
    assert len(tasks) == 14
    dev = sum(t["est_hours"] or 0 for t in tasks if t["phase"] == "Development")
    assert dev == 560
    total = sum(t["est_hours"] or 0 for t in tasks)
    assert total <= 1000, f"Σ est_hours {total} must stay within L2 (budget Green, master §6.2.5)"
    assert {t["wbs_code"] for t in tasks} >= {"WBS-100", "WBS-210", "WBS-700"}


def test_hero_06_gantt_critical_path_and_key_dates(hero_flow):
    g = step(hero_flow, "gantt")
    check_gantt(g)
    assert g["critical_path"], "critical path must be present"
    crit = {t["id"] for t in g["tasks"] if t["critical"]}
    assert set(g["critical_path"]) == crit, "critical flags disagree with critical_path"
    assert (g["readiness_date"], g["prod_date"], g["float_bd"]) == ("2027-02-17", "2027-02-20", 2)


def test_hero_07_health_target(hero_flow):
    h = step(hero_flow, "health_before")
    check_health(h, scored=True)
    rag = {d: h["dimensions"][d]["rag"] for d in DIMS}
    assert (h["overall"], rag) == ("Amber", {"schedule": "Amber", "resources": "Red", "scope": "Green",
                                             "dependencies": "Green", "budget": "Green"})
    # R2 decision 7: every Red dimension plus Schedule Amber with float <= 2
    assert h["attention"] == ["SA capacity constraint affecting WBS-100",
                              "Readiness float 2 business days to DC-2702 affecting WBS-600"], h["attention"]


def test_hero_08_rebalance_turns_resources_green(hero_flow):
    run = step(hero_flow, "rebal_run")
    check_airun(run, "rebalance")
    opt = run["output"]["options"][0]
    assert (opt["task_wbs_code"], opt["from_resource_name"], opt["to_resource_name"]) == (
        "WBS-100", "Sana Whitfield", "Mateo Brennan")
    step(hero_flow, "rebal_apply")
    h = step(hero_flow, "health_after")
    assert h["dimensions"]["resources"]["rag"] == "Green"
    assert h["overall"] == "Amber"
    assert h["attention"] == ["Readiness float 2 business days to DC-2702 affecting WBS-600"], h["attention"]


def test_hero_09_risks_applied_to_register(hero_flow):
    run = step(hero_flow, "risks_run")
    check_airun(run, "risks")
    applied = step(hero_flow, "risks_apply")["applied"]["risks"]
    items = step(hero_flow, "risks")["items"]
    assert applied >= 1 and len(items) == applied
    assert all(re.match(r"^RSK-\d{3,}$", r["risk_code"]) for r in items)
    assert len({r["risk_code"] for r in items}) == len(items), "risk codes must be unique"


def test_hero_10_crq_draft_and_compliance(hero_flow):
    cr = step(hero_flow, "crq_draft", 201)
    check_cr(cr)
    assert cr["crq_number"] == "CRQ000001052216"  # R2 decision 1 (app_settings.crq_next, not the RDDC)
    assert cr["release_type"] == "Bundle" and cr["release_train"] == "DC-2702"
    assert cr["crq_start"].startswith("2027-02-20T02:00") and cr["crq_end"].startswith("2027-02-20T06:00")
    flags = cr["compliance"]["flags"]
    assert [f["code"] for f in flags] == ["CR-11"], flags  # R2 decision 3: exactly 1 flag, backout plan
    assert cr["sto_approval"] is None  # R2 decision 2: "Not requested"
    not_due = {f["rule_id"] for f in cr["compliance"]["findings"] if f["status"] == "Not due yet"}
    assert {"CR-01", "CR-02"} <= not_due, not_due
    ai = step(hero_flow, "crq_ai")
    check_airun(ai, "cr_compliance")
    assert ai["output"]["crq_number"] == "CRQ000001052216"


def test_hero_11_portfolio_includes_hero(hero_flow):
    p = step(hero_flow, "portfolio")
    hero = [x for x in p["projects"] if x["rddc"] == "RDDC-24817"]
    assert len(hero) == 1 and hero[0]["rag"] == "Amber"
    assert hero[0]["dimensions"]["resources"] == "Green"


@pytest.mark.parametrize("name, sheets", [
    ("xlsx_demo", {"Mission Statement", "Demo View", "Portfolio View", "Gantt", "Capacity", "Risk Register", "Lists"}),
    ("xlsx_portfolio", {"Mission Statement", "Portfolio View", "Capacity", "Risk Register", "Lists"}),
])
def test_hero_12_exports_open_with_openpyxl(hero_flow, name, sheets):
    import openpyxl
    assert name in hero_flow, hero_flow.get("_error")
    resp = hero_flow[name]["resp"]
    assert resp.status_code == 200 and resp.content_type.startswith(XLSX_MIME)
    wb = openpyxl.load_workbook(io.BytesIO(resp.data))
    assert sheets <= set(wb.sheetnames), wb.sheetnames
    text = " ".join(str(c.value) for ws in wb.worksheets for row in ws.iter_rows() for c in row if c.value)
    assert "RDDC-24817" in text


def _existing_records(c) -> dict:
    inits = c.get("/api/initiatives").get_json()["items"]
    return {
        "rddc": {i["rddc"] for i in inits}, "iid": {i["id"] for i in inits},
        "crq": {x["crq_number"] for x in c.get("/api/change-requests").get_json()["items"]},
        "resource": {r["id"] for r in c.get("/api/resources?active=all").get_json()["items"]}
        | {r["name"] for r in c.get("/api/resources?active=all").get_json()["items"]},
        "prn": {p["prn_code"] for p in c.get("/api/prns").get_json()["items"]},
        "train": {t["code"] for t in c.get("/api/release-trains").get_json()["items"]},
        "component": {x["code"] for x in c.get("/api/lookups").get_json()["components"]},
    }


def _bad_citations(c, answer: dict, known: dict) -> list[str]:
    bad = []
    for cit in answer["citations"]:
        t, ident, route = cit["type"], cit["id"], cit.get("route") or ""
        m = re.match(r"^#/initiative/(\d+)/", route)
        if m and int(m.group(1)) not in known["iid"]:
            bad.append(f"route {route} -> initiative id does not exist")
        if t == "initiative" and ident not in known["rddc"] and ident not in known["iid"]:
            bad.append(f"initiative {ident}")
        elif t == "change_request" and ident not in known["crq"]:
            bad.append(f"change_request {ident}")
        elif t == "resource" and ident not in known["resource"]:
            bad.append(f"resource {ident}")
        elif t == "prn" and ident not in known["prn"]:
            bad.append(f"prn {ident}")
        elif t == "release_train" and ident not in known["train"]:
            bad.append(f"release_train {ident}")
        elif t == "component" and ident not in known["component"]:
            bad.append(f"component {ident}")
        elif t == "wbs_task":
            rddc, _, code = str(ident).partition("/")
            if rddc not in known["rddc"]:
                bad.append(f"wbs_task {ident} (initiative)")
            else:
                iid = next(i["id"] for i in c.get(f"/api/initiatives?q={rddc}").get_json()["items"]
                           if i["rddc"] == rddc)
                codes = {x["wbs_code"] for x in c.get(f"/api/initiatives/{iid}/tasks").get_json()["items"]}
                if code not in codes:
                    bad.append(f"wbs_task {ident}")
    return bad


def _assistant_questions() -> list[str]:
    qs = []
    for f in sorted(glob.glob(str(ROOT / "app/ai/fixtures/assistant/*.json"))):
        data = json.loads(Path(f).read_text(encoding="utf-8"))
        q = data.get("match", {}).get("question")
        if q:
            qs.append(q)
    return qs + ["Which projects are Red?", "What is blocking RDDC-99999?", "Who is Zed Unknown working with?",
                 "What changed this week for CRQ0009999999?"]


@pytest.mark.parametrize("state", ["seed_only", "after_hero"])
def test_hero_13_assistant_cites_only_existing_records(qa_app_factory, state):
    app = qa_app_factory()
    c = app.test_client()
    if state == "after_hero":
        assert c.post("/api/admin/fast-forward-hero").status_code == 200
    known = _existing_records(c)
    problems = []
    for q in _assistant_questions():
        resp = c.post("/api/assistant/chat", json={"message": q})
        if resp.status_code != 200:
            problems.append(f"{q!r}: HTTP {resp.status_code}")
            continue
        for b in _bad_citations(c, resp.get_json(), known):
            problems.append(f"{q!r}: cites missing {b}")
    assert not problems, "\n".join(problems)


def test_hero_14_reset_restores_seed_counts_and_rddc_sequence(qa_app_factory, seeded_template):
    seed_counts = table_counts(str(seeded_template[0]))
    app = qa_app_factory()
    c = app.test_client()
    assert c.post("/api/admin/fast-forward-hero").get_json()["rddc"] == "RDDC-24817"
    create_plain_initiative(c, "QA Extra After Hero")
    assert c.post("/api/initiatives/4/ai/risks", json={}).status_code == 200
    hero_dir = Path(app.config["UPLOAD_DIR"]) / "9"
    assert hero_dir.is_dir()
    resp = c.post("/api/admin/reset")
    assert resp.status_code == 200
    counts = resp.get_json()["counts"]
    after = table_counts(app.config["DB_PATH"])
    skip = {"activity_log", "assistant_messages"}
    diff = {t: (seed_counts[t], after.get(t)) for t in seed_counts if t not in skip and seed_counts[t] != after.get(t)}
    assert not diff, f"reset did not restore seed row counts (seed, now): {diff}"
    for t, n in counts.items():
        assert after.get(t) == n, f"reset reported {t}={n} but table has {after.get(t)}"
    assert after["ai_runs"] == 0
    assert not hero_dir.exists(), "reset must clear uploads of deleted initiatives"
    assert c.get("/api/initiatives").get_json()["total"] == 8
    assert create_plain_initiative(c, "QA First After Reset") and \
        c.get("/api/initiatives?q=QA First After Reset").get_json()["items"][0]["rddc"] == "RDDC-24817"


def test_hero_15_fast_forward_is_idempotent(qa_app_factory):
    app = qa_app_factory()
    c = app.test_client()
    first = c.post("/api/admin/fast-forward-hero").get_json()
    assert all(s["ok"] for s in first["steps"]) and len(first["steps"]) == 6
    snap = table_counts(app.config["DB_PATH"])
    h1 = c.get(f"/api/initiatives/{first['initiative_id']}/health").get_json()
    second = c.post("/api/admin/fast-forward-hero").get_json()
    assert second["initiative_id"] == first["initiative_id"] and second["rddc"] == "RDDC-24817"
    assert all(s["ok"] for s in second["steps"])
    assert not any("ai_run_id" in s for s in second["steps"]), "second run must not create AI runs"
    after = table_counts(app.config["DB_PATH"])
    changed = {t: (snap[t], after[t]) for t in snap if t != "activity_log" and snap[t] != after[t]}
    assert not changed, f"second fast-forward changed data: {changed}"
    h2 = c.get(f"/api/initiatives/{first['initiative_id']}/health").get_json()
    assert h1["overall"] == h2["overall"] == "Amber"
    assert h2["dimensions"]["resources"]["rag"] == "Red"


def test_hero_16_fast_forward_continues_from_partial_state(qa_app_factory):
    app = qa_app_factory()
    c = app.test_client()
    people = resource_ids(c)
    iid = c.post("/api/initiatives", json={"dc_intake": "DCI-3391", "dc_pm_id": people["Grace Ellingham"],
                                           "dc_sa_id": people["Sana Whitfield"]}).get_json()["initiative"]["id"]
    out = c.post("/api/admin/fast-forward-hero").get_json()
    assert out["initiative_id"] == iid
    assert all(s["ok"] for s in out["steps"]), out["steps"]
    assert len(c.get(f"/api/initiatives/{iid}/tasks").get_json()["items"]) == 14


# ===================================================================== 5. robustness
SQLI = ["' OR 1=1--", "\" OR \"\"=\"", "'; DROP TABLE initiatives; --", "%", "_", "\\",
        "') UNION SELECT name FROM sqlite_master--"]


@pytest.mark.parametrize("path", ["/api/initiatives?q={}", "/api/dc-intakes?q={}", "/api/decisions?q={}",
                                  "/api/lessons?q={}", "/api/documents?q={}"])
def test_sqli_in_search_is_literal(client, path):
    total = client.get(path.format("")).get_json()["total"]
    assert total > 0
    for s in SQLI:
        resp = client.get(path.format(s.replace("%", "%25").replace("&", "%26").replace("#", "%23")))
        assert resp.status_code == 200, (s, resp.get_json())
        assert resp.get_json()["total"] == 0, f"search {s!r} matched rows: wildcard/injection not escaped"
    assert client.get("/api/initiatives").get_json()["total"] == 8, "initiatives table damaged"


def test_sqli_in_name_is_stored_literally(client):
    name = "Robert'); DROP TABLE initiatives;--"
    iid = create_plain_initiative(client, name)
    assert client.get(f"/api/initiatives/{iid}").get_json()["initiative"]["name"] == name
    found = client.get("/api/initiatives", query_string={"q": "DROP TABLE"}).get_json()["items"]
    assert [i["name"] for i in found] == [name]
    assert client.get("/api/initiatives").get_json()["total"] == 9


XSS = ["<script>alert(1)</script>", "<img src=x onerror=alert(1)>", "\"><svg/onload=alert(1)>", "javascript:alert(1)"]


@pytest.mark.parametrize("payload", XSS)
def test_xss_strings_stored_verbatim_returned_as_json_data(client, payload):
    iid = create_plain_initiative(client, payload[:80])
    r = client.post(f"/api/initiatives/{iid}/risks", json={"title": payload, "category": "Technical", "severity": 2,
                                                          "likelihood": 2, "mitigation": payload})
    assert r.status_code == 201
    d = client.post("/api/decisions", json={"title": payload, "decision": payload, "initiative_id": iid})
    assert d.status_code == 201
    for path in (f"/api/initiatives/{iid}", "/api/initiatives", f"/api/risks?initiative_id={iid}", "/api/decisions",
                 "/api/portfolio"):
        resp = client.get(path)
        assert resp.status_code == 200 and resp.content_type.startswith("application/json"), path
        assert payload[:80] in json.dumps(resp.get_json(), ensure_ascii=False), f"{path} altered the stored text"
    bundle = client.get(f"/api/initiatives/{iid}").get_json()
    assert bundle["initiative"]["name"] == payload[:80]
    assert bundle["risks"][0]["title"] == payload


def test_xss_in_url_is_reflected_only_as_json(client):
    resp = client.get("/api/dc-intakes/<script>alert(1)</script>")
    assert_error(resp, 404, "not_found")
    assert not resp.content_type.startswith("text/html")


def test_export_escapes_formula_injection(client):
    import openpyxl
    evil = ['=HYPERLINK("http://evil.example","x")', "+cmd|' /C calc'!A0", "-2+3+cmd|' /C calc'!A0", "@SUM(1+1)"]
    assert client.put("/api/initiatives/4", json={"comments": evil[0], "description": evil[1]}).status_code == 200
    assert client.post("/api/initiatives/4/risks", json={"title": evil[3], "category": "Technical", "severity": 2,
                                                         "likelihood": 2, "mitigation": evil[2]}).status_code == 201
    tid = build_ctx(client)["tid"]
    assert client.put(f"/api/tasks/{tid}", json={"comments": evil[0], "step": evil[2]}).status_code == 200
    for url in ("/api/export/demo-view.xlsx?initiative_id=4", "/api/export/portfolio.xlsx"):
        resp = client.get(url)
        assert resp.status_code == 200
        wb = openpyxl.load_workbook(io.BytesIO(resp.data))
        for ws in wb.worksheets:
            for row in ws.iter_rows():
                for cell in row:
                    v = cell.value
                    if isinstance(v, str) and any(e in v for e in evil):
                        assert cell.data_type != "f" and not v.startswith(("=", "+", "-", "@")), \
                            f"{url} {ws.title}!{cell.coordinate} holds a live formula: {v!r}"
    csv_text = client.get("/api/export/portfolio.csv").data.decode("utf-8-sig")
    for line in csv_text.splitlines():
        for cell in line.split(","):
            assert not cell.strip('"').startswith(("=", "+", "@")) or cell.strip('"').startswith("'"), line


def test_portfolio_csv_content_type_is_well_formed(client):
    resp = client.get("/api/export/portfolio.csv")
    assert resp.status_code == 200
    ct = resp.headers["Content-Type"]
    assert ct.lower().count("charset") == 1, f"malformed Content-Type header: {ct!r}"


def _upload(client, iid, name, data, kind="sa_doc"):
    return client.post(f"/api/initiatives/{iid}/attachments", data={"file": (io.BytesIO(data), name), "kind": kind},
                       content_type="multipart/form-data")


def _files_under(folder: Path) -> set:
    return {str(p.relative_to(folder)) for p in folder.rglob("*") if p.is_file()} if folder.exists() else set()


def test_upload_exe_renamed_pdf_is_422_and_not_kept(app, client):
    folder = Path(app.config["UPLOAD_DIR"])
    before = _files_under(folder)
    resp = _upload(client, 4, "invoice.pdf", b"MZ\x90\x00\x03\x00\x00\x00" + b"\x00" * 4000 + b"This program cannot")
    body = assert_error(resp, 422)
    assert body["error"]["code"] in ("unreadable_file", "validation")
    assert _files_under(folder) == before, "rejected upload left a file on disk"
    assert client.get("/api/initiatives/4/attachments").get_json()["total"] == 1


def test_upload_zero_bytes_is_422(app, client):
    folder = Path(app.config["UPLOAD_DIR"])
    before = _files_under(folder)
    assert_error(_upload(client, 4, "empty.docx", b""), 422)
    assert _files_under(folder) == before


def test_upload_over_10mb_is_413_json(app, client):
    folder = Path(app.config["UPLOAD_DIR"])
    before = _files_under(folder)
    assert_error(_upload(client, 4, "big.txt", b"a" * (10 * 1024 * 1024 + 1), kind="other"), 413, "payload_too_large")
    assert _files_under(folder) == before


def test_upload_exactly_10mb_is_accepted(client):
    """Master §1 Safety and contracts §2: uploads up to 10 MB are accepted (≤10 MB)."""
    resp = _upload(client, 4, "exactly_10mb.txt", b"a" * (10 * 1024 * 1024), kind="other")
    assert resp.status_code == 201, resp.get_json()


@pytest.mark.parametrize("name", ["../../app.py", "../../evil.md", "..\\..\\evil.md", "/etc/passwd.md", "....//x.md"])
def test_upload_path_traversal_filename_is_sanitised(app, client, name):
    upload_root = Path(app.config["UPLOAD_DIR"]).resolve()
    app_py = ROOT / "app" / "__init__.py"
    digest = hashlib.sha256(app_py.read_bytes()).hexdigest()
    resp = _upload(client, 4, name, b"# Traversal probe\nThis text is long enough to extract.\n", kind="other")
    assert resp.status_code in (201, 422), resp.get_json()
    if resp.status_code == 201:
        att = resp.get_json()["attachment"]
        assert "/" not in att["filename"] and "\\" not in att["filename"] and ".." not in att["filename"]
        stored = (upload_root / att["stored_path"]).resolve()
        assert upload_root in stored.parents and stored.is_file()
    else:
        assert_error(resp, 422)
    assert hashlib.sha256(app_py.read_bytes()).hexdigest() == digest
    assert not (ROOT / "evil.md").exists() and not (upload_root.parent / "evil.md").exists()


def test_dependency_cycle_is_422_and_nothing_written(client):
    a = client.post("/api/initiatives/4/tasks", json={"wbs_code": "WBS-971", "step": "Cycle A",
                                                      "planned_start": "2026-11-02", "planned_end": "2026-11-03"})
    a_id = a.get_json()["task"]["id"]
    b = client.post("/api/initiatives/4/tasks", json={"wbs_code": "WBS-972", "step": "Cycle B", "depends_on": [a_id],
                                                      "planned_start": "2026-11-04", "planned_end": "2026-11-05"})
    b_id = b.get_json()["task"]["id"]
    resp = client.put(f"/api/tasks/{a_id}", json={"depends_on": [b_id]})
    assert_error(resp, 422, "validation")
    tasks = {t["id"]: t for t in client.get("/api/initiatives/4/tasks").get_json()["items"]}
    assert tasks[a_id]["depends_on"] == [], "cycle edge was persisted despite the 422"
    bulk = client.put("/api/initiatives/4/tasks/bulk", json={"tasks": [{"id": a_id, "depends_on": [b_id]}]})
    assert_error(bulk, 422, "validation")
    self_dep = client.put(f"/api/tasks/{a_id}", json={"depends_on": [a_id]})
    assert_error(self_dep, 422, "validation")


@pytest.mark.parametrize("method, path, body", [
    ("POST", "/api/initiatives/4/tasks", {"wbs_code": "WBS-981", "step": "x", "planned_start": "2026-11-10",
                                          "planned_end": "2026-11-09"}),
    ("PUT", "/api/tasks/{tid}", {"planned_end": "2020-01-01"}),
    ("PUT", "/api/initiatives/4/tasks/bulk", {"tasks": [{"id": "{tid}", "planned_start": "2026-12-10",
                                                         "planned_end": "2026-12-01"}]}),
    ("POST", "/api/initiatives/5/change-requests", {"crq_start": "2027-02-20T06:00", "crq_end": "2027-02-20T02:00"}),
    ("PUT", "/api/change-requests/4", {"crq_end": "2020-01-01T00:00"}),
])
def test_end_before_start_is_422(client, method, path, body):
    tid = build_ctx(client)["tid"]
    body = json.loads(json.dumps(body).replace('"{tid}"', str(tid)))
    assert_error(client.open(path.format(tid=tid), method=method, json=body), 422, "validation")


def test_concurrent_double_apply_never_duplicates(app, client, monkeypatch):
    """Two Accept clicks on the same ai_run racing: one must win; the other 409 (or be a no-op). Never duplicate rows.
    get_run is wrapped with a short delay to make the race window deterministic (timing only, no logic change)."""
    from app.ai import apply as ai_apply

    run = client.post("/api/initiatives/4/ai/risks", json={}).get_json()
    n_proposed = len(run["output"]["risks"])
    before = client.get("/api/risks?initiative_id=4").get_json()["total"]
    original = ai_apply.get_run

    def slow_get_run(run_id):
        row = original(run_id)
        time.sleep(0.25)
        return row

    monkeypatch.setattr(ai_apply, "get_run", slow_get_run)
    barrier, results = threading.Barrier(2), []

    def accept():
        c = app.test_client()
        barrier.wait()
        resp = c.post(f"/api/ai-runs/{run['ai_run_id']}/apply", json={})
        results.append(resp.status_code)

    threads = [threading.Thread(target=accept) for _ in range(2)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(30)
    monkeypatch.setattr(ai_apply, "get_run", original)
    after = client.get("/api/risks?initiative_id=4").get_json()["total"]
    assert sorted(results) in ([200, 409], [200, 200]), results
    assert after == before + n_proposed, f"double apply inserted {after - before} risks for {n_proposed} proposed"


# ---------------------------------------------------------------- live AI fallback
class _FakeMessages:
    def __init__(self, behaviour):
        self.behaviour = behaviour

    def create(self, **kwargs):
        if self.behaviour == "raise":
            raise RuntimeError("upstream 529 overloaded")
        if self.behaviour == "timeout":
            raise TimeoutError("read timed out")
        if self.behaviour == "bad_tool_json":
            block = types.SimpleNamespace(type="tool_use", name=kwargs["tools"][-1]["name"], input="{not json", id="t1")
            return types.SimpleNamespace(content=[block], stop_reason="tool_use", usage=None)
        if self.behaviour == "empty":
            return types.SimpleNamespace(content=[], stop_reason="end_turn", usage=None)
        raise AssertionError(self.behaviour)


class _FakeAnthropic:
    seen: ClassVar[dict] = {}

    def __init__(self, behaviour, **kwargs):
        self.behaviour = behaviour
        _FakeAnthropic.seen.update(kwargs)

    def with_options(self, **kwargs):
        _FakeAnthropic.seen["with_options"] = kwargs
        return self

    @property
    def beta(self):
        return types.SimpleNamespace(messages=_FakeMessages(self.behaviour))


@pytest.fixture
def live_client(qa_app_factory, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-qa-fake-key")
    app = qa_app_factory(AI_MODE="live", HAS_API_KEY=True)
    c = app.test_client()
    resp = c.put("/api/settings", json={"ai_mode": "live"})
    assert resp.status_code == 200 and resp.get_json()["live_available"] is True
    return c


LIVE_CALLS = [("POST", "/api/initiatives/4/ai/risks", {}), ("POST", "/api/ai/exec-summary", {}),
              ("POST", "/api/assistant/chat", {"message": "Which projects are red?"})]


@pytest.mark.parametrize("behaviour", ["raise", "timeout", "empty", "bad_tool_json", "client_ctor_fails"])
@pytest.mark.parametrize("method, path, body", LIVE_CALLS, ids=[p for _, p, _ in LIVE_CALLS])
def test_live_failure_falls_back_within_22s(live_client, monkeypatch, behaviour, method, path, body):
    import anthropic

    if behaviour == "client_ctor_fails":
        def ctor(**kwargs):
            raise RuntimeError("could not build HTTP client (bad proxy settings)")
        monkeypatch.setattr(anthropic, "Anthropic", ctor)
    else:
        monkeypatch.setattr(anthropic, "Anthropic", lambda **kw: _FakeAnthropic(behaviour, **kw))
    t0 = time.monotonic()
    resp = live_client.open(path, method=method, json=body)
    elapsed = time.monotonic() - t0
    assert resp.status_code == 200, f"{behaviour}: {resp.status_code} {resp.get_json()}"
    j = resp.get_json()
    assert j["mode"] == "live_fallback" and j["mode_label"] == "Live → Simulated", j["mode"]
    assert elapsed < 22


def test_live_client_configured_timeout_20s_no_retries(live_client, monkeypatch):
    import anthropic

    _FakeAnthropic.seen = {}
    monkeypatch.setattr(anthropic, "Anthropic", lambda **kw: _FakeAnthropic("raise", **kw))
    assert live_client.post("/api/initiatives/4/ai/risks", json={}).status_code == 200
    assert _FakeAnthropic.seen.get("max_retries") == 0
    assert 0 < _FakeAnthropic.seen.get("timeout", 99) <= 20
    assert 0 < _FakeAnthropic.seen["with_options"]["timeout"] <= 20


def test_live_fallback_warning_and_key_not_leaked(live_client, monkeypatch):
    import anthropic

    monkeypatch.setattr(anthropic, "Anthropic", lambda **kw: _FakeAnthropic("raise", **kw))
    resp = live_client.post("/api/initiatives/4/ai/risks", json={})
    j = resp.get_json()
    assert any("Live" in w for w in j["warnings"]), j["warnings"]
    for path in (f"/api/ai-runs/{j['ai_run_id']}", "/api/settings", "/api/health", "/api/ai-runs"):
        assert "sk-ant-qa-fake-key" not in live_client.get(path).get_data(as_text=True), path


# ===================================================================== 6. determinism
def _deterministic_calls(c) -> dict:
    out = {}
    ff = c.post("/api/admin/fast-forward-hero").get_json()
    hero = ff["initiative_id"]
    for s in ff["steps"]:
        if "ai_run_id" in s:
            run = c.get(f"/api/ai-runs/{s['ai_run_id']}").get_json()
            out[f"ff:{s['step']}"] = {k: run[k] for k in ("feature", "mode", "fixture_key", "variant_index",
                                                           "confidence", "sources", "warnings", "output")}
    calls = [(f"/api/initiatives/{hero}/ai/{f}", {}) for f in ("intake-analysis", "rebalance", "risks", "exec-summary",
                                                               "l2-estimate")]
    calls += [(f"/api/initiatives/{i}/ai/{f}", {}) for i, f in ((7, "change-summary"), (6, "wbs"), (5, "resources"),
                                                                (4, "cr-compliance"))]
    calls += [(f"/api/ai/{slug}", body) for slug, body in sorted(GLOBAL_FEATURE_BODY.items())]
    for path, body in calls:
        j = c.post(path, json=body).get_json()
        out[path] = {k: j.get(k) for k in ("feature", "mode", "fixture_key", "variant_index", "confidence", "sources",
                                           "warnings", "output")}
    for q in ("Who is over-allocated?", "Summarise RDDC-24817", "What is the weather in Toronto?"):
        j = c.post("/api/assistant/chat", json={"message": q}).get_json()
        out[f"chat:{q}"] = {k: j[k] for k in ("answer_md", "citations", "suggested_actions", "follow_ups", "mode")}
    out["l2"] = c.post(f"/api/initiatives/{hero}/l2/calculate").get_json()
    return out


def test_simulated_ai_identical_across_fresh_databases(qa_app_factory):
    a = _deterministic_calls(qa_app_factory().test_client())
    b = _deterministic_calls(qa_app_factory().test_client())
    diffs = [k for k in a if a[k] != b.get(k)]
    assert not diffs, f"simulated output differs between two fresh DBs: {diffs}"


_SUBPROCESS = r"""
import json, os, sys, tempfile, logging
logging.disable(logging.CRITICAL)
sys.path.insert(0, os.getcwd())
sys.path.insert(0, os.path.join(os.getcwd(), "tests", "qa"))
from app import create_app, db
from app.seed.seed import reset_database
import test_api_contract as T
d = tempfile.mkdtemp()
app = create_app(DB_PATH=d + "/x.db", UPLOAD_DIR=d + "/u", TESTING=True, TODAY="2026-10-19", AI_MODE="simulated",
                 HAS_API_KEY=False)
with app.app_context():
    reset_database(db.get_db(), upload_dir=d + "/u", today="2026-10-19", ai_mode="simulated")
print("@@" + json.dumps(T._deterministic_calls(app.test_client()), sort_keys=True))
"""


def test_simulated_ai_identical_across_processes_and_hash_seeds():
    outs = []
    for seed in ("0", "4242"):
        env = {k: v for k, v in os.environ.items() if k != "ANTHROPIC_API_KEY"}
        env.update(PYTHONHASHSEED=seed, BMO_TODAY="2026-10-19", BMO_AI_MODE="simulated")
        proc = subprocess.run([sys.executable, "-c", _SUBPROCESS], cwd=ROOT, env=env, capture_output=True, text=True,
                              timeout=300, check=False)
        assert proc.returncode == 0, proc.stderr[-2000:]
        payload = next(line for line in proc.stdout.splitlines() if line.startswith("@@"))[2:]
        outs.append(json.loads(payload))
    diffs = [k for k in outs[0] if outs[0][k] != outs[1].get(k)]
    assert not diffs, f"simulated output depends on the process/hash seed: {diffs}"


# ===================================================================== 7. round 2 contract (docs/qa/round2_decisions.md)
def _slots_of(client, iid):
    sessions = client.get("/api/grooming/sessions").get_json()["items"]
    return [(s["id"], s["session_date"], sl["status"]) for s in sessions for sl in s["slots"] if sl["initiative_id"] == iid]


def test_r3_groomed_before_session_is_adhoc_walkthrough_and_frees_slot(client):
    """R3 N2: on 19 Oct, before the Thu 22 Oct slot, grooming is recorded as an ad-hoc walk-through today."""
    assert [x[1] for x in _slots_of(client, 8)] == ["2026-10-22"]
    assert client.get("/api/initiatives/8").get_json()["initiative"]["stage"] == "Grooming"
    resp = client.post("/api/initiatives/8/groomed")
    assert resp.status_code == 200, resp.get_json()
    body = resp.get_json()
    assert body["initiative"]["stage"] == "Solution"
    assert "ad-hoc walk-through today (Mon 19 Oct 2026)" in body["message"], body["message"]
    assert "Stage moved Grooming → Solution" in body["message"], body["message"]
    assert _slots_of(client, 8) == [], "the future slot must be freed, not marked Discussed"
    queued = client.get("/api/outbox?status=Queued&initiative_id=8&rule=grooming_invite").get_json()["items"]
    assert queued == [], "queued grooming invites for the freed slot must be dismissed"
    assert_error(client.post("/api/initiatives/8/groomed"), 409, "conflict")  # already past grooming


def test_r3_groomed_on_session_date_marks_slot_discussed(client):
    """R3 N2: on/after the session date the old behaviour holds (slot Discussed, 'Groomed in session …')."""
    iid = create_plain_initiative(client, "QA Grooming Same Day")
    (sid, sdate, _), = _slots_of(client, iid)
    assert client.put("/api/settings", json={"demo_today": sdate}).status_code == 200
    resp = client.post(f"/api/initiatives/{iid}/groomed")
    assert resp.status_code == 200, resp.get_json()
    body = resp.get_json()
    assert body["session_id"] == sid and body["initiative"]["stage"] == "Solution"
    assert body["message"].startswith("Groomed in session"), body["message"]
    assert _slots_of(client, iid) == [(sid, sdate, "Discussed")]


def test_r2_groomed_unknown_id_and_wrong_stage(client):
    assert_error(client.post("/api/initiatives/999999/groomed"), 404, "not_found")
    assert_error(client.post("/api/initiatives/4/groomed"), 409, "conflict")  # RDDC-24601 is in QA
    assert_error(client.post("/api/initiatives/6/groomed"), 409, "conflict")  # Estimation


def _hero_planned(client) -> int:
    ff = client.post("/api/admin/fast-forward-hero").get_json()
    assert all(s["ok"] for s in ff["steps"]), ff["steps"]
    return ff["initiative_id"]


WRITE_TABLES = ("initiatives", "initiative_components", "wbs_tasks", "wbs_dependencies", "allocations", "risks",
                "change_requests", "decisions", "notifications", "grooming_slots", "attachments")


@pytest.mark.parametrize("question, intent", [
    ("How many hours are left on PRN-71840 and when does funding run out?", "prn_status"),
    ("Which CRQs are not ready for STO go/no-go this week?", "crq_sto_readiness"),
    ("What happens to RDDC-24817 if CIAM approval slips two weeks?", "what_if_slip"),
    ("What if WBS-210 on RDDC-24817 slips 5 business days?", "what_if_slip"),
])
def test_r2_new_assistant_intents_answer_without_db_writes(app, client, question, intent):
    hero = _hero_planned(client)
    tasks_before = client.get(f"/api/initiatives/{hero}/tasks").get_json()["items"]
    health_before = client.get(f"/api/initiatives/{hero}/health").get_json()
    before = table_counts(app.config["DB_PATH"])
    resp = client.post("/api/assistant/chat", json={"message": question})
    assert resp.status_code == 200, resp.get_json()
    j = resp.get_json()
    k_chat(j, {})
    assert j["intent"] == intent, (question, j["intent"])
    assert isinstance(j["deterministic"], bool)
    after = table_counts(app.config["DB_PATH"])
    changed = {t: (before[t], after[t]) for t in WRITE_TABLES if before[t] != after[t]}
    assert not changed, f"assistant {intent} wrote to {changed}"
    assert client.get(f"/api/initiatives/{hero}/tasks").get_json()["items"] == tasks_before
    assert client.get(f"/api/initiatives/{hero}/health").get_json()["overall"] == health_before["overall"]
    if intent == "prn_status":
        assert "PRN-71840" in j["answer_md"]
    if intent == "what_if_slip" and "CIAM" in question:
        assert "WBS-230" in j["answer_md"] and "DC-2702" in j["answer_md"]


def test_r2_what_if_slip_reports_red_when_train_missed(client):
    """Independent check: the master §6.2.6 pin says WBS-210 +5 bd → Readiness 2027-02-24 → misses DC-2702."""
    _hero_planned(client)
    j = client.post("/api/assistant/chat", json={"message": "What if WBS-210 on RDDC-24817 slips 5 business days?"})
    text = j.get_json()["answer_md"]
    assert "24 Feb 2027" in text and "misses DC-2702" in text, text


def test_r2_deterministic_flag_in_envelopes(client):
    _hero_planned(client)
    client.post("/api/initiatives/9/change-requests/draft", json={})
    seen = {}
    for path, body in (("/api/initiatives/9/ai/cr-compliance", {}), ("/api/initiatives/9/ai/risks", {}),
                       ("/api/ai/intake-analysis", {"options": {"name": "Commercial sweep alerts",
                                                               "description": "Real-time sweep alerts."}})):
        j = client.post(path, json=body).get_json()
        check_airun(j)
        assert isinstance(j.get("deterministic"), bool), f"{path}: AiRun has no boolean `deterministic`"
        expected = j["feature"] == "cr_compliance" or j["mode"] == "simulated_generated"
        assert j["deterministic"] is expected, (path, j["mode"], j["deterministic"])
        assert client.get(f"/api/ai-runs/{j['ai_run_id']}").get_json()["deterministic"] is expected
        seen[j["ai_run_id"]] = expected
    for item in client.get("/api/ai-runs?limit=50").get_json()["items"]:
        assert isinstance(item.get("deterministic"), bool)
        if item["id"] in seen:
            assert item["deterministic"] is seen[item["id"]]
    chat = client.post("/api/assistant/chat", json={"message": "How many hours are left on PRN-71840?"}).get_json()
    assert chat["deterministic"] is (chat["mode"] == "simulated_generated")


def test_r2_not_due_yet_excluded_from_compliance_score(client):
    _hero_planned(client)
    cr = client.post("/api/initiatives/9/change-requests/draft", json={}).get_json()
    comp = cr["compliance"]
    statuses = [f["status"] for f in comp["findings"]]
    assert set(statuses) <= {"Pass", "Fail", "Warn", "Not due yet"}, set(statuses)
    passes, fails, warns = statuses.count("Pass"), statuses.count("Fail"), statuses.count("Warn")
    not_due = statuses.count("Not due yet")
    assert not_due >= 2
    assert (comp["passed"], comp["checked"], comp["not_due"]) == (passes, passes + fails + warns, not_due)
    for f in comp["findings"]:
        if f["status"] == "Not due yet":
            assert ISO_DATE.match(f.get("due_date") or ""), f
            assert f.get("reason", "").startswith("Due by"), f
    assert [f["code"] for f in comp["flags"]] == ["CR-11"]
    ai = client.post("/api/initiatives/9/ai/cr-compliance", json={}).get_json()["output"]
    ai_status = [f["status"] for f in ai["findings"]]
    p, d = ai_status.count("Pass"), ai_status.count("Fail") + ai_status.count("Warn")
    assert ai["score"] == round(100 * p / (p + d)), (ai["score"], p, d)
    assert ai_status == statuses, "AI findings disagree with the engine"


def test_r2_ai_not_due_findings_carry_due_date(client):
    """Decision 3: "Not due yet" carries due_date. contracts: CR_COMPLIANCE.findings[].due_date mirrors the engine."""
    _hero_planned(client)
    cr = client.post("/api/initiatives/9/change-requests/draft", json={}).get_json()
    engine = {f["rule_id"]: f.get("due_date") for f in cr["compliance"]["findings"] if f["status"] == "Not due yet"}
    ai = client.post("/api/initiatives/9/ai/cr-compliance", json={}).get_json()["output"]
    got = {f["rule_id"]: f.get("due_date") for f in ai["findings"] if f["status"] == "Not due yet"}
    assert got == engine, f"AI Not-due-yet due dates {got} != engine {engine}"


def test_r2_suggest_resources_apply_never_replaces_existing_unless_selected(client):
    hero = _hero_planned(client)
    before = {t["wbs_code"]: t["resource_id"] for t in client.get(f"/api/initiatives/{hero}/tasks").get_json()["items"]}
    assert before["WBS-100"] == 14  # Sana stays on WBS-100 after fast-forward (decision 9)
    run = client.post(f"/api/initiatives/{hero}/ai/resources", json={}).get_json()
    recs = run["output"]["recommendations"]
    # Make every recommendation point at someone other than the current assignee.
    edited = json.loads(json.dumps(run["output"]))
    retargeted = 0
    for r in edited["recommendations"]:
        other = [cand["resource_id"] for cand in r.get("candidates", []) if cand["resource_id"] != before.get(r["wbs_code"])]
        if other and before.get(r["wbs_code"]) is not None:
            r["recommended_resource_id"] = other[0]
            retargeted += 1
    assert retargeted, "no recommendation could be pointed at a different candidate"
    resp = client.post(f"/api/ai-runs/{run['ai_run_id']}/apply", json={"edited_output": edited})
    assert resp.status_code == 200, resp.get_json()
    after = {t["wbs_code"]: t["resource_id"] for t in client.get(f"/api/initiatives/{hero}/tasks").get_json()["items"]}
    replaced = {c: (before[c], after[c]) for c in before if before[c] is not None and before[c] != after[c]}
    assert not replaced, f"unselected Accept replaced existing assignments: {replaced}"
    # Selecting a row does replace it.
    run2 = client.post(f"/api/initiatives/{hero}/ai/resources", json={}).get_json()
    edited2 = json.loads(json.dumps(run2["output"]))
    idx, rec = next((i, r) for i, r in enumerate(edited2["recommendations"])
                    if after.get(r["wbs_code"]) is not None
                    and any(cand["resource_id"] != after[r["wbs_code"]] for cand in r.get("candidates", [])))
    target = next(cand["resource_id"] for cand in rec["candidates"] if cand["resource_id"] != after[rec["wbs_code"]])
    rec["recommended_resource_id"] = target
    resp = client.post(f"/api/ai-runs/{run2['ai_run_id']}/apply", json={"selected": [idx], "edited_output": edited2})
    assert resp.status_code == 200, resp.get_json()
    final = {t["wbs_code"]: t["resource_id"] for t in client.get(f"/api/initiatives/{hero}/tasks").get_json()["items"]}
    code = rec["wbs_code"]
    assert final[code] == target, f"selected row {code} was not replaced"
    assert {c: final[c] for c in final if c != code} == {c: after[c] for c in after if c != code}
    assert recs  # proposal was non-empty


def test_r2_hidden_bau_initiative_never_exposed(client):
    assert all(i["id"] > 0 for i in client.get("/api/initiatives").get_json()["items"])
    assert all(p["id"] > 0 and p["rddc"] != "BAU-FY27" for p in client.get("/api/portfolio").get_json()["projects"])
    assert all(r["initiative_id"] > 0 for r in client.get("/api/portfolio/gantt").get_json()["rows"])
    assert "BAU-FY27" not in client.get("/api/export/portfolio.csv").data.decode("utf-8-sig")
    assert_error(client.get("/api/initiatives/-1"), 404)


def test_r2_crq_draft_dry_run_writes_nothing_and_keeps_number(app, client):
    """B1 round 2: `dry_run: true` previews the draft without a row and without consuming app_settings.crq_next."""
    _hero_planned(client)
    before = table_counts(app.config["DB_PATH"])["change_requests"]
    resp = client.post("/api/initiatives/9/change-requests/draft", json={"dry_run": True})
    assert resp.status_code in (200, 201), resp.get_json()
    preview = resp.get_json()
    assert preview["crq_number"] == "CRQ000001052216"
    assert table_counts(app.config["DB_PATH"])["change_requests"] == before, "dry run inserted a CRQ row"
    real = client.post("/api/initiatives/9/change-requests/draft", json={}).get_json()
    assert real["crq_number"] == "CRQ000001052216", "dry run consumed the CRQ number"
    assert table_counts(app.config["DB_PATH"])["change_requests"] == before + 1


# ===================================================================== 8. round 3 contract (round3_L6_director.md)
def test_r3_cr_compliance_rules_check_and_sto_not_requested(client):
    _hero_planned(client)
    cr = client.post("/api/initiatives/9/change-requests/draft", json={}).get_json()
    detail = cr["compliance"]["sto_readiness_detail"]
    # T-5 business days before Sat 20 Feb 2027, skipping Family Day Mon 15 Feb → Thu 11 Feb 2027
    assert detail["status"] == "Not requested" and detail["suggest_from"] == "2027-02-11", detail
    assert "Not requested" in detail["label"] and "11 Feb 2027" in detail["label"], detail
    assert cr["compliance"]["sto_readiness"] == "Not requested"
    ai = client.post("/api/initiatives/9/ai/cr-compliance", json={}).get_json()
    check_airun(ai, "cr_compliance")  # asserts "Rules check" + deterministic
    assert ai["output"]["sto_readiness"] == "Not requested"
    listed = next(r for r in client.get("/api/ai-runs?limit=5").get_json()["items"] if r["id"] == ai["ai_run_id"])
    assert listed["mode_label"] == "Rules check" and listed["deterministic"] is True


def test_r3_sto_readiness_detail_on_crq_payloads_and_ai_status_matches_engine(client):
    """Coordinator ruling on QA-A-11: the detail lives on CRQ/compliance payloads; AI keeps the status string."""
    _hero_planned(client)
    cid = client.post("/api/initiatives/9/change-requests/draft", json={}).get_json()["id"]
    payloads = [client.get(f"/api/change-requests/{cid}").get_json(),
                next(x for x in client.get("/api/change-requests?initiative_id=9").get_json()["items"] if x["id"] == cid),
                next(x for x in client.get("/api/initiatives/9").get_json()["change_requests"] if x["id"] == cid)]
    for cr in payloads:
        detail = cr["compliance"]["sto_readiness_detail"]
        has_keys(detail, {"status", "suggest_from", "label"}, "sto_readiness_detail")
        assert detail["suggest_from"] == "2027-02-11" and detail["status"] == "Not requested", detail
    engine_status = payloads[0]["compliance"]["sto_readiness"]
    ai = client.post("/api/initiatives/9/ai/cr-compliance", json={}).get_json()["output"]
    assert ai["sto_readiness"] == engine_status == "Not requested", (ai["sto_readiness"], engine_status)


@pytest.mark.parametrize("path", ["/api/prn/PRN-71840/burndown", "/api/initiatives/2/burndown"])
def test_r3_burn_rate_is_last_three_charged_months_average(client, path):
    charges = client.get("/api/initiatives/2").get_json()["prn"]["charges"]
    charged = [c for c in sorted(charges, key=lambda c: c["month"]) if c["month"] <= "2026-10" and c["charged_hours"]]
    last3 = charged[-3:]
    expected = round(sum(c["charged_hours"] for c in last3) / len(last3), 1)
    b = client.get(path).get_json()
    check_burndown(b)
    assert b["burn_rate"] == pytest.approx(expected, abs=0.05), (b["burn_rate"], expected)
    assert b["burn_rate_window"] == "3-month average"
    assert b["burn_rate_months"] == [c["month"] for c in last3]


def test_r3_burn_rate_with_no_charges(client):
    b = client.get("/api/prn/PRN-77310/burndown").get_json()
    check_burndown(b)
    assert b["burn_rate"] in (0, 0.0, None) and b["burn_rate_window"] == "3-month average"


def test_r3_prn_overrun_intent_matches_burndown_and_writes_nothing(app, client):
    overrun = {p["prn_code"] for p in client.get("/api/prns").get_json()["items"] if p["status"] == "overrun"}
    before = table_counts(app.config["DB_PATH"])
    j = client.post("/api/assistant/chat", json={"message": "Which PRNs are forecast to overrun?"}).get_json()
    k_chat(j, {})
    assert j["intent"] == "prn_overrun"
    mentioned = set(re.findall(r"PRN-\d{5}", j["answer_md"]))
    assert mentioned == overrun, (mentioned, overrun)
    assert {c["id"] for c in j["citations"] if c["type"] == "prn"} == overrun
    after = table_counts(app.config["DB_PATH"])
    assert {t: after[t] for t in WRITE_TABLES} == {t: before[t] for t in WRITE_TABLES}
    assert not _bad_citations(client, j, _existing_records(client))


def test_r3_resources_selected_row_assigns_recommended_person(client):
    hero = _hero_planned(client)
    current = {t["wbs_code"]: t["resource_id"] for t in client.get(f"/api/initiatives/{hero}/tasks").get_json()["items"]}
    run = client.post(f"/api/initiatives/{hero}/ai/resources", json={"options": {"wbs_code": "WBS-100"}}).get_json()
    recs = run["output"]["recommendations"]
    assert [r["wbs_code"] for r in recs] == ["WBS-100"], "options.wbs_code filter not honoured"
    want = recs[0].get("recommended_resource_id") or recs[0]["candidates"][0]["resource_id"]
    resp = client.post(f"/api/ai-runs/{run['ai_run_id']}/apply", json={"selected": [0]})
    assert resp.status_code == 200, resp.get_json()
    after = {t["wbs_code"]: t["resource_id"] for t in client.get(f"/api/initiatives/{hero}/tasks").get_json()["items"]}
    assert after["WBS-100"] == want
    assert {c: after[c] for c in after if c != "WBS-100"} == {c: current[c] for c in current if c != "WBS-100"}


def test_r3_resources_selected_row_without_recommendation_takes_top_candidate(client):
    hero = _hero_planned(client)
    current = {t["wbs_code"]: t["resource_id"] for t in client.get(f"/api/initiatives/{hero}/tasks").get_json()["items"]}
    run = client.post(f"/api/initiatives/{hero}/ai/resources", json={}).get_json()
    edited = json.loads(json.dumps(run["output"]))
    idx, rec = next(((i, r) for i, r in enumerate(edited["recommendations"])
                     if r.get("candidates") and r["candidates"][0]["resource_id"] != current.get(r["wbs_code"])),
                    (0, edited["recommendations"][0]))
    rec["recommended_resource_id"] = None
    resp = client.post(f"/api/ai-runs/{run['ai_run_id']}/apply", json={"selected": [idx], "edited_output": edited})
    assert resp.status_code == 200, resp.get_json()
    after = {t["wbs_code"]: t["resource_id"] for t in client.get(f"/api/initiatives/{hero}/tasks").get_json()["items"]}
    assert after[rec["wbs_code"]] == rec["candidates"][0]["resource_id"]
