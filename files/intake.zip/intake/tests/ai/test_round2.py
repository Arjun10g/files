"""Round 2 (Director L6 + binding decisions): assistant coverage, honest fallback, consistent AI facts."""
from __future__ import annotations

from app import db
from app.ai import context as C
from app.ai import generators, provider


def _plan_hero(client, hero, approve, resources=True):
    steps = ["change-summary", "wbs"] + (["resources"] if resources else [])
    for slug in steps:
        if slug == "wbs":
            approve(hero)
        env = client.post(f"/api/initiatives/{hero}/ai/{slug}", json={}).get_json()
        client.post(f"/api/ai-runs/{env['ai_run_id']}/apply", json={})


def ask(client, message, **extra):
    res = client.post("/api/assistant/chat", json={"message": message, **extra})
    assert res.status_code == 200, res.get_json()
    return res.get_json()


def test_directors_six_questions(client, hero, l2_approve):
    _plan_hero(client, hero, l2_approve)
    readiness_before = db.scalar("SELECT readiness_date FROM initiatives WHERE id = ?", (hero,))
    expected = {
        "Which initiatives are at risk for the Feb release and why?": "list_by_rag",
        "Draft this week's exec summary": "status_report",
        "Who has CIAM capacity in January?": "availability",
        "How many hours are left on PRN-71840 and when does funding run out?": "prn_status",
        "What happens to RDDC-24817 if CIAM approval slips two weeks?": "what_if_slip",
        "Which CRQs are not ready for STO go/no-go this week?": "crq_sto_readiness",
    }
    answers = {q: ask(client, q) for q in expected}
    for q, intent in expected.items():
        assert answers[q]["intent"] == intent, (q, answers[q]["intent"])
    prn = answers["How many hours are left on PRN-71840 and when does funding run out?"]["answer_md"]
    b = __import__("app.ai.assistant", fromlist=["prn_burndown"]).prn_burndown("PRN-71840")
    assert generators.fmt_hours(b["charges_left"]) in prn and "PRN-71840" in prn
    if b.get("exhaust_month"):
        assert generators.fmt_month(b["exhaust_month"]) in prn
    what_if = answers["What happens to RDDC-24817 if CIAM approval slips two weeks?"]["answer_md"]
    assert "WBS-230" in what_if and "10 business days" in what_if and "misses DC-2702" in what_if
    assert db.scalar("SELECT readiness_date FROM initiatives WHERE id = ?", (hero,)) == readiness_before
    sto = answers["Which CRQs are not ready for STO go/no-go this week?"]
    assert "STO" in sto["answer_md"] or "No CRQ starts" in sto["answer_md"]


def test_unknown_question_is_honest_and_low_confidence(client):
    body = ask(client, "What is the capital of France?")
    assert body["intent"] == "help" and "can't answer that yet" in body["answer_md"]
    assert body["confidence"] <= 0.3 and len(body["follow_ups"]) == 4
    weak = ask(client, "How many?")
    assert weak["intent"] == "help"


def test_chat_exec_summary_matches_button(client, hero, l2_approve):
    """#20: the chat summary uses the same exec_summary output as Write Executive Summary."""
    _plan_hero(client, hero, l2_approve, resources=False)
    button = provider.preview_feature("exec_summary", None, {})
    chat = ask(client, "Draft this week's exec summary")
    for p in button.get("per_initiative") or []:
        if p["rag"] in ("Red", "Amber"):
            assert p["rddc"] in chat["answer_md"]
    assert button["headline"] in chat["answer_md"]


def test_intake_analysis_reads_prn_from_the_form(ai_app, hero, no_fixtures):
    """#5: PRN on the form is never reported missing; the question becomes a funding confirmation."""
    out = provider.run_feature("intake_analysis", hero, {})["output"]
    prn = db.scalar("SELECT prn_code FROM initiatives WHERE id = ?", (hero,))
    if prn:
        checks = {f["field"]: f["status"] for f in out["field_checks"]}
        assert checks["prn_code"] == "present"
        assert not any("PRN" in m["item"] for m in out["missing_info"])
        assert any(q["question"].startswith(f"Confirm {prn} funded hours") for q in out["clarifying_questions"])


def test_intake_fixture_with_stale_prn_gap_is_not_served(ai_app, hero):
    ctx = C.build_context("intake_analysis", hero, {})
    stale = {"field_checks": [{"field": "prn_code", "label": "PRN", "status": "missing", "note": "No PRN"}],
             "missing_info": [{"item": "PRN for funding", "impact": "Medium"}], "clarifying_questions": []}
    if ctx["bundle"]["initiative"].get("prn_code"):
        assert provider.fixture_fits("intake_analysis", stale, ctx) is False


def test_hero_labels_are_domain_not_payments(hero_bundle):
    """Decision 10."""
    ini = hero_bundle["initiative"]
    labels = generators.suggest_labels(ini["name"], ini["description"], hero_bundle["sa_doc_text"], ini["lob"])
    assert labels == ["accounts", "open-banking", "partner-api", "us-p&c"]
    assert "Payments APIs" not in generators.COMPONENT_SKILLS["APIP"]


def test_comparables_use_one_similarity(ai_app, hero, client, l2_approve):
    """Decision 8: the same Jaccard score on every card; undelivered comparables show the approved L2."""
    _plan_hero(client, hero, l2_approve, resources=False)
    out = provider.run_feature("l2_estimate", hero, {})["output"]
    mine = [r["code"] for r in db.query("""SELECT c.code FROM initiative_components ic JOIN dc_components c ON c.id = ic.component_id
                                            WHERE ic.initiative_id = ?""", (hero,))]
    for c in out.get("comparables") or []:
        theirs = [r["code"] for r in db.query("""SELECT c.code FROM initiative_components ic JOIN dc_components c ON c.id = ic.component_id
                                                  JOIN initiatives i ON i.id = ic.initiative_id WHERE i.rddc = ?""", (c["rddc"],))]
        assert c["similarity"] == generators.component_similarity(mine, theirs)
        stage = db.scalar("SELECT stage FROM initiatives WHERE rddc = ?", (c["rddc"],))
        if stage != "Closed":
            assert c["note"].startswith("Approved L2") and "actual" not in c["note"]


def test_resources_honour_wbs_filter_and_flag_over_capacity(client, hero, l2_approve):
    """Decision 9."""
    _plan_hero(client, hero, l2_approve, resources=False)
    one = client.post(f"/api/initiatives/{hero}/ai/resources", json={"options": {"wbs_code": "WBS-210"}}).get_json()
    assert [r["wbs_code"] for r in one["output"]["recommendations"]] == ["WBS-210"]
    ctx = C.build_context("resources", hero, {"wbs_code": "WBS-100"})
    rec = generators.generate("resources", ctx)["recommendations"][0]
    over = [c for c in rec["candidates"] if c["peak_util_after_pct"] > 100]
    assert over and all(c["concerns"][0].split(":")[0] in ("Best fit · over capacity", "Over capacity") for c in over)


def test_change_summary_advances_stage(client, hero):
    """Decision 4: accepting a Change Summary with components moves the initiative to Estimation."""
    env = client.post(f"/api/initiatives/{hero}/ai/change-summary", json={}).get_json()
    out = client.post(f"/api/ai-runs/{env['ai_run_id']}/apply", json={}).get_json()
    assert db.scalar("SELECT stage FROM initiatives WHERE id = ?", (hero,)) == "Estimation"
    assert out.get("stage", {}).get("to", "Estimation") == "Estimation"


def test_deterministic_flag(client, hero):
    """Decision 11: the UI hides confidence on rules-engine output."""
    rules = ask(client, "Which CRQs are non-compliant?")
    assert "deterministic" in rules
    env = client.post(f"/api/initiatives/{hero}/ai/intake-analysis", json={}).get_json()
    assert env["deterministic"] is (env["mode"] == "simulated_generated")
    listing = client.get("/api/ai-runs").get_json()["items"]
    assert all("deterministic" in i for i in listing)


def test_suggest_resources_accept_keeps_existing_assignments(client, hero, l2_approve):
    """Deck parity: Accept fills unassigned steps only; WBS-100 stays with Sana until the user picks the row."""
    _plan_hero(client, hero, l2_approve, resources=False)
    env = client.post(f"/api/initiatives/{hero}/ai/resources", json={}).get_json()
    for rec in env["output"]["recommendations"]:
        if rec["wbs_code"] == "WBS-100":
            rec["recommended_resource_id"] = 15
    db.update("ai_runs", env["ai_run_id"], {"output_json": db.to_json(env["output"])})
    client.post(f"/api/ai-runs/{env['ai_run_id']}/apply", json={})
    assert db.scalar("SELECT resource_id FROM wbs_tasks WHERE initiative_id = ? AND wbs_code = 'WBS-100'", (hero,)) == 14
    health = provider.run_feature("rebalance", hero, {})["output"]
    assert health["problem"]["resource_id"] == 14 and health["options"]
    env2 = client.post(f"/api/initiatives/{hero}/ai/resources", json={"options": {"wbs_code": "WBS-100"}}).get_json()
    env2["output"]["recommendations"][0]["recommended_resource_id"] = 15
    db.update("ai_runs", env2["ai_run_id"], {"output_json": db.to_json(env2["output"])})
    client.post(f"/api/ai-runs/{env2['ai_run_id']}/apply", json={"selected": [0]})
    assert db.scalar("SELECT resource_id FROM wbs_tasks WHERE initiative_id = ? AND wbs_code = 'WBS-100'", (hero,)) == 15


def test_hidden_bau_initiative_never_surfaces_but_counts_in_capacity(client):
    """Follow-up (4): id <= 0 rows are excluded from answers and lists, but their hours are real load."""
    hidden = db.query("SELECT id, rddc FROM initiatives WHERE id <= 0")
    for q in ("How many initiatives per stage?", "Which initiatives are at risk?", "Who is over-allocated next month?",
              "Top risks across the portfolio", "Draft this week's exec summary"):
        body = ask(client, q)
        for h in hidden:
            assert h["rddc"] not in body["answer_md"]
            assert all(str(c["id"]) not in (h["rddc"], str(h["id"])) for c in body["citations"] if c["type"] == "initiative")
    if hidden:
        month = db.scalar("SELECT month FROM allocations WHERE initiative_id = ? ORDER BY month LIMIT 1", (hidden[0]["id"],))
        rid = db.scalar("SELECT resource_id FROM allocations WHERE initiative_id = ? AND month = ? LIMIT 1", (hidden[0]["id"], month))
        assert C.utilisation([month])[rid][month]["allocated"] > 0
