"""run_feature: tiers, envelope, ai_runs audit row, regenerate, determinism and live fallback."""
from __future__ import annotations

import json
from types import SimpleNamespace

import pytest

from app import db
from app.ai import claude, generators, provider
from app.ai import context as C
from app.ai.schemas import FEATURES, validate

ENVELOPE_KEYS = {"ai_run_id", "feature", "initiative_id", "scope", "mode", "mode_label", "model", "variant_index", "confidence",
                 "sources", "warnings", "output", "status", "latency_ms", "minutes_saved", "regen_of", "created_at"}


class FakeClient:
    """Stands in for anthropic.Anthropic; ``behaviour(kwargs)`` returns a response or raises."""

    def __init__(self, behaviour):
        self.calls: list[dict] = []
        outer = self

        class _Messages:
            def create(self, **kwargs):
                outer.calls.append(kwargs)
                return behaviour(kwargs)

        self.beta = SimpleNamespace(messages=_Messages())

    def with_options(self, **_kwargs):
        return self


def tool_response(name: str, payload: dict, call_id: str = "toolu_1"):
    return SimpleNamespace(stop_reason="tool_use", usage=SimpleNamespace(input_tokens=120, output_tokens=80),
                           content=[SimpleNamespace(type="tool_use", name=name, input=payload, id=call_id)])


@pytest.fixture
def live(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    db.execute("INSERT OR REPLACE INTO app_settings (key, value) VALUES ('ai_mode', 'auto')")

    def install(behaviour):
        fake = FakeClient(behaviour)
        monkeypatch.setattr(claude, "_client", lambda timeout: fake)
        return fake
    return install


def test_envelope_and_audit_row(client, hero):
    res = client.post(f"/api/initiatives/{hero}/ai/intake-analysis", json={})
    assert res.status_code == 200
    env = res.get_json()
    assert ENVELOPE_KEYS <= set(env)
    assert env["feature"] == "intake_analysis" and env["status"] == "generated" and env["scope"] == "initiative"
    assert env["mode"] in ("simulated_fixture", "simulated_generated")
    assert env["mode_label"] == provider.MODE_LABELS[env["mode"]]
    assert env["minutes_saved"] == FEATURES["intake_analysis"]["minutes_saved"]
    assert validate("intake_analysis", env["output"]) == []
    row = db.query_one("SELECT * FROM ai_runs WHERE id = ?", (env["ai_run_id"],))
    assert row["input_hash"] and len(row["input_hash"]) == 16
    assert row["confidence"] == pytest.approx(env["output"]["confidence"])
    assert json.loads(row["sources_json"]) == env["sources"]
    assert isinstance(json.loads(row["warnings_json"]), list)
    assert row["prompt_version"] == "1.0" and row["actor"]


def test_simulated_output_is_deterministic(ai_app, hero):
    for feature in ("change_summary", "intake_analysis", "l2_estimate"):
        a = provider.run_feature(feature, hero, {})
        b = provider.run_feature(feature, hero, {})
        assert json.dumps(a["output"], sort_keys=True) == json.dumps(b["output"], sort_keys=True)
        assert a["mode"] == b["mode"]


def test_hero_change_summary_serves_fixture_then_variants_then_generator(client, hero):
    first = client.post(f"/api/initiatives/{hero}/ai/change-summary", json={}).get_json()
    assert (first["mode"], first["fixture_key"], first["variant_index"]) == ("simulated_fixture", "RDDC-24817", 0)
    second = client.post(f"/api/initiatives/{hero}/ai/change-summary",
                         json={"regen_of": first["ai_run_id"], "instruction": "More detail on CIAM"}).get_json()
    assert second["regen_of"] == first["ai_run_id"] and second["instruction"] == "More detail on CIAM"
    assert db.scalar("SELECT status FROM ai_runs WHERE id = ?", (first["ai_run_id"],)) == "superseded"
    variants = json.loads((provider.simulated.FIXTURE_DIR / "change_summary" / "RDDC-24817.json").read_text(encoding="utf-8"))["variants"]
    if len(variants) > 1:
        assert (second["mode"], second["variant_index"]) == ("simulated_fixture", 1)
    third = client.post(f"/api/ai-runs/{second['ai_run_id']}/regenerate", json={}).get_json()
    assert third["regen_of"] == second["ai_run_id"]
    assert third["variant_index"] == second["variant_index"] + 1
    if len(variants) <= third["variant_index"]:
        assert third["mode"] == "simulated_generated"
    for env in (second, third):
        assert validate("change_summary", env["output"]) == []
        assert env["output"]["sa_completeness"] == 88


def test_engine_numbers_override_any_tier(ai_app, hero):
    env = provider.run_feature("change_summary", hero, {})
    from app.ai import apply as ai_apply

    ai_apply.apply_run(env["ai_run_id"])
    l2 = provider.run_feature("l2_estimate", hero, {})["output"]
    assert (l2["total_hours"], l2["low_hours"], l2["high_hours"], l2["tshirt"], l2["dev_hours"]) == (1000, 750, 1250, "L", 560)


def test_live_failure_falls_back_never_500(client, hero, live):
    def boom(_kwargs):
        raise ConnectionError("network unreachable")
    fake = live(boom)
    res = client.post(f"/api/initiatives/{hero}/ai/intake-analysis", json={})
    assert res.status_code == 200
    env = res.get_json()
    assert env["mode"] == "live_fallback" and env["mode_label"] == "Live → Simulated"
    assert validate("intake_analysis", env["output"]) == []
    assert fake.calls, "live tier was attempted"
    assert db.scalar("SELECT error FROM ai_runs WHERE id = ?", (env["ai_run_id"],))


def test_live_invalid_answer_falls_back(client, hero, live):
    live(lambda kw: tool_response("emit_intake_analysis", {"summary": "incomplete"}))
    env = client.post(f"/api/initiatives/{hero}/ai/intake-analysis", json={}).get_json()
    assert env["mode"] == "live_fallback"


def test_live_success_uses_forced_shape_and_model(client, hero, live):
    def ok(kwargs):
        assert kwargs["tool_choice"] == {"type": "auto"}
        assert kwargs["tools"][0]["name"] == "emit_intake_analysis"
        assert "temperature" not in kwargs
        ctx = C.build_context("intake_analysis", hero, {})
        return tool_response("emit_intake_analysis", generators.generate("intake_analysis", ctx))
    fake = live(ok)
    env = client.post(f"/api/initiatives/{hero}/ai/intake-analysis", json={}).get_json()
    assert env["mode"] == "live" and env["model"] == "claude-sonnet-5-5"
    assert fake.calls[0]["model"] == "claude-sonnet-5-5"
    row = db.query_one("SELECT tokens_in, tokens_out FROM ai_runs WHERE id = ?", (env["ai_run_id"],))
    assert (row["tokens_in"], row["tokens_out"]) == (120, 80)


def test_live_client_has_no_retries_and_short_timeout(monkeypatch):
    import anthropic

    seen = {}

    class Capture:
        def __init__(self, **kwargs):
            seen.update(kwargs)

    monkeypatch.setattr(anthropic, "Anthropic", Capture)
    claude._client(claude._timeout())
    assert seen["max_retries"] == 0 and seen["timeout"] <= 20


def test_force_simulated_ignores_key(ai_app, hero, live):
    fake = live(lambda kw: (_ for _ in ()).throw(AssertionError("live must not be called")))
    env = provider.run_feature("intake_analysis", hero, {}, force_mode="simulated")
    assert env["mode"].startswith("simulated") and not fake.calls


def test_live_assistant_tool_loop_and_citation_check(client, live):
    turns = iter([
        tool_response("search_initiatives", {"rag": "Red"}, "toolu_a"),
        tool_response("emit_assistant", {
            "answer_md": "RDDC-24412 is Red.", "intent": "list_by_rag",
            "citations": [{"type": "initiative", "id": "RDDC-24412", "label": "RDDC-24412", "route": "#/initiative/2/pg5"},
                          {"type": "initiative", "id": "RDDC-99999", "label": "Made up", "route": "#/initiative/99/pg1"}],
            "table": None, "suggested_actions": [], "follow_ups": [], "confidence": 0.9, "sources": [], "warnings": []}, "toolu_b"),
    ])
    fake = live(lambda kw: next(turns))
    body = client.post("/api/assistant/chat", json={"message": "Which projects are red?"}).get_json()
    assert body["mode"] == "live"
    assert [c["id"] for c in body["citations"]] == ["RDDC-24412"]
    assert len(fake.calls) == 2
    assert fake.calls[1]["messages"][-1]["content"][0]["type"] == "tool_result"


def test_unknown_feature_and_initiative(client):
    assert client.post("/api/initiatives/1/ai/not-a-feature", json={}).status_code == 404
    assert client.post("/api/initiatives/999/ai/wbs", json={}).status_code == 404
    assert client.post("/api/ai/meeting-extract", json={}).status_code == 422
    assert client.post("/api/ai/intake-autofill", json={}).status_code == 422


def test_runs_list_detail_and_stats(client, hero):
    env = client.post(f"/api/initiatives/{hero}/ai/intake-analysis", json={}).get_json()
    client.post(f"/api/ai-runs/{env['ai_run_id']}/apply", json={})
    other = client.post(f"/api/initiatives/{hero}/ai/risks", json={}).get_json()
    client.post(f"/api/ai-runs/{other['ai_run_id']}/reject", json={"reason": "Not needed yet"})
    listing = client.get(f"/api/ai-runs?initiative_id={hero}").get_json()
    assert listing["total"] == 2 and {i["status"] for i in listing["items"]} == {"accepted", "rejected"}
    detail = client.get(f"/api/ai-runs/{env['ai_run_id']}").get_json()
    assert detail["status"] == "accepted" and "input_json" in detail and detail["applied_json"] is not None
    stats = client.get("/api/ai-runs/stats").get_json()
    assert stats["accepted"] == 1 and stats["rejected"] == 1 and stats["acceptance_rate"] == 0.5
    assert stats["minutes_saved"] == FEATURES["intake_analysis"]["minutes_saved"]
    assert client.get("/api/ai-runs/9999").status_code == 404


def test_live_client_construction_failure_falls_back(client, hero, monkeypatch):
    """QA-A-02: a client that cannot be built is a fallback, never a 500."""
    import anthropic

    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    db.execute("INSERT OR REPLACE INTO app_settings (key, value) VALUES ('ai_mode', 'live')")

    def broken(**_kwargs):
        raise RuntimeError("could not build HTTP client")

    monkeypatch.setattr(anthropic, "Anthropic", broken)
    res = client.post(f"/api/initiatives/{hero}/ai/risks", json={})
    assert res.status_code == 200 and res.get_json()["mode"] == "live_fallback"
    chat = client.post("/api/assistant/chat", json={"message": "Which projects are red?"})
    assert chat.status_code == 200 and chat.get_json()["mode"] == "live_fallback"


def test_live_unreadable_tool_input_falls_back(client, hero, live):
    live(lambda kw: tool_response("emit_risks", "{not json"))
    res = client.post(f"/api/initiatives/{hero}/ai/risks", json={})
    assert res.status_code == 200 and res.get_json()["mode"] == "live_fallback"


def test_malformed_and_wrong_typed_requests(client, hero):
    """QA-A-04/05/06: unreadable bodies are 400, wrong types 422 with the field, unknown records 404."""
    env = client.post(f"/api/initiatives/{hero}/ai/intake-analysis", json={}).get_json()
    bad = client.post(f"/api/ai-runs/{env['ai_run_id']}/apply", data='{"selected":[0]', content_type="application/json")
    assert bad.status_code == 400
    assert db.scalar("SELECT status FROM ai_runs WHERE id = ?", (env["ai_run_id"],)) == "generated"
    assert client.post("/api/assistant/chat", data="{", content_type="application/json").status_code == 400
    res = client.post("/api/ai/meeting-extract", json={"options": {"meeting_note_id": "abc"}})
    assert res.status_code == 422 and "meeting_note_id" in res.get_json()["error"]["details"]["fields"]
    res = client.post("/api/ai/intake-analysis", json={"options": {"name": 12345}})
    assert res.status_code == 422 and "name" in res.get_json()["error"]["details"]["fields"]
    assert client.post("/api/ai/intake-autofill", json={"options": {"attachment_id": 999999}}).status_code == 404
    other = db.query_one("SELECT id FROM change_requests WHERE initiative_id != 4 LIMIT 1")
    assert client.post("/api/initiatives/4/ai/cr-compliance", json={"options": {"change_request_id": other["id"]}}).status_code == 404


def test_l2_contingency_matches_engine(ai_app, hero):
    from app.ai import apply as ai_apply

    ai_apply.apply_run(provider.run_feature("change_summary", hero, {})["ai_run_id"])
    out = provider.run_feature("l2_estimate", hero, {})["output"]
    phases = {p["phase"]: p["hours"] for p in out["by_phase"]}
    assert phases["Contingency"] == 130 and out["total_hours"] == 1000


def test_nudge_keys_follow_engine_format(client):
    env = client.post("/api/ai/nudges", json={}).get_json()
    for m in env["output"]["messages"]:
        rule, kind, _ent, day = m["dedupe_key"].split(":")
        assert rule == m["rule"] and kind in ("resource", "recipient") and day == m["action_required_by"]
    client.post(f"/api/ai-runs/{env['ai_run_id']}/apply", json={})
    rows = db.query("SELECT entity_type, entity_id, due_at, action_required_by FROM notifications WHERE ai_run_id = ?",
                    (env["ai_run_id"],))
    assert rows and all(r["entity_type"] in ("resource", "recipient") and r["due_at"] == r["action_required_by"] for r in rows)


def test_mode_labels_are_presenter_wording(client, hero):
    """QA-C-17: user-facing mode chips never mention test agents."""
    assert provider.MODE_LABELS == {"simulated_fixture": "Simulated AI · prepared response",
                                    "simulated_generated": "Simulated AI · rules engine",
                                    "live": "Live Claude", "live_fallback": "Live → Simulated"}
    env = client.post(f"/api/initiatives/{hero}/ai/change-summary", json={}).get_json()
    assert env["mode_label"] == provider.MODE_LABELS[env["mode"]] and "test" not in env["mode_label"].lower()


def test_cr_findings_are_the_engines_in_every_tier(client, hero, l2_approve):
    """QA-A-10: status, due_date and detail come from derive.compliance_for, whatever the tier served."""
    from app.services import derive

    for slug in ("change-summary", "wbs"):
        if slug == "wbs":
            l2_approve(hero)
        env = client.post(f"/api/initiatives/{hero}/ai/{slug}", json={}).get_json()
        client.post(f"/api/ai-runs/{env['ai_run_id']}/apply", json={})
    draft = client.post(f"/api/initiatives/{hero}/change-requests/draft", json={})
    crs = db.query("SELECT * FROM change_requests WHERE initiative_id = ?", (hero,))
    targets = crs or db.query("SELECT * FROM change_requests LIMIT 2")
    assert draft.status_code in (200, 201) or targets
    for cr in targets:
        env = client.post(f"/api/initiatives/{cr['initiative_id']}/ai/cr-compliance",
                          json={"options": {"change_request_id": cr["id"]}}).get_json()
        live = derive.compliance_for(C.parse_row(cr))
        got = {f["rule_id"]: (f["status"], f.get("due_date")) for f in env["output"]["findings"]}
        want = {f["rule_id"]: (f["status"], f.get("due_date") if f["status"] == "Not due yet" or f.get("due_date") else None)
                for f in live["findings"]}
        assert got == want
