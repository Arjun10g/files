"""AI test fixtures: a seeded demo database (built once per session, copied per test) and the live hero helper."""
from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from app import create_app, db

ROOT = Path(__file__).resolve().parents[2]
BUNDLE_PATH = ROOT / "tests" / "fixtures" / "bundle_hero.json"
HERO_SA_MD = ROOT / "app" / "seed" / "files" / "SA_US_API_Enhancement_v1.2.md"


def _seed_module():
    try:
        from app.seed import seed
    except ModuleNotFoundError:
        return None
    return seed if hasattr(seed, "reset_database") else None


@pytest.fixture(scope="session")
def seed_template(tmp_path_factory):
    seed = _seed_module()
    if seed is None:
        pytest.skip("Demo seed (app.seed) is not installed yet")
    folder = tmp_path_factory.mktemp("ai_seed")
    path = folder / "template.db"
    uploads = folder / "uploads"
    app = create_app(DB_PATH=str(path), UPLOAD_DIR=str(uploads), TESTING=True)
    with app.app_context():
        seed.reset_database(db.get_db(), upload_dir=uploads, today="2026-10-19", ai_mode="simulated")
        db.get_db().execute("PRAGMA wal_checkpoint(TRUNCATE)")
    return path, uploads


@pytest.fixture
def ai_app(seed_template, tmp_path, monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    src, uploads = seed_template
    dst = tmp_path / "ai.db"
    shutil.copy(src, dst)
    app = create_app(DB_PATH=str(dst), UPLOAD_DIR=str(uploads), TESTING=True)
    with app.app_context():
        yield app


@pytest.fixture
def client(ai_app):
    return ai_app.test_client()


@pytest.fixture(scope="session")
def hero_bundle() -> dict:
    return json.loads(BUNDLE_PATH.read_text(encoding="utf-8"))


def hero_sa_text(bundle: dict) -> str:
    return HERO_SA_MD.read_text(encoding="utf-8") if HERO_SA_MD.is_file() else bundle["sa_doc_text"]


def create_hero(bundle: dict) -> int:
    """Insert RDDC-24817 as it looks right after Add New Initiative + SA attach (before any AI step)."""
    from app.ai import context as C
    from app.today import now_iso

    ini = bundle["initiative"]
    has_prn = db.query_one("SELECT 1 AS x FROM prn_budget WHERE prn_code = ?", (ini["prn_code"],)) is not None
    has_intake = db.query_one("SELECT 1 AS x FROM dc_intakes WHERE code = ?", (ini["dc_intake"],)) is not None
    with db.transaction():
        iid = db.insert("initiatives", {
            "rddc": ini["rddc"], "dc_intake": ini["dc_intake"] if has_intake else None, "name": ini["name"], "lob": ini["lob"],
            "priority": ini["priority"], "stage": "Solution", "status": "Backlog", "labels": db.to_json(ini["labels"]),
            "requestor": ini["requestor"], "requestor_id": ini["requestor_id"], "assigned_to_id": ini["assigned_to_id"],
            "pm_id": ini["pm_id"], "tech_lead_id": ini["tech_lead_id"], "dc_pm_id": ini["dc_pm_id"], "dc_sa_id": ini["dc_sa_id"],
            "description": ini["description"], "prn_code": ini["prn_code"] if has_prn else None,
            "requested_go_live": ini["requested_go_live"], "target_release": ini["target_release"],
            "created_at": now_iso(), "updated_at": now_iso()})
        text = hero_sa_text(bundle)
        score = C.sa_score(text)
        att = db.insert("attachments", {"initiative_id": iid, "entity_type": "initiative", "entity_id": iid, "kind": "sa_doc",
                                        "filename": "SA_US_API_Enhancement_v1.2.docx", "stored_path": f"{iid}/SA_US_API_Enhancement_v1.2.docx",
                                        "mime": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                        "extracted_text": text, "version": "1.2", "uploaded_by": "Grace Ellingham", "uploaded_at": now_iso()})
        db.update("initiatives", iid, {"sa_doc_attachment_id": att, "sa_author": score.get("author") or "Sana Whitfield",
                                       "sa_version": score.get("version") or "1.2", "sa_completeness": score["completeness"],
                                       "sa_missing_json": db.to_json(score.get("missing") or [])})
    return iid


def approve_l2(iid: int) -> None:
    from app.today import now_iso

    row = db.query_one("SELECT l2_hours FROM initiatives WHERE id = ?", (iid,))
    db.update("initiatives", iid, {"l2_status": "Approved", "l2_submitted_at": now_iso(), "l2_approved_at": now_iso(),
                                   "l2_approved_by": "Clara Pemberton", "l2_baseline_hours": row["l2_hours"],
                                   "stage": "Planning", "status": "In progress"})


@pytest.fixture
def hero(ai_app, hero_bundle) -> int:
    return create_hero(hero_bundle)


@pytest.fixture
def l2_approve():
    return approve_l2


@pytest.fixture
def no_fixtures(monkeypatch, tmp_path):
    """Route the simulated tier straight to the generators (unseen-intake path)."""
    from app.ai import simulated

    empty = tmp_path / "no_fixtures"
    empty.mkdir()
    monkeypatch.setattr(simulated, "FIXTURE_DIR", empty)
    return empty
