"""Accept round-trips: each feature writes its domain rows with provenance and refreshes derived data (§6.2 golden)."""
from __future__ import annotations

import json

import pytest

from app import db
from app.ai import provider

HERO_DATES = {"WBS-100": ("2026-10-20", "2026-11-17"), "WBS-210": ("2026-11-18", "2027-01-15"),
              "WBS-240": ("2026-11-18", "2026-12-15"), "WBS-300": ("2027-01-18", "2027-01-29"),
              "WBS-310": ("2027-01-18", "2027-01-22"), "WBS-400": ("2027-02-01", "2027-02-10"),
              "WBS-500": ("2027-02-11", "2027-02-12"), "WBS-600": ("2027-02-16", "2027-02-17"),
              "WBS-700": ("2027-02-20", "2027-02-20"), "WBS-800": ("2027-02-22", "2027-03-05")}


def run(client, iid, slug, body=None):
    res = client.post(f"/api/initiatives/{iid}/ai/{slug}", json=body or {})
    assert res.status_code == 200, res.get_json()
    return res.get_json()


def accept(client, run_id, body=None):
    res = client.post(f"/api/ai-runs/{run_id}/apply", json=body or {})
    assert res.status_code == 200, res.get_json()
    return res.get_json()


def rags(health):
    return health["overall"], {k: v["rag"] for k, v in health["dimensions"].items()}


def hero_pipeline(client, hero, approve):
    cs = run(client, hero, "change-summary")
    out = accept(client, cs["ai_run_id"])
    assert out["applied"]["initiative_components"] == 4
    ini = db.query_one("SELECT stage, l2_hours, l2_tshirt, sa_completeness FROM initiatives WHERE id = ?", (hero,))
    assert (ini["stage"], ini["l2_hours"], ini["l2_tshirt"], ini["sa_completeness"]) == ("Estimation", 1000, "L", 88)
    comps = db.query("""SELECT c.code, ic.complexity, ic.approval, ic.est_hours, ic.source, ic.ai_run_id FROM initiative_components ic
                         JOIN dc_components c ON c.id = ic.component_id WHERE ic.initiative_id = ? ORDER BY ic.sort""", (hero,))
    assert {(c["code"], c["complexity"], c["approval"], c["est_hours"]) for c in comps} == {
        ("APIP", "High", "Approved", 280), ("EDP", "Medium", "Approved", 120), ("CIAM", "Medium", "Pending", 120),
        ("SRE", "Low", "Not required", 40)}
    assert all(c["source"] == "ai" and c["ai_run_id"] == cs["ai_run_id"] for c in comps)
    approve(hero)
    wbs = run(client, hero, "wbs")
    applied = accept(client, wbs["ai_run_id"])
    assert applied["applied"]["wbs_tasks"] == 14
    return applied


def check_hero_plan(hero):
    tasks = {t["wbs_code"]: t for t in db.query("SELECT * FROM wbs_tasks WHERE initiative_id = ?", (hero,))}
    for code, (start, end) in HERO_DATES.items():
        assert (tasks[code]["planned_start"], tasks[code]["planned_end"]) == (start, end), code
        assert (tasks[code]["baseline_start"], tasks[code]["baseline_end"]) == (start, end), code
    assert sum(tasks[c]["est_hours"] for c in ("WBS-210", "WBS-220", "WBS-230", "WBS-240")) == 560
    assert sum(t["est_hours"] for t in tasks.values()) <= 1000
    assert tasks["WBS-210"]["parent_id"] == tasks["WBS-200"]["id"]
    assert tasks["WBS-100"]["resource_id"] == 14 and tasks["WBS-230"]["resource_id"] == 4
    assert all(t["source"] == "ai" for t in tasks.values())
    deps = db.query("""SELECT t.wbs_code, p.wbs_code AS dep FROM wbs_dependencies d JOIN wbs_tasks t ON t.id = d.task_id
                        JOIN wbs_tasks p ON p.id = d.depends_on_task_id WHERE t.initiative_id = ?""", (hero,))
    assert ("WBS-700", "WBS-600") in {(d["wbs_code"], d["dep"]) for d in deps}
    ini = db.query_one("SELECT readiness_date, qa_date, prod_date FROM initiatives WHERE id = ?", (hero,))
    assert (ini["readiness_date"], ini["qa_date"], ini["prod_date"]) == ("2027-02-17", "2027-02-10", "2027-02-20")


def test_hero_pipeline_with_fixtures(client, hero, l2_approve):
    applied = hero_pipeline(client, hero, l2_approve)
    check_hero_plan(hero)
    health = applied.get("health")
    if health is not None:
        overall, dims = rags(health)
        assert overall == "Amber" and dims["schedule"] == "Amber" and dims["resources"] == "Red"
        assert dims["scope"] == dims["dependencies"] == dims["budget"] == "Green"
    res = run(client, hero, "resources")
    accept(client, res["ai_run_id"])
    fix = run(client, hero, "rebalance")
    best = fix["output"]["options"][fix["output"]["recommended_option_index"]]
    assert (best["task_wbs_code"], best["to_resource_id"], best["after"]) == ("WBS-100", 15, {"from_pct": 96, "to_pct": 74})
    done = accept(client, fix["ai_run_id"])
    assert done["applied"] == {"wbs_tasks": 1, "decisions": 1}
    assert db.scalar("SELECT resource_id FROM wbs_tasks WHERE initiative_id = ? AND wbs_code = 'WBS-100'", (hero,)) == 15
    if done.get("health") is not None:
        overall, dims = rags(done["health"])
        assert overall == "Amber" and dims["resources"] == "Green"
    decision = db.query_one("SELECT * FROM decisions WHERE ai_run_id = ?", (fix["ai_run_id"],))
    assert decision["source"] == "ai" and "WBS-100" in decision["title"]


def test_hero_pipeline_with_generators_only(client, hero, l2_approve, no_fixtures):
    hero_pipeline(client, hero, l2_approve)
    check_hero_plan(hero)
    assert db.scalar("SELECT COUNT(*) FROM ai_runs WHERE mode = 'simulated_fixture'") == 0
    fix = run(client, hero, "rebalance")
    assert fix["mode"] == "simulated_generated"
    best = fix["output"]["options"][0]
    assert (best["task_wbs_code"], best["to_resource_id"]) == ("WBS-100", 15)


def test_apply_twice_conflicts_and_reject(client, hero):
    env = run(client, hero, "intake-analysis")
    accept(client, env["ai_run_id"])
    assert client.post(f"/api/ai-runs/{env['ai_run_id']}/apply", json={}).status_code == 409
    other = run(client, hero, "intake-analysis")
    rej = client.post(f"/api/ai-runs/{other['ai_run_id']}/reject", json={"reason": "Duplicate"}).get_json()
    assert rej == {"ai_run_id": other["ai_run_id"], "status": "rejected"}
    assert client.post(f"/api/ai-runs/{other['ai_run_id']}/apply", json={}).status_code == 409


def test_intake_analysis_merges_labels(client, hero):
    env = run(client, hero, "intake-analysis")
    out = accept(client, env["ai_run_id"], {"selected": [0]})
    labels = json.loads(db.scalar("SELECT labels FROM initiatives WHERE id = ?", (hero,)))
    assert env["output"]["suggested_labels"][0] in labels and out["labels"] == labels


def test_edited_output_is_validated_and_stored(client, hero):
    env = run(client, hero, "change-summary")
    bad = client.post(f"/api/ai-runs/{env['ai_run_id']}/apply", json={"edited_output": {"components": "nope"}})
    assert bad.status_code == 422
    edited = json.loads(json.dumps(env["output"]))
    edited["components"] = [c for c in edited["components"] if c["component_code"] != "SRE"]
    edited["components"][0]["change_summary"] = "Edited by the DC PM before accepting."
    out = accept(client, env["ai_run_id"], {"edited_output": edited})
    assert out["applied"]["initiative_components"] == len(edited["components"])
    assert db.scalar("SELECT edited_output_json FROM ai_runs WHERE id = ?", (env["ai_run_id"],))
    assert db.scalar("""SELECT COUNT(*) FROM initiative_components ic JOIN dc_components c ON c.id = ic.component_id
                         WHERE ic.initiative_id = ? AND c.code = 'SRE'""", (hero,)) == 0


def test_risks_selected_rows_get_codes(client, hero, l2_approve):
    hero_pipeline(client, hero, l2_approve)
    env = run(client, hero, "risks")
    before = db.scalar("SELECT COUNT(*) FROM risks")
    out = accept(client, env["ai_run_id"], {"selected": [0, 1]})
    assert out["applied"] == {"risks": 2}
    rows = db.query("SELECT risk_code, source, ai_run_id, task_id FROM risks WHERE ai_run_id = ?", (env["ai_run_id"],))
    assert len(rows) == 2 and db.scalar("SELECT COUNT(*) FROM risks") == before + 2
    assert len({r["risk_code"] for r in rows}) == 2 and all(r["risk_code"].startswith("RSK-") for r in rows)


def test_cr_compliance_updates_change_request(client):
    cr = db.query_one("SELECT id, initiative_id FROM change_requests ORDER BY id LIMIT 1")
    env = run(client, cr["initiative_id"], "cr-compliance", {"options": {"change_request_id": cr["id"]}})
    accept(client, env["ai_run_id"])
    stored = json.loads(db.scalar("SELECT compliance_json FROM change_requests WHERE id = ?", (cr["id"],)))
    assert "ok" in stored and "flags" in stored and stored["ai"]["ai_run_id"] == env["ai_run_id"]


def test_exec_summary_never_overwrites_comments(client, hero, l2_approve):
    """L5-13: the summary is stored as a status note; the PM's Comments stay as they were."""
    hero_pipeline(client, hero, l2_approve)
    db.update("initiatives", hero, {"comments": "Steering call moved to Thursday."})
    env = run(client, hero, "exec-summary")
    out = accept(client, env["ai_run_id"])
    assert db.scalar("SELECT comments FROM initiatives WHERE id = ?", (hero,)) == "Steering call moved to Thursday."
    note = db.query_one("SELECT * FROM meeting_notes WHERE id = ?", (out["meeting_note_id"],))
    assert note["initiative_id"] == hero and env["output"]["headline"] in note["notes_md"]
    assert note["title"].startswith("Executive summary")


@pytest.mark.parametrize("slug,body,table", [
    ("skill-matrix", {}, "resource_skills"),
    ("nudges", {}, "notifications"),
    ("meeting-extract", {"text": "Weekly sync 2026-10-16\nDecision: RDDC-24412 moves to DC-2701 if validation fails\n"
                                 "Action: Sana to update the SA document by Wed"}, "decisions"),
])
def test_global_features_apply(client, slug, body, table):
    env = client.post(f"/api/ai/{slug}", json=body).get_json()
    before = db.scalar(f"SELECT COUNT(*) FROM {table}")
    out = accept(client, env["ai_run_id"])
    assert out["status"] == "accepted"
    if slug != "nudges" or env["output"]["messages"]:
        assert db.scalar(f"SELECT COUNT(*) FROM {table}") >= before
    assert db.scalar("SELECT status FROM ai_runs WHERE id = ?", (env["ai_run_id"],)) == "accepted"


def test_lessons_draft_writes_rows(client):
    closed = db.query_one("SELECT id FROM initiatives WHERE stage = 'Closed' AND id > 0 LIMIT 1")
    env = client.post("/api/ai/lessons", json={"options": {"initiative_id": closed["id"]}}).get_json()
    out = accept(client, env["ai_run_id"])
    assert out["applied"].get("lessons_learned", 0) == len(env["output"]["lessons"])


def test_intake_autofill_returns_fields_only(client):
    env = client.post("/api/ai/intake-autofill", json={"text": "Solution Architecture: OLB Real-time Alerts\nAuthor: Mateo Brennan\n"
                                                               "LOB: Canadian P&C\nVersion 0.3"}).get_json()
    before = db.scalar("SELECT COUNT(*) FROM initiatives")
    out = accept(client, env["ai_run_id"])
    assert out["applied"] == {} and "fields" in out
    assert db.scalar("SELECT COUNT(*) FROM initiatives") == before


def test_minutes_saved_counted_on_accept(ai_app, hero):
    env = provider.run_feature("intake_analysis", hero, {})
    from app.ai import apply as ai_apply

    out = ai_apply.apply_run(env["ai_run_id"])
    assert out["minutes_saved"] == 30


def test_concurrent_apply_writes_rows_once(ai_app, hero, l2_approve, client):
    """L5-08: the run is claimed atomically; a second apply is a 409 and adds nothing."""
    import threading

    from app import create_app

    hero_pipeline(client, hero, l2_approve)
    env = run(client, hero, "risks")
    before = db.scalar("SELECT COUNT(*) FROM risks")
    codes = []
    path = ai_app.config["DB_PATH"]

    def worker():
        app = create_app(DB_PATH=path, UPLOAD_DIR=ai_app.config["UPLOAD_DIR"], TESTING=True)
        codes.append(app.test_client().post(f"/api/ai-runs/{env['ai_run_id']}/apply", json={}).status_code)

    threads = [threading.Thread(target=worker) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert sorted(codes) == [200, 409, 409, 409]
    assert db.scalar("SELECT COUNT(*) FROM risks") == before + len(env["output"]["risks"])


def test_l2_explanation_saved_without_touching_status(client, hero):
    """L5-12: Save explanation writes a Decision Log entry and never revives a rejected L2."""
    cs = run(client, hero, "change-summary")
    accept(client, cs["ai_run_id"])
    db.update("initiatives", hero, {"l2_status": "Rejected"})
    first = run(client, hero, "l2-estimate")
    out = accept(client, first["ai_run_id"])
    assert db.scalar("SELECT l2_status FROM initiatives WHERE id = ?", (hero,)) == "Rejected"
    dec = db.query_one("SELECT * FROM decisions WHERE id = ?", (out["decision_id"],))
    assert dec["decision"] == first["output"]["narrative"] and dec["source"] == "ai" and dec["initiative_id"] == hero
    second = run(client, hero, "l2-estimate")
    accept(client, second["ai_run_id"])
    assert db.scalar("SELECT status FROM decisions WHERE id = ?", (out["decision_id"],)) == "Superseded"


def test_cr_review_is_visible(client):
    """L5-11: the review lands on compliance_json.ai and in the Decision Log."""
    cr = db.query_one("SELECT id, initiative_id, crq_number FROM change_requests ORDER BY id LIMIT 1")
    env = run(client, cr["initiative_id"], "cr-compliance", {"options": {"change_request_id": cr["id"]}})
    out = accept(client, env["ai_run_id"])
    assert out["compliance"]["ai"]["reviewer_note"] == env["output"]["reviewer_note"]
    stored = json.loads(db.scalar("SELECT compliance_json FROM change_requests WHERE id = ?", (cr["id"],)))
    assert {"score", "sto_readiness", "reviewer_note", "findings", "ai_run_id", "reviewed_at"} <= set(stored["ai"])
    assert db.scalar("SELECT COUNT(*) FROM decisions WHERE ai_run_id = ? AND title LIKE 'CR compliance review%'",
                     (env["ai_run_id"],)) == 1


def test_nudges_do_not_duplicate_queued_reminders(client):
    """L5-10: accepting reminders dismisses the per-item reminders they consolidate; a second accept adds nothing."""
    queued_before = db.scalar("SELECT COUNT(*) FROM notifications WHERE status = 'Queued'")
    env = client.post("/api/ai/nudges", json={}).get_json()
    out = accept(client, env["ai_run_id"])
    for m in env["output"]["messages"]:
        rid = m["recipient_resource_id"]
        if rid is None:
            continue
        rows = db.query("SELECT rule, initiative_id FROM notifications WHERE status = 'Queued' AND to_resource_id = ? "
                        "AND ai_run_id IS NULL AND rule IN ('sa_action_required', 'component_approval', 'l2_approval', "
                        "'cr_noncompliance', 'validation_missing', 'backout_missing')", (rid,))
        rddcs = {i["rddc"] for i in m["items"]}
        ids = {r["id"] for r in db.query("SELECT id, rddc FROM initiatives") if r["rddc"] in rddcs}
        assert not [r for r in rows if r["initiative_id"] in ids]
    queued_after = db.scalar("SELECT COUNT(*) FROM notifications WHERE status = 'Queued'")
    assert queued_after <= queued_before + out["applied"]["notifications"]
    again = client.post("/api/ai/nudges", json={}).get_json()
    second = accept(client, again["ai_run_id"])
    assert second["applied"]["notifications"] == 0
    assert db.scalar("SELECT COUNT(*) FROM notifications WHERE status = 'Queued'") == queued_after


def test_rebalance_fixture_only_while_problem_holds(client, hero, l2_approve):
    """L5-14: after the fix is applied, Suggest fix no longer replays the 128% fixture."""
    hero_pipeline(client, hero, l2_approve)
    first = run(client, hero, "rebalance")
    accept(client, first["ai_run_id"])
    again = run(client, hero, "rebalance")
    assert again["mode"] == "simulated_generated"
    assert not any(o["task_wbs_code"] == "WBS-100" and o["from_resource_id"] == 14 for o in again["output"]["options"])
