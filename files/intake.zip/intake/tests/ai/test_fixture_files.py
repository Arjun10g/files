"""Every test-agent fixture validates against the frozen schemas and references records that exist in the seed."""
from __future__ import annotations

import io
import json
import warnings
from pathlib import Path

import pytest

from app.ai import assistant, cli_ext, schemas, simulated
from app.ai.simulated import FIXTURE_DIR

FILES = sorted(p for p in FIXTURE_DIR.rglob("*.json") if p.name != "manifest.json") if FIXTURE_DIR.is_dir() else []


@pytest.mark.parametrize("path", FILES, ids=[str(p.relative_to(FIXTURE_DIR)) for p in FILES])
def test_fixture_file_validates(path: Path):
    assert schemas.validate_fixture_file(path) == []


@pytest.mark.parametrize("path", FILES, ids=[str(p.relative_to(FIXTURE_DIR)) for p in FILES])
def test_fixture_references_exist(ai_app, path: Path):
    from app import db

    known = {r["rddc"] for r in db.query("SELECT rddc FROM initiatives")}
    assert cli_ext.reference_problems(json.loads(path.read_text(encoding="utf-8")), known) == []


def test_assistant_bindings_name_known_queries():
    for path in FILES:
        data = json.loads(path.read_text(encoding="utf-8"))
        for spec in (data.get("bindings") or {}).values():
            assert str(spec).split(":")[0] in assistant.BINDINGS, f"{path.name}: {spec}"


def test_unresolved_bindings_never_reach_the_user(ai_app):
    """A showcase answer whose binding cannot be read from the live data is skipped, never shown with a gap."""
    unresolved = []
    for path in FILES:
        data = json.loads(path.read_text(encoding="utf-8"))
        if data["feature"] != "assistant":
            continue
        missing = [spec for spec in (data.get("bindings") or {}).values() if assistant.resolve_binding(spec) is None]
        if missing:
            unresolved.append(f"{path.name}: {missing}")
            assert simulated.render_showcase(data, 0) is None
        else:
            out = simulated.render_showcase(data, 0)
            if out is not None:
                assert "{" not in out["answer_md"] or "}" not in out["answer_md"]
    if unresolved:
        warnings.warn("Showcase answers waiting on live data: " + "; ".join(unresolved), stacklevel=1)


def test_validate_fixtures_command(ai_app):
    out = io.StringIO()
    assert cli_ext.validate_fixtures(out=out) == 0, out.getvalue()
