"""Assistant: intent routing, grounded answers and citations that always point at existing records."""
from __future__ import annotations

import re
from pathlib import Path

import pytest

from app import db
from app.ai import assistant, provider
from app.ai.schemas import validate

QUESTIONS = [
    ("Which projects are red?", "list_by_rag"),
    ("Which initiatives are at risk for the Feb release and why?", "list_by_rag"),
    ("Who is over-allocated in December?", "overallocated_resources"),
    ("Summarise RDDC-24601", "summarize_initiative"),
    ("What's blocking e-Transfer Request Money Redesign?", "blockers"),
    ("Suggest a developer for CIAM work", "suggest_resource"),
    ("Who has CIAM capacity in January?", "availability"),
    ("What is Lena Oduya working on?", "resource_workload"),
    ("What's going to production in the next 2 weeks?", "upcoming_releases"),
    ("Which CRQs are non-compliant?", "cr_noncompliance"),
    ("Top risks across the portfolio", "top_risks"),
    ("When is QA for RDDC-24601?", "milestone_dates"),
    ("How much EAPI demand next quarter?", "component_demand"),
    ("What approvals are pending?", "pending_approvals"),
    ("Who knows Kafka?", "skill_lookup"),
    ("How many initiatives per LOB?", "portfolio_stats"),
    ("Draft this week's exec summary", "status_report"),
    ("Why is RDDC-24412 red?", "explain_health"),
    ("Why is Resources red?", "explain_health"),
    ("tell me a joke", "help"),
]
BAD_TEXT = re.compile(r"\bundefined\b|\bNaN\b|\bnull\b|\bNone\b|\{[a-z_]+\}")


def ask(client, message, **extra):
    res = client.post("/api/assistant/chat", json={"message": message, **extra})
    assert res.status_code == 200, res.get_json()
    return res.get_json()


def check_answer(body):
    assert body["answer_md"] and not BAD_TEXT.search(body["answer_md"]), body["answer_md"]
    for c in body["citations"]:
        assert assistant.citation_exists(c), c
        assert c["route"].startswith("#/")
    run = db.query_one("SELECT output_json FROM ai_runs WHERE id = ?", (body["ai_run_id"],))
    assert validate("assistant", db.from_json(run["output_json"])) == []


@pytest.mark.parametrize(("question", "intent"), QUESTIONS)
def test_questions_on_seed(client, question, intent):
    body = ask(client, question)
    check_answer(body)
    if body["mode"] == "simulated_generated":
        assert body["intent"] == intent, (question, body["intent"])


def test_questions_after_hero_pipeline(client, hero, l2_approve):
    for slug in ("change-summary", "wbs"):
        if slug == "wbs":
            l2_approve(hero)
        env = client.post(f"/api/initiatives/{hero}/ai/{slug}", json={}).get_json()
        client.post(f"/api/ai-runs/{env['ai_run_id']}/apply", json={})
    for question, _intent in QUESTIONS:
        check_answer(ask(client, question))
    body = ask(client, "Why is Resources red?", initiative_id=hero, page="pg3")
    check_answer(body)
    if body["mode"] == "simulated_generated":
        assert "Sana Whitfield" in body["answer_md"]
        assert any(a.get("api") == f"/api/initiatives/{hero}/ai/rebalance" for a in body["suggested_actions"])


def test_showcase_fixture_binds_live_numbers(client):
    body = ask(client, "Which CRQs are non-compliant?")
    noncompliant = assistant.resolve_binding("count_noncompliant_crqs")
    assert noncompliant is not None and noncompliant in body["answer_md"]


def test_showcase_not_used_for_a_different_person(client):
    body = ask(client, "What is Lena Oduya working on?")
    assert "Lena Oduya" in body["answer_md"] and "Sana Whitfield" not in body["answer_md"]


def test_page_context_resolves_this_initiative(client):
    rid = db.query_one("SELECT id, rddc FROM initiatives WHERE stage = 'QA' LIMIT 1")
    body = ask(client, "What is the status of this initiative?", initiative_id=rid["id"])
    assert rid["rddc"] in body["answer_md"]


def test_missing_initiative_asks_which(client):
    body = ask(client, "When is QA?")
    assert body["intent"] == "milestone_dates" and "Which initiative" in body["answer_md"]
    assert body["follow_ups"]


def test_help_offers_example_chips(client):
    body = ask(client, "asdf qwerty")
    assert body["intent"] == "help" and len(body["follow_ups"]) == 4


def test_conversation_is_stored(client):
    first = ask(client, "Which projects are red?")
    ask(client, "Who knows Kafka?", conversation_id=first["conversation_id"])
    conv = client.get(f"/api/assistant/conversations/{first['conversation_id']}").get_json()
    assert [m["role"] for m in conv["messages"]] == ["user", "assistant", "user", "assistant"]
    assert client.get("/api/assistant/conversations/nope").status_code == 404
    assert client.post("/api/assistant/chat", json={"message": "  "}).status_code == 422


def test_assistant_is_deterministic(ai_app):
    a = provider.run_feature("assistant", None, {"message": "Who is over-allocated in December?"})
    b = provider.run_feature("assistant", None, {"message": "Who is over-allocated in December?"})
    assert a["output"] == b["output"]


def test_live_tools_return_data(ai_app):
    assert assistant.run_tool("search_initiatives", {"rag": "Red"})
    assert assistant.run_tool("get_initiative", {"rddc": "RDDC-24412"})["rddc"] == "RDDC-24412"
    assert isinstance(assistant.run_tool("get_allocations", {"month_from": "2026-11", "month_to": "2026-12"}), list)
    assert isinstance(assistant.run_tool("portfolio_stats", {"group_by": "lob"}), dict)
    assert isinstance(assistant.run_tool("find_resources", {"skills": ["Kafka"]}), list)


def test_placeholder_percent_sign_never_doubles():
    from app.ai.simulated import _substitute

    assert _substitute({"t": "{x}% booked, {x} of plan"}, {"x": "58%"}) == {"t": "58% booked, 58% of plan"}
    assert _substitute(["{n}% done"], {"n": "40"}) == ["40% done"]


ASSISTANT_JS = Path(__file__).resolve().parents[2] / "static" / "js" / "views" / "assistant.js"


def ui_chips() -> dict[str, list[str]]:
    """The suggested-prompt chips the drawer offers (static/js/views/assistant.js PROMPTS)."""
    if not ASSISTANT_JS.is_file():
        return {}
    block = re.search(r"const PROMPTS = \{(.*?)\n\};", ASSISTANT_JS.read_text(encoding="utf-8"), re.DOTALL)
    out: dict[str, list[str]] = {}
    for key, body in re.findall(r"(\w+):\s*\[(.*?)\]", block.group(1) if block else "", re.DOTALL):
        out[key] = [a or b for a, b in re.findall(r"'((?:[^'\\]|\\.)*)'|\"((?:[^\"\\]|\\.)*)\"", body)]
    return out


def test_every_ui_chip_routes_to_an_answer(client, hero, l2_approve):
    """L5-02: chips (with typographic apostrophes) never fall back to help, on every page they appear."""
    chips = ui_chips()
    if not chips:
        pytest.skip("assistant drawer not built yet")
    for slug in ("change-summary", "wbs"):
        if slug == "wbs":
            l2_approve(hero)
        env = client.post(f"/api/initiatives/{hero}/ai/{slug}", json={}).get_json()
        client.post(f"/api/ai-runs/{env['ai_run_id']}/apply", json={})
    for page, prompts in chips.items():
        for prompt in prompts:
            extra = {"initiative_id": hero, "page": "pg1"} if page == "initiative" else {"page": page}
            body = ask(client, prompt, **extra)
            check_answer(body)
            assert body["intent"] != "help", (page, prompt)


def test_curly_quotes_match_like_straight_ones(client, hero):
    straight = ask(client, "What's driving the health status?", initiative_id=hero)
    curly = ask(client, "What\u2019s driving the health status?", initiative_id=hero)
    assert curly["intent"] == straight["intent"] == "explain_health"
    assert curly["answer_md"] == straight["answer_md"]


def test_release_train_question_lists_the_train(client, hero, l2_approve):
    """L5-03: 'Which initiatives are on DC-2702?' lists every initiative on the train with its RAG."""
    for slug in ("change-summary", "wbs"):
        if slug == "wbs":
            l2_approve(hero)
        env = client.post(f"/api/initiatives/{hero}/ai/{slug}", json={}).get_json()
        client.post(f"/api/ai-runs/{env['ai_run_id']}/apply", json={})
    body = ask(client, "Which initiatives are on DC-2702?")
    on_train = [r["rddc"] for r in db.query("SELECT rddc FROM initiatives WHERE target_release = 'DC-2702' AND stage != 'Closed'")]
    assert on_train and all(r in body["answer_md"] for r in on_train)
    assert "No active initiative is Red" not in body["answer_md"]
    check_answer(body)


def test_page_context_scopes_initiative_questions(client):
    """L5-04: in a workspace, 'this initiative' questions answer for it and never get a portfolio showcase."""
    row = db.query_one("SELECT id, rddc FROM initiatives WHERE rddc = 'RDDC-24688'")
    over = ask(client, "Who is over-allocated on this initiative?", initiative_id=row["id"])
    assert over["mode"] == "simulated_generated" and over["intent"] == "overallocated_resources"
    held = {r["resource_id"] for r in db.query("SELECT DISTINCT resource_id FROM allocations WHERE initiative_id = ?", (row["id"],))}
    for c in over["citations"]:
        if c["type"] == "resource":
            assert c["id"] in held
    risks = ask(client, "What are the top risks?", initiative_id=row["id"])
    assert risks["mode"] == "simulated_generated"
    cited = {c["id"] for c in risks["citations"] if c["type"] == "risk"}
    allowed = {r["risk_code"] for r in db.query("SELECT risk_code FROM risks WHERE initiative_id = ?", (row["id"],))}
    assert cited <= allowed
