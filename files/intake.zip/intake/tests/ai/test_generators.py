"""Deterministic generators: schema-valid for every feature and initiative, hero numbers pinned (master plan §6.2)."""
from __future__ import annotations

import json

import pytest

from app import db
from app.ai import context as C
from app.ai import generators as G
from app.ai.schemas import SCHEMAS, validate

INITIATIVE_FEATURES = ("intake_analysis", "change_summary", "l2_estimate", "wbs", "resources", "rebalance", "risks",
                       "exec_summary", "cr_compliance", "lessons")
GLOBAL_CASES = (
    ("skill_matrix", {}), ("nudges", {}), ("exec_summary", {}), ("lessons", {}),
    ("intake_analysis", {"name": "OLB Real-time Alerts", "lob": "Canadian P&C",
                         "description": "ASAP minor UI changes similar to existing alerts, etc."}),
    ("intake_autofill", {"text": "Solution Architecture: OLB Real-time Alerts\nVersion 0.3 · Author: Mateo Brennan\n"
                                 "LOB: Canadian P&C\n\n1. Business context\nCustomers want real-time alerts in Online Banking."}),
    ("meeting_extract", {"text": "Weekly DC sync 2026-10-16\nAttendees: Grace Ellingham, Sana Whitfield\n"
                                 "Decision: RDDC-24412 moves to DC-2701 if validation fails\n"
                                 "Action: Sana to finish the SA document by Wed\nRisk: CIAM capacity in December\n"
                                 "Is data residency confirmed?"}),
)


def _offline_ctx(bundle: dict, feature: str, inputs: dict | None = None) -> dict:
    people = [{"id": r["id"], "name": r["name"], "role": r["role"], "team": r["team"]} for r in bundle["resources"]]
    return {"feature": feature, "initiative_id": 9, "today": "2026-10-19", "inputs": inputs or {}, "bundle": bundle,
            "subject": None, "data": {"people_rows": people, "catalog": bundle["component_catalog"], "others": []},
            "scope": "initiative", "keys": {"rddc": "RDDC-24817"}}


# ------------------------------------------------------------------ hero bundle (no database)
def test_hero_wbs_skeleton_matches_pinned_plan(hero_bundle):
    out = G.generate("wbs", _offline_ctx(hero_bundle, "wbs"))
    assert validate("wbs", out) == []
    rows = {t["wbs_code"]: t for t in out["tasks"]}
    assert list(rows) == ["WBS-100", "WBS-200", "WBS-210", "WBS-220", "WBS-230", "WBS-240", "WBS-300", "WBS-310",
                          "WBS-320", "WBS-400", "WBS-500", "WBS-600", "WBS-700", "WBS-800"]
    assert sum(rows[c]["est_hours"] for c in ("WBS-210", "WBS-220", "WBS-230", "WBS-240")) == 560
    assert out["total_est_hours"] == 859
    expect = {"WBS-100": (70, 50, 14), "WBS-210": (280, 100, 1), "WBS-220": (120, 43, 2), "WBS-230": (120, 43, 4),
              "WBS-240": (40, 29, 6), "WBS-300": (56, 80, 3), "WBS-310": (24, 70, 13), "WBS-320": (24, 70, 10),
              "WBS-400": (56, 100, 12), "WBS-500": (14, 100, 22), "WBS-600": (14, 100, 20), "WBS-800": (35, 50, 6)}
    for code, (hours, pct, rid) in expect.items():
        assert (rows[code]["est_hours"], rows[code]["allocation_pct"], rows[code]["suggested_resource_id"]) == (hours, pct, rid), code
    assert rows["WBS-700"]["is_milestone"] and rows["WBS-700"]["duration_days"] == 0
    sched = G.schedule_plan(out["tasks"], "2026-10-20", C.release_trains(), "DC-2702")
    d = sched["dates"]
    assert d["WBS-100"] == ("2026-10-20", "2026-11-17")
    assert d["WBS-210"] == ("2026-11-18", "2027-01-15")
    assert d["WBS-300"] == ("2027-01-18", "2027-01-29")
    assert d["WBS-400"] == ("2027-02-01", "2027-02-10")
    assert d["WBS-500"] == ("2027-02-11", "2027-02-12")
    assert d["WBS-600"] == ("2027-02-16", "2027-02-17")
    assert d["WBS-700"] == ("2027-02-20", "2027-02-20")
    assert d["WBS-800"] == ("2027-02-22", "2027-03-05")
    assert sched["train"] == "DC-2702"


def test_hero_l2_numbers_come_from_engine(hero_bundle):
    out = G.generate("l2_estimate", _offline_ctx(hero_bundle, "l2_estimate"))
    assert validate("l2_estimate", out) == []
    assert (out["total_hours"], out["low_hours"], out["high_hours"], out["tshirt"], out["dev_hours"]) == (1000, 750, 1250, "L", 560)


def test_hero_change_summary_from_sa_text(hero_bundle):
    out = G.generate("change_summary", _offline_ctx(hero_bundle, "change_summary"))
    assert validate("change_summary", out) == []
    rows = {r["component_code"]: (r["complexity"], r["approval"], r["est_hours"]) for r in out["components"]}
    assert rows == {"APIP": ("High", "Approved", 280), "EDP": ("Medium", "Approved", 120),
                    "CIAM": ("Medium", "Pending", 120), "SRE": ("Low", "Not required", 40)}
    assert out["sa_completeness"] == 88
    assert len(out["open_items"]) == 2 and all("TBD" in i for i in out["open_items"])
    assert any("backout" in g.lower() for g in out["gaps"])


def test_hero_rebalance_moves_wbs100_to_mateo(hero_bundle):
    out = G.generate("rebalance", _offline_ctx(hero_bundle, "rebalance"))
    assert validate("rebalance", out) == []
    assert (out["problem"]["resource_id"], out["problem"]["month"], round(out["problem"]["util_pct"])) == (14, "2026-11", 128)
    best = out["options"][out["recommended_option_index"]]
    assert (best["task_wbs_code"], best["to_resource_id"]) == ("WBS-100", 15)
    assert best["before"] == {"from_pct": 128, "to_pct": 42}
    assert best["after"] == {"from_pct": 96, "to_pct": 74}
    assert best["health_after"] == {"resources": "Green", "overall": "Amber"}


@pytest.mark.parametrize("feature", ["intake_analysis", "change_summary", "l2_estimate", "wbs", "resources", "rebalance",
                                     "risks", "exec_summary", "lessons"])
def test_hero_bundle_generators_valid_and_deterministic(hero_bundle, feature):
    first = G.generate(feature, _offline_ctx(hero_bundle, feature))
    second = G.generate(feature, _offline_ctx(hero_bundle, feature))
    assert validate(feature, first) == []
    assert json.dumps(first, sort_keys=True) == json.dumps(second, sort_keys=True)
    regen = G.generate(feature, _offline_ctx(hero_bundle, feature), variant=1)
    assert validate(feature, regen) == []


# ------------------------------------------------------------------ seeded database
def _seeded_ids() -> list[int]:
    return [r["id"] for r in db.query("SELECT id FROM initiatives WHERE id > 0 ORDER BY id")]


def test_every_initiative_feature_valid_for_every_seeded_initiative(ai_app, hero):
    ids = _seeded_ids()
    assert len(ids) >= 9
    for feature in INITIATIVE_FEATURES:
        for iid in ids:
            ctx = C.build_context(feature, iid, {})
            out = G.generate(feature, ctx)
            assert validate(feature, out) == [], (feature, iid, validate(feature, out)[:3])
            again = G.generate(feature, C.build_context(feature, iid, {}))
            assert json.dumps(out, sort_keys=True) == json.dumps(again, sort_keys=True), (feature, iid)


def test_cr_compliance_for_every_change_request(ai_app):
    for cr in db.query("SELECT id, initiative_id FROM change_requests ORDER BY id"):
        ctx = C.build_context("cr_compliance", cr["initiative_id"], {"change_request_id": cr["id"]})
        out = G.generate("cr_compliance", ctx)
        assert validate("cr_compliance", out) == []
        assert out["crq_number"] == db.scalar("SELECT crq_number FROM change_requests WHERE id = ?", (cr["id"],))


@pytest.mark.parametrize(("feature", "inputs"), GLOBAL_CASES)
def test_global_generators_valid(ai_app, feature, inputs):
    out = G.generate(feature, C.build_context(feature, None, inputs))
    assert validate(feature, out) == []
    again = G.generate(feature, C.build_context(feature, None, inputs))
    assert json.dumps(out, sort_keys=True) == json.dumps(again, sort_keys=True)


def test_meeting_extract_reads_seeded_notes(ai_app):
    for note in db.query("SELECT id FROM meeting_notes ORDER BY id"):
        out = G.generate("meeting_extract", C.build_context("meeting_extract", None, {"meeting_note_id": note["id"]}))
        assert validate("meeting_extract", out) == []


def test_lessons_draft_for_closed_initiative(ai_app):
    closed = db.query_one("SELECT id, rddc FROM initiatives WHERE stage = 'Closed' AND id > 0 ORDER BY id LIMIT 1")
    assert closed is not None
    out = G.generate("lessons", C.build_context("lessons", closed["id"], {}))
    assert out["mode"] == "draft" and out["initiative_rddc"] == closed["rddc"]
    assert validate("lessons", out) == []


def test_generators_cover_every_feature():
    assert set(G.GENERATORS) == set(SCHEMAS)
