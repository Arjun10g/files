"""Round 1b (QA-C-03, QA-C-04): AI text and fixtures always agree with the live screen."""
from __future__ import annotations

import json

from app import db
from app.ai import assistant, generators, provider, schemas, simulated
from app.ai import context as C


def _hero_planned(client, hero, approve):
    cs = client.post(f"/api/initiatives/{hero}/ai/change-summary", json={}).get_json()
    client.post(f"/api/ai-runs/{cs['ai_run_id']}/apply", json={})
    approve(hero)
    wbs = client.post(f"/api/initiatives/{hero}/ai/wbs", json={}).get_json()
    client.post(f"/api/ai-runs/{wbs['ai_run_id']}/apply", json={})


def _slip_wbs210(client, hero, days: int = 5):
    task = db.query_one("SELECT id, planned_end FROM wbs_tasks WHERE initiative_id = ? AND wbs_code = 'WBS-210'", (hero,))
    new_end = C.add_business_days(task["planned_end"], days).isoformat()
    res = client.put(f"/api/tasks/{task['id']}", json={"planned_end": new_end})
    assert res.status_code == 200, res.get_json()


def test_float_matches_plan_before_and_after_slip(client, hero, l2_approve):
    """QA-C-03: the assistant's readiness float is the Pg 2 / health float, negative when the train is missed."""
    _hero_planned(client, hero, l2_approve)
    assert assistant.resolve_binding("readiness_float:RDDC-24817") == "2"
    _slip_wbs210(client, hero)
    row = db.query_one("SELECT * FROM initiatives WHERE id = ?", (hero,))
    expected = C.readiness_float_bd(row["readiness_date"], "2027-02-20")
    assert row["readiness_date"] == "2027-02-24" and expected == -3
    assert assistant.resolve_binding("readiness_float:RDDC-24817") == "-3"
    assert assistant.resolve_binding("float_bd:RDDC-24817") == "-3"
    health = json.loads(row["health_cached_json"])
    assert health["dimensions"]["schedule"]["metrics"]["float_bd"] == -3
    body = client.post("/api/assistant/chat", json={"message": "When is QA for RDDC-24817?"}).get_json()
    if body["mode"] == "simulated_generated":
        assert "misses the train by 3 business days" in body["answer_md"]
    assert "17 business days" not in body["answer_md"]
    risks = provider.run_feature("risks", hero, {}, force_mode="simulated")["output"]
    assert not any("float of 17" in r["title"] for r in risks["risks"])


def _write_fixture(folder, feature, key, match, variant):
    (folder / feature).mkdir(parents=True, exist_ok=True)
    data = {"fixture_version": 1, "feature": feature, "key": key, "match": match, "variants": [variant]}
    path = folder / feature / f"{key}.json"
    path.write_text(json.dumps(data), encoding="utf-8")
    assert schemas.validate_fixture_file(path) == []
    return data


def test_requires_gates_fixtures_on_live_state(client, hero, l2_approve, no_fixtures):
    """QA-C-04: a fixture with match.requires is served only while every requirement holds."""
    _hero_planned(client, hero, l2_approve)
    ctx = C.build_context("exec_summary", None, {})
    variant = generators.generate("exec_summary", ctx)
    _write_fixture(no_fixtures, "exec_summary", "portfolio", {
        "name_contains": "portfolio",
        "requires": {"initiatives_exist": ["RDDC-24817"], "health": {"RDDC-24817": {"overall": "Amber", "resources": "Red"}},
                     "stage_in": {"RDDC-24817": ["Planning", "Build"]}, "float_bd": {"RDDC-24817": 2}}}, variant)
    served = client.post("/api/ai/exec-summary", json={}).get_json()
    assert served["mode"] == "simulated_fixture"
    _slip_wbs210(client, hero)
    after = client.post("/api/ai/exec-summary", json={}).get_json()
    assert after["mode"] == "simulated_generated"


def test_requires_absent_and_unknown_keys(ai_app, no_fixtures):
    data = {"match": {"requires": {"initiatives_absent": ["RDDC-24817"]}}}
    assert simulated.requirements_met(data)
    assert not simulated.requirements_met({"match": {"requires": {"initiatives_exist": ["RDDC-24817"]}}})
    assert not simulated.requirements_met({"match": {"requires": {"made_up": True}}})
    bad = {"fixture_version": 1, "feature": "risks", "key": "x", "match": {"requires": {"made_up": True}}, "variants": [{}]}
    assert schemas.validate_fixture_data(bad)


def test_rebalance_effect_text_follows_live_health(client, hero, l2_approve, monkeypatch):
    """QA-C-04 case 2: the Suggest fix wording never contradicts the health shown under it."""
    _hero_planned(client, hero, l2_approve)
    monkeypatch.setattr(generators, "health_after", lambda b: {"resources": "Green", "overall": "Red"})
    env = client.post(f"/api/initiatives/{hero}/ai/rebalance", json={}).get_json()
    best = env["output"]["options"][env["output"]["recommended_option_index"]]
    assert best["health_after"] == {"resources": "Green", "overall": "Red"}
    assert "Amber" not in best["effect"] and "Red" in best["effect"]


def test_change_summary_generator_reads_uploaded_docx_and_pdf(hero_bundle):
    """Without the fixture, the generator still finds the four hero components in extracted .docx and .pdf text."""
    from pathlib import Path

    import pytest

    textract = pytest.importorskip("app.textract")
    files = Path(__file__).resolve().parents[2] / "app" / "seed" / "files"
    for name, mime in (("SA_US_API_Enhancement_v1.2.pdf", "application/pdf"),
                       ("SA_US_API_Enhancement_v1.2.docx",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document")):
        if not (files / name).is_file():
            continue
        bundle = {**hero_bundle, "sa_doc_text": textract.extract_text(str(files / name), mime)}
        ctx = {"feature": "change_summary", "initiative_id": 9, "today": "2026-10-19", "inputs": {}, "bundle": bundle,
               "subject": None, "data": {}, "scope": "initiative", "keys": {}}
        out = generators.generate("change_summary", ctx)
        assert {c["component_code"]: (c["complexity"], c["approval"]) for c in out["components"]} == {
            "APIP": ("High", "Approved"), "EDP": ("Medium", "Approved"), "CIAM": ("Medium", "Pending"),
            "SRE": ("Low", "Not required")}, name
