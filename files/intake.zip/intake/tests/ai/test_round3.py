"""Round 3 (Director N5–N13): clean, complete answers on the presenter's own questions."""
from __future__ import annotations

import re

from app import db
from app.ai import context as C
from app.ai import generators, provider


def _plan_hero(client, hero, approve, resources=True):
    for slug in ["change-summary", "wbs"] + (["resources"] if resources else []):
        if slug == "wbs":
            approve(hero)
        env = client.post(f"/api/initiatives/{hero}/ai/{slug}", json={}).get_json()
        client.post(f"/api/ai-runs/{env['ai_run_id']}/apply", json={})


def ask(client, message, **extra):
    res = client.post("/api/assistant/chat", json={"message": message, **extra})
    assert res.status_code == 200, res.get_json()
    return res.get_json()


def test_n5_answers(client, hero, l2_approve):
    _plan_hero(client, hero, l2_approve)
    sto = ask(client, "Which CRQs are not ready for STO go/no-go this week?")
    assert sto["intent"] == "crq_sto_readiness"
    assert not re.search(r"[.;]\s*[.;]|\.;|;\s*\.", sto["answer_md"]), sto["answer_md"]
    if "due " in sto["answer_md"]:
        assert re.search(r"(STO Go|CRQ approval|validation evidence|Backout plan)[^;]* due ", sto["answer_md"])
    over = ask(client, "Which PRNs are forecast to overrun?")
    assert over["intent"] == "prn_overrun" and "Which PRN?" not in over["answer_md"]
    from app.ai.assistant import prn_burndown
    overrunning = [p["prn_code"] for p in db.query("SELECT prn_code FROM prn_budget")
                   if (b := prn_burndown(p["prn_code"])) and b["forecast_hours"] > b["funded_hours"]]
    assert all(code in over["answer_md"] for code in overrunning)
    train = ask(client, "How many initiatives and hours are landing on DC-2702?")
    assert re.search(r"[\d,]+ h\*\* planned in total", train["answer_md"])
    dec = ask(client, "Who is over-allocated in December and what should we do about it?")
    assert dec["intent"] == "overallocated_resources"
    if "over-allocated in" in dec["answer_md"] and "No one" not in dec["answer_md"]:
        assert "Suggested for" in dec["answer_md"] or "consider moving dates" in dec["answer_md"]


def test_n6_burn_rate_is_the_charts(client):
    from app.ai.assistant import prn_burndown

    b = prn_burndown("PRN-71840")
    body = ask(client, "How many hours are left on PRN-71840 and when does funding run out?")
    assert generators.fmt_hours(b["burn_rate"]) in body["answer_md"]
    assert str(b.get("burn_rate_window") or "3-month average") in body["answer_md"]


def test_n7_script_path_serves_prepared_intake_analysis(client):
    intake = client.get("/api/dc-intakes/DCI-3391").get_json()
    body = {k: intake[k] for k in ("name", "lob", "priority", "requestor", "requested_go_live", "description") if intake.get(k)}
    body.update({"dc_intake": "DCI-3391", **{k: intake[k] for k in ("dc_pm_id", "dc_sa_id", "tech_lead_id", "pm_id") if intake.get(k)}})
    iid = client.post("/api/initiatives", json=body).get_json()["initiative"]["id"]
    env = client.post(f"/api/initiatives/{iid}/ai/intake-analysis", json={}).get_json()
    assert env["mode"] == "simulated_fixture", env["warnings"]
    ini = db.query_one("SELECT target_release, prn_code FROM initiatives WHERE id = ?", (iid,))
    checks = {f["field"]: f for f in env["output"]["field_checks"]}
    if ini["target_release"] and "target_release" in checks:
        assert checks["target_release"]["status"] == "present"


def test_n7_rules_engine_reasons_read_like_evidence(hero_bundle):
    comps = generators.likely_components(hero_bundle["initiative"]["description"], hero_bundle["component_catalog"])
    reasons = {c["component_code"]: c["reason"] for c in comps}
    assert reasons["APIP"].endswith("→ API Platform") and "/v2/accounts" in reasons["APIP"]
    assert not any(r.startswith("Mentions") for r in reasons.values())


def test_n8_resources_scoped_and_assign_on_selection(client, hero, l2_approve):
    _plan_hero(client, hero, l2_approve, resources=False)
    env = client.post(f"/api/initiatives/{hero}/ai/resources", json={"options": {"wbs_code": "WBS-210"}}).get_json()
    blob = " ".join(env["warnings"]) + " " + " ".join(s["label"] for s in env["sources"])
    assert "WBS-100" not in blob and "Sana" not in blob and "Mateo" not in blob
    for rec in env["output"]["recommendations"]:
        for c in rec["candidates"]:
            assert not any("Best fit · over capacity" in x for x in c["concerns"])
            if any(x.startswith("Over capacity") for x in c["concerns"]):
                assert c["peak_util_after_pct"] > 100
    one = client.post(f"/api/initiatives/{hero}/ai/resources", json={"options": {"wbs_code": "WBS-100"}}).get_json()
    rec = one["output"]["recommendations"][0]
    want = rec["recommended_resource_id"] or rec["candidates"][0]["resource_id"]
    client.post(f"/api/ai-runs/{one['ai_run_id']}/apply", json={"selected": [0]})
    assert db.scalar("SELECT resource_id FROM wbs_tasks WHERE initiative_id = ? AND wbs_code = 'WBS-100'", (hero,)) == want


def test_n9_follow_ups_have_true_premises(ai_app):
    rows = db.query("SELECT rddc, rag_cached FROM initiatives WHERE id > 0")
    red = next((r for r in rows if r["rag_cached"] == "Red"), None)
    green = next((r for r in rows if r["rag_cached"] == "Green"), None)
    if red:
        assert provider.follow_up_holds(f"Why is {red['rddc']} Red?", {})
    if green:
        assert not provider.follow_up_holds(f"Why is {green['rddc']} Red?", {})
    any_resources_red = any(((C.parse_row(r).get("health_cached_json") or {}).get("dimensions") or {}).get("resources", {}).get("rag") == "Red"
                            for r in db.query("SELECT health_cached_json FROM initiatives WHERE id > 0 AND health_cached_json IS NOT NULL"))
    assert provider.follow_up_holds("Why is Resources red?", {}) is any_resources_red


def test_n10_cr_compliance_is_a_rules_check(client):
    cr = db.query_one("SELECT id, initiative_id FROM change_requests ORDER BY id LIMIT 1")
    env = client.post(f"/api/initiatives/{cr['initiative_id']}/ai/cr-compliance", json={"options": {"change_request_id": cr["id"]}}).get_json()
    assert env["mode_label"] == "Rules check" and env["deterministic"] is True
    assert env["output"]["sto_readiness"] in ("Ready for Go", "Tentative", "Not ready", "Not requested")


def test_n13_chat_summary_is_the_cards_text(client):
    card = provider.preview_feature("exec_summary", None, {})
    chat = ask(client, "Draft this week's exec summary")
    assert card["headline"] in chat["answer_md"]
    assert card["summary_md"].split("\n")[0][:60] in chat["answer_md"]


def test_comparable_wording_in_delivery(ai_app):
    out = {"comparables": [{"rddc": r["rddc"], "name": "x", "actual_hours": 0, "similarity": 0.5, "note": ""}
                           for r in db.query("SELECT rddc FROM initiatives WHERE id > 0 AND stage != 'Closed' LIMIT 1")]}
    provider._fix_comparables(out, ["APIP"])
    for c in out["comparables"]:
        assert c["note"].endswith("(in delivery)") and "not yet delivered" not in c["note"] and "actual" not in c["note"]
