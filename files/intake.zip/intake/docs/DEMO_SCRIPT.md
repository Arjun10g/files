# Demo script · Digital Channels Project Management Tool (about 9 minutes)

**Before you start:** `./run_demo.sh` (resets data, opens http://127.0.0.1:5055). Optional: Settings → AI response speed → Fast for a rehearsal; Realistic for the room. Have `data/uploads/SA_US_API_Enhancement_v1.2.docx` ready to drag in.
**Story:** enter the intake once → the tool calculates, visualises and automates. Demo date is Mon 19 Oct 2026.
**If anything goes wrong:** Settings → **Fast-forward hero** builds RDDC-24817 end to end; continue from step 9.

| # | Click | Say / point at |
|---|---|---|
| 1 | **Portfolio View** (home) | KPI strip: Active 7 · Red 1 · Amber 1 · CRQs this week 2 · Over-allocated 2. The three tiles are the deck's MVP 1 dashboard: Project Health, Resource Capacity, Project Gantt. "This is where we end up. Let's add one intake." |
| 2 | **Add New Initiative** → DC Intake `DCI-3391` → **Look up** | Name, LOB, requestor, priority, go-live, DC PM, DC SA and Tech Lead pre-fill from the DC intake. |
| 3 | **Save** | RDDC-24817 assigned. Toast: "Slotted for grooming Tue 20 Oct, 10:00" — invite in the Outbox. Intake Analysis card: completeness, suggested labels, likely components, closest past initiative. |
| 4 | Pg 1 → drop the SA document | SA Completeness **88%** · Missing: Backout plan · "Action required by Sana Whitfield · Wed 21 Oct". |
| 5 | **Mark as groomed** | Stage Grooming → Solution (the grooming walk-through has happened). |
| 6 | ✦ **Generate Change Summary** → **Accept** | Thinking steps, then 4 DC components with approvals and SA § citations: API Platform (High), EDP (Medium), CIAM / Security (Medium, Pending), SRE / Observability (Low). L2 panel: **1,000 h · L · 750–1,250 h** — open "How we got this". |
| 7 | Persona → Dev Lead → **Send L2 to DLR**; Persona → Requestor → **Approve L2** | L2 Approved, stage → Planning, demand flips Tentative → Confirmed. |
| 8 | Pg 2 ✦ **Generate Project Plan** → **Accept** | 14-step WBS with owners, hours, dependencies. Key dates: QA **Wed 10 Feb 2027**, Readiness **Wed 17 Feb**, Production **Sat 20 Feb (DC-2702)**, float 2 business days. "Plan 859 h vs L2 1,000 h" reconciliation line. |
| 9 | ✦ **Generate Gantt view** → Show critical path. Then edit **WBS-210 End** +5 business days | Bars, today line, freeze band, train markers. The edit cascades: Readiness 24 Feb, "Misses DC-2702", Schedule **Red**. Click **Undo last change** → back to Amber. "Health is calculated, not typed." |
| 10 | Pg 3 Resource Management | Quarter grid (Nov–Jan · Feb–Apr …), heatmap: **Sana Whitfield 128% in Nov**. Project Health: Overall **Amber** · Schedule Amber · Resources **Red** · Scope Green · Dependencies Green · Budget Green · "SA capacity constraint affecting WBS-100" — the deck slide, live. |
| 11 | Red Resources pill → **Suggest fix** → **Accept** | Move WBS-100 to Mateo Brennan: Sana 128% → 96%, Mateo 42% → 74%. Resources Green, overall stays Amber (schedule float). |
| 12 | Risks tab ✦ **Predict risks** → **Add selected to Risk Register** | Risk register rows with severity × likelihood, trigger signal, dated mitigations, linked WBS. |
| 13 | Pg 4 ✦ **Create CRQ draft** → review → **Accept** → ✦ **Check CR Compliance** | CRQ000001052216, Sat 20 Feb 02:00–06:00, Bundle, DC-2702, STO "Not requested". Compliance: 1 flag (backout plan), STO/CRQ approval "Not due yet · due Wed 17 Feb". |
| 14 | **Portfolio View** | RDDC-24817 now in the Project Dashboard and Change Management tables, heatmap and Gantt. |
| 15 | **Ask Assistant**: "Which initiatives are at risk for the Feb release and why?" · "Draft this week's exec summary" · "Who has CIAM capacity in January?" · "What happens to RDDC-24817 if CIAM approval slips two weeks?" | Grounded answers with RDDC links; Copy to email. Invite one question from the room. |
| 16 | **Initiative Demo View workbook…** (RDDC-24817) | The Excel Demo View, generated: Pg 1–4 boxes with yellow automation cells, Gantt, Capacity, Risk Register, Lists. |
| 17 | Close | "Enter once · calculate · visualise · automate." AI Activity shows every AI run, its mode and the time saved. |

**About the AI:** the badge reads "Simulated AI". "Prepared response" = drafted in advance by an AI test agent from the same prompt and data, served only while the live data still matches; anything else is answered by the rules engine. With an API key, Settings → Live Claude runs the same prompts live. Nothing AI-generated is saved until Accept; dates, hours, capacity and RAG are always calculated.
