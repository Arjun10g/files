# Requirements

Sources: the `MVP_Backlog.xlsx` workbook and the "Project Management Tool" roadmap deck.

## 1. The ask
Build something like the workbook's Demo View tab as an initial demo, then add automations to it. The first use case is deriving the **Project Plan and Gantt Chart** from the intake; later, **associated risks and suggested resources**.

Workbook: `MVP_Backlog.xlsx` with tabs **Mission Statement · MVP Backlog · Demo View · Sheet1**.

## 2. Mission Statement (tab 1)
"Create a single platform that manages intake, planning, governance, delivery, resource management, documentation, reporting, and AI-assisted decision making from project initiation through production deployment."

## 3. MVP Backlog (tab 2)
Columns: Epic# | Description | Priority | Features | User Stories | Current State | Future State | Acceptance Criteria

| Epic | Description | Pri | Feature | User story | Current | Future | Acceptance criteria |
|---|---|---|---|---|---|---|---|
| Epic-1 | Intake & Demand Management | 1 | Intake Registration (RDDC creation) | As a requestor, I want to create a RDDC ticket | Manual | Manual | NA |
| | | 1 | Demand Prioritization (Grooming) | As a Delivery Lead, I want to slot the respective ticket in the next available grooming session | Manual | Automated | Requested tickets (To Do) to be scheduled for the upcoming grooming session with respective recipients |
| | | 1 | Solution Finalization | As a DC Solution Architect, I want to give my inputs so that the Channels SA can share the finalized SA document | Manual | Automated | Any action/input needed from DC SA, to be sent every two days as "action required by" |
| | | 2 | Effort Estimation | As a Development Lead, I want to get the finalized L2 to review and share it with DLR | Manual | Automated | L2 to be calculated based on the scope at discussion phase |
| | | 3 | Approval reminders | As an intake requestor, I want to receive regular reminders on pending L2 approvals | Manual | Automated | Regular reminders to the requestors for L2 approvals |
| Epic-2 | Project Planning | 1 | Project Setup | As a Project Manager, I want to have the detailed project plan with each actionable step mentioned in the form of WBS | Manual | Automated | Project Plan set up with WBS including: readiness date, QA date, Developer man-hours, intake against each resource |
| | | 1 | WBS Management and Gantt Chart | As a Project Manager, I want to update regular implementation updates | NA | Manual | PMs and Devs to manually update the details and highlight potential risks |
| | | 1 | Dependency Mapping | As a Development Lead, I want to get know the impact on all downstream and upstream applications | NA | Automated | Test/make changes, and include in the PM actionable step |
| | | 2 | Risk Register | As a PM, I want to see the probable risks with severity and occurrence chance, with actionable items to avoid the risk | NA | Automated | Automated Risk Register to be maintained with actionable steps |
| Epic-3 | Resource Management | 1 | Resource Inventory | As an Account Manager, I want to update monthly hours to each resource as per monthly availability | NA | Manual | Account Manager is able to manually update available hours for each resource |
| | | 1 | Resource Utilization Dashboard | As a Lead, I want to see a calendar view of resource occupancy and individual occupancy | NA | Automated | Resource availability dashboard |
| | | 2 | Project Allocation | As a Lead, I want to see a burndown chart against each PRN (Charged vs Available amount) | Manual | Automated | Dashboard to show PR (PRN) wise burndown is updated |
| | | 1 | Suggested Resources | As a Delivery Lead, I want to see an AI suggested most suitable resource for a new intake | NA | Automated | Suggestion on "Recommended Developer" for the initiative |
| | | 2 | Skill Matrix | As a Lead, I want to see the skill matrix of each resource (has worked on), which will provide more view of the spectrum of skills team has acquired | NA | Automated | AI generated Skill Matrix |
| Epic-4 | Delivery Governance | 1 | Status Reporting | As a team, we want to review the portfolio status | Manual | Automated | (Dashboard) |
| | | 1 | Change Management | As a Lead, I want to see the weekly list of CRs to be reviewed and meet compliance | Manual | Automated | Dashboard to show CRs and notify non-compliance to standards |
| | | | Governance Reviews | As an approver, I want to see the ... | | | |
| | | | Release Tracking | | | | |
| Epic-5 | Artifacts | | Document Repository, Decision Log, Architecture Repository, Lessons Learned, Meeting Notes | | | | |
| Epic-6 | AI Productivity Layer | | Intake Analysis, Project Plan Generation, Risk Prediction, Executive Summarizer, Conversational Assistant | | | | |

## 4. Demo View (tab 3) — the UI to emulate
Left-hand buttons: **Add New Initiative · Edit Initiative · Search Initiative · Portfolio View**. Pages are boxed forms labelled Pg 1..Pg 5.
Yellow-highlighted items are the automation hooks.

**Pg 1 – General Details**
- Left block: RDDC # · Current Status · Assigned To | PM · Tech/Dev Lead | DC PM · DC SA
- Right block: DC Intake · Labels · Requestor | **SA document [attachment]** · Author | DC SA · SA Completeness
- Description of Change (free text)
- **[Generate Change Summary]** "(populated from SA doc attachment)" → table: DC Component | Approval | Change Summary

**Pg 2 – Project Plan** "(WBS to be auto-populated from Change Summary)"
- Table: WBS Steps | Description | SME/Owner | Resource | Start Date | End Date | Status | % Completion | Comments
- **[Generate Gantt view]** "(auto-populated from Project Plan)"

**Pg 3 – Resource Management**
- Table: Resource Name | then per quarter (Nov–Jan, Feb–Apr, May–Jul, Aug–Oct): Availability | Allocation (BMO fiscal year starts Nov)

**Pg 4 – Change Governance**
- Left: CRQ/RCSR # · CRQ Start Date and Time · CRQ End Date and Time · Release Type · Release Train/Sprint | Affected CIs · Target Release · Impacted Component · Implementation Status · CRQ Approval Status | **STO Approval**
- Right: CMS Lead · Rel Lead · Resource | Implementation Status · Technical Validation Status **[attachment]** · Business Validation Status **[attachment]**

**Pg 5 – Portfolio View**
- Project Dashboard table: Intake/RDDC # | Project Name | LOB | DC PM | Stage | RAG | ... | QA Sign-off | Prod/Final | Comments
- Change Management table: Intake/Release | CMS Lead | Rel Lead | Resource | Implementation Status | Technical Validation Status | Business Validation Status

## 5. Sheet1 (lookup lists)
- Status: Backlog, In progress, Completed
- Release Type: Bundle, Independent
- STO Approval: Tentative Go, Tentative No Go, Go, No-Go
- Validation Status: Not Started (Default), In progress, Completed, Failed
- RAG: Red, Amber, Green

## 6. Deck: "Project Management Tool — Roadmap from manual tracking to intelligent portfolio management" (BMO)
**What are we building?** Intake / Project (intake information) → DC Component (impacted components) → WBS (steps to break the project into intermediate milestones) → Resource + Timeline (add resource against WBS) → Automated Views (reports). Tagline: **ENTER ONCE • CALCULATE • VISUALIZE • AUTOMATE**

**MVP 0 | Foundation & design** (data model)
1. Project master — Intake ID • PM • LOB • priority • phase • dates (can be pulled from DC Intake)
2. DC component master — impacted DigCom service/component (each PM needs to create a WBS and assign resources)
3. WBS structure — deliverable • owner • planned/forecast dates • progress (Gantt chart view)
4. Resource model — resource • role • allocation % • assignment dates (resource allocation view)
5. Health framework — RAG dimensions • risks • health check

**MVP 1 | Immediate working product**: 1 INTAKE / PROJECT (create or select intake: PM • LOB • priority • phase • dates) → 2 + ADD DC COMPONENT (select impacted service; add component lead and WBS) → 3 WBS + RESOURCES (dates • forecast • status; resource • role • allocation %) → 4 AUTOMATIC OUTPUTS (health • capacity • Gantt • DC component demand)

**How one input creates multiple views**: Intake "US API Enhancement" · DC Component "API Platform | EDP | Security" · WBS "Architecture | Development | Integration" · Resource Assignment "Dev Name → Nov'25 to Mar'26" ⇒ PROJECT HEALTH (RAG + risks), RESOURCE CAPACITY (demand vs availability), PROJECT GANTT (WBS + dependencies)

**MVP 1 dashboard experience** ("what we should be able to demonstrate once the first increment is working")
- PROJECT HEALTH: overall Amber — Schedule Amber, Resources Red, Scope Green, Dependencies Green; "Management attention: SA capacity constraint affecting WBS-100"
- RESOURCE CAPACITY: bars per team — EAPI (Dev1), EAPI (Dev2), CIAM, SRE
- PROJECT GANTT: Estimation, Development, QA, Production

**Roadmap | Visibility → Governance → Intelligence**: Foundation: Data model · MVP1: Visibility · MVP2: Governance · MVP3: Delivery intelligence · MVP4: Automation + forecast

**Immediate team actions**: 01 Agree the fields (project, component, WBS, resource, timeline and status fields) · 02 Define RAG rules (which health dimensions are manual vs calculated and their thresholds) · 03 Agree capacity logic (available capacity, allocation %, time period and tentative vs confirmed demand) · 04 Prototype the data layer (initial lists / data structure and sample intakes) · 05 Build 3 priority views (Project Health • Resource Capacity • Gantt / Timeline) · 06 Pilot and refine (small set of representative intakes before scaling)

**FIRST DEMO GOAL = ONE INTAKE IN | HEALTH + CAPACITY + GANTT CHART**

## 7. Glossary (inferred)
DC = Digital Channels; RDDC = intake ticket id; SA = Solution Architect / SA document; L2 = level-2 estimate; DLR = delivery lead review; CRQ/RCSR = change request; STO = go/no-go approval authority; CMS = change management; LOB = line of business; PRN = project reference number (budget code); EAPI/CIAM/SRE = DC component teams (Enterprise API, Customer Identity & Access Mgmt, Site Reliability Eng.).
