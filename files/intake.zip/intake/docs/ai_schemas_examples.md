# AI output examples (one minimal valid `output` per feature)

Contract: `app/ai/schemas.py` (frozen). Each block below validates with `schemas.validate(feature, output)`; the last block is a complete fixture file and validates with `schemas.validate_fixture_file`. Content authors copy a block into a fixture's `variants: [...]` and enlarge it. Rules that are not visible in the JSON Schema:

- Every output has `confidence` (0–1; pill: High ≥0.80, Medium 0.60–0.79, Low <0.60), `sources` (`{type, id, label, excerpt?}`) and `warnings` (strings, may be empty).
- Component codes: `APIP APIGW EDP CIAM MOB_IOS MOB_AND OLB PAYHUB NOTIF STMT SRE FRAUD`. Complexity `Low|Medium|High`. Approval `Pending|Approved|Not required|Rejected`. Risk severity/likelihood 1–4. Skill level 1–3.
- WBS: codes `WBS-100`, children `WBS-210`; `parent_code` and every `depends_on` code must exist in the same plan; no dates (the scheduler computes them from `depends_on`, `duration_days`, optional `offset_days`). `allocation_pct` integer 0–100; milestones have `duration_days: 0`.
- Numbers owned by engines (L2 hours, compliance Pass/Fail, utilisation %, SA completeness = floor(found/9×100)) must equal the engine result; fixtures for the hero use the values pinned in master plan §6.
- Fixture file: `app/ai/fixtures/<feature>/<key>.json`, `key` = file name stem, `variants` = list of outputs (no single `output` key). Assistant fixtures may use `{placeholders}` in text; every placeholder needs a `bindings` entry naming a query in `assistant.py`.
- Resource ids: 1 Tobias Wren · 2 Lena Oduya · 4 Mira Castellane · 6 Kai Moreau · 12 Hana Brightwater · 14 Sana Whitfield · 15 Mateo Brennan · 16 Grace Ellingham (see `docs/BUILDER_BRIEF.md`).

### intake_analysis
```json
{
  "summary": "US API Enhancement is mostly ready for grooming. Scope and components are clear; partner onboarding SLA and data residency are still open.",
  "completeness_score": 82,
  "readiness": "Ready for grooming",
  "field_checks": [
    {"field": "prn_code", "label": "PRN", "status": "present", "note": "PRN-77310"},
    {"field": "description", "label": "Description of Change", "status": "weak", "note": "No volumes or response-time targets stated"}
  ],
  "ambiguities": [
    {"text": "similar to the Canadian aggregator APIs", "why": "Does not say which endpoints or versions are in scope", "source_field": "description"}
  ],
  "missing_info": [{"item": "Expected daily call volume", "impact": "Medium"}],
  "clarifying_questions": [
    {"question": "Which partner aggregators must be onboarded for DC-2702, and what onboarding SLA applies?", "addressed_to": "Requestor", "priority": 1}
  ],
  "suggested_labels": ["US P&C", "Open banking", "API"],
  "likely_components": [
    {"component_code": "APIP", "complexity": "High", "reason": "New accounts and transactions APIs for US channels"},
    {"component_code": "CIAM", "complexity": "Medium", "reason": "New OAuth scopes for partner consent"}
  ],
  "suggested_priority": 2,
  "possible_duplicates": [],
  "confidence": 0.78,
  "sources": [{"type": "initiative", "id": "RDDC-24817", "label": "RDDC-24817 Description of Change"}],
  "warnings": []
}
```

### change_summary
```json
{
  "components": [
    {"component_code": "APIP", "approval": "Approved", "complexity": "High",
     "change_summary": "New /v2/accounts and /v2/transactions APIs for US digital channels and partner aggregators, with pagination, ETag caching and 50 TPS per-client rate limits.",
     "est_hours": 280, "evidence": [{"section": "4.1 API Platform", "excerpt": "Expose /v2/accounts and /v2/transactions to US digital channels"}]},
    {"component_code": "CIAM", "approval": "Pending", "complexity": "Medium",
     "change_summary": "Add OAuth2 scopes accounts.read and transactions.read with 90-day consent tokens; mTLS for partner clients.",
     "est_hours": 120, "evidence": [{"section": "4.2 CIAM / Security", "excerpt": "New scopes accounts.read, transactions.read"}]}
  ],
  "sa_completeness": 88,
  "sa_sections": [{"section": "Backout plan", "found": false}],
  "gaps": ["No backout plan section"],
  "open_items": ["TBD: partner onboarding SLA"],
  "confidence": 0.86,
  "sources": [{"type": "sa_doc", "id": "SA_US_API_Enhancement_v1.2.docx", "label": "SA document v1.2 §4", "excerpt": "Approvals: API Platform Approved; CIAM / Security Pending"}],
  "warnings": []
}
```

### l2_estimate
```json
{
  "total_hours": 1000, "low_hours": 750, "high_hours": 1250, "tshirt": "L", "dev_hours": 560, "contingency_pct": 15,
  "by_component": [
    {"component_code": "APIP", "complexity": "High", "dev_hours": 280, "rationale": "Two new versioned APIs with rate limiting; High catalogue rate."},
    {"component_code": "EDP", "complexity": "Medium", "dev_hours": 120, "rationale": "New CDC feed to an existing Kafka cluster."},
    {"component_code": "CIAM", "complexity": "Medium", "dev_hours": 120, "rationale": "Two new scopes and partner mTLS."},
    {"component_code": "SRE", "complexity": "Low", "dev_hours": 40, "rationale": "Dashboards and SLO alerts on existing tooling."}
  ],
  "by_phase": [
    {"phase": "Development", "hours": 560}, {"phase": "Architecture", "hours": 56},
    {"phase": "QA", "hours": 196}, {"phase": "PM / Release", "hours": 56}, {"phase": "Contingency", "hours": 132}
  ],
  "assumptions": ["Partner onboarding is out of scope for this estimate"],
  "narrative": "560 h of development across four components, plus architecture, QA and release effort and 15% contingency, rounds to 1,000 h (L).",
  "confidence": 0.8,
  "sources": [{"type": "engine", "id": "l2", "label": "L2 calculation"}],
  "warnings": []
}
```

### wbs
```json
{
  "summary": "Nine-phase plan from solution finalization to hypercare, targeting release train DC-2702.",
  "tasks": [
    {"wbs_code": "WBS-100", "parent_code": null, "step": "Estimation & solution finalization", "phase": "Estimation",
     "description": "Close SA open items and confirm L2 with DLR.", "component_code": null, "owner_role": "DC SA",
     "suggested_resource_id": 14, "suggested_resource_name": "Sana Whitfield", "est_hours": 70, "allocation_pct": 50,
     "duration_days": 20, "depends_on": [], "is_milestone": false},
    {"wbs_code": "WBS-200", "parent_code": null, "step": "Development", "phase": "Development",
     "description": "Component build work.", "component_code": null, "owner_role": "Tech Lead",
     "suggested_resource_id": null, "est_hours": 0, "allocation_pct": 0, "duration_days": 40,
     "depends_on": ["WBS-100"], "is_milestone": false},
    {"wbs_code": "WBS-210", "parent_code": "WBS-200", "step": "Build /v2/accounts and /v2/transactions APIs", "phase": "Development",
     "description": "Implement endpoints, pagination, ETag and rate limits.", "component_code": "APIP", "owner_role": "EAPI Developer",
     "suggested_resource_id": 1, "suggested_resource_name": "Tobias Wren", "est_hours": 280, "allocation_pct": 88,
     "duration_days": 40, "depends_on": ["WBS-100"], "is_milestone": false},
    {"wbs_code": "WBS-700", "parent_code": null, "step": "Production implementation (DC-2702)", "phase": "Production",
     "description": "Deploy under approved CRQ on the release train date.", "component_code": null, "owner_role": "Rel Lead",
     "suggested_resource_id": null, "est_hours": 0, "allocation_pct": 0, "duration_days": 0,
     "depends_on": ["WBS-210"], "is_milestone": true}
  ],
  "total_est_hours": 350,
  "dependency_impacts": [
    {"component_code": "MOB_IOS", "direction": "downstream", "impact": "iOS app consumes the accounts API", "action": "Regression test account summary on iOS", "wbs_code": "WBS-210"}
  ],
  "assumptions": ["Plan starts the business day after grooming"],
  "confidence": 0.84,
  "sources": [{"type": "component", "id": "APIP", "label": "Change Summary · API Platform"}],
  "warnings": []
}
```

### resources
```json
{
  "recommendations": [
    {"wbs_code": "WBS-230", "role_needed": "IAM Engineer", "required_skills": ["OAuth2/OIDC", "Scopes"], "hours_needed": 120,
     "window": {"start": "2026-11-18", "end": "2027-01-15"},
     "candidates": [
       {"rank": 1, "resource_id": 4, "resource_name": "Mira Castellane", "team": "CIAM", "fit_score": 91, "skill_match_pct": 100,
        "free_hours": 210, "peak_util_after_pct": 92, "matched_skills": ["OAuth2/OIDC", "Scopes"], "missing_skills": [],
        "prior_work": ["RDDC-24601"], "reasons": ["Built step-up scopes on RDDC-24601", "Stays under 100% in every month"], "concerns": []}
     ],
     "recommended_resource_id": 4}
  ],
  "confidence": 0.82,
  "sources": [{"type": "resource", "id": 4, "label": "Mira Castellane · skills and availability"}],
  "warnings": []
}
```

### rebalance
```json
{
  "problem": {"resource_id": 14, "resource_name": "Sana Whitfield", "month": "2026-11", "util_pct": 128,
              "wbs_codes": ["WBS-100"], "summary": "Sana Whitfield is at 128% in Nov 2026 (154.0 h of 120 h)."},
  "options": [
    {"action": "Move WBS-100 from Sana Whitfield to Mateo Brennan", "task_wbs_code": "WBS-100",
     "from_resource_id": 14, "from_resource_name": "Sana Whitfield", "to_resource_id": 15, "to_resource_name": "Mateo Brennan",
     "month": "2026-11", "before": {"from_pct": 128, "to_pct": 42}, "after": {"from_pct": 96, "to_pct": 74},
     "effect": "Resources turns Green; overall health stays Amber because of schedule float.",
     "health_after": {"resources": "Green", "overall": "Amber"}}
  ],
  "recommended_option_index": 0,
  "confidence": 0.88,
  "sources": [{"type": "allocation", "id": "14:2026-11", "label": "Sana Whitfield · Nov 2026 allocation"}],
  "warnings": []
}
```

### risks
```json
{
  "risks": [
    {"title": "EDP event schema not frozen before WBS-220 start", "description": "The CDC event schema is still marked TBD in the SA document.",
     "category": "Dependency", "severity": 3, "likelihood": 2, "trigger_signal": "SA §10 open item: event schema TBD",
     "wbs_code": "WBS-220", "owner_role": "DC SA", "owner_resource_id": 14,
     "mitigation_steps": [{"step": "Agree the txn-history event schema with EDP", "owner_role": "DC SA", "due": "2026-11-13"}]}
  ],
  "management_attention": "SA capacity constraint affecting WBS-100",
  "overall_level": "Medium",
  "confidence": 0.74,
  "sources": [{"type": "sa_doc", "id": "SA_US_API_Enhancement_v1.2.docx", "label": "SA document §10 open items"}],
  "warnings": []
}
```

### exec_summary
```json
{
  "scope": "initiative", "rddc": "RDDC-24817", "period": {"from": "2026-10-13", "to": "2026-10-19"},
  "headline": "US API Enhancement is Amber: plan baselined for DC-2702 with 2 days of readiness float.",
  "rag": "Amber",
  "summary_md": "Plan of 1,000 h approved at L2. Readiness on 17 Feb 2027 leaves 2 business days before DC-2702.",
  "highlights": ["Change Summary accepted with 4 DC components"],
  "concerns": ["CIAM / Security approval still pending"],
  "asks": ["Confirm CIAM approval by 18 Nov 2026"],
  "confidence": 0.8,
  "sources": [{"type": "initiative", "id": "RDDC-24817", "label": "RDDC-24817 health"}],
  "warnings": []
}
```

### cr_compliance
```json
{
  "crq_number": "CRQ000418822", "compliant": false, "score": 67, "sto_readiness": "Not ready",
  "findings": [
    {"rule_id": "CR-01", "rule": "STO approval is Go at least 24 h before the CRQ start", "status": "Fail", "field": "sto_approval",
     "detail": "STO approval is Tentative No Go.", "fix": "Resolve the business validation failure and request STO re-review.", "blocking": true},
    {"rule_id": "CR-07", "rule": "CMS lead and Rel lead are named", "status": "Pass", "field": null,
     "detail": "Petra Vallance and Owen Stroud are named.", "fix": null, "blocking": false}
  ],
  "reviewer_note": "Not ready for Go. Business validation failed and STO is Tentative No Go.",
  "confidence": 0.9,
  "sources": [{"type": "change_request", "id": "CRQ000418822", "label": "CRQ000418822"}, {"type": "rule", "id": "CR-01", "label": "STO approval rule"}],
  "warnings": []
}
```

### skill_matrix
```json
{
  "skills": ["OAuth2/OIDC", "Kafka"],
  "rows": [
    {"resource_id": 4, "resource_name": "Mira Castellane", "team": "CIAM",
     "skills": [{"skill": "OAuth2/OIDC", "level": 3, "evidence": ["RDDC-24601 WBS-230 (96 h)"], "source": "both"}],
     "top_skills": ["OAuth2/OIDC"]}
  ],
  "team_gaps": [{"skill": "Kafka", "holders": 1, "holder_names": ["Lena Oduya"], "note": "Key-person risk for EDP work"}],
  "confidence": 0.76,
  "sources": [{"type": "wbs_task", "id": "RDDC-24601/WBS-230", "label": "RDDC-24601 WBS-230"}],
  "warnings": []
}
```

### nudges
```json
{
  "messages": [
    {"recipient_name": "Sana Whitfield", "recipient_resource_id": 14, "recipient_role": "DC SA", "rule": "sa_action_required",
     "subject": "Action required by 21 Oct 2026: SA inputs for RDDC-24817",
     "body": "Hi Sana, two items are waiting on you for US API Enhancement: the partner onboarding SLA and the data residency confirmation. Please update the SA document by 21 Oct 2026.",
     "action_required_by": "2026-10-21", "urgency": "Normal", "escalation_level": 0, "dedupe_key": "sa_action_required:RDDC-24817:2026-10-21",
     "items": [{"type": "sa_input", "rddc": "RDDC-24817", "label": "TBD: partner onboarding SLA", "age_days": 0}]}
  ],
  "confidence": 0.9,
  "sources": [{"type": "sa_doc", "id": "SA_US_API_Enhancement_v1.2.docx", "label": "SA open items"}],
  "warnings": []
}
```

### meeting_extract
```json
{
  "summary": "Grooming for RDDC-24817 confirmed scope and target train DC-2702.",
  "meeting_date": "2026-10-20",
  "decisions": [{"decision": "Target release train DC-2702", "made_by": "Grace Ellingham", "rationale": "DC-2701 is too close to the change freeze", "rddc": "RDDC-24817"}],
  "actions": [{"action": "Confirm CIAM scope approval", "owner_name": "Mira Castellane", "owner_resource_id": 4, "due": "2026-10-23", "rddc": "RDDC-24817", "source_line": 7}],
  "risks_raised": [],
  "open_questions": ["Is data residency confirmation needed before build?"],
  "confidence": 0.83,
  "sources": [{"type": "meeting_note", "id": 1, "label": "Grooming notes 20 Oct 2026"}],
  "warnings": []
}
```

### lessons
```json
{
  "mode": "draft", "initiative_rddc": "RDDC-24310",
  "lessons": [
    {"category": "Estimation", "kind": "improve", "what_happened": "QA ran 22% over plan because partner test data arrived late.",
     "lesson": "Partner test data is on the critical path.", "recommendation": "Add a test-data readiness step before SIT.", "evidence": "WBS-400 planned 180 h, actual 219.5 h"}
  ],
  "relevant_lessons": [],
  "estimate_accuracy": {"planned_hours": 820, "actual_hours": 901.5, "variance_pct": 9.9, "worst_phases": ["QA"]},
  "confidence": 0.77,
  "sources": [{"type": "initiative", "id": "RDDC-24310", "label": "RDDC-24310 planned vs actual"}],
  "warnings": []
}
```

### intake_autofill
```json
{
  "fields": {
    "name": {"value": "US API Enhancement", "confidence": 0.95, "source": "SA document title"},
    "lob": {"value": "US P&C", "confidence": 0.9, "source": "SA §1 Document control"},
    "priority": {"value": 2, "confidence": 0.6, "source": "SA §2 Business context"}
  },
  "likely_components": ["APIP", "EDP", "CIAM", "SRE"],
  "confidence": 0.85,
  "sources": [{"type": "sa_doc", "id": "SA_US_API_Enhancement_v1.2.docx", "label": "SA document §1"}],
  "warnings": []
}
```

### assistant
```json
{
  "answer_md": "**Sana Whitfield** is at **128%** in Nov 2026 because WBS-100 on RDDC-24817 overlaps her RDDC-24688 and RDDC-24702 work.",
  "intent": "explain_health",
  "citations": [{"type": "resource", "id": 14, "label": "Sana Whitfield", "route": "#/resources"},
                {"type": "wbs_task", "id": "RDDC-24817/WBS-100", "label": "WBS-100", "route": "#/initiative/9/pg2"}],
  "table": null,
  "suggested_actions": [{"label": "Suggest fix", "api": "/api/initiatives/9/ai/rebalance", "method": "POST"}],
  "follow_ups": ["Who has spare capacity in November?"],
  "confidence": 0.9,
  "sources": [{"type": "allocation", "id": "14:2026-11", "label": "Sana Whitfield · Nov 2026"}],
  "warnings": []
}
```

### Fixture file example (`app/ai/fixtures/assistant/red_projects.json`)
```json
{
  "fixture_version": 1,
  "feature": "assistant",
  "key": "red_projects",
  "match": {"intent": "list_by_rag", "question": "Which projects are red?", "patterns": ["\\bred\\b", "at risk"]},
  "authored_by": "b6-test-agent",
  "model_emulated": "claude-opus-5-5",
  "simulated_latency_ms": 1300,
  "bindings": {"red_count": "count_red_initiatives", "red_list": "list_red_initiatives"},
  "variants": [
    {"answer_md": "{red_count} initiative is Red: {red_list}.", "intent": "list_by_rag",
     "citations": [{"type": "initiative", "id": "RDDC-24412", "label": "RDDC-24412 e-Transfer Request Money Redesign", "route": "#/initiative/2/pg5"}],
     "table": null, "suggested_actions": [{"label": "Open Portfolio View", "route": "#/portfolio"}],
     "follow_ups": ["What is blocking RDDC-24412?"], "confidence": 0.92,
     "sources": [{"type": "initiative", "id": "RDDC-24412", "label": "RDDC-24412 health"}], "warnings": []}
  ]
}
```
