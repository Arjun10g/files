# QA summary · lines of defense

| Line | Who | Result |
|---|---|---|
| L1 builder self-checks | B1–B6 | ruff clean (app + tests), compileall OK, all 44 JS modules pass `node --input-type=module --check`, 74/74 AI fixtures schema-valid |
| L2 API contract | QA-A (independent) | Every `/api` route has a happy-path and a bad-input test (meta-tested). 11 defects found across 3 rounds, all fixed. `docs/qa/round1_QA-A_api.md` |
| L3 engine rules | QA-B (independent, hand-computed expectations) | 159 independent tests; 9 defects found, all fixed; all goldens re-derived by hand. `docs/qa/round1_QA-B_engines.md` |
| L4 browser end-to-end | B5 suite + QA-C audit | Full demo script in 3 timezones (Toronto / Auckland / Los Angeles) at 1366 and 1920, click-all sweep, no console errors, no 5xx, no "undefined/NaN/null". 29 UX defects found in round 1, all fixed. `docs/qa/round1_QA-C_e2e.md` |
| L5 red team | adversarial code reviewer | 17 findings (6 Major), all fixed; security clean (no unsafe HTML, parameterised SQL, safe uploads, Excel injection escaped, no key leakage). `docs/qa/round1_L5_redteam.md` |
| L6 fresh-eyes rehearsal | "BMO Director" (never saw code) | Round 2: 3–4/5, 5 Must-fix → all fixed. Round 3: **every score ≥4 (clarity 5), 0 Must-fix**; Should-fixes addressed in a polish round. `docs/qa/round2_L6_director.md`, `docs/qa/round3_L6_director.md` |
| L7 final regression | orchestrator | 3 consecutive runs from a clean reset: **1,189 non-browser + 20 browser tests, all green each run** |

Binding product decisions taken during QA: `docs/00_MASTER_PLAN.md` §6, `docs/qa/round2_decisions.md`.
Deck parity (asserted by tests): RDDC-24817 → L2 1,000 h L (750–1,250) · QA Wed 10 Feb, Readiness Wed 17 Feb, Production Sat 20 Feb 2027 (DC-2702), float 2 business days · Health Overall Amber, Schedule Amber, Resources Red (Sana Whitfield 128% Nov), Scope/Dependencies/Budget Green · Suggest fix → Sana 96%, Mateo 74%, Resources Green, Overall Amber · WBS-210 +5 business days → Schedule Red, Undo restores.
