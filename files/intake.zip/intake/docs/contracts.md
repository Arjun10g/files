# Contracts (FROZEN, owner B0)

This file pins what `00_MASTER_PLAN.md` leaves open. Precedence: master plan §6, then this file, then `planning/2_solution_architect.md`.
The frozen code is `app/schema.sql`, `app/db.py`, `app/config.py`, `app/errors.py`, `app/today.py`, `app/__init__.py`, `static/js/api.js` and `tests/fixtures/bundle_hero.json`. `app/ai/schemas.py` is owned by the AI Lead.
To request a change, write it under "Contract change requests" in your handoff. Do not edit these files.

## 0. Conventions
- **JSON field names = DB column names.** Joined display fields get a `_name` suffix (`dc_pm_name`). Joined codes get a `_code` suffix (`component_code`).
- **JSON-ish TEXT columns are returned parsed**, under the same name: every `*_json` column, plus `labels`, `keywords`, `affected_cis`, `impacted_components`, `cc_names`, `attendees`, `tags`, `components`. Clients send them as arrays or objects, and the server serialises them with `db.to_json`.
- **Dates and times.** Dates are `YYYY-MM-DD`, months `YYYY-MM`. Datetimes are ISO 8601 with an offset (`2026-10-19T09:44:12-04:00`), produced by `today.now_iso()`. App code sets `created_at`/`updated_at` itself; the schema `CURRENT_TIMESTAMP` defaults are only a fallback.
- **Clock.** Python code calls `today.get_today()` and `today.get_now()` (demo date at 09:30 America/Toronto) and never calls `date.today()`. Engines receive `today` as a parameter.
- **Lists** return `{"items":[...], "total":n}`. **Writes** return the updated row (or the documented object) and call `activity.log_activity(...)`.
- **Errors** are always `{"error":{"code","message","details"}}`, never HTML. Codes: `bad_request` 400 · `not_found` 404 · `method_not_allowed` 405 · `conflict` 409 · `payload_too_large` 413 · `validation` 422 (`details.fields = {field: msg}`) · `unreadable_file` 422 (`details.fallback = "paste_text"`) · `ai_error` 502 · `internal` 500. Raise them with `app.errors.ApiError` or the helpers `not_found`, `validation`, `conflict` and `unreadable_file`.
- **Transactions.** Group writes with `with db.transaction():` (nestable). A CRUD write and the `derive` calls it triggers go in the **same** transaction.
- **Enums.** The UI reads every enum from `GET /api/lookups` and never hard-codes one. The DB enforces them with CHECK constraints (see `schema.sql`).
- **No-cache.** `/` and `/api/*` are served `Cache-Control: no-store`. Static assets are loaded with `?v=<APP_VERSION>`.

## 1. Blueprints and Python service contracts
`create_app()` imports `app.api.<name>` in this fixed order: `core, initiatives, plan, resources, governance, artifacts, views, export, ai`. Each module exposes `bp = Blueprint("<name>", __name__, url_prefix="/api")`. A missing module is skipped with a log line. A module that fails to import still breaks startup, so bugs stay visible. `create_app` also serves a fallback `GET /api/health` when `core` is absent.

Cross-builder Python calls (the signatures are frozen):

| Function | Owner | Notes |
|---|---|---|
| `app.repo.get_initiative_bundle(initiative_id) -> dict` | B1 | §3 shape. Raises `errors.not_found`. |
| `app.repo.list_initiatives(filters: dict) -> list[dict]` | B1 | |
| `app.activity.log_activity(entity_type, entity_id, action, detail=None, initiative_id=None)` | B1 | Reads actor and persona from `app_settings.persona`. Action `scope_change` = an insert, delete or complexity edit of `initiative_components` after `l2_approved_at`. |
| `app.textract.extract_text(path, mime) -> str` | B1 | Raises `errors.unreadable_file`. |
| `app.engines.sa_completeness.score(text) -> {completeness, sections_found, missing:[str], author, version}` | B2 | `completeness = floor(found/9*100)`. B1 calls it on SA upload or paste. |
| `app.engines.l2.estimate_l2(components, catalog) -> L2Estimate` | B2 | |
| `app.engines.health.compute_health(bundle, today) -> Health` | B2 | |
| `app.engines.schedule.build_gantt(tasks, today) / critical_path(tasks) / propagate_slip(tasks, changed_id) -> {task_id: (start, end)}` | B2 | |
| `app.engines.capacity.spread_hours(start, end, hours) -> {month: hours}` | B2 | Each month is rounded to 0.1 h; the last month absorbs the remainder so the months sum to `hours` exactly. A Saturday milestone books its hours to its own month. |
| `app.engines.compliance.check_cr(cr, today, context) -> {ok, flags:[{code, message}]}` | B2 | |
| `app.services.derive.rebuild_allocations(initiative_id) -> int` | B2 | Replaces `source='derived'` rows. Firmness is `confirmed` when `l2_status='Approved'`, otherwise `tentative`. |
| `app.services.derive.refresh_health(initiative_id) -> Health` | B2 | Writes `rag_cached` and `health_cached_json`. |
| `app.services.derive.slot_grooming(initiative_id) -> {session_id, session_date, start_time, label} \| None` | B2 | B1 calls it on create. It also queues the invite in the Outbox. |
| `app.services.derive.run_reminders(now=None) -> {created:[...], skipped:n}` | B2 | |
| `app.ai.provider.run_feature(feature, initiative_id, payload, *, instruction=None, regen_of=None, force_mode=None) -> AiRun` | B3 | `feature` is snake_case. `force_mode="simulated"` is used by fast-forward-hero. |
| `app.ai.apply.apply_run(run_id, selected=None, edited_output=None) -> dict` | B3 | Calls `derive.rebuild_allocations` and `derive.refresh_health` in the same transaction. |

Only `services/derive.py` writes allocations (`source='derived'`), `rag_cached`, `health_cached_json` and reminder notifications.

## 2. Endpoints
Notation: `->` is the response. Request bodies take the DB column names unless stated otherwise. `{id}` is `initiatives.id`.

**core (B1)**
- `GET /api/health` -> `{status, db, ai_mode:"simulated"|"live", model, today, version, modules}`
- `GET /api/lookups` -> §5
- `GET /api/settings` -> `{ai_mode:"auto"|"simulated"|"live", ai_speed:"Realistic"|"Fast", demo_today, persona, live_available, model_heavy, model_fast}`. `PUT /api/settings` takes a partial body and returns the same shape. These settings live in `app_settings`.
- `POST /api/admin/reset` -> `{ok, counts:{table:n}}`. Re-seeds data, sets `rddc_next=24817`, clears uploads and ai_runs.
- `POST /api/admin/fast-forward-hero` -> `{initiative_id, rddc, steps:[{step, ok, ai_run_id?, message?}]}`. Runs these steps server-side in simulated mode: create RDDC-24817 from DCI-3391 → attach the sample SA → change summary + apply → L2 submit + approve → WBS + apply → resources + apply. If the hero already exists, it continues from the first missing step.
- `GET /api/activity?initiative_id&limit` -> list of `{id, ts, actor, persona, entity_type, entity_id, initiative_id, action, detail_json, summary}`
- `GET /api/release-trains` -> `{items:[{code, train_date, status, in_freeze, initiatives:[{id, rddc, name, rag}]}], freeze:{start:"2026-12-14", end:"2027-01-08"}, holidays:[...]}`
- `GET /api/dc-intakes?q` -> list. `GET /api/dc-intakes/{code}` -> `{code, name, lob, requestor, priority, requested_go_live, description, initiative_id|null}` (404 if unknown)

**initiatives (B1)**
- `GET /api/initiatives?q&stage&lob&status&rag&dc_pm_id&release` -> list of `{id, rddc, name, lob, stage, status, priority, dc_pm_name, dc_sa_name, rag, target_release, readiness_date, planned_end}`
- `POST /api/initiatives` with `{name, lob, priority, requestor, requestor_id?, dc_intake?, description?, requested_go_live?, dc_pm_id?, dc_sa_id?, tech_lead_id?, labels?}`. RDDC is assigned from `rddc_next`. -> `{initiative, grooming, queued_notifications:[{id, to_name, subject}]}`
- `GET /api/initiatives/{id}` -> **Bundle** (§3). `PUT` takes a partial body -> initiative. `DELETE` -> `{ok}`
- `GET|POST /api/initiatives/{id}/components`. `PUT|DELETE /api/initiative-components/{icid}`. Body `{component_id, approval, change_summary, complexity, est_hours, component_lead_id}`. When `est_hours` is omitted it is set to the catalogue `base_hours_<complexity>`.
- `GET /api/initiatives/{id}/attachments` -> list
- `POST /api/initiatives/{id}/attachments` (multipart: `file`, `kind`, `entity_type?`, `entity_id?`) -> `{attachment, extracted_chars, sa:{author, version, completeness, missing}|null}`. `kind=sa_doc` also updates `sa_*` and `sa_doc_attachment_id`. Uploads accept `.docx .pdf .md .txt` up to 10 MB.
- `POST /api/initiatives/{id}/sa-text` with `{text, filename?}` -> same shape (paste fallback)
- `GET /api/attachments/{aid}/download` -> file

**plan (B1)**
- `GET|POST /api/initiatives/{id}/tasks`. `PUT|DELETE /api/tasks/{tid}`. Task body is the `wbs_tasks` columns plus `depends_on:[task_id]`. A write returns `{task, shifted_tasks:[{id, wbs_code, planned_start, planned_end}], health}`.
- `PUT /api/initiatives/{id}/tasks/bulk` with `{tasks:[...]}` -> `{items, health}`
- `POST /api/initiatives/{id}/baseline` with `{reason}` -> `{ok, baseline_set_at}`. Also logs a decision.

**resources (B1)**
- `GET /api/resources?tracked&team`, `POST /api/resources`, `PUT /api/resources/{rid}`. A resource row includes `skills:[{skill, level}]` and `current_load`.
- `GET /api/resources/{rid}/availability?from&to` -> `{resource_id, months:{YYYY-MM: h}}`. `PUT` with `{months:{...}}` returns the same.
- `GET /api/allocations?initiative_id&resource_id&month`, `POST /api/allocations` (source `manual`), `PUT|DELETE /api/allocations/{aid}`
- `GET /api/skills/matrix` -> `{skills:[{id, name, category}], rows:[{resource_id, name, team, levels:{skill: 1-3}, evidence:{skill: text}}]}`. `PUT /api/resources/{rid}/skills` with `{skills:{name: level}}`.

**governance (B1)**
- `GET /api/change-requests?week&initiative_id&from&to` -> list, each row with `compliance:{ok, flags:[{code, message}]}`. `GET /api/change-requests/{cid}`. `POST /api/initiatives/{id}/change-requests`. `POST /api/initiatives/{id}/change-requests/draft` builds a deterministic draft (e.g. `CRQ0001048817`, Sat 02:00–06:00 window on the train date, Bundle, CIs from the components, STO Approval `Tentative Go`/`Tentative No Go` by the flags). `PUT|DELETE /api/change-requests/{cid}`.
- `GET /api/risks?initiative_id&status&min_score`, `POST /api/initiatives/{id}/risks`, `PUT|DELETE /api/risks/{rid}`. The server assigns `risk_code` (`RSK-###`).
- `GET /api/grooming/sessions?from&to` -> sessions, each with `slots:[{initiative_id, rddc, name, priority, slot_order, status, recipients:[{id, name}]}]`. `POST /api/grooming/sessions`. `PUT /api/grooming/slots` with `{session_id, initiative_id, status?, new_session_id?}`.
- `GET /api/outbox?status&initiative_id&rule` -> `{items:[Notification], total, counts:{Queued, Sent}}`. `POST /api/outbox/{nid}/send|ack|dismiss` -> the notification.

**artifacts (B1)**: `GET|POST /api/{decisions|lessons|meeting-notes|documents}?initiative_id` and `PUT|DELETE /api/{type}/{id}`. Rows are the table columns plus `rddc`.

**views (B2)**
- `GET /api/portfolio?lob&dc_pm_id&stage&rag&release` -> `{kpis:{active, red, amber, green, crqs_this_week, overallocated_people}, projects:[{id, rddc, name, lob, dc_pm_name, stage, rag, dimensions:{schedule..budget: rag}, target_release, readiness_date, qa_signoff_date, prod_date, comments}], change_mgmt:[{initiative_id, rddc, crq_number, release_train, cms_lead_name, rel_lead_name, resource_name, implementation_status, tech_validation_status, biz_validation_status, sto_approval, compliance_flags:[str]}], capacity_teams:[{team, available, confirmed, tentative, util}]}`
- `GET /api/portfolio/gantt` -> `{start, end, today, freeze, trains:[{code, train_date}], rows:[{initiative_id, rddc, name, rag, stage, start, end, readiness_date, prod_date}]}`
- `GET /api/intake-queue` -> `{items:[{initiative_id, rddc, name, lob, priority, stage, submitted_at, session|null, action_required_by|null, waiting_on|null}], sessions:[...]}`
- `GET /api/initiatives/{id}/health` -> **Health**. `PUT /api/initiatives/{id}/health/override` with `{dimension, rag|null, reason}`; `reason` is required when `rag` is set. -> Health
- `GET /api/initiatives/{id}/gantt` -> **Gantt**
- `GET /api/capacity?from&to&group=resource|team|quarter&initiative_id&team` -> **Capacity**
- `GET /api/initiatives/{id}/resource-grid` -> `{fy, quarters:[{fy, q, label, months}], rows:[{resource_id, name, team, role, cells:[{quarter, availability, allocation, confirmed, tentative, util, band}]}], assignments:[{resource_id, resource_name, wbs_code, hours, allocation_pct, from, to, firmness}]}`
- `GET /api/prns` -> list of `{prn_code, name, lob, funded_hours, charged_hours, forecast_hours, status}`. `GET /api/prn/{code}/burndown` and `GET /api/initiatives/{id}/burndown` -> **Burndown**
- `POST /api/initiatives/{id}/l2/calculate` -> **L2Estimate** (nothing is saved). `POST .../l2/submit` (status becomes `Pending approval`, queues the reminder) -> `{initiative, notifications}`. `POST .../l2/approve` with `{comment?}` -> `{initiative, health}`: status `Approved`, the baseline hours lock, stage moves to Planning, demand becomes confirmed, and a decision is logged. `POST .../l2/reject` with `{reason}` -> `{initiative}`.
- `POST /api/grooming/auto-slot` with `{dry_run}` -> `{assignments:[{session_id, session_date, start_time, initiative_id, rddc, recipients}], unslotted:[{initiative_id, rddc, reason}]}`
- `POST /api/reminders/run` with `{now?}` -> `{created:[Notification], skipped}`
- `GET /api/governance/weekly?week=YYYY-Www` -> `{week, from, to, items:[CR + compliance], noncompliant_count}`. The window is the CRQs starting in the next 14 days from that Monday.
- `GET /api/governance/approvals` -> list of `{kind:"l2"|"component"|"sto", initiative_id, rddc, name, entity_id, title, requested_at, waiting_days, approver}`. Approve or reject through the owning endpoint (L2 approve/reject, `PUT initiative-components`, `PUT change-requests`).

**export (B2)**: `GET /api/export/demo-view.xlsx?initiative_id`, `GET /api/export/portfolio.xlsx`, `GET /api/export/portfolio.csv?<portfolio filters>`. Any cell starting with `= + - @` is escaped.

**ai (B3).** These endpoints return an **AiRun** and write nothing else.
- `POST /api/initiatives/{id}/ai/{intake-analysis|change-summary|l2-estimate|wbs|resources|rebalance|risks|exec-summary|cr-compliance}`
- `POST /api/ai/{intake-analysis|intake-autofill|skill-matrix|exec-summary|nudges|meeting-extract|lessons}`
- The body is `{instruction?, regen_of?, options?}`. `options` carries the feature inputs: `wbs_code`, `resource_id`, `change_request_id`, `meeting_note_id`, `text`, `attachment_id`, `name`/`description`/`lob` (draft intake analysis), `initiative_id` (lessons). A Regenerate sets `regen_of`, which marks the old run `superseded` and serves the next fixture variant.
- `POST /api/ai-runs/{run_id}/apply` with `{selected?:[index], edited_output?}` -> `{ai_run_id, status:"accepted", initiative_id, applied:{table: n}, minutes_saved, health?}`. Applying a run that is not `generated` returns 409.
- `POST /api/ai-runs/{run_id}/reject` with `{reason?}` -> `{ai_run_id, status:"rejected"}`
- `GET /api/ai-runs?feature&initiative_id&status&limit` -> list. `GET /api/ai-runs/{id}` -> the full run.
- `GET /api/ai-runs/stats` -> `{runs, accepted, rejected, acceptance_rate, minutes_saved, by_feature:[{feature, runs, accepted, minutes_saved}]}`
- `POST /api/assistant/chat` with `{message, conversation_id?, initiative_id?, page?}` -> `{conversation_id, answer_md, citations:[{type, id, label, route}], suggested_actions:[{label, route?}], follow_ups:[str], ai_run_id, mode, mode_label}`. `GET /api/assistant/conversations/{cid}` -> `{conversation_id, messages:[...]}`

**AiRun envelope:**
`{ai_run_id, feature (snake_case), initiative_id|null, scope:"initiative"|"portfolio"|"draft", mode:"simulated_fixture"|"simulated_generated"|"live"|"live_fallback", mode_label:"Simulated · test-agent response"|"Simulated · rules engine"|"Live · Claude"|"Live → Simulated", model|null, variant_index, confidence 0–1, sources:[{type, id, label, field?, excerpt?, route?}], warnings:[str], output:{per app/ai/schemas.py}, status:"generated", latency_ms, minutes_saved, regen_of|null, created_at}`.
The server always answers within 22 s (live timeout 20 s, `max_retries=0`). The client times out AI calls at 25 s and everything else at 15 s.

## 3. Bundle (`GET /api/initiatives/{id}`, `repo.get_initiative_bundle`), sample in `tests/fixtures/bundle_hero.json`
```
{initiative: {all initiatives columns, JSON columns parsed, + requestor_name, assigned_to_name, pm_name, tech_lead_name, dc_pm_name, dc_sa_name},
 components: [{initiative_components columns + code, name, component_lead_name}],
 tasks: [{wbs_tasks columns + owner_name, resource_name, component_code, depends_on:[task_id], depends_on_codes:[wbs_code]}],   ordered by sort
 allocations: [{resource_id, task_id, month, hours, firmness}],          this initiative only
 resources: [{id, name, role, team, team_label, component_id, capacity_eligible, default_monthly_hours,
              availability:{YYYY-MM: h}, committed:{YYYY-MM: h across ALL initiatives}, skills:[{skill, level}]}],
              all capacity-tracked people + any non-tracked person referenced by this initiative; months = project window ±1
 risks: [...risks columns + owner_name, wbs_code], change_requests: [...columns + compliance],
 prn: {prn_budget columns, charges:[{month, charged_hours, charged_amount}]} | null,
 attachments: [...], grooming: {session_id, session_date, start_time, status} | null,
 scope_changes: [{ts, action, component_code, detail}], target_train: {code, train_date} | null,
 component_catalog: [{dc_components columns, keywords parsed, downstream:[code]}],
 sa_doc_text: str | null, today: "YYYY-MM-DD", now: ISO datetime}
```
The ids in the sample are illustrative, except the pinned seed ids (BUILDER_BRIEF). The sample's arithmetic matches §6.2 and was checked by script: Sana Nov 154.0/120 = 128%, Mateo after the move 89.0/120 = 74%, dev = 560 h, Σ est_hours = 859 h, readiness float 2 bd.

**Plan semantics (pinned):**
- `planned_start/planned_end` is the **current schedule**: what the grid edits and the Gantt draws. `baseline_*` is the locked snapshot, set when the plan is accepted with L2 Approved or on Re-baseline.
- A row with children and `est_hours = 0` is a **summary** (WBS-200). Its dates are the min/max of its children, and capacity and health ignore it. WBS-300 has its own hours and is a normal task; its children 310 and 320 run inside the SIT window.
- `allocation_pct` sets the duration: `duration_bd = ceil(est_hours / (7 × allocation_pct/100))`. WBS-700 is a Saturday milestone and is exempt from business-day maths.
- Downstream regression steps (WBS-3x0) are generated for the catalogue downstream components of **High-complexity** components that are not in the initiative, grouped by channel: Mobile (MOB_IOS + MOB_AND) and Online Banking Web. For the hero this gives exactly Mobile and Web; EDP's downstream (Statements) is skipped because EDP is Medium.

**Resources-dimension evaluation (pinned):** a person is checked only in the months where they hold allocation on this initiative. Hana (Dec 104% before the hero) is therefore fine on WBS-400, which runs in Feb.

**Seed requirement (B1):** Tobias Wren's December availability must be **147.0 h** (21 business days × 7 h). WBS-210 runs at 100% for 40 bd, which books 147 h in Dec. At 140 h he would be at 105%, turning Resources Amber and breaking the "Resources Green after the fix" golden. The pre-hero committed hours per person and month are in `bundle_hero.json` (`committed` minus this initiative's allocations).

**Health:** `{scored, overall:"Red"|"Amber"|"Green"|null, dimensions:{schedule|resources|scope|dependencies|budget: {rag, reasons:[str], metrics:{...}, overridden, override_reason?}}, attention:[str], as_of}`. Before stage Planning: `scored:false, overall:null`, and the UI shows "Not scored yet".
**Gantt:** `{start, end, today, freeze:{start, end}, trains:[{code, train_date}], readiness_date, qa_date, prod_date, float_bd, critical_path:[task_id], tasks:[{id, wbs_code, parent_id, step, phase, resource_name, planned_start, planned_end, baseline_start, baseline_end, pct, status, is_milestone, is_summary, critical, float_bd, depends_on:[id]}]}`
**Capacity:** `{months:[YYYY-MM], rows:[{key, label, team, cells:[{month, available, confirmed, tentative, util, band:"spare"|"ok"|"stretched"|"over"}]}], teams:[{team, available, confirmed, tentative, util, band}]}`. `util` is unrounded. Bands: `<0.70` spare, `≤1.00` ok, `≤1.10` stretched, `>1.10` over.
**Burndown:** `{prn_code, funded_hours, months:[...], charged_cum:[...], forecast_cum:[...], funded_line:[...], exhaust_month|null, status:"on_track"|"at_risk"|"overrun"}`
**L2Estimate:** `{dev_hours, architecture_hours, qa_hours, pm_release_hours, subtotal, contingency_hours, total_hours, low_hours, high_hours, tshirt, by_component:[{code, name, complexity, hours}], rule:"..."}`. Hero values: 560 · 56 · 196 · 56 · 868 · 130 · 1000 · 750 · 1250 · L.
**Fiscal quarter object:** `{fy:"FY27", q:"Q1", label:"Nov–Jan", months:[...]}`

## 4. Settings and the demo clock
The `app_settings` keys are `ai_mode` (auto|simulated|live), `ai_speed` (Realistic|Fast), `demo_today` (default 2026-10-19), `persona` (DC PM|Dev Lead|Requestor|STO|Account Manager; default DC PM) and `rddc_next` (24817 after reset). `get_now()` is the demo date at 09:30 ET. `now_iso()` is the demo date plus the real wall-clock time.

## 5. Lookups payload (`GET /api/lookups`)
Each enum category is an array of `{value, label}` in display order; integer enums carry integer values.
Categories: `stage`, `status`, `l2_status`, `approval`, `complexity`, `task_status`, `phase`, `priority` (1–4 → P1–P4), `lob` (Canadian P&C · US P&C · Commercial Banking · Wealth · Cards & Payments · Technology), `release_type`, `sto_approval`, `validation_status`, `implementation_status`, `crq_approval_status`, `rag`, `risk_category`, `risk_severity` (1 Low · 2 Medium · 3 High · 4 Critical), `risk_likelihood` (1 Rare · 2 Unlikely · 3 Possible · 4 Likely), `risk_status`, `l2_tshirt`, `attachment_kind`, `doc_type`, `notification_status`, `grooming_slot_status`, `ai_mode`, `ai_speed`, `persona`, `skill_level` (1–3).
Entity lists: `components:[{id, code, name, team, component_lead_id, component_lead_name}]`, `resources:[{id, name, role, team, team_label, capacity_eligible}]`, `release_trains:[{code, train_date, status}]`, `fiscal_quarters:[FY27 Q1..Q4]`, `freeze:{start, end}`, `holidays:[...]`.

## 6. Frontend contracts
**Routes** (B4 `main.js`): `#/portfolio` (also where `#/` lands), `#/search`, `#/initiative/new`, `#/initiative/:id/:tab` with tab ∈ `pg1|pg2|pg3|pg4|pg5|risks|artifacts` (and `print`), `#/intake`, `#/resources`, `#/risks`, `#/changes`, `#/artifacts`, `#/outbox`, `#/ai-activity`, `#/settings`.

**View module:** `export async function render(root: HTMLElement, params: object, ctx) -> (() => void) | void`. `ctx = {api, state, ui, dates, navigate(hash), refresh()}`. The optional return value is a cleanup function. The assistant drawer is `views/assistant.js` → `export function mount(drawerEl, ctx)`.

**Charts** (B5; each takes the exact API JSON above and returns `{update(json), destroy()}`):
- `charts/gantt.js` `renderGantt(el, gantt, {onTaskClick?, compact?})`
- `charts/heatmap.js` `renderHeatmap(el, capacity, {onCellClick?})`
- `charts/capacity.js` `renderTeamBars(el, capacity.teams | portfolio.capacity_teams)`
- `charts/burndown.js` `renderBurndown(el, burndown)`
- `charts/rag.js` `renderHealth(el, health, {onSuggestFix?, onOverride?})`
- `charts/portfolio_gantt.js` `renderPortfolioGantt(el, portfolioGantt)`

**Rules:** DOM text goes through `textContent`/`esc()`. Dates are handled only via `static/js/dates.js`. Enums come only from `/api/lookups`. Every call goes through `api.js`, and every `ApiError` is shown with `err.message` (user-facing copy) and a recovery action.

## Contract changes
- **2026-10-19 · QA-C-02 (approved by the orchestrator, applied by B1):** `dc_intakes` gains nullable `dc_pm_id`, `dc_sa_id`, `tech_lead_id`, `pm_id` (INTEGER REFERENCES resources(id)). `GET /api/dc-intakes/{code}` returns these ids plus `dc_pm_name`, `dc_sa_name`, `tech_lead_name` and `pm_name`. `POST /api/initiatives` with `dc_intake` applies them when the body does not supply them. DCI-3391 maps to DC PM 16 Grace Ellingham, DC SA 14 Sana Whitfield, Tech Lead 3 Devon Achterberg and PM 16.
- **2026-10-19 · QA-C-04 (requested by the orchestrator, applied by B3):** the `app/ai/schemas.py` fixture wrapper `match` takes an optional `requires` object. All keys are optional; unknown keys are rejected. Shape: `{"initiatives_exist":[RDDC], "initiatives_absent":[RDDC], "health":{RDDC:{"overall"|dimension: "Red"|"Amber"|"Green"|"Not scored"}}, "stage_in":{RDDC:[stage]}, "float_bd":{RDDC: int}}`. `app/ai/simulated.py` checks these against live data (cached health, stage, and the readiness float as Pg 2 shows it). If any requirement fails, the fixture is not served and the generator answers instead.
- **2026-10-19 · Round 2 #4 (requested by the orchestrator, applied by B3):** `schemas.ASSISTANT_INTENTS` gains `prn_status`, `crq_sto_readiness` and `what_if_slip`. This is additive: fixtures and the UI may use them. The AiRun envelope and the chat response gain `deterministic: bool`. It is true when the answer comes from rules rather than a model or test-agent text (mode `simulated_generated`, or feature `cr_compliance`); the UI hides the confidence pill when it is true.
- **2026-10-19 · Round 2 decision 3 (applied by B3):** `CR_COMPLIANCE.findings[].status` adds `"Not due yet"`, and findings take an optional `due_date` (`YYYY-MM-DD` or null). This mirrors `engines.compliance`.
- **2026-10-19 · Round 3 N5 (applied by B3):** `schemas.ASSISTANT_INTENTS` gains `prn_overrun`, which lists every PRN forecast to exceed its funded hours across the portfolio. This is additive.
- **2026-10-19 · Round 3 (orchestrator ruling, applied by B3):** `CR_COMPLIANCE.sto_readiness` adds `"Not requested"`. It stays a status string; when `engines.compliance` returns an object, the AI layer reads its `status`. This is additive.
