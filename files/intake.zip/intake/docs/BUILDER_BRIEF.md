# Builder brief (applies to every builder B1–B6)

Project root: the repository root · Python: `.venv/bin/python` (3.13; flask, openpyxl, python-docx, pypdf, anthropic, jsonschema, pytest, playwright+chromium, ruff) · Node 25 for `node --check` only.

## Read first (in this order)
1. `docs/00_MASTER_PLAN.md` — the contract. **§6 red-team amendments override everything.**
2. `docs/contracts.md` — endpoints, payload shapes, bundle, lookups, view-module and chart signatures (frozen).
3. Frozen contract code: `app/schema.sql`, `app/db.py`, `app/config.py`, `app/errors.py`, `app/__init__.py`, `app/today.py`, `app/ai/schemas.py`, `static/js/api.js`, `tests/fixtures/bundle_hero.json`, `docs/ai_schemas_examples.md`.
4. The planning doc(s) for your slice in `docs/planning/` (1 PO fields/rules/seed · 2 architecture · 3 AI · 4 UX · 5 QA).

## Rules
- **Own only your files** (master plan §3 + §6.1). Never edit another builder's file or a frozen contract. If a contract is wrong or missing something, work around it locally and write the request in your handoff under "Contract change requests" — the orchestrator decides.
- **Direct, complete, working code.** No TODOs, no `pass` placeholders, no mock data where real data/API exists, no `console.log`/`print` debugging left behind. Match the app's own idioms; keep comments sparse and useful.
- **User-facing text reads like a BMO PM tool** (UX doc §6 copy rules): business labels, sentence case, no "JSON/API/model/token/null", no emojis, no exclamation marks. Never render `undefined`, `NaN`, `null`.
- **Dates:** ISO strings in DB/JSON; Python uses `app/today.py` for today/now (never `date.today()`); JS uses only `static/js/dates.js` helpers; business-day maths only in `app/engines/calendar.py`.
- **Enums** come from `GET /api/lookups` in the UI; CHECK constraints in the DB. Use exact spellings from the master plan.
- **Security:** SQL via `?` params only; user/AI text into DOM via `textContent` or `esc()`; uploads per master plan §1.
- **Derived data** (allocations, rag_cached, notifications) is written only by `app/services/derive.py`.

## L1 self-check (must pass before you hand off)
- `.venv/bin/ruff check <your python files>` → 0 errors · `.venv/bin/python -m compileall -q app` OK · `node --check` on each of your JS files.
- Your slice's tests pass: `.venv/bin/python -m pytest <your test dirs> -q`.
- If the app is runnable with your slice: `BMO_DB_PATH=/tmp/<you>.db .venv/bin/python -m app.cli reset` (once B1 exists) and hit your endpoints/pages.

## Handoff
Write `docs/handoffs/<Bn>.md` (≤40 lines): files written · what works (verified how) · known gaps · contract change requests · how to verify. Then reply to the orchestrator with a ≤10-line summary.

## Pinned seed IDs (B1 seeds exactly these; B3/B6 may reference them)
- **resources.id**: 1 Tobias Wren (EAPI Dev1) · 2 Lena Oduya (EAPI Dev2) · 3 Devon Achterberg (EAPI Tech Lead) · 4 Mira Castellane (CIAM) · 5 Felix Hartwell (CIAM) · 6 Kai Moreau (SRE) · 7 Ines Hollowell (SRE) · 8 Jasper Quill (Mobile iOS) · 9 Yuki Larkspur (Mobile Android) · 10 Nadia Fenwick (Web) · 11 Theo Marchetti (Web) · 12 Hana Brightwater (QA Lead) · 13 Omar Velasquez (QA) · 14 Sana Whitfield (DC SA) · 15 Mateo Brennan (DC SA) · 16 Grace Ellingham (DC PM) · 17 Ravi Dunmore (DC PM) · 18 Arlo Kingsley (Delivery Lead) · 19 Petra Vallance (CMS Lead) · 20 Owen Stroud (Rel Lead) · 21 Elena Rusk (Account Manager) · 22 Clara Pemberton (Requestor, US P&C) · 23 Marcus Thorne (Requestor, Cards & Payments) · 24 Bea Lindqvist (Requestor, Wealth). Ids 16–24 have `capacity_eligible=0`.
- **dc_components.id**: 1 APIP API Platform · 2 APIGW API Gateway · 3 EDP Enterprise Data Platform · 4 CIAM "CIAM / Security" · 5 MOB_IOS Mobile App – iOS · 6 MOB_AND Mobile App – Android · 7 OLB Online Banking Web · 8 PAYHUB Payments Hub · 9 NOTIF Notifications Service · 10 STMT Statements & Documents · 11 SRE "SRE / Observability" · 12 FRAUD Fraud Signals Integration (leads, hours, downstream per PO doc §4).
- **initiatives.id**: 1 RDDC-24310 · 2 RDDC-24412 · 3 RDDC-24533 · 4 RDDC-24601 · 5 RDDC-24688 · 6 RDDC-24702 · 7 RDDC-24755 · 8 RDDC-24790. The hero RDDC-24817 is created live (id 9 after reset).
- **Hero WBS skeleton** (B6 fixture, B3 generator and B2 golden must agree; §6.2 dates): WBS-100 Estimation & solution finalization (DC SA Sana, 70 h, 50%) → WBS-200 Development parent with children WBS-210 API Platform (280 h dev, Tobias), WBS-220 EDP (120 h, Lena), WBS-230 CIAM / Security (120 h, Mira), WBS-240 SRE / Observability (40 h, Kai) [dev rows sum exactly 560] → WBS-300 Integration / SIT (+ child regression steps for downstream Mobile/Web) → WBS-400 QA (Hana, ends 2027-02-10 = QA Date) → WBS-500 UAT / business validation → WBS-600 Release readiness & CRQ (ends 2027-02-17 = Readiness Date) → WBS-700 Production implementation (milestone Sat 2027-02-20, DC-2702) → WBS-800 Hypercare (10 bd). Σ est_hours ≤ 1,000.
