# Round 1 · L5 adversarial red-team review

Reviewer: L5 red-team agent (did not write this code). Date: 2026-10-19 (demo clock).
Scope: `app/**/*.py`, `static/js/**/*.js`, `static/index.html`, `run.sh`, `run_demo.sh`, `reset.sh`. App code was read only; no app files were edited.
Method: full read of the core, plan, AI-apply, derive and view code, then targeted reads of the other modules. Every finding below was reproduced on a private server (`BMO_DB_PATH=/tmp/redteam.db BMO_UPLOAD_DIR=/tmp/redteam_uploads BMO_PORT=5092`) through HTTP probes or Playwright, unless it is marked "by inspection".
Hero state used in the repros: `POST /api/admin/reset` then `POST /api/admin/fast-forward-hero`, which gives RDDC-24817 id 9 with Resources Red before the fix.

**Counts: 0 Blocker · 6 Major · 11 Minor.**

---

## Major

### L5-01 · Major · The cached RAG goes stale for other initiatives, so Search, the trains, the header and the assistant contradict the Portfolio KPIs
- **Where:** `app/services/derive.py:23-70`. `rebuild_allocations` and `refresh_health` act only on the initiative being written. The call sites are `app/ai/apply.py:46-54` (`derive_after`), `app/api/plan.py:243` (`_finish`), and `app/api/views.py:582-583` and `626-627` (L2 submit and approve).
  The stale `rag_cached` and `health_cached_json` values are read by `app/repo.py:156` (Search list and RAG filter), `app/api/core.py:315` (release-train cards), `static/js/views/initiative.js:51` (workspace header pill), `app/ai/context.py:444` with `app/ai/assistant.py:1163` (assistant KPI bindings), and `app/ai/provider.py:139,206` (exec-summary RAG and fixture check).
  By contrast, `app/api/resources.py:186-188` refreshes every affected initiative after an availability change, so the pattern already exists in the code.
- **Repro:** reset, then fast-forward the hero. The hero's WBS-100 puts Sana Whitfield at 128% in Nov 2026, which turns **RDDC-24688** Resources Red and Overall **Amber**:
  - `GET /api/portfolio` returns RDDC-24688 `rag: "Amber"` with KPIs `amber: 3`.
  - `GET /api/initiatives` (Search) returns RDDC-24688 `rag: "Green"`.
  - `GET /api/release-trains` shows DC-2702 → RDDC-24688 `rag: "Green"`.
  - `GET /api/initiatives/5` returns `health_cached_json.overall = "Green"`, while `GET /api/initiatives/5/health` returns `"Amber"`. The workspace header shows Green on Pg 1 and then flips to Amber with a pulse when Pg 3 loads.
  - Assistant "Draft this week’s exec summary" (a default chip) says *"8 active initiatives: 1 Red, 2 Amber"*, while the Portfolio KPI tile on the same screen says Amber **3**. This is demo-risk R15: the assistant contradicts the dashboard.
- **Fix:** in `derive.rebuild_allocations`, collect the old and new `resource_id`s and their months. Then call `refresh_health` for every initiative that holds allocations for those people, inside the same transaction. With 9 initiatives, `refresh_all_health()` after any allocation rebuild is also cheap. Add a regression test: after fast-forward, `GET /api/initiatives` RAG must equal `/api/portfolio` RAG for every row.
- **Owner:** B2 (derive). B3 needs no change once derive handles it.

### L5-02 · Major · The assistant's own suggested prompt "What’s driving the health status?" gets the generic help answer
- **Where:** `static/js/views/assistant.js:22,25`. The prompt chips use a typographic apostrophe (U+2019): `What’s`, `this week’s`. `app/ai/assistant.py:39` matches `what'?s driving` against `message.lower()` (`assistant.py:256`) without normalising quotes.
- **Repro:** `POST /api/assistant/chat {"message":"What’s driving the health status?","initiative_id":9}` returns *"I can answer questions about initiatives, health, people, capacity… Try one of these:"*. The same text with a straight `'` returns the correct per-dimension explanation. This is the first chip shown in every initiative workspace.
- **Fix:** in `route_intent`, entity extraction and `simulated._normal`, normalise `’ ‘ “ ”` to ASCII before matching. Use straight quotes in `PROMPTS` too. Add a test that sends every `PROMPTS` chip through chat and asserts a non-help intent.
- **Owner:** B3 (routing); B5 (chip text).

### L5-03 · Major · The chip "Which initiatives are on DC-2702?" answers "No active initiative is Red for DC-2702."
- **Where:** `static/js/views/assistant.js:24` (Changes page chips). `app/ai/assistant.py:41-43`: only `list_by_rag` scores (0.5, from "which … initiatives"). Then `h_list_by_rag` (`assistant.py:323-333`) defaults the colour to `["Red"]`.
- **Repro:** `POST /api/assistant/chat {"message":"Which initiatives are on DC-2702?"}` returns *"No active initiative is Red for DC-2702."* In fact RDDC-24817 and RDDC-24688 are both on DC-2702 (`GET /api/release-trains`).
- **Fix:** add a train-membership intent (`\bon dc-\d{4}\b`, or any train entity with no RAG word) that lists every initiative on the train with its RAG. `list_by_rag` with no colour word should not silently filter to Red.
- **Owner:** B3.

### L5-04 · Major · Initiative-scoped questions get portfolio-scoped showcase answers
- **Where:** `app/ai/simulated.py:200-219`. `match_showcase` matches on wording only and ignores `ctx.initiative_id`. `h_top_risks` (`app/ai/assistant.py:763-769`) also only scopes by initiatives named in the text, not by the page context.
- **Repro:**
  - On RDDC-24688 (`initiative_id: 5`), "Who is over-allocated on this initiative?" returns the showcase answer *"3 people … Felix Hartwell (120% in Dec 2026) … Hana Brightwater"*. Neither Felix nor Hana has work on that initiative.
  - In the hero workspace, "What are the top risks?" (a chip) returns RSK-001/002/007 from RDDC-24412 and RDDC-24601, not the hero's risks.
- **Fix:** when the request carries `initiative_id` and the message says "this initiative/project", or the question comes from the initiative chip list, skip portfolio showcases. Then pass the context initiative into `ents["initiatives"]` before routing.
- **Owner:** B3.

### L5-05 · Major · Editing Hours or Alloc % in the Pg 2 grid never moves dates, against the contract "allocation_pct sets the duration"
- **Where:** `app/api/plan.py:280` and `335`. Only `planned_start`, `planned_end` and `depends_on` changes trigger propagation, and nothing recomputes `duration_bd = ceil(est_hours/(7×pct))` (contracts §3, "Plan semantics"). The grid makes both columns editable (`static/js/views/pg2_plan.js:108-117`).
- **Repro:**
  - `PUT /api/initiatives/9/tasks/bulk {"tasks":[{"id":<WBS-210>,"allocation_pct":50}]}` leaves the dates unchanged (2026-11-18 → 2027-01-15).
  - Setting `est_hours: 560` also leaves the dates unchanged. Tobias Wren is then booked 294 h against 147 h in Dec (200%), and Resources and Budget turn Red with no schedule effect. A presenter showing a "what if we halve his allocation" scenario sees nothing move.
- **Fix:** for a leaf task, when `est_hours` or `allocation_pct` changes, recompute `planned_end` from `planned_start` with `engines.calendar` business days. Add the task to `changed_dates` so `propagate_slip` runs. Milestones stay exempt.
- **Owner:** B1 (plan), using B2 `calendar`.

### L5-06 · Major · Dropping a PDF on Add New Initiative shows "Attach an SA document or paste its text first."
- **Where:** `static/js/views/initiative_new.js:50-57`. `readFileText` extracts only `.md`, `.txt` and `.docx`. For a `.pdf` it returns `''`, so only `{filename}` is sent (`initiative_new.js:185-188`). The server then rejects it at `app/api/ai.py:80-81`. The dropzone accepts PDF (`ui/components.js:336`, ALLOWED list), and the hero SA ships as `.pdf` as well as `.docx`.
- **Repro:** `POST /api/ai/intake-autofill {"options":{"filename":"SA_US_API_Enhancement_v1.2.pdf"}}` returns 422 *"Attach an SA document or paste its text first."* In the UI this error card appears right after the user attached the document.
- **Fix:** either upload the file to a staging endpoint and extract it server-side (`textract.extract_text` already handles PDF), or tell the user plainly: "PDF autofill isn't available here; drop the .docx or paste the text."
- **Owner:** B4 (view); B3 if a server-side extract option is added.

---

## Minor

### L5-07 · Minor · Two concurrent creates of the same DC intake give two initiatives linked to DCI-3391
- **Where:** `app/api/initiatives.py:89-92`. The "already registered" check runs before `with db.transaction()` (line 116). `initiatives.dc_intake` has no UNIQUE constraint (`schema.sql:106`).
- **Repro:** two parallel `POST /api/initiatives {"dc_intake":"DCI-3391"}` return 201 RDDC-24817 and 201 RDDC-24818, both with `dc_intake = DCI-3391`. RDDC-24818 has no fixtures, so every AI card would come from the rules engine. The UI Save button is busy-disabled, so this needs two tabs, a retry after a timeout, or a script.
- **Fix:** run the linked-intake check inside the `BEGIN IMMEDIATE` transaction, or add `CREATE UNIQUE INDEX … ON initiatives(dc_intake) WHERE dc_intake IS NOT NULL`. The second option is a frozen-schema change request, so it goes to B0.
- **Owner:** B1 (B0 if the index is chosen).

### L5-08 · Minor · Applying one AI run concurrently writes its rows several times
- **Where:** `app/ai/apply.py:414-431`. `status != 'generated'` is checked before the transaction starts.
- **Repro:** three parallel `POST /api/ai-runs/{risks run}/apply` all return 200 `{"risks":5}`. The register then has 15 risks with 5 distinct titles. The UI disables Accept (`ui/ai_card.js:328`), so this needs two tabs or a retry after the 25 s client timeout.
- **Fix:** inside the transaction, run `UPDATE ai_runs SET status='accepted' … WHERE id=? AND status='generated'`. If `rowcount == 0`, return 409 before calling the applier.
- **Owner:** B3.

### L5-09 · Minor · Reset drops and recreates tables outside a transaction, so concurrent requests get 500
- **Where:** `app/seed/seed.py:325-339`. `_drop_all` and `init_schema` run outside `db.transaction`, and other request threads keep reading.
- **Repro:** five `POST /api/admin/reset` calls while four threads poll `/portfolio`, `/intake-queue`, `/outbox` and `/initiatives/9` produced 60 responses with **500** (`OperationalError: no such table: initiatives` and `…notifications`). A second browser tab (for example the projector window) that refreshes or navigates during Reset shows the "Something went wrong" banner.
- **Fix:** seed a temp DB file and atomically `os.replace` it. Alternatively, guard requests with a reset lock (a `before_request` that waits, or returns 503 "Resetting…").
- **Owner:** B1.

### L5-10 · Minor · The Outbox shows duplicate reminders, and accepting "Draft reminders" adds more
- **Where:** `app/services/derive.py:180-197` with `app/engines/reminders.py` (queues both the reminder due now and the next one). Also `app/ai/apply.py:285-303` with `app/ai/fixtures/nudges/portfolio.json`, whose dedupe keys differ from derive's.
- **Repro, after reset alone:** six pairs of Queued reminders for the same item. Example: Yuki Larkspur gets "Action required by Mon 19 Oct: Mobile App – Android approval…" and "…Wed 21 Oct…". This inflates the Outbox badge to 16.
- **Repro, Outbox → Draft reminders → Accept:** 7 more are queued. The preview says they are "consolidated… one per person", but the originals stay Queued and the keys (`sa_action_required:14:2026-10-21`) never dedupe against derive's (`sa_action_required:initiative:9:2026-10-21`). Sana then has two SA reminders for the hero.
- **Fix:** queue only reminders that are due today or earlier. Make nudges use derive's `rule:entity:id:date` keys, and mark the per-item reminders a nudge replaces as Dismissed.
- **Owner:** B2 (reminders); B3 (nudges apply and fixture).

### L5-11 · Minor · "Check CR Compliance → Save review" stores a review nobody can see
- **Where:** `app/ai/apply.py:373-389` writes `compliance_json.ai` (score, findings, reviewer note). `app/repo.py:241-249` (`list_change_requests`) recomputes compliance live and pops `compliance_json`, so nothing displays the saved review. The toast says "Compliance review saved to the change request" (`static/js/views/pg4_governance.js:312`).
- **Repro:** accept a cr_compliance run, then call `GET /api/change-requests/{id}`. The response has no `ai` block and Pg 4 is unchanged.
- **Fix:** return `compliance.ai` from the cached JSON next to the live flags and render it on Pg 4. Otherwise relabel the button "Close" and make the run read-only.
- **Owner:** B3 with B1 (read model), B4 (Pg 4).

### L5-12 · Minor · Pg 1 "How we got this" → "Save explanation" saves no explanation and can revive a rejected L2
- **Where:** `app/ai/apply.py:135-139` and `81-89`. `apply_l2_estimate` only recomputes `l2_hours` and sets `l2_status` to `Draft` when it was `Rejected`. The toast says "L2 explanation saved." (`static/js/views/pg1_general.js:421`).
- **Repro:** reject L2 (`POST …/l2/reject`), then accept an `l2_estimate` run. The initiative goes back to `l2_status: "Draft"` and no narrative is stored anywhere except `ai_runs`.
- **Fix:** make the card read-only (`acceptable: false`, a Close button), or store the narrative, for example as a decision or note. Do not touch `l2_status`.
- **Owner:** B3 (applier); B4 (label).

### L5-13 · Minor · Accepting the initiative Executive Summary overwrites the human "Comments" field
- **Where:** `app/ai/apply.py:392-395` sets `initiatives.comments = headline`. Comments is a PM-maintained column on the Portfolio and Pg 5 dashboard (`static/js/views/portfolio.js:54`). The toast says "accepted and logged" (`pg5_portfolio.js:184`).
- **Repro:** Pg 5 → Write Executive Summary → Accept. The seeded comment is replaced by the AI headline, with no undo.
- **Fix:** log the summary as a decision or document, or append to Comments with a prefix. Never overwrite silently.
- **Owner:** B3.

### L5-14 · Minor · The rebalance fixture is still served after the problem it describes is fixed
- **Where:** `app/ai/provider.py:195-196`. `fixture_fits('rebalance')` checks only that the WBS codes exist.
- **Repro:** apply the recommended fix (WBS-100 moves to Mateo; Resources Green). A new `POST /api/initiatives/9/ai/rebalance` returns the fixture *"Sana Whitfield is at 128% in Nov 2026 … WBS-100 adds 38.5 h"* and proposes moving WBS-100 from Sana to Mateo again. Post-validation shows `before = after = 96%/74%`.
- **Fix:** require the live `problem.resource_id` to still own `problem.wbs_codes[0]`, and live util for `problem.month` to be within 1 point of `util_pct`. Otherwise use the generator.
- **Owner:** B3.

### L5-15 · Minor · A non-ASCII file name is rejected as a wrong file type
- **Where:** `app/api/initiatives.py:337-341`. `secure_filename("设计.txt")` returns `"txt"`, so the suffix is `""` and the user sees "Attach a .docx, .pdf, .md or .txt file." The file is a `.txt`.
- **Fix:** take the extension from the original name, and fall back to `upload-<n><ext>` when `secure_filename` strips the stem.
- **Owner:** B1.

### L5-16 · Minor · `run_demo.sh` resets before checking the port, and gives up if the app is already running
- **Where:** `run_demo.sh:13-15`, `app/cli.py:70-73`. If a rehearsal server still holds 5055, the script wipes that server's DB, the new server fails to bind, and the script exits with "The server did not start". No browser opens, and the old process, possibly running older code, keeps serving. Risk R8 asked the launcher to pick or recognise the port.
- **Fix:** before resetting, probe `http://127.0.0.1:$PORT/api/health`. If it answers with this app's `version`, say so and open it. Otherwise pick the next free port and print the URL.
- **Owner:** B1.

### L5-17 · Minor · The full test suite is red because of a harness error
- **Where:** `tests/qa/test_e2e_audit.py`. Playwright's sync API is called inside an asyncio loop. `pytest` reports `1 failed, 471 passed` ("It looks like you are using Playwright Sync API inside the asyncio loop"). This is not app code, but the L7 "full pytest green" gate cannot pass until it is fixed or isolated, for example by running it in its own process or switching to `async_playwright`.
- **Owner:** QA L4 harness author (B0 to arbitrate).

---

## Checked and clean (evidence)
- **api.js and `app.url_map`:** every path in `static/js/api.js` resolves to a registered rule (0 missing). The server-only routes `/api/ai-runs/<id>/regenerate`, `/api/ai/features` and `/api/resources/<rid>/calendar` are unused but harmless. Several api.js functions have no UI caller: allocation CRUD, `createResource`, `updateResource`, `setResourceSkills`, `createGroomingSession`, `updateArtifact` and `deleteArtifact`. This means Artifacts rows cannot be edited or deleted in the UI. This is a coverage gap, not a defect.
- **Smoke test:** a Playwright run over 85 routes (all global pages, plus 8 tabs × 9 initiatives, plus a bogus route) showed 0 console errors, page errors, HTTP ≥ 400, banners or error panels.
- **Click sweep:** non-destructive buttons were clicked on Portfolio, Intake, Changes, Risks, Outbox, Resources, Artifacts, AI Activity and Search. No console errors and no 5xx.
- **Security:**
  - The only `innerHTML` mention is a comment (`charts/kit.js:2`). The DOM builder uses `textContent` and text nodes. The markdown renderer (`kit.js:689-762`) never interprets HTML, and links are restricted to `^#/[\w\-/]*$`.
  - AI `route` fields are schema-constrained to `^#/` (`schemas.py:157`).
  - All SQL with values uses `?`. The f-string identifiers come from code constants or whitelists.
  - Uploads use `secure_filename`, are stored under `data/uploads/<id>/`, and are capped at 10 MB. Corrupt `.docx` and `.pdf` files return 422 `unreadable_file` with the paste fallback. `../../etc/x.md` was stored as `etc_x.md`.
  - XLSX and CSV cells starting with `= + - @ \t \r` are escaped (`xlsx_export.py:58-62`).
  - No API key appears in `/api/health`, `/api/settings`, logs or page source. Debug is off, the bind address is 127.0.0.1, and there is no CORS.
- **Live fallback:** with `ANTHROPIC_API_KEY=bogus` and an unreachable `ANTHROPIC_BASE_URL`, intake-analysis answered `live_fallback` in 6.0 s and chat in 4.1 s, with the "Live → Simulated" label and warning. Live calls use `max_retries=0` and a 20 s deadline.
- **Determinism:** no `random`, wall-clock or uuid in the AI or engine paths (only `today.now_iso` for audit stamps). Fixture variants advance deterministically on Regenerate (variant 0 → 1 → generator 2).
- **Hero arithmetic:** fast-forward reproduced Overall Amber and Schedule Amber (float 2 bd, Readiness 17 Feb, Prod Sat 20 Feb). The fix moved WBS-100 to Mateo (Sana 128% → 96%, Mateo 42% → 74%) and turned Resources Green. Editing the WBS-210 end +5 bd turned Schedule Red and Overall Red; editing it back restored Amber. The CRQ draft is CRQ0001048817.
- **Robustness:** 20 malformed-input probes (bad dates, cycles, non-numeric ids, unknown sessions, negative hours) all returned 4xx JSON. No 500 except under the reset race in L5-09.
- **Dates:** JS date maths goes through `dates.js` and `kit.js` UTC day numbers. The only `new Date(y, m, 1)` is a month iterator in the Pg 2 fallback Gantt, which is timezone-safe. Toronto offsets come from `Intl` (`dates.js:154`).
