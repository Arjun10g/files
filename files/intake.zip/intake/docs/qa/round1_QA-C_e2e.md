# Round 1 · QA-C · End-to-end browser and UX audit (L4)

**Auditor:** QA-C (independent; did not write the code) · **Date:** demo date Mon 19 Oct 2026
**Build under test:** app 1.0.0 on `127.0.0.1:5091`, own DB `/tmp/qa_c.db`, uploads `/tmp/qa_c_uploads`, Simulated AI, AI speed Fast (one Realistic pass for thinking steps and Stop)
**Script:** `tests/qa/test_e2e_audit.py`. It runs under pytest and starts its own server on a free port with a temp DB. `QA_C_PARTS=demo1366,demo1920,sweep,tz` picks the parts to run. It can also run standalone with `--base-url`.
**Evidence:** `docs/qa/shots/round1/`. The files are:
- `demo1366_NN_*.png`: demo walk, America/Toronto, 1366×768
- `demo1920_NN_*.png`: demo walk, Pacific/Auckland, 1920×1080
- `s1366_*` and `s1920_*`: route and tab sweep
- `realistic_*`: Realistic speed pass
- `d1366_*`: first pass, same flow
- `qa_c_report.json` and `qa_c_sweep.json`: raw findings
- `*.xlsx`: downloaded exports

## Verdict

The demo walks end to end through the UI with **0 page errors, 0 unhandled rejections and 0 HTTP 5xx**. There is no horizontal page overflow at either viewport. No undefined, NaN, null or [object Object] text appears. No spinner gets stuck, and all 32 AI cards opened in the sweep can be dismissed. Every export downloads and opens in openpyxl. Dates are identical in Toronto and Auckland on 7 date-heavy routes.

The pages read like the Excel Demo View: PG n boxes, label/value grids, yellow automation buttons, Pg 4 attachment cells in yellow, and Pg 5 deck tiles.

**But one scripted beat is broken (Undo on the WBS-210 edit).** It leaves the hero Red for every later beat: Pg 3 Overall Red instead of Amber, Portfolio Red, a CRQ window that no longer matches the plan, and assistant answers that are wrong. Two more script beats are missing at steps 3 and 4: the DC SA invite and the "Action required by DC SA" chip.

| Severity | Count |
|---|---|
| Blocker | 1 |
| Major | 5 |
| Minor | 16 |
| Polish | 7 |
| **Total** | **29** |

Owner split (roughly): B4 has 12, B5 has 11, and 6 sit with the backend or content owners (B1, B2, B3, B6). For those 6 the screen owner is noted so it can route the defect.

---

## Defects

### QA-C-01 · Blocker · Pg 2 `#/initiative/:id/pg2` · Undo after a WBS date edit re-sends the new date
- **Shots:** `demo1366_16_edit_wbs210_end_plus5.png` → `demo1366_17_undo_edit.png` (also `demo1920_16/17`, `d1366_16/17`).
- **Steps:**
  1. On Pg 2, click the WBS-210 End cell.
  2. Change 15 Jan 2027 to 22 Jan 2027 (+5 business days) and press Enter.
  3. Toast: "WBS-200 and 8 more steps moved · Readiness Date now 24 Feb 2027. [Undo]". The header turns Red and Float is −3 business days. This part is correct.
  4. Click **Undo**.
- **Expected:** WBS-210 goes back to 15 Jan. Readiness Wed 17 Feb 2027, Float 2 business days, Schedule Amber, Overall Amber (master plan §6.2 item 6).
- **Actual:** Nothing changes. WBS-210 stays at 22 Jan, Readiness 24 Feb, Production **Sat 20 Mar 2027**, header Red. Network shows that Undo sends `PUT /tasks/bulk {"id":143,"planned_start":"2026-11-18","planned_end":"2027-01-22"}`, which is the *new* value. This happens in both viewports and both timezones, every time.
- **Cause:** `ui/grid.js commitEdit` writes `row[col.key] = value` *before* it calls `onCommit`. `pg2_plan.js flush()` then builds its `before` map from `grid.getRows()`, which already holds the edited value, so `oldEnd` equals the new end. Capture the original value (`editing.original`) in `onCommit` or `queue()`. Re-typing 15 Jan by hand does restore Amber with 2 business days, so the backend is fine.
- **Impact:** Steps 9–14 all show the slipped state:
  - Pg 3 health is Overall **Red** and Schedule Red instead of Amber (`demo1366_18_pg3_health.png`).
  - After "Suggest fix", Overall stays Red (`demo1366_23_fix_applied.png`).
  - Portfolio shows RDDC-24817 Red, Readiness 24 Feb, Prod 20 Mar (`demo1366_30_portfolio_after.png`).
  - The assistant gets it wrong (see QA-C-03).
- **Owner:** B4: `static/js/views/pg2_plan.js` (`flush`/`undoDates`), `static/js/ui/grid.js`.

### QA-C-02 · Major · Add New Initiative and Pg 1 · Following the script never sets DC SA, so the step 3 invite and step 4 chip are missing
- **Shots:** `demo1366_03_dci_lookup_prefill.png`, `demo1366_04_saved_grooming_toast.png`, `demo1366_06_sa_attached_88.png`.
- **Steps:** Add New Initiative → DC Intake `DCI-3391` → Look up → Save → on Pg 1 attach `SA_US_API_Enhancement_v1.2.docx`.
- **Expected (PO §1 steps 3–4):**
  - Toast: "Invite queued to Arlo Kingsley, Grace Ellingham, **Sana Whitfield**".
  - Pg 1 shows the "Action required by DC SA" chip with next reminder **Wed 21 Oct**.
  - DC SA is Sana Whitfield and Tech/Dev Lead is Devon Achterberg (hero pins in master plan §1).
- **Actual:**
  - The lookup fills name, LOB, requestor, priority, go-live, release, PRN and description, but leaves **DC SA "—"** and **Tech/Dev Lead "—"**.
  - The toast reads "Invite queued to Arlo Kingsley, Grace Ellingham, Clara Pemberton".
  - After the attach, Author shows "Sana Whitfield" but DC SA stays "—", and no Action-required chip renders. `pg1_general.js:131` only renders it when a DC SA notification exists.
  - The Outbox does hold "Action required by Wed 21 Oct: SA document for RDDC-24817" to Sana (`s1366_09_sweep_outbox.png`), so the engine is fine. The UI path just never assigns her.
  - DC SA is only filled when the SA document is dropped on the Add New page (autofill), which the script does not do.
- **Owner:** B4: `views/initiative_new.js` (default DC SA and Tech Lead on lookup, or the `dc_intakes` row should carry them) and `views/pg1_general.js` (set DC SA from the SA author on attach when empty). Backend: `app/seed/governance.json` `dc_intakes` (B1) has no `dc_sa`/`tech_lead`.

### QA-C-03 · Major · Assistant drawer · Readiness float binding is wrong ("17 business days" when float is −3)
- **Shots:** `demo1366_19_ask_why_resources_red_before_fix.png`, `demo1366_32_ask_feb_release.png`, `demo1366_35_ask_resources_red.png`.
- **Steps:** With the hero slipped (Readiness Wed 24 Feb 2027, train Sat 20 Feb, Pg 2 Float "−3 business days", Schedule Red), ask "Why is Resources red?" or "Which initiatives are at risk for the Feb release and why?".
- **Expected:** The float matches Pg 2 (−3, misses DC-2702).
- **Actual:**
  - "Overall health is Red; Schedule sets the floor with **17 business days of readiness float**."
  - "Schedule Red: Readiness Date 24 Feb 2027 leaves **17 business days** before the train."
  - Both sentences contradict themselves on the projector.
- **Cause:** `app/ai/assistant.py _b_float()` counts business days from `readiness_date` to the initiative's own `prod_date` (20 Mar, after the slip) instead of to the target train date (20 Feb), and it never goes negative.
- **Also:** "What needs management attention this week?" gives the reason for RDDC-24817 (Red) as "Sana Whitfield at 96% in November" (`demo1366_36_ask_mgmt_attention.png`). That is not a cause; Schedule is.
- **Owner:** B3 `app/ai/assistant.py` (binding) and B6 `app/ai/fixtures/assistant/{feb_release_at_risk,why_resources_red,mgmt_attention*}.json`. It surfaces in B5 `views/assistant.js`.

### QA-C-04 · Major · Portfolio, Pg 3 and Pg 5 · Static AI narratives state things the live data contradicts
- **Shots:** `realistic_02_exec_summary_card.png`, `demo1366_22_suggest_fix_card.png`.
- **Case 1, Portfolio right after Reset demo data** (the hero does not exist yet, step 1 of the demo): **Write Executive Summary** returns:
  - "US API Enhancement registered and planned Amber for DC-2702"
  - "RDDC-24817 … planned at 1,000 h … with 2 business days of readiness float"
  - "Change Summary, L2 (1,000 h, L) and a 14-step plan on day one"
  - None of this has happened yet.
- **Case 2, Pg 3 Suggest fix card:** the body says "overall health stays Amber because readiness float is 2 business days". The live line directly under it reads "After: Resources Green · Overall **Red**".
- **Case 3:** The hero exec-summary fixture hard-codes "is Amber … 2 business days of readiness float".
- **Expected:** AI text binds to live values (as the assistant fixtures do), or the fixture is not served when its preconditions fail (hero missing, or state not Amber). A director who notices one invented sentence stops trusting the rest.
- **Owner:** B6 `app/ai/fixtures/exec_summary/{portfolio,RDDC-24817}.json` and `fixtures/rebalance/RDDC-24817.json`, B3 fixture matching (`simulated.py`). It surfaces in B5 `portfolio.js`/`pg5_portfolio.js` and B4 `pg3_resources.js`.

### QA-C-05 · Major · Pg 2 grid at 1366 (and 1920) · Start, End, Status, % and Comments are off-screen
- **Shots:** `demo1366_13_plan_accepted.png`: columns stop at "Alloc %". Compare `demo1366_16_edit_wbs210_end_plus5.png` (scrolled) and `demo1920_15_gantt_critical_path.png` (End cut to "29 J").
- **Measured:**

  | Viewport | Visible width | Grid width |
  |---|---|---|
  | 1366 | 1,050 px | 1,873 px |
  | 1920 | 1,340 px | 1,873 px |

  There is no visible scroll hint. The step 8 edit target (End) and the dates the audience must read are hidden until the presenter scrolls sideways. When scrolled, the frozen WBS and Steps columns cover half the Description text, and the Description header label disappears.
- **Expected:** At 1366 the WBS #, Steps, Resource, Start, End, Status and % columns are visible without scrolling. Hide Description, SME and Comments by default, or move Start and End next to Steps. Give the scroller a visible shadow or scrollbar.
- **Owner:** B4: `views/pg2_plan.js` (column order and widths), `static/css/app.css` (`.grid-scroll`).

### QA-C-06 · Major · Initiative Risks tab · Table clipped and rows about 160 px tall
- **Shots:** `demo1366_25_risks_accepted.png`, `demo1920_25_risks_accepted.png`.
- **Actual:**
  - At 1366 the grid is 778 px visible out of 1,393 px. Owner names are cut ("Lena (", "Mira C", "Hana I"), and Mitigation, Linked WBS and Status are hidden.
  - The hidden multi-line Mitigation cell makes every row about 160 px tall, so 5 risks fill 750 px of mostly empty yellow. The 4×4 matrix takes the right third.
  - At 1920, Mitigation is cut mid-word.
- **Expected:** Step 11 shows severity × likelihood, owner, mitigation and linked WBS on one screen. Stack the matrix above the table or make it collapsible, clamp mitigation to 2 lines, and fit the columns.
- **Owner:** B4: `views/risks_tab.js`, `app.css`.

### QA-C-07 · Minor · Risk Register `#/risks` · Title column one word per line, Status clipped
- **Shot:** `s1366_06_sweep_risks.png`.
- **Actual:** The Title column is about 60 px wide ("Business / validation / retest / slips past / 13 Nov"), Risk ID wraps to "RSK- / 001", and the Status select is cut ("Mitigating"). Rows are up to 170 px tall.
- **Owner:** B5 `views/risks.js`.

### QA-C-08 · Minor · Portfolio and Pg 5 tables clipped at 1366
- **Shots:** `demo1366_01_portfolio_home.png`, `demo1366_29_pg5.png`.
- **Actual:**
  - Project Dashboard is 1,050 px visible of 1,174 px. Comments is cut ("Business va", "QA 6 busine") and Project Name wraps to 4 lines.
  - Change Management is 1,050 px visible of 1,483 px. The Compliance column shows "Busin", "Backo", "Chang".
  - Pg 5 Compliance shows "Backout p".
- **Expected:** Compliance flags are the point of that table, so they should not be hidden. Wrap the pills or drop the CMS and Rel Lead columns at 1366.
- **Owner:** B5 `views/portfolio.js`, `views/pg5_portfolio.js`, `css/charts.css`.

### QA-C-09 · Minor · Resource heatmap headers truncated
- **Shots:** `demo1366_01_portfolio_home.png` (bottom-left), `demo1366_18_pg3_health.png` (Monthly allocation).
- **Actual:**
  - Portfolio heatmap: "Feb–Apr · Q2 FY" is cut and the Apr column is hidden (`ch-scroll` 484/534).
  - Pg 3 monthly allocation: the header reads "Aug–Oct · Q4 F".
- **Owner:** B5 `charts/heatmap.js`.

### QA-C-10 · Minor · Gantt labels collide, and the critical path legend is misleading
- **Shots:** `demo1366_15_gantt_critical_path.png`, `demo1920_15_gantt_critical_path.png`.
- **Actual:**
  - The "DC-2612" train label overprints "CHANGE FREEZE" ("DC-26CHANGE FREEZE") at both widths.
  - The "0%" labels are crossed by connector arrows.
  - Legend: "Critical path: WBS-100 → WBS-210 → WBS-220 → WBS-230 → WBS-300 …". WBS-210, 220 and 230 run in **parallel**, so chaining them reads as sequential work.
- **Expected:** Train and freeze labels on separate rows. Critical path shows a single chain, or groups parallel steps ("WBS-210/220/230").
- **Owner:** B5 `charts/gantt.js`.

### QA-C-11 · Minor · After a slip, Production and CRQ disagree with the plan
- **Shots:** `demo1366_16_edit_wbs210_end_plus5.png`, `demo1366_28_cr_compliance.png`.
- **Actual:**
  - The Pg 2 key strip reads "Production Date **Sat 20 Mar 2027** · DC-2702 release train". 20 Mar is DC-2703, and the header still says Target Release DC-2702.
  - "Create CRQ draft" then drafts a window on **Sat 20 Feb 2027** while WBS-700 is on 20 Mar.
  - Check CR Compliance passes CR-09 "Implementation status matches the change window dates".
- **Expected:** The caption names the train the date belongs to and flags "misses DC-2702". The CRQ draft follows WBS-700, or compliance flags the mismatch.
- **Owner:** B4 `views/pg2_plan.js` (caption); B2 `app/engines/compliance.py` (rule).

### QA-C-12 · Minor · Native date inputs show ISO and AM/PM, not "19 Oct 2026"
- **Shots:** `demo1366_02_add_new_initiative.png` ("yyyy-mm-dd"), `demo1366_06_sa_attached_88.png` (Requested Go-live "2027-02-20"), `demo1366_28_cr_compliance.png` (CRQ Start "2027-02-20, 02:00 AM"), `demo1366_40_settings.png` (Demo date "2026-10-19").
- **Expected:** UX §6 date format, with 24-hour CRQ windows ("Sat 20 Feb 2027 02:00").
- **Note:** The rendering depends on the browser locale. Under en-US it becomes "02/20/2027", which is the wrong format for a Canadian bank.
- **Owner:** B4 `initiative_new.js`, `pg1_general.js`, `pg4_governance.js`, `settings.js` (show the formatted date with a picker button, or a text input parsed by `dates.js`).

### QA-C-13 · Minor · Pg 1 Current Status stays "Backlog" at Stage Planning; the export says "In progress"
- **Shots:** `demo1366_10_persona_requestor_approve_l2.png` (Current Status Backlog, Stage Planning); `demo1366_hero_demo_view.xlsx` sheet Demo View (Current Status "In progress").
- **Expected:** PO §3: Backlog until Planning, then In progress. Screen and export must agree.
- **Owner:** B4 `pg1_general.js` (or B1/B2 `app/services/derive.py` if the stored value is stale).

### QA-C-14 · Minor · Assistant drawer header is a jumble
- **Shots:** `demo1366_31_assistant_open.png`, `demo1920_36_ask_mgmt_attention.png`.
- **Actual:** "Assistant", the "● Simulated AI" chip, "New conversation" and "Close" wrap onto 3 lines. "Close" floats under the chip as a text link, which overlaps the sweep's hit-test with "Export to Excel" at 1366.
- **Expected:** UX §2.6: "Assistant ─── ● Simulated ✕" on one line.
- **Owner:** B5 `views/assistant.js` and drawer CSS.

### QA-C-15 · Minor · Chart tooltip outlives its page
- **Shots:** `demo1920_25_risks_accepted.png` and `demo1920_36_ask_mgmt_attention.png`.
- **Actual:** The "Dependencies = Green … Earliest need-by (business days): 21" tooltip from a health tile stays on screen over unrelated content: the Risks tab after leaving Pg 3, and the capacity chart.
- **Expected:** `destroy()` removes the tooltip node, and the tooltip hides on route change.
- **Owner:** B5 `charts/rag.js`, `charts/kit.js`.

### QA-C-16 · Minor · Settings → Reset leaves stale UI
- **Shots:** `d1366_43_41_reset_done.png` and `demo1366_44_reset_done.png`.
- **Actual:**
  - After the reset, the "RDDC-24817 is ready. [Open]" toast from Fast-forward is still shown, and its Open link points to a deleted initiative.
  - The Outbox rail badge stays at **19**. Fresh seed has 8 queued, confirmed with `GET /api/outbox?status=Queued`.
- **Owner:** B4 `views/settings.js` (dismiss toasts on reset) and `main.js` (refresh rail badges after reset).

### QA-C-17 · Minor · Mode chip copy "Simulated · test-agent response"
- **Shots:** every AI card, assistant answer and AI Activity row (`s1366_10_sweep_ai_activity.png`).
- **Actual:** "test-agent" is build-team jargon. The audience will ask what a test agent is. UX §6 says no dev jargon, and the top bar already says "● Simulated AI".
- **Expected:** Use "Simulated AI" (or "Simulated · prepared response" vs "Simulated · rules engine"). The master plan §2 wording should be revised to match.
- **Owner:** B4 `ui/components.js modeChip`; B5 `views/assistant.js`, `views/ai_activity.js`.

### QA-C-18 · Minor · Pg 1 Intake Analysis card is stale and in the way at step 4
- **Shots:** `demo1366_05_intake_analysis_card.png`, `demo1366_06_sa_attached_88.png`.
- **Actual:**
  - The card is about 750 px tall, so at 1366 the SA document dropzone needed for step 4 is below the fold.
  - After the attach, the card still warns "No SA document attached yet; components are inferred from the description only".
  - Its summary says "Requestor, LOB, priority, **DC SA** … are in place" while DC SA is empty (QA-C-02).
- **Expected:** Collapse the card to a summary line by default, and refresh it or drop the stale warning after the attach.
- **Owner:** B4 `views/pg1_general.js`; B6 fixture `intake_analysis/RDDC-24817.json` (DC SA claim).

### QA-C-19 · Minor · CR Compliance rows read as contradictions
- **Shot:** `demo1366_28_cr_compliance.png`.
- **Actual:**
  - "CR-02 CRQ approval is Approved by 2 business days before the CRQ start · **Pass** · CRQ approval is Draft."
  - "CR-04 Technical validation evidence is attached and not failed · **Pass** · Technical validation is Not Started", while the evidence cell beside it says "Not attached".
- **Expected:** Show "Not due yet" (neutral) for rules whose deadline has not arrived. Do not show Pass.
- **Owner:** B2 `app/engines/compliance.py` (result value); B4 preview in `ui/previews.js`.

### QA-C-20 · Minor · "+ Add change request" on an initiative without a plan fails silently
- **Evidence:** `qa_c_sweep.json` events (sweep `#/initiative/8/pg4`, RDDC-24790, stage Grooming).
- **Actual:** `POST /api/initiatives/8/change-requests` → **422**, a console error, and the toast "⚠ Some fields need attention." No field is highlighted and nothing tells the user what is missing.
- **Expected:** Either create a blank CRQ (as it does for the hero) or explain the cause, e.g. "Add a target release first".
- **Owner:** B4 `views/pg4_governance.js`; B1 `app/api/governance.py` (validation message).

### QA-C-21 · Minor · Portfolio "Export Demo View · RDDC-24790" on the home screen
- **Shot:** `demo1366_01_portfolio_home.png` (top-right).
- **Actual:** At step 1 the button exports whatever initiative was created last, here "Digital Channels Observability Uplift". This is a known B5 gap, but it is confusing on the opening screen.
- **Expected:** Hide the button at portfolio scope, or label it "Export Demo View (choose initiative…)".
- **Owner:** B5 `views/portfolio.js`.

### QA-C-22 · Minor · Step 1 KPI strip doesn't match the script
- **Shot:** `demo1366_01_portfolio_home.png`.
- **Actual:** Active 7 · Red 1 · **Amber 1** · CRQs this week 2 · Over-allocated 2. PO §1 says Amber 3. This is known to B5, and the data comes from seed and engines.
- **Expected:** Change the seed so the KPI reads Amber 3, or change the presenter script to match.
- **Owner:** B1 seed / B2 health. Screen owner B5.

### QA-C-23 · Polish · "PRN burndown" chart is a burn-up and is mostly empty
- **Shots:** `demo1366_18_pg3_health.png`, `demo1366_29_pg5.png`.
- **Actual:** Charged 0 h gives a flat solid line at 0. "Forecast" is a dotted line *rising* to 859 h. The Funded dashed line is at 1,100 h but the axis tops out at "1,210 h". This doesn't match UX §4.4 (remaining line burning down to 0).
- **Owner:** B5 `charts/burndown.js`.

### QA-C-24 · Polish · Intake & Grooming session card buttons clipped
- **Shot:** `s1366_04_sweep_intake.png`.
- **Actual:** In the Tue 20 Oct card, the hero row's "Confirm · Move to next" is cut to "Mov".
- **Owner:** B5 `views/intake.js`.

### QA-C-25 · Polish · Resources page tables clipped and uneven
- **Shot:** `s1366_05_sweep_resources.png`.
- **Actual:** The inventory shows Nov–Jun only (1,016 px visible of 1,468 px), and row heights vary (32–60 px) for no visible reason. The skill matrix is 1,016 px visible of 3,746 px and the last header reads "Ever…".
- **Owner:** B5 `views/resources.js`.

### QA-C-26 · Polish · ID columns wrap
- **Shots:** `s1366_02_sweep_search.png` ("RDDC- / 24817"), `s1366_06_sweep_risks.png` ("RSK- / 001").
- **Expected:** Use `white-space: nowrap` on ID columns.
- **Owner:** B4 `views/search.js`; B5 `views/risks.js`.

### QA-C-27 · Polish · "17 bd" abbreviation
- **Shot:** `s1366_07_sweep_changes.png` (Governance Reviews "Waiting" column).
- **Actual:** "bd" is not business copy.
- **Expected:** "17 business days".
- **Owner:** B5 `views/changes.js`.

### QA-C-28 · Polish · Rebalance card squeezed into the Project Health tile
- **Shot:** `d1366_21_20_suggest_fix_card.png`.
- **Actual:** At 1366 the Suggest fix card renders inside the half-width health box. The text wraps every 5 words, and the PRN box beside it gains about 400 px of white space. This is the "health is calculated, not typed" moment of the demo.
- **Expected:** Render the card full width below the two tiles.
- **Owner:** B4 `views/pg3_resources.js`.

### QA-C-29 · Polish · Health shows Schedule Amber before any plan exists
- **Shots:** `demo1366_10_persona_requestor_approve_l2.png` (header Amber right after L2 approval) and `demo1366_12_plan_card.png` (Pg 2 key strip: Float "—", Schedule **Amber**).
- **Actual:** An Amber with no dates behind it invites "why?" before step 7.
- **Expected:** Show "Not scored yet" until a plan exists.
- **Owner:** B2 `app/engines/health.py`. Screen owner B4 `pg2_plan.js`.

---

## Sweep results (all routes, all tabs, both viewports)

- **Routes and tabs:** all 11 rail routes, all 8 initiative tabs (pg1–pg5, risks, artifacts, print) for the hero and for RDDC-24790, unknown initiative, unknown route and search miss. Screenshots are `s1366_*` and `s1920_*`.
- **Console and network (demo walks, both viewports):**

  | Kind | Count |
  |---|---|
  | `console.error` | 0 |
  | `pageerror` | 0 |
  | Failed requests | 0 |
  | HTTP ≥ 400 | 0 |

  In the sweep there were two:
  - 422 on `+ Add change request` for RDDC-24790 (QA-C-20).
  - 404 `GET /api/initiatives/99999`. This is expected; it renders the friendly panel "This initiative no longer exists…".
- **Buttons that do nothing:** 0 real ones.
  - The remaining hits are tabs that were already active ("Pg 1 General Details" on pg1, "Phase" in print view).
  - Sort headers, exports (21 downloads, all named and opening) and AI buttons all react.
  - Coverage note: 29 buttons were skipped where a re-render changed button order. The script refuses to click a button whose label doesn't match.
- **AI cards:** 32 opened (exec summary, auto-slot, skill matrix, nudges, intake analysis, change summary, L2, 12× Recommended Developer, rebalance, resources, risks). All 32 dismissed with Discard.
  - The Realistic pass showed thinking steps ○ → spinner → ✓ in 2.5 s (`realistic_01_thinking_steps_exec_summary.png`). The Stop button appears and works.
- **Stuck spinners:** none after 25 s.
- **Bad text:** no undefined, NaN, null, [object Object] or Invalid Date on any screen.
- **Horizontal page overflow:** none at 1366 or 1920. Inner table clipping is listed above (QA-C-05 to -09 and -25).
- **Empty states:** a new bare initiative (RDDC-24818) was checked on every tab. The copy matches UX §6 word for word:
  - Pg 2: "No project plan yet…"
  - Gantt: "The Gantt view appears once…"
  - Pg 3: "No one is assigned yet…"
  - Pg 4: "No change request logged…"
  - Risks: "No risks recorded…"
  - Artifacts: "No documents yet…"
  - Health: "Not scored yet. Health is scored from the Planning stage onward…"
  - Global search miss: 'No initiatives match "xyz".'
  - Unknown route: "Page not found".

## Copy check (UX §6)

- **Dates and hours:** dates render "19 Oct 2026" and "Tue 20 Oct, 10:00" everywhere except native inputs (QA-C-12). Hours render "1,000 h" and "137.5 h"; no "hrs" anywhere.
- **Sheet1 enums are verbatim:**
  - Not Started / Scheduled / In progress / Implemented
  - Draft / Tentative Go / Tentative No Go
  - Backlog / In progress / Completed
  - Pending / Approved / Not required
  - Low / Medium / High
- **Jargon:** only "test-agent" (QA-C-17) and "bd" (QA-C-27). Hits on "schema" and "token" are domain words in SA content and are fine.
- **Sentence case:** OK. Workbook labels keep Excel casing ("CRQ/RCSR #", "SA document", "Description of Change").
- **Excel parity:**
  - Pg 1 two-column label/value blocks match the Excel Demo View Pg 1, including the duplicated DC SA row.
  - The Pg 4 left/right blocks and the yellow evidence and backout attachment cells match the Excel Demo View Pg 4.
  - The Pg 5 Health / Resource Capacity / Project Gantt tiles match the deck MVP 1 dashboard.
  - The rail matches the four Excel buttons word for word.

## Timezones

America/Toronto and Pacific/Auckland at 1366 gave **identical** date strings on these routes:
- `#/portfolio`
- hero `pg1`, `pg2`, `pg4`
- `#/intake`, `#/changes`, `#/outbox`

The 1366-Toronto and 1920-Auckland demo walks also show the same key dates: Wed 17 Feb 2027, Wed 10 Feb 2027, Sat 20 Feb 2027, Tue 20 Oct 10:00, Wed 21 Oct, and Today 19 Oct.

## What held (for the record)

- **Steps 2–3:** RDDC-24817 auto-numbered, grooming Tue 20 Oct 10:00.
- **Step 4:** SA 88% "Missing: Backout plan".
- **Step 5:** 4 components 280/120/120/40 h; L2 1,000 h · L · 750–1,250 h with the exact breakdown 560/56/196/56/868/130.
- **Step 6:** persona send/approve, stage Estimation → Planning, Tentative → Confirmed.
- **Step 7:** 14 steps; Readiness Wed 17 Feb, QA Wed 10 Feb, Prod Sat 20 Feb (DC-2702), 560 h, float 2 business days Amber.
- **Step 8:** Gantt with today line, freeze band and train markers; the edit propagates live to Red / 24 Feb.
- **Steps 9–10:** Sana 128% Nov, Suggest fix → Mateo, 96% / 74%, Resources Green.
- **Step 11:** 5 risks added to the register.
- **Step 12:** CRQ0001048817 "Sat 20 Feb 2027 02:00–06:00 · STO Tentative Go", compliance flag "Backout plan not attached".
- **Step 13:** portfolio row for RDDC-24817.
- **Step 14:** assistant cites only real RDDCs, has "Copy to email", and says "Felix Hartwell … 58% booked" in January.
- **Exports:** portfolio xlsx/csv and Demo View xlsx with Pg 1 boxed sheet and Sheet1 lookups.
- **Settings:** Fast-forward is idempotent ("Already created…"). Reset confirm copy matches UX §6.
