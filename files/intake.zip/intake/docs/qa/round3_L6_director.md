# Round 3 · L6 fresh-eyes re-rehearsal · Director of Digital Channels Delivery

**Reviewer:** the same sceptical DC Delivery Director as round 2. I read only `docs/qa/round2_decisions.md` and `docs/DEMO_SCRIPT.md`. I did not look at any code, tests or planning documents.

**Setup:**
- Fresh instance: `BMO_DB_PATH=/tmp/director2.db`, port 5098, data reset first, demo date Mon 19 Oct 2026.
- Playwright Chromium at 1440×900, with a spot-check at 1366×768.
- I followed the new 17-step script from start to finish.
- Screenshots are in `/tmp/director2_shots/` (63 files). I opened every one cited below.

**Stability and speed:**
- No console errors and no page errors anywhere.
- Pages load in 0.8–1.7 s. AI cards return in 2–3.5 s. Assistant answers take about 3–4 s. Workbooks download in under 0.5 s.
- At 1366 px, no page scrolls sideways: Portfolio and Pg 1–Pg 5 are all exactly 1366 px wide (`/tmp/director2_shots/40_1366_portfolio.png`, `/tmp/director2_shots/42_1366_pg2.png`, `/tmp/director2_shots/46_1366_assistant.png`).

**Bottom line:** this is now a demo I would let the team run in front of my VP. All five round-2 Must-fix items are fixed. What's left is a set of realism and wording issues that a sharp PM in the room could catch, but none of them breaks the story.

---

## Scores (1–5)

| | Dimension | R2 | **R3** | One-line justification |
|---|---|---|---|---|
| a | Clarity of "one intake in → health + capacity + Gantt" | 4 | **5** | Every toast names the real stage change (Grooming → Solution → Estimation → Planning). The stepper advances honestly. The WBS-210 slip turns the plan Red with "Misses DC-2702", and "Undo last change" brings it back. The Assistant what-if now tells the same story in words. |
| b | Fidelity to the Excel Demo View idea | 4 | **4** | The "Initiative Demo View workbook…" export has Pg 1–4 boxes, Gantt, Capacity, Risk Register and a Lists sheet, with % formatting and roll-ups fixed. The in-initiative "Pg 5 Portfolio View" tab is still not called "Demo View". The workbook's "Action required by" cell is blank. |
| c | Realism of data, names, dates, numbers | 4 | **4** | Fixed: CRQ numbers are a consistent 15 characters and don't copy the RDDC, STO shows "Not requested", and the labels are right. New problems: the item is "Groomed in the Tue 20 Oct session" when today is Mon 19 Oct. April 2027 is a one-month 0% hole between 45–65% in March and a flat 25/30/35% in May–Oct. |
| d | Correct use of our jargon | 4 | **4** | DLR is now present. Compliance uses "Not due yet · due Wed 17 Feb (T-2 BD)". The stage flow is real. Two problems remain: DLR is expanded as "Delivery Lead Review", which needs confirming against our process, and Pg 4 shows "STO readiness: Tentative" right beside "STO Approval: Not requested". |
| e | Believability & usefulness of AI outputs | 3 | **4** | The scripted cards are still excellent, and the Assistant now gets PRN, what-if and CRQ-readiness questions right. Three things hold it below 5: Intake Analysis on the script path now comes from the rules engine and reads like keyword matching ("Mentions 'cdc'"); 3 of my 9 questions got a garbled or partial answer; and the burn rate quoted differs from the widget. |
| f | Absence of fluff / clutter | 3 | **4** | The duplicate DC SA and Implementation Status fields are gone. Exports have clear names. The WBS table hides extra columns behind "More columns". Still left: PM and DC PM as two rows, an "AI-generated" badge on a deterministic rules check, and two Close buttons in the export dialog. |
| g | Polish & reliability | 3 | **4** | The persona hint is fixed, the step filter is honoured, the Undo button stays on screen and nothing errors. Still left: Undo history is lost on page reload, the Pg 1 "Action required by" line disappears later in the flow, and the STO pill contradicts the field next to it. |

**Must-fix count: 0.** Every score is now 4 or higher.

---

## Findings status (all 31 round-2 findings)

| # | R2 finding (short) | Status | Evidence / note |
|---|---|---|---|
| 1 | CR-12/13 claimed no production date | **Fixed** | `28_cr_compliance.png`: "Window matches WBS-700 on Sat 20 Feb 2027"; CR-13 Pass |
| 2 | "Pass" on Draft / Not Started items | **Fixed** | `28_cr_compliance.png`: CR-01/02 and CR-04/05 show "Not due yet · Due by …"; score 89% (8 of 9 due checks) |
| 3 | Persona hint went stale | **Fixed** | `12_requestor.png`: "you are acting as Requestor" updates live |
| 4 | Assistant gave confidently wrong answers | **Fixed** (new follow-ups below) | `31_assistant_q4/q5/q6.png`: correct what-if (readiness 3 Mar, misses DC-2702 by 8 BD), PRN-71840 156 h left and Oct 2026 exhaustion, CRQ STO readiness. See N5 and N6 |
| 5 | Intake Analysis asked for the PRN | **Fixed** | `04_intake_analysis.png`: "Confirm PRN-77310 funded hours (1,100 h) cover the work" |
| 6 | L2 approved before grooming | **Partly** | The flow is now Grooming → Solution → Estimation → Planning (`07_after_groomed.png`), but it says "groomed" in tomorrow's session. See N2 |
| 7 | Management attention contradicted itself | **Fixed** | `29_portfolio_after.png` and Pg 3 both list "Readiness float 2 business days to DC-2702" |
| 8 | Portfolio Red vs exec summary Amber | **Fixed** | Tile shows "Worst: Red"; Write Executive Summary pill is Red (`37_exec_summary.png`) |
| 9 | Utilisation dropped to 0 after April | **Partly** | May–Oct now 20–40%, but April is still 0–4% and May–Oct is identical every month (`47_resources_full.png`, Portfolio heatmap "Apr" column). See N1 |
| 10 | Comparable facts disagreed | **Partly** | One similarity score per pair now (24688 17%, 24310 14%), but the card still reads "RDDC-24688 · **actual** 650 h · … not yet delivered" (`10_l2_how.png`) |
| 11 | Plan / L2 / PRN didn't reconcile | **Fixed** | `14_plan_accepted.png`: "Plan 859 h vs L2 1,000 h — contingency 130 h held (+2 h rounding); Architecture/SA +14 · QA −22 · PM −1". The arithmetic checks out |
| 12 | Step filter ignored; over-capacity person ranked top | **Fixed** | `19_suggest_wbs210.png` shows WBS-210 only. `20_suggest_wbs100.png` ranks Mateo first and labels Sana "Best fit · over capacity". Title reads "Recommended resource". See N8 for leftovers |
| 13 | "Payments" used for an accounts API | **Fixed** | Labels are accounts, open-banking, partner-api, us-p&c; the fix card says "has not worked on US P&C account APIs" |
| 14 | CRQ draft looked fabricated | **Fixed** | `26_crq_draft_review.png`: review card, CRQ000001052216, STO "Not requested", CIs wrap. See N4 for the new pill contradiction |
| 15 | Script and UI labels didn't match | **Fixed** (one nit) | "Predict risks" button; Red pill opens a modal with Suggest fix (`21_click_red.png`); fix button reads "Accept". The risk card's button still says "Add selected to Risk Register" while the script says "Accept" |
| 16 | AI Activity oversold results | **Fixed** (nit) | `33_ai_activity.png`: "5 of 19 (26%)", Saved only on accepted rows, "Not reviewed" status, rules-engine rows show "Rules". The CR Compliance row still says "prepared response". See N10 |
| 17 | Excel export polish | **Fixed** (new nit) | Util columns formatted `0%`, "Lists" sheet, WBS-200 = 560 h, hero comment filled. Demo View "Action required by" cell is empty (N3) |
| 18 | Duplicate and confusing fields | **Partly** | DC SA and Implementation Status duplicates removed; role dropdowns filtered. **PM and DC PM** are still two rows with the same person (`38_pg1_final.png`) |
| 19 | No DLR anywhere | **Fixed** (confirm meaning) | "Send L2 to DLR", "DLR (Delivery Lead Review): shared 19 Oct 2026 · Arlo Kingsley" (`12_requestor.png`). The team should confirm DLR's expansion against our gating process |
| 20 | Weekly exec summary left out RDDC-24601 | **Fixed** | `31_assistant_q2.png` lists RDDC-24601 Amber |
| 21 | Three "EAPI" teams | **Fixed** (nit) | Third team now "EAPI Tech Lead". Pg 3 shows "EAPI Tech Lead · EAPI Tech Lead", and the Resource inventory still says team "EAPI" |
| 22 | Overall-health rule unexplained | **Partly** | The tile tooltip says "Overall health · see Pg 3 for the five dimensions" but doesn't state the rule |
| 23 | KPI tiles not clickable | **Fixed** | CRQs this week → Change Mgmt; Over-allocated → Resources |
| 24 | Portfolio Gantt showed only RDDC numbers | **Fixed** | Names shown (`01_portfolio_full.png`) |
| 25 | WBS table cut off | **Fixed** | "More columns" toggle (`14_plan_accepted.png`) |
| 26 | Stepper ticked everything early | **Fixed** | Stepper advances step by step; "Automated Views" stays open (`27_crq_accepted.png`) |
| 27 | Pg 5 should be called "Demo View" | **Won't fix – acceptable** | Still "Pg 5 Portfolio View"; the script doesn't depend on it |
| 28 | "Accept labels" was unclear | **Fixed** | "Apply suggested labels" |
| 29 | Undo only in the toast | **Partly** | A persistent "Undo last change" button works after the toast is dismissed. After a page reload it is disabled ("No date change to undo") |
| 30 | Labelling nits | **Fixed** | Heatmap "Q4 FY26"; Change Mgmt shows "Week of Mon 19 Oct … (this week and next)" |
| 31 | PRN-77310 in dropdown before intake | **Fixed / acceptable** | Shown as "PRN-77310 · US API Enhancement (not yet linked)" |

**Tally:** 22 Fixed (including the acceptable and nit cases), 7 Partly, 1 Won't fix – acceptable, 1 Fixed with the DLR meaning to confirm. None are "Not fixed".

---

## New findings (round 3)

### Must-fix before demo
None.

### Should-fix

**N1. The April 2027 capacity hole now looks worse than the old cliff.**
Screenshots: `/tmp/director2_shots/47_resources_full.png` and the Portfolio heatmap "Apr" column in `/tmp/director2_shots/29_portfolio_after_full.png`.
Everyone is at 45–65% in March, 0–4% in April, then exactly 25% / 30% / 35% for each of May–Oct. Anyone looking at the Resources page will see seeded data.
*Suggestion:* extend the BAU/run allocation to April as well (20–40%). Vary it by ±5% per month so it doesn't look stamped.

**N2. The item is "groomed" in a session that hasn't happened yet.**
Screenshots: `/tmp/director2_shots/07_after_groomed.png`, `/tmp/director2_shots/34_grooming.png`.
On Mon 19 Oct, clicking "Mark as groomed" gives the toast "Groomed in the Tue 20 Oct session". Intake & Grooming then shows RDDC-24817 as "Discussed" in tomorrow's session.
*Suggestion:* record it as "Groomed · ad-hoc walk-through Mon 19 Oct" (and free the Tue slot). Alternatively, let "Mark as groomed" open a session picker that defaults to today.

**N3. "Action required by" appears on Pg 1, then disappears, and is blank in the workbook.**
Screenshots: `/tmp/director2_shots/05_sa_attached.png` (shown) and `/tmp/director2_shots/38_pg1_final.png` (gone). The Demo View workbook cell G15 "Action required by" is also empty.
The backout plan is still missing at the end of the flow: Pg 4 flags it, and CR-11 fails on it.
*Suggestion:* keep the action visible until the SA is re-uploaded with the section. Write the same text into the workbook.

**N4. Pg 4 shows "STO readiness: Tentative" next to "STO Approval: Not requested".**
Screenshot: `/tmp/director2_shots/28_cr_compliance.png`. This is on the script path at step 13.
*Suggestion:* show "STO readiness: Not requested · auto-suggest from T-5 BD (Mon 15 Feb)".

**N5. Assistant answers are still uneven on my own questions.**
- Q6 "Which CRQs are not ready for STO go/no-go this week?" is correct in substance, but the text is mangled: "tentative — still to come: Due by Wed 21 Oct 2026 (T-2 business days).; Due by Sun 25 Oct 2026 (24 h after implementation)." It never says *what* is due (STO Go, CRQ approval). Screenshot: `/tmp/director2_shots/31_assistant_q6.png`.
- Q7 "Which PRNs are forecast to overrun?" got "Which PRN? Give the PRN number…". The answer (PRN-71840, +981.5 h) is on the same page.
- Q8 "How many initiatives **and hours** are landing on DC-2702?" lists 2 initiatives but gives no hours.
- Q9 "Who is over-allocated in December **and what should we do about it?**" gives a correct list (Felix 120%, Hana 104% with a per-RDDC breakdown) but no recommendation. The Resource Fix engine could supply one.

*Suggestion:* render rule names in readiness answers ("STO Go due Wed 21 Oct; CRQ approval due Wed 21 Oct"). Add a portfolio-wide PRN overrun intent. Add hours to train answers. Have the over-allocation intent call Suggest fix.

**N6. Two different burn rates for PRN-71840.**
The Assistant says "about 361.5 h a month over the last three months" (`/tmp/director2_shots/31_assistant_q5.png`). The PRN Burndown widget on the same page says "Burn 202.8 h/month".
These are probably different windows, but the widget doesn't say which.
*Suggestion:* label the widget window ("6-month average") or use the same window in both.

**N7. On the script path, Intake Analysis now comes from the rules engine and reads like keyword matching.**
Screenshot: `/tmp/director2_shots/04_intake_analysis.png`.
The summary reads "US API Enhancement scores 80% for grooming readiness (ready for grooming)". The component reasons are "Mentions '/v2', 'api'", "Mentions 'consent'" and "Mentions 'cdc'". Clicking Analyse intake again gives the same rules-engine output.
In round 2 this card was the richer prepared response. It is the first AI card the room sees, so it sets the tone.
*Suggestion:* make sure the prepared response matches the DCI-3391 prefill (the PRN line probably changed the fingerprint). Alternatively, give the rules engine human reasons such as "two new versioned APIs → API Platform".

**N8. Leftover text on the Suggest Resources cards.**
Screenshots: `/tmp/director2_shots/19_suggest_wbs210.png`, `/tmp/director2_shots/20_suggest_wbs100.png`.
- The WBS-210 card's "Check before accepting" and Sources talk about WBS-100, Sana, Mateo and Felix.
- The WBS-100 card recommends Mateo, then says "WBS-100 is not changed by Accept… use Suggest fix". So "Assign recommended" won't assign the person it recommends.
- "Best fit · over capacity" is shown on the *lower* match (Devon 41% vs Tobias 92%; Sana 74% vs Mateo 78%).

*Suggestion:* scope the checks and sources to the selected step. Let "Assign recommended" assign. Rename the badge to "Over capacity".

### Nice

**N9. The Assistant offers a stale follow-up chip, "Why is Resources red?", after Resources has turned Green** (`/tmp/director2_shots/46_1366_assistant.png`).

**N10. The CR Compliance card still carries "AI-generated — review before use · Simulated AI · prepared response"** even though it is a deterministic rules check. In AI Activity the same row shows mode "prepared response" with confidence "Rules". Badge it "Rules check".

**N11. Export naming and dialog.** The initiative header button still says "Export to Excel" while Portfolio says "Initiative Demo View workbook…", although both download the same file. The export dialog has two "Close" buttons (`/tmp/director2_shots/32_demo_view_dialog.png`).

**N12. "EAPI Tech Lead · EAPI Tech Lead" role/team repeat on Pg 3.** The Resource inventory still lists Devon's team as "EAPI".

**N13. Exec summary quality differs by entry point.** The Assistant's "Draft this week's exec summary" is now rules-engine and thinner ("4 changes going to production soon") than the Write Executive Summary card. Point the Assistant at the same content.

---

## Assistant questions (9)

| # | Question | Result | Screenshot |
|---|---|---|---|
| 1 | Which initiatives are at risk for the Feb release and why? | Good: 24817 Amber (2 BD float, WBS-210 through the holidays), 24688 Green, freeze caveat | `31_assistant_q1.png` |
| 2 | Draft this week's exec summary | OK: includes 24412, 24601, 24817 and dated Asks; thinner than the button version (N13) | `31_assistant_q2.png` |
| 3 | Who has CIAM capacity in January? | Good: Felix 58%, Mira 51% with reasoning | `31_assistant_q3.png` |
| 4 | What if CIAM approval slips two weeks? (R2 own question) | **Now correct.** WBS-230 starts 2 Dec, readiness 3 Mar, misses DC-2702 by 8 BD, next train DC-2703; I checked the arithmetic | `31_assistant_q4.png` |
| 5 | Hours left on PRN-71840 and funding run-out? (R2 own) | **Now correct.** 156 h left, 92% burned, +981.5 h, Oct 2026; burn rate differs from the widget (N6) | `31_assistant_q5.png` |
| 6 | Which CRQs are not ready for STO go/no-go this week? (R2 own) | Right CRQs, mangled wording (N5) | `31_assistant_q6.png` |
| 7 | **New:** Which PRNs are forecast to overrun? | Asked back "Which PRN?" instead of answering (N5) | `31_assistant_q7.png` |
| 8 | **New:** How many initiatives and hours are landing on DC-2702? | 2 initiatives with float, but no hours (N5) | `31_assistant_q8.png` |
| 9 | **New:** Who is over-allocated in December and what should we do? | Correct list with breakdown, no recommendation (N5) | `31_assistant_q9.png` |

None of the nine answers was confidently off-topic, which was the round-2 trust problem.

---

## Script walk-through notes (new script)

Every step behaved as the script says, with these exceptions:
- **Step 3:** the Intake Analysis card is rules-engine (N7).
- **Step 5:** the grooming date is in the future (N2).
- **Step 12:** the risk button text is "Add selected to Risk Register", not "Accept".
- **Step 13:** the STO pill contradicts the field (N4).

Key numbers matched the script exactly:
- 88% SA completeness; Action required by Sana Whitfield, Wed 21 Oct.
- L2 1,000 h · L · 750–1,250 h.
- QA Wed 10 Feb, Readiness Wed 17 Feb, Production Sat 20 Feb on DC-2702, 2 BD float.
- After the WBS-210 slip: Readiness 24 Feb, "Misses DC-2702", Red, then Undo back to Amber.
- Sana 128% → 96% and Mateo 42% → 74% after the fix.
- CRQ000001052216; compliance shows 1 flag and 4 "Not due yet".

---

## Top 5 things that impressed me (protect these)

1. **The Assistant what-if** (`31_assistant_q4.png`). It slips CIAM by 10 BD, shows readiness moving to 3 Mar, says DC-2702 is missed by 8 BD, lists the steps that move and states "plan unchanged". The business-day arithmetic is right. This is the question every exec asks.
2. **Plan-vs-L2 reconciliation line** (`14_plan_accepted.png`). One sentence explains the 141 h gap by phase, and the numbers add up. It heads off the first finance question.
3. **"Not due yet" compliance** (`28_cr_compliance.png`). Due dates are explicit (T-2 BD, 24 h after implementation), the score is honest (8 of 9), and the only real flag is the backout plan. A CMS lead would accept this.
4. **Numbers stay consistent across screens.** Tobias 22% → 88%, Sana 128% → 96%, Felix 120% (96 h of 80 h), Hana 104% (145.5 of 140 h) and PRN-71840 at 92% agree across Portfolio, Pg 3, AI cards, the Assistant and both workbooks.
5. **The honest stage flow, persona switching and DLR step** (`07_after_groomed.png`, `12_requestor.png`). Every transition toast states the real from → to, and the approval panel says who is acting. The process story now holds up in front of PMs.

Also keep: the slip and Undo cascade, the critical-path summary line under the Gantt, clickable KPI tiles, Gantt rows with names, and no console errors at 1440 or 1366.
