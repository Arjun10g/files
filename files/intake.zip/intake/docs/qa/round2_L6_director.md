# Round 2 · L6 fresh-eyes rehearsal · Director of Digital Channels Delivery

Reviewer: a sceptical DC Delivery Director (manages PMs, SAs, Dev Leads). I had not seen any code, plans or design notes before this run.
Run: own instance (`BMO_DB_PATH=/tmp/director.db`, port 5097), reset seed, Playwright Chromium 1440×900, demo date Mon 19 Oct 2026.
I followed the presenter's script steps 1–15 and then poked around the app the way a curious exec would. Screenshots are in `/tmp/director_shots/` (79 files) and every one cited below was looked at.
No console errors or page errors at any point. Navigation took about 1.1–1.5 s. AI cards took 2–3.5 s ("Realistic" speed). Excel exports took about 0.3 s.

---

## Scores (1–5)

| | Dimension | Score | One-line justification |
|---|---|---|---|
| a | Clarity of "one intake in → health + capacity + Gantt" | **4** | It lands. Accepting the plan turns the header Amber, and the Pg 3 heatmap, the Portfolio tiles and the Gantt all pick up RDDC-24817. The WBS-210 +5-day slip flips it to Red / "Misses DC-2702", and Undo puts it back. The story gets muddied by the order of events (L2 is approved before the grooming session has happened) and by a stepper that ticks all 5 steps as soon as the plan is accepted. |
| b | Fidelity to the Excel Demo View idea | **4** | Pg 1–Pg 5 tabs, "(populated from SA doc attachment)" captions and yellow AI cells feel like the workbook brought to life. "Export Demo View…" gives a Demo View sheet laid out as Pg 1–4 plus Gantt, Capacity and Risk sheets. The in-initiative "Pg 5 Portfolio View" tab is the real Demo View screen, but nobody would find it on their own. |
| c | Realism of data, names, dates, numbers | **4** | Very good overall. Family Day, Remembrance Day, Boxing Day observed on 28 Dec, the 14 Dec–8 Jan freeze, Sat 02:00–06:00 windows, the BMO Nov–Oct FY, and figures that reconcile across screens (Tobias 22%→88%, Sana 128%→96%). Points lost for allocations dropping to 0% after Apr 2027 everywhere, CRQ numbers of different lengths and one that copies the RDDC suffix, and "payments" labels on an accounts/transactions API. |
| d | Correct use of our jargon | **4** | RDDC, L2 (T-shirt, range, approval), SA completeness, CRQ/RCSR, STO Tentative Go/No Go, PRN burndown, DC-27xx release trains and FY27 quarters are all used correctly. DLR is missing entirely: there is no Design Level Review gate anywhere. And a CR compliance check that marks "Pass" on a Draft CRQ is something my CMS lead would laugh at. |
| e | Believability & usefulness of AI outputs | **3** | The scripted cards are excellent: Change Summary with SA § citations, an L2 "How we got this" where the arithmetic works (868+130→1,000), a 14-step plan with correct business-day maths, a resource fix with exact before/after hours, and risks that know about the fix. Free-form Assistant answered 3 of my 6 questions wrongly or not at all, and once at "High 90%" confidence. Intake Analysis asks for a PRN that is already on the form. CR Compliance says there is no production date when the plan has one. |
| f | Absence of fluff / clutter | **3** | Duplicate fields: PM/DC PM and DC SA twice on Pg 1, Implementation Status twice on Pg 4. There are two export buttons, a confidence badge plus a "Simulated AI · prepared response" chip on every card, and "PG 1/PG 5" eyebrows. The Portfolio page is 3,500 px long. The content is useful but dense. |
| g | Polish & reliability | **3** | Fast and stable, Undo works, and the Fast-forward recovery in Settings is a good idea. But the persona hint goes stale on the exact step where we demo persona switching. Suggest Resources ignores its "for WBS-210" filter. Compliance contradicts Pg 2. The Assistant misroutes questions. |

**Must-fix count: 5** (findings 1–5).

---

## Findings

### Must-fix before demo

**1. CR Compliance says there is no production date or target release, which contradicts Pg 2 and the CRQ itself.**
Screenshot: `/tmp/director_shots/36_cr_compliance.png` (scroll: rows CR-12 / CR-13; full text captured in the run log).
CR-12 reads "Pass · No production date in the plan yet." CR-13 reads "Pass · Target release or production date not set." Meanwhile Pg 2 shows Production Date Sat 20 Feb 2027 (WBS-700), the CRQ window is Sat 20 Feb 02:00–06:00, and the target is DC-2702. A CMS lead would stop trusting the whole score (92%) at that point.
*Suggestion:* compute CR-12/CR-13 from the saved plan (WBS-700 date, target release) and show "Pass · window matches WBS-700 on Sat 20 Feb 2027".

**2. CR Compliance marks things that are not done as "Pass".**
Screenshot: `/tmp/director_shots/36_cr_compliance.png`.
CR-01 "STO approval is Go…" shows Pass with the detail "STO approval is Tentative Go". CR-02 "CRQ approval is Approved…" shows Pass with "CRQ approval is Draft". CR-04 and CR-05 say evidence is attached and show Pass with "Not Started".
*Suggestion:* add a third result, **"Not due yet" (grey)**, with its due date (e.g. "due by Wed 17 Feb 2027, T-2 BD"). Count only actual passes and fails in the score.

**3. The persona hint does not update when you switch persona, on the exact step where the script demos persona switching.**
Screenshots: `/tmp/director_shots/17_requestor.png`, `/tmp/director_shots/55_persona_stale_check.png`.
With the top bar set to **Requestor**, the L2 panel says "Usually approved by the Requestor · you are acting as **Dev Lead**". Reproduced on RDDC-24702: switching DC PM → Requestor → DC PM leaves "you are acting as DC PM" unchanged until the page reloads.
*Suggestion:* re-render the L2 action row (and any "you are acting as" text) on persona change. Add a test.

**4. The Assistant gives confidently wrong answers to reasonable exec questions.**
Screenshots: `/tmp/director_shots/40_assistant_q4.png`, `/tmp/director_shots/40_assistant_q5.png`, `/tmp/director_shots/40_assistant_q6.png`.
- "How many hours are left on PRN-71840 and when does funding run out?" was answered with "9 initiatives by stage: Grooming 1…". AI Activity logs this at High 90%. The right answer (156 h left, funding exhausted Oct 2026, 982 h overrun) is already on the PRN burndown.
- "What happens to RDDC-24817 if CIAM approval slips two weeks?" was answered with a list of pending approvals. There is no what-if, even though the tool knows WBS-230 starts 18 Nov and has 2 BD of float.
- "Which CRQs are not ready for STO go/no-go this week?" got the generic fallback "I can answer questions about…".

The three scripted questions were good. But an exec will always ask one question of their own, and the PRN miss is a trust-killer.
*Suggestion:* add intents for PRN (burn, remaining, exhaustion date), CRQ/STO readiness and a simple slip what-if (shift a WBS by N BD and report readiness, float and train). If no intent matches, say "I can't answer that yet". Never fall back to an unrelated rule at High confidence.

**5. Intake Analysis contradicts the form in front of the exec.**
Screenshots: `/tmp/director_shots/07_intake_analysis_result.png`, `/tmp/director_shots/08_intake_details.png`.
The summary says "Still open: … and the PRN". Missing information lists "PRN for funding". One clarifying question is "Which PRN funds this work… · for DC PM". Yet PRN-77310 is filled on the form directly below.
*Suggestion:* drop the PRN items when the PRN is present, or change them to "Confirm PRN-77310 funded hours (1,100 h) cover the L2".

### Should-fix

**6. The process runs in the wrong order: L2 is approved and the stage is Planning before grooming has happened.**
Screenshots: `/tmp/director_shots/18_l2_approved.png`, `/tmp/director_shots/45_grooming.png`.
On 19 Oct the L2 is approved ("stage moved Estimation → Planning") while the grooming session is still "Tue 20 Oct · Proposed". Intake & Grooming also still shows the item as Proposed. The toast says "Estimation → Planning" although the screen showed "Grooming" a moment earlier. Any PM in the room will notice.
*Suggestion:* either have the presenter click "Confirm" and mark it groomed first, or add a "Groomed (walk-through)" step that moves Grooming → Solution → Estimation. At the very least, set the grooming slot to "Groomed" when the L2 is sent.

**7. Management Attention contradicts itself between screens.**
Screenshots: `/tmp/director_shots/30_fix_applied.png`, `/tmp/director_shots/37_portfolio_after.png`.
After the fix, Pg 3 says "Nothing needs management attention." The Portfolio Management Attention list shows "Amber · RDDC-24817 US API Enhancement — Schedule Amber".
*Suggestion:* use one rule. Either both list Schedule Amber at ≤2 BD float, or neither does.

**8. Portfolio overall health is "Red" but the Executive Summary says "Amber".**
Screenshots: `/tmp/director_shots/37_portfolio_after.png` (the Red pill on the Project Health tile) and `/tmp/director_shots/54_write_exec_summary.png` (Amber).
*Suggestion:* derive the summary's overall RAG from the same calculation, or label the tile pill "Worst: Red".

**9. Utilisation drops to zero after April 2027 everywhere.**
Screenshots: `/tmp/director_shots/26_pg3_full.png` (May–Jul and Aug–Oct allocation are 0 h for everyone), `/tmp/director_shots/37_portfolio_after_full.png` (heatmap Apr 0–4%). The same cliff appears in the Capacity sheet of both workbooks and dilutes "Team capacity (whole window)" to 22–33%.
No real portfolio has nothing booked from May. It looks fake.
*Suggestion:* seed BAU/run allocations of 20–40% through Q4 FY27, or limit the grid to the planning horizon and label the cut-off.

**10. Comparable-initiative facts disagree between AI cards.**
Screenshots: `/tmp/director_shots/07_intake_analysis_result.png` (RDDC-24310 is **31%** similar) and `/tmp/director_shots/14_l2_how.png` (the same pair is **46%** similar). The L2 card also lists "RDDC-24688 … **actual** 650 h … not yet delivered".
*Suggestion:* use one similarity score per pair. Label not-yet-delivered comparables "approved L2", not "actual".

**11. The plan, the L2 and the PRN don't reconcile, and nothing explains why.**
Screenshots: `/tmp/director_shots/20_plan_suggest.png`, `/tmp/director_shots/26_pg3.png`.
The L2 is 1,000 h, of which QA is 196 h. The plan totals 859 h, of which QA is 104 h (56 h for WBS-400 plus 2 × 24 h regression). The PRN is funded at 1,100 h with "Forecast to finish 859 h". My first question would be "where did 141 h go?"
*Suggestion:* add one line on Pg 2: "Plan 859 h vs L2 1,000 h: contingency 130 h held, architecture/PM differences ±…". Alternatively, size QA from the L2.

**12. Suggest Resources ignores the step filter, and its top pick is the person causing the Red.**
Screenshot: `/tmp/director_shots/27_recommended_dev.png`.
I selected "WBS-210 API Platform" but the result starts with WBS-100 and lists every step. For WBS-100 it labels Sana Whitfield "Recommended Developer" at 128% in November, which is the very constraint Pg 3 flags Red one click later. Mateo has 69.5 h free. "Recommended Developer" is also the wrong title for a Solution Architect.
*Suggestion:* honour the filter. Penalise picks that go over 100% (or label them "Best fit · over capacity"). Use "Recommended resource" for non-developers.

**13. "Payments" is used for an accounts/transactions API.**
Screenshots: `/tmp/director_shots/09_sa_attached_full.png` (labels "payments, api, us-p&c"), `/tmp/director_shots/27_recommended_dev.png` ("needs Payments, API, Identity", "Payments APIs"). The Resource Fix also says "Mateo has not worked the US P&C payments domain". The SA itself lists payment initiation as out of scope.
*Suggestion:* use "accounts", "open-banking", "partner-api" labels and skills.

**14. The CRQ draft looks fabricated.**
Screenshot: `/tmp/director_shots/35_crq_draft_full.png`.
A draft already has a CRQ number, CRQ0001048817, whose suffix copies the RDDC number (24817). STO is pre-set to "Tentative Go" four months before the go/no-go. Seeded CRQ numbers have different lengths (CRQ000417305 and CRQ000421907 vs CRQ0001045902; see `/tmp/director_shots/01_portfolio_full.png`). Unlike every other AI action, the draft is written straight into the form with no review card. "Affected CIs" is cut off ("OBSERVABILI").
*Suggestion:* leave CRQ # blank with "assigned when raised in Remedy" (or use a believable unrelated number of one fixed length). Leave STO blank or set it to "Not requested". Show the draft as a review-before-accept card like the others.

**15. Script and UI labels don't match.**
- The script says "Predict risks". The button is **Identify Risks**, but AI Activity calls the feature "Predict risks" (`/tmp/director_shots/31_risks_empty.png`, `/tmp/director_shots/44_ai_activity.png`).
- The script says "Click the Red dimension → Suggest fix → Accept". Clicking the Red pill opens an **Override** modal (`/tmp/director_shots/28_click_red.png`), and the button is "Apply this fix", not Accept.
- The script says the hero shows "Action required by" on Pg 1. For RDDC-24817 Pg 1 only shows "Missing: Backout plan", with no named owner or date (`/tmp/director_shots/11_sa_completeness_click.png`). "Action required by" only appears for RDDC-24755 and RDDC-24702 on Intake & Grooming.

*Suggestion:* align the script and labels. Show "Action required by Sana Whitfield · <date>: add backout plan" under SA Completeness for the hero.

**16. AI Activity metrics oversell.**
Screenshot: `/tmp/director_shots/44_ai_activity.png`.
"Accepted 100% · 5 suggestions accepted" appears next to 20 runs, most of them "Awaiting review". Unaccepted rows show "Saved 5–45 min" although the tile says time is "Credited on Accept". Rules-engine Assistant replies show "High 90%" confidence and 0.0 s latency. The deterministic CR Compliance check is presented as AI with a confidence score.
*Suggestion:* show the acceptance rate as accepted ÷ all runs (or "5 of 20"). Show Saved only on accepted rows. Show no confidence for rules-engine or deterministic checks. Expire orphaned "Awaiting review" runs when the page is left.

**17. Excel export polish.**
Files: `dc-portfolio-2026-10-19.xlsx`, `RDDC-24817-demo-view.xlsx`, downloaded and inspected with openpyxl.
- Util columns use the General format, so they show 0.877 instead of 88%.
- The lookup tab is still called "Sheet1".
- In the Demo View sheet, WBS-200 Development has 0 hours (the UI shows 560 h).
- The hero's Comments and Management attention are blank in the Portfolio sheet and the UI.

Good: dates use `dd mmm yyyy`, panes are frozen, the Gantt sheet has coloured week bars with a float column, and there is a Mission Statement sheet.
*Suggestion:* apply `0%` to Util columns, rename the tab to "Lists", roll up the WBS-200 hours, and auto-write a one-line comment for the hero (e.g. "Planned for DC-2702; L2 1,000 h approved; 2 BD float").

**18. Duplicate and confusing fields.**
Screenshots: `/tmp/director_shots/05_after_save.png`, `/tmp/director_shots/35_crq_draft_full.png`.
On Pg 1, "PM" and "DC PM" are separate rows with the same person, and "DC SA" appears in both columns. On Pg 4, "Implementation Status" appears twice. "Assigned To" and "Tech/Dev Lead" list requestors, release leads and QA.
*Suggestion:* remove the duplicates and filter role dropdowns to the relevant roles.

**19. There is no DLR anywhere.**
I checked every page and the SA documents. The flow goes SA → Change Summary → L2 with no Design Level Review gate, decision or date.
*Suggestion:* add a "DLR" row (date and outcome) to Pg 1 or the governance reviews. Have the CIAM pending approval reference "November architecture review / DLR".

**20. The Assistant's weekly exec summary leaves out an Amber initiative.**
Screenshot: `/tmp/director_shots/40_assistant_q2.png`.
The "Draft this week's exec summary" reply covers the Red RDDC-24412, the new intake, approvals, CRQs and capacity, but not Amber RDDC-24601 (QA 6 BD behind). The "Write Executive Summary" button version does include it (`/tmp/director_shots/54_write_exec_summary.png`).
*Suggestion:* make both use the same content.

**21. Three "EAPI" teams.**
Screenshot: `/tmp/director_shots/01_portfolio.png`. "EAPI (Dev1)", "EAPI (Dev2)" and "EAPI" (Devon, Tech Lead) look like a data bug.
*Suggestion:* label the third one "EAPI Tech Lead", or group all three under EAPI with sub-rows.

### Nice

**22. One Red dimension still gives an Amber overall, and the rule isn't explained** (`/tmp/director_shots/29_suggest_fix.png`). Add a one-line rule tooltip such as "Overall = Red if Schedule Red or 2+ Red".

**23. KPI tiles aren't clickable.** "CRQs this week 2" goes nowhere (`/tmp/director_shots/51_kpi_crq_click.png`). Link each tile to a filtered list.

**24. Portfolio Gantt rows show only RDDC numbers** (`/tmp/director_shots/01_portfolio_full.png`). Add short names or show them on hover.

**25. The Pg 2 WBS table is cut off at "Depends on" at 1440 px** (`/tmp/director_shots/21_plan_accepted_full.png`). SME/Owner, Description and Comments are off-screen.

**26. The stepper ticks "Resource + Timeline" and "Automated Views" as soon as the plan is accepted,** before the Gantt or Pg 3 have been looked at (`/tmp/director_shots/21_plan_accepted.png`).

**27. "Pg 5 Portfolio View" inside an initiative sits alongside the sidebar "Portfolio View".** The in-initiative tab is the best "one intake → health + capacity + Gantt" screen (`/tmp/director_shots/53_initiative_pg5_tab.png`). Consider calling it "Demo View" and making it the presenter's landing step.

**28. Intake Analysis "Accept labels" only applies labels, which is unclear** (`/tmp/director_shots/07_intake_analysis_result.png`). Rename it "Apply suggested labels", or say what accepting the analysis actually does.

**29. Undo exists only in the transient toast** (`/tmp/director_shots/24b_after_slip_toast.png`). It works, but if the presenter dismisses the toast there is no way back except editing the date manually.

**30. Labelling nits.** The Monthly allocation heatmap labels Oct as "Q4" with no FY (`/tmp/director_shots/26_pg3_full.png`). Change Mgmt says "next 14 days" but its buttons are Previous/Next **week** (`/tmp/director_shots/48_changemgmt.png`).

**31. PRN-77310 appears in the Portfolio PRN dropdown before the intake exists** (`/tmp/director_shots/01_portfolio_full.png`). This is defensible (funding before RDDC), but an observant viewer may see it as pre-baked.

---

## "I don't get what this is for" moments
- **Pg 5 inside an initiative vs the Portfolio View in the sidebar.** I only realised Pg 5 was the Demo View when I clicked it by accident. Finding 27.
- **"Export to Excel" vs "Export Demo View…".** It's not clear which one my team wants. Either merge them, or label them "Portfolio workbook" and "Initiative Demo View workbook".
- **"Accept labels" on Intake Analysis.** I'm accepting an analysis, but only labels change. Finding 28.
- **Confidence % on rule checks.** Why would a rules check be "High 90%" confident? Finding 16.

## What would make me stop trusting it
Findings 1, 2, 4 and 5: the tool contradicting itself or answering a different question with high confidence. Fix those and the rest are polish.

---

## Top 5 things that impressed me (protect these)

1. **Numbers reconcile across every screen.** Tobias goes from 22% to 88% in Q1 (Portfolio, Pg 3, Suggest Resources and Excel all agree). Sana's 128% → 96% is 154 − 38.5 = 115.5 of 120 h, and Mateo's 42% → 74% also checks out. 868 + 130 rounds to 1,000 h. PRN-71840 at 92% burned is 1,794/1,950. That is what makes it credible to a Director.
2. **The slip-and-Undo moment** (`/tmp/director_shots/24b_after_slip_toast.png`, `/tmp/director_shots/25_after_undo.png`). Moving WBS-210 out 5 BD cascades through 9 steps, skips Family Day, flips Schedule to Red, shows "-3 business days · Misses DC-2702 → DC-2703", and Undo restores everything. This is the money shot.
3. **The Change Summary and L2 "How we got this" cards** (`/tmp/director_shots/12_change_summary_suggest.png`, `/tmp/director_shots/14_l2_how.png`). They cite SA § numbers, list gaps, open items with owners, and out-of-scope items, show the L2 formula with a breakdown table, and add a comparable-initiative rationale. This is exactly what our SAs and PMs do by hand.
4. **A realistic BMO calendar.** It has the FY27 Nov–Oct quarters, DC-27xx Saturday trains, the 14 Dec–8 Jan freeze band on the Gantt, Ontario/federal stat holidays skipped, Tue/Thu 10:00 ET grooming slots with attendees, an Outbox with escalating "Action required by" reminders, and 17-business-day waits on component approvals.
5. **The Resource Fix and context-aware Risks** (`/tmp/director_shots/29_suggest_fix.png`, `/tmp/director_shots/32_risks_predicted.png`). The fix shows exact before/after hours and states its own side-effect on Mateo's October. The predicted risks already know WBS-100 moved to Mateo and give dated mitigations and contingencies (e.g. "if WBS-210 slips ≥3 BD, move to DC-2703"). The Write Executive Summary output (`/tmp/director_shots/54_write_exec_summary.png`) is close to something I'd forward as-is.

Also worth keeping: the Settings "Fast-forward RDDC-24817" recovery button, no console errors in the whole run, and every AI card honestly badged "Simulated AI".
