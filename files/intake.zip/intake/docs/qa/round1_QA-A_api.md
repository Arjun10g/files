# Round 1 · QA-A · L2 API contract report

**Tester:** QA-A (independent; wrote none of the app code) · **Date:** 2026-10-19 (demo clock)
**Suite:** `tests/qa/test_api_contract.py` + `tests/qa/conftest.py` · run with `.venv/bin/python -m pytest tests/qa/test_api_contract.py -q`
**Baseline:** the builders' suite (`pytest tests --ignore=tests/e2e`) was 452 passed before this round. QA-A edited only `tests/qa/` and `docs/qa/`. Builders changed app code during the round; see the Status lines below.

## Summary

| | Count |
|---|---|
| Tests in the QA-A suite | **443** |
| First full run (~11:00) | 411 passed · **32 failed** |
| Re-run at 11:24, after builders changed app code mid-round | 421 passed · **22 failed** (two consecutive runs, identical failure set) |
| Distinct defects found | **9**: Blocker 0 · Major 4 · Minor 5 |
| Still open at 11:24 | **6**: Major 2 (QA-A-02, -04) · Minor 4 (QA-A-05 AI part, -06, -07, -08) |
| Verified fixed during the round | QA-A-01, QA-A-03, QA-A-09, and the views half of QA-A-05. Their QA tests now pass. |
| `/api` rules in `app.url_map` | 76 rules, 98 rule+method pairs |
| Pairs with ≥1 happy-path **and** ≥1 bad-input case | 98 / 98 (enforced by `test_meta_route_table_has_happy_and_bad_case_per_route`) |
| Rules not referenced by any test in `tests/` | 0 (enforced by `test_meta_every_api_rule_is_exercised_by_some_test`) |
| Rules not referenced by the **builder** suites alone | 1: `GET /api/ai/features`. Informational only; QA-A now covers it. |

Runtime is about 30 s. The defect list below is what the first run found. Each entry has a **Status** line from the 11:24 re-run. The QA tests stay as written, so each one is the regression check for its defect.

### What passed (contract holds)
- **Hero end-to-end through the API only (simulated AI): every step meets its target.**
  - Created from DCI-3391 as **RDDC-24817**, with grooming on **Tue 20 Oct 10:00**. Invites went to Arlo, Grace, Sana and Clara.
  - The SA `.docx` and `.pdf` both score **88** with "Backout plan" missing.
  - Change Summary → apply gives **4 components**: APIP High Approved, EDP Medium Approved, CIAM Medium Pending, SRE Low Not required.
  - L2: **560 / 56 / 196 / 56 / 868 / 130 → 1,000 h, L, 750–1,250**. Submit, then approve, moves the stage to Planning.
  - WBS → apply gives **14 rows**, dev **560 h**, Σ 859 h.
  - The Gantt has a critical path; Readiness 2027-02-17, Prod 2027-02-20, float 2.
  - Health: **Amber / Schedule Amber / Resources Red / Scope Green / Deps Green / Budget Green**, with attention "SA capacity constraint affecting WBS-100".
  - Rebalance moves WBS-100 from Sana to Mateo; after apply, **Resources is Green** and overall stays Amber.
  - Risks apply into the register with unique RSK codes.
  - CRQ draft **CRQ0001048817**: Bundle, Sat 02:00–06:00, **1 flag**, Tentative Go.
  - The portfolio includes the hero.
  - Both xlsx files open in openpyxl with the expected sheet names.
  - Assistant citations point only at existing records, both before and after the hero.
  - Reset restores every seed table count and RDDC-24817.
  - Fast-forward-hero is idempotent and resumes from a partial state.
- **Error responses:** every unknown id on 32 id-bearing routes returns 404 JSON. Unknown `/api` paths return JSON. 405 responses are JSON. No HTML error anywhere.
- **SQL injection and wildcards:** injection and wildcard strings in 5 search endpoints match nothing. A name containing SQL is stored literally.
- **XSS:** XSS strings are stored verbatim and returned as JSON data.
- **Excel/CSV injection:** formula-like cells in the xlsx and CSV exports are escaped.
- **Uploads:**
  - A `.exe` renamed `.pdf` returns 422 `unreadable_file` (paste-text fallback) and leaves no file on disk.
  - A 0-byte file returns 422.
  - A file over 10 MB returns 413 JSON.
  - Traversal filenames are sanitised and stay inside `uploads/`.
- **Plan and CRQ validation:** a dependency cycle (single update, bulk, or self-dependency) returns 422 and nothing is written. End before start returns 422 for tasks, bulk, and CRQ create/update.
- **Sequential double apply** returns 409.
- **Live tier:** the client is built with `timeout ≤ 20` and `max_retries=0`. The API key never appears in responses.
- **Determinism:** simulated AI output is identical across two fresh databases, and across two processes with different `PYTHONHASHSEED`. This covers 19 AI calls, 3 chats and L2.

## Defects

### QA-A-01 · Major · Concurrent double-apply of one AI run duplicates rows
- **Endpoint:** `POST /api/ai-runs/{id}/apply`
- **Repro:** `test_concurrent_double_apply_never_duplicates`. Two Accept requests race on one `risks` run.
- **Expected:** one 200 and one 409 (or a no-op); the risk count grows by the 4 proposed.
- **Actual:** both requests return 200 and **8 risks are inserted**. A plain two-thread race reproduced it 3 of 3 times while probing, without the timing shim the test uses.
- **Suspected owner:** `app/ai/apply.py` `apply_run`. It checks `status != 'generated'` before `db.transaction()` (check-then-act). The fix is to re-check inside the `BEGIN IMMEDIATE` transaction, or guard with `UPDATE ai_runs SET status='accepted' WHERE id=? AND status='generated'` and test the rowcount.
- **Status (11:24): FIXED.** `apply_run` now claims the run with a conditional `UPDATE … WHERE status='generated'` inside the transaction, and the test passes.

### QA-A-02 · Major · Live-AI failures other than `LiveError` return 500 instead of falling back
- **Endpoints:** every AI route and `/api/assistant/chat` in live mode
- **Repro:** 6 failures in `test_live_failure_falls_back_within_22s`:
  - `[*-client_ctor_fails]`: `anthropic.Anthropic()` raises.
  - `[*-bad_tool_json]`: `tool_use.input` is a non-JSON string.
- **Expected:** 200 with `mode=live_fallback` within 22 s (master §1 AI pattern; contracts §2).
- **Actual:** 500 `internal`. The cases where `create` raises, times out or returns no content do fall back correctly.
- **Suspected owners:**
  - `app/ai/claude.py`: `_client` wraps only `ImportError`, and `_tool_input` calls `json.loads` outside any try.
  - `app/ai/provider.py`: `run_feature` catches only `claude.LiveError`. Catch any exception from the live tier.
- **Status (11:24): OPEN.**

### QA-A-03 · Major · Non-string text fields in views endpoints return 500
- **Endpoints:**
  - `PUT /api/initiatives/{id}/health/override`: `reason`
  - `POST /api/initiatives/{id}/l2/approve`: `comment` and `approved_by`
  - `POST /api/initiatives/{id}/l2/reject`: `reason`
- **Repro:** `test_wrong_types_never_500[...health/override]`, `[...l2/approve]`, `[...l2/reject]`. For example, `{"dimension":"budget","rag":"Amber","reason":123}`.
- **Expected:** 422 `validation` (QA §1 L2 exit: no 500 for malformed input).
- **Actual:** 500. The code calls `(body.get(...) or "").strip()` on an int, list, dict or bool.
- **Suspected owner:** `app/api/views.py` (`health_override`, `l2_approve`, `l2_reject`).
- **Status (11:24): FIXED.** All three `test_wrong_types_never_500[...]` cases now pass.

### QA-A-04 · Major · Wrong-typed AI `options` return 500
- **Endpoints and repro tests:** each line is one failure in `test_ai_option_wrong_types_never_500`.
  - `POST /api/initiatives/{id}/ai/cr-compliance` with `options.change_request_id="abc"`.
  - `POST /api/ai/meeting-extract` with `options.meeting_note_id="abc"`.
  - `POST /api/ai/intake-autofill` with `options.attachment_id="abc"`.
  - `POST /api/ai/intake-analysis` with `options.name` or `options.description` set to a number, list, dict or bool.
- **Expected:** 422 `validation`.
- **Actual:** 500.
- **Suspected owners:**
  - `app/ai/context.py` `build_context` (lines ~541, ~590) and `_text_from_inputs` (~454) call bare `int()`.
  - `app/ai/generators.py` `gen_intake_analysis` (~727) calls `.lower()` on a non-string.
  - `app/api/ai.py` should validate the documented `options` (contracts §2 ai) before calling the provider.
- **Status (11:24): OPEN.**

### QA-A-05 · Minor · Malformed JSON is silently treated as `{}` on AI and views endpoints
- **Endpoints:**
  - `POST /api/ai-runs/{id}/apply|reject|regenerate`
  - `POST /api/ai/{slug}` and `POST /api/initiatives/{id}/ai/{slug}`
  - `POST /api/assistant/chat` (returns 422 "Type a question first" instead of 400)
  - `POST /api/grooming/auto-slot`
  - `POST /api/initiatives/{id}/l2/approve|reject`
  - `POST /api/reminders/run`
  - `PUT /api/initiatives/{id}/health/override`
- **Repro:** 11 failures in `test_malformed_json_body_is_400[...]`.
- **Expected:** 400 `bad_request`. The B1 endpoints already do this through `_shared.json_body()`.
- **Actual:** the request runs with an empty body. The worst case is **apply**: a truncated `{"selected":[0]` body returns 200 and **applies every row**. Auto-slot with a corrupt body runs a real (non-dry-run) slotting.
- **Suspected owners:** `app/api/ai.py` `_body()` and `app/api/views.py` `_body()`. Both use `get_json(silent=True)` and cannot tell an empty body from an unreadable one. Reuse `app/api/_shared.json_body`.
- **Status (11:24): PARTLY FIXED.** The views endpoints (auto-slot, L2 approve/reject, reminders, health override) now return 400. The 6 AI routes (apply, reject, regenerate, both feature routes, chat) still fail.

### QA-A-06 · Minor · AI options naming a record that does not exist return 200 with a proposal
- **Endpoints:** `POST /api/initiatives/4/ai/cr-compliance` with `change_request_id=999999`, `POST /api/ai/meeting-extract` with `meeting_note_id=999999`, `POST /api/ai/intake-autofill` with `attachment_id=999999`.
- **Repro:** `test_ai_option_unknown_record_id_is_404[...]` (3).
- **Expected:** 404 `not_found` (contracts §0).
- **Actual:** 200.
  - cr-compliance **silently analyses a different CRQ** (CRQ000421907, `simulated_fixture`), which is misleading.
  - The other two return an empty `simulated_generated` draft with a warning.
- **Suspected owners:** `app/api/ai.py` (validate option ids) and `app/ai/context.py`, which falls back to the initiative's CRQ.
- **Status (11:24): OPEN.**

### QA-A-07 · Minor · `GET /api/initiatives` ignores invalid numeric filters
- **Endpoint:** `GET /api/initiatives?dc_pm_id=abc` (also `priority=abc`)
- **Repro:** `test_route_contract[bad:GET /api/initiatives non-numeric dc_pm_id filter]`
- **Expected:** 422, as `/api/portfolio?dc_pm_id=abc` and every other B1 list (`activity`, `risks`, `outbox`, `change-requests`) already return.
- **Actual:** 200 with 0 items. An invalid RAG (`rag=Purple`) is also accepted silently.
- **Suspected owner:** `app/api/initiatives.py` `list_initiatives` / `app/repo.py` `list_initiatives`.
- **Status (11:24): OPEN.**

### QA-A-08 · Minor · Uploads at or just under 10 MB are rejected with 413
- **Endpoint:** `POST /api/initiatives/{id}/attachments`
- **Repro:** `test_upload_exactly_10mb_is_accepted`
- **Expected:** a 10 MiB file is accepted (master §1 Safety "≤10 MB"; contracts §2 "up to 10 MB").
- **Actual:** 413. Probing shows that a file of 10 MiB − 100 B also gets 413, while 10 MiB − 1000 B gets 201. Flask's `MAX_CONTENT_LENGTH` (10 MiB) caps the whole multipart request, overhead included.
- **Suspected owner:** `app/config.py` (`MAX_CONTENT_LENGTH`; this file is B0-frozen, so the fix needs a contract change request) and `app/api/initiatives.py`. Set the request limit to 10 MiB plus a small margin and keep the per-file check in `store_upload`.
- **Status (11:24): OPEN.**

### QA-A-09 · Minor · CSV export sends a malformed Content-Type
- **Endpoint:** `GET /api/export/portfolio.csv`
- **Repro:** `test_portfolio_csv_content_type_is_well_formed`
- **Expected:** `text/csv; charset=utf-8`
- **Actual:** `text/csv; charset=utf-8; charset=utf-8`
- **Suspected owner:** `app/api/export.py` `_download`. It passes a charset inside `mimetype=`, and Werkzeug appends another; use `content_type=` instead.

## Notes (not defects)
- `GET /api/initiatives/{id}/burndown` returns 404 for an initiative with no PRN ("This initiative has no PRN yet"). That is consistent with contracts §0 but semantically "no data". The UI should treat it as an empty state.
- `POST /api/assistant/chat` with a non-string `conversation_id` silently starts a new conversation. This is acceptable.
- `POST /api/initiatives/{id}/change-requests/draft` ignores any body, including malformed JSON. The contract defines no body, so this is not counted.
- Another QA agent's files in `tests/qa/` (`test_engines_independent.py`, `test_e2e_audit.py`) are not part of this report.
- **Status (11:24): FIXED.**


## Round 2 · contract update and regressions (2026-10-19, after `docs/qa/round2_decisions.md`)

**Run:** `.venv/bin/python -m pytest tests/qa/test_api_contract.py -q` → **458 passed, 1 failed**. Two consecutive runs gave the same result. The suite now has 459 tests.

**Round 1 defects:** QA-A-02, -04, -05, -06, -07 and -08 now pass unchanged. All 9 round-1 defects are closed.

### Tests updated to intended decisions
Each failure was checked against the decisions before its test was changed. None of them was a regression.
- **Decision 1, CRQ format.** The hero draft is `CRQ000001052216`, and a draft number is `CRQ` + 12 digits.
- **Decision 2, draft STO.** A draft's `sto_approval` is `null` ("Not requested").
- **Decision 3, compliance.** The hero draft's only flag is CR-11. CR-01 and CR-02 are "Not due yet".
- **Decision 7, attention.** The hero list is exactly ["SA capacity constraint affecting WBS-100", "Readiness float 2 business days to DC-2702 affecting WBS-600"]. Only the float line remains after Suggest fix.
- **Decision 12, reset counts.** `counts.initiatives` is now 9: these are raw table counts, including the hidden BAU-FY27 row with id -1. `GET /api/initiatives` still returns 8.
- **Decision 13, exports.** The lookup sheet is "Lists" (was "Sheet1").
- **Coordinator-confirmed, mode labels.** "Simulated AI · prepared response", "Simulated AI · rules engine", "Live Claude", "Live → Simulated".
- **New route `POST /api/initiatives/{id}/groomed`.** Added to the route table (happy: Grooming → Solution; bad: 409 when already past grooming) and to the unknown-id sweep (404).
- **Test bug fixed.** Shape checks passed a dict to `pytest.fail`, which raised a TypeError and hid the real assertion. They now pass a string.

### New round-2 contract tests (all pass unless listed below)
- `/groomed`:
  - The slot becomes Discussed, the message reads "Groomed in session Thu 22 Oct, 10:00", and the stage moves to Solution.
  - A second call returns 409.
  - Unknown id returns 404; an initiative in QA stage returns 409.
- Assistant intents `prn_status`, `crq_sto_readiness` and `what_if_slip` (by component and by WBS code):
  - Each routes to the right intent.
  - None writes to any domain table, and plan and health are unchanged.
  - The WBS-210 +5 bd what-if reports 24 Feb 2027 and "misses DC-2702" (master §6.2.6).
- `deterministic` is a boolean on the AiRun envelope, `GET /api/ai-runs/{id}`, the runs list and the chat response. It is true exactly when the feature is cr_compliance or the mode is simulated_generated.
- "Not due yet" is left out of the score:
  - The engine's `passed`, `checked` and `not_due` match the findings.
  - Each Not-due finding has a `due_date` and a "Due by …" reason.
  - The AI score equals round(100 × Pass ÷ (Pass + Fail + Warn)).
  - The AI statuses equal the engine's.
- Suggest Resources Accept:
  - Without `selected`, it never replaces an existing assignment; WBS-100 stays with Sana.
  - With `selected`, it replaces only the selected row.
- The hidden BAU-FY27 initiative never appears in initiatives, portfolio, portfolio Gantt or CSV, and `/api/initiatives/-1` returns 404.
- CRQ draft with `dry_run: true` inserts no row and does not use up the number; the real draft is still CRQ000001052216. B1's fix has already landed, and this test passes.

### Regressions / new defects
**QA-A-10 · Minor · AI CR-compliance "Not due yet" findings drop `due_date`**
- **Endpoint:** `POST /api/initiatives/{id}/ai/cr-compliance`
- **Repro:** `test_r2_ai_not_due_findings_carry_due_date`
- **Expected:** decision 3 and contracts ("findings take an optional `due_date`… mirrors `engines.compliance`") require the engine dates: CR-01/02 2027-02-17, CR-04/05 2027-02-21.
- **Actual:** `due_date` is null for all four.
- **Suspected owner:** `app/ai/fixtures/cr_compliance/RDDC-24817.json` (B6), whose findings have no `due_date` field. Also `app/ai/provider.py` `post_validate` (B3), which keeps the engine verdicts but does not copy `due_date` across from `derive.compliance_for`. The generator path (`generators.py:1931`) does copy it.

## Round 3 · contract update (after `docs/qa/round3_L6_director.md`)

**Run:** `.venv/bin/python -m pytest tests/qa/test_api_contract.py -q` → **467 passed, 1 failed** (468 tests).

**Round 2 defect:** QA-A-10 (AI Not-due-yet `due_date`) now passes.

### Failures confirmed as intended Round 3 changes, then updated
- **N2, `/groomed` before the session date.** It is now an ad-hoc walk-through: the slot is freed (not Discussed), queued invites are dismissed, and the message reads "Groomed in an ad-hoc walk-through today (Mon 19 Oct 2026)…".
  - The route-table happy case and the R2 groomed test now cover this.
  - The old behaviour is kept as `test_r3_groomed_on_session_date_marks_slot_discussed`, which moves `demo_today` to the session date.
- **N10, cr_compliance label.** Mode label "Rules check" and `deterministic: true`, asserted in `check_airun`. Three tests had pinned the old label.

No other failures appeared, so no regressions came from these changes.

### New round-3 tests
- **`/groomed`:**
  - Before the session date: ad-hoc walk-through, slot freed, grooming invites dismissed, Grooming → Solution.
  - On the session date: slot Discussed.
  - Unknown id returns 404; Estimation and QA stages return 409.
- **CR compliance:**
  - The hero draft engine payload has `sto_readiness_detail = {status: "Not requested", suggest_from: "2027-02-11", label "…Thu 11 Feb 2027"}`. T-5 business days skips Family Day, Mon 15 Feb.
  - The AI `sto_readiness` is "Not requested".
  - The runs list shows "Rules check" and `deterministic: true`.
- **Burndown:**
  - `burn_rate` for PRN-71840 equals the average of the last 3 charged months up to the current month: (476 + 210 + 398.5) / 3 = 361.5. This was computed independently from the bundle charges.
  - `burn_rate_window` is "3-month average" and `burn_rate_months` lists those months. A PRN with no charges gives 0.
- **Assistant `prn_overrun`:** the PRNs named and cited equal exactly the `/api/prns` rows with status `overrun`. The answer writes nothing and cites no missing record.
- **Suggest Resources Accept with `selected`:**
  - With the WBS-100 filter, the output contains only WBS-100, and the recommended person is assigned; no other row changes.
  - When the selected row has no recommendation, the top-ranked candidate is assigned.

### Open
**QA-A-11 · Minor · `sto_readiness_detail` is missing from the cr_compliance AI output**
- **Endpoint:** `POST /api/initiatives/{id}/ai/cr-compliance`
- **Repro:** `test_r3_cr_compliance_ai_output_carries_sto_readiness_detail`
- **Expected:** the coordinator's Round 3 change (2) says the cr_compliance AI output gains `sto_readiness_detail {status, suggest_from, label}`.
- **Actual:** the engine and CRQ compliance payload carry it, but the AI `output` has no such key.
- **Suspected owners:** `app/ai/schemas.py` CR_COMPLIANCE (frozen; B6 notes the schema does not accept the object), plus `app/ai/provider.py` post-validate and the B6 fixtures.
- **Decision needed:** if the intended contract is "engine payload only", close this and drop the test.

**QA-A-11 · CLOSED by coordinator ruling.** The engine-only placement is intended: `sto_readiness_detail` lives on the CRQ/compliance payloads, and the AI keeps the `sto_readiness` string. The test is now `test_r3_sto_readiness_detail_on_crq_payloads_and_ai_status_matches_engine`. It checks that the CRQ get, list and bundle payloads carry the detail with suggest_from 2027-02-11, and that the AI status equals the engine's.
