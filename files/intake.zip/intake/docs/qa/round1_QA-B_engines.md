# Round 1 · QA-B · Engine and business-rule verification (L3)

**Scope.** `app/engines/*.py` and `app/services/derive.py`, checked against master plan §1 and §6 (binding), PO §5, and contracts.md.
**Test file.** `tests/qa/test_engines_independent.py` has 144 tests. Every expected value was worked out by hand (the arithmetic is in the test comments) or with small spec helpers in the file (holiday set, business-day counter, roll-up rule). None of them call the code under test, and the goldens are not used as an oracle.
**Run.** `.venv/bin/python -m pytest tests/qa/test_engines_independent.py -q` → **138 passed, 6 failed**. The 6 failures are QA-B-01 to QA-B-06.

## Summary

| Severity | Count |
|---|---|
| Blocker | 0 |
| Major | 0 |
| Minor | 8 (6 with a failing test, 2 found by code review only) |

**Every hero / deck-parity pin holds.** L2 gives 560 → 1,000 h, L, 750–1,250. Grooming on Mon 09:30 lands on Tue 20 Oct 10:00. WBS-100 spreads as Oct 31.5 h / Nov 38.5 h. QA date is 10 Feb, Readiness 17 Feb, Prod Sat 20 Feb, float 2. Health is Amber with Resources Red at 128%. After moving WBS-100 to Mateo, Resources is Green (Sana 96%, Mateo 74%) and overall stays Amber. Pushing WBS-210 out 5 bd gives Readiness 24 Feb, float -3, Schedule Red and overall Red, and reverting restores every date.

**Goldens.** I recomputed every value in `tests/golden/*.json` by hand: calendar counts, fiscal boundaries, L2's three cases, spread_hours (including the 7-bd uneven split 7.1/2.9 and Tobias 63/147/70), bands, grooming, burndown (859 h forecast, overrun and at-risk cases), compliance cases 1–4, reminders, SA 8/9 → 88, and the hero health states. **All of them are correct.**

## Defects

### QA-B-01 · Minor · L2 payload reports two different contingency figures
- **Rule:** PO §5 says "868 → +130 → 1,000 h".
- **Expected:** one contingency figure per estimate.
- **Actual:** `contingency_hours` is round(868 × 0.15) = round(130.2) = **130**, but `by_phase[Contingency]` is total − subtotal = 1000 − 868 = **132**.
  - Pg 1's breakdown table shows 130 (`pg1_general.js:412`).
  - The F3 AI card's `by_phase` (`app/ai/generators.py:888`, same formula) shows 132.
  - So the same screen can show both numbers.
- **Where:** `app/engines/l2.py:78` vs `app/engines/l2.py:114`. Test: `test_l2_contingency_reported_consistently`.
- **Fix:** label the by_phase line "Contingency + rounding" or show 130 plus a separate "Rounding +2" line. Do the same in generators.py.

### QA-B-02 · Minor (latent) · Grooming ignores the time zone of an aware `now`
- **Rule:** master §1 says the cut-off is 17:00 ET.
- **Expected:** `now = 2026-10-19 20:30Z` is 16:30 ET, which is before the cut-off, so the slot is **Tue 20 Oct**.
- **Actual:** **Thu 22 Oct**. `_wall()` calls `now.replace(tzinfo=None)`, which drops the offset without converting to America/Toronto, so 20:30 is read as an ET wall time.
- **Where:** `app/engines/grooming.py:24-30`. Test: `test_grooming_timezone_aware_now_is_converted`.
- **Impact today:** none. `derive` passes `get_now()`, which is already Toronto-aware. Any future caller that passes UTC (an API `now`, a test, a server clock) will slot wrongly.
- **Fix:** `if now.tzinfo: now = now.astimezone(ZoneInfo("America/Toronto"))` before stripping the offset.

### QA-B-03 · Minor · `propagate_slip` processes a child before its inherited predecessor moves
- **Rule:** the `propagate_slip` docstring and `effective_preds` say children inherit their parent's dependencies.
- **Setup:** A → Q → P, where P has hours. X is a child of P with no dependencies of its own. A is extended from 6 to 10 Nov.
- **Expected:**
  - Q moves to 12–13 Nov (11 Nov is a holiday).
  - P moves to 16–17 Nov.
  - X inherits P's predecessor Q, so it moves to **16–17 Nov**.
- **Actual:** X is not moved. It stays at 12–13 Nov, overlapping Q.
- **Cause:** the order comes from `_topo` over explicit `depends_on` only (`schedule.py:286-288`). X has in-degree 0, so it is processed before Q's new end exists. `effective_preds` (`:320-326`) then reads Q's stale end.
- **Where:** `app/engines/schedule.py:286-288, 320-334`. Test: `test_slip_propagation_through_inherited_parent_dependency`.
- **Impact:** not on the hero path, because every hero row (fixture and `bundle_hero.json`) carries explicit dependencies. It does hit any WBS whose child rows rely on inheritance, which `schedule_plan` explicitly supports.
- **Fix:** add each node's inherited predecessors to `preds` before calling `_topo`, as `schedule_plan` already does with `leaf_preds`.

### QA-B-04 · Minor · The STO suggestion ignores open non-blocking flags (deviation from PO §5)
- **Rule:** PO §5 says the STO approval "auto-sets **Tentative Go** when all flags clear at T-5, **Tentative No Go** if any open".
- **Setup:** a CRQ for Sat 21 Nov with the CMS Lead missing (CR-07), checked on Mon 16 Nov (T-4: 17, 18, 19, 20 Nov).
- **Expected:** Tentative No Go.
- **Actual:** **Tentative Go**. `sto_suggestion` is driven only by `blocking`, and these flags are never blocking: CR-07, CR-10 (late raise), CR-06 (window over 8 h), CR-04/05 (Completed without a file) and CR-09.
- **Where:** `app/engines/compliance.py:204,211`. Test: `test_compliance_sto_suggestion_any_open_flag_at_t5_is_no_go`.
- **Note:** B2 handoff decision 5 only argues the backout case (blocking from T-5). The orchestrator should rule on the general case. Suggested rule: any open flag at or inside T-5 → Tentative No Go.

### QA-B-05 · Minor (latent) · Compliance drops time-zone offsets instead of converting
- **Rule:** master §6.1 puts the freeze at 14 Dec – 8 Jan, ET.
- **Setup:** `crq_start = 2026-12-14T03:00:00+00:00`, which is 22:00 ET on Sun 13 Dec (outside the freeze).
- **Expected:** no CR-06 flag.
- **Actual:** **CR-06 fires**. `_naive()` removes the offset, so the start is read as 03:00 on 14 Dec, inside the freeze. The same applies to `implemented_at` vs `now` for the 24 h validation grace, and to CR-09.
- **Where:** `app/engines/compliance.py:52-53, 77-78, 115`. Test: `test_compliance_utc_window_freeze_boundary`.
- **Impact today:** none. Seed and `crq_window()` write ET offsets. **Fix:** convert with `.astimezone(ZoneInfo(RULES["timezone"]))` before dropping the offset.

### QA-B-06 · Minor · SA Completeness treats short body sentences as headings
- **Rule:** PO §5 scores 9 sections from headings, and master §6.2 pin 2 needs the hero at **88**.
- **Setup:** the hero-shaped 8-section document plus the body line "Rollback is not defined yet."
- **Expected:** 88. Backout is still missing; this line is not a heading.
- **Actual:** **100**. Any line of 90 characters or fewer whose text starts with a section keyword counts as a heading. Other false positives: "Security is via mTLS.", "Data stays in Canada.", "Questions go to Sana."
- **Where:** `app/engines/sa_completeness.py:35-41` (only a length test), plus the patterns at `:10-24`. Test: `test_sa_body_sentence_is_not_a_heading`.
- **Risk:** one innocent sentence added to the hero SA doc breaks the Scope Green / 88% demo pin. B2 handoff note 2 already warns B6.
- **Fix:** require heading form: markdown `#`, numbering, a trailing `:`, or a line with no final period and at most about 8 words.

### QA-B-07 · Minor (review only) · The Scope rule text says "above baseline" but the code uses an absolute delta
- **Where:** `app/engines/health.py:319` uses `abs(delta_pct) > 20`.
- **Effect:** an L2 that drops 25% (750 vs 1,000) is **Red** with the reason "L2 estimate -25% against the approved baseline". But `RULE_TEXT["scope"]` (`health.py:35-37`), which the "How we got this" panel shows, says "more than 20% **above** baseline".
- **Also:** any non-zero delta, even -1%, turns Scope Amber (`:322`).
- **Rule:** master §1 says "delta ≤20% / >20%", which is ambiguous.
- **Fix:** align the text and the logic. The likely intent is increases only, or say "differs by" in the text.

### QA-B-08 · Minor (review only) · Burndown counts the current month's charges twice
- **Where:** `app/engines/burndown.py:47-48`. For the current month, the forecast adds `charged + planned` for that whole month.
- **Rule:** PO §5 defines forecast as charged + **remaining** planned. If October has 40 h charged out of 50 h planned, the forecast should be 50, not 90. A manual check returned `forecast_cum` [90, 90] for funded 100, which could flip a PRN to at_risk or overrun.
- **Impact:** none in the demo, because the seed charges run only through Sep 2026 and the hero has no charges. **Fix:** for the current month use `max(planned, charged)`, or charged + max(planned − charged, 0).

## Review notes (no defect)
- **Inclusive/exclusive date ranges are consistent:**
  - `business_days` / `count_business_days` are inclusive.
  - `business_days_after` covers (a, b].
  - `strictly_between` excludes both ends.
  - `end_after_business_days` counts the start day.
  - Readiness float past the train is `-count(train, readiness)`, which gives -3 for 24 Feb. Correct.
- **Units:** utilisation is a ratio and banded unrounded (`round(·, 9)` guards 147/147 and 132/120). Health converts to % only for display. Budget gaps are in percentage points. No hours/% mix-ups found.
- **Freeze:** it affects only milestone and train choice (`_milestone_date`, `next_train_after`) and CR-06. Business days and dev/QA durations ignore it (tested across 30 Nov – 13 Jan).
- **Roll-up:** all 243 RAG combinations match master §1. Before Planning the result is "Not scored yet".
- **Small edges** (not raised as defects):
  - The grooming cut-off is exclusive: a save at exactly 17:00:00 misses the session.
  - A Readiness date equal to the Saturday train date gives float 0 (Amber), not Red.
- **`now_iso()`:** it combines the demo date with the real time-of-day using a ZoneInfo tz, so its offset is right for the demo date.

---

## Round 2 · re-verification against `docs/qa/round2_decisions.md` (decisions 2, 3, 7, 13)

**Run:** `.venv/bin/python -m pytest tests/qa/test_engines_independent.py -q` → **159 passed, 0 failed**.

### Round 1 defects
- **Fixed, and my tests pass unchanged:** QA-B-01 through QA-B-06. QA-B-04 now holds the STO suggestion when any flag is open from T-5. QA-B-05 converts offsets with `cal.local_naive`.
- **Not re-checked in this round:** QA-B-07 and QA-B-08. Both were found by code review and have no test.

### Expectations updated for decision 7
The attention list is now every Red dimension, plus a Schedule Amber with float ≤ 2.
- **Hero as planned:** {"SA capacity constraint affecting WBS-100", "Readiness float 2 business days to DC-2702 affecting WBS-600"}.
- **After the fix:** only the float line.
- **WBS-210 +5 bd:** the list contains the slip line and the Sana line, and no "Readiness float" line, because Schedule is Red.

### New independent tests, all derived by hand and all passing

**Attention edges.** "Between" means business days strictly between Readiness and Sat 20 Feb; 15 Feb is a holiday.
- **Readiness 12 Feb:** float 4. No attention.
- **Readiness 16 Feb:** float 3 (17, 18, 19). No attention.
- **Readiness 17 Feb:** float 2. Attention line present.
- **Readiness 18 Feb:** float 1. Attention line present.
- **Readiness 19 Feb:** float 0. Attention line present.
- **Readiness 24 Feb:** -3 (22, 23, 24). Schedule Red, overall Red, and the attention list has no Amber watch line.
- **Float 2 with a Green override on Schedule:** no attention line.

**Hero draft CRQ on 19 Oct.** I ran it twice: once with explicit plan context and once with `{bundle}`.
- **Not due yet:** CR-01, CR-02, CR-04, CR-05.
- **CR-01 / CR-02 due date:** T-2 = 2027-02-17. Working back from Sat 20 Feb: the last business day before the window is Fri 19 Feb, and 2 business days before that is Wed 17 Feb. The reason text reads "Due by Wed 17 Feb 2027 (T-2 business days)."
- **CR-04 / CR-05 due date:** 2027-02-21, which is 24 h after the window ends.
- **Score:** 13 rules − 4 not due = 9 checked. That is 8 Pass (CR-03, 06, 07, 08, 09, 10, 12, 13) and 1 Fail (CR-11), so 8/9 = 88.9 → **89%**, with exactly 1 flag.
- **CR-12 Pass text:** "Window matches WBS-700 on Sat 20 Feb 2027."
- **STO suggestion:** `null` before T-5.

**T-2 boundary.**
- **Tue 16 Feb:** (16, 20] holds 3 business days, so CR-01 and CR-02 are still Not due yet.
- **Wed 17 Feb:** 2 business days, so both Fail. With Go and Approved, both Pass.

**Validation evidence.** Implemented 20 Feb at 05:40.
- **At 23 h 59 m:** Not due yet, due 2027-02-21.
- **At 24 h 01 m:** Fail.

**Score excluding Not due yet.**
- **Clean CRQ on 16 Nov:** 11 checked, 2 not due, 100%.
- **Same CRQ without a CMS Lead:** 10/11 = 90.9 → 91%.

**STO suggestion from T-5.**
- **Wed 10 Feb (6 business days out):** `null`.
- **Thu 11 Feb (5 business days out), clean:** Tentative Go.
- **Thu 11 Feb, backout missing:** Tentative No Go.

**CR-12 / CR-13.**
- **Bundle CRQ, plan production 20 Mar vs window 20 Feb:** both Fail.
- **Independent CRQ:** both Pass, because the rules are not applied.

**Capacity columns.**
- **Month view:** 2026-10 / 2026-11 show "Q4 FY26" / "Q1 FY27" with "Aug–Oct" / "Nov–Jan".
- **Quarter view:** headers read "Q4 FY26 (Aug–Oct)" and "Q1 FY27 (Nov–Jan)".

### New observation
**QA-B-09 · Minor · "Due by Wed 17 Feb" fails on 17 Feb itself.**
- **What happens:** CR-01 and CR-02 say "Due by Wed 17 Feb 2027". But at 09:30 on Wed 17 Feb (`compliance.py:117`, `near = bd_to_start <= 2`) they already show **Fail**, so the user gets no part of the due day to act.
- **Spec:** decision 3 doesn't say whether "by" includes the day. My test pins the current behaviour (Fail on the 17th).
- **Fix:** the orchestrator should decide. Either word it "Due before Wed 17 Feb", or make the Fail start on Thu 18 Feb.

**QA-B-09 ruling (orchestrator):** "Due by <date>" is inclusive. A rule stays Not due yet for the whole due date and fails from the next business day. For the hero, due Wed 17 Feb 2027 means Fail from Thu 18 Feb; for the 21 Nov window, due Wed 18 Nov means Fail from Thu 19 Nov. I updated `test_r2_t2_boundary_sto_and_crq_approval` and `test_compliance_each_flag_fires_and_clears` to match the ruling. Both fail against the current engine (`compliance.py:117`, `near = bd_to_start <= 2`) until B2's change lands.

**Re-run after B2 landed the change:** `.venv/bin/python -m pytest tests/qa/test_engines_independent.py -q` → **159 passed**. QA-B-09 is closed.
