# 2 — Solution Architecture (BMO DC Intake & Delivery Platform demo)

Author: Solution Architect. Status: **DECIDED** (builders treat it as the contract; to change it, raise it with the panel).
Source of truth for scope: `docs/01_requirements.md`. Demo goal: **one intake in → Health + Capacity + Gantt**, then AI automations on top.

---

## 1. Stack decision

| Layer | Decision | Why |
|---|---|---|
| Server | **Flask 3.1**, app factory, one Blueprint per API area | Already in the venv. Synchronous code is fine for one local user, and it's easy to split across builders. |
| DB | **SQLite through stdlib `sqlite3`**, no ORM. One file at `data/bmo_intake.db`, `PRAGMA foreign_keys=ON`, WAL mode | Nothing to install, a reset is just deleting a file, and the SQL is readable on screen during the demo. |
| Frontend | **Vanilla JS SPA with native ES modules** and a hash router (`#/initiatives/12/plan`). One CSS file using CSS variables for the BMO-style theme. **No build step and no npm.** | Opens straight from Flask static. Each view is a separate file, so builders don't collide. |
| Charts | **Hand-rolled SVG** (Gantt, capacity bars and heatmap, burndown, RAG tiles) in `static/js/charts/`. **No third-party JS.** | Works offline with no vendoring and no licences to check. Gantt dependency arrows and the critical-path highlight are much simpler in our own SVG than in a chart library. |
| Docs ingest | `python-docx` and `pypdf` pull the text out of the SA document when it is uploaded | This text feeds Generate Change Summary. |
| Excel | **openpyxl** export that copies the Demo View workbook layout | Big showcase moment: "your spreadsheet, but generated". |
| AI | Our own `AIProvider` abstraction. **Simulated** is the default; **Claude** (`anthropic` SDK) switches on when `ANTHROPIC_API_KEY` is set | Has to run offline. The live path is optional. |
| Tests | pytest for engines, API and AI; Playwright (Python) for the end-to-end smoke test | Already installed. |

Runtime config (env, `app/config.py`): `BMO_PORT=5050`, `BMO_DB_PATH=data/bmo_intake.db`, `BMO_AI_MODE=auto|simulated|live` (auto means live only if a key is set), `BMO_AI_MODEL=claude-opus-5-5` (the fast option is `claude-sonnet-5-5`), `BMO_AI_TIMEOUT=45`, `BMO_SIM_LATENCY=1` (adds a realistic 0.6–1.5 s delay; tests set it to 0), `BMO_TODAY` (optional fixed "today" for deterministic demos and tests).

**Seed dates are relative.** Seed JSON stores dates as offsets such as `"T-20"`, `"T+45"` or `"M+2"` (month), and `seed.py` turns them into real dates at reset time based on today. The demo therefore always looks current: tasks in flight, one slipping, next week's grooming session in the future.

Commands: `./run.sh` creates the DB if it's missing, then serves at http://localhost:5050. `./reset.sh` (or `POST /api/admin/reset`, which is also a button in the Admin view) drops the DB, re-seeds it, and clears uploads and ai_runs.

---

## 2. Directory tree

```
BMO Intake/
├─ run.sh                      # activate .venv, python -m app.cli init-if-missing, serve :5050
├─ reset.sh                    # python -m app.cli reset
├─ requirements.txt            # pinned: flask, openpyxl, python-docx, pypdf, anthropic, pytest, playwright
├─ pytest.ini                  # testpaths=tests, markers: e2e, live
├─ data/                       # runtime only (gitignored): bmo_intake.db, uploads/
├─ app/
│  ├─ __init__.py              # create_app(): config, db teardown, register blueprints (list below), static SPA route
│  ├─ config.py                # env → Config object
│  ├─ cli.py                   # init-if-missing | reset | seed | run
│  ├─ db.py                    # get_db, query, query_one, execute, executemany, transaction(), row→dict
│  ├─ schema.sql               # §3 verbatim
│  ├─ repo.py                  # read models: get_initiative_bundle(id), list_initiatives(filters), get_resource_calendar()
│  ├─ activity.py              # log_activity(actor, entity_type, entity_id, action, detail, initiative_id)
│  ├─ errors.py                # ApiError + JSON error handlers
│  ├─ textract.py              # extract_text(path, mime) for docx/pdf/txt
│  ├─ seed/
│  │  ├─ seed.py               # load JSON → DB, resolve T±n offsets, then derive allocations
│  │  ├─ lookups.json          # Sheet1 lists + stages, phases, LOBs
│  │  ├─ components.json       # DC component catalogue + dependencies + keywords
│  │  ├─ resources.json        # ~14 people, skills, monthly availability
│  │  ├─ initiatives.json      # 6 intakes incl. hero RDDC-24117 "US API Enhancement"
│  │  ├─ governance.json       # CRs, grooming sessions, PRNs + charges
│  │  ├─ artifacts.json        # decisions, lessons, meeting notes, documents
│  │  └─ files/                # sample SA docs (.docx/.pdf) copied to uploads on reset
│  ├─ api/                     # each module exposes `bp`
│  │  ├─ core.py               # health, lookups, admin/reset, settings, activity
│  │  ├─ initiatives.py        # initiative CRUD, search, components, attachments
│  │  ├─ plan.py               # WBS tasks + dependencies CRUD
│  │  ├─ resources.py          # resources, availability, allocations, skills
│  │  ├─ governance.py         # CRs, risks, grooming sessions/slots CRUD, notifications ack
│  │  ├─ artifacts.py          # decisions, lessons, meeting notes, documents
│  │  ├─ views.py              # portfolio, capacity, gantt, health, burndown, grooming/auto-slot, reminders/run, cr weekly
│  │  ├─ export.py             # xlsx export endpoints
│  │  └─ ai.py                 # all /ai/* endpoints, ai-runs, apply, assistant chat
│  ├─ engines/                 # PURE functions: dicts in, dicts out, no DB/Flask imports
│  │  ├─ calendar.py           # business days, month spans, BMO fiscal quarters (Q1=Nov–Jan)
│  │  ├─ health.py             # RAG engine
│  │  ├─ capacity.py           # demand vs availability, spread_hours
│  │  ├─ l2.py                 # L2 estimate
│  │  ├─ grooming.py           # slotter
│  │  ├─ reminders.py          # reminder scheduler
│  │  ├─ schedule.py           # gantt rows, CPM critical path, slip propagation
│  │  ├─ burndown.py           # PRN burndown
│  │  └─ compliance.py         # CR compliance checks
│  ├─ services/
│  │  ├─ derive.py             # writes engine outputs back: allocations from tasks, rag_cached, notifications
│  │  └─ xlsx_export.py        # openpyxl workbook builder
│  └─ ai/
│     ├─ provider.py           # AIProvider ABC, get_provider(), run_feature() (audit + fallback)
│     ├─ simulated.py          # SimulatedProvider (fixture → generator)
│     ├─ claude.py             # ClaudeProvider (forced tool-use JSON)
│     ├─ schemas.py            # JSON Schema per feature output (shared by both providers + tests)
│     ├─ prompts.py            # system + user prompt builders per feature
│     ├─ context.py            # bundle → compact prompt context; input_hash
│     ├─ generators.py         # deterministic fallback generators per feature
│     ├─ assistant.py          # chat: intent router + data-grounded answers
│     ├─ apply.py              # persist an ai_run's output into domain tables
│     └─ fixtures/<feature>/<key>.json
├─ static/
│  ├─ index.html               # shell: left nav (Add/Edit/Search/Portfolio …), #app, assistant drawer
│  ├─ css/app.css              # theme tokens, layout, forms, tables, Pg boxes, yellow "automation" buttons
│  ├─ css/charts.css           # SVG chart styles
│  ├─ img/                     # logo-free neutral icon set (inline SVG sprites)
│  └─ js/
│     ├─ main.js               # bootstrap + hash router + route table
│     ├─ api.js                # fetch wrapper, one function per endpoint
│     ├─ state.js              # tiny store (lookups cache, current initiative, ai mode)
│     ├─ ui/components.js      # table, field, select(lookups), modal, toast, badge, tabs
│     ├─ ui/ai_review.js       # "Generate → preview diff → Apply/Discard" modal, mode badge
│     ├─ views/intake_list.js  # Search Initiative
│     ├─ views/intake_new.js   # Add New Initiative wizard (incl. AI intake analysis)
│     ├─ views/initiative.js   # workspace shell, Pg tabs
│     ├─ views/pg1_general.js  # General Details + SA upload + Change Summary
│     ├─ views/pg2_plan.js     # WBS grid + Generate WBS + embedded Gantt
│     ├─ views/pg3_resources.js# quarter availability/allocation grid + suggestions
│     ├─ views/pg4_governance.js # CR form, validation attachments, STO
│     ├─ views/risks.js        # per-initiative risk register
│     ├─ views/artifacts.js    # docs, decisions, lessons, meeting notes
│     ├─ views/admin.js        # reset demo, AI mode, ai_runs log
│     ├─ views/dashboard.js    # home: hero Health + Capacity + Gantt (deck slide)
│     ├─ views/portfolio.js    # Pg5 project dashboard + change mgmt table + exec summary
│     ├─ views/capacity.js     # resource calendar heatmap, team bars, skill matrix
│     ├─ views/governance_weekly.js # weekly CR review + compliance flags
│     ├─ views/grooming.js     # sessions + auto-slot
│     ├─ views/notifications.js# reminders inbox
│     ├─ views/assistant.js    # chat drawer
│     └─ charts/{svg.js,gantt.js,capacity.js,heatmap.js,burndown.js,rag.js}
└─ tests/
   ├─ conftest.py              # app fixture w/ temp DB, BMO_TODAY=2026-10-19, BMO_SIM_LATENCY=0
   ├─ fixtures/bundle_hero.json# frozen get_initiative_bundle() output for engine/AI tests
   ├─ engines/test_*.py  ├─ api/test_*.py  ├─ ai/test_*.py  └─ e2e/test_demo_flow.py
```

---

## 3. SQLite schema (`app/schema.sql`)

Conventions: dates are ISO `YYYY-MM-DD` TEXT, timestamps are ISO UTC TEXT, months are `YYYY-MM`, JSON is stored in TEXT. `source` is one of `manual|ai|derived|seed`.

```sql
PRAGMA foreign_keys = ON;

CREATE TABLE app_settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE lookups (category TEXT, value TEXT, sort INTEGER DEFAULT 0, is_default INTEGER DEFAULT 0,
  PRIMARY KEY (category, value));
-- categories: status, release_type, sto_approval, validation_status, rag, stage, lob, phase,
--             task_status, approval, implementation_status, crq_approval_status, risk_status, l2_status

CREATE TABLE resources (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT, role TEXT NOT NULL,      -- Developer, QA, DC SA, PM, Lead, CMS Lead, Rel Lead, Account Manager
  team TEXT, component_id INTEGER REFERENCES dc_components(id), location TEXT,
  hourly_rate REAL DEFAULT 0, default_monthly_hours REAL DEFAULT 140,
  capacity_eligible INTEGER DEFAULT 1, active INTEGER DEFAULT 1);

CREATE TABLE dc_components (
  id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, team TEXT,   -- EAPI, CIAM, SRE, EDP, APIP, SEC, MOB, WEB
  component_lead_id INTEGER REFERENCES resources(id), keywords TEXT,                   -- JSON array, used by generators
  base_hours_s REAL, base_hours_m REAL, base_hours_l REAL, description TEXT);
CREATE TABLE component_dependencies (
  from_component_id INTEGER REFERENCES dc_components(id), to_component_id INTEGER REFERENCES dc_components(id),
  kind TEXT DEFAULT 'downstream', note TEXT, PRIMARY KEY (from_component_id, to_component_id));

CREATE TABLE prn_budget (
  prn_code TEXT PRIMARY KEY, name TEXT, lob TEXT, budget_amount REAL NOT NULL,
  budget_hours REAL, currency TEXT DEFAULT 'CAD', owner_id INTEGER REFERENCES resources(id),
  start_month TEXT, end_month TEXT);
CREATE TABLE prn_charges (
  id INTEGER PRIMARY KEY, prn_code TEXT REFERENCES prn_budget(prn_code) ON DELETE CASCADE,
  month TEXT NOT NULL, charged_amount REAL NOT NULL, charged_hours REAL, source TEXT DEFAULT 'seed');

CREATE TABLE initiatives (
  id INTEGER PRIMARY KEY, rddc TEXT UNIQUE NOT NULL, dc_intake TEXT, name TEXT NOT NULL,
  lob TEXT, priority INTEGER DEFAULT 3,              -- 1 highest
  stage TEXT DEFAULT 'Intake',                       -- Intake, Grooming, Discussion, L2 Estimation, L2 Approval, Planning, Build, QA, Release, Closed
  status TEXT DEFAULT 'Backlog',                     -- Sheet1: Backlog, In progress, Completed
  labels TEXT, requestor TEXT,
  assigned_to_id INTEGER REFERENCES resources(id), pm_id INTEGER REFERENCES resources(id),
  tech_lead_id INTEGER REFERENCES resources(id), dc_pm_id INTEGER REFERENCES resources(id),
  dc_sa_id INTEGER REFERENCES resources(id), sa_author TEXT, sa_completeness INTEGER DEFAULT 0,
  sa_doc_attachment_id INTEGER, description TEXT, prn_code TEXT REFERENCES prn_budget(prn_code),
  planned_start TEXT, planned_end TEXT, readiness_date TEXT, qa_date TEXT, qa_signoff_date TEXT, prod_date TEXT,
  l2_hours REAL, l2_status TEXT DEFAULT 'Not Started', l2_submitted_at TEXT, l2_approved_at TEXT,
  rag_cached TEXT, rag_override TEXT, rag_override_reason TEXT, comments TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE initiative_components (
  id INTEGER PRIMARY KEY, initiative_id INTEGER NOT NULL REFERENCES initiatives(id) ON DELETE CASCADE,
  component_id INTEGER NOT NULL REFERENCES dc_components(id),
  approval TEXT DEFAULT 'Pending',                   -- Pending, Approved, Not Required, Rejected
  change_summary TEXT, complexity TEXT DEFAULT 'M',  -- S, M, L
  component_lead_id INTEGER REFERENCES resources(id), sort INTEGER DEFAULT 0,
  source TEXT DEFAULT 'manual', ai_run_id INTEGER REFERENCES ai_runs(id),
  UNIQUE (initiative_id, component_id));

CREATE TABLE wbs_tasks (
  id INTEGER PRIMARY KEY, initiative_id INTEGER NOT NULL REFERENCES initiatives(id) ON DELETE CASCADE,
  initiative_component_id INTEGER REFERENCES initiative_components(id) ON DELETE SET NULL,
  wbs_code TEXT NOT NULL, parent_id INTEGER REFERENCES wbs_tasks(id) ON DELETE CASCADE,
  step TEXT NOT NULL, phase TEXT, description TEXT,  -- phase: Estimation, Architecture, Development, Integration, QA, Production
  owner_id INTEGER REFERENCES resources(id), resource_id INTEGER REFERENCES resources(id),
  planned_start TEXT, planned_end TEXT, forecast_start TEXT, forecast_end TEXT, actual_end TEXT,
  est_hours REAL DEFAULT 0, status TEXT DEFAULT 'Not Started',  -- Not Started, In progress, Completed, Blocked
  pct INTEGER DEFAULT 0 CHECK (pct BETWEEN 0 AND 100), comments TEXT,
  is_milestone INTEGER DEFAULT 0, sort INTEGER DEFAULT 0, source TEXT DEFAULT 'manual',
  ai_run_id INTEGER REFERENCES ai_runs(id), updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (initiative_id, wbs_code));
CREATE TABLE wbs_dependencies (
  task_id INTEGER REFERENCES wbs_tasks(id) ON DELETE CASCADE,
  depends_on_task_id INTEGER REFERENCES wbs_tasks(id) ON DELETE CASCADE,
  type TEXT DEFAULT 'FS', lag_days INTEGER DEFAULT 0, PRIMARY KEY (task_id, depends_on_task_id));

CREATE TABLE resource_availability (
  resource_id INTEGER REFERENCES resources(id) ON DELETE CASCADE, month TEXT NOT NULL,
  available_hours REAL NOT NULL, note TEXT, updated_by TEXT, PRIMARY KEY (resource_id, month));
CREATE TABLE allocations (
  id INTEGER PRIMARY KEY, resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  initiative_id INTEGER NOT NULL REFERENCES initiatives(id) ON DELETE CASCADE,
  task_id INTEGER REFERENCES wbs_tasks(id) ON DELETE CASCADE, month TEXT NOT NULL, hours REAL NOT NULL,
  firmness TEXT DEFAULT 'tentative' CHECK (firmness IN ('tentative','confirmed')),
  source TEXT DEFAULT 'derived');   -- derived rows are rebuilt by services/derive.py; manual rows are kept
CREATE INDEX ix_alloc_month ON allocations(month, resource_id);

CREATE TABLE skills (id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, category TEXT);
CREATE TABLE resource_skills (
  resource_id INTEGER REFERENCES resources(id) ON DELETE CASCADE, skill_id INTEGER REFERENCES skills(id),
  level INTEGER CHECK (level BETWEEN 1 AND 5), source TEXT DEFAULT 'manual', evidence TEXT,
  PRIMARY KEY (resource_id, skill_id));

CREATE TABLE risks (
  id INTEGER PRIMARY KEY, initiative_id INTEGER NOT NULL REFERENCES initiatives(id) ON DELETE CASCADE,
  task_id INTEGER REFERENCES wbs_tasks(id) ON DELETE SET NULL, title TEXT NOT NULL, description TEXT,
  category TEXT,                                    -- Schedule, Resource, Scope, Dependency, Technical, Compliance
  severity INTEGER CHECK (severity BETWEEN 1 AND 5), likelihood INTEGER CHECK (likelihood BETWEEN 1 AND 5),
  score INTEGER GENERATED ALWAYS AS (severity * likelihood) STORED,
  mitigation TEXT, owner_id INTEGER REFERENCES resources(id), status TEXT DEFAULT 'Open',
  due_date TEXT, source TEXT DEFAULT 'manual', ai_run_id INTEGER REFERENCES ai_runs(id),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE attachments (
  id INTEGER PRIMARY KEY, initiative_id INTEGER REFERENCES initiatives(id) ON DELETE CASCADE,
  entity_type TEXT NOT NULL, entity_id INTEGER,     -- initiative | change_request | document
  kind TEXT NOT NULL,                               -- sa_doc, tech_validation, biz_validation, other
  filename TEXT NOT NULL, stored_path TEXT NOT NULL, mime TEXT, size_bytes INTEGER,
  extracted_text TEXT, uploaded_by TEXT, uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE change_requests (
  id INTEGER PRIMARY KEY, initiative_id INTEGER NOT NULL REFERENCES initiatives(id) ON DELETE CASCADE,
  crq_number TEXT UNIQUE, crq_start TEXT, crq_end TEXT,                  -- ISO datetime
  release_type TEXT, release_train TEXT, affected_cis TEXT, target_release TEXT,
  impacted_component_id INTEGER REFERENCES dc_components(id),
  implementation_status TEXT DEFAULT 'Not Started', crq_approval_status TEXT DEFAULT 'Draft',
  sto_approval TEXT,                                -- Tentative Go, Tentative No Go, Go, No-Go
  cms_lead_id INTEGER REFERENCES resources(id), rel_lead_id INTEGER REFERENCES resources(id),
  resource_id INTEGER REFERENCES resources(id),
  tech_validation_status TEXT DEFAULT 'Not Started', biz_validation_status TEXT DEFAULT 'Not Started',
  tech_validation_attachment_id INTEGER REFERENCES attachments(id),
  biz_validation_attachment_id INTEGER REFERENCES attachments(id),
  compliance_json TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE grooming_sessions (
  id INTEGER PRIMARY KEY, session_date TEXT NOT NULL, start_time TEXT DEFAULT '10:00',
  title TEXT, capacity INTEGER DEFAULT 4, status TEXT DEFAULT 'Scheduled');
CREATE TABLE grooming_slots (
  session_id INTEGER REFERENCES grooming_sessions(id) ON DELETE CASCADE,
  initiative_id INTEGER REFERENCES initiatives(id) ON DELETE CASCADE,
  slot_order INTEGER, recipients_json TEXT, status TEXT DEFAULT 'Proposed',   -- Proposed, Confirmed, Discussed
  PRIMARY KEY (session_id, initiative_id));

CREATE TABLE notifications (
  id INTEGER PRIMARY KEY, rule TEXT NOT NULL,       -- grooming_invite, sa_action_required, l2_approval, cr_noncompliance, validation_missing
  initiative_id INTEGER REFERENCES initiatives(id) ON DELETE CASCADE, entity_type TEXT, entity_id INTEGER,
  recipient_id INTEGER REFERENCES resources(id), recipient_text TEXT, channel TEXT DEFAULT 'in_app',
  subject TEXT, body TEXT, due_at TEXT, sent_at TEXT, status TEXT DEFAULT 'Scheduled',  -- Scheduled, Sent, Acknowledged, Dismissed
  escalation_level INTEGER DEFAULT 0, dedupe_key TEXT UNIQUE);

CREATE TABLE decisions (id INTEGER PRIMARY KEY, initiative_id INTEGER REFERENCES initiatives(id) ON DELETE CASCADE,
  title TEXT, context TEXT, decision TEXT, decided_by TEXT, decided_on TEXT, status TEXT DEFAULT 'Approved');
CREATE TABLE lessons_learned (id INTEGER PRIMARY KEY, initiative_id INTEGER REFERENCES initiatives(id) ON DELETE CASCADE,
  category TEXT, what_happened TEXT, lesson TEXT, recommendation TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE meeting_notes (id INTEGER PRIMARY KEY, initiative_id INTEGER REFERENCES initiatives(id) ON DELETE CASCADE,
  grooming_session_id INTEGER REFERENCES grooming_sessions(id), meeting_date TEXT, title TEXT,
  attendees TEXT, notes_md TEXT, action_items_json TEXT);
CREATE TABLE documents (id INTEGER PRIMARY KEY, initiative_id INTEGER REFERENCES initiatives(id) ON DELETE CASCADE,
  doc_type TEXT,                                    -- SA, Architecture, Test Plan, Runbook, Release Notes
  title TEXT, version TEXT, attachment_id INTEGER REFERENCES attachments(id), url TEXT,
  owner_id INTEGER REFERENCES resources(id), status TEXT, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE ai_runs (
  id INTEGER PRIMARY KEY, feature TEXT NOT NULL, initiative_id INTEGER REFERENCES initiatives(id) ON DELETE SET NULL,
  input_hash TEXT NOT NULL, input_json TEXT, output_json TEXT,
  mode TEXT NOT NULL,                               -- simulated_fixture | simulated_generated | live | live_fallback
  model TEXT, fixture_key TEXT, latency_ms INTEGER, status TEXT DEFAULT 'ok', error TEXT,
  applied_at TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE assistant_messages (id INTEGER PRIMARY KEY, conversation_id TEXT, role TEXT, content TEXT,
  ai_run_id INTEGER REFERENCES ai_runs(id), created_at TEXT DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE activity_log (
  id INTEGER PRIMARY KEY, ts TEXT DEFAULT CURRENT_TIMESTAMP, actor TEXT DEFAULT 'demo.user',
  entity_type TEXT, entity_id INTEGER, initiative_id INTEGER, action TEXT, detail_json TEXT);
CREATE INDEX ix_activity_init ON activity_log(initiative_id, ts);
```

---

## 4. REST API contract

All routes are JSON under `/api`. Errors return `{"error":{"code":"not_found|validation|conflict|ai_error","message":str,"details":{}}}` with a 4xx/5xx status. Lists return `{"items":[...],"total":n}`. Every write calls `log_activity` and returns the updated object. Field names are exactly the DB column names. Joined display names get a `_name` suffix (for example `pm_name`).

**Core** (`api/core.py`)
- `GET /api/health` returns `{status:"ok", db:true, ai_mode:"simulated|live", model, today, version}`
- `GET /api/lookups` returns `{status:[..], release_type:[..], ..., components:[{id,code,name}], resources:[{id,name,role,team}]}`
- `GET|PUT /api/settings` returns or updates `{ai_mode, demo_today}`
- `POST /api/admin/reset` returns `{ok:true, counts:{initiatives:6,...}}`
- `GET /api/activity?initiative_id&limit` returns a list

**Initiatives** (`api/initiatives.py`)
- `GET /api/initiatives?q&stage&lob&status&rag` returns a list of `{id,rddc,name,lob,stage,status,priority,pm_name,dc_pm_name,rag,planned_end}`
- `POST /api/initiatives` takes `{rddc?,name,lob,priority,requestor,description,...}` (rddc is auto-generated as `RDDC-2xxxx` if missing) and returns the initiative
- `GET /api/initiatives/{id}` returns the **bundle** (see below). `PUT` takes a partial initiative and returns the initiative. `DELETE` returns `{ok}`
- `GET|POST /api/initiatives/{id}/components`. `PUT|DELETE /api/initiative-components/{icid}` with body `{component_id,approval,change_summary,complexity,component_lead_id}`
- `POST /api/initiatives/{id}/attachments` (multipart `file`, `kind`, `entity_type`, `entity_id`) returns `{id,filename,kind,extracted_chars}`. For `kind=sa_doc` it also sets `initiatives.sa_doc_attachment_id`
- `GET /api/attachments/{id}/download`

**Bundle shape** (also frozen in `tests/fixtures/bundle_hero.json`; it is the input to the engines and the AI layer):
```json
{"initiative":{...all columns, pm_name, dc_sa_name...},
 "components":[{"id","component_id","code","name","approval","change_summary","complexity","component_lead_name"}],
 "tasks":[{...wbs_tasks columns, "resource_name","owner_name","depends_on":[task_id,...]}],
 "allocations":[{"resource_id","task_id","month","hours","firmness"}],
 "resources":[{"id","name","role","team","availability":{"2026-11":140,...},"committed":{"2026-11":152.5}}],
 "risks":[...], "change_requests":[...], "prn":{"prn_code","budget_amount","charges":[{"month","charged_amount"}]},
 "sa_doc_text":"...", "component_catalog":[{"id","code","name","keywords",...}], "today":"2026-10-19"}
```
`resources[].committed` is the hours that resource has committed across **all** initiatives. Engines need this to detect over-allocation.

**Plan** (`api/plan.py`)
- `GET|POST /api/initiatives/{id}/tasks`. `PUT|DELETE /api/tasks/{tid}` with body `{wbs_code,step,phase,description,owner_id,resource_id,planned_start,planned_end,forecast_start,forecast_end,est_hours,status,pct,comments,depends_on:[tid]}`. After every write, `derive.rebuild_allocations(initiative_id)` and `derive.refresh_health(initiative_id)` run
- `PUT /api/initiatives/{id}/tasks/bulk` takes `{tasks:[...]}` (grid save)
- `POST /api/initiatives/{id}/baseline` copies forecast dates into planned dates

**Resources** (`api/resources.py`)
- `GET|POST /api/resources`, `PUT /api/resources/{rid}`
- `GET /api/resources/{rid}/availability?from&to`. `PUT /api/resources/{rid}/availability` takes `{months:{"2026-11":120,...}}`
- `GET|POST /api/allocations?initiative_id&resource_id`, `PUT|DELETE /api/allocations/{aid}` with body `{resource_id,initiative_id,task_id,month,hours,firmness}`
- `GET /api/skills/matrix` returns `{skills:[..], rows:[{resource_id,name,levels:{skill:level}}]}`. `PUT /api/resources/{rid}/skills` takes `{skill:level}`

**Governance** (`api/governance.py`)
- `GET /api/change-requests?week=YYYY-Www&initiative_id` returns a list that includes `compliance:{ok,flags:[..]}`. `POST /api/initiatives/{id}/change-requests`. `PUT|DELETE /api/change-requests/{cid}`
- `GET|POST /api/initiatives/{id}/risks`, `PUT|DELETE /api/risks/{rid}`
- `GET|POST /api/grooming/sessions`, `PUT /api/grooming/slots` takes `{session_id,initiative_id,status}`
- `GET /api/notifications?status`, `POST /api/notifications/{nid}/ack`

**Artifacts** (`api/artifacts.py`): `GET|POST /api/{decisions|lessons|meeting-notes|documents}?initiative_id` and `PUT|DELETE /api/{type}/{id}`.

**Computed views** (`api/views.py`). These are read-only and computed by the engines on every request.
- `GET /api/portfolio` returns `{projects:[{id,rddc,name,lob,dc_pm_name,stage,rag,dimensions,planned_end,forecast_end,qa_signoff_date,prod_date,comments}], change_mgmt:[{rddc,crq_number,cms_lead_name,rel_lead_name,resource_name,implementation_status,tech_validation_status,biz_validation_status}], kpis:{active,red,amber,green,open_crs,overallocated_resources}}`
- `GET /api/initiatives/{id}/health` returns the health engine output (§6)
- `GET /api/initiatives/{id}/gantt` returns `{start,end,tasks:[{id,wbs_code,step,phase,resource_name,planned_start,planned_end,forecast_start,forecast_end,pct,status,is_milestone,critical:bool,float_days,slip_days,depends_on:[id]}],critical_path:[id],today}`
- `GET /api/capacity?from=YYYY-MM&to=YYYY-MM&group=resource|team|quarter&initiative_id?` returns `{months:[..], rows:[{key,label,team,cells:[{month,available,confirmed,tentative,util_pct,band}]}], teams:[{team,available,demand}]}`
- `GET /api/initiatives/{id}/resource-grid` returns the Pg3 grid: `{quarters:["Q1 FY27 (Nov–Jan)",...], rows:[{resource_id,name,cells:[{quarter,availability,allocation}]}]}`
- `GET /api/prn/{code}/burndown` and `GET /api/initiatives/{id}/burndown` return `{budget,months:[..],actual_cum:[..],ideal:[..],forecast:[..],exhaust_month,status}`
- `POST /api/initiatives/{id}/l2/calculate` returns the L2 engine output. `POST /api/initiatives/{id}/l2/submit` (moves to Pending Approval) and `/approve` return the initiative
- `POST /api/grooming/auto-slot` takes `{dry_run:bool}` and returns `{assignments:[{session_id,session_date,initiative_id,rddc,recipients:[..]}], unslotted:[..]}`
- `POST /api/reminders/run` takes `{now?}` and returns `{created:[notification], skipped:n}`
- `GET /api/governance/weekly?week=` returns `{week,crs:[...with compliance], noncompliant_count}`

**Export** (`api/export.py`)
- `GET /api/export/demo-view.xlsx?initiative_id=` returns a workbook with these sheets: *Mission Statement*, *Demo View* (Pg1–Pg4 boxed sections laid out like the source, with automation cells filled yellow), *Portfolio View* (Pg5), *Gantt* (week columns with fills coloured by phase, critical path in red), *Capacity* (fiscal quarters with conditional fills), *Risk Register*, *Sheet1* (lookups wired up as data validations)
- `GET /api/export/portfolio.xlsx`

**AI** (`api/ai.py`). Every AI endpoint returns a **proposal**. Nothing is written to domain tables until the user clicks Apply, so a human is always in the loop.
- `POST /api/initiatives/{id}/ai/{feature}` where feature is one of `change-summary | wbs | risks | resources | exec-summary | intake-analysis | l2-estimate`. Request body `{options?:{}}`. Response `{ai_run_id, feature, mode, model, latency_ms, output:{...per schema}, applied:false}`
- `POST /api/ai/intake-analysis` takes `{name,description,lob}` (used before the initiative exists) and returns the same shape
- `POST /api/ai/skill-matrix` returns the same shape
- `POST /api/ai-runs/{run_id}/apply` takes `{selected?:[index]}` and returns `{applied:{components|tasks|risks|allocations|...:n}, initiative_id}`
- `GET /api/ai-runs?feature&initiative_id` returns a list. `GET /api/ai-runs/{id}` returns the run
- `POST /api/assistant/chat` takes `{conversation_id?, message, initiative_id?}` and returns `{conversation_id, answer_md, citations:[{type,id,label,route}], suggested_actions:[{label,route|api}], ai_run_id, mode}`

---

## 5. AI provider abstraction (`app/ai/`)

```python
class AIProvider(ABC):
    name: str                                  # "simulated" | "claude"
    @abstractmethod
    def run(self, feature: str, context: dict) -> dict: ...   # returns {"output": dict, "mode": str, "model": str|None, "fixture_key": str|None}

def run_feature(feature, context, initiative_id=None) -> dict:   # the ONLY entry point the API uses
    # 1) input_hash = sha256(canonical_json(context))[:16]
    # 2) provider = get_provider()  (settings.ai_mode / env / key presence)
    # 3) try provider.run → validate against schemas.SCHEMAS[feature] (jsonschema-lite validator in schemas.py)
    # 4) on ClaudeProvider error/timeout/invalid → SimulatedProvider.run, mode="live_fallback"
    # 5) insert ai_runs row (input_json, output_json, mode, model, latency_ms, status) → return API payload
```

**Features** (snake_case internally; the URL uses kebab-case): `change_summary, wbs, risks, resources, exec_summary, intake_analysis, l2_estimate, skill_matrix, assistant`.

**Output schemas** (`schemas.py`; these are the contract for fixtures, generators, Claude and `apply.py`):
- `change_summary`: `{components:[{code, approval:"Approved|Pending|Not Required", complexity:"S|M|L", summary, confidence:0-1}], sa_completeness_pct, gaps:[str]}`
- `wbs`: `{tasks:[{wbs_code, step, phase, description, component_code, owner_role, est_hours, duration_days, offset_days, depends_on:[wbs_code], is_milestone}]}`. `apply.py` converts the offsets into dates starting from `planned_start` (or the next business day) using `engines.calendar`
- `risks`: `{risks:[{title, description, category, severity:1-5, likelihood:1-5, mitigation, owner_role, wbs_code|null}]}`
- `resources`: `{recommendations:[{wbs_code, resource_id, resource_name, score:0-100, rationale, alternatives:[{resource_id,resource_name,score}]}]}`. Scoring combines skill match, component team, and free capacity across the task's months
- `exec_summary`: `{headline, rag, summary_md, highlights:[str], concerns:[str], asks:[str]}`
- `intake_analysis`: `{classification, complexity:"S|M|L|XL", impacted_components:[code], suggested_priority:1-4, missing_info:[str], clarifying_questions:[str], suggested_stage}`
- `l2_estimate`: `{total_hours, low_hours, high_hours, by_component:[{code,hours}], by_phase:[{phase,hours}], assumptions:[str], narrative}`. **Numbers always come from `engines.l2`**. The AI only writes the assumptions and narrative
- `skill_matrix`: `{rows:[{resource_id, skills:[{skill, level:1-5, evidence}]}]}`
- `assistant`: `{answer_md, citations:[...], suggested_actions:[...]}`

**SimulatedProvider lookup order:**
1. `fixtures/<feature>/<rddc>.json`, for example `fixtures/wbs/RDDC-24117.json`. These are hand-authored for the 6 seed intakes.
2. `fixtures/<feature>/<input_hash>.json`. These are captured from live runs (`python -m app.cli capture-fixtures`).
3. `fixtures/assistant/<intent>.json` (assistant only, matched by intent).
4. `generators.generate(feature, context)`, a **deterministic** generator so any new intake still gets sensible output. It matches `sa_doc_text + description` against component `keywords`, uses phase templates per component (Architecture → Development → Integration → QA → Production), takes risk templates from task, capacity and dependency signals, calls the `resources` scorer and the `l2` engine, and builds a templated exec summary from the health output.

**Fixture file format** (exact):
```json
{
  "fixture_version": 1,
  "feature": "wbs",
  "key": "RDDC-24117",
  "match": {"rddc": "RDDC-24117"},
  "authored_by": "ai-lead-agent",
  "model_emulated": "claude-opus-5-5",
  "simulated_latency_ms": 1400,
  "notes": "Hero intake; produces WBS-100 SA review on critical path",
  "output": { "tasks": [ { "wbs_code": "WBS-100", "step": "Solution Architecture review", "phase": "Architecture",
      "description": "...", "component_code": "APIP", "owner_role": "DC SA", "est_hours": 40,
      "duration_days": 8, "offset_days": 0, "depends_on": [], "is_milestone": false } ] }
}
```
For the assistant, `match` is `{"intent": "overallocated_resources", "patterns": ["over ?allocat", "capacity"]}`. Intents are answered with a **live data query** first (the SQL template lives in `assistant.py`), and the fixture supplies the phrasing template with `{placeholders}`. Every `output` must validate against `schemas.py`, and `tests/ai/test_fixtures_valid.py` enforces this.

**ClaudeProvider:** `anthropic.Anthropic(timeout=BMO_AI_TIMEOUT, max_retries=1)` and `messages.create(model=BMO_AI_MODEL, max_tokens=4096, system=prompts.SYSTEM[feature], tools=[{"name":"emit_"+feature,"input_schema":SCHEMAS[feature]}], tool_choice={"type":"tool","name":"emit_"+feature}, messages=[{"role":"user","content":prompts.user(feature, context.compact(bundle))}])`. The `tool_use.input` from the response becomes the output. Any exception, timeout or schema failure falls back to simulated mode, and the fallback is visible in the UI as a "Live → fallback" badge. Live tests are marked `@pytest.mark.live` and skipped when there is no key.

---

## 6. Calculation engines (`app/engines/`, pure, 100% unit-tested)

| Module | Signature | Rules (defaults live in `RULES` dicts at the top of each module so the "agree RAG rules" workshop can tune them) |
|---|---|---|
| `calendar.py` | `business_days(a,b)`, `add_business_days(d,n)`, `month_range(a,b)`, `fiscal_quarter(month)->("FY27","Q1")`, `quarter_label` | BMO FY starts Nov 1: Q1 Nov–Jan, Q2 Feb–Apr, Q3 May–Jul, Q4 Aug–Oct. FY27 = Nov 2026–Oct 2027. Statutory holidays are ignored. |
| `health.py` | `compute_health(bundle) -> {overall, dimensions:{schedule,resources,scope,dependencies,budget:{rag,score,reasons:[str]}}, attention:str|None, overridden:bool}` | **Schedule**: worst open-task slip (`forecast_end - planned_end`, business days) >10 is Red, >3 or any overdue task is Amber. Also checks expected % vs actual % on the critical path (gap >25 pts is Amber). **Resources**: any task resource >120% utilised in a task month is Red, >100% is Amber, an unassigned task starting within 10 days is Amber. **Scope**: sa_completeness <50 is Red, <80 is Amber; a component in Pending approval after stage Planning is Amber; an open scope CR is Amber. **Dependencies**: a predecessor forecast_end after a successor's start is Red; any Blocked task is Amber. **Budget**: burndown `exhaust_month` before planned_end is Red; charged% minus pct_complete >15 is Amber. **Overall**: Red if Schedule is Red or ≥2 dimensions are Red, otherwise Amber if anything is Red or Amber, otherwise Green. A manual `rag_override` wins over everything. `attention` is the top reason, e.g. "SA capacity constraint affecting WBS-100". |
| `capacity.py` | `spread_hours(start,end,hours)->{month:h}` (by business days), `compute_capacity(resources, allocations, months, group) -> rows`, `band(util)` | util = (confirmed + tentative) / available. Bands: <70% `under`, 70–100% `ok`, 100–110% `stretched`, >110% `over`. Tentative hours are drawn hatched. Allocations derived from tasks are `tentative` until the initiative reaches stage Build (or the user confirms them). |
| `l2.py` | `estimate_l2(components, catalog, nfr_flags) -> {total_hours,low_hours,high_hours,by_component,by_phase,assumptions}` | Per component: `base_hours_{S,M,L}`. Then multiply by 1.10 per downstream dependency (max 1.3) and by 1.10 if `SEC` is touched. Phase split: Estimation 5%, Architecture 15%, Development 40%, Integration 10%, QA 20%, Production 10%. Add 15% contingency. The range is −15%/+25%. |
| `grooming.py` | `slot(initiatives, sessions, today) -> {assignments, unslotted}` | Candidates are stage Intake/Grooming with no slot yet. Order by priority, then created_at. Put each one in the earliest future session with free capacity. Recipients are requestor, DC PM, DC SA, tech lead, plus component leads. |
| `reminders.py` | `due_reminders(state, now) -> [Notification(rule, dedupe_key, ...)]` | `sa_action_required`: stage Discussion and sa_completeness <100, every **2 days** to the DC SA ("Action required by <date>"). `l2_approval`: l2_status Pending Approval, every 3 business days to the requestor, escalation level +1 each time, and after 3 reminders it is CC'd to the Delivery Lead. `cr_noncompliance`: every Monday, a list for leads. `validation_missing`: 2 days before crq_start if either validation status is ≠ Completed or has no attachment. `grooming_invite`: on slot. The dedupe key is `rule:entity:period`, so running it again is a no-op. |
| `schedule.py` | `build_gantt(tasks, deps, today) -> {...}`, `critical_path(tasks, deps) -> [ids]`, `propagate_slip(tasks, deps) -> {task_id: new_forecast}` | CPM on business-day durations of forecast dates (planned dates when there is no forecast). Forward and backward pass give float, and float == 0 is critical. FS dependencies with lag. Detects cycles and raises `ScheduleError`. |
| `burndown.py` | `burndown(budget, charges, start_month, end_month, today) -> {...}` | Cumulative actual spend. The ideal line is linear. The forecast is the 3-month average run-rate. `exhaust_month` is when the forecast reaches the budget. Status is `on_track|at_risk|overrun`. |
| `compliance.py` | `check_cr(cr, today) -> {ok, flags:[{code,message}]}` | Flags: CRQ lead time <5 business days, STO approval not Go within 2 days of start, validation evidence missing, no CMS or Rel lead, `Bundle` release without a train. |

`services/derive.py` (owned by B2) is the only code that writes derived data: `rebuild_allocations(iid)` replaces `source='derived'` allocation rows with `spread_hours(task.forecast_*, est_hours)`, `refresh_health(iid)` writes `rag_cached`, and `run_reminders(now)` inserts notifications. B1's CRUD handlers call these functions. Until B2 delivers, B1 uses no-op stubs guarded by `try: from app.services import derive`.

---

## 7. Parallel build plan

Five builders, each with **exclusive file ownership**. Shared contracts are this document plus `app/schema.sql`, `app/ai/schemas.py` and `tests/fixtures/bundle_hero.json`. Those three files are written in **Step 0** by their owners and then frozen.

| Builder | Owns (exclusive) | Delivers |
|---|---|---|
| **B1: Core data & CRUD API** | `run.sh`, `reset.sh`, `requirements.txt`, `pytest.ini`, `app/__init__.py`, `config.py`, `cli.py`, `db.py`, `schema.sql`, `repo.py`, `activity.py`, `errors.py`, `textract.py`, `app/seed/**`, `app/api/{core,initiatives,plan,resources,governance,artifacts}.py`, `tests/conftest.py`, `tests/fixtures/bundle_hero.json`, `tests/api/test_crud_*.py` | A runnable app and seed (hero RDDC-24117 "US API Enhancement" with components APIP/EDP/SEC, WBS-100 SA review overloaded so Resources is Red and overall Amber; 5 more intakes at different stages; 14 resources across the EAPI, CIAM, SRE, EDP and Security teams; 3 PRNs; 6 CRs incl. 2 non-compliant; 3 future grooming sessions) |
| **B2: Engines, views, export** | `app/engines/**`, `app/services/{derive,xlsx_export}.py`, `app/api/{views,export}.py`, `tests/engines/**`, `tests/api/test_views.py`, `tests/api/test_export.py` | Every computed view and the xlsx export |
| **B3: AI layer** | `app/ai/**` (incl. all fixtures), `app/api/ai.py`, `tests/ai/**` | Providers, generators, fixtures for 6 intakes × 7 features plus about 12 assistant intents, apply logic, `cli capture-fixtures` (registered via `app/ai/cli_ext.py`, which B1's `cli.py` imports if present) |
| **B4: Frontend shell & workspace** | `static/index.html`, `static/css/app.css`, `static/js/{main,api,state}.js`, `static/js/ui/**`, `static/js/views/{intake_list,intake_new,initiative,pg1_general,pg2_plan,pg3_resources,pg4_governance,risks,artifacts,admin}.js` | Navigation, every form, AI review modal, Pg1–Pg4 |
| **B5: Dashboards, charts, E2E** | `static/css/charts.css`, `static/js/charts/**`, `static/js/views/{dashboard,portfolio,capacity,governance_weekly,grooming,notifications,assistant}.js`, `tests/e2e/**` | Hero dashboard, SVG charts, Pg5, assistant drawer, Playwright demo-flow test |

**Interface contracts:**
- **Blueprint registration:** B1's `create_app` imports this fixed list: `core, initiatives, plan, resources, governance, artifacts, views, export, ai`. A missing module is logged and skipped, so builders can land in any order. Each module exports `bp = Blueprint(name, __name__, url_prefix="/api")`.
- **DB access:** only through `app.db` (`query(sql, params)->list[dict]`, `query_one`, `execute(sql, params)->lastrowid`, `transaction()` context manager). Bundles come only from `app.repo.get_initiative_bundle(id, today)`.
- **Engines** import nothing from Flask or the DB. B2 and B3 develop against `bundle_hero.json` before the API exists.
- **AI to engines:** B3 imports `engines.l2`, `engines.health` and `engines.capacity` (read-only use). `apply.py` writes through `app.db` and then calls `services.derive.rebuild_allocations`/`refresh_health`.
- **Frontend view modules:** `export async function render(root: HTMLElement, params: object, ctx: {api, state, ui}) -> (cleanup?: fn)`. B4's `main.js` route table is fixed now: `#/` dashboard (B5), `#/intakes` list, `#/intakes/new`, `#/initiatives/:id/:tab(general|plan|resources|governance|risks|artifacts)`, `#/portfolio`, `#/capacity`, `#/governance`, `#/grooming`, `#/notifications`, `#/admin`. The assistant is a drawer opened from every page via `views/assistant.js#mount(drawerEl, ctx)`.
- **Chart API (B5 provides, B4 embeds in Pg2/Pg3):** `charts/gantt.js#renderGantt(el, ganttJson, {onTaskClick})`, `charts/heatmap.js#renderHeatmap(el, capacityJson)`, `charts/capacity.js#renderTeamBars(el, capacityJson)`, `charts/burndown.js#renderBurndown(el, burndownJson)`, `charts/rag.js#renderHealth(el, healthJson)`. All of them take the exact API response JSON from §4.
- **`api.js` (B4)** has one exported function per endpoint in §4, named camelCase after the path (`getPortfolio`, `runAi(iid, feature, opts)`, `applyAiRun(runId, selected)`, `chat(msg, iid, convId)`, ...). B5 imports it and never calls `fetch` directly.

**Integration order:**
1. **Step 0 (contracts):** B1 commits `schema.sql`, `db.py`, the `create_app` skeleton, `/api/health` and `bundle_hero.json`. B3 commits `schemas.py`. B4 commits the `api.js` stubs, `main.js` route table and `ui/components.js`.
2. **Step 1 (parallel):** B1 seed and CRUD. B2 engines with unit tests. B3 providers, fixtures and generators. B4 Pg1–Pg4 forms. B5 charts, using the §4 sample JSON saved in `tests/e2e/samples/`.
3. **Step 2:** B2 wires the views API and `derive.py`, and B1 drops its no-op stubs. B3 wires `api/ai.py` and `apply.py`.
4. **Step 3:** B4 and B5 switch to the live API. B4 embeds B5's charts in Pg2 and Pg3.
5. **Step 4:** B5's Playwright flow runs against `./reset.sh && ./run.sh`: create an intake → AI intake analysis → upload SA doc → Generate Change Summary → apply → Generate WBS → apply → Gantt renders with the critical path → Suggest Resources → apply → Health shows Amber/Resources Red → Portfolio → export xlsx opens → assistant answers "who is over-allocated in November?". The QA lead red-teams the demo from there.
6. The panel signs off when `pytest -m "not live"` is green and the end-to-end test passes from a clean reset with networking off.
