# 4 · UX / Design Lead — Plan

**North star:** the Demo View workbook turned into a working app. A BMO PM should recognise every box, label and yellow button from the Excel file, and every one of them should work. No marketing chrome or decorative charts. Every label is a business term.

References: the Excel Demo View tab for structure; the roadmap deck for colour and the MVP 1 dashboard.

---

## 1. Information architecture

### 1.1 Shell (at every width ≥1280px)

```
┌──────────────────────────────────────────────────────────────────────────────────────────┐
│ BMO  Digital Channels · Project Management Tool   [Search RDDC # or name…]  ● Simulated AI  [Ask Assistant] AS │  ← navy bar 56px
├───────────────┬──────────────────────────────────────────────────────────────┬───────────┤
│ INITIATIVES   │  page content (max-width 1440, 24px padding)                  │ Assistant │
│ + Add New     │                                                              │ (drawer,  │
│   Initiative  │                                                              │  380px,   │
│ ✎ Edit        │                                                              │  closed   │
│   Initiative  │                                                              │  by       │
│ ⌕ Search      │                                                              │  default) │
│   Initiative  │                                                              │           │
│ ▦ Portfolio   │                                                              │           │
│   View        │                                                              │           │
│ ───────────── │                                                              │           │
│ DELIVERY      │                                                              │           │
│ Intake &      │                                                              │           │
│   Grooming 3  │                                                              │           │
│ Resources     │                                                              │           │
│ Risk Register │                                                              │           │
│ Change Mgmt   │                                                              │           │
│ Artifacts     │                                                              │           │
│ ───────────── │                                                              │           │
│ ⚙ Settings    │                                                              │           │
└───────────────┴──────────────────────────────────────────────────────────────┴───────────┘
   rail 216px, white, 1px right border. The top group copies the four Excel buttons word for word.
```

| Rail item | Route | What it is |
|---|---|---|
| Add New Initiative | `#/initiative/new` | Empty workspace opened on Pg 1. Requires RDDC # and Project Name before the first save. |
| Edit Initiative | `#/initiative/:id/pg1` | Opens the last initiative you viewed. With none, it opens the Search Initiative picker. |
| Search Initiative | `#/search` | Filter table: RDDC #, Project Name, LOB, DC PM, Stage, RAG. Click a row to open its workspace. |
| Portfolio View | `#/portfolio` | Excel Pg 5 at portfolio scope (see §2.5) |
| Intake & Grooming | `#/intake` | RDDC queue (To Do / Slotted / Groomed), next grooming session, reminders |
| Resources | `#/resources` | Team capacity bars, resource × month heatmap, PRN burndown, skill matrix |
| Risk Register | `#/risks` | All risks across initiatives with a 5×5 matrix |
| Change Mgmt | `#/changes` | This week's CRQs for review, compliance flags |
| Artifacts | `#/artifacts` | Document Repository · Decision Log · Meeting Notes · Lessons Learned |
| Settings | `#/settings` | AI mode, simulated latency, demo data reset |

### 1.2 Initiative workspace

```
┌ RDDC-10482 · US API Enhancement                         [Amber] Stage: Development   [Ask about this initiative] ┐
│ LOB Personal Banking (US) · DC PM Maya Chen · Target Release R26.02 · Last saved 2 min ago                      │
│ ① Intake ✓ ── ② DC Component ✓ ── ③ WBS ● ── ④ Resource + Timeline ○ ── ⑤ Automated Views ○                    │
├─────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ [Pg 1 General Details] [Pg 2 Project Plan] [Pg 3 Resource Management] [Pg 4 Change Governance] [Pg 5 Portfolio View] │
└─────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

- **Decision: one tab per page, not a single scroll.** Each tab shows one page box styled like the Excel box: a bordered section with a small "PG 2" eyebrow and the page title. Tabs keep the projector view uncluttered and give each step its own URL (`/pg2`). Choose **"Print view"** to show all five pages stacked, the way the workbook looks.
- The stepper doubles as navigation. Each step opens its page: Intake → Pg 1 header fields, DC Component → Pg 1 change-summary table, WBS → Pg 2, Resource + Timeline → Pg 3, Automated Views → Pg 5. Pg 4 (governance) is not on the stepper because it follows the build steps (MVP2).
- The header RAG and Stage are always visible and are recalculated after each save.

### 1.3 AI touch points (all yellow automation buttons)

| Page | Button | Output |
|---|---|---|
| Pg 1 | Generate Change Summary | DC Component / Approval / Change Summary rows plus SA Completeness % |
| Pg 2 | Generate Plan | WBS rows (from the Change Summary) |
| Pg 2 | Generate Gantt view | Gantt (deterministic, no AI wait) |
| Pg 3 | Suggest Resources | Ranked "Recommended Developer" cards |
| Pg 5 / Risk Register | Identify Risks | Risk rows with severity, likelihood and mitigation |
| Pg 5 | Write Executive Summary | Four-sentence status note |
| Pg 4 | Check CR Compliance | List of compliance gaps |
| Intake | Schedule Grooming / Send Reminders | Draft slots and reminder emails (preview only, nothing sent) |

---

## 2. Wireframes

### 2.1 Pg 1 — General Details

```
┌ PG 1 ─ General Details ─────────────────────────────────────────────────────────────────────┐
│ ┌──────────────────┬───────────────────┐        ┌──────────────────┬────────────────────────┐ │
│ │ RDDC #           │ RDDC-10482        │        │ DC Intake        │ DCI-2291               │ │
│ │ Current Status   │ [In progress ▾]   │        │ Labels           │ API · US · Mobile      │ │
│ │ Assigned To      │ Maya Chen         │        │ Requestor        │ R. Patel (USPB)        │ │
│ ├──────────────────┼───────────────────┤        ├──────────────────┼────────────────────────┤ │
│ │ PM               │ Maya Chen         │        │ SA document      │ ┌ ⤓ Drop SA document ┐ │ │
│ │ Tech/Dev Lead    │ Daniel Okafor     │        │                  │ │ here or Browse     │ │ │
│ ├──────────────────┼───────────────────┤        │                  │ │ PDF · DOCX · TXT   │ │ │
│ │ DC PM            │ Maya Chen         │        │                  │ └────────────────────┘ │ │
│ │ DC SA            │ Luis Ortega       │        │ Author           │ Luis Ortega            │ │
│ └──────────────────┴───────────────────┘        ├──────────────────┼────────────────────────┤ │
│                                                  │ DC SA            │ Luis Ortega            │ │
│                                                  │ SA Completeness  │ ▓▓▓▓▓▓▓░░ 78%  [AI]    │ │
│                                                  └──────────────────┴────────────────────────┘ │
│ Description of Change                                                                         │
│ ┌───────────────────────────────────────────────────────────────────────────────────────────┐ │
│ │ Expose account-aggregation endpoints to the US mobile app via EAPI; add step-up MFA …      │ │
│ └───────────────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                               │
│ [✦ Generate Change Summary]  (populated from SA document attachment)                          │
│ ┌──────────────────┬───────────────┬────────────────────────────────────────────────────────┐ │
│ │ DC Component     │ Approval      │ Change Summary                                         │ │
│ ├──────────────────┼───────────────┼────────────────────────────────────────────────────────┤ │
│ │ API Platform     │ [Pending ▾]   │ New /accounts/aggregate endpoint, rate-limited …   [AI]│ │
│ │ CIAM             │ [Approved ▾]  │ Step-up MFA on aggregation consent …               [AI]│ │
│ │ SRE              │ [Pending ▾]   │ New dashboards and alerts for p95 latency …        [AI]│ │
│ │ + Add component                                                                         │ │
│ └──────────────────┴───────────────┴────────────────────────────────────────────────────────┘ │
│                                                         [Discard changes]  [Save Pg 1]        │
└───────────────────────────────────────────────────────────────────────────────────────────────┘
```

- Dropzone states: *empty* (dashed border) → *drag-over* (blue border, tint `--blue-50`) → *uploading* (bar) → *attached* (file chip `SA_US_API_v3.pdf · 412 KB · ✕ Remove` plus a "View" link).
- Generate Change Summary is disabled until an SA document is attached. Hover text: "Attach the SA document first."
- With a demo sample attached, the button runs the thinking steps (§5). An AI result card (§2.7) then appears above the table. Accept writes the rows.

### 2.2 Pg 2 — Project Plan

```
┌ PG 2 ─ Project Plan ──────────────── (WBS to be auto-populated from Change Summary) ─────────────┐
│ [✦ Generate Plan]  [+ Add step]  [↑↓ Reorder]                               Filter: [All ▾]         │
│ ┌───┬───────────────────┬──────────────┬────────────┬────────────┬────────┬────────┬──────────┬────┬─────────┐ │
│ │WBS│ WBS Steps         │ Description  │ SME/Owner  │ Resource   │ Start  │ End    │ Status   │ %  │Comments │ │
│ ├───┼───────────────────┼──────────────┼────────────┼────────────┼────────┼────────┼──────────┼────┼─────────┤ │
│ │100│ Estimation        │ L2 + SA sign │ L. Ortega  │ L. Ortega  │ 03 Nov │ 14 Nov │[Complete]│100 │         │ │
│ │110│  └ L2 estimate    │ …            │ D. Okafor  │ D. Okafor  │ 03 Nov │ 07 Nov │[Complete]│100 │         │ │
│ │200│ Development       │ EAPI build   │ D. Okafor  │ EAPI Dev1 ▾│ 17 Nov │ 23 Jan │[In prog.]│ 35 │ ⚠ SA cap│ │
│ │300│ Integration / QA  │ SIT + UAT    │ QA Lead    │ —  ⚠       │ 26 Jan │ 20 Feb │[Backlog] │  0 │         │ │
│ │400│ Production        │ CRQ + PIV    │ CMS Lead   │ SRE ▾      │ 23 Feb │ 27 Feb │[Backlog] │  0 │         │ │
│ └───┴───────────────────┴──────────────┴────────────┴────────────┴────────┴────────┴──────────┴────┴─────────┘ │
│ Depends on: column hidden by default → "Show dependencies" toggle adds a "Predecessor" column (e.g. 200 → 300)  │
│                                                                                                    │
│ [✦ Generate Gantt view]  (auto-populated from Project Plan)          Scale: (Week) (●Month)  ☐ Critical path │
│ ┌─────────────────────┬──── Nov ────┬──── Dec ────┬──── Jan ────┬──── Feb ────┬─ Mar ─┐               │
│ │ 100 Estimation      │ ████        │             │      ┆      │             │       │               │
│ │ 200 Development     │      ███████│█████████████│██████┆      │             │       │               │
│ │ 300 Integration/QA  │             │             │      ┆ └──▶█│██████       │       │               │
│ │ 400 Production      │             │             │      ┆      │       └──▶██│       │               │
│ └─────────────────────┴─────────────┴─────────────┴──Today 19 Jan┴─────────────┴───────┘               │
│                                                               [Discard changes]  [Save Pg 2]       │
└────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

- Grid behaves like Excel. Click a cell to edit it. Tab or Enter moves to the next cell, Esc cancels. Status uses the Sheet1 list (Backlog / In progress / Completed). Dates use a date picker. % is 0–100 with a mini bar. Child rows are indented with └.
- Validation is inline. An End date before the Start date shows a red cell border and the note "End date is before start date." A missing Resource shows ⚠ and feeds the Resources RAG.
- Edits in the grid redraw the Gantt live without another click. The "Generate Gantt view" button stays for Excel parity and also scrolls to the chart.

### 2.3 Pg 3 — Resource Management

```
┌ PG 3 ─ Resource Management ────────────────────────────── Fiscal year FY26 (Nov–Oct) ▾ ─┐
│ Hours per quarter                                                                         │
│ ┌──────────────────┬──── Nov–Jan ────┬──── Feb–Apr ────┬──── May–Jul ────┬── Aug–Oct ──┐ │
│ │ Resource Name    │ Availability│Alloc│ Availability│Alloc│ Availability│Alloc│ Avail│Alloc │ │
│ ├──────────────────┼─────────────┼─────┼─────────────┼─────┼─────────────┼─────┼──────┼──────┤ │
│ │ Daniel Okafor    │ 420 h       │ 468 │ 450 h       │ 210 │ 450 h       │  0  │ 450  │  0   │ │ ← 468 red (111%)
│ │ Priya Raman      │ 420 h       │ 300 │ …                                                    │
│ │ Luis Ortega (SA) │ 210 h       │ 260 │ …                                                    │ ← red
│ └──────────────────┴─────────────┴─────┴─────────────┴─────┴─────────────┴─────┴──────┴──────┘ │
│ Availability is editable (Account Manager). Allocation is calculated from Pg 2 assignments.   │
│                                                                                           │
│ Monthly allocation          Nov   Dec   Jan   Feb   Mar   Apr                              │
│ Daniel Okafor              [ 90][118][124][ 60][ 40][  0]   % of available hours          │
│ Priya Raman                [ 70][ 75][ 70][ 50][ 20][  0]                                  │
│ Luis Ortega (SA)           [110][135][ 95][ 30][  0][  0]                                  │
│ Legend: □0  ░1–50  ▒51–80  ▓81–100  ■ over 100                                             │
│                                                                                           │
│ [✦ Suggest Resources]  for: [300 Integration / QA ▾]                                      │
│ ┌ 1 Aisha Khan · QA Analyst · 92% match ───┐ ┌ 2 Tom Reid · 81% ──┐ ┌ 3 … ┐               │
│ │ Has worked on: EAPI, CIAM SIT (4 proj.)  │ │ …                  │ │     │               │
│ │ Free Jan 26–Feb 20: 140 h (85%)          │ │                    │ │     │               │
│ │ [Assign to WBS 300]                      │ │ [Assign]           │ │     │               │
│ └──────────────────────────────────────────┘ └────────────────────┘ └─────┘               │
└───────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2.4 Pg 4 — Change Governance

```
┌ PG 4 ─ Change Governance ─────────────────────────────────────────── [✦ Check CR Compliance] ┐
│ ┌──────────────────────────┬──────────────────┐   ┌──────────────────────────┬──────────────┐ │
│ │ CRQ/RCSR #               │ CRQ000731455     │   │ CMS Lead                 │ J. Martin    │ │
│ │ CRQ Start Date and Time  │ 24 Feb 2026 22:00│   │ Rel Lead                 │ S. Gill      │ │
│ │ CRQ End Date and Time    │ 25 Feb 2026 02:00│   │ Resource                 │ SRE on-call  │ │
│ │ Release Type             │ [Bundle ▾]       │   └──────────────────────────┴──────────────┘ │
│ │ Release Train/Sprint     │ R26.02 / S14     │                                                │
│ ├──────────────────────────┼──────────────────┤   ┌──────────────────────────┬──────────────┬─────────────┐ │
│ │ Affected CIs             │ eapi-gw, ciam-mfa│   │ Implementation Status    │ [Not Started▾]│             │ │
│ │ Target Release           │ R26.02           │   │ Technical Validation St. │ [In progress▾]│ ⤓ Attach    │ │
│ │ Impacted Component       │ API Platform     │   │ Business Validation St.  │ [Not Started▾]│ ⤓ Attach    │ │
│ │ Implementation Status    │ [Not Started ▾]  │   └──────────────────────────┴──────────────┴─────────────┘ │
│ │ CRQ Approval Status      │ [Pending ▾]      │                                                │
│ ├──────────────────────────┼──────────────────┤   Compliance: ⚠ 2 items need attention          │
│ │ STO Approval             │ [Tentative Go ▾] │   • Business validation evidence missing         │
│ └──────────────────────────┴──────────────────┘   • CRQ window overlaps freeze (20–28 Feb)       │
└──────────────────────────────────────────────────────────────────────────────────────────────────┘
```

The two attachment cells use the yellow automation styling, as in Excel.

### 2.5 Pg 5 — Portfolio View (MVP1 dashboard, matches the deck slide)

Scope switch: **(● This initiative) ( All initiatives )**. The rail's Portfolio View opens with "All initiatives" selected.

```
┌ PG 5 ─ Portfolio View ─────────────────── [✦ Identify Risks] [✦ Write Executive Summary] ┐
│ ┌ PROJECT HEALTH ──── [Amber] ┐ ┌ RESOURCE CAPACITY ─────────────┐ ┌ PROJECT GANTT ─────────┐ │
│ │ Schedule        ● Amber     │ │ EAPI (Dev1) ███████████▌  112% │ │ Estimation  ██          │ │
│ │ Resources       ● Red       │ │ EAPI (Dev2) ███████░░░░    68% │ │ Development   ██████    │ │
│ │ Scope           ● Green     │ │ CIAM        █████████░░    86% │ │ QA                ███   │ │
│ │ Dependencies    ● Green     │ │ SRE         ████░░░░░░░    41% │ │ Production          ██  │ │
│ │ ─────────────────────────── │ │ ▇ confirmed ▨ tentative ▢ avail│ │        ┆Today         │ │
│ │ Management attention:       │ │ Nov–Jan ▾                      │ │                        │ │
│ │ SA capacity constraint      │ └────────────────────────────────┘ └────────────────────────┘ │
│ │ affecting WBS-100           │                                                               │
│ └─────────────────────────────┘                                                               │
│ Project Dashboard                                                                             │
│ ┌──────────┬────────────────────┬──────┬────────┬────────────┬───────┬──────────┬──────────┬───────────┬─────────┐ │
│ │Intake/RDDC│ Project Name      │ LOB  │ DC PM  │ Stage      │ RAG   │ Dev Start│ QA Sign-off│ Prod/Final│Comments │ │
│ │RDDC-10482 │ US API Enhancement│ USPB │ M. Chen│ Development│[Amber]│ 17 Nov   │ 20 Feb   │ 27 Feb    │ SA cap. │ │ ← highlighted
│ │RDDC-10377 │ CIAM Passkeys     │ CPB  │ …      │ QA         │[Green]│ …        │          │           │         │ │
│ └──────────┴────────────────────┴──────┴────────┴────────────┴───────┴──────────┴──────────┴───────────┴─────────┘ │
│ Change Management                                    From [01 Feb] To [28 Feb]                │
│ ┌──────────────┬──────────┬──────────┬──────────┬───────────────┬───────────────┬───────────────┐ │
│ │Intake/Release│ CMS Lead │ Rel Lead │ Resource │ Implementation│ Tech Validation│ Bus Validation│ │
│ └──────────────┴──────────┴──────────┴──────────┴───────────────┴───────────────┴───────────────┘ │
└───────────────────────────────────────────────────────────────────────────────────────────────┘
```

In "All initiatives" scope, the Health card shows portfolio counts (`3 Red · 5 Amber · 9 Green`) and the Gantt shows one bar per initiative. Clicking a row opens that initiative's workspace.

### 2.6 AI Assistant panel (right drawer)

```
┌ Assistant ─────────────────── ● Simulated ✕ ┐
│ Context: RDDC-10482 · Pg 2 Project Plan      │
├──────────────────────────────────────────────┤
│ Try:                                          │
│ (What's driving the Amber?) (Who's free in Jan?)│
│ (Summarise for the steering call)             │
│                                               │
│ You: Why is Resources red?                    │
│                                               │
│ Assistant:                                    │
│ ✓ Checked Pg 3 allocations                    │
│ ✓ Checked WBS 200–300 assignments             │
│ Luis Ortega (DC SA) is at 135% in December    │
│ because WBS 110 and RDDC-10377 overlap. WBS   │
│ 300 also has no QA resource assigned.▌        │
│ Sources: Pg 3 · WBS 300 · RDDC-10377          │
│ [Open Pg 3]  [Suggest Resources for WBS 300]  │
├──────────────────────────────────────────────┤
│ [Ask about this initiative…            ] [➤]  │
└──────────────────────────────────────────────┘
```

At widths ≥1600px the drawer pushes the content aside. Below 1600px it overlays the content with a scrim. Action chips run real app actions. Source chips link to the page or row they cite.

### 2.7 AI result card pattern

```
┌ ✦ AI suggestion · Change Summary ─────────── Confidence [High 86%] ─ 2.4 s ┐
│ 3 DC components identified · SA Completeness 78%                           │
│ ┌ API Platform │ Pending │ New /accounts/aggregate endpoint … ┐ (preview)   │
│ │ CIAM         │ Approved│ Step-up MFA on consent …            │             │
│ └ SRE          │ Pending │ Alerts for p95 latency …            ┘             │
│ Sources: SA_US_API_v3.pdf §2.1 p.3 · §4 p.7 · §6 p.11                      │
│ Gaps found: Non-functional requirements section is empty (−22%)            │
├────────────────────────────────────────────────────────────────────────────┤
│ [Accept]  [Edit before accepting]  [Regenerate]           Discard          │
└────────────────────────────────────────────────────────────────────────────┘
```

- Confidence pill: High ≥80% (green tint), Medium 60–79% (amber tint), Low <60% (red tint, with the note "Review carefully").
- Accept writes the values to the page. Edit opens the preview as an editable table and Accept stays available. Regenerate keeps the card and replays a shorter 2-step thinking sequence. Discard collapses the card. Nothing is written until Accept.
- Footer note: "Generated by Simulated AI" or "Generated by Claude". The same wording is stored in the activity log.

---

## 3. Design system

### 3.1 Tokens

```css
:root{
  /* brand */
  --bmo-blue:#0079C1; --bmo-blue-600:#00639E; --blue-50:#E8F3FA; --blue-100:#CCE6F5;
  --navy:#0A2240; --navy-700:#13325A; --bmo-red:#E1251B;           /* red: logo mark only */
  /* step chips (deck "What are we building?" slide) */
  --step-intake:#0079C1; --step-dc:#00A3AD; --step-wbs:#6B3FD4;
  --step-resource:#2F6FDE; --step-views:#1DB45A;
  /* phase colours for Gantt (deck MVP 1 dashboard slide) */
  --ph-estimation:#0079C1; --ph-dev:#6B3FD4; --ph-qa:#00A3AD; --ph-prod:#1DB45A;
  /* RAG */
  --rag-red:#D93025;   --rag-red-bg:#FDECEA;
  --rag-amber:#F2A900; --rag-amber-bg:#FFF4D6; --rag-amber-text:#8A5A00;
  --rag-green:#1E8E3E; --rag-green-bg:#E6F4EA;
  /* automation (Excel yellow, softened) */
  --auto-bg:#FFE066; --auto-bg-hover:#FFD633; --auto-border:#D4A800; --auto-text:#0A2240;
  --ai-fill:#FFF8D1;                                               /* diff highlight */
  /* neutrals */
  --ink:#1B2533; --ink-2:#4A5868; --ink-3:#7A8796; --line:#C9D3DE; --line-soft:#E3E9EF;
  --cell-label:#F4F7FA; --surface:#FFFFFF; --canvas:#F5F7FA;
  /* type */
  --font:"Segoe UI",-apple-system,"Helvetica Neue",Arial,sans-serif;
  --fs-11:11px; --fs-12:12px; --fs-13:13px; --fs-14:14px; --fs-16:16px; --fs-20:20px; --fs-24:24px; --fs-32:32px;
  /* spacing (4px base) */
  --s1:4px; --s2:8px; --s3:12px; --s4:16px; --s5:24px; --s6:32px; --s7:48px;
  /* radius & elevation */
  --r-sm:4px; --r-md:8px; --r-lg:12px; --r-pill:999px;
  --sh-1:0 1px 2px rgba(10,34,64,.08);
  --sh-2:0 4px 12px rgba(10,34,64,.10);
  --sh-3:0 12px 32px rgba(10,34,64,.18);
  --row-h:32px; --rail-w:216px; --drawer-w:380px;
}
```

Body text is 14px (dense, like the workbook). Page titles are 20px semibold. Eyebrows ("PG 1", card headers) are 11px, uppercase, letter-spacing .06em, colour `--ink-3`. All numbers use `font-variant-numeric: tabular-nums`. The app is light theme only, since the projector demo needs fixed contrast.

### 3.2 Components

| Component | Spec |
|---|---|
| **Page box** | 1px `--line` border, `--r-md`, white background, 24px padding. Header shows the eyebrow "PG n", the title, and an optional italic hint in `--ink-3` such as "(auto-populated from Project Plan)". |
| **Label-value grid** | Two-column bordered table. Label cell: `--cell-label`, 13px, `--ink-2`, 168px wide. Value cell: white, editable on click (focus ring 2px `--bmo-blue`). Rows are `--row-h`. Groups are separated by a 12px gap, as in Excel's stacked mini-tables. |
| **Editable table** | Sticky header in `--cell-label`, 1px grid lines, row hover `--blue-50`. The selected cell gets a 2px blue outline (Excel cell selection). Supports keyboard navigation, inline selects and date pickers, and a "+ Add …" footer row. Dirty cells show a 3px blue left tick until saved. |
| **Buttons** | *Primary* (blue fill, white text): Save. *Secondary* (white, 1px line): Discard, Cancel. *Automation* (`--auto-bg`, 1px `--auto-border`, navy text, ✦ glyph, 32px tall): every AI or automation hook. *Danger text*: Reset demo data. Disabled state is 45% opacity with a hover reason. |
| **Pills** | RAG pill: tinted background, coloured 8px dot plus the word (never colour alone). Status pill: Backlog grey, In progress blue, Completed green, Failed red. Confidence pill as in §2.7. "AI" tag: 10px uppercase, `--auto-bg`, `--r-sm`. |
| **Step chips / stepper** | Five chips in the step colours. *Done*: filled with a ✓. *Current*: filled with a 3px outer ring of the same colour at 30%. *To do*: white with a coloured 1px border and coloured text. The connector line turns solid once the left step is done. Each initiative stores its progress; the Search table shows a mini 5-dot version. |
| **Dropzone** | 96px tall, dashed 1.5px `--line`, centred icon and the text "Drop SA document here or Browse". States as in §2.1. |
| **Toast** | Bottom-right, navy background, white text, 4s, max 3 stacked. Variants are success ✓ and warning ⚠. Includes an optional "Undo" for Accept and delete actions. |
| **Modal** | 560px, used only for destructive or blocking actions (Reset demo data, delete initiative). |
| **Drawer** | Right, 380px. Used by the Assistant and the "Risk detail" view. Esc closes it. |
| **Skeleton loader** | `--line-soft` blocks with a shimmer. Used only on first load of a page, never for AI (AI uses thinking steps). |
| **Empty state** | Icon outline, one sentence, one action button. Copy in §6. |
| **Activity log** | Collapsible footer on each page, for example "14:02 · Change Summary accepted (Simulated AI) · Maya Chen". |

### 3.3 Layout rules

- Grid uses a 12-column content area with 24px gutters. Pg 1 places its two blocks in columns 1–5 and 7–12, copying Excel's empty middle column.
- **1280px:** rail 216px and content about 1016px. The WBS table scrolls horizontally inside its box, with WBS # and Steps frozen. The dashboard's three cards stack as 2 + 1. The Assistant overlays.
- **1920px:** content capped at 1440px and centred. The Assistant pushes the content.

---

## 4. Chart specs (hand-rolled SVG)

All charts share these rules: 12px labels in `--ink-2`, gridlines 1px `--line-soft`, no chart borders. Tooltips are HTML divs (navy background, 12px, 8px padding) that follow the pointer. Every coloured mark also carries a text label or value.

### 4.1 Gantt

- Label column 240px (WBS # and step name, children indented 16px). Row height 32px, bar height 14px, radius 3px.
- **Scale toggle:** Week (header "W/C 03 Nov", 28px per week) or Month (header "Nov 25", 96px per month). Fiscal quarters get alternating background bands (`#FAFBFD`/white) labelled "Q1 FY26" above the months.
- **Colour by** toggle: *Phase* (default, deck colours) or *Status* (Backlog `#B8C2CC`, In progress `--bmo-blue`, Completed `--rag-green`, At risk `--rag-amber`, Late `--rag-red`). A bar counts as Late when today is after the End date and it is under 100%.
- **Progress:** the full bar is drawn at 35% opacity and the completed portion is solid on top. The percentage label sits to the right of the bar.
- **Today line:** 2px dashed `--navy` running the full height, with a top label pill reading "Today 19 Jan".
- **Dependencies:** finish-to-start elbow connectors (8px horizontal stub, vertical, then horizontal into the successor). 1.25px `--ink-3` with a 6px arrowhead. Hovering a bar highlights its connectors.
- **Critical path** (checkbox): the longest zero-slack chain, computed client-side. Critical bars get a 2px `--navy` outline and connectors become 2px navy. Non-critical bars dim to 40%. Legend: "Critical path: 100 → 200 → 300 → 400 · 17 weeks".
- **Milestones:** diamond (10px) for zero-length rows (QA Sign-off, Prod).
- Dragging bars is out of scope for the demo. Dates are edited in the grid only.

### 4.2 Capacity heatmap (resource × month)

- Cells are 56×28px and show the % value. Rows are resources grouped by team. Columns are fiscal months with quarter headers matching Pg 3 (Nov–Jan …).
- Scale: 0 → `#F2F5F8`; 1–50 → `#D6EAF5`; 51–80 → `#8CC4E6`; 81–100 → `--bmo-blue` with white text; >100 → `--rag-red` with white bold text and a ▲ marker.
- Tooltip example: "Luis Ortega · Dec · 162 h of 120 h available (135%) — US API Enhancement 110 h, CIAM Passkeys 52 h".
- Clicking a cell filters the Pg 2 or Resources table to that person and month.

### 4.3 Team capacity bars (demand vs availability)

- One horizontal row per team (EAPI (Dev1), EAPI (Dev2), CIAM, SRE). Track = availability (1px `--line` outline, length 100%). Confirmed demand is a solid `--bmo-blue` fill. Tentative demand is the same blue at 40% with 45° hatching. Any part beyond 100% is `--rag-red` and runs past the track end. A label on the right shows "112% · 470 / 420 h".
- Period selector: Nov–Jan / Feb–Apr / May–Jul / Aug–Oct.

### 4.4 PRN burndown (charged vs available)

- Stat row above the chart: `PRN 4471-22 · Budget 1,200 h · Charged 640 h · Remaining 560 h · Burn 46 h/wk · Exhausted by 06 Mar`.
- Lines: *Available (plan)* is dashed `--ink-3`, a straight line from budget to 0 at the planned end. *Remaining (actual)* is solid `--bmo-blue` with 3px dots at month ends. *Forecast* is dotted blue, extended at the current burn rate. If the forecast reaches 0 before the planned end, the gap between the forecast and plan is filled `--rag-red-bg` and labelled "Overrun risk: 3 weeks early".
- Today line as in the Gantt.

### 4.5 RAG health tiles

- One overall tile (pill size 16px) plus four dimension rows (Schedule, Resources, Scope, Dependencies), each with a word pill. Hovering a dimension shows the rule that produced it, for example "Resources = Red: 1 person >120% in the next 60 days". The "Management attention" line shows the top driver in plain words.
- Manual override: click a pill, choose a value and enter a reason (required). An "Overridden" tag then shows next to the pill (deck action 02: manual vs calculated).

---

## 5. Micro-interactions: making simulated AI feel real

1. **Thinking steps.** Clicking an automation button shows an inline panel in place of the result card. Each step goes ○ → spinner → ✓, with 400–900ms of jitter per step and 1.5–3s in total. Step lists:
   - *Generate Change Summary:* Reading SA document (12 pages)… → Identifying impacted DC components… → Matching components to approvers… → Drafting change summary… → Scoring SA completeness…
   - *Generate Plan:* Reading change summary… → Applying DC WBS template… → Sequencing dependencies… → Estimating effort from L2… → Proposing owners…
   - *Suggest Resources:* Checking skill matrix… → Checking availability Jan–Feb… → Ranking candidates…
   - *Identify Risks:* Reviewing plan dates and allocations… → Comparing with past initiatives… → Rating severity and likelihood…
   - *Generate Gantt view* (deterministic): a single 300ms "Building timeline…" step. It should not look like AI.
2. **Streaming reveal.** Free text appears in 2–4 character chunks every 18–30ms with a blinking ▌ caret. Table rows appear one at a time with a 120ms stagger and a fade-up of 4px.
3. **Diff highlighting on Accept.** Each AI-filled cell gets a `--ai-fill` background that fades to white over 1.5s and keeps a small "AI" tag. When a field had a previous value, hovering shows "Was: …", and the toast offers "Undo". Once a user edits the cell, the tag changes to "Edited", so viewers can see which values a person changed.
4. **Ripple to dependent views.** After Accept on Pg 2, the stepper chip animates to ✓ and the header RAG pill pulses once if it changed. A toast reads "Plan updated · Gantt, capacity and health recalculated."
5. **Cancel and speed.** While steps run, the button reads "Stop". Settings has "AI response speed: Realistic / Fast (for rehearsal)". `prefers-reduced-motion` skips the streaming and fades.
6. **Live Claude mode** uses the same UI. Its steps advance on real stream events, and the footer reads "Generated by Claude".

---

## 6. Copy guidelines and exact strings

**Rules:** write the way a PM would. Use sentence case, except proper workbook labels, which keep Excel casing ("SA document", "CRQ/RCSR #"). Use "initiative" in navigation and "intake" only for the RDDC queue. Never show words like *JSON, API key, endpoint, model, token, LLM, null, error 500*. Dates are written "19 Jan 2026" and hours "120 h". Write AI output in plain sentences and avoid hedging filler. Keep tooltips to one sentence.

**Screen titles:** Add New Initiative · Edit Initiative · Search Initiative · Portfolio View · Pg 1 General Details · Pg 2 Project Plan · Pg 3 Resource Management · Pg 4 Change Governance · Pg 5 Portfolio View · Intake & Grooming · Resources · Risk Register · Change Management · Artifacts · Settings.

**Buttons:** Save Pg n · Discard changes · Generate Change Summary · Generate Plan · Generate Gantt view · Suggest Resources · Assign to WBS nnn · Identify Risks · Write Executive Summary · Check CR Compliance · Schedule for Next Grooming · Send Reminders (preview) · Accept · Edit before accepting · Regenerate · Discard · Stop · + Add step · + Add component · + Add risk · Show critical path · Ask Assistant · Reset demo data · Load sample initiatives · Print view.

**Empty states:**
- Pg 1 change summary: "No DC components yet. Attach the SA document and click Generate Change Summary, or add a component yourself."
- Pg 2: "No project plan yet. Generate one from the Change Summary, or add steps manually."
- Gantt: "The Gantt view appears once the plan has steps with start and end dates."
- Pg 3: "No one is assigned yet. Assign resources on Pg 2, or click Suggest Resources."
- Pg 4: "No change request logged. Add the CRQ/RCSR # when the change is raised."
- Risk Register: "No risks recorded. Click Identify Risks to review the plan, or add one."
- Search: "No initiatives match 'xyz'. Check the RDDC # or clear filters."
- Intake queue: "Nothing waiting for grooming. New RDDC tickets will appear here."
- Artifacts: "No documents yet. Drop files here to add them to this initiative."
- Assistant: "Ask about this initiative's plan, people or risks."

**Toasts and messages:** "Pg 2 saved." · "Change Summary accepted · 3 components added." · "Resources is now Red — Luis Ortega is over 120% in Dec." · "Couldn't read this file. Try a PDF, DOCX or TXT under 10 MB." · "Live Claude is unavailable — switched to Simulated AI." · Reset modal: "Reset demo data? All initiatives return to the starting sample. This can't be undone." [Cancel] [Reset demo data]

**Settings:** AI mode: (● Simulated AI) (Live Claude). The note under Live Claude reads either "Connected" or "Not configured on this machine". AI response speed: Realistic / Fast. Fiscal year starts: November. Demo data: Load sample initiatives · Reset demo data. The top-bar badge always shows the current mode. Simulated is grey-blue, "● Simulated AI". Live is green, "● Live Claude".
