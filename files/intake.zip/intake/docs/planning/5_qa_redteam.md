# 5 — QA Lead / Red-Team / Demo-Readiness Plan

Owner: QA Lead. Scope: DC Intake & PM tool demo (Flask + SQLite + vanilla JS SPA, simulated/live AI).
Rule zero: **nothing is "done" because an agent says so. It is done when a test that someone else wrote passes.**

Tooling confirmed on this machine: `python3` (venv `.venv`), `pytest`, `playwright` (chromium), `ruff`, `node` (for `node --check`).

---

## 0. Pinned conventions QA will enforce (assert these, don't debate them in QA)

If the Architect doc says otherwise, the Architect doc wins — but the values must then be pinned in `tests/golden/*.json` before L3 starts. Tests must never compute expected values with the same code under test.

- **Dates are ISO strings `YYYY-MM-DD`** in DB and JSON. Datetimes (CRQ start/end) are ISO with explicit offset `America/Toronto`. JS never calls `new Date('YYYY-MM-DD')` (UTC parse → shows the previous day in Toronto). One `dates.js` helper parses as local.
- **BMO fiscal year starts 1 Nov.** FY26 = 2025-11-01..2026-10-31. Q1 Nov–Jan, Q2 Feb–Apr, Q3 May–Jul, Q4 Aug–Oct.
- **"Today" is injectable** (`DEMO_TODAY` env / `?today=`), default `2026-10-19` for tests, so health/burndown/grooming are deterministic.
- **RAG roll-up** must reproduce the deck: Schedule Amber + Resources Red + Scope Green + Deps Green ⇒ **Overall Amber**. So it is *not* worst-of. Rule: Red if ≥2 dimensions Red; else Amber if any Red/Amber; else Green.
- **Capacity status:** allocation/availability >100% Red, 85–100% Amber, <85% Green.
- **Simulated AI is byte-identical across runs** (seeded, no `random()` without seed, no timestamps in output).

---

## 1. Lines of Defense

| Line | Owner | Entry criteria | Exit criteria |
|---|---|---|---|
| **L1 Builder self-check** | Each builder agent | Code written for its slice | `ruff check .` = 0 errors (F-rules at minimum); `python -m compileall -q app` OK; `node --check` on every `static/js/*.js`; app boots via `python run.py` and `GET /api/health` → 200; builder's own smoke test for its slice passes; no `TODO`, `pass`-stubs, or `console.log` left in shipped paths. Builder posts a 5-line handoff: files touched, endpoints, how to verify. |
| **L2 API contract** | QA agent A (not a builder) | All builders at L1 exit; API contract doc frozen | `pytest tests/api` green. Every route in `app.url_map` has ≥1 happy-path and ≥1 bad-input test (auto-check: a meta-test enumerates `url_map` and fails if a route is untested). No 500 for any malformed input — 400/404/422 with JSON `{error}`. |
| **L3 Engine unit** | QA agent B | Engines importable without Flask | `pytest tests/engine` green against hand-computed golden values (§2 E-cases). 100% branch coverage on `rag.py`, `capacity.py`, `fiscal.py`; ≥90% on others. |
| **L4 E2E browser** | QA agent C | L2+L3 green | `pytest tests/e2e` (Playwright, chromium, headless + one headed run) walks full demo script with `timezone_id='America/Toronto'` **and** re-runs once with `'Pacific/Auckland'`. Global fixtures fail any test on: `console.error`, `pageerror`, any response status ≥500, any request failure, unhandled rejection. Screenshots of each screen saved to `tests/e2e/artifacts/`. |
| **L5 Adversarial review** | Red-team agent (did not write code) | L4 green | Written findings list, each tagged Blocker/Major/Minor. Checklist: dead buttons (every `<button>` has a handler — grep + click-all sweep); every `fetch` has `.catch` + UI error state; every spinner has a timeout (≤20 s) and a recovery; `innerHTML` with user/AI text (must use `textContent` or `esc()`); f-string SQL (must be `?` params); upload: extension+MIME+size limit (10 MB), `secure_filename`, stored outside `static/`, corrupt file → 422 not 500; date/timezone; empty states for every list/chart; double-submit; Excel formula injection (`=`, `+`, `-`, `@` prefixed cells escaped); API key never sent to browser or logged. Exit: 0 Blockers, 0 Majors open. |
| **L6 Fresh-eyes rehearsal** | "BMO Director" agent (never saw code/docs except the demo script) | L5 Blockers closed | Drives the app via Playwright screenshots, narrates as a sceptical Digital Channels director. Scores 1–5 on: clarity of the "one intake in → three views" story, realism of data/names/dates, jargon correctness (RDDC, L2, CRQ, STO, PRN), AI output believability, fluff. Exit: every score ≥4; every "I don't get what this is for" comment fixed or cut. |
| **L7 Final regression** | QA Lead | All fixes merged, code freeze | Clean clone → `rm -f data/*.db` → `./run_demo.sh` → full `pytest` (L2+L3+L4) green **3 consecutive runs** (flake check); simulated-mode output diffed against rehearsal snapshot (identical); live-mode smoke with key (if available) and with key revoked (falls back to simulated, banner shows). DoD (§4) signed off. |

Defect loop: any failure at Ln returns to the builder; fix must add a regression test at the lowest line that could have caught it, then re-run from L2 upward.

---

## 2. Test Matrix (P0 = first demo goal "ONE INTAKE IN → HEALTH + CAPACITY + GANTT")

Golden scenario **GS-1** (seeded and also created live in E2E): Intake `RDDC-24817` "US API Enhancement", LOB "Personal & Commercial (US)", PM "Priya Natarajan", priority 1, components EAPI, CIAM, SRE; WBS Estimation → Development → QA → Production; Dev assignment Nov '25–Mar '26.

| ID | Layer | P | Steps | Expected |
|---|---|---|---|---|
| API-01 | L2 | P0 | `POST /api/intakes` valid GS-1 body | 201, returns id, `rddc` echoed, `status`="Backlog" |
| API-02 | L2 | P0 | `POST /api/intakes` missing project name | 400 `{error}` naming the field, no row inserted |
| API-03 | L2 | P0 | `GET /api/intakes/<id>` unknown id | 404 JSON, not HTML |
| API-04 | L2 | P0 | `PUT /api/intakes/<id>` change PM | 200; GET reflects; `updated_at` changed |
| API-05 | L2 | P0 | `GET /api/intakes?q=API` | GS-1 in results; `q=zzz` → `[]` |
| API-06 | L2 | P0 | `POST /api/intakes/<id>/components` EAPI | 201; duplicate component → 409 |
| API-07 | L2 | P0 | `POST /api/intakes/<id>/wbs` end < start | 422 "end date before start date" |
| API-08 | L2 | P0 | `GET /api/intakes/<id>/health` GS-1 | dims schedule/resources/scope/dependencies + overall + `attention` string |
| API-09 | L2 | P0 | `GET /api/capacity?fy=2026` | rows per resource × 4 quarters, keys `availability`,`allocation`,`status` |
| API-10 | L2 | P0 | `GET /api/intakes/<id>/gantt` | tasks with ISO start/end, deps, `critical` bool |
| API-11 | L2 | P0 | `POST /api/intakes/<id>/sa-doc` with .docx | 201; text extracted length >200 chars |
| API-12 | L2 | P0 | Same with .pdf | 201; extracted text non-empty |
| API-13 | L2 | P1 | Upload .exe renamed .pdf / 0-byte / 11 MB | 422 / 422 / 413; nothing written to disk |
| API-14 | L2 | P0 | `POST /api/ai/change-summary` (simulated) | 200 within 3 s; rows `{component, approval, summary}`; same body twice → identical JSON |
| API-15 | L2 | P0 | `POST /api/ai/wbs` from change summary | ≥4 WBS rows, each has owner, start, end, hours |
| API-16 | L2 | P1 | `POST /api/ai/*` with live mode, API raises/timeout (monkeypatched) | 200 with simulated result + `"mode":"simulated-fallback"`; never 500 |
| API-17 | L2 | P1 | `POST /api/crqs` start > end; invalid STO enum | 422 each |
| API-18 | L2 | P1 | `GET /api/portfolio` | every seeded intake once; RAG ∈ {Red,Amber,Green} |
| API-19 | L2 | P1 | `GET /api/export.xlsx` | 200, content-type `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`, `openpyxl.load_workbook` opens it, sheets: Portfolio, WBS, Capacity, Changes |
| API-20 | L2 | P1 | `POST /api/demo/reset` | 200; DB equals fresh seed (row counts match golden) |
| API-21 | L2 | P1 | SQLi: `GET /api/intakes?q=' OR 1=1--`; name `Robert'); DROP TABLE intakes;--` | no error, returns 0 rows / stores literal string; table intact |
| API-22 | L2 | P1 | Meta-test: every `app.url_map` rule appears in test registry | pass |
| API-23 | L2 | P2 | `POST /api/assistant` "Which projects are Red?" (simulated) | answer names exactly the seeded Red projects |
| ENG-01 | L3 | P0 | fiscal: 2025-11-01, 2026-01-31, 2026-02-01, 2026-10-31, 2026-11-01 | FY26Q1, FY26Q1, FY26Q2, FY26Q4, FY27Q1 |
| ENG-02 | L3 | P0 | RAG: S=A, R=Red, Sc=G, D=G | Overall **Amber** (deck parity) |
| ENG-03 | L3 | P0 | RAG: R=Red, S=Red | Overall Red; all Green → Green; S=A only → Amber |
| ENG-04 | L3 | P0 | Schedule dim: forecast end 0 / 6 / 15 working days past baseline (thresholds ≤5 G, 6–10 A, >10 R) | Green / Amber / Red |
| ENG-05 | L3 | P0 | Capacity: avail 420h in FY26Q1, alloc 378h / 400h / 441h | 90% Amber / 95.2% Amber / 105% Red |
| ENG-06 | L3 | P0 | Capacity: assignment 50% from 2025-12-15 to 2026-02-14, resource 140h/month | Q1 alloc = 0.5×140×(17/31 Dec + 1 Jan) ≈ 108.4h; Q2 = 0.5×140×(1 Feb×14/28)=35.0h (proration by calendar day, ±0.1) |
| ENG-07 | L3 | P0 | Capacity: resource with 0 availability | status Red, no ZeroDivisionError, pct shown "n/a" |
| ENG-08 | L3 | P0 | Gantt CPM: A(5d)→B(10d)→D(3d), A→C(4d)→D, start Mon 2026-11-02 | critical A,B,D; C float 6 wd; D ends Wed 2026-11-25 (weekends skipped) |
| ENG-09 | L3 | P0 | Gantt: dependency cycle A→B→A | raises `CycleError`; API maps to 422 |
| ENG-10 | L3 | P0 | Resources dim: any assigned resource Red in the project window | Resources = Red, `attention` names resource + WBS id (e.g. "SA capacity constraint affecting WBS-100") |
| ENG-11 | L3 | P1 | L2 estimate: EAPI M (80h), CIAM S (40h), SRE S (40h), contingency 15% | 184h; breakdown sums to total |
| ENG-12 | L3 | P1 | L2: zero components | 0h + warning "no components", not exception |
| ENG-13 | L3 | P1 | Grooming slot (weekly Wed 10:00 ET, 5 per session): created Mon 2026-10-19 | 2026-10-21 |
| ENG-14 | L3 | P1 | Grooming: created Wed 2026-10-21 11:00 ET; 6th ticket on a full session | 2026-10-28; 6th → 2026-10-28 when 21st full |
| ENG-15 | L3 | P1 | Burndown PRN budget 500h, 50h charged each Monday from 2026-09-07 | remaining after 4 charges (as of 2026-10-04) = 300h; projected exhaustion = week of 2026-11-09 (10th charge) |
| ENG-16 | L3 | P1 | Burndown: overspend (charged > budget) | remaining negative shown, status Red, chart doesn't clip |
| ENG-17 | L3 | P1 | SA-doc parser on fixture `tests/fixtures/sa_us_api.docx` / `.pdf` | finds components {EAPI, CIAM, SRE} |
| ENG-18 | L3 | P1 | Simulated AI generator run twice, different processes | identical output (hash compare) |
| ENG-19 | L3 | P2 | Skill matrix / resource suggestion for EAPI intake | top recommendation is seeded EAPI dev with capacity, not an over-allocated one |
| ENG-20 | L3 | P2 | Excel export escapes `=HYPERLINK(...)` in a comment cell | stored as text (`'=` prefix) |
| E2E-01 | L4 | P0 | Load `/` fresh | Portfolio/home renders <2 s, 0 console errors, BMO-style header, no "undefined"/"NaN"/"null" text anywhere (DOM text scan) |
| E2E-02 | L4 | P0 | Add New Initiative → fill Pg1 GS-1 → Save | toast success; appears in Search; RDDC shown |
| E2E-03 | L4 | P0 | Upload SA doc (docx) on Pg1 | filename chip shown; SA Completeness updates |
| E2E-04 | L4 | P0 | Click **Generate Change Summary** | spinner ≤3 s (simulated); table has EAPI, CIAM, SRE rows; button disabled while running |
| E2E-05 | L4 | P0 | Pg2 → **Generate WBS** | WBS table populated; edit a row's % completion → persists after reload |
| E2E-06 | L4 | P0 | **Generate Gantt view** | SVG/canvas has one bar per WBS row; bars inside container (no horizontal overflow of page: `scrollWidth <= clientWidth`); critical path highlighted; today line on 2026-10-19 |
| E2E-07 | L4 | P0 | Pg3 Resources | quarter headers read "Nov–Jan / Feb–Apr / May–Jul / Aug–Oct"; Dev assigned Nov '25–Mar '26 shows allocation in Q1 and Q2 only |
| E2E-08 | L4 | P0 | Health panel for GS-1 | Overall Amber, Schedule Amber, Resources Red, Scope Green, Dependencies Green, attention line present (deck parity) |
| E2E-09 | L4 | P0 | Capacity panel | bars for EAPI (Dev1), EAPI (Dev2), CIAM, SRE; Red bar for over-allocated |
| E2E-10 | L4 | P0 | Change WBS end date +15 wd → back to Health | Schedule flips to Red, Overall recalculates without page reload |
| E2E-11 | L4 | P1 | Pg4 Change Governance: create CRQ with STO "Tentative Go", attach validation evidence | saved; dropdowns exactly match Sheet1 lists |
| E2E-12 | L4 | P1 | Pg5 Portfolio | Project Dashboard + Change Management tables; GS-1 present with Amber pill; sort by RAG works |
| E2E-13 | L4 | P1 | Assistant: "What needs management attention this week?" | answer ≤5 s, references real seeded RDDC ids; no raw markdown asterisks/`#` visible |
| E2E-14 | L4 | P1 | Export to Excel | download event fires; file opens with openpyxl; row count = portfolio count |
| E2E-15 | L4 | P1 | Reset demo | confirm dialog; data back to seed; GS-1 created in this run is gone |
| E2E-16 | L4 | P0 | Sweep: visit every route/tab, click every visible button (non-destructive allowlist) | 0 console errors, 0 responses ≥500, 0 unhandled rejections, no button with no effect |
| E2E-17 | L4 | P0 | Whole flow with `timezone_id='Pacific/Auckland'` and `'America/Los_Angeles'` | all displayed dates identical to Toronto run |
| E2E-18 | L4 | P1 | Kill server mid-session, click Generate | friendly error banner within 20 s, spinner stops, button re-enabled |
| E2E-19 | L4 | P1 | Viewport 1366×768 and 1920×1080 | no clipped tables, Gantt fits, left nav visible |
| E2E-20 | L4 | P2 | Empty states: new intake with no WBS → Gantt/Health tabs | "Add WBS steps to see the Gantt" style message, not blank/crash |
| SEC-01 | L5 | P0 | Project name `<img src=x onerror=alert(1)>`; view in list, portfolio, Gantt label, assistant answer | rendered literally, no dialog fires (Playwright `page.on('dialog')` fails test) |
| SEC-02 | L5 | P1 | grep `innerHTML\s*=` / `insertAdjacentHTML` | every hit uses `esc()` or static template; reviewer signs each |
| SEC-03 | L5 | P1 | grep `execute(f"` / `%` / `.format(` in SQL | zero hits |
| SEC-04 | L5 | P1 | Upload filename `../../app.py` | saved under uploads with sanitized name; app.py untouched |
| SEC-05 | L5 | P1 | `ANTHROPIC_API_KEY` set; inspect page source, network, logs | key never appears |
| SEC-06 | L5 | P2 | Flask `debug=False` in demo launcher; Werkzeug debugger not reachable | pass |
| REH-01 | L6 | P0 | Director walks scripted 7-minute demo cold | scores ≥4/5 all dimensions; zero "lorem", "test", "foo", "John Doe" seen |
| REG-01 | L7 | P0 | Fresh clone → `./run_demo.sh` → full suite ×3 | 3/3 green, simulated outputs hash-identical to rehearsal snapshot |

(71 cases: 23 API, 20 engine, 20 E2E, 6 security, 1 rehearsal, 1 regression.)

---

## 3. Demo Risk Register (top 15)

| # | Risk (what embarrasses the presenter) | L | I | Mitigation |
|---|---|---|---|---|
| R1 | AI button spins forever (live API slow, no key, rate-limited, Wi-Fi off) | H | H | Simulated is the default. Live calls: 15 s timeout → auto-fallback to fixture + small "simulated" badge. Every spinner has a hard client timeout. E2E-18, API-16. |
| R2 | Non-deterministic output differs from rehearsal | H | M | Simulated generators seeded; L7 hash-compares against rehearsal snapshot. Presenter rehearses in simulated mode only. Live mode is opt-in via a visible toggle, never default. |
| R3 | Dates shift by a day (UTC parse of `YYYY-MM-DD`) | H | H | Single `dates.js` local parser; lint-grep bans `new Date(` with a date-only string outside it; E2E-17 multi-timezone runs. |
| R4 | Wrong fiscal quarter (calendar Q vs BMO Nov FY) | M | H | `fiscal.py` single source; ENG-01 boundary tests; headers literally "Nov–Jan" etc. A BMO audience will spot this instantly. |
| R5 | Deck parity fails: health shows Red when deck promised Amber | M | H | ENG-02/E2E-08 assert exact deck values for GS-1 seed. |
| R6 | Gantt overflows / bars off-screen / unreadable labels for long project | M | M | Auto-scale to project span, min bar width 4 px, label truncation with tooltip; E2E-06 overflow assertion; seed one 18-month project to test. |
| R7 | Seed data looks fake (lorem, "Test Project 1", round 100% numbers, all Green) | H | H | Curated seed: ~8 intakes with realistic DC names (e.g. "Zelle Limits Uplift", "CIAM MFA Step-up", "US API Enhancement"), plausible LOBs, mixed RAG (2 Red, 3 Amber, 3 Green), ragged hours (e.g. 137.5). L6 rubric + grep for banned tokens. Avoid real employee names; use clearly fictional but plausible names. |
| R8 | Port 5000 in use (macOS AirPlay Receiver squats on 5000) | H | M | Default port **5055**; launcher checks port, picks next free, prints the URL and opens browser. |
| R9 | Stale JS/CSS from browser cache after a late fix | M | H | Static URLs carry `?v=<build hash>`; `Cache-Control: no-store` on `index.html` and `/api/*`. Rehearse in a fresh incognito window. |
| R10 | SA doc fails to parse (scanned PDF, .doc, password-protected) | M | H | Ship the demo SA doc in `demo_assets/` (docx + text PDF), pre-tested by ENG-17. Unparseable file → clear message "Couldn't read text from this file — paste the scope instead" with a paste box fallback. Never 500. |
| R11 | Exported .xlsx won't open / "We found a problem with some content" in Excel | M | H | openpyxl only, no hand-rolled XML; dates written as real dates with number format; sheet names ≤31 chars, no `/\?*[]`; API-19 load test; open once in real Excel/Numbers during rehearsal. |
| R12 | Demo DB polluted from rehearsal (half-made intakes visible) | H | M | `Reset demo` button + `run_demo.sh` recreates DB from seed every launch; reset is idempotent (API-20). |
| R13 | Console red errors/visible "undefined" or "NaN%" when presenter opens DevTools or a panel | M | M | E2E-01 DOM text scan + E2E-16 sweep; ENG-07 zero-division. |
| R14 | XSS/garbled rendering when audience asks "type something weird" | L | H | SEC-01; all user and AI text rendered via `textContent`/`esc()`. |
| R15 | Assistant hallucinates a project or gives an answer contradicting the dashboard | M | H | Assistant answers are grounded in a JSON snapshot of the DB (in both modes); simulated mode uses intent-matching over real data, not canned prose; E2E-13 checks every RDDC id it cites exists. Show "sources" chips. |

---

## 4. Definition of Done (ship checklist)

- [ ] `./run_demo.sh` from a clean clone: creates venv deps, resets DB, starts on free port, opens browser — under 30 s, no manual steps.
- [ ] `pytest` (api + engine + e2e) green 3 consecutive runs; no `skip`/`xfail` on P0 tests.
- [ ] `ruff check` clean; `node --check` clean; no `print`/`console.log` debugging left.
- [ ] Every route has a test (API-22 meta-test passes).
- [ ] Zero console errors, zero ≥500 responses in E2E-16 sweep.
- [ ] Deck parity: GS-1 health = Amber / Amber / Red / Green / Green with attention line; capacity bars EAPI(Dev1), EAPI(Dev2), CIAM, SRE; Gantt Estimation → Development → QA → Production.
- [ ] Multi-timezone run identical (E2E-17).
- [ ] L5 red-team: 0 Blocker, 0 Major open; Minors logged with decision.
- [ ] L6 director scores ≥4/5 on all dimensions; no placeholder text anywhere.
- [ ] Simulated mode works with network disabled (Wi-Fi off test). Live mode falls back gracefully when key missing/invalid.
- [ ] Exported xlsx opened successfully in Excel or Numbers by a human/agent screenshot.
- [ ] Demo script (`docs/demo_script.md`, ≤1 page, 7 minutes) matches the app click-for-click; rehearsal snapshot saved.
- [ ] README: 3 commands to run, how to reset, how to enable live AI.
- [ ] Every Sheet1 lookup list (Status, Release Type, STO, Validation, RAG) appears verbatim in dropdowns.

---

## 5. Scope-Risk Critique

**The real risk is breadth.** The backlog lists 6 epics and ~25 features; the deck's first demo goal is three views off one intake. Builders will be tempted to make 12 screens shallow. A director forgives a missing tab; they do not forgive a broken one. **A feature that isn't at L4-green by code freeze is hidden, not shown half-working.**

**Never cut (the spine of the demo):**
1. Intake create/edit/search (Pg1) with SA doc upload.
2. Generate Change Summary → Generate WBS → Gantt (the "enter once, calculate, visualize" story and the explicit ask in the requirements).
3. Project Health with the deck's RAG dimensions + attention line.
4. Resource Capacity by BMO fiscal quarter.
5. Portfolio View with RAG.
6. Simulated-AI determinism, fallback, and Reset.
7. The full L2–L4 suite and the L6 rehearsal. Cutting QA to buy features is the wrong trade.

**Cut in this order if time runs short:**
1. Live Claude mode polish (keep the switch, ship simulated only).
2. Skill matrix / AI resource suggestion (show as a static "Recommended Developer" from deterministic rule).
3. Burndown per PRN (keep engine + one chart; drop interactivity).
4. Conversational assistant → reduce to 5 suggested questions with grounded answers.
5. Grooming-slot automation and L2 approval reminders (show computed "Next grooming: Wed 21 Oct" text only).
6. Change Governance attachments (keep CRQ form + statuses, drop file evidence upload).
7. Excel export of all sheets → Portfolio sheet only.
8. Epic-5 Artifacts repository — out entirely; mention as roadmap MVP2.

**Push-backs to the panel:**
- Product Owner: do not promise Epics 4–6 as "working" — label them "MVP2/3 preview" in the UI if shown.
- Architect: one place for dates, one for fiscal logic, one for RAG rules; engines pure-Python with no Flask imports so L3 is cheap.
- AI Lead: fixtures must be keyed to GS-1's SA doc so the change summary visibly reflects its content; generic summaries kill credibility.
- UX Lead: keep the Pg1–Pg5 mental model from the Demo View sheet — that is what the requestor already drew; don't invent a different IA.
