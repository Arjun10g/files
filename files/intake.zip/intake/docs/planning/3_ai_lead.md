# 3 — AI / ML Lead: AI Productivity Layer Plan

Scope: Epic-6 "AI Productivity Layer", plus the AI hooks in Epics 1–5 (the yellow cells in Demo View). Table and field names follow the data model in §0. If the Architect's model renames anything, only the field mapping changes.

## 0. Core design decisions

1. **Three-tier resolver, one interface.** `ai.run(feature, initiative_id, inputs, opts)` resolves in this order:
   **LIVE** (if `ANTHROPIC_API_KEY` is set) → **FIXTURE** (a pre-generated test-agent response whose `input_hash` matches) → **GENERATOR** (a deterministic Python algorithm). If live mode fails (timeout 20 s, schema-invalid output after 1 repair retry, or HTTP error), the call drops to FIXTURE/GENERATOR and the UI shows "Live unavailable – simulated".
2. **The LLM proposes and code decides.** Dates, hours, capacity numbers, compliance verdicts and RAG are always computed or validated in Python. The LLM supplies structure, wording, rationale and judgement. A live WBS is re-scheduled by the same `scheduler.py` the generator uses, so the Gantt is always internally consistent.
3. **Structured output via forced tool-use.** Each feature has a JSON Schema in `ai/schemas/<feature>.json`. Live mode passes it as the `input_schema` of a tool named `emit_<feature>` and sets `tool_choice={"type":"tool","name":"emit_<feature>"}`. Fixtures and generator outputs are validated against the same schema (`jsonschema`), so all three tiers produce the same shape.
4. **Models.** `claude-opus-5-5` for document reasoning (F2 Change Summary, F6 WBS, F8 Risk, F17 Assistant). `claude-sonnet-5-5` for everything else (fast and cheap). Override with `AI_MODEL_HEAVY` / `AI_MODEL_FAST`. Temperature is 0.2, or 0.7 on Regenerate.
5. **Common envelope.** Every feature returns the envelope below. Only `output` varies by feature.

```json
{ "run_id": "uuid", "feature": "change_summary", "initiative_id": 12, "mode": "live|fixture|generator",
  "model": "claude-opus-5-5|null", "prompt_version": "1.0", "confidence": 0.0,
  "sources": [{"type": "initiative|document|wbs_task|resource|allocation|crq|risk|meeting_note|rule",
               "id": "RDDC-1042", "field": "description", "excerpt": "≤200 chars"}],
  "warnings": ["string"], "output": { } }
```

**Data model assumed (abridged).** `initiatives`(id, rddc, name, lob, status, stage, rag, priority, pm, dev_lead, dc_pm, dc_sa, requestor, labels, description, sa_completeness, prn, target_release, start_date, end_date) · `documents`(id, initiative_id, kind[sa_doc|validation_evidence|notes], filename, text) · `dc_components`(id, initiative_id, component, approval, change_summary, lead) · `wbs_tasks`(id, initiative_id, code, step, description, owner, resource_id, start, end, status, pct, depends_on, dev_hours, actual_hours, comments) · `resources`(id, name, role, team, skills_json, monthly_hours) · `allocations`(resource_id, initiative_id, month, hours, tentative) · `risks` · `crqs`(id, initiative_id, crq_no, start_dt, end_dt, release_type, release_train, affected_cis, target_release, impacted_component, impl_status, crq_approval, sto_approval, cms_lead, rel_lead, tech_validation_status, tech_evidence_doc_id, biz_validation_status, biz_evidence_doc_id) · `grooming_sessions`(id, date, slots, attendees) · `meeting_notes`, `decisions`, `action_items`, `lessons` · `ai_runs` (§4).

**Shared system prompt (prepended to every live feature):**
```
You are the AI Productivity Layer inside BMO Digital Channels' Project Intake & Portfolio tool.
Users are PMs, Delivery Leads, DC Solution Architects and Dev Leads. Domain vocabulary: RDDC (intake id),
DC component (EAPI = Enterprise API, CIAM = Customer Identity & Access Mgmt, EDP = Enterprise Data
Platform, SRE, Mobile, OLB Web, Security), SA document, L2 estimate, DLR, CRQ/RCSR, STO approval (Go/
Tentative Go/Tentative No Go/No-Go), PRN, BMO fiscal year starting 1 Nov.
Rules: use ONLY the data supplied in <context>; never invent people, ids, dates or numbers that are not
derivable from it. If information is missing, say so in the output's gap/warning fields. Every claim
must be traceable to a source item (type+id+field). Respond ONLY by calling the provided tool.
Set "confidence" (0–1) to reflect data completeness and ambiguity, not tone.
```
The user turn is always `<context>{json of the inputs listed}</context>` followed by `<task>…feature template…</task>`.

## 1–2. Feature catalogue

Each entry gives the backlog mapping, the trigger, the inputs, the output schema (the `output` field only), the live task prompt, and the generator algorithm. In schemas, `"a|b"` means an enum.

### F1 Intake Analysis — Epic-1 Intake Registration / SA Completeness
- **Trigger:** "Analyse Intake" on Pg 1. It also runs on save of a new initiative, and its score populates `SA Completeness`.
- **Inputs:** initiatives.{name, description, lob, requestor, labels, priority, target_release, dc_sa, prn}, documents(sa_doc).text, dc_components.
- **Output:**
```json
{"completeness_score": 0, "readiness": "Ready for grooming|Needs info|Not ready",
 "field_checks": [{"field": "prn", "status": "present|missing|weak", "note": "str"}],
 "ambiguities": [{"text": "quoted phrase", "why": "str", "source_field": "description"}],
 "missing_info": [{"item": "Non-functional requirements", "impact": "High|Medium|Low"}],
 "clarifying_questions": [{"question": "str", "addressed_to": "Requestor|DC SA|PM|Dev Lead", "priority": 1}],
 "suggested_labels": ["str"]}
```
- **Task prompt:** "Assess this intake for grooming readiness. Score completeness 0–100 against: business objective, scope in/out, impacted DC components, NFRs (volume, latency, availability), security/CIAM impact, data impact, dependencies, target release, funding (PRN), named DC SA. Quote vague phrases ('ASAP', 'minor changes', 'etc.', 'similar to') as ambiguities. Ask at most 6 clarifying questions, each addressed to one role, ordered by impact on the L2 estimate."
- **Generator:** a 10-item checklist, each with a weight and a detector (non-empty field, or keyword regex on description + SA text, e.g. NFR = `/\b(tps|latency|p9\d|availability|sla|rto|rpo)\b/i`). The score is the sum of the weights found. Ambiguities come from a 40-phrase vague lexicon. Each missing checklist item maps to a templated question with a fixed role. Confidence = 0.5 + 0.4 × (SA doc present).

### F2 SA Document → Change Summary — Epic-1 Solution Finalization (Pg 1 yellow button)
- **Trigger:** "Generate Change Summary" (enabled once an SA document is attached). Accept writes the rows into `dc_components`.
- **Inputs:** documents(sa_doc).text, initiatives.{name, description}, the component master list.
- **Output:**
```json
{"components": [{"dc_component": "EAPI|CIAM|EDP|SRE|Mobile|OLB Web|Security|Other",
   "approval": "Approved|Pending|Not required|Rejected", "approver": "str|null",
   "change_summary": "≤60 words", "change_type": "New|Modify|Decommission|Config",
   "complexity": "S|M|L|XL", "evidence": [{"section": "4.2 API Design", "excerpt": "str"}]}],
 "out_of_scope": ["str"], "open_items": ["str"], "sa_completeness": 0}
```
- **Task prompt:** "Read the Solution Architecture document and produce one row per impacted DC component. For each row, take approval status only from explicit text (approval table, sign-off section); otherwise use 'Pending'. Write the change summary in delivery language (what changes, interface, data, security) in at most 60 words. Rate complexity from the number of interfaces, new versus modified, and the presence of a new vendor or data store. Cite the section heading for every row. List items the doc marks TBD/TBC as open_items."
- **Generator:** split the doc into sections on Markdown/numbered headings. Score each sentence against a component lexicon (EAPI: api, gateway, endpoint, openapi, apigee, rate limit; CIAM: oauth, token, mfa, login, scope, consent; EDP: kafka, event, topic, warehouse, cdc; SRE: slo, alert, dynatrace, splunk, runbook; Security: tls, encryption, pen test, waf, threat model; Mobile; OLB Web). A component is included when it has ≥2 hits. The summary is the top two scoring sentences, trimmed. Approval is parsed from an "Approvals" table with the regex `^(EAPI|CIAM|…)\s*\|\s*([^|]+)\|\s*(Approved|Pending|…)`. Complexity is a bucket of hit-count + interface-count. `TBD|TBC|to be confirmed` lines become open_items. Confidence = 0.45 + 0.05 × components_with_approval_table_match (capped at 0.85).

### F3 L2 Effort Estimate with rationale — Epic-1 Effort Estimation
- **Trigger:** "Estimate L2" on Pg 1/Pg 2. Accept stores the estimate in `initiatives.l2_hours` and starts the DLR approval reminder (F5).
- **Inputs:** dc_components (rows, complexity), F1 completeness score, historical actuals of completed initiatives (`wbs_tasks.actual_hours` grouped by component and complexity).
- **Output:**
```json
{"total_hours": 0, "range": {"low": 0, "high": 0}, "tshirt": "S|M|L|XL", "contingency_pct": 0,
 "by_component": [{"dc_component": "EAPI", "dev_hours": 0, "qa_hours": 0, "design_hours": 0, "rationale": "str"}],
 "assumptions": ["str"], "drivers": [{"factor": "New external vendor", "multiplier": 1.2}],
 "comparables": [{"rddc": "RDDC-0981", "name": "str", "actual_hours": 0, "similarity": 0.0}]}
```
- **Task prompt:** "Produce an L2 estimate. Anchor on the comparables provided (cite them). Apply only drivers evidenced in the context. Contingency is 15% if completeness ≥80, 20% if 60–79, 25% below that. Explain each component's hours in one sentence."
- **Generator:** base hours from the table S/M/L/XL = 80/200/400/700 dev hours, with QA = 35% and design = 15% of dev. Multipliers: new vendor ×1.2, regulatory/compliance keyword ×1.15, new data store ×1.1, CIAM change ×1.1. Comparables are the top 3 completed initiatives by Jaccard similarity of component sets. The final figure is a 50/50 blend of the table result and the comparable mean. Range = ±20%.

### F4 Grooming Slot Recommendation — Epic-1 Demand Prioritization
- **Trigger:** "Recommend grooming slot" on Pg 1. There is also a batch "Auto-slot To-Do backlog" action on the Portfolio page.
- **Inputs:** initiatives in status Backlog/To Do (priority, created date, F1 score, components), grooming_sessions (date, remaining slots, attendees).
- **Output:**
```json
{"recommendations": [{"rddc": "RDDC-1042", "session_id": 3, "session_date": "2026-11-04",
   "priority_score": 0.0, "invitees": [{"name": "str", "role": "DC SA"}], "prep_actions": ["str"], "reason": "str"}],
 "unscheduled": [{"rddc": "str", "reason": "No slot with CIAM SA before target release"}]}
```
- **Task prompt:** "Slot each ticket into the earliest grooming session that has free slots and whose attendees cover the ticket's component leads. Rank by priority score. List the prep actions that must happen before the session (from intake gaps)."
- **Generator:** priority_score = 0.4·(4−priority)/3 + 0.3·min(age_days/30, 1) + 0.3·completeness/100. Greedy assignment in score order to the earliest session with slots > 0 at least 2 business days ahead. Invitees = requestor + PM + DC SA + leads of the impacted components. Prep actions = F1 questions with priority ≤ 2.

### F5 Action-Required Nudges & Approval Reminders — Epic-1 Solution Finalization + Approval reminders
- **Trigger:** "Draft nudges" on the Dashboard, plus a simulated every-two-days scheduler shown as an "Outbox" (no email is actually sent).
- **Inputs:** open action_items, pending dc_components.approval, unapproved L2 estimates, open F1 questions, with ages.
- **Output:** `{"messages":[{"to":"str","role":"DC SA","subject":"Action required by 2026-10-23: …","body":"≤120 words","items":[{"type":"approval|question|action","ref":"RDDC-1042/CIAM"}],"urgency":"High|Normal"}]}`
- **Task prompt:** "Write one concise, courteous nudge per recipient that consolidates all of their pending items, with an explicit 'action required by' date of today + 2 business days. Don't repeat items they already completed."
- **Generator:** group by recipient and render a Jinja template. Urgency is High if any item is older than 5 days.

### F6 Change Summary → WBS Project Plan — Epic-2 Project Setup (Pg 2)
- **Trigger:** "Generate Project Plan" on Pg 2 (needs a Change Summary). Accept writes `wbs_tasks` and enables "Generate Gantt view".
- **Inputs:** dc_components, F3 estimate (or a default estimate), initiatives.{start_date, target_release}, resources + allocations, release calendar / freeze windows.
- **Output:**
```json
{"tasks": [{"code": "1.2", "step": "EAPI – Develop /v2/accounts endpoints", "description": "str",
   "phase": "Estimation|Design|Development|Integration|QA|UAT|Readiness|Production",
   "dc_component": "EAPI", "sme_owner": "str", "resource": "str|null", "dev_hours": 0,
   "duration_days": 0, "depends_on": ["1.1"], "start": "YYYY-MM-DD", "end": "YYYY-MM-DD", "milestone": false}],
 "key_dates": {"readiness_date": "date", "qa_start": "date", "qa_signoff": "date", "prod_date": "date"},
 "critical_path": ["1.1", "2.3"], "total_dev_hours": 0,
 "resource_intake": [{"resource": "str", "month": "2026-11", "hours": 0}], "assumptions": ["str"]}
```
- **Task prompt:** "Build a WBS that a PM can execute. Use a phase skeleton per impacted component (Design → Development → Integration), then shared SIT/QA, UAT, Readiness (CAB/CRQ raised, STO Go), and Production + Validation milestones. Each step must be actionable (verb + object). Distribute the L2 hours. Give finish-to-start dependencies, including cross-component ones (e.g. CIAM scope config before EAPI integration). Propose a resource only from the supplied roster. Dates you give are advisory; the system will reschedule them."
- **Generator:** a template per component phase, with hours split Design 15% / Dev 55% / Integration 10%, plus shared QA 20% and fixed milestones. Dependencies come from the component dependency graph (F7). `scheduler.py` runs a forward pass over business days (6 productive hrs/day/resource), skips the Dec code-freeze and holidays, and sets readiness_date = prod − 5 bd and QA sign-off = prod − 3 bd. Resources come from F10 (top-1 per component). Code recomputes the critical path in both modes.

### F7 Dependency Mapping (upstream/downstream impact) — Epic-2
- **Trigger:** the "Impact map" tab on Pg 2. The output adds test/change steps to the WBS on Accept.
- **Inputs:** dc_components, SA text, other active initiatives touching the same components (with dates), the static component graph `ai/data/component_graph.json`.
- **Output:**
```json
{"upstream": [{"system": "CIAM token service", "relation": "auth provider", "impact": "str", "action": "str"}],
 "downstream": [{"system": "Mobile app v8.4", "relation": "API consumer", "impact": "str", "action": "Regression test /v1 accounts"}],
 "cross_initiative": [{"rddc": "RDDC-1043", "component": "CIAM", "overlap": "2026-12-01..2027-01-15", "conflict": "str"}],
 "wbs_additions": [{"step": "str", "phase": "QA", "after": "2.3"}], "graph": {"nodes": [], "edges": []}}
```
- **Task prompt:** "Identify upstream providers and downstream consumers impacted by these changes, using the graph and the SA text. For each, state the impact and a concrete test or change action. Flag other initiatives that change the same component in an overlapping window."
- **Generator:** BFS of depth 2 on the component graph from the impacted components. Text mentions of known system names are added. Cross-initiative overlap is a SQL date-overlap check on the same component. Every downstream consumer gets a templated regression step.

### F8 Risk Prediction → Risk Register — Epic-2 Risk Register
- **Trigger:** "Predict risks" on Pg 2. It also runs nightly in the demo when the user clicks "Refresh portfolio intelligence". Accept upserts into `risks`.
- **Inputs:** initiative, WBS (slippage = planned vs today vs pct), allocations, F7 output, CRQs, F1 gaps, history of realized risks on similar initiatives.
- **Output:**
```json
{"risks": [{"id": "R-1042-03", "title": "SA capacity constraint", "category": "Resource|Schedule|Scope|Dependency|Technical|Compliance|Vendor",
   "description": "str", "severity": 1, "likelihood": 1, "score": 1, "rating": "High|Medium|Low",
   "trigger_signal": "str (data that raised it)", "affected_wbs": ["1.2"], "owner": "str",
   "mitigation_steps": [{"step": "str", "owner": "str", "due": "date"}], "contingency": "str"}],
 "overall_risk_rating": "High|Medium|Low", "management_attention": "≤25 words"}
```
- **Task prompt:** "Predict the risks most likely to affect delivery. Every risk must name its trigger_signal from the context (e.g. 'Rina at 135% in Dec'). Severity and likelihood are 1–5; score = product; rating High ≥15, Medium 8–14. Give 2–4 mitigation steps, each actionable with owner and due date. Write a one-line 'management attention' statement like 'SA capacity constraint affecting WBS-100'."
- **Generator:** a library of 22 rules (`ai/rules/risks.yaml`), each = condition SQL/py + title + sev/likelihood formula + mitigation templates. Examples: resource >100% in any task month → Resource, sev 4, likelihood = f(overage); task past end with pct <100 → Schedule; completeness <60 → Scope; CRQ in ≤10 days and validation Not Started → Compliance; only one resource holds a required skill → key-person risk; cross-initiative overlap from F7 → Dependency; prod date in Nov–Jan freeze → Schedule; vendor keyword → Vendor. Duplicates are merged and the top 8 kept. management_attention = highest-score risk title + affected WBS.

### F9 Health / RAG Explainer — Epic-4 Status Reporting / Health framework
- **Trigger:** hovering or clicking any RAG chip. The Project Health panel shows Schedule/Resources/Scope/Dependencies.
- **Output:** `{"overall":"Red|Amber|Green","dimensions":[{"name":"Schedule|Resources|Scope|Dependencies","rag":"…","reason":"str","metric":"str"}],"what_would_turn_it_green":["str"]}`
- **Logic:** the RAG values are always rule-computed (thresholds agreed in "Immediate actions #02"): Schedule = max slip on the critical path (>10 bd Red, >3 Amber); Resources = peak allocation (>110% Red, >95% Amber); Scope = open SA items / completeness; Dependencies = conflicting overlaps. Live mode only writes `reason` / `what_would_turn_it_green`.

### F10 Suggested Resources (ranked) — Epic-3 Suggested Resources
- **Trigger:** "Suggest resource" on Pg 1/Pg 3 and per WBS row.
- **Inputs:** required skills (derived from components + SA keywords), date window and hours (from WBS/L2), resources.skills_json, the F11 matrix, allocations.
- **Output:**
```json
{"required_skills": ["Apigee", "OAuth2"], "window": {"start": "date", "end": "date", "hours_needed": 0},
 "candidates": [{"rank": 1, "resource": "str", "team": "EAPI", "fit_score": 0.0,
   "skill_match": 0.0, "matched_skills": [], "missing_skills": [], "availability_pct": 0.0,
   "free_hours_in_window": 0, "prior_work": ["RDDC-0981"], "reasons": ["str"], "concerns": ["str"]}]}
```
- **Task prompt:** "Rank up to 5 candidates for this work. Use the computed skill_match and availability numbers as given (do not change them). Write 2–3 reasons and any concerns per candidate, citing prior initiatives."
- **Generator:** fit = 0.5·skill_match (proficiency-weighted coverage of required skills from the F11 levels) + 0.3·min(free_hours/hours_needed, 1) + 0.15·component_history + 0.05·same-team continuity. Reasons come from templates on the top contributing terms. A concern is added if allocation >90% in any month. The numbers are computed in code in both modes.

### F11 Skill Matrix generation — Epic-3 Skill Matrix
- **Trigger:** "Generate Skill Matrix" on the Resources page, shown as a heatmap.
- **Inputs:** wbs_tasks (resource × step/description × actual_hours), dc_components of those initiatives, resources.skills_json (declared).
- **Output:** `{"skills":["Apigee","OAuth2","Kafka",…],"matrix":[{"resource":"str","levels":{"Apigee":0},"evidence":{"Apigee":["RDDC-0981 1.2 (120h)"]},"top_skills":[],"growth_suggestions":[]}],"team_gaps":[{"skill":"str","holders":1,"note":"Key-person risk"}]}`
- **Task prompt:** "Infer skills from task history (step text + component) and declared skills. Levels: 0 none, 1 exposure, 2 working, 3 proficient, 4 expert. Every level >0 needs evidence. Identify skills held by ≤1 person."
- **Generator:** a skill lexicon (≈40 skills → regex) applied to task text, plus component → default skills. Hours are summed per (resource, skill): >0 → 1, ≥20 → 2, ≥80 → 3, ≥200 → 4. Declared skills give a floor of 2.

### F12 Capacity & PRN Burn Forecast — Epic-3 Utilization / Project Allocation (added)
- **Trigger:** the "Forecast" toggle on the Resource Capacity and PRN burndown charts.
- **Output:** `{"overallocations":[{"resource":"str","month":"2027-02","allocated_pct":0,"initiatives":[]}],"rebalancing_options":[{"action":"Move 40h of RDDC-1047 3.1 from Rina to Dev2","effect":"Rina 135%→98%"}],"prn_forecast":[{"prn":"str","budget":0,"charged":0,"forecast_at_completion":0,"exhaust_date":"date|null"}]}`
- **Generator:** monthly sum of allocations / monthly_hours. Rebalancing is greedy: move tasks from >100% resources to the best F10 candidate with free capacity. PRN burn uses linear run-rate extrapolation. Live mode only narrates and ranks the options.

### F13 CR Compliance Check — Epic-4 Change Management (Pg 4)
- **Trigger:** "Check compliance" on Pg 4, plus the weekly "CRs to review" list on the Dashboard.
- **Inputs:** crqs row + linked evidence documents, initiative, release calendar.
- **Output:**
```json
{"crq": "CRQ000123456", "compliant": false, "score": 0,
 "findings": [{"rule_id": "CR-04", "rule": "Technical validation evidence attached when status=Completed",
   "status": "Pass|Fail|Warn", "field": "tech_evidence_doc_id", "detail": "str", "fix": "str", "blocking": true}],
 "sto_readiness": "Ready for Go|Tentative|Not ready", "reviewer_note": "≤60 words"}
```
- **Rules (code, both modes):** CR-01 STO approval = Go ≥24h before start_dt; CR-02 CRQ approval Approved before start; CR-03 affected CIs and impacted component non-empty; CR-04/05 technical/business validation evidence attached when status is In progress/Completed, and status not Failed; CR-06 window not in a freeze and ≤ 8h; CR-07 CMS lead and Rel lead named; CR-08 Bundle release must name a release train; CR-09 implementation status consistent with dates (past end_dt but not Completed = Warn). Live mode writes `reviewer_note` and `fix` text, and may add Warn findings from the evidence text (e.g. "evidence screenshot is from UAT, not Prod").

### F14 Executive Summary / Weekly Status Report — Epic-4 Status Reporting
- **Trigger:** "Generate weekly status" on the Portfolio page, or per initiative. Export to .md/print.
- **Inputs:** portfolio rows (RAG, stage, dates), RAG changes in the last 7 days (status_history), top risks, CRQs in the next 14 days, capacity hotspots (F12), milestones completed.
- **Output:** `{"period":"2026-10-13..2026-10-19","headline":"≤30 words","portfolio_health":{"red":0,"amber":0,"green":0,"trend":"improving|stable|declining"},"highlights":["str"],"lowlights":["str"],"decisions_needed":[{"decision":"str","by":"date","owner":"str"}],"upcoming_releases":[{"rddc":"","crq":"","date":"","sto":""}],"per_initiative":[{"rddc":"","name":"","rag":"","one_liner":"≤25 words"}],"capacity_watch":["str"]}`
- **Task prompt:** "Write a weekly executive status for DC leadership. Lead with what changed and what needs a decision. No adjectives without numbers. Max 5 highlights, 5 lowlights."
- **Generator:** SQL aggregates + Jinja sentence templates ("{n} initiatives moved to Red: {list}"). The headline picks from 4 templates based on trend.

### F15 Meeting Notes → Actions / Decisions — Epic-5 Meeting Notes & Decision Log
- **Trigger:** paste or upload notes on Artifacts → Meeting Notes, then "Extract". Accept writes `action_items` / `decisions`.
- **Output:** `{"summary":"≤80 words","decisions":[{"decision":"str","made_by":"str|null","rationale":"str","rddc":"str|null"}],"actions":[{"action":"str","owner":"str|null","owner_matched_resource_id":0,"due":"date|null","rddc":"str|null","source_line":0}],"risks_raised":[{"title":"str"}],"open_questions":["str"]}`
- **Generator:** line-level regex. Actions: `^(AI|Action|TODO)[:\-]`, `@(\w+)`, `(\w+) (will|to) (\w+)`. Decisions: `^(Decision|Agreed|Decided)[:\-]?`, `we (agreed|decided)`. Owners are fuzzy-matched to resources (difflib ≥0.8). Due dates come from patterns like `by (Mon|…|\d{4}-\d\d-\d\d|EOW|EOD)` resolved against the meeting date. RDDC references match `RDDC-\d+` or an initiative name.

### F16 Lessons Learned — Epic-5 Lessons Learned
- **Trigger:** "Draft lessons learned" on initiatives in Completed status, plus a cross-portfolio "Patterns" view.
- **Output:** `{"what_went_well":[{"point":"str","evidence":"str"}],"what_to_improve":[{"point":"str","evidence":"str","recommendation":"str"}],"estimate_accuracy":{"planned_hours":0,"actual_hours":0,"variance_pct":0,"worst_phases":[]},"reusable_assets":["str"],"tags":["str"]}`
- **Generator:** planned vs actual per phase (variance >20% → improve item), realized risks (from `risks.status=Realized`), failed validations/CRQ reschedules, decision log entries. Templated sentences.

### F17 Conversational Portfolio Assistant — Epic-6 (see §3)
- **Trigger:** a global chat drawer (Ctrl+K), with page context preloaded (the current initiative).
- **Output:** `{"answer_markdown":"str","citations":[{"type":"initiative|wbs_task|resource|crq|risk","id":"str","label":"str","link":"/initiative/12#pg2"}],"table":{"columns":[],"rows":[]}|null,"follow_ups":["str"],"intent":"str"}`

### F18 Smart Intake Autofill (added) — Epic-1
- **Trigger:** on "Add New Initiative", drop an SA doc or paste an email. The tool pre-fills name, LOB, requestor, labels, DC SA, description and target release with per-field confidence (`{"fields":{"lob":{"value":"P&C Banking","confidence":0.7,"source":"SA §1"}}}`).
- **Generator:** a regex over the doc's metadata block (`Author:`, `LOB:`, `Target Release:`), plus F2 components to generate labels.

## 3. Conversational assistant

**Pipeline (simulated):** normalize → **showcase match** (fixture questions: rapidfuzz `token_set_ratio ≥ 88` returns the pre-generated answer, but **re-binds numbers from the live DB** where the fixture declares `bindings`) → **entity extraction** → **intent router** → handler (pure SQL/Python) → templated markdown + citations.

**Entity extraction:** `RDDC-\d{3,5}`, `CRQ\d+`; initiative names via an exact substring search over `initiatives.name`, then fuzzy matching (≥0.8) on n-grams; resource names (first/last/full); components (EAPI|CIAM|EDP|SRE|Mobile|OLB|Security, plus synonyms like "identity" → CIAM and "api" → EAPI); RAG colors; months/quarters (Jan…Dec, "Q1" = Nov–Jan fiscal, "next month"); stages; skills (lexicon from F11). If the page is an initiative page, "this project" resolves to it.

**Intents (regex triggers → handler):**
| # | Intent | Example | Handler |
|---|---|---|---|
| 1 | list_by_rag | "which projects are red?" | filter initiatives by rag, with a dimension reason (F9) |
| 2 | overallocated | "who is over-allocated in Feb?" | allocations / monthly_hours > 1.0 for the month |
| 3 | summarize_initiative | "summarise RDDC-1042" | stage, RAG, dates, components, next milestone, top risk |
| 4 | blockers | "what's blocking US API Enhancement?" | overdue/blocked tasks, unmet depends_on, High risks, pending approvals, CR findings |
| 5 | suggest_resource | "suggest a developer for CIAM work" | F10 generator for that component's skills over the next 60 days |
| 6 | availability | "who has capacity in March?" | free hours ranked |
| 7 | resource_workload | "what is Priya working on?" | allocations + tasks |
| 8 | upcoming_releases | "what's going to prod in the next 2 weeks?" | crqs by start_dt with STO status |
| 9 | cr_noncompliance | "which CRs are non-compliant?" | F13 rules over crqs this week |
| 10 | top_risks | "top risks across the portfolio" | risks ordered by score |
| 11 | milestone_dates | "when is QA for RDDC-1047?" | key dates from WBS |
| 12 | component_demand | "how much EAPI demand next quarter?" | hours by component vs capacity |
| 13 | pending_approvals | "what approvals are pending?" | dc_components.approval, L2, STO |
| 14 | skill_lookup | "who knows Kafka?" | F11 matrix level ≥2 |
| 15 | portfolio_stats | "how many initiatives per LOB / stage?" | group-by |
| 16 | status_report | "give me this week's status" | F14 headline + bullets |
| 17 | help / fallback | anything unmatched | "I can answer…" with 5 clickable example chips |

The router scores each intent as regex hits + whether its required entities are present. If the top score is under threshold, it asks a disambiguation question ("Did you mean RDDC-1042 US API Enhancement or RDDC-1051 …?"). Each handler returns rows, a markdown template and citations (one per row id), and offers 2 follow-ups.

**Live mode:** Claude (`claude-opus-5-5`) gets the same handlers as tools: `search_initiatives(query, rag?, stage?, lob?)`, `get_initiative(rddc)`, `get_wbs(rddc)`, `get_allocations(resource?, month_from, month_to)`, `find_resources(skills[], start, end, hours)`, `get_risks(rddc?, min_score?)`, `get_crqs(from, to, rddc?)`, `check_cr_compliance(crq)`, `portfolio_stats(group_by)`, `get_skill_matrix(skill?)`. The loop runs at most 6 tool turns. The final turn is forced to `emit_answer` (the F17 schema). The system addendum reads: "Answer only from tool results; cite every record you mention with its id; if tools return nothing, say so; never estimate numbers yourself." Tool results are logged in `ai_runs.sources_json`.

## 4. Explainability UX and audit

Every AI output is rendered in a shared **AI Result Card** (`components/ai_card.html`):
- **Header:** feature name, the label **"AI-generated — review before use"**, a mode chip (`Live · claude-opus-5-5` / `Simulated · test-agent fixture` / `Simulated · rules engine`), and a timestamp.
- **Confidence badge:** High ≥0.80 (green), Medium 0.50–0.79 (amber), Low <0.50 (grey, with a "verify carefully" tooltip). It also shows per-row confidence where the schema has it. Generator confidence comes from explicit formulas, never a constant.
- **Sources drawer:** a list of `sources[]` with a clickable record link and the excerpt highlighted. Rule-based outputs list the rule ids fired (`rule:CR-04`).
- **Warnings:** missing inputs ("No SA document; plan based on description only").
- **Actions:** **Accept** writes to the target tables with `ai_run_id` provenance (rows get a small ✦ marker until a human edits them). **Edit** opens an inline editable grid; saving stores `edited_output_json` and a diff. **Regenerate** takes an optional instruction box ("more conservative", "split QA by component"); in simulated mode it serves the next fixture `variant` or applies a generator perturbation (contingency +5%, alternate template). **Reject** takes a reason.
- **"Why?"** link: shows the prompt version, the inputs hash, and (live) the token counts.
- **Time-saved counter:** each feature has a baseline manual-minutes value (e.g. WBS = 90 min). The AI Activity page totals the minutes for accepted runs, which makes a good showcase KPI.

**`ai_runs` table:** `id TEXT PK, feature, initiative_id, mode, model, prompt_version, input_hash, input_json, output_json, confidence REAL, sources_json, warnings_json, latency_ms, tokens_in, tokens_out, status [generated|accepted|edited|rejected|superseded], user_action_at, edited_output_json, regen_of TEXT, instruction, user, created_at`. The AI Activity page lists runs with filters, and the acceptance rate per feature works as a trust metric.

**Guardrails:** schema validation on all tiers; post-validators (referenced ids exist, owners exist in resources, dates within project bounds, hours sum within ±1% of total); PII-free prompts (only work data); a live-mode token cap per call (8k out).

## 5. Fixture generation plan (test agents)

**Process.** Test agents (Claude subagents, run at build time) act as the live model. Each receives the exact shared system prompt plus the feature task prompt and the seed's context JSON, and must emit schema-valid JSON. `tools/validate_fixtures.py` checks the schema, the post-validators and the input_hash. Each fixture carries `{"generated_by":"test-agent claude-opus-5-5","prompt_version":"1.0","input_hash":"…","variants":[{…},{…}]}`. Two variants support Regenerate. The input_hash is computed over the canonical seed context. If a demo user edits an input, the hash misses and the generator tier takes over, which is the intended behaviour and is shown by the mode chip.

**Seed intakes (to coordinate with the PO's seed list):**
| RDDC | Name | Components | Purpose in demo |
|---|---|---|---|
| RDDC-1042 | US API Enhancement | EAPI, EDP, Security, CIAM | Hero flow: SA doc → summary → WBS → Gantt; Amber, Resources Red ("SA capacity constraint affecting WBS-100") |
| RDDC-1043 | CIAM Passkey / MFA Step-up | CIAM, Mobile, OLB Web | Overlaps 1042 on CIAM → dependency conflict |
| RDDC-1047 | Mobile Cheque Deposit Limit Increase | Mobile, EAPI, SRE | Red: schedule slip + over-allocated dev in Feb |
| RDDC-1051 | OLB Real-time Alerts (event-driven) | EDP, OLB Web, SRE | Intake with a vague description → Intake Analysis showcase |
| RDDC-1055 | SRE Observability Uplift | SRE | Green; CRQ fully compliant (contrast) |
| RDDC-0981 | Open Banking Consent Dashboard (Completed) | EAPI, CIAM | Comparables, skill evidence, lessons learned |
| RDDC-0975 | Statement e-Delivery (Completed) | OLB Web, EDP | Comparables / lessons |

**Files to produce** (`app/fixtures/`):
- `sa_docs/RDDC-1042_US_API_Enhancement_SA_v1.2.md`, `sa_docs/RDDC-1043_CIAM_Passkey_SA_v0.9.md`, `sa_docs/RDDC-1051_OLB_Alerts_SA_v0.3.md` (plus a `.pdf`/`.docx` render of the 1042 doc for upload realism; the text extractor handles md/txt/docx/pdf).
- `ai/<feature>/<RDDC>.json` for each feature applicable to each seed: F1 for all 5 active seeds; F2, F6, F7 for 1042/1043/1051 (the SA-doc seeds); F3, F4, F8, F10, F9 for all active; F11 a single `ai/skill_matrix/portfolio.json`; F12 `ai/capacity/portfolio.json`; F13 `ai/cr_compliance/<CRQ>.json` for 4 CRQs (1 compliant, 1 missing biz evidence, 1 STO Tentative No Go, 1 freeze-window clash); F14 `ai/status_report/2026-W42.json`; F5 `ai/nudges/portfolio.json`; F16 for 0981 and 0975; F18 for the 3 SA docs.
- `meeting_notes/2026-10-14_RDDC-1042_grooming.txt`, `meeting_notes/2026-10-16_weekly_DC_sync.txt` (≈300 words each, with mixed action and decision phrasing, one unowned action) + `ai/meeting_extract/<file>.json`.
- `assistant/showcase_qa.json`: 25 Q&A pairs covering all 17 intents, each with `question`, `paraphrases[3]`, `answer_markdown`, `citations`, `bindings` (e.g. `{"{red_count}":"SELECT COUNT(*)…"}`) so the numbers stay true after demo edits.
- `manifest.json`: index of fixture → feature, seed, input_hash, schema version.

**SA document content requirements** (each 900–1,400 words, BMO-plausible, no real system internals or real names):
1. **RDDC-1042 US API Enhancement, v1.2.** Sections: 1 Document control (Author: DC SA; LOB: U.S. Personal & Commercial; Target Release: R2027.02; PRN). 2 Business context (expose account and transaction APIs to US digital channels and partner aggregators; deprecate screen-scraping). 3 Scope in/out. 4 Solution overview, with 4.1 EAPI: new `/v2/accounts`, `/v2/transactions` (pagination, ETag), gateway rate limiting 50 TPS per client; 4.2 CIAM: new OAuth2 scopes `accounts.read`, `transactions.read`, consent token TTL 90 days; 4.3 EDP: CDC events to the `txn-history` Kafka topic, 13-month retention; 4.4 Security: mTLS for partners, threat model, pen test before prod. 5 NFRs (p95 < 300 ms, 99.9% availability, 2M calls/day). 6 Dependencies (CIAM token service upgrade; Mobile v8.4 consumer). 7 Risks/assumptions. 8 Transition (canary, rollback to v1). 9 **Approvals table** (EAPI Approved, CIAM Pending, EDP Approved, Security Pending, SRE Not required). 10 Open items, with 2 TBDs (partner onboarding SLA; data residency confirmation).
2. **RDDC-1043 CIAM Passkey / MFA Step-up, v0.9.** WebAuthn passkeys for Mobile and OLB, step-up for high-risk transfers, risk engine integration, fallback OTP. Approvals: CIAM Approved, Mobile Pending, OLB Web Pending. Deliberately overlaps the CIAM token-service window with 1042.
3. **RDDC-1051 OLB Real-time Alerts, v0.3 (draft).** Deliberately incomplete: no NFRs, vague phrases ("minor UI changes", "similar to existing alerts", "ASAP"), no approvals table, 4 TBDs. This document exists to showcase Intake Analysis (score ≈45, 6 clarifying questions) and a low-confidence Change Summary.

**Acceptance for fixtures:** 100% schema-valid; every `sources[].id` exists in the seed DB; the generator output for the same seed also passes validation (a test asserts this, so an unseen-input path never crashes on stage).
