# 1 · Product Owner / BA — Demo Script, Scope, Field Spec, Seed Data, Rules

**Demo date:** Mon 2026-10-19 · **Fiscal year:** FY27 = 1 Nov 2026 – 31 Oct 2027 (Q1 Nov–Jan, Q2 Feb–Apr, Q3 May–Jul, Q4 Aug–Oct)
**First-demo promise:** ONE INTAKE IN → HEALTH + CAPACITY + GANTT. Everything else is real, but secondary.
**Shell:** left rail mirrors the Excel Demo View — **Add New Initiative · Edit Initiative · Search Initiative · Portfolio View** — then **Intake Queue · Resources · Change Governance · Risks · Artifacts · Assistant**. An initiative opens as one long page with anchored sections Pg 1–Pg 4 (like the sheet), each section collapsible. Yellow buttons in the Excel are the AI/automation buttons in the app, same labels.

---

## 1. Demo script (9 minutes, hero intake = "US API Enhancement")

Sample SA document ships with the app: `samples/SA_US_API_Enhancement_v1.2.docx` (also `.md`). Header role switcher (top right) shows the current persona; presenter switches persona where noted.

| # | Time | Click | Audience sees |
|---|---|---|---|
| 1 | 0:00 | **Portfolio View** | 8 live initiatives, KPI strip (Active 7 · Red 1 · Amber 3 · CRQs this week 2 · Over-allocated people 2). "This is where we end up. Let's add one." |
| 2 | 0:30 | **Add New Initiative** → DC Intake # lookup, pick `DCI-3391` | Name "US API Enhancement – Real-time Payment Status", LOB US P&C, Requestor Clara Pemberton, Priority P2, Requested Go-live Feb 2027 pre-fill. RDDC # assigned on save: **RDDC-24817**. |
| 3 | 1:00 | **Save** | Toast: "Slotted for grooming **Tue 20 Oct, 10:00**. Invite queued to Arlo Kingsley, Grace Ellingham, Sana Whitfield." Intake Analysis card (AI): suggested labels `payments`, `api`, `us-p&c`; likely components API Platform, EDP, CIAM; possible duplicate: none (closest RDDC-24310, 31%). |
| 4 | 1:45 | Pg 1 **SA document → Attach** the sample doc | Author "Sana Whitfield", Version 1.2, **SA Completeness 88%** ("Missing: Backout plan"). "Action required by DC SA" chip: next reminder **Wed 21 Oct**. |
| 5 | 2:15 | **Generate Change Summary** | Table fills: API Platform (High, 280 h) · Enterprise Data Platform (Medium, 120 h) · CIAM / Security (Medium, 120 h) · SRE / Observability (Low, 40 h), each with 1–2 line summary, Approval = Pending, Component Lead filled. **L2 Estimate** panel: **1,000 h · T-shirt L · range 750–1,250 h**, with "How we got this" breakdown. |
| 6 | 3:00 | Switch persona to Dev Lead → **Send L2 for approval**; switch to Requestor → **Approve L2** | L2 status Approved, Stage moves Estimation → Planning, demand flips Tentative → Confirmed. |
| 7 | 3:30 | Pg 2 **Generate Project Plan** | 14-row WBS (WBS-100 … WBS-800, incl. 2 downstream regression steps for Mobile and Web) with owners, resources, dates, hours, dependencies. Header: Readiness Date **Wed 17 Feb 2027**, QA Date **Wed 10 Feb 2027**, Production **Sat 20 Feb 2027 (DC-2702)**, Developer hours 560. Dates skip stat holidays; Production avoids the 14 Dec–8 Jan freeze. |
| 8 | 4:15 | **Generate Gantt view** | Gantt with bars grouped Estimation / Development / QA / Production (matches deck), dependency arrows, today line (19 Oct), freeze band shaded, release train markers. Drag WBS-210 end +5 days → dependants shift, Readiness float drops, Schedule chip updates live. Undo. |
| 9 | 5:00 | Pg 3 **Resource Management** | Quarterly Availability / Allocation grid (Nov–Jan … Aug–Oct). Sana Whitfield **128% in Nov** (red). **Recommended Developer** card: Tobias Wren for API Platform (92% match: OpenAPI, payments, idempotency; 61% booked Q1). **Project Health** box: Overall **Amber** — Schedule Amber · Resources **Red** · Scope Green · Dependencies Green · Budget Green. "Management attention: SA capacity constraint affecting WBS-100." (deck slide, live) |
| 10 | 5:45 | Click the Red → **Suggest fix** → accept "Move WBS-100 to Mateo Brennan" | Sana drops to 96%, Mateo 74%. Resources turns Green; overall stays Amber (Schedule). "Health is calculated, not typed." |
| 11 | 6:15 | **Risks** tab on the initiative → **Predict risks** | 5 risks with severity × likelihood, owner, mitigation, linked WBS (e.g. "EDP event schema not frozen before WBS-220 start — High/Medium"). Accept 3 → Risk Register. |
| 12 | 6:45 | Pg 4 **Change Governance** → **Create CRQ draft** | CRQ0001048817 drafted: window Sat 20 Feb 2027 02:00–06:00, Bundle, DC-2702, Affected CIs from components, STO Approval **Tentative Go**. Compliance check: 1 flag "Backout plan not attached". |
| 13 | 7:15 | **Portfolio View** | RDDC-24817 now in Project Dashboard (Planning, Amber). Change Management table shows it. Resource heatmap shows the new confirmed demand. PRN burndown for PRN-77310 (0 charged / 1,100 funded). |
| 14 | 7:45 | **Assistant**: "Which initiatives are at risk for the Feb release and why?" then "Draft this week's exec summary" then "Who has CIAM capacity in January?" | Grounded answers with RDDC links; exec summary in 5 bullets; capacity answer names Felix Hartwell (Jan 58% booked). "Copy to email" button. |
| 15 | 8:30 | Close | "Enter once · calculate · visualize · automate." **Reset demo** button in footer restores seed. |

---

## 2. Scope (MoSCoW) — every backlog feature appears

MUST = works end-to-end in the demo. SHOULD = working, simpler. COULD = present and clickable with seeded content.

| Epic | Feature | Pri | What ships |
|---|---|---|---|
| 1 | Intake Registration (RDDC) | MUST | Add/Edit/Search initiative; RDDC auto-number; DC Intake lookup pre-fill; validation. |
| 1 | Demand Prioritization (Grooming) | MUST | Auto-slot to next Tue/Thu session; Intake Queue page with session agenda, capacity 6/session, drag to re-slot, invite in Outbox. |
| 1 | Solution Finalization | MUST | SA doc attach, completeness %, "Action required by" every 2 business days into Outbox until SA = 100% or Finalized. |
| 1 | Effort Estimation (L2) | MUST | L2 calculated from Change Summary; editable per row; send to DLR; approve/reject. |
| 1 | Approval reminders | SHOULD | L2 pending reminders every 3 business days; escalation after 3rd. |
| 2 | Project Setup (WBS) | MUST | Generate Project Plan from Change Summary incl. readiness date, QA date, dev hours, resource per step. |
| 2 | WBS Management & Gantt | MUST | Inline edit status/%/dates/comments; Gantt with drag, dependencies, freeze band, baseline vs forecast. |
| 2 | Dependency Mapping | MUST | Component-to-component upstream/downstream map from catalogue; impacted apps listed; auto-adds "Regression test downstream" WBS steps. |
| 2 | Risk Register | SHOULD | AI-predicted risks, manual add, severity × likelihood matrix, mitigation actions, link to WBS. |
| 3 | Resource Inventory | MUST | Account Manager edits monthly available hours per person (12 months FY27). |
| 3 | Resource Utilization Dashboard | MUST | Team bars (deck style) + person × month heatmap + calendar view of one person. |
| 3 | Project Allocation (PRN burndown) | SHOULD | Burndown per PRN: funded vs charged vs forecast, monthly. |
| 3 | Suggested Resources | MUST | Recommended Developer per WBS step with score + reasons; one-click assign. |
| 3 | Skill Matrix | SHOULD | AI-generated person × skill grid from past WBS history; editable. |
| 4 | Status Reporting | MUST | Portfolio View with RAG, filters, export CSV. |
| 4 | Change Management | MUST | Pg 4 form; weekly CR list (next 14 days); compliance flags; Outbox notices. |
| 4 | Governance Reviews | SHOULD | Approval queue: L2 approvals, component approvals, STO decisions in one list with Approve/Reject + comment. |
| 4 | Release Tracking | SHOULD | Release train calendar: trains, freeze, intakes per train, readiness. |
| 5 | Document Repository | SHOULD | All attachments per initiative with version and uploader. |
| 5 | Decision Log | SHOULD | Auto-entries (L2 approved, reassignment, STO) + manual. |
| 5 | Architecture Repository | COULD | SA docs across portfolio, searchable by component. |
| 5 | Lessons Learned | COULD | Seeded from RDDC-24310; AI surfaces relevant lessons on new intake. |
| 5 | Meeting Notes | COULD | Paste notes → AI extracts decisions + actions into logs. |
| 6 | Intake Analysis | MUST | On save: completeness, labels, component guess, duplicate check. |
| 6 | Project Plan Generation | MUST | Change Summary + WBS + dates (deterministic engine, AI writes descriptions). |
| 6 | Risk Prediction | SHOULD | As above. |
| 6 | Executive Summarizer | SHOULD | Per initiative and portfolio, 5 bullets, copy button. |
| 6 | Conversational Assistant | MUST | Grounded Q&A over app data + drafts emails; cites RDDC #s. |

Product rule: every AI output carries an "AI draft — review" tag, is editable, and is logged in the Decision Log when accepted. Calculations (L2, dates, RAG, capacity) are deterministic rules; AI explains and drafts, it does not set numbers silently.

---

## 3. Field spec

Filled by: **U** user · **C** calculated · **AI** AI-drafted, user-editable · **S** system.

### Pg 1 — General Details
| Label | Type | Values | Req | By |
|---|---|---|---|---|
| RDDC # | text | `RDDC-#####` | Y | S |
| Project Name | text ≤80 | — | Y | U |
| Current Status | select | Backlog · In progress · Completed | Y | C (Backlog until Planning, Completed at Closed) |
| Stage | select | Intake · Grooming · Solution · Estimation · Planning · Build · QA · Release · Closed | Y | C (events), U override |
| Assigned To | person | — | Y | U (default DC PM) |
| PM | person | — | N | U |
| Tech/Dev Lead | person | — | Y by Estimation | U |
| DC PM | person | — | Y | U |
| DC SA | person | DC SA team | Y by Solution | U / AI suggests |
| DC Intake | lookup | `DCI-####` | N | U → pre-fills name, LOB, requestor, priority |
| Labels | tags | free + suggested | N | U / AI |
| Requestor | person | — | Y | U |
| LOB | select | Canadian P&C · US P&C · Commercial Banking · Wealth · Cards & Payments · Technology | Y | U |
| Priority | select | P1 · P2 · P3 · P4 | Y | U |
| Requested Go-live | date | — | Y | U |
| Target Release | select | release trains (§4) | N | U / C from plan |
| PRN | text | `PRN-#####` | Y by Planning | U |
| SA document | attachment | .docx .pdf .md .txt | Y by Estimation | U |
| Author · SA Version | text | — | — | C from doc |
| SA Completeness | % | 0–100 | — | AI (9-section checklist) |
| Description of Change | long text | — | Y | U, **Improve wording** (AI) |
| Change Summary table | rows | DC Component (catalogue) · Approval (Pending · Approved · Rejected · Not required) · Change Summary · Complexity (Low · Medium · High) · Est. hours · Component Lead | ≥1 row by Estimation | AI rows, U edits; hours C |
| L2 Estimate | panel | Total h · T-shirt · Range · L2 Status (Draft · Pending approval · Approved · Rejected) · Approved by/on · Reminders sent | — | C |
| Grooming Session | datetime | — | — | C |
| Action required by | date + person | — | — | C |

### Pg 2 — Project Plan
Header (C): Plan baseline date · Readiness Date · QA Date · Production Date · Developer hours · Float to release (business days).
| Label | Type | Values | Req | By |
|---|---|---|---|---|
| WBS Step | id | `WBS-100`, child `WBS-210` | Y | C |
| Description | text | — | Y | AI / U |
| SME/Owner | person | — | Y | C (component lead) / U |
| Resource | person(s) | — | Y before start | AI recommended / U |
| Hours | number | — | Y | C / U |
| Allocation % | number | 10–100 | Y | C / U |
| Depends on | multi WBS | finish-to-start | N | C / U |
| Start Date · End Date | date | business days | Y | C / U |
| Baseline End | date | locked at L2 approval | — | C |
| Status | select | Backlog · In progress · Completed | Y | U |
| % Completion | 0–100 | — | Y | U (Completed forces 100) |
| At risk | flag | — | N | U / AI |
| Comments | text | — | N | U |
Buttons: **Generate Project Plan**, **Generate Gantt view**, **Re-baseline** (DC PM only, logs decision).

### Pg 3 — Resource Management
Grid: Resource Name · Team · Role · per quarter Nov–Jan / Feb–Apr / May–Jul / Aug–Oct: **Availability (h) | Allocation (h)** + util % colour; click a quarter → months; Allocation split **Confirmed / Tentative**.
Assignments table: Resource · WBS Step · Hours · Allocation % · From · To · Demand (Confirmed · Tentative) — C from Pg 2.
Panels: Recommended Developer (AI: name, score, 3 reasons, current load), Project Health (C, §5), PRN burndown (C).

### Pg 4 — Change Governance
| Label | Type | Values | Req | By |
|---|---|---|---|---|
| CRQ/RCSR # | text | `CRQ##########` | Y | U / S on draft |
| CRQ Start Date and Time · End | datetime | — | Y | C from plan / U |
| Release Type | select | Bundle · Independent | Y | U |
| Release Train/Sprint | select | trains | Y if Bundle | U |
| Affected CIs | multi | from catalogue | Y | C / U |
| Target Release | select | trains | Y | C (Pg 1) |
| Impacted Component | multi | Change Summary | Y | C |
| Implementation Status | select | Not Started · Scheduled · In progress · Implemented · Backed out | Y | U |
| CRQ Approval Status | select | Draft · Submitted · CAB Review · Approved · Rejected | Y | U |
| STO Approval | select | Tentative Go · Tentative No Go · Go · No-Go | Y | C (Tentative) / U STO (final) |
| CMS Lead · Rel Lead · Resource | person | — | Y | U |
| Technical Validation Status + attachment | select | Not Started (default) · In progress · Completed · Failed | Y | U |
| Business Validation Status + attachment | select | same | Y | U |
| Backout plan | attachment | — | Y | U |
| Compliance | list | flags §5 | — | C |

### Pg 5 — Portfolio View
Project Dashboard: Intake/RDDC # · Project Name · LOB · DC PM · Stage · RAG (dot + hover shows 5 dimensions) · Target Release · Readiness Date · QA Sign-off (date/✓) · Prod/Final · Comments (latest). Filters: LOB, DC PM, Stage, RAG, Release. Export CSV.
Change Management: Intake/Release · CMS Lead · Rel Lead · Resource · Implementation Status · Technical Validation Status · Business Validation Status · STO Approval · Compliance flags.
Above tables: KPI strip; three deck tiles (Health, Capacity by team, Portfolio Gantt by initiative).

### Added pages
- **Intake Queue / Grooming:** columns RDDC # · Name · LOB · Priority · Submitted · Session (Tue/Thu) · Action required by · Waiting on. Session cards with agenda (max 6) and attendees.
- **Risk Register:** Risk ID `RSK-###` · RDDC # · Title · Category (Schedule · Resource · Scope · Dependency · Budget · Technical · Compliance) · Severity (Low · Medium · High · Critical) · Likelihood (Rare · Unlikely · Possible · Likely) · Score (C) · Owner · Mitigation · Linked WBS · Status (Open · Mitigating · Closed) · Source (AI/U). 4×4 matrix view.
- **Resources (inventory & skills):** Name · Team · Role · Monthly available hours ×12 (Account Manager edits) · Skills (AI matrix: skill × level 1–3, evidence = WBS steps) · Current load.
- **Artifacts:** tabs Documents · Decision Log (Date · RDDC # · Decision · By · Source) · Architecture · Lessons Learned · Meeting Notes (paste → **Extract actions**).
- **Assistant:** chat panel + suggested prompts; also slide-over on every page with page context.
- **Outbox:** every reminder/invite/notice the system "sends": To · Subject · Due · Trigger · Status (Queued · Sent). No real email.

---

## 4. Seed data

**People (capacity-tracked, monthly available hours; Dec reduced for holidays):**
| Name | Team | Role | h/month | Key skills |
|---|---|---|---|---|
| Tobias Wren | EAPI | Senior API Developer (EAPI Dev1) | 140 | Java/Spring, OpenAPI, payments APIs, idempotency |
| Lena Oduya | EAPI | API Developer (EAPI Dev2) | 140 | Node, Kafka, event streams, EDP feeds |
| Devon Achterberg | EAPI | EAPI Tech Lead | 120 | API design, gateway policy, code review |
| Mira Castellane | CIAM | IAM Engineer | 140 | OAuth2/OIDC, scopes, step-up MFA |
| Felix Hartwell | CIAM | IAM Developer | 140 (Dec 80) | MFA, biometrics, session mgmt |
| Kai Moreau | SRE | Site Reliability Engineer | 140 | SLOs, dashboards, alerting |
| Ines Hollowell | SRE | Platform Engineer | 140 | Kubernetes, CI/CD, perf tuning |
| Jasper Quill | Mobile | iOS Developer | 140 | Swift, biometrics, accessibility |
| Yuki Larkspur | Mobile | Android Developer | 140 | Kotlin, push notifications |
| Nadia Fenwick | Web | Front-end Developer | 140 | React, WCAG 2.1, design system |
| Theo Marchetti | Web | Full-stack Developer | 140 | React, Node BFF, statements |
| Hana Brightwater | QA | QA Lead (automation) | 140 | API automation, regression |
| Omar Velasquez | QA | QA Analyst | 140 | Performance, mobile testing |
| Sana Whitfield | DC SA | Solution Architect | 120 | Payments, API, data |
| Mateo Brennan | DC SA | Solution Architect | 120 | Identity, web, mobile |

Not capacity-tracked: DC PMs Grace Ellingham, Ravi Dunmore · Delivery Lead Arlo Kingsley · CMS Lead Petra Vallance · Rel Lead Owen Stroud · Account Manager Elena Rusk · Requestors Clara Pemberton (US P&C), Marcus Thorne (Cards & Payments), Bea Lindqvist (Wealth) · STO Board.

**Initiatives (seeded; hero RDDC-24817 is created live):**
| RDDC # | Name | LOB | DC PM | Stage | RAG | Why (seeded driver) | Train | PRN |
|---|---|---|---|---|---|---|---|---|
| 24310 | US Business Bill Pay Migration | US P&C | Ravi Dunmore | Closed | Green | Done; source of Lessons Learned | DC-2610 | 70112 |
| 24412 | e-Transfer Request Money Redesign | Cards & Payments | Grace Ellingham | Release | **Red** | STO Tentative No Go, Business Validation Failed, budget burn 92% at 70% complete | DC-2611 | 71840 |
| 24533 | Mobile Biometric Login Refresh | Canadian P&C | Ravi Dunmore | Build | Green | On plan | DC-2701 | 72205 |
| 24601 | Step-up MFA for Wire Transfers | Commercial Banking | Grace Ellingham | QA | Amber | QA 6 days behind; Felix over-allocated Dec | DC-2612 | 72391 |
| 24688 | Online Statement Download Redesign | Canadian P&C | Ravi Dunmore | Planning | Green | Plan generated, all confirmed | DC-2702 | 73050 |
| 24702 | Credit Card Instalment Plan API | Cards & Payments | Grace Ellingham | Estimation | Amber | L2 pending approval 8 business days, 2 reminders sent | DC-2703 | 73388 |
| 24755 | Wealth Dashboard Accessibility Fixes | Wealth | Ravi Dunmore | Solution | Amber | SA Completeness 60%, action required by Mateo | DC-2703 | — |
| 24790 | Digital Channels Observability Uplift | Technology | Grace Ellingham | Grooming | — (not scored before Planning) | Slotted Thu 22 Oct | — | — |

Sana Whitfield is pre-loaded at ~105% in Nov across 24688, 24702, 24412 so the hero intake pushes her to 128%.

**Release trains:** DC-2610 (Sat 17 Oct 2026, done) · DC-2611 (Sat 21 Nov) · DC-2612 (Sat 12 Dec, last before freeze) · DC-2701 (Sat 16 Jan 2027) · DC-2702 (Sat 20 Feb) · DC-2703 (Sat 20 Mar). **Change freeze:** Mon 14 Dec 2026 – Fri 8 Jan 2027. **Stat holidays:** 11 Nov (observed by DC), 25 & 28 Dec, 1 Jan, 15 Feb.

**DC component catalogue** (Component · Team/CI · Lead · Low/Med/High dev hours · Downstream):
1. API Platform · EAPI · Devon Achterberg · 40/120/280 · EDP, Mobile, Web
2. API Gateway · EAPI · Devon Achterberg · 24/80/160 · all channels
3. Enterprise Data Platform (EDP) · EAPI · Lena Oduya · 40/120/240 · Statements
4. CIAM / Security · CIAM · Mira Castellane · 40/120/280 · Mobile, Web
5. Mobile App – iOS · Mobile · Jasper Quill · 40/140/300 · —
6. Mobile App – Android · Mobile · Yuki Larkspur · 40/140/300 · —
7. Online Banking Web · Web · Nadia Fenwick · 40/120/280 · —
8. Payments Hub · EAPI · Tobias Wren · 60/160/320 · Notifications
9. Notifications Service · EAPI · Lena Oduya · 24/80/160 · Mobile
10. Statements & Documents · Web · Theo Marchetti · 32/100/200 · Web
11. SRE / Observability · SRE · Kai Moreau · 40/80/160 · —
12. Fraud Signals Integration · CIAM · Felix Hartwell · 40/120/240 · Payments Hub

---

## 5. Business rules

**Grooming slotting.** Sessions Tue and Thu 10:00 ET. A saved intake goes to the next session that is ≥1 business day away (cut-off 17:00 the prior business day); max 6 per session, overflow to the next; P1 jumps the queue. Invite → Delivery Lead, DC PM, DC SA, Requestor. 19 Oct save → **Tue 20 Oct**.

**Action required by.** When an initiative is waiting on someone (DC SA input, component approval, CRQ attachment), a reminder is queued every **2 business days** from the request until resolved. Chip shows owner + next date; 3rd reminder copies the DC PM.

**SA Completeness.** 9 sections, equal weight: Context · Scope · Impacted components · Integration/sequence · NFRs · Security · Data · Backout · Open questions resolved. <70% blocks L2.

**L2 estimate.** Dev hours = Σ component hours by complexity (catalogue). Add Architecture 10%, QA 35%, PM/Release 10% of dev; contingency 15% on the subtotal; round to nearest 50 h. T-shirt: XS <100 · S 100–300 · M 301–700 · L 701–1,500 · XL >1,500. Range ±25%. Hero: 560 + 56 + 196 + 56 = 868 → +130 → **1,000 h, L**. L2 Approved locks the baseline; any Change Summary edit afterwards is a scope change and a delta is shown.

**Approval reminders.** L2 "Pending approval" → requestor reminder every 3 business days; after the 3rd, escalate to Delivery Lead; Amber on Dependencies after 10 business days.

**Plan generation.** WBS template: 100 Estimation & Solution Finalization (DC SA) → 200 Development, one child per component (parallel; CIAM before API if scopes needed) → 300 Integration/SIT → 400 QA (QA Date = end) → 500 UAT/Business Validation → 600 Release Readiness & CRQ (Readiness Date = end) → 700 Production Implementation (on Target Release train) → 800 Hypercare (10 business days). Downstream components from the catalogue add a "Regression test: <component>" step under 300. Duration = hours ÷ (7 h × allocation % × people). Business days only; skip stat holidays; Production may never fall in the freeze.

**Health (RAG) — calculated from Planning onward; DC PM can override any dimension with a mandatory comment (badge "Manual").**
| Dimension | Green | Amber | Red |
|---|---|---|---|
| Schedule | Readiness float ≥5 bd, nothing overdue | Float 0–4 bd, or a task overdue ≤5 bd | Forecast misses Target Release, critical-path task overdue >5 bd, or Production in freeze |
| Resources | All assigned people ≤100% in the project window | Any person 101–110%, or an unassigned step starting ≤10 bd | Any person >110%, or a step starting ≤5 bd unassigned |
| Scope | No change after L2, SA Completeness 100% | 1 scope change or L2 delta ≤20%, or SA 70–99% | ≥2 changes or delta >20% |
| Dependencies | All component approvals in, no blocked downstream step | Approval pending with need-by ≤15 bd, or L2 pending >10 bd | Approval Rejected, or a dependency step overdue |
| Budget | Burn % − completion % ≤10 pts | 11–20 pts | >20 pts, or forecast > PRN funded |
Overall: **Red** if Schedule is Red or ≥2 dimensions Red; **Amber** if any Red or Amber; else **Green**. "Management attention" lists every Red with the WBS it hits.

**Capacity.** Available = monthly hours per person (Account Manager). Allocation = each assignment's hours spread evenly over its business days, summed per month/quarter. Demand is **Tentative** before L2 Approved, **Confirmed** after; both count toward utilisation, tentative drawn hatched. Utilisation colours: <70% grey (spare) · 70–100% green · 101–110% amber · >110% red. Team view = sum of members.

**PRN burndown.** Funded hours per PRN (seeded; $ = hours × CAD 110 blended). Charged hours seeded monthly through Sep 2026 for in-flight work; Forecast = charged + remaining planned hours. Chart: funded line, charged cumulative, forecast dashed; Red when forecast > funded.

**Change governance compliance (weekly list every Monday = CRQs starting in next 14 days).** Flags: raised <10 bd before start (Bundle) or <5 bd (Independent) · window inside freeze · Affected CIs empty · no backout plan · STO not Go by T-2 bd · validation attachment missing 24 h after Implemented. STO Approval auto-sets **Tentative Go** when all flags clear at T-5, **Tentative No Go** if any open; only the STO persona sets Go/No-Go.

---

## 6. UI copy guidance

Write like the Excel: short labels, the team's own words, sentence case, no marketing.

**Use:** RDDC # · Initiative · DC PM · DC SA · SA document · SA Completeness · Change Summary · DC Component · L2 estimate · DLR · WBS step · Readiness Date · QA Date · Release train · CRQ · STO approval · Tentative Go · CMS Lead · Rel Lead · PRN · Available / Allocated hours · Confirmed / Tentative · Action required by · Grooming session.
**Avoid:** ticket/project/epic for initiative · "AI magic", "insights", "smart" · story points · sprint velocity · "workspace" · "stakeholder alignment" · emojis · exclamation marks.

Button labels are verbs that say the result: **Generate Change Summary**, **Generate Project Plan**, **Generate Gantt view**, **Send L2 for approval**, **Predict risks**, **Create CRQ draft**, **Suggest fix**. Status messages state fact + next date: "Slotted for grooming Tue 20 Oct, 10:00." "Waiting on Sana Whitfield — next reminder Wed 21 Oct." Empty states say what to do: "No SA document yet. Attach one to generate the Change Summary." Every calculated value has a "How we got this" link showing the rule and inputs.
