# 00 · MASTER PLAN — BMO DC Project Management Tool (local showcase demo)

This file is THE contract. It merges the five panel plans in `docs/planning/` and **overrides them wherever they conflict**.
Read order for any builder: this file → `docs/planning/2_solution_architect.md` (schema/API/files base) → the role doc relevant to your slice (1 PO = fields/rules/seed, 3 AI = features/prompts/schemas, 4 UX = layout/tokens/copy, 5 QA = tests) → `docs/01_requirements.md`.

**North star:** The Excel "Demo View" workbook turned into a working app. ONE INTAKE IN → HEALTH + CAPACITY + GANTT, with an AI layer on every yellow button. It reads like a BMO PM's tool: business labels, no dev jargon, no fluff, nothing fake-looking, nothing broken. A feature that isn't working by freeze is hidden, not shown half-done.

---

## 1. Pinned decisions (resolving panel conflicts)

| Topic | Decision |
|---|---|
| Stack | Flask 3.1 + stdlib sqlite3 + vanilla JS ES-module SPA, hand-rolled SVG charts, no build, no CDN (works offline). Python venv at `.venv` (3.13). |
| Port / launch | **5055**. `./run.sh` (init DB if missing, serve), `./reset.sh` (re-seed), `./run_demo.sh` (reset + serve + open browser). `debug=False`. `Cache-Control: no-store` on `index.html` and `/api/*`; static assets referenced with `?v=<APP_VERSION>`. |
| "Today" | App setting `demo_today`, default **2026-10-19** (env `BMO_TODAY` overrides). Every engine takes `today` as a parameter; nothing calls `date.today()` except config. Seed dates are **absolute** (PO doc §4), not relative offsets. |
| Fiscal year | BMO FY starts 1 Nov. **FY27 = 2026-11-01 … 2027-10-31**. Q1 Nov–Jan, Q2 Feb–Apr, Q3 May–Jul, Q4 Aug–Oct. Quarter labels read exactly "Nov–Jan", "Feb–Apr", "May–Jul", "Aug–Oct" (en dash). |
| Calendar | Business days Mon–Fri; stat holidays 2026-11-11, 2026-12-25, 2026-12-28, 2027-01-01, 2027-02-15. Change freeze 2026-12-14 … 2027-01-08. Release trains (all Saturdays): DC-2610 2026-10-17 (done), DC-2611 2026-11-21, DC-2612 2026-12-12, DC-2701 2027-01-16, DC-2702 2027-02-20, DC-2703 2027-03-20. Store in `lookups`/`release_trains` table. |
| Hero intake | **RDDC-24817 "US API Enhancement"** (LOB US P&C, requestor Clara Pemberton, P2, DC PM Grace Ellingham, DC SA Sana Whitfield, Tech Lead Devon Achterberg, DC Intake DCI-3391, PRN-77310, target DC-2702). It is **created live** in the demo (not seeded). The RDDC auto-number sequence must yield 24817 for the first new initiative after reset. Settings has a **"Fast-forward hero"** safety button that runs the whole hero pipeline server-side (create → attach sample SA → change summary → L2 approve → WBS → resources) so the presenter can recover in one click. |
| Seed | PO doc §4 exactly: 8 initiatives RDDC-24310…24790, 15 capacity-tracked people + 8 non-tracked roles, 12 DC components with downstream links, release trains, 3+ PRNs with monthly charges, CRQs (≥4 incl. 2 non-compliant), grooming sessions (Tue/Thu 10:00), risks, decisions, lessons (from 24310), meeting notes, documents. Sana Whitfield ≈105% in Nov 2026 before the hero. Names are fictional (PO list). No lorem/test/foo. Hours ragged (e.g. 137.5), not all round. |
| Hero SA doc | `app/seed/files/SA_US_API_Enhancement_v1.2.docx` (+ `.pdf` + `.md`), 1,000–1,400 words. Content = AI-Lead doc §5 item 1 (accounts/transactions APIs for US digital channels + partner aggregators; CIAM scopes; EDP CDC to Kafka; Security mTLS; SRE SLOs; approvals table; 2 TBDs; **no backout plan section** → SA Completeness 88%). Components it must yield: **API Platform (High), Enterprise Data Platform (Medium), CIAM / Security (Medium), SRE / Observability (Low)**. Also ship `SA_OLB_Realtime_Alerts_v0.3.docx` (deliberately vague, for Intake Analysis showcase). |
| L2 rule | PO §5: dev = Σ catalogue hours by complexity (Low/Med/High); + Architecture 10% + QA 35% + PM/Release 10% of dev; + 15% contingency on subtotal; round to nearest 50 h; T-shirt XS<100, S 100–300, M 301–700, L 701–1,500, XL>1,500; range ±25%. **Hero: 560 dev → 1,000 h, L, 750–1,250.** Numbers from `engines/l2.py` only; AI writes narrative/assumptions. |
| Complexity enum | Stored as `Low`/`Medium`/`High` everywhere (UI, DB, AI schemas). |
| RAG rules | PO §5 table with one fix — **Scope**: Green = no scope change after L2 approval AND SA Completeness ≥80; Amber = SA 60–79 or 1 change / L2 delta ≤20%; Red = SA <60 or ≥2 changes or delta >20%. Dimensions: Schedule, Resources, Scope, Dependencies, Budget. **Overall: Red if Schedule Red or ≥2 dims Red; else Amber if any Red/Amber; else Green.** Health is computed from stage Planning onward (earlier → "Not scored yet"). DC PM override per dimension with mandatory reason. `attention` = every Red reason naming the WBS it hits, e.g. "SA capacity constraint affecting WBS-100". |
| Hero health target | After plan + resources: **Overall Amber · Schedule Amber · Resources Red (Sana 128% Nov) · Scope Green · Dependencies Green · Budget Green**. "Suggest fix" → move WBS-100 to Mateo Brennan → Resources Green, overall stays Amber. Seed/engine/fixtures must be tuned so this holds (golden test). |
| Capacity | Monthly available hours per person; task hours spread evenly over its business days → months. Demand **Tentative before L2 Approved, Confirmed after**; both count. Bands: <70% "spare" grey · 70–100% green · 101–110% amber · >110% red. Teams for deck bars: **EAPI (Dev1), EAPI (Dev2), CIAM, SRE** (+ Mobile, Web, QA, DC SA in full view). |
| Grooming | Tue/Thu 10:00 ET; next session ≥1 business day away (cut-off 17:00 prior business day); max 6/session; P1 jumps queue. Saving hero on Mon 19 Oct → **Tue 20 Oct 10:00**. Invites go to Outbox (Delivery Lead Arlo Kingsley, DC PM, DC SA, Requestor). |
| Reminders | "Action required by" every 2 business days while waiting on someone; L2 approval reminders every 3 business days, escalate to Delivery Lead after 3rd. Outbox only — no real email. Dedupe keys. |
| AI pattern | **AI proposes, user Accepts.** Every AI endpoint returns a proposal logged in `ai_runs`; nothing is written until `POST /api/ai-runs/{id}/apply`. Tiers: Live Claude (if `ANTHROPIC_API_KEY` and setting allows) → fixture (test-agent authored) → deterministic generator. Live failure/timeout (20 s) → fallback, chip "Live → Simulated". Dates/hours/RAG/capacity/compliance always computed in Python. |
| AI models | `claude-opus-5-5` for change_summary, wbs, risks, assistant; `claude-sonnet-5-5` for the rest. Env overrides `BMO_AI_MODEL_HEAVY`, `BMO_AI_MODEL_FAST`. Forced tool-use JSON (`emit_<feature>`). |
| Fixture matching | Lookup order: `fixtures/<feature>/<RDDC>.json` → else fixture whose `match.name_contains` is in initiative name (case-insensitive) → `fixtures/<feature>/<input_hash>.json` → generator. Fixtures hold `variants: [ {...}, {...} ]`; Regenerate serves the next variant (then generator). |
| Workspace IA | UX doc: top navy bar + left rail (Add New Initiative · Edit Initiative · Search Initiative · Portfolio View │ Intake & Grooming · Resources · Risk Register · Change Mgmt · Artifacts · Outbox │ AI Activity · Settings). Initiative workspace = header (RDDC, name, RAG, stage) + 5-step stepper + tabs **Pg 1 · Pg 2 · Pg 3 · Pg 4 · Pg 5 · Risks · Artifacts** + "Print view" (all pages stacked). Persona switcher in top bar (demo.user acting as: DC PM / Dev Lead / Requestor / STO / Account Manager) — used as actor in activity log and to gate Approve buttons softly (always allowed, just labelled). |
| Gantt editing | No drag. Dates edited in the WBS grid; Gantt + health + capacity recompute live (no reload). Slip propagates to dependants (`schedule.propagate_slip`). |
| Excel export | `GET /api/export/demo-view.xlsx?initiative_id=` mirroring the workbook (Mission Statement, Demo View Pg1–Pg4 boxed with yellow automation cells, Portfolio View, Gantt, Capacity, Risk Register, Sheet1 lookups as data validations) + `GET /api/export/portfolio.xlsx`. Escape cells starting with `= + - @`. |
| Dates in JS | Only `static/js/dates.js` parses/formats dates (`parseISODate('YYYY-MM-DD')` → local Date; never `new Date('YYYY-MM-DD')`). Display "19 Oct 2026", short "19 Oct"; hours "120 h". |
| Safety | All user/AI text rendered via `textContent` or `esc()`; SQL only with `?` params; uploads: .docx/.pdf/.md/.txt, ≤10 MB, `secure_filename`, stored under `data/uploads/`, parse failure → 422 with friendly message + paste-text fallback. Every fetch has error handling; every AI spinner has a 25 s client timeout with recovery. |

## 2. AI feature catalogue (build all; MUST = in demo script)

Feature keys (snake_case; URL kebab-case). Output schemas live in `app/ai/schemas.py` (B3 writes first, then frozen). Base on AI-Lead doc §1–2, adapted to Architect table names.

| # | Key | Trigger (UI) | Pri |
|---|---|---|---|
| F1 | `intake_analysis` | Auto after first save on Add New Initiative + "Analyse intake" on Pg 1 (completeness, labels, likely components, duplicate check vs existing initiatives, clarifying questions) | MUST |
| F2 | `change_summary` | Pg 1 **Generate Change Summary** (from SA doc) → rows + SA completeness + gaps | MUST |
| F3 | `l2_estimate` | Pg 1 L2 panel "How we got this" narrative + comparables; numbers from engine | MUST |
| F4 | `wbs` | Pg 2 **Generate Project Plan** (includes downstream regression steps from component dependencies = Dependency Mapping) | MUST |
| F5 | `resources` | Pg 3 **Suggest Resources** / per WBS row "Recommended Developer" with score + reasons | MUST |
| F6 | `rebalance` | Health Resources Red → **Suggest fix** (move task to best alternative; shows before/after %) | MUST |
| F7 | `risks` | Risks tab **Predict risks** → register rows (sev×likelihood, trigger signal, mitigation steps, linked WBS) | SHOULD |
| F8 | `exec_summary` | Pg 5 / Portfolio **Write Executive Summary** (initiative or portfolio scope; weekly status) | SHOULD |
| F9 | `cr_compliance` | Pg 4 **Check CR Compliance** (rules in code; AI writes reviewer note + fixes) + **Create CRQ draft** (deterministic) | SHOULD |
| F10 | `skill_matrix` | Resources → **Generate Skill Matrix** (from task history) | SHOULD |
| F11 | `nudges` | Outbox **Draft reminders** (consolidated "Action required by" messages per recipient) | SHOULD |
| F12 | `meeting_extract` | Artifacts → Meeting Notes **Extract actions** (decisions → Decision Log, actions) | COULD |
| F13 | `lessons` | Artifacts → Lessons **Draft lessons learned** for closed initiatives; "Relevant lessons" on new intake | COULD |
| F14 | `intake_autofill` | Add New Initiative: drop SA doc → pre-fill fields with per-field confidence | SHOULD |
| F15 | `assistant` | Global drawer: intent router over live DB (17 intents per AI-Lead §3) + showcase Q&A fixtures with live-number bindings; "Copy to email" | MUST |

Every AI output renders in the shared **AI Result Card** (UX §2.7): "AI-generated — review before use", mode chip (Simulated · test-agent response / Simulated · rules engine / Live · Claude), confidence pill, sources, gaps/warnings, Accept · Edit before accepting · Regenerate · Discard. Client shows feature-specific thinking steps (UX §5) for 1.5–3 s ("Realistic") or 0.3 s ("Fast" setting). Accepted cells flash `--ai-fill` and carry an "AI" tag until edited. **AI Activity** page lists all runs + "time saved" counter.

## 3. Build team — file ownership (exclusive) and deliverables

Base file tree = Architect doc §2 with these changes: add `static/js/dates.js` (B4), `static/js/views/{outbox,ai_activity,governance}.js` (B5), `static/js/views/pg5_portfolio.js` (B5; initiative-scoped Pg 5 reuses portfolio components), `app/engines/calendar.py` holds holidays/freeze/trains, `run_demo.sh` (B1), `app/seed/files/*` (B6), `app/ai/fixtures/**` (B6), `tests/golden/*.json` (B2).

| Builder | Role | Owns |
|---|---|---|
| **B0 Contracts** (Architect) | Writes frozen contracts before others start | `app/schema.sql`, `app/db.py`, `app/__init__.py` skeleton (blueprint list, missing ones skipped), `app/config.py`, `app/ai/schemas.py`, `tests/fixtures/bundle_hero.json` (shape sample), `static/js/api.js` (all endpoint functions), `docs/contracts.md` (any clarifications) |
| **B1 Core data & CRUD** | Backend data engineer | run/reset/run_demo scripts, `requirements.txt`, `pytest.ini`, `app/cli.py`, `repo.py`, `activity.py`, `errors.py`, `textract.py`, `app/seed/*.json` + `seed.py`, `app/api/{core,initiatives,plan,resources,governance,artifacts}.py`, `tests/conftest.py`, `tests/api/test_crud_*.py` |
| **B2 Engines, views, export** | Calculation engineer | `app/engines/**`, `app/services/{derive,xlsx_export}.py`, `app/api/{views,export}.py`, `tests/engines/**`, `tests/golden/**`, `tests/api/test_views.py`, `tests/api/test_export.py` |
| **B3 AI platform** | AI engineer | `app/ai/{provider,simulated,claude,prompts,context,generators,assistant,apply}.py`, `app/api/ai.py`, `tests/ai/**` (incl. fixture validator) |
| **B4 Frontend shell & workspace** | Frontend engineer | `static/index.html`, `static/css/app.css`, `static/js/{main,state,dates}.js`, `static/js/ui/**` (components, ai_card, thinking steps), `static/js/views/{search,initiative_new,initiative,pg1_general,pg2_plan,pg3_resources,pg4_governance,risks_tab,artifacts_tab,settings}.js` |
| **B5 Dashboards, charts, portfolio** | Data-viz engineer | `static/css/charts.css`, `static/js/charts/**`, `static/js/views/{portfolio,pg5_portfolio,intake,resources,risks,changes,artifacts,outbox,ai_activity,assistant}.js`, `tests/e2e/**` |
| **B6 Content & AI-response author** ("test agent") | Plays the live model; writes everything the simulated AI serves | `app/seed/files/**` (SA docs .md/.docx/.pdf, meeting notes), `app/ai/fixtures/**` (per feature, per seed + hero, 2 variants for hero F2/F4/F7; assistant showcase Q&A ≥25 with bindings), `app/ai/fixtures/manifest.json` |

## 4. Lines of defense (QA doc §1, adopted)

L1 builder self-check (ruff/compileall/node --check/boot/slice tests) → L2 API contract QA (independent agent; every route tested; meta-test) → L3 engine golden QA (hand-computed goldens incl. hero deck parity) → L4 Playwright E2E full demo script + click-all sweep + 3 timezones + 1366/1920 viewports, fail on console error / ≥500 / unhandled rejection / "undefined|NaN|null" text → L5 red-team code review (XSS, SQLi, uploads, dead buttons, spinners, dates, export injection) → L6 fresh-eyes "BMO Director" rehearsal (≥4/5 on all dimensions) → L7 final regression ×3 from clean reset, simulated output identical.

Defect loop: failure → owning builder fixes + adds regression test at lowest layer → re-run from L2.

## 5. Demo script

PO doc §1 (15 steps, ~9 min) is the script, with UX labels. It becomes `docs/DEMO_SCRIPT.md` (presenter-facing, ≤1 page) at the end, matching the app click-for-click.

---

## 6. Red-team amendments (binding)

Overrides all earlier sections and panel docs. Arithmetic checked in Python.

### 6.1 Contract fixes (names, enums, ownership)
| Conflict | Binding value |
|---|---|
| Port | `BMO_PORT` default **5055**. Seed dates **absolute** (no `T±n`). |
| Hero key | **RDDC-24817** everywhere. Fixtures `fixtures/<feature>/RDDC-24817.json`. Seed sets `app_settings.rddc_next=24817`. |
| Complexity | `Low|Medium|High` in DB, schemas and fixtures. Columns `dc_components.base_hours_low/medium/high`; `initiative_components.complexity DEFAULT 'Medium'` with a CHECK. T-shirt is separate: `l2_tshirt` `XS|S|M|L|XL`. |
| Enums (CHECK constraints in `schema.sql`) | stage `Intake|Grooming|Solution|Estimation|Planning|Build|QA|Release|Closed` · l2_status `Draft|Pending approval|Approved|Rejected` · approval `Pending|Approved|Not required|Rejected` · task status `Backlog|In progress|Completed|Blocked` · risk severity/likelihood INTEGER **1–4**, mapped to PO labels (4×4 matrix; UX's 5×5 is void) |
| Component codes | `APIP` API Platform · `APIGW` · `EDP` · `CIAM` ("CIAM / Security") · `MOB_IOS` · `MOB_AND` · `OLB` · `PAYHUB` · `NOTIF` · `STMT` · `SRE` ("SRE / Observability") · `FRAUD`. AI schemas use these codes. |
| WBS codes | `WBS-100`, child `WBS-210`. Architect WBS schema (`offset/duration`); code computes dates. |
| Missing tables (B0) | `release_trains(code PK, train_date)`, `dc_intakes(code PK, name, lob, requestor, priority, requested_go_live)`. Initiative columns: `requested_go_live`, `target_release`, `sa_version`, `l2_tshirt`. Task columns: `allocation_pct`, `at_risk`. `initiative_components.est_hours`. `grooming_sessions.capacity DEFAULT 6`. |
| Routes (UX wins) | `#/portfolio` (also the target of `#/`), `#/search`, `#/initiative/new`, `#/initiative/:id/:tab` with tab ∈ `pg1..pg5|risks|artifacts`, `#/intake`, `#/resources`, `#/risks`, `#/changes`, `#/artifacts`, `#/outbox`, `#/ai-activity`, `#/settings`. No `dashboard.js`; deck tiles in `portfolio.js`/`pg5_portfolio.js` (B5). |
| Orphans/overlaps | `views/governance.js` is void (it is `changes.js`, B5). The Governance Reviews approval queue and the release-train calendar go to `changes.js` (B5). `engines/sa_completeness.py` → B2. `app/ai/cli_ext.py` → B3. `schemas.py` and `bundle_hero.json` → **B0 only**, frozen **before** B6 writes any fixture. `api.js` (B0) covers every route incl. 15 AI features; additions via `docs/contracts.md`. |
| AI URLs | Initiative-scoped: `POST /api/initiatives/{id}/ai/{intake-analysis|change-summary|l2-estimate|wbs|resources|rebalance|risks|exec-summary|cr-compliance}`. Global: `POST /api/ai/{intake-analysis|intake-autofill|skill-matrix|exec-summary|nudges|meeting-extract|lessons}`. Chat: `/api/assistant/chat`. `ai_runs.mode` ∈ `simulated_fixture|simulated_generated|live|live_fallback`. |
| Fixture file | `{fixture_version, feature, key, match:{rddc?|name_contains?|intent?,patterns?}, variants:[output,…]}`. The single `output` key is void. |
| Timeouts | Live: `timeout=20`, **`max_retries=0`** (a retry exceeds the 25 s client timeout). |

### 6.2 Hero deck parity: reachable, but only with these pins
1. **Schedule Amber.** Readiness float = business days strictly between the Readiness Date and the target train date. Production `WBS-700` is a milestone on the **Saturday** train date and is exempt from business-day maths. The freeze blocks **only** WBS-700 and CRQ windows, not dev or QA work (AI-Lead's "skip freeze for all tasks" is void). Forward pass from plan start Tue 2026-10-20: dev ends Fri 2027-01-15 (40 bd) → SIT 2027-01-18..01-29 → QA 2027-02-01..**02-10** → UAT 02-11..02-12 → Readiness 02-16..**02-17** → Prod Sat **02-20** → Hypercare 02-22..03-05. Float = 2 (Thu 18, Fri 19) → **Amber**.
2. **Scope Green.** SA Completeness = `floor(sections_found/9*100)`. 8/9 = 88.9, so it **must floor to 88** (rounding would show 89). F1's `completeness_score` never writes `sa_completeness`. A scope change counts only as an insert, delete or complexity edit of `initiative_components` after `l2_approved_at`.
3. **Dependencies Green with CIAM Pending.** The PO's Green ("all approvals in") contradicts the target. New rule: Green unless an Amber or Red trigger fires. The need-by date is the earliest `planned_start` of that component's WBS-2xx task (Wed 2026-11-18), which is 21 bd away, more than 15 → no trigger. The SA approvals table reads: API Platform **Approved**, EDP **Approved**, CIAM / Security **Pending**, SRE / Observability **Not required**.
4. **Resources Red → Green after the fix: broken as written.** With Sana at 105% pre-hero, moving WBS-100 leaves her at 105% (Amber), and "drops to 96%" is impossible. **Seed Sana Nov = 115.5 h (96%)**. WBS-100 = Sana at 50%, **70 h, Tue 2026-10-20 → Tue 2026-11-17** (20 bd; Oct 31.5 h, Nov **38.5 h**) → 154.0/120 = **128%**. Seed Mateo Nov = 50.5 h → after the move 89.0/120 = **74%**. Every other hero assignee must stay ≤100% every month (Mira on CIAM, never Felix). Step-1 KPI "Over-allocated 2" = Felix (Dec) + **Hana Brightwater Dec 145.5/140 h (104%)**.
5. **Budget Green.** PRN-77310 funded 1,100 h, 0 charged. Σ hero WBS `est_hours` must be ≤1,000 (dev rows = exactly 560).
6. **Overall Amber** in both states. Grid-editing WBS-210 end +5 bd → Readiness 2027-02-24 → misses train → **Schedule Red → Overall Red**. Editing it back restores Amber. Golden test `tests/golden/hero_health.json` asserts both states.

### 6.3 Arithmetic verified
L2: 280+120+120+40 = 560 → +56+196+56 = 868 → ×1.15 = 998.2 → **1,000 h** (round to nearest 50), **L**, range computed from the **rounded** total → 750–1,250. Grooming: needs a fixed `demo_now` = demo_today **09:30 ET** (the wall clock after 17:00 would slot Thu 22 Oct) → **Tue 2026-10-20 10:00**. Seed leaves ≤5 slots on 20 Oct. Next SA reminder Wed 2026-10-21. Fiscal: 2026-10-31 FY26 Q4 · 2026-11-01 FY27 Q1 · 2027-01-31 FY27 Q1 · 2027-02-01 FY27 Q2. The API returns `{fy:"FY27",q:"Q1",label:"Nov–Jan"}`. Capacity bands on unrounded util: `<0.70 spare · ≤1.00 ok · ≤1.10 stretched · >1.10 over`. QA doc §0/§2 values that conflict (bands, grooming, L2 example, GS-1 names) are superseded by this section.

### 6.4 Top 5 integration risks → preventing contract line
1. **Enum drift** (seed/rules/fixtures/dropdowns) → §6.1 CHECKs; UI reads enums only from `GET /api/lookups`.
2. **Fixtures written to AI-Lead schemas** → schemas.py frozen first; `tests/ai/test_fixtures_valid.py` is B6's L1 gate.
3. **Calendar logic duplicated** → only `engines/calendar.py`; JS never computes business days.
4. **Orphaned spinner** → §6.1 timeouts; server always answers ≤22 s.
5. **Multiple writers of derived data** → only `services/derive.py`; CRUD and `apply.py` call `rebuild_allocations` + `refresh_health` in the same `transaction()`.
