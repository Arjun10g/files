# Digital Channels · Project Management Tool (local demo)

The MVP_Backlog "Demo View" workbook as a working app: one intake in → Change Summary → WBS project plan → Gantt → resource capacity → project health → change governance → portfolio view, with an AI layer on every yellow button.

## Run it

```bash
./run_demo.sh      # reset demo data, start on http://127.0.0.1:5055, open the browser
./run.sh           # start without resetting (creates the database on first run)
./reset.sh         # restore the starting sample data
```

First time on a new machine:

```bash
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
.venv/bin/python -m playwright install chromium   # only needed for the browser tests
```

Everything runs offline. Data lives in `data/` (SQLite + uploaded files); **Settings → Reset demo data** does the same as `./reset.sh`.

## Presenting

Follow `docs/DEMO_SCRIPT.md`. The sample SA document to attach in step 4 is `data/uploads/SA_US_API_Enhancement_v1.2.docx` (also `.pdf`, `.md`).
If anything goes wrong mid-demo, **Settings → Fast-forward hero** builds RDDC-24817 end to end in one click.
**Settings → AI response speed → Fast** shortens the AI "thinking" animation for rehearsals.

## AI modes

| Mode | When | What answers |
|---|---|---|
| Simulated AI · prepared response | default | Responses drafted in advance by an AI test agent from the same prompts and seed data, served only while the live data still matches them |
| Simulated AI · rules engine | any other input | Deterministic generators over the live data, so new intakes still get sensible output |
| Live Claude | `export ANTHROPIC_API_KEY=…` before `./run.sh`, then Settings → AI mode → Live Claude | `claude-opus-5-5` (document work) / `claude-sonnet-5-5` (the rest); any failure or 20 s timeout falls back to Simulated |

Every AI result is a proposal: nothing is saved until **Accept**. Dates, hours, capacity, RAG and compliance are always calculated by the rules engines, never by the AI. Every run is listed under **AI Activity**.

## Tests

```bash
.venv/bin/python -m pytest -q -m "not e2e"     # API, engine, AI and QA contract tests
.venv/bin/python -m pytest -q -m e2e           # browser walk-throughs of the demo script (Playwright)
```

## Where things are

| Path | What |
|---|---|
| `app/engines/` | Calendar (BMO fiscal year, holidays, freeze, release trains), health/RAG, capacity, L2 estimate, schedule/critical path, grooming, reminders, burndown, CR compliance |
| `app/ai/` | AI layer: provider tiers, prepared responses (`fixtures/`), generators, assistant, Accept logic |
| `app/api/` | JSON API (one module per area) |
| `app/seed/` | Sample portfolio, people, components, SA documents |
| `static/` | The app (plain JavaScript modules, hand-drawn SVG charts) |
| `docs/` | Requirements, panel plans, master plan, contracts, QA reports, demo script |
