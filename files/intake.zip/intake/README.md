# Digital Channels delivery portal

A local, persistent intake-to-delivery application. The operational workspace starts **empty**: no initiatives, people, allocations, funding, or generated proposals. Component and skill catalogues, lookup choices, holidays, and release trains are reference configuration.

```bash
./run.sh                 # http://127.0.0.1:5055
./run_demo.sh            # same portal; opens a browser and preserves your work
```

First-time installation:

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
```

Data is stored in `data/portal.db`; original uploads are stored in `data/portal_uploads/`. Both survive restarts. The previous demo database and its source files remain separate. `./reset.sh` is a legacy demo-only reset; it does not target the default portal. Do not point a demo reset at your operational database.

## Intake and delivery

1. **Add New Initiative** captures a request directly, including typed people names, platform, region, channel, APT/PR codes, ownership, funding, and solution concurrence. Open **People and funding** to enter new names or choose existing people. Saving registers or reuses the same people in Resources and links the funding entry; there is no second round of typing.
2. **Import data** reads `.xlsx`, `.xlsm`, `.csv`, `.docx`, text-based `.pdf`, `.md`, `.txt`, and `.json`. Use an existing Jira export or download a blank Excel template. Multiple sheets, title rows, repeated Jira columns, rich-text Jira descriptions, and custom field names are handled with rules.
3. **Review fields** shows mapped values, validation gaps, duplicates, original columns, and extraction evidence. Correct fields, select records, optionally remap columns, then save. Preview creates no initiatives or funding records. Commits are transactional and repeated commits return the same result. Existing records are flagged for review rather than overwritten.
4. Word extraction reads paragraphs, tables, nested tables, headers, footers, comments, footnotes, and endnotes. The full extracted document and original file remain accessible. Section coverage and technical facts such as TPS, latency, encryption, and AppCat references have source evidence. Explicitly select proposed component impacts before adding them; their approvals stay pending.
5. Open an initiative to confirm component impacts, calculate/submit/approve L2, build and review the delivery plan, assign people, track capacity and health, prepare release governance, and export the delivery workbook.

The regex parser reads text; it cannot interpret screenshots, architecture drawings, scanned PDFs, or embedded images. Paste a text copy for those sources. A section coverage percentage indicates extracted headings and content, not architectural approval. Reviewed names from Excel, Word, and Jira intakes register or reuse people when the intake is committed. Preview does not create people or funding entries.

People and funding can also be maintained from the initiative's **Intake & estimates** tab. Names are matched ignoring case and repeated spaces; existing people keep their current team, rate, and capacity. New intake people start with zero capacity and rate until those details are entered. New funding codes create linked Pending drafts when figures are missing. Explicit funding figures populate the shared budget; changing an existing shared budget requires selecting **Update this shared funding record**. Links from the intake open its resource allocation and funding details.

## Resource allocation and funding

**Resource allocation** manages people, teams, rates, skills, monthly availability, and initiative allocations entirely in the portal. Capacity heatmaps, team totals, utilization, confirmed/tentative hours, and over-allocation indicators use saved data.

**Funding** supports manual budgets and imports from spreadsheets, JSON, Word/PDF confirmations, or pasted emails. Capture funding/PR codes, approved hours or budget amount, currency, blended rate, Project/POD charging, decision, scope, and assumptions. Estimate lines track AppCat, team, STO, Planning/Development/Support, hours, rate, amount, and decision. Add monthly actuals and link initiatives for allocation-based forecasts. Different currencies are summarized separately. Estimate totals include every decision; the approved funding budget is recorded separately.

Funding text works best with explicit labels and tables, for example:

```text
PR Code: <your funding code>
Project name: <initiative>
Funded hours: <hours>
Hourly rate: <rate>
Team: <team>
AppCat: <application code>
Planning: <hours> hours @ $<rate>
Development: <hours> hours @ $<rate>
Support: <hours> hours @ $<rate>
```

## Experimental Jira integration

The **Experimental** tab has a separate local password and an eight-hour session. Create its initial password from the local machine. Passwords are hashed; sign-in attempts are throttled and mutations require a session CSRF token. This lab password protects the integration tab; the rest of this local portal is not enterprise SSO or a multi-user authorization system. Persona selection is an audit label, not authentication.

Upload/paste a saved Jira JSON object or an issue array, review the mapped fields, and save selected intakes. To fetch an issue directly, export these variables before starting:

```bash
export BMO_JIRA_BASE_URL='https://your-jira-host'
export BMO_JIRA_TOKEN='<API token or bearer token>'
export BMO_JIRA_EMAIL='<email>'       # Basic auth; omit to use Bearer
export BMO_JIRA_API_VERSION='3'       # use 2 for Jira versions that require it
./run.sh
```

Issue fetches are read-only and use only the configured HTTPS host; redirects are rejected. Server credentials are not sent to the browser. Browser SSO cookies are not reused: the configured Jira identity must have API permission. For scoped Atlassian Cloud tokens, use the appropriate `https://api.atlassian.com/ex/jira/<cloudId>` base URL. See [Atlassian authentication](https://developer.atlassian.com/cloud/jira/platform/basic-auth-for-rest-apis/) and [Jira REST API](https://developer.atlassian.com/cloud/jira/platform/rest/v3/intro).

## Rules now, Bedrock later

The portal uses deterministic rules over current records. Prepared demo responses are disabled in the operational workspace, and an unrelated Anthropic key does not activate a provider. Proposals require explicit acceptance; calculations remain owned by the planning engines.

The optional Amazon Bedrock adapter uses the [Converse API](https://docs.aws.amazon.com/boto3/latest/reference/services/bedrock-runtime/client/converse.html), the existing structured schemas, source policies, audit trail, validation, and rules fallback. To connect it later:

```bash
.venv/bin/pip install -r requirements-bedrock.txt
export BMO_AI_PROVIDER=bedrock
export BMO_BEDROCK_ENABLED=true
export BMO_BEDROCK_REGION='<AWS region>'
export BMO_BEDROCK_MODEL_ID='<model or inference-profile ID>'
./run.sh
```

Use the standard AWS credential chain or an IAM workload role with permission to invoke the model. In **Settings**, choose the configured provider mode. Bedrock stays disabled without explicit opt-in; failed calls produce a labelled local rules proposal. Real Jira and AWS connectivity require your credentials and environment; tests use controlled transports and make no live service calls.

The service binds to loopback by default. For a shared deployment, add enterprise authentication/authorization, a production WSGI server, HTTPS, secure-cookie configuration, and managed credentials. `.env.example` documents settings; `.env` files are not loaded automatically.

## Verification

```bash
.venv/bin/python -m pytest -q -m 'not e2e'  # API, engines, parsing, auth, provider, contracts
.venv/bin/python -m playwright install chromium
.venv/bin/python -m pytest tests/e2e/test_portal_intake.py tests/e2e/test_portal_intake_connections.py tests/e2e/test_portal_operations.py -q -m e2e
.venv/bin/python -m ruff check app
```

Portal browser tests use isolated temporary databases. Earlier demo-script browser tests remain in `tests/e2e/` as historical scenarios; their original interface assumptions differ from the operational portal. The four WhatsApp videos informed the implementation; their displayed workbooks were not themselves imported or preloaded.
