#!/usr/bin/env bash
# Portal launch: preserve entered data, initialize an empty workspace when missing, and open a browser.
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f .venv/bin/activate ]; then
  echo "Python environment .venv not found. Create it with: python3 -m venv .venv && .venv/bin/pip install -r requirements.txt" >&2
  exit 1
fi
# shellcheck disable=SC1091
source .venv/bin/activate
PORT="${BMO_PORT:-5055}"

open_url() {
  open "$1" 2>/dev/null || echo "Open $1 in your browser."
}

HEALTH="$(curl -fsS --max-time 2 "http://127.0.0.1:${PORT}/api/health" 2>/dev/null || true)"
if printf '%s' "$HEALTH" | grep -q '"version"' && printf '%s' "$HEALTH" | grep -q '"status": *"ok"'; then
  echo "The portal is already running at http://127.0.0.1:${PORT}/."
  open_url "http://127.0.0.1:${PORT}/"
  exit 0
fi

FREE_PORT="$(python - "$PORT" <<'PY'
import socket, sys
start = int(sys.argv[1])
for port in range(start, start + 20):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", port))
        except OSError:
            continue
        print(port)
        break
PY
)"
if [ -z "$FREE_PORT" ]; then
  echo "Ports ${PORT}-$((PORT + 19)) are all in use. Free one or set BMO_PORT." >&2
  exit 1
fi
if [ "$FREE_PORT" != "$PORT" ]; then
  echo "Port ${PORT} is used by another program; using ${FREE_PORT} instead."
fi
export BMO_PORT="$FREE_PORT"
URL="http://127.0.0.1:${FREE_PORT}/"

python -m app.cli init-if-missing
python -m app.cli run &
SERVER_PID=$!
trap 'kill "$SERVER_PID" 2>/dev/null || true' INT TERM EXIT
for _ in $(seq 1 60); do
  if ! kill -0 "$SERVER_PID" 2>/dev/null; then
    wait "$SERVER_PID" || true
    echo "The server did not start. See the message above." >&2
    exit 1
  fi
  if curl -fsS "${URL}api/health" >/dev/null 2>&1; then
    open_url "$URL"
    break
  fi
  sleep 0.5
done
wait "$SERVER_PID"
