"""The only writer of derived data: allocations (source='derived'), rag_cached / health_cached_json,
reminder and grooming-invite notifications, and grooming slots.

Every function joins the caller's transaction (db.transaction() nests with savepoints), so a CRUD write and the
recalculation it triggers commit or roll back together.
"""
from __future__ import annotations

from app import db, errors
from app.engines import calendar as cal
from app.engines import capacity, compliance, grooming, health, reminders
from app.today import get_now, get_today, now_iso

PRE_PLANNING = ("Intake", "Grooming", "Solution", "Estimation")
STATUS_BY_STAGE = {"Intake": "Backlog", "Grooming": "Backlog", "Solution": "Backlog", "Estimation": "Backlog",
                   "Planning": "In progress", "Build": "In progress", "QA": "In progress", "Release": "In progress",
                   "Closed": "Completed"}


def _repo():
    from app import repo
    return repo


# ------------------------------------------------------------------ allocations
def rebuild_allocations(initiative_id) -> int:
    """Replace this initiative's derived allocations from its WBS rows. Returns the number of rows written.

    Each task's hours are spread evenly over its business days and bucketed by month. Summary rows (children and
    no hours of their own) are skipped. Demand is confirmed once L2 is Approved, tentative before.
    """
    with db.transaction():
        ini = db.query_one("SELECT id, l2_status FROM initiatives WHERE id = ?", (initiative_id,))
        if ini is None:
            raise errors.not_found("Initiative", initiative_id)
        firmness = "confirmed" if ini["l2_status"] == "Approved" else "tentative"
        tasks = db.query(
            "SELECT id, parent_id, resource_id, planned_start, planned_end, est_hours FROM wbs_tasks "
            "WHERE initiative_id = ? ORDER BY sort, id", (initiative_id,))
        parents = {t["parent_id"] for t in tasks if t["parent_id"] is not None}
        db.execute("DELETE FROM allocations WHERE initiative_id = ? AND source = 'derived'", (initiative_id,))
        rows = []
        for t in tasks:
            hours = float(t["est_hours"] or 0)
            if t["id"] in parents and not hours:
                continue
            if not t["resource_id"] or not t["planned_start"] or hours <= 0:
                continue
            for month, h in capacity.spread_hours(t["planned_start"], t["planned_end"] or t["planned_start"],
                                                  hours).items():
                if h > 0:
                    rows.append((t["resource_id"], initiative_id, t["id"], month, h, firmness))
        if rows:
            db.executemany(
                "INSERT INTO allocations (resource_id, initiative_id, task_id, month, hours, firmness, source) "
                "VALUES (?, ?, ?, ?, ?, ?, 'derived')", rows)
        return len(rows)


# ------------------------------------------------------------------ health
def compute_health(initiative_id, today=None) -> dict:
    """Health for one initiative from the live bundle (read-only)."""
    bundle = _repo().get_initiative_bundle(initiative_id)
    return health.compute_health(bundle, today or get_today())


def _cache_health(initiative_id) -> dict:
    """Cache health, and keep Current Status in step with the stage (PO §3: Backlog until Planning)."""
    result = compute_health(initiative_id)
    stage = db.scalar("SELECT stage FROM initiatives WHERE id = ?", (initiative_id,))
    db.execute("UPDATE initiatives SET rag_cached = ?, health_cached_json = ?, status = COALESCE(?, status) "
               "WHERE id = ?", (result["overall"] if result["scored"] else None, db.to_json(result),
                                STATUS_BY_STAGE.get(stage), initiative_id))
    return result


def refresh_health(initiative_id) -> dict:
    """Recompute and cache health (rag_cached, health_cached_json) for this initiative and every other one.

    Health depends on people shared across initiatives (one plan can push a person over 110% and turn another
    initiative's Resources Red), so every cached RAG is refreshed in the same transaction. With a portfolio of
    this size that is a few milliseconds, and Search, train cards and headers can never disagree with Portfolio.
    Returns this initiative's health.
    """
    with db.transaction():
        result = _cache_health(initiative_id)
        for row in db.query("SELECT id FROM initiatives WHERE id <> ? ORDER BY id", (initiative_id,)):
            _cache_health(row["id"])
        return result


def refresh_all_health() -> int:
    """Recompute and cache health for every initiative (after reset or a demo-date change)."""
    ids = [r["id"] for r in db.query("SELECT id FROM initiatives ORDER BY id")]
    with db.transaction():
        for iid in ids:
            _cache_health(iid)
    return len(ids)


# ------------------------------------------------------------------ people helpers
def _name(resource_id) -> str | None:
    if not resource_id:
        return None
    row = db.query_one("SELECT name FROM resources WHERE id = ?", (resource_id,))
    return row["name"] if row else None


def delivery_lead() -> dict | None:
    row = db.query_one(
        "SELECT id, name FROM resources WHERE active = 1 AND (role = 'Delivery Lead' OR team = 'Delivery') "
        "ORDER BY id LIMIT 1")
    return dict(row) if row else None


REMINDER_FAMILIES = {"l2_approval": ("l2_approval", "l2_escalation"), "l2_escalation": ("l2_approval", "l2_escalation")}


def _family(rule: str) -> tuple:
    return REMINDER_FAMILIES.get(rule, (rule,))


def _is_duplicate(n: dict) -> bool:
    """Same dedupe key, or the same reminder already exists under another key (seeded rows, AI nudges):
    same rule family, item, recipient and due date; or a weekly CRQ notice already queued that week."""
    if n.get("dedupe_key") and db.query_one("SELECT id FROM notifications WHERE dedupe_key = ?", (n["dedupe_key"],)):
        return True
    due = str(n.get("due_at") or "")[:10]
    if not due or n.get("entity_id") is None:
        return False
    fam = _family(n["rule"])
    marks = ", ".join("?" for _ in fam)
    if db.query_one(f"SELECT id FROM notifications WHERE rule IN ({marks}) AND entity_type = ? AND entity_id = ? "
                    f"AND substr(due_at, 1, 10) = ? AND to_name = ?",
                    (*fam, n.get("entity_type"), n["entity_id"], due, n.get("to_name"))):
        return True
    if n["rule"] == "cr_noncompliance":
        crq = db.scalar("SELECT crq_number FROM change_requests WHERE id = ?", (n["entity_id"],))
        monday = cal.week_monday(due)
        for row in db.query("SELECT due_at, body FROM notifications WHERE rule = 'cr_noncompliance' "
                            "AND status <> 'Dismissed'"):
            if row["due_at"] and cal.week_monday(row["due_at"]) == monday and crq and crq in (row["body"] or ""):
                return True
    return False


def _supersede(n: dict) -> None:
    """A newer reminder replaces the still-queued older ones for the same item."""
    if n.get("entity_id") is None or not n.get("due_at"):
        return
    fam = _family(n["rule"])
    marks = ", ".join("?" for _ in fam)
    db.execute(f"UPDATE notifications SET status = 'Dismissed' WHERE status = 'Queued' AND rule IN ({marks}) "
               f"AND entity_type = ? AND entity_id = ? AND substr(due_at, 1, 10) < ?",
               (*fam, n.get("entity_type"), n["entity_id"], str(n["due_at"])[:10]))


def _insert_notification(n: dict) -> dict | None:
    """Insert unless it duplicates an existing notification. Returns the new row or None."""
    if _is_duplicate(n):
        return None
    values = {
        "rule": n["rule"],
        "trigger_event": n.get("trigger_event"),
        "initiative_id": n.get("initiative_id"),
        "entity_type": n.get("entity_type"),
        "entity_id": n.get("entity_id"),
        "to_resource_id": n.get("to_resource_id"),
        "to_name": n["to_name"],
        "cc_names": db.to_json(n.get("cc_names") or []),
        "subject": n["subject"],
        "body": n["body"],
        "action_required_by": n.get("action_required_by"),
        "due_at": n.get("due_at"),
        "status": "Queued",
        "escalation_level": int(n.get("escalation_level") or 0),
        "dedupe_key": n.get("dedupe_key"),
        "created_at": now_iso(),
    }
    nid = db.insert("notifications", values)
    row = db.query_one("SELECT * FROM notifications WHERE id = ?", (nid,))
    row["cc_names"] = db.from_json(row.get("cc_names"), [])
    return row


def queue_notification(n: dict) -> dict | None:
    """Public entry for views that queue a one-off notice (L2 request). Same dedupe rules."""
    with db.transaction():
        return _insert_notification(n)


# ------------------------------------------------------------------ reminders
def _component_since(comp_id, fallback):
    row = db.query_one(
        "SELECT MIN(ts) AS ts FROM activity_log WHERE entity_type IN ('initiative_component', 'component') "
        "AND entity_id = ?", (comp_id,))
    return (row or {}).get("ts") or fallback


def reminder_state() -> dict:
    """Snapshot for engines.reminders.due_reminders."""
    inis = db.query(
        "SELECT i.*, sa.name AS dc_sa_name, pm.name AS dc_pm_name, rq.name AS requestor_name_r, "
        "a.uploaded_at AS sa_uploaded_at "
        "FROM initiatives i "
        "LEFT JOIN resources sa ON sa.id = i.dc_sa_id LEFT JOIN resources pm ON pm.id = i.dc_pm_id "
        "LEFT JOIN resources rq ON rq.id = i.requestor_id "
        "LEFT JOIN attachments a ON a.id = i.sa_doc_attachment_id "
        "WHERE i.id > 0 AND i.stage <> 'Closed' ORDER BY i.id")
    comps = db.query(
        "SELECT ic.id, ic.initiative_id, ic.approval, ic.component_lead_id, c.name, c.code, r.name AS lead_name "
        "FROM initiative_components ic JOIN dc_components c ON c.id = ic.component_id "
        "LEFT JOIN resources r ON r.id = ic.component_lead_id ORDER BY ic.initiative_id, ic.sort, ic.id")
    by_ini: dict[int, list] = {}
    for c in comps:
        by_ini.setdefault(c["initiative_id"], []).append(c)
    out = []
    for i in inis:
        sa_since = i["sa_uploaded_at"] if i["sa_doc_attachment_id"] else None
        fallback = i["l2_submitted_at"] or sa_since or i["created_at"]
        out.append({
            "id": i["id"], "rddc": i["rddc"], "name": i["name"], "stage": i["stage"], "created_at": i["created_at"],
            "dc_sa_id": i["dc_sa_id"], "dc_sa_name": i["dc_sa_name"], "dc_pm_name": i["dc_pm_name"],
            "requestor_id": i["requestor_id"], "requestor_name": i["requestor_name_r"] or i["requestor"],
            "sa_completeness": i["sa_completeness"], "sa_missing": db.from_json(i["sa_missing_json"], []),
            "sa_attached": bool(i["sa_doc_attachment_id"]), "sa_since": sa_since,
            "l2_status": i["l2_status"], "l2_submitted_at": i["l2_submitted_at"], "l2_hours": i["l2_hours"],
            "l2_tshirt": i["l2_tshirt"],
            "components": [{"id": c["id"], "name": c["name"], "approval": c["approval"],
                            "component_lead_id": c["component_lead_id"], "component_lead_name": c["lead_name"],
                            "since": _component_since(c["id"], fallback)} for c in by_ini.get(i["id"], [])],
        })
    return {"initiatives": out, "change_requests": change_requests_with_compliance(), "delivery_lead": delivery_lead()}


def production_date(initiative_id) -> str | None:
    """The plan's production milestone date (WBS-700), else the initiative's prod_date."""
    if initiative_id is None:
        return None
    row = db.query_one(
        "SELECT planned_start FROM wbs_tasks WHERE initiative_id = ? AND is_milestone = 1 AND planned_start IS NOT NULL "
        "ORDER BY CASE WHEN phase = 'Production' THEN 0 ELSE 1 END, planned_start LIMIT 1", (initiative_id,))
    if row:
        return row["planned_start"]
    return db.scalar("SELECT prod_date FROM initiatives WHERE id = ?", (initiative_id,))


def compliance_context(initiative_id) -> dict:
    """Plan facts compliance.check_cr needs for CR-12/CR-13: production date and target train."""
    ctx = {"now": get_now().isoformat()}
    if initiative_id is None:
        return ctx
    ctx["plan_prod_date"] = production_date(initiative_id)
    train = db.query_one("SELECT t.code, t.train_date FROM initiatives i JOIN release_trains t "
                         "ON t.code = i.target_release WHERE i.id = ?", (initiative_id,))
    if train:
        ctx["target_train"] = dict(train)
    return ctx


def compliance_for(cr: dict) -> dict:
    """Live compliance for one CR row, including the plan-alignment rules."""
    return compliance.check_cr(cr, get_today(), compliance_context(cr.get("initiative_id")))


def change_requests_with_compliance(where: str = "", params: tuple = ()) -> list[dict]:
    """CR rows with joined names, parsed lists and live compliance including plan alignment. `where` is trusted."""
    rows = _repo().list_change_requests(where, params)
    for r in rows:
        ai = (r.get("compliance") or {}).get("ai")
        r["compliance"] = compliance_for(r)
        if ai is not None:
            r["compliance"]["ai"] = ai
    return rows


def run_reminders(now=None) -> dict:
    """Queue every reminder that is due on or before today and not queued yet; a newer reminder dismisses the
    older queued one for the same item. Upcoming reminders are not queued (the engine's next date drives the
    "Action required by" chips). Returns {created:[...], skipped:n, upcoming:n}."""
    today = cal.to_date(now) if now else get_today()
    with db.transaction():
        state = reminder_state()
        due = reminders.due_reminders(state, today)
        created, skipped, upcoming = [], 0, 0
        for n in due:
            if n.get("due_at") and cal.to_date(n["due_at"]) > today:
                upcoming += 1
                continue
            row = _insert_notification(n)
            if row is None:
                skipped += 1
            else:
                _supersede(n)
                created.append(row)
        for ini in state["initiatives"]:
            if ini["l2_status"] == "Pending approval":
                db.execute("UPDATE initiatives SET l2_reminders_sent = ? WHERE id = ?",
                           (reminders.l2_reminder_count(ini, today), ini["id"]))
        return {"created": created, "skipped": skipped, "upcoming": upcoming}


# ------------------------------------------------------------------ grooming
def _sessions_from(today) -> list[dict]:
    sessions = db.query(
        "SELECT * FROM grooming_sessions WHERE session_date >= ? ORDER BY session_date, start_time",
        (cal.iso(today),))
    slots = db.query(
        "SELECT s.session_id, s.initiative_id, s.slot_order, s.status, s.recipients_json, i.priority, i.rddc, "
        "i.name, i.created_at FROM grooming_slots s JOIN initiatives i ON i.id = s.initiative_id "
        "ORDER BY s.session_id, s.slot_order")
    by_session: dict[int, list] = {}
    for s in slots:
        by_session.setdefault(s["session_id"], []).append({**s, "submitted_at": s["created_at"]})
    for s in sessions:
        s["slots"] = by_session.get(s["id"], [])
    return sessions


def _ensure_session(session_date: str, start_time: str) -> int:
    row = db.query_one("SELECT id FROM grooming_sessions WHERE session_date = ? AND start_time = ?",
                       (session_date, start_time))
    if row:
        return row["id"]
    return db.insert("grooming_sessions", {
        "session_date": session_date, "start_time": start_time,
        "title": f"DC grooming – {grooming.label(session_date, start_time)}",
        "capacity": grooming.RULES["capacity"], "status": "Scheduled"})


def _recipients(ini: dict) -> list[dict]:
    lead = delivery_lead()
    people = []
    for rid in ((lead or {}).get("id"), ini.get("dc_pm_id"), ini.get("dc_sa_id"), ini.get("requestor_id")):
        if rid and rid not in [p["id"] for p in people]:
            name = _name(rid)
            if name:
                people.append({"id": rid, "name": name})
    if not ini.get("requestor_id") and ini.get("requestor"):
        people.append({"id": None, "name": ini["requestor"]})
    return people


def _queue_invites(ini: dict, session_date: str, start_time: str, recipients: list[dict]) -> list[dict]:
    when = grooming.label(session_date, start_time)
    out = []
    for p in recipients:
        row = _insert_notification({
            "rule": "grooming_invite",
            "dedupe_key": f"grooming_invite:initiative:{ini['id']}:{session_date}:{p['id'] or p['name']}",
            "initiative_id": ini["id"], "entity_type": "initiative", "entity_id": ini["id"],
            "to_resource_id": p["id"], "to_name": p["name"],
            "cc_names": [], "subject": f"Grooming invite: {ini['rddc']} {ini['name']} – {when}",
            "body": (f"{ini['rddc']} {ini['name']} is on the agenda for DC grooming on {when} ET. "
                     "Please review the intake and the SA document before the session."),
            "trigger_event": f"Saved {ini['rddc']}", "action_required_by": session_date,
            "due_at": cal.iso(get_today()), "escalation_level": 0,
        })
        if row:
            out.append({"id": row["id"], "to_name": row["to_name"], "subject": row["subject"]})
    return out


def _upcoming_slot(initiative_id, today) -> dict | None:
    return db.query_one(
        "SELECT g.id AS session_id, g.session_date, g.start_time, s.slot_order, s.status FROM grooming_slots s "
        "JOIN grooming_sessions g ON g.id = s.session_id WHERE s.initiative_id = ? AND g.session_date >= ? "
        "AND g.status = 'Scheduled' ORDER BY g.session_date LIMIT 1", (initiative_id, cal.iso(today)))


def slot_grooming(initiative_id) -> dict | None:
    """Put a saved intake on the next grooming session and queue the invites. None if it is past grooming."""
    with db.transaction():
        ini = db.query_one("SELECT * FROM initiatives WHERE id = ?", (initiative_id,))
        if ini is None:
            raise errors.not_found("Initiative", initiative_id)
        if ini["stage"] not in grooming.RULES["candidate_stages"]:
            return None
        today = get_today()
        existing = _upcoming_slot(initiative_id, today)
        if existing:
            return {**existing, "label": grooming.label(existing["session_date"], existing["start_time"]),
                    "notifications": [], "bumped": None}
        placement = grooming.slot_one(ini, _sessions_from(today), get_now())
        sid = placement["session_id"] or _ensure_session(placement["session_date"], placement["start_time"])
        bumped = placement["bumped"]
        if bumped:
            to_sid = bumped["to_session_id"] or _ensure_session(bumped["to_session_date"], bumped["to_start_time"])
            db.execute("UPDATE grooming_slots SET session_id = ?, slot_order = ? WHERE session_id = ? "
                       "AND initiative_id = ?", (to_sid, bumped["to_slot_order"], sid, bumped["initiative_id"]))
        people = _recipients(ini)
        db.execute(
            "INSERT INTO grooming_slots (session_id, initiative_id, slot_order, recipients_json, status) "
            "VALUES (?, ?, ?, ?, 'Proposed')",
            (sid, initiative_id, placement["slot_order"], db.to_json([p["id"] for p in people if p["id"]])))
        notes = _queue_invites(ini, placement["session_date"], placement["start_time"], people)
        return {"session_id": sid, "session_date": placement["session_date"], "start_time": placement["start_time"],
                "label": placement["label"], "slot_order": placement["slot_order"], "notifications": notes,
                "bumped": bumped}


def grooming_candidates(today) -> list[dict]:
    rows = db.query(
        "SELECT id AS initiative_id, rddc, name, priority, created_at AS submitted_at FROM initiatives "
        "WHERE id > 0 AND stage IN ('Intake', 'Grooming') AND id NOT IN (SELECT s.initiative_id FROM grooming_slots s "
        "JOIN grooming_sessions g ON g.id = s.session_id WHERE g.session_date >= ? AND g.status = 'Scheduled') "
        "ORDER BY priority, created_at, id", (cal.iso(today),))
    return rows


def auto_slot_grooming(dry_run: bool = False) -> dict:
    """Slot every unslotted intake (P1 first). With dry_run nothing is written."""
    today = get_today()
    with db.transaction():
        plan = grooming.auto_slot(grooming_candidates(today), _sessions_from(today), get_now())
        for a in plan["assignments"]:
            ini = db.query_one("SELECT * FROM initiatives WHERE id = ?", (a["initiative_id"],))
            people = _recipients(ini)
            a["recipients"] = people
            if dry_run:
                continue
            sid = a["session_id"] or _ensure_session(a["session_date"], a["start_time"])
            a["session_id"] = sid
            db.execute(
                "INSERT INTO grooming_slots (session_id, initiative_id, slot_order, recipients_json, status) "
                "VALUES (?, ?, ?, ?, 'Proposed')",
                (sid, a["initiative_id"], a["slot_order"], db.to_json([p["id"] for p in people if p["id"]])))
            _queue_invites(ini, a["session_date"], a["start_time"], people)
        return plan
