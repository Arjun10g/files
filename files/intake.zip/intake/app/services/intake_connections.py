"""Connect entered intake names and funding to shared portal records.

Call mutations inside the intake/import transaction. Preview uses the same matching
and validation without creating people or budgets.
"""
from __future__ import annotations

import re

from app import db, errors, repo
from app.activity import log_activity
from app.api._shared import Fields

PEOPLE = {
    'requestor': ('requestor_id', 'Requestor', 'Business', 0),
    'dc_pm': ('dc_pm_id', 'DC PM', 'DC PM', 1),
    'dc_sa': ('dc_sa_id', 'Solution Architect', 'DC SA', 1),
    'tech_lead': ('tech_lead_id', 'Technical Lead', None, 1),
    'pm': ('pm_id', 'Project Manager', None, 1),
    'assigned_to': ('assigned_to_id', 'Unspecified', None, 0),
    'business_analyst': (None, 'Business Analyst', 'Business', 0),
    'owner': ('owner_id', 'Budget Owner', 'Business', 0),
}
FINANCIAL = ('funded_hours', 'rate', 'budget_amount', 'currency')
FUNDING_KEYS = {'prn_code', 'name', 'lob', 'owner', 'owner_id', 'start_month', 'end_month',
                'decision', 'charge_type', 'scope', 'assumptions', 'platform', 'region',
                'channel', 'apt_number', 'external_pr_code', *FINANCIAL}


def portal_mode() -> bool:
    return repo.setting('workspace_mode') == 'portal'


def enabled(data: dict) -> bool:
    return portal_mode() or 'funding' in data or any(k in data for k in PEOPLE if k not in ('requestor', 'owner'))


def summary() -> dict:
    return {key: [] for key in ('people_created', 'people_reused', 'funding_created',
                                'funding_updated', 'funding_reused', 'warnings')}


def normalize_name(value: str) -> str:
    return ' '.join(value.split()).casefold()


def _add(result: dict, key: str, value: dict):
    if not any(item.get('id', item.get('prn_code')) == value.get('id', value.get('prn_code'))
               for item in result[key]):
        result[key].append(value)


def resolve_people(data: dict, *, commit: bool, result: dict | None = None,
                   include: tuple | None = None) -> tuple[dict, dict]:
    result = result if result is not None else summary()
    values = dict(data)
    for field, (target, role, team, tracked) in PEOPLE.items():
        if include is not None and field not in include:
            continue
        if field not in values and (not target or target not in values):
            continue
        f = Fields(values)
        f.text(field, max_len=120)
        if target:
            f.ref(target, 'resources', label='person')
        clean = f.check()
        name = clean.get(field)
        person = None
        if target and clean.get(target):
            person = db.query_one('SELECT * FROM resources WHERE id=?', (clean[target],))
            if name and normalize_name(name) != normalize_name(person['name']):
                raise errors.validation('Check the selected person.', {
                    field: 'The name does not match the selected person. Select a matching person or clear the selection.'})
        elif name:
            matches = [p for p in db.query('SELECT * FROM resources ORDER BY id')
                       if normalize_name(p['name']) == normalize_name(name)]
            if len(matches) > 1:
                raise errors.validation('Choose the person to link.', {
                    field: 'More than one portal person has this name. Choose an existing person by ID.'})
            person = matches[0] if matches else None
            if person is None:
                name = ' '.join(name.split())
                if commit:
                    rid = db.insert('resources', {'name': name, 'role': role, 'team': team,
                        'team_label': team, 'hourly_rate': 0, 'default_monthly_hours': 0,
                        'capacity_eligible': tracked, 'active': 1})
                    person = db.query_one('SELECT * FROM resources WHERE id=?', (rid,))
                    log_activity('resource', rid, 'create', {'label': name, 'source': 'intake'})
                    _add(result, 'people_created', {'id': rid, 'name': name, 'field': field})
                else:
                    result['warnings'].append(f'{field.replace("_", " ").title()} "{name}" will be added to Resources with zero hours and rate.')
        if person:
            if not any(p['id'] == person['id'] for p in result['people_created']):
                _add(result, 'people_reused', {'id': person['id'], 'name': person['name'], 'field': field})
            if target:
                values[target] = person['id']
            if field in ('requestor', 'business_analyst'):
                values[field] = person['name']
        elif name:
            values[field] = ' '.join(name.split())
        elif target and field in values and target not in values:
            values[target] = None
    return values, result


def funding_from_import(fields: dict) -> dict | None:
    """Flat import columns carry optional funding details on an intake row."""
    details = {k: v for k, v in fields.items() if k in FUNDING_KEYS and k not in
               ('name', 'lob', 'scope', 'assumptions', 'platform', 'region', 'channel', 'apt_number', 'external_pr_code')}
    for source, target in (('funding_name', 'name'), ('funding_scope', 'scope'), ('funding_assumptions', 'assumptions')):
        if source in fields:
            details[target] = fields[source]
    return details or None


def connect(data: dict, *, commit: bool, before: dict | None = None) -> tuple[dict, dict]:
    """Prepare an intake; persist shared records only when commit is true."""
    from app.api import funding

    values, result = resolve_people(data, commit=commit,
                                   include=tuple(k for k in PEOPLE if k != 'owner'))
    raw = values.get('funding')
    if raw is not None and not isinstance(raw, dict):
        raise errors.validation('Check the funding details.', {'funding': 'Send a funding object.'})
    details = dict(raw or {})
    if 'update_existing' in details and not isinstance(details['update_existing'], bool):
        raise errors.validation('Check the funding details.', {'funding.update_existing': 'Use true or false.'})
    supplied_code = details.get('prn_code')
    code = supplied_code or values.get('prn_code') or ((before or {}).get('prn_code') if raw is not None else None)
    if not code:
        if any(k in FUNDING_KEYS and v not in (None, '') for k, v in details.items()):
            raise errors.validation('Enter the funding code for these details.', {
                'prn_code': 'Enter the PRN or funding code to save these funding details.'})
        values.pop('funding', None)
        return values, result
    if not isinstance(code, str) or not re.fullmatch(r'[A-Z0-9][A-Z0-9._-]{0,59}', code.strip().upper()):
        raise errors.validation('Check the funding code.', {'prn_code': 'Use letters, numbers, dots, underscores or hyphens.'})
    code = code.strip().upper()
    if supplied_code and values.get('prn_code') and str(values['prn_code']).strip().upper() != code:
        raise errors.validation('Check the funding code.', {'funding.prn_code': 'Use the same code as the intake funding code.'})
    values['prn_code'] = code
    details['prn_code'] = code
    details, result = resolve_people(details, commit=commit, result=result, include=('owner',))
    cleaned, metadata = funding.budget_fields({k: v for k, v in details.items() if k in FUNDING_KEYS}, creating=False)
    existing = db.query_one('SELECT * FROM prn_budget WHERE prn_code=?', (code,))
    if existing:
        if details.get('update_existing') and 'budget_amount' not in cleaned and any(k in cleaned for k in ('funded_hours', 'rate')):
            merged = {**existing, **cleaned}
            cleaned['budget_amount'] = merged['funded_hours'] * merged['rate']
        current_meta = funding._metadata(code) if db.table_exists('funding_details') else {}
        conflicts = {k: 'This is a shared budget. Confirm the update to change its funding values.'
                     for k in FINANCIAL if k in cleaned and cleaned[k] != existing.get(k)}
        if conflicts and not details.get('update_existing'):
            raise errors.validation('Review the shared funding update.', {f'funding.{k}': v for k, v in conflicts.items()})
        updates = {k: v for k, v in cleaned.items() if k != 'prn_code' and v is not None and
                   (details.get('update_existing') or existing.get(k) in (None, '')) and v != existing.get(k)}
        meta_updates = {k: v for k, v in metadata.items() if v is not None and
                        (current_meta.get(k) in (None, '') or details.get('update_existing'))}
        if current_meta.get('intake_draft') and details.get('update_existing'):
            remaining = [k for k in current_meta.get('intake_missing_fields',
                         ['funded_hours', 'rate', 'budget_amount']) if k not in cleaned]
            meta_updates.update({'intake_draft': bool(remaining), 'intake_missing_fields': remaining})
        if commit and (updates or meta_updates):
            db.update('prn_budget', code, updates, key='prn_code')
            funding._write_metadata(code, meta_updates)
            log_activity('funding', None, 'update', {'label': code, 'source': 'intake'})
        _add(result, 'funding_updated' if updates or meta_updates else 'funding_reused', {'prn_code': code, 'name': existing.get('name')})
    else:
        context = {**(before or {}), **values}
        cleaned.setdefault('name', context.get('name') or code)
        for k in ('lob', 'platform', 'region', 'channel', 'apt_number', 'external_pr_code'):
            if k in context and context[k] not in (None, ''):
                (metadata if k in funding.META_FIELDS else cleaned).setdefault(k, context[k])
        if 'budget_amount' not in cleaned and all(k in cleaned for k in ('funded_hours', 'rate')):
            cleaned['budget_amount'] = cleaned['funded_hours'] * cleaned['rate']
        if 'funded_hours' not in cleaned and 'budget_amount' in cleaned and cleaned.get('rate', 0) > 0:
            cleaned['funded_hours'] = cleaned['budget_amount'] / cleaned['rate']
        missing = [k for k in ('funded_hours', 'rate', 'budget_amount') if k not in cleaned]
        for k in ('funded_hours', 'rate', 'budget_amount'):
            cleaned.setdefault(k, 0)
        cleaned.setdefault('currency', 'CAD')
        metadata.setdefault('decision', 'Pending')
        metadata.setdefault('charge_type', 'Project')
        metadata.update({'intake_draft': bool(missing), 'intake_missing_fields': missing})
        if commit:
            db.insert('prn_budget', cleaned)
            funding._write_metadata(code, metadata)
            log_activity('funding', None, 'create', {'label': code, 'source': 'intake'})
        else:
            result['warnings'].append(f'{code} will be added to Funding; missing financial values stay zero until entered.')
        _add(result, 'funding_created', {'prn_code': code, 'name': cleaned['name']})
    values.pop('funding', None)
    return values, result


def attach_source(result: dict, initiative_id: int):
    from app.api import funding
    for row in result['funding_created']:
        funding._write_metadata(row['prn_code'], {'source_initiative_id': initiative_id})
