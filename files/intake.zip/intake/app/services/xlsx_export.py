"""Excel exports built with openpyxl: the Demo View workbook for one initiative, and the portfolio workbook.

Pure builders: they take plain dicts (assembled by app/api/export.py) and return .xlsx bytes. Text cells that start
with = + - @ are escaped so Excel never evaluates them; dates are real date cells with a number format.
"""
from __future__ import annotations

import csv
import io
from datetime import date, timedelta

from openpyxl import Workbook
from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from app.engines import calendar as cal

MISSION = ("Create a single platform that manages intake, planning, governance, delivery, resource management, "
           "documentation, reporting, and AI-assisted decision making from project initiation through production "
           "deployment.")

NAVY = "0B2D5B"
BLUE = "0079C1"
YELLOW = "FFFF00"
LABEL = "EEF2F7"
GREY = "D9D9D9"
RAG_FILL = {"Red": "E04B4B", "Amber": "F2B03D", "Green": "4CA65A"}
BAND_FILL = {"spare": "D9D9D9", "ok": "C6E0B4", "stretched": "FFE699", "over": "F4B6B6"}
PHASE_FILL = {"Estimation": "9DC3E6", "Architecture": "9DC3E6", "Development": "2E75B6", "Integration": "5B9BD5",
              "QA": "70AD47", "UAT": "A9D18E", "Readiness": "FFC000", "Production": "7030A0", "Hypercare": "BDD7EE"}
CRITICAL_FILL = "C00000"
FREEZE_FILL = "F2F2F2"

THIN = Side(style="thin", color="A6A6A6")
MED = Side(style="medium", color=NAVY)
DATE_FMT = "dd mmm yyyy"
SHEET1_LISTS = (
    ("Status", "status", ("Backlog", "In progress", "Completed")),
    ("Release Type", "release_type", ("Bundle", "Independent")),
    ("STO Approval", "sto_approval", ("Tentative Go", "Tentative No Go", "Go", "No-Go")),
    ("Validation Status", "validation_status", ("Not Started", "In progress", "Completed", "Failed")),
    ("RAG", "rag", ("Red", "Amber", "Green")),
    ("Stage", "stage", ("Intake", "Grooming", "Solution", "Estimation", "Planning", "Build", "QA", "Release",
                        "Closed")),
    ("Implementation Status", "implementation_status",
     ("Not Started", "Scheduled", "In progress", "Implemented", "Backed out")),
    ("CRQ Approval Status", "crq_approval_status", ("Draft", "Submitted", "CAB Review", "Approved", "Rejected")),
    ("Approval", "approval", ("Pending", "Approved", "Not required", "Rejected")),
    ("Complexity", "complexity", ("Low", "Medium", "High")),
    ("Task Status", "task_status", ("Backlog", "In progress", "Completed", "Blocked")),
    ("L2 Status", "l2_status", ("Draft", "Pending approval", "Approved", "Rejected")),
)


# ------------------------------------------------------------------ cell helpers
def safe(value):
    """Escape formula-like text (= + - @, plus tab/CR) so Excel stores it as text."""
    if isinstance(value, str) and value and value[0] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + value
    return value


def _date(value):
    d = cal.to_date(value) if value else None
    return d


def _put(ws, row, col, value, *, bold=False, fill=None, color=None, fmt=None, wrap=False, align=None, size=None,
         border=True, italic=False):
    cell = ws.cell(row=row, column=col)
    if isinstance(value, date):
        cell.value = value
        cell.number_format = fmt or DATE_FMT
    else:
        cell.value = safe(value)
        if isinstance(cell.value, str):
            cell.data_type = "s"
        if fmt:
            cell.number_format = fmt
    if bold or color or size or italic:
        cell.font = Font(bold=bold, color=color, size=size or 10, italic=italic)
    else:
        cell.font = Font(size=10)
    if fill:
        cell.fill = PatternFill("solid", fgColor=fill)
    cell.alignment = Alignment(wrap_text=wrap, vertical="top", horizontal=align)
    if border:
        cell.border = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
    return cell


def _header_row(ws, row, col, headers, fill=NAVY):
    for i, h in enumerate(headers):
        _put(ws, row, col + i, h, bold=True, fill=fill, color="FFFFFF", wrap=True)


def _box(ws, top, left, bottom, right):
    """Medium navy outline around a Pg section, keeping inner borders."""
    for r in range(top, bottom + 1):
        for c in range(left, right + 1):
            cell = ws.cell(row=r, column=c)
            b = cell.border
            cell.border = Border(
                left=MED if c == left else b.left, right=MED if c == right else b.right,
                top=MED if r == top else b.top, bottom=MED if r == bottom else b.bottom)


def _title(ws, row, col, text, span):
    _put(ws, row, col, text, bold=True, fill=BLUE, color="FFFFFF", size=12)
    if span > 1:
        ws.merge_cells(start_row=row, start_column=col, end_row=row, end_column=col + span - 1)


def _automation(ws, row, col, text, span=1):
    """Yellow automation cell (an AI / calculation button in the app)."""
    cell = _put(ws, row, col, text, bold=True, fill=YELLOW, align="center")
    if span > 1:
        ws.merge_cells(start_row=row, start_column=col, end_row=row, end_column=col + span - 1)
    return cell


def _pair(ws, row, col, label, value, *, automation=False, fmt=None):
    _put(ws, row, col, label, bold=True, fill=LABEL)
    cell = _put(ws, row, col + 1, value if value not in (None, "") else "", fill=YELLOW if automation else None,
                fmt=fmt)
    return cell


def _fit(ws, row: int, text, width_chars: float, min_height: float = 15.0) -> None:
    """Row height for wrapped text in merged cells (Excel cannot auto-fit those)."""
    if not text:
        return
    lines = sum(max(1, -(-len(part) // max(1, int(width_chars)))) for part in str(text).split("\n"))
    height = max(min_height, 13.5 * lines + 2)
    current = ws.row_dimensions[row].height or 0
    ws.row_dimensions[row].height = max(current, height)


def _widths(ws, widths: dict):
    for col, w in widths.items():
        ws.column_dimensions[col].width = w


def _pct_text(util):
    return f"{int(util * 100 + 0.5)}%" if util is not None else "No availability"


# ------------------------------------------------------------------ Lists (lookups sheet)
def _sheet1(wb, lookups: dict | None) -> dict:
    """Write lookup lists; returns {key: absolute range} for data validations."""
    ws = wb.create_sheet("Lists")
    ranges = {}
    for i, (title, key, default) in enumerate(SHEET1_LISTS, start=1):
        values = [x.get("value") for x in (lookups or {}).get(key) or [] if x.get("value")] or list(default)
        _put(ws, 1, i, title, bold=True, fill=NAVY, color="FFFFFF")
        for j, v in enumerate(values, start=2):
            _put(ws, j, i, v)
        letter = get_column_letter(i)
        ranges[key] = f"Lists!${letter}$2:${letter}${len(values) + 1}"
        ws.column_dimensions[letter].width = max(14, len(title) + 4)
    return ranges


def _validate(ws, ranges: dict, key: str, cells: list[str]):
    if key not in ranges or not cells:
        return
    dv = DataValidation(type="list", formula1=f"={ranges[key]}", allow_blank=True)
    dv.error = "Pick a value from the list."
    dv.errorTitle = "Not in the list"
    ws.add_data_validation(dv)
    for c in cells:
        dv.add(c)


# ------------------------------------------------------------------ Mission Statement
def _mission(wb, data: dict, subtitle: str):
    ws = wb.active
    ws.title = "Mission Statement"
    _widths(ws, {"A": 3, "B": 28, "C": 90})
    _put(ws, 2, 2, "BMO Digital Channels – Project Management Tool", bold=True, size=16, color=NAVY, border=False)
    _put(ws, 4, 2, "Mission Statement", bold=True, fill=LABEL)
    _put(ws, 4, 3, MISSION, wrap=True)
    ws.row_dimensions[4].height = 48
    _put(ws, 5, 2, "Exported for", bold=True, fill=LABEL)
    _put(ws, 5, 3, subtitle)
    _put(ws, 6, 2, "As of", bold=True, fill=LABEL)
    _put(ws, 6, 3, _date(data.get("today")))
    _put(ws, 8, 2, "Sheets in this workbook", bold=True, border=False)
    for i, (name, text) in enumerate(data.get("sheet_notes") or [], start=9):
        _put(ws, i, 2, name, bold=True)
        _put(ws, i, 3, text, wrap=True)
    _put(ws, 9 + len(data.get("sheet_notes") or []) + 1, 2,
         "Yellow cells are calculated or AI-assisted in the app (Enter once · Calculate · Visualize · Automate).",
         italic=True, border=False)


# ------------------------------------------------------------------ Demo View
def _demo_view(wb, data: dict, ranges: dict):
    ws = wb.create_sheet("Demo View")
    ini = data["initiative"]
    _widths(ws, {"A": 2, "B": 22, "C": 2, "D": 20, "E": 26, "F": 16, "G": 16, "H": 16, "I": 16, "J": 14, "K": 14,
                 "L": 14, "M": 24})
    ws.sheet_view.showGridLines = False

    for i, label in enumerate(("Add New Initiative", "Edit Initiative", "Search Initiative", "Portfolio View")):
        _put(ws, 3 + i * 2, 2, label, bold=True, fill=NAVY, color="FFFFFF", align="center")

    # ---- Pg 1
    r = 2
    _title(ws, r, 4, "Pg 1 – General Details", 10)
    top = r
    r += 1
    left = [
        ("RDDC #", ini.get("rddc")), ("Project Name", ini.get("name")), ("Current Status", ini.get("status")),
        ("Stage", ini.get("stage")), ("Assigned To", ini.get("assigned_to_name")), ("PM", ini.get("pm_name")),
        ("Tech/Dev Lead", ini.get("tech_lead_name")), ("DC PM", ini.get("dc_pm_name")),
        ("DC SA", ini.get("dc_sa_name")), ("LOB", ini.get("lob")),
        ("Priority", f"P{ini['priority']}" if ini.get("priority") else ""),
        ("Requested Go-live", _date(ini.get("requested_go_live"))), ("Target Release", ini.get("target_release")),
        ("PRN", ini.get("prn_code")),
    ]
    sa_doc = next((a.get("filename") for a in data.get("attachments") or [] if a.get("kind") == "sa_doc"), None)
    grooming = data.get("grooming") or {}
    right = [
        ("DC Intake", ini.get("dc_intake"), False), ("Labels", ", ".join(ini.get("labels") or []), True),
        ("Requestor", ini.get("requestor_name") or ini.get("requestor"), False),
        ("SA document", sa_doc or "Not attached", False), ("Author", ini.get("sa_author"), True),
        ("SA Version", ini.get("sa_version"), True),
        ("SA Completeness", f"{ini['sa_completeness']}%" if ini.get("sa_completeness") is not None else "", True),
        ("L2 Estimate", f"{cal.fmt_hours(ini['l2_hours'])} h" if ini.get("l2_hours") else "", True),
        ("T-shirt", ini.get("l2_tshirt"), True),
        ("L2 Range", f"{cal.fmt_hours(ini['l2_low_hours'])}–{cal.fmt_hours(ini['l2_high_hours'])} h"
         if ini.get("l2_low_hours") else "", True),
        ("L2 Status", ini.get("l2_status"), False),
        ("Grooming Session", grooming.get("label") or (cal.fmt_day(grooming["session_date"]) + ", " +
                                                       grooming.get("start_time", "10:00")
                                                       if grooming.get("session_date") else ""), True),
        ("Action required by", data.get("action_required_by") or "", True),
        ("Overall RAG", (data.get("health") or {}).get("overall") or "Not scored yet", True),
    ]
    for i, (label, value) in enumerate(left):
        _pair(ws, r + i, 4, label, value)
    for i, (label, value, auto) in enumerate(right):
        _pair(ws, r + i, 7, label, value, automation=auto)
    status_row = r + 2
    _validate(ws, ranges, "status", [f"E{status_row}"])
    _validate(ws, ranges, "stage", [f"E{r + 3}"])
    _validate(ws, ranges, "l2_status", [f"H{r + 10}"])
    r += max(len(left), len(right)) + 1
    _put(ws, r, 4, "Description of Change", bold=True, fill=LABEL)
    _put(ws, r, 5, ini.get("description") or "", wrap=True)
    ws.merge_cells(start_row=r, start_column=5, end_row=r, end_column=13)
    _fit(ws, r, ini.get("description"), 150)
    r += 2
    _automation(ws, r, 4, "Generate Change Summary", 2)
    _put(ws, r, 6, "(populated from SA doc attachment)", italic=True, border=False)
    r += 1
    _header_row(ws, r, 4, ["DC Component", "Approval", "Change Summary", "", "", "Complexity", "Est. hours",
                           "Component Lead"])
    ws.merge_cells(start_row=r, start_column=6, end_row=r, end_column=8)
    r += 1
    comp_start = r
    for c in data.get("components") or []:
        _put(ws, r, 4, c.get("name") or c.get("code"))
        _put(ws, r, 5, c.get("approval"))
        _put(ws, r, 6, c.get("change_summary") or "", wrap=True, fill=YELLOW)
        ws.merge_cells(start_row=r, start_column=6, end_row=r, end_column=8)
        _put(ws, r, 9, c.get("complexity"))
        _put(ws, r, 10, c.get("est_hours"), fmt="#,##0.0")
        _put(ws, r, 11, c.get("component_lead_name"))
        _fit(ws, r, c.get("change_summary"), 46)
        r += 1
    if r == comp_start:
        _put(ws, r, 4, "No DC components yet.", italic=True)
        r += 1
    else:
        _validate(ws, ranges, "approval", [f"E{x}" for x in range(comp_start, r)])
        _validate(ws, ranges, "complexity", [f"I{x}" for x in range(comp_start, r)])
    _box(ws, top, 4, r - 1, 13)

    # ---- Pg 2
    r += 2
    _title(ws, r, 4, "Pg 2 – Project Plan", 10)
    top = r
    r += 1
    gantt = data.get("gantt") or {}
    dev_hours = sum(float(t.get("est_hours") or 0) for t in data.get("tasks") or []
                    if t.get("phase") == "Development")
    kd = [("Readiness Date", _date(gantt.get("readiness_date"))), ("QA Date", _date(gantt.get("qa_date"))),
          ("Production Date", _date(gantt.get("prod_date"))), ("Developer hours", dev_hours),
          ("Float (business days)", gantt.get("float_bd"))]
    for i, (label, value) in enumerate(kd):
        _pair(ws, r + i // 3, 4 + (i % 3) * 3, label, value, automation=True)
    r += 3
    _automation(ws, r, 4, "Generate Project Plan", 2)
    _put(ws, r, 6, "(WBS auto-populated from Change Summary)", italic=True, border=False)
    r += 1
    _header_row(ws, r, 4, ["WBS Steps", "Description", "SME/Owner", "Resource", "Start Date", "End Date", "Status",
                           "% Completion", "Hours", "Comments"])
    r += 1
    task_start = r
    tasks = data.get("tasks") or []
    for t in tasks:
        indent = "   " if t.get("parent_id") else ""
        _put(ws, r, 4, indent + (t.get("wbs_code") or ""), bold=not t.get("parent_id"))
        _put(ws, r, 5, t.get("step"), wrap=True)
        _put(ws, r, 6, t.get("owner_name"))
        _put(ws, r, 7, t.get("resource_name"))
        _put(ws, r, 8, _date(t.get("planned_start")))
        _put(ws, r, 9, _date(t.get("planned_end")))
        _put(ws, r, 10, t.get("status"))
        _put(ws, r, 11, (t.get("pct") or 0) / 100, fmt="0%")
        _put(ws, r, 12, _rolled_hours(t, tasks), fmt="#,##0.0")
        _put(ws, r, 13, t.get("comments") or "", wrap=True)
        r += 1
    if r == task_start:
        _put(ws, r, 4, "No project plan yet.", italic=True)
        r += 1
    else:
        _validate(ws, ranges, "task_status", [f"J{x}" for x in range(task_start, r)])
    _automation(ws, r, 4, "Generate Gantt view", 2)
    _put(ws, r, 6, "(see the Gantt sheet; critical path in red)", italic=True, border=False)
    _box(ws, top, 4, r, 13)

    # ---- Pg 3
    r += 3
    _title(ws, r, 4, "Pg 3 – Resource Management", 10)
    top = r
    r += 1
    grid = data.get("resource_grid") or {}
    quarters = grid.get("quarters") or []
    _put(ws, r, 4, f"Resource Name ({grid.get('fy', '')})", bold=True, fill=NAVY, color="FFFFFF")
    for i, q in enumerate(quarters):
        _put(ws, r, 5 + i * 2, f"{q.get('short') or q['label']} ({q['label']})", bold=True, fill=NAVY,
             color="FFFFFF", align="center")
        ws.merge_cells(start_row=r, start_column=5 + i * 2, end_row=r, end_column=6 + i * 2)
    r += 1
    _put(ws, r, 4, "", fill=LABEL)
    for i, _q in enumerate(quarters):
        _put(ws, r, 5 + i * 2, "Availability", bold=True, fill=LABEL)
        _put(ws, r, 6 + i * 2, "Allocation", bold=True, fill=LABEL)
    r += 1
    for row in grid.get("rows") or []:
        _put(ws, r, 4, row["name"])
        for i, c in enumerate(row["cells"]):
            _put(ws, r, 5 + i * 2, c["availability"], fmt="#,##0.0")
            _put(ws, r, 6 + i * 2, c["allocation"], fmt="#,##0.0",
                 fill=BAND_FILL.get(c.get("peak_band") or c["band"]) if c["allocation"] else None)
        r += 1
    _automation(ws, r, 4, "Suggest Resources", 1)
    r += 2
    h = data.get("health") or {}
    _put(ws, r, 4, "Project Health", bold=True, fill=LABEL)
    _put(ws, r, 5, h.get("overall") or "Not scored yet", bold=True,
         fill=RAG_FILL.get(h.get("overall")), color="FFFFFF" if h.get("overall") else None)
    r += 1
    for dim in ("schedule", "resources", "scope", "dependencies", "budget"):
        d = (h.get("dimensions") or {}).get(dim) or {}
        _put(ws, r, 4, dim.capitalize(), bold=True, fill=LABEL)
        _put(ws, r, 5, d.get("rag") or "Not scored", fill=RAG_FILL.get(d.get("rag")),
             color="FFFFFF" if d.get("rag") else None, bold=True)
        _put(ws, r, 6, "; ".join(d.get("reasons") or []), wrap=True)
        ws.merge_cells(start_row=r, start_column=6, end_row=r, end_column=13)
        _fit(ws, r, "; ".join(d.get("reasons") or []), 140)
        r += 1
    _put(ws, r, 4, "Management attention", bold=True, fill=LABEL)
    _put(ws, r, 5, "; ".join(h.get("attention") or []) or "Nothing needs attention", fill=YELLOW, wrap=True)
    ws.merge_cells(start_row=r, start_column=5, end_row=r, end_column=13)
    _validate(ws, ranges, "rag", [f"E{r - 6}"])
    _box(ws, top, 4, r, 13)

    # ---- Pg 4
    r += 3
    _title(ws, r, 4, "Pg 4 – Change Governance", 10)
    top = r
    r += 1
    crs = data.get("change_requests") or []
    cr = crs[0] if crs else {}
    flags = (cr.get("compliance") or {}).get("flags") or []
    left = [
        ("CRQ/RCSR #", cr.get("crq_number"), False),
        ("CRQ Start Date and Time", _fmt_dt(cr.get("crq_start")), False),
        ("CRQ End Date and Time", _fmt_dt(cr.get("crq_end")), False),
        ("Release Type", cr.get("release_type"), False), ("Release Train/Sprint", cr.get("release_train"), False),
        ("Affected CIs", ", ".join(cr.get("affected_cis") or []), True),
        ("Target Release", cr.get("target_release") or ini.get("target_release"), False),
        ("Impacted Component", ", ".join(cr.get("impacted_components") or []), True),
        ("Implementation Status", cr.get("implementation_status"), False),
        ("CRQ Approval Status", cr.get("crq_approval_status"), False),
        ("STO Approval", cr.get("sto_approval"), True),
    ]
    right = [
        ("CMS Lead", cr.get("cms_lead_name"), False), ("Rel Lead", cr.get("rel_lead_name"), False),
        ("Resource", cr.get("resource_name"), False),
        ("Technical Validation Status", cr.get("tech_validation_status") or "Not Started", False),
        ("Business Validation Status", cr.get("biz_validation_status") or "Not Started", False),
        ("Backout plan", "Attached" if cr.get("backout_attachment_id") else "Not attached", False),
        ("Compliance", "; ".join(f["message"] for f in flags) if cr else "", True),
    ]
    for i, (label, value, auto) in enumerate(left):
        _pair(ws, r + i, 4, label, value, automation=auto)
    for i, (label, value, auto) in enumerate(right):
        _pair(ws, r + i, 7, label, value, automation=auto)
    _validate(ws, ranges, "release_type", [f"E{r + 3}"])
    _validate(ws, ranges, "implementation_status", [f"E{r + 8}"])
    _validate(ws, ranges, "crq_approval_status", [f"E{r + 9}"])
    _validate(ws, ranges, "sto_approval", [f"E{r + 10}"])
    _validate(ws, ranges, "validation_status", [f"H{r + 3}", f"H{r + 4}"])
    r += len(left)
    _automation(ws, r, 4, "Create CRQ draft", 1)
    _automation(ws, r, 5, "Check CR Compliance", 1)
    if len(crs) > 1:
        _put(ws, r, 7, f"{len(crs) - 1} more change request(s) on the Portfolio View sheet.", italic=True,
             border=False)
    _box(ws, top, 4, r, 13)
    ws.freeze_panes = "D2"


def _rolled_hours(task: dict, tasks: list[dict]) -> float:
    """A summary row (children, no hours of its own) shows the sum of its children: WBS-200 reads 560 h."""
    own = float(task.get("est_hours") or 0)
    kids = [t for t in tasks if t.get("parent_id") == task.get("id")]
    if own or not kids:
        return own
    return sum(_rolled_hours(k, tasks) for k in kids)


def _fmt_dt(value) -> str:
    if not value:
        return ""
    text = str(value)
    d = cal.to_date(text)
    hhmm = text[11:16] if len(text) >= 16 else ""
    return f"{cal.fmt_day_long(d)} {hhmm}".strip()


# ------------------------------------------------------------------ Portfolio View
def _portfolio_sheet(wb, portfolio: dict, ranges: dict, title="Portfolio View"):
    ws = wb.create_sheet(title)
    ws.sheet_view.showGridLines = False
    _widths(ws, {"A": 2, "B": 14, "C": 36, "D": 18, "E": 18, "F": 12, "G": 10, "H": 14, "I": 14, "J": 14, "K": 14,
                 "L": 40, "M": 30})
    _title(ws, 1, 2, "Pg 5 – Portfolio View", 12)
    k = portfolio.get("kpis") or {}
    kpis = [("Active", k.get("active")), ("Red", k.get("red")), ("Amber", k.get("amber")), ("Green", k.get("green")),
            ("CRQs this week", k.get("crqs_this_week")), ("Over-allocated people", k.get("overallocated_people"))]
    for i, (label, value) in enumerate(kpis):
        _put(ws, 3, 2 + i, label, bold=True, fill=LABEL, wrap=True, align="center")
        _put(ws, 4, 2 + i, value if value is not None else 0, fill=YELLOW, bold=True, size=14, align="center")
    r = 6
    _put(ws, r, 2, "Project Dashboard", bold=True, size=12, border=False, color=NAVY)
    r += 1
    _header_row(ws, r, 2, ["Intake/RDDC #", "Project Name", "LOB", "DC PM", "Stage", "RAG", "Target Release",
                           "Readiness Date", "QA Sign-off", "Prod/Final", "Management attention", "Comments"])
    r += 1
    first = r
    for p in portfolio.get("projects") or []:
        _put(ws, r, 2, p["rddc"])
        _put(ws, r, 3, p["name"], wrap=True)
        _put(ws, r, 4, p.get("lob"))
        _put(ws, r, 5, p.get("dc_pm_name"))
        _put(ws, r, 6, p.get("stage"))
        _put(ws, r, 7, p.get("rag") or "Not scored", fill=RAG_FILL.get(p.get("rag")),
             color="FFFFFF" if p.get("rag") else None, bold=True)
        _put(ws, r, 8, p.get("target_release"))
        _put(ws, r, 9, _date(p.get("readiness_date")))
        _put(ws, r, 10, _date(p.get("qa_signoff_date")))
        _put(ws, r, 11, _date(p.get("prod_date")))
        _put(ws, r, 12, "; ".join(p.get("attention") or []), wrap=True)
        _put(ws, r, 13, p.get("comments") or "", wrap=True)
        r += 1
    if r > first:
        _validate(ws, ranges, "stage", [f"F{x}" for x in range(first, r)])
        _validate(ws, ranges, "rag", [f"G{x}" for x in range(first, r)])
        ws.auto_filter.ref = f"B{first - 1}:M{r - 1}"
    r += 2
    _put(ws, r, 2, "Change Management", bold=True, size=12, border=False, color=NAVY)
    r += 1
    _header_row(ws, r, 2, ["Intake/Release", "CRQ/RCSR #", "CMS Lead", "Rel Lead", "Resource",
                           "Implementation Status", "Technical Validation Status", "Business Validation Status",
                           "STO Approval", "Release Train", "Compliance flags"])
    r += 1
    first = r
    for c in portfolio.get("change_mgmt") or []:
        _put(ws, r, 2, c["rddc"])
        _put(ws, r, 3, c.get("crq_number"))
        _put(ws, r, 4, c.get("cms_lead_name"))
        _put(ws, r, 5, c.get("rel_lead_name"))
        _put(ws, r, 6, c.get("resource_name"))
        _put(ws, r, 7, c.get("implementation_status"))
        _put(ws, r, 8, c.get("tech_validation_status"))
        _put(ws, r, 9, c.get("biz_validation_status"))
        _put(ws, r, 10, c.get("sto_approval"), fill=YELLOW)
        _put(ws, r, 11, c.get("release_train"))
        _put(ws, r, 12, "; ".join(c.get("compliance_flags") or []) or "Compliant", wrap=True,
             fill="F4B6B6" if c.get("compliance_flags") else "C6E0B4")
        r += 1
    if r > first:
        _validate(ws, ranges, "implementation_status", [f"G{x}" for x in range(first, r)])
        _validate(ws, ranges, "validation_status", [f"{col}{x}" for x in range(first, r) for col in ("H", "I")])
        _validate(ws, ranges, "sto_approval", [f"J{x}" for x in range(first, r)])
    else:
        _put(ws, r, 2, "No change requests logged.", italic=True)
    ws.freeze_panes = "C8"


# ------------------------------------------------------------------ Gantt
def _gantt_sheet(wb, gantt: dict, rddc: str):
    ws = wb.create_sheet("Gantt")
    ws.sheet_view.showGridLines = False
    tasks = [t for t in gantt.get("tasks") or [] if t.get("planned_start") and t.get("planned_end")]
    _widths(ws, {"A": 11, "B": 40, "C": 18, "D": 12, "E": 12, "F": 7})
    _title(ws, 1, 1, f"{rddc} – Project Gantt (weeks starting Monday)", 6)
    if not tasks:
        _put(ws, 3, 1, "The Gantt view appears once the plan has steps with start and end dates.", italic=True)
        return
    start = cal.week_monday(min(cal.to_date(t["planned_start"]) for t in tasks))
    end = max(cal.to_date(t["planned_end"]) for t in tasks)
    weeks = []
    w = start
    while w <= end:
        weeks.append(w)
        w += timedelta(days=7)
    _header_row(ws, 3, 1, ["WBS", "Step", "Resource", "Start", "End", "Float"])
    today = cal.to_date(gantt.get("today"))
    train_days = {cal.to_date(t["train_date"]) for t in gantt.get("trains") or []}
    for i, wk in enumerate(weeks):
        col = 7 + i
        ws.column_dimensions[get_column_letter(col)].width = 4.2
        in_frz = any(cal.in_freeze(wk + timedelta(days=d)) for d in range(5))
        month_cell = _put(ws, 2, col, cal.MONTH_ABBR[wk.month - 1] if wk.day <= 7 or i == 0 else "", bold=True,
                          border=False)
        month_cell.alignment = Alignment(horizontal="left")
        fill = FREEZE_FILL if in_frz else NAVY
        hdr = _put(ws, 3, col, wk, bold=True, fill=fill, color="FFFFFF" if not in_frz else "000000", fmt="dd")
        hdr.alignment = Alignment(horizontal="center", text_rotation=90)
        if today and wk <= today < wk + timedelta(days=7):
            hdr.fill = PatternFill("solid", fgColor=CRITICAL_FILL)
            hdr.font = Font(bold=True, color="FFFFFF", size=10)
    r = 4
    for t in gantt.get("tasks") or []:
        _put(ws, r, 1, t.get("wbs_code"), bold=t.get("is_summary") or not t.get("parent_id"))
        _put(ws, r, 2, ("   " if t.get("parent_id") else "") + (t.get("step") or ""))
        _put(ws, r, 3, t.get("resource_name") or "")
        _put(ws, r, 4, _date(t.get("planned_start")))
        _put(ws, r, 5, _date(t.get("planned_end")))
        _put(ws, r, 6, t.get("float_bd") if t.get("float_bd") is not None else "")
        if t.get("planned_start") and t.get("planned_end"):
            s, e = cal.to_date(t["planned_start"]), cal.to_date(t["planned_end"])
            for i, wk in enumerate(weeks):
                wk_end = wk + timedelta(days=6)
                cell = ws.cell(row=r, column=7 + i)
                cell.border = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
                if s <= wk_end and e >= wk:
                    if t.get("is_milestone"):
                        cell.value = "◆"
                        cell.alignment = Alignment(horizontal="center")
                        cell.font = Font(bold=True, color=CRITICAL_FILL if t.get("critical") else NAVY)
                    else:
                        color = CRITICAL_FILL if t.get("critical") else PHASE_FILL.get(t.get("phase"), BLUE)
                        if t.get("is_summary"):
                            color = "595959"
                        cell.fill = PatternFill("solid", fgColor=color)
                elif any(cal.in_freeze(wk + timedelta(days=d)) for d in range(5)):
                    cell.fill = PatternFill("solid", fgColor=FREEZE_FILL)
                if any(wk <= td <= wk_end for td in train_days) and not cell.value:
                    cell.border = Border(left=THIN, right=Side(style="thick", color="7030A0"), top=THIN, bottom=THIN)
        r += 1
    r += 1
    _put(ws, r, 1, "Legend", bold=True, border=False)
    legend = [("Critical path", CRITICAL_FILL)] + [(p, c) for p, c in PHASE_FILL.items()] + \
             [("Change freeze", FREEZE_FILL)]
    for i, (label, color) in enumerate(legend):
        _put(ws, r + 1 + i, 1, "", fill=color)
        _put(ws, r + 1 + i, 2, label, border=False)
    _put(ws, r + 2 + len(legend), 2,
         f"Readiness {cal.fmt_date(gantt.get('readiness_date'))} · QA {cal.fmt_date(gantt.get('qa_date'))} · "
         f"Production {cal.fmt_date(gantt.get('prod_date'))} · Float {gantt.get('float_bd')} business days",
         italic=True, border=False)
    ws.freeze_panes = "G4"


# ------------------------------------------------------------------ Capacity
def _band_rules(ws, rng: str):
    ws.conditional_formatting.add(rng, CellIsRule(operator="greaterThan", formula=["1.1"],
                                                  fill=PatternFill("solid", fgColor=BAND_FILL["over"])))
    ws.conditional_formatting.add(rng, CellIsRule(operator="between", formula=["1.0000001", "1.1"],
                                                  fill=PatternFill("solid", fgColor=BAND_FILL["stretched"])))
    ws.conditional_formatting.add(rng, CellIsRule(operator="between", formula=["0.7", "1"],
                                                  fill=PatternFill("solid", fgColor=BAND_FILL["ok"])))
    first = rng.split(":")[0]
    ws.conditional_formatting.add(rng, FormulaRule(formula=[f'AND(ISNUMBER({first}),{first}<0.7)'],
                                                   fill=PatternFill("solid", fgColor=BAND_FILL["spare"])))


def _capacity_sheet(wb, cap_quarter: dict, cap_month: dict, heading: str):
    ws = wb.create_sheet("Capacity")
    ws.sheet_view.showGridLines = False
    _widths(ws, {"A": 22, "B": 14})
    _title(ws, 1, 1, heading, 8)
    qcols = cap_quarter.get("months") or []
    r = 3
    _put(ws, r, 1, "Resource", bold=True, fill=NAVY, color="FFFFFF")
    _put(ws, r, 2, "Team", bold=True, fill=NAVY, color="FFFFFF")
    labels = {}
    for row in cap_quarter.get("rows") or []:
        for c in row["cells"]:
            labels[c["month"]] = f"{c.get('short') or c.get('quarter', '')} ({c.get('label', '')})"
    for i, key in enumerate(qcols):
        col = 3 + i * 3
        _put(ws, r, col, labels.get(key, key), bold=True, fill=NAVY, color="FFFFFF", align="center")
        ws.merge_cells(start_row=r, start_column=col, end_row=r, end_column=col + 2)
        for j, sub in enumerate(("Availability", "Allocation", "Util")):
            _put(ws, r + 1, col + j, sub, bold=True, fill=LABEL)
            ws.column_dimensions[get_column_letter(col + j)].width = 12
    r += 2
    first = r
    for row in cap_quarter.get("rows") or []:
        _put(ws, r, 1, row["label"])
        _put(ws, r, 2, row["team"])
        for i, c in enumerate(row["cells"]):
            col = 3 + i * 3
            _put(ws, r, col, c["available"], fmt="#,##0.0")
            _put(ws, r, col + 1, c["confirmed"] + c["tentative"], fmt="#,##0.0")
            _put(ws, r, col + 2, round(c["util"], 4) if c["util"] is not None else "No availability", fmt="0%")
        r += 1
    for i in range(len(qcols)):
        letter = get_column_letter(3 + i * 3 + 2)
        if r > first:
            _band_rules(ws, f"{letter}{first}:{letter}{r - 1}")

    r += 2
    months = cap_month.get("months") or []
    _put(ws, r, 1, "Monthly utilisation", bold=True, size=12, border=False, color=NAVY)
    r += 1
    _put(ws, r, 1, "Resource", bold=True, fill=NAVY, color="FFFFFF")
    _put(ws, r, 2, "Team", bold=True, fill=NAVY, color="FFFFFF")
    for i, m in enumerate(months):
        _put(ws, r, 3 + i, cal.month_label(m), bold=True, fill=NAVY, color="FFFFFF", align="center")
    r += 1
    first = r
    for row in cap_month.get("rows") or []:
        _put(ws, r, 1, row["label"])
        _put(ws, r, 2, row["team"])
        for i, c in enumerate(row["cells"]):
            _put(ws, r, 3 + i, round(c["util"], 4) if c["util"] is not None else "No availability", fmt="0%")
        r += 1
    if months and r > first:
        _band_rules(ws, f"C{first}:{get_column_letter(2 + len(months))}{r - 1}")
    r += 1
    _put(ws, r, 1, "Bands: under 70% spare (grey) · 70–100% on plan (green) · 101–110% stretched (amber) · over 110% "
                   "over-allocated (red). Demand counts confirmed and tentative hours.", italic=True, border=False)
    teams = cap_quarter.get("teams") or []
    if teams:
        r += 2
        _put(ws, r, 1, "Team capacity (whole window)", bold=True, size=12, border=False, color=NAVY)
        r += 1
        _header_row(ws, r, 1, ["Team", "Available", "Confirmed", "Tentative", "Util"])
        r += 1
        first = r
        for t in teams:
            _put(ws, r, 1, t["team"])
            _put(ws, r, 2, t["available"], fmt="#,##0.0")
            _put(ws, r, 3, t["confirmed"], fmt="#,##0.0")
            _put(ws, r, 4, t["tentative"], fmt="#,##0.0")
            _put(ws, r, 5, round(t["util"], 4) if t["util"] is not None else "No availability", fmt="0%")
            r += 1
        _band_rules(ws, f"E{first}:E{r - 1}")
    ws.freeze_panes = "C5"


# ------------------------------------------------------------------ Risk Register
def _risk_sheet(wb, risks: list[dict]):
    ws = wb.create_sheet("Risk Register")
    ws.sheet_view.showGridLines = False
    _widths(ws, {"A": 10, "B": 13, "C": 40, "D": 13, "E": 11, "F": 11, "G": 8, "H": 20, "I": 50, "J": 11,
                 "K": 12, "L": 9})
    _title(ws, 1, 1, "Risk Register", 12)
    _header_row(ws, 3, 1, ["Risk ID", "RDDC #", "Title", "Category", "Severity", "Likelihood", "Score", "Owner",
                           "Mitigation", "Linked WBS", "Status", "Source"])
    sev = {1: "Low", 2: "Medium", 3: "High", 4: "Critical"}
    lik = {1: "Rare", 2: "Unlikely", 3: "Possible", 4: "Likely"}
    r = 4
    for k in risks:
        score = k.get("score") or (int(k.get("severity") or 0) * int(k.get("likelihood") or 0))
        _put(ws, r, 1, k.get("risk_code"))
        _put(ws, r, 2, k.get("rddc"))
        _put(ws, r, 3, k.get("title"), wrap=True)
        _put(ws, r, 4, k.get("category"))
        _put(ws, r, 5, sev.get(k.get("severity"), k.get("severity")))
        _put(ws, r, 6, lik.get(k.get("likelihood"), k.get("likelihood")))
        _put(ws, r, 7, score, fill="F4B6B6" if score >= 9 else ("FFE699" if score >= 4 else "C6E0B4"))
        _put(ws, r, 8, k.get("owner_name"))
        _put(ws, r, 9, k.get("mitigation") or "", wrap=True)
        _put(ws, r, 10, k.get("wbs_code") or "")
        _put(ws, r, 11, k.get("status"))
        _put(ws, r, 12, "AI" if k.get("source") == "ai" else "User")
        r += 1
    if r == 4:
        _put(ws, r, 1, "No risks recorded.", italic=True)
    ws.freeze_panes = "A4"


# ------------------------------------------------------------------ builders
def _print_setup(wb) -> None:
    """Landscape, one page wide, so Print / PDF shows each sheet like the workbook."""
    for ws in wb.worksheets:
        ws.page_setup.orientation = "landscape"
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        ws.sheet_properties.pageSetUpPr.fitToPage = True


def _save(wb) -> bytes:
    _print_setup(wb)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def build_demo_view(data: dict) -> bytes:
    """data: {today, initiative, components, tasks, attachments, grooming, action_required_by, health, gantt,
    resource_grid, change_requests, risks, capacity_quarter, capacity_month, portfolio, lookups}"""
    ini = data["initiative"]
    wb = Workbook()
    notes = [("Demo View", "Pg 1–4 for this initiative, laid out like the Demo View tab."),
             ("Portfolio View", "Pg 5 project dashboard and change management."),
             ("Gantt", "Weekly bars by phase; critical path in red; change freeze shaded."),
             ("Capacity", "Availability vs allocation by BMO fiscal quarter, with utilisation bands."),
             ("Risk Register", "Risks for this initiative."),
             ("Lists", "Lookup lists used by the dropdowns.")]
    _mission(wb, {**data, "sheet_notes": notes}, f"{ini['rddc']} {ini['name']}")
    ranges = _sheet1(wb, data.get("lookups"))
    _demo_view(wb, data, ranges)
    _portfolio_sheet(wb, data.get("portfolio") or {}, ranges)
    _gantt_sheet(wb, data.get("gantt") or {}, ini["rddc"])
    _capacity_sheet(wb, data.get("capacity_quarter") or {}, data.get("capacity_month") or {},
                    f"Capacity – people on {ini['rddc']} (all their bookings)")
    _risk_sheet(wb, data.get("risks") or [])
    wb.move_sheet("Lists", offset=len(wb.sheetnames))
    return _save(wb)


def build_portfolio_workbook(data: dict) -> bytes:
    """data: {today, portfolio, capacity_quarter, capacity_month, risks, lookups}"""
    wb = Workbook()
    notes = [("Portfolio View", "Project dashboard, KPIs and change management."),
             ("Capacity", "Every tracked person by fiscal quarter and month."),
             ("Risk Register", "Open and closed risks across the portfolio."),
             ("Lists", "Lookup lists used by the dropdowns.")]
    _mission(wb, {**data, "sheet_notes": notes}, "Digital Channels portfolio")
    ranges = _sheet1(wb, data.get("lookups"))
    _portfolio_sheet(wb, data.get("portfolio") or {}, ranges)
    _capacity_sheet(wb, data.get("capacity_quarter") or {}, data.get("capacity_month") or {},
                    "Capacity – all tracked people")
    _risk_sheet(wb, data.get("risks") or [])
    wb.move_sheet("Lists", offset=len(wb.sheetnames))
    return _save(wb)


def build_portfolio_csv(projects: list[dict]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["Intake/RDDC #", "Project Name", "LOB", "DC PM", "Stage", "RAG", "Schedule", "Resources", "Scope",
                "Dependencies", "Budget", "Target Release", "Readiness Date", "QA Sign-off", "Prod/Final",
                "Management attention", "Comments"])
    for p in projects:
        dims = p.get("dimensions") or {}
        w.writerow([safe(x if x is not None else "") for x in (
            p["rddc"], p["name"], p.get("lob"), p.get("dc_pm_name"), p.get("stage"), p.get("rag") or "Not scored",
            dims.get("schedule"), dims.get("resources"), dims.get("scope"), dims.get("dependencies"),
            dims.get("budget"), p.get("target_release"), p.get("readiness_date"), p.get("qa_signoff_date"),
            p.get("prod_date"), "; ".join(p.get("attention") or []), p.get("comments"))])
    return buf.getvalue()
