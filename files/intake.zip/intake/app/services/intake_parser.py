"""Deterministic intake extraction. No network calls or AI are used by this module.

Every proposed field carries source evidence; source text and unmapped columns stay
in the preview so a reviewer can resolve uncertain information before committing.
"""
from __future__ import annotations

import csv
import io
import re
from datetime import date, datetime
from pathlib import Path
from typing import Any

from app import errors, textract

MAX_ROWS = 5000
MAX_COLUMNS = 1500
MAX_CELLS = 1_000_000

ALIASES = {
    'name': r'(?:name|initiative(?: name| title)?|project(?: name| title)?|summary|title|business initiative)',
    'lob': r'(?:lob|line of business|business (?:line|unit)|portfolio)',
    'priority': r'(?:priority|business priority|ranking)',
    'requestor': r'(?:requestor|requester|requested by|reporter|business owner|sponsor)',
    'description': r'(?:description|business (?:context|description|justification)|scope|overview)',
    'requested_go_live': r'(?:requested (?:go live|date)|go live(?: date)?|target(?: delivery| implementation| completion| release)? date|due date|delivery date|implementation date)',
    'prn_code': r'(?:prn(?: code| number| no)?|project reference(?: number)?|funding (?:code|prn))',
    'target_release': r'(?:target release|release train)',
    'labels': r'(?:labels?|tags?)',
    'comments': r'(?:comments?|notes?)',
    'external_key': r'(?:issue key|jira(?: issue)?(?: key| id| ticket)?|ticket(?: number| id| key)?|rddc|external (?:key|id))',
    'dc_intake': r'(?:dc intake(?: code| number)?|dci(?: code| number)?)',
    'pm': r'(?:pm|project manager)',
    'dc_pm': r'(?:dc pm|dc project manager)',
    'dc_sa': r'(?:dc sa|dc solution architect|solution architect)',
    'tech_lead': r'(?:tech(?:nical)? lead)',
    'assigned_to': r'(?:assignee|assigned to)',
    'sa_author': r'(?:sa author|author|prepared by)',
    'sa_version': r'(?:sa version|document version|version)',
    'funded_hours': r'(?:funded hours|approved hours|budget(?:ed)? hours|hours budget|funding hours|approved effort)',
    'rate': r'(?:rate|hourly rate|blended rate|cost per hour)',
    'budget_amount': r'(?:budget(?: amount)?|approved (?:budget|funding|amount)|funding(?: amount)?|total (?:budget|funding)|allocated budget)',
    'currency': r'(?:currency|ccy)',
    'funding_name': r'(?:funding name|budget name)',
    'funding_scope': r'(?:funding scope|budget scope)',
    'funding_assumptions': r'(?:funding assumptions|budget assumptions)',
    'owner': r'(?:owner|funding owner|budget owner)',
    'start_month': r'(?:start month|funding start|budget start)',
    'end_month': r'(?:end month|funding end|budget end)',
    'month': r'(?:month|charge month|reporting month|period|fiscal period)',
    'charged_hours': r'(?:charged hours|actual hours|hours charged|hours consumed|consumed hours|spent hours)',
    'charged_amount': r'(?:charged amount|actual(?:s| amount| cost| spend)?|amount charged|spend|spent|consumed amount|cost)',
    'jira_status': r'(?:status|issue status|workflow status|jira status)',
    'jira_key': r'(?:bidc|bidc key)',
    'project_key': r'(?:project key)',
    'platform': r'(?:platform)',
    'region': r'(?:region|country)',
    'channel': r'(?:channel)',
    'apt_number': r'(?:apt(?: number| no| id)?)',
    'external_pr_code': r'(?:dc external team pr code|external pr code|pr code|project pr code)',
    'business_analyst': r'(?:ba|business analyst)',
    'solution_concurrence_date': r'(?:solution concurrence(?: date)?)',
    'decision': r'(?:decision|approval(?: status)?|funding status|funding decision)',
    'charge_type': r'(?:charge type|funding type|pod vs project)',
    'scope': r'(?:scope|funding scope)',
    'assumptions': r'(?:assumptions)',
    'appcat': r'(?:appcat(?: id| number| code)?|application catalogue|app cat)',
    'team': r'(?:team|delivery team)',
    'sto': r'(?:sto)',
    'phase': r'(?:phase|work type)',
    'hours': r'(?:hours|estimate hours|estimated hours|effort|effort hours)',
    'amount': r'(?:amount|estimate amount|estimated amount)',
    'notes': r'(?:estimate notes)',
}
INTAKE_FIELDS = {'name','lob','priority','requestor','description','requested_go_live','prn_code','target_release',
                 'labels','comments','external_key','dc_intake','pm','dc_pm','dc_sa','tech_lead','assigned_to','sa_author','sa_version','jira_status','jira_key','project_key','platform','region','channel','apt_number','external_pr_code','business_analyst','solution_concurrence_date',
                 'funded_hours','rate','budget_amount','currency','owner','owner_id','decision','charge_type','start_month','end_month','funding_name','funding_scope','funding_assumptions'}
FUNDING_FIELDS = {'prn_code','name','lob','funded_hours','rate','budget_amount','currency','owner','owner_id',
                  'start_month','end_month','month','charged_hours','charged_amount','decision','charge_type','scope','assumptions','platform','region','channel','apt_number','external_pr_code','appcat','team','sto','phase','hours','amount','notes'}


def normal_header(value: Any) -> str:
    value = re.sub(r'\s*#\d+$', '', str(value or '').strip())
    value = re.sub(r'^custom\s*field\s*\((.*?)\)$', r'\1', value, flags=re.IGNORECASE)
    return re.sub(r'[^a-z0-9]+', ' ', value.lower()).strip()


def field_for_header(value: Any, kind: str = 'intake') -> str | None:
    norm = normal_header(value)
    if kind=='funding' and norm in ('pr code','project pr code','pod pr code','charge code','funding code','pr number'):
        return 'prn_code'
    allowed = FUNDING_FIELDS if kind == 'funding' else INTAKE_FIELDS
    if str(value) in allowed:
        return str(value)
    for field, pattern in ALIASES.items():
        if field in allowed and re.fullmatch(pattern, norm):
            return field
    return None


def scalar(value: Any) -> Any:
    if isinstance(value, (datetime, date)):
        return value.isoformat()[:10]
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


def date_value(value: Any, month: bool = False) -> Any:
    if value in (None, ''):
        return value
    if isinstance(value, (date, datetime)):
        return value.isoformat()[:7 if month else 10]
    text = str(value).strip()
    patterns = ['%Y-%m-%d','%d-%b-%Y','%d %b %Y','%d %B %Y','%Y/%m/%d','%d/%m/%Y',
                '%d/%m/%y','%d/%b/%y','%d/%b/%Y','%Y-%m-%dT%H:%M:%S.%f%z','%Y-%m-%dT%H:%M:%S%z']
    if month:
        patterns = ['%Y-%m','%b %Y','%B %Y','%b-%y','%b-%Y','%m/%Y'] + patterns
    for pattern in patterns:
        try:
            return datetime.strptime(text, pattern).date().isoformat()[:7 if month else 10]
        except ValueError:
            pass
    if re.match(r'^\d{4}-\d{2}-\d{2}[ T]', text):
        return text[:7 if month else 10]
    return text


def number_value(value: Any) -> Any:
    if value in (None, '') or isinstance(value, (int, float)):
        return value
    text = re.sub(r'(?i)\b(?:CAD|USD|EUR|GBP|hours|hrs)\b', '', str(value)).strip()
    negative = text.startswith('(') and text.endswith(')')
    text = re.sub(r'[$£€,\s()]', '', text)
    try:
        return float(text) * (-1 if negative else 1)
    except ValueError:
        return value


def clean_fields(fields: dict, kind: str) -> dict:
    out = {str(k): v if k == 'labels' and isinstance(v,list) else scalar(v) for k, v in fields.items() if v is not None and v != ''}
    for field in ('requested_go_live','solution_concurrence_date'):
        if field in out:
            out[field] = date_value(out[field])
    for field in ('month','start_month','end_month'):
        if field in out:
            out[field] = date_value(out[field], month=True)
    for field in ('rate','budget_amount','funded_hours','charged_hours','charged_amount','hours','amount'):
        if field in out:
            out[field] = number_value(out[field])
    if 'priority' in out:
        p = str(out['priority']).strip().lower()
        match = re.fullmatch(r'(?:p|priority\s*)?([1-4])(?:\s*[-:.].*)?', p)
        priority = {'highest':1,'critical':1,'urgent':1,'high':2,'medium':3,'normal':3,'low':4,'lowest':4}
        out['priority'] = int(match[1]) if match else priority.get(p, out['priority'])
    for field in ('prn_code','external_key','dc_intake'):
        if field in out:
            text = str(out[field]).strip().upper()
            if field == 'prn_code':
                match = re.fullmatch(r'(?:PRN\s*[-:#]?\s*)?(\d+(?:\.0)?)', text)
                if match:
                    text = 'PRN-' + match[1].removesuffix('.0')
            out[field] = text
    if 'labels' in out and isinstance(out['labels'], str):
        out['labels'] = [s.strip() for s in re.split(r'[,;|]', out['labels']) if s.strip()]
    return out


def mapped_record(raw: dict, kind: str, mapping: dict | None = None) -> tuple[dict, dict, list]:
    """Mapping is source-column -> target-field (an empty target ignores a column)."""
    mapping = mapping or {}
    fields, evidence, warnings = {}, {}, []
    for column, value in raw.items():
        field = mapping.get(column) if column in mapping else field_for_header(column, kind)
        if not field or value in (None, ''):
            continue
        allowed = FUNDING_FIELDS if kind == 'funding' else INTAKE_FIELDS
        if field not in allowed:
            continue
        if field in fields and fields[field] != value:
            if field == 'labels':
                previous = fields[field] if isinstance(fields[field],list) else re.split(r'[,;|]',str(fields[field]))
                incoming = value if isinstance(value,list) else re.split(r'[,;|]',str(value))
                fields[field] = list(dict.fromkeys(str(v).strip() for v in previous+incoming if str(v).strip()))
                evidence[field].append({'column':column,'value':scalar(value)})
            elif field in ('comments','description'):
                fields[field] = f'{fields[field]}\n{value}'
                evidence[field].append({'column':column, 'value':scalar(value)})
            else:
                warnings.append(f'Multiple columns map to {field}; kept the first value. Review {column}.')
            continue
        fields[field] = value
        evidence[field] = [{'column':column,'value':scalar(value)}]
    return clean_fields(fields, kind), evidence, warnings


def _unique_headers(values: list) -> list[str]:
    counts, headers = {}, []
    for idx, value in enumerate(values):
        name = str(scalar(value) or f'Column {idx+1}').strip()
        counts[name] = counts.get(name, 0) + 1
        headers.append(name if counts[name] == 1 else f'{name} #{counts[name]}')
    return headers


def _tables_to_rows(tables: list[tuple[str,list]], kind: str, mapping: dict | None) -> dict:
    rows, sheets, columns, detected_mapping = [], [], [], {}
    total_cells = 0
    for sheet, grid in tables:
        if not grid:
            continue
        total_cells += sum(len(row) for row in grid)
        if total_cells > MAX_CELLS:
            raise errors.validation('This workbook is too large to review.', {'file':f'Use fewer than {MAX_CELLS:,} cells.'})
        scores = [(sum(bool(field_for_header(c, kind) or (mapping or {}).get(str(c))) for c in row), i)
                  for i, row in enumerate(grid[:40])]
        score, header_index = max(scores, key=lambda item: (item[0],-item[1]))
        if score < 1:
            sheets.append({'name':sheet,'rows':0,'warning':'No recognised headers found. Supply a custom mapping.'})
            continue
        headers = _unique_headers(grid[header_index])
        if len(headers) > MAX_COLUMNS:
            raise errors.validation('This sheet has too many columns.', {'file':f'Use at most {MAX_COLUMNS} columns.'})
        for col in headers:
            if col not in columns:
                columns.append(col)
            if field_for_header(col, kind):
                detected_mapping[col] = field_for_header(col, kind)
        count = 0
        for line, values in enumerate(grid[header_index+1:], start=header_index+2):
            if not any(v is not None and str(v).strip() for v in values):
                continue
            raw = {header:scalar(values[i]) if i < len(values) else None for i, header in enumerate(headers)}
            fields, evidence, warnings = mapped_record(raw, kind, mapping)
            # Repeated header rows and instruction-only rows do not represent intake records.
            if sum(normal_header(raw.get(h)) == normal_header(h) for h in headers) >= max(2,score // 2):
                continue
            if not fields:
                continue
            row = {'row_id':f'{sheet}:{line}', 'source':{'sheet':sheet,'row':line}, 'raw':raw,
                   'fields':fields,'evidence':evidence,'warnings':warnings,'errors':{},'selected':True}
            rows.append(row)
            count += 1
            if len(rows) > MAX_ROWS:
                raise errors.validation('This import has too many rows.', {'file':f'Import at most {MAX_ROWS:,} rows at a time.'})
        sheets.append({'name':sheet,'header_row':header_index+1,'rows':count})
    if not rows:
        raise errors.validation('No records were found. Check the header row or use the blank template.', {'file':'No recognised records.'})
    return {'rows':rows,'sheets':sheets,'columns':columns,'mapping':{**detected_mapping,**(mapping or {})}}


def parse_spreadsheet(data: bytes, filename: str, kind: str = 'intake', mapping: dict | None = None) -> dict:
    ext = Path(filename).suffix.lower()
    if ext in ('.xlsx','.xlsm'):
        from openpyxl import load_workbook
        try:
            book = load_workbook(io.BytesIO(data), read_only=True, data_only=True, keep_links=False)
            tables = []
            total = 0
            for sheet in book.worksheets:
                # Dimensions supplied by a workbook are untrusted; bound actual iteration too.
                grid = []
                for row in sheet.iter_rows(values_only=True):
                    total += len(row)
                    if total > MAX_CELLS or len(grid) > MAX_ROWS + 40 or len(row) > MAX_COLUMNS:
                        raise errors.validation('This workbook is too large to review.', {'file':'Split the workbook into smaller files.'})
                    grid.append(list(row))
                tables.append((sheet.title,grid))
            book.close()
        except errors.ApiError:
            raise
        except Exception as exc:
            raise errors.unreadable_file('We could not read that workbook. Save it as .xlsx or .csv and try again.') from exc
    elif ext == '.csv':
        try:
            text = data.decode('utf-8-sig')
        except UnicodeDecodeError:
            text = data.decode('cp1252')
        try:
            dialect = csv.Sniffer().sniff(text[:8192], delimiters=',;\t|')
        except csv.Error:
            dialect = csv.excel
        tables = [(Path(filename).stem,list(csv.reader(io.StringIO(text),dialect)))]
    else:
        raise errors.validation('Use an Excel workbook or CSV file.', {'file':'Use .xlsx, .xlsm or .csv.'})
    return _tables_to_rows(tables,kind,mapping)


def flatten_adf(value: Any) -> str:
    if value is None:
        return ''
    if isinstance(value,str):
        return value
    if isinstance(value,list):
        return '\n'.join(filter(None,(flatten_adf(v) for v in value)))
    if isinstance(value,dict):
        if value.get('type') == 'hardBreak':
            return '\n'
        if 'text' in value:
            return str(value['text'])
        content = value.get('content')
        if isinstance(content,list):
            joiner = '' if value.get('type') in ('paragraph','heading','text') else '\n'
            return joiner.join(flatten_adf(v) for v in content)
        return str(value.get('displayName') or value.get('name') or value.get('value') or value.get('key') or '')
    return str(value)


def map_json_payload(payload: Any, mapping: dict | None = None, kind: str = 'intake') -> dict:
    """Accept Jira search results, a single Jira issue, a list, or a flat portal record."""
    if isinstance(payload,dict):
        values = payload.get('issues', payload.get('items',payload.get('records',payload)))
    else:
        values = payload
    if isinstance(values,dict):
        values = [values]
    if not isinstance(values,list) or not values or not all(isinstance(v,dict) for v in values):
        raise errors.validation('Provide a JSON object or an array of issue objects.', {'payload':'No records found.'})
    if len(values) > MAX_ROWS:
        raise errors.validation('Too many JSON records.', {'payload':f'Use at most {MAX_ROWS} records.'})
    rows, columns, applied = [], [], {}
    for i, record in enumerate(values,1):
        raw = {}
        jira_fields = record.get('fields')
        if isinstance(jira_fields,dict):
            raw['Issue key'] = record.get('key') or record.get('id')
            names = payload.get('names',{}) if isinstance(payload,dict) else {}
            for key,value in jira_fields.items():
                label = names.get(key,key)
                label = {'summary':'Summary','description':'Description','reporter':'Reporter','assignee':'Assignee',
                         'priority':'Priority','duedate':'Due date','labels':'Labels','status':'Status'}.get(label,label)
                raw[label] = ', '.join(flatten_adf(v) for v in value) if isinstance(value,list) else flatten_adf(value)
        else:
            raw = {k:flatten_adf(v) if isinstance(v,(list,dict)) else scalar(v) for k,v in record.items()}
        if kind == 'intake' and isinstance(record.get('funding'), dict):
            # A portal JSON record can carry the same nested funding object as the form.
            # Keep its source fields independently reviewable; do not import update permissions.
            raw.pop('funding', None)
            for key, value in record['funding'].items():
                target = {'name':'funding_name', 'scope':'funding_scope', 'assumptions':'funding_assumptions'}.get(key,key)
                if target in INTAKE_FIELDS and value is not None:
                    raw[target] = flatten_adf(value) if isinstance(value,(dict,list)) else scalar(value)
        fields,evidence,warnings = mapped_record(raw,kind,mapping)
        rows.append({'row_id':f'json:{i}','source':{'record':i,'external_key':fields.get('external_key')},
                     'raw':raw,'fields':fields,'evidence':evidence,'warnings':warnings,'errors':{},'selected':True})
        for col in raw:
            if col not in columns:
                columns.append(col)
            if field_for_header(col,kind):
                applied[col] = field_for_header(col,kind)
    return {'rows':rows,'sheets':[],'columns':columns,'mapping':{**applied,**(mapping or {})}}


SECTION_RULES = {
    'Business context':r'business\s+(?:context|requirements?|objectives?|justification)(?:\s*/\s*(?:context|requirements?))?|executive summary|overview',
    'Technical context':r'technical (?:context|requirements?|overview)|current state|future state',
    'Scope':r'(?:in[ -])?scope|out[ -]of[ -]scope',
    'Architecture':r'(?:solution|technical|logical|physical)\s+(?:architecture|design)|architecture',
    'Components':r'(?:impacted|affected|dc|solution)\s+(?:components?|systems?)|component(?:s| impact)?',
    'Interfaces':r'interfaces?|integration(?:s| points| and sequence| patterns?)?|consumer applications?|api(?:s| contracts)?',
    'Data':r'data(?: model| flow| migration| requirements?| architecture)?',
    'Security':r'security|authentication|authori[sz]ation|privacy',
    'Non-functional requirements':r'non[ -]functional(?: requirements)?|nfrs?|performance|availability',
    'Dependencies':r'dependencies|assumptions|constraints',
    'Risks':r'risks?|mitigations?',
    'Deployment':r'deployment|implementation(?: plan)?|rollout|backout|rollback',
    'Testing':r'test(?:ing| strategy| plan)?|validation',
    'Environments':r'environments?|environment requirements',
    'Next steps':r'next steps|action items?|follow[ -]ups?',
    'Change summary':r'change summary|summary of changes|component changes',
    'Open questions':r'open (?:questions|items|issues)|outstanding (?:questions|items)',
}


def parse_document_text(text: str, filename: str = 'Document.txt', mapping: dict | None = None, kind: str = 'intake') -> dict:
    if kind=='funding':
        return parse_funding_document_text(text,filename,mapping)
    if not isinstance(text,str) or not text.strip():
        raise errors.unreadable_file('No text was found. Paste the document text to continue.')
    if len(text) > 1_000_000:
        raise errors.validation('This document is too long.', {'text':'Use at most 1,000,000 characters.'})
    raw, evidence, sections, fields = {}, {}, [], {}
    lines = text.replace('\r\n','\n').replace('\r','\n').splitlines()
    for i,line in enumerate(lines,1):
        stripped = line.strip().strip('|').strip()
        match = re.match(r'^\s*(?:[-*#]+\s*)?([^:|=]{2,70})\s*[:|=]\s*(.+?)\s*$', stripped)
        if match:
            key,value = match.groups()
            field = (mapping or {}).get(key) or field_for_header(key,'intake')
            if field:
                fields.setdefault(field,value)
                evidence.setdefault(field,[]).append({'line':i,'text':line})
                raw[key] = value
        header = re.sub(r'^\s*(?:#{1,6}\s*|\d+(?:\.\d+)*[.)]?\s*)','',stripped).strip(': ')
        if len(header) < 110:
            for section,pattern in SECTION_RULES.items():
                if re.fullmatch(pattern,header,re.IGNORECASE):
                    sections.append({'name':section,'heading':header,'line':i,'text':''})
                    break
    for index,section in enumerate(sections):
        end = sections[index+1]['line']-1 if index+1 < len(sections) else len(lines)
        section['text'] = '\n'.join(lines[section['line']:end]).strip()
    if 'name' not in fields:
        for i,line in enumerate(lines[:20],1):
            match = re.match(r'^\s*#*\s*(?:solution architecture|sa document|solution design|project)\s*[:–—-]\s*(.+)',line,re.IGNORECASE)
            if match:
                fields['name'] = match[1].strip()
                evidence['name'] = [{'line':i,'text':line}]
                break
    if 'name' not in fields:
        fields['name'] = Path(filename).stem.replace('_',' ')
        evidence['name'] = [{'filename':filename}]
    # Inline version and author metadata commonly share one line in SA templates.
    for field,pattern in [('sa_author',r'\b(?:Author|Prepared by)\s*:\s*([^\n|·]+)'),
                          ('sa_version',r'\bVersion\s*:?\s*(v?\d+(?:\.\d+){0,3})')]:
        match = re.search(pattern,text,re.IGNORECASE)
        if match:
            fields.setdefault(field,match[1].strip())
            evidence.setdefault(field,[]).append({'text':match[0],'line':text[:match.start()].count('\n')+1})
    if not fields.get('description'):
        context = next((s for s in sections if s['name'] == 'Business context' and s['text']),None)
        if context:
            fields['description'] = context['text'][:8000]
            evidence['description'] = [{'line':context['line'],'text':context['text']}]
    found = {s['name'] for s in sections if s['text']}
    metrics = []
    metric_patterns = {
        'Throughput':r'(?i)(?:\b(?:expected\s+)?(?:tps|throughput)\s*[:=|]?\s*(\d[\d,.]*\s*(?:tps|transactions?(?:\s*(?:/|per)\s*(?:s|sec|second))?)?)|(\d[\d,.]*\s*(?:tps|transactions?\s*(?:/|per)\s*(?:s|sec|second))))',
        'Response time':r'(?i)\b(?:response\s*time|latency)\s*[:=|]?\s*([<>≤≥~]?\s*\d[\d,.]*\s*(?:ms|milliseconds?|s|seconds?))',
        'Availability':r'(?i)\b(?:availability|uptime|sla)\s*[:=|]?\s*([<>≥]?\s*\d{1,3}(?:\.\d+)?\s*%)',
        'Encryption':r'(?i)\b((?:TLS|SSL)\s*\d(?:\.\d)?|AES[ -]?(?:128|192|256)|RSA[ -]?(?:2048|4096))\b',
    }
    for label,pattern in metric_patterns.items():
        for match in re.finditer(pattern,text):
            value = next((v.strip() for v in match.groups() if v),'')
            metrics.append({'label':label,'value':value,'line':text[:match.start()].count('\n')+1,'evidence':match[0]})
    appcats = []
    for number,line in enumerate(lines,1):
        match = re.search(r'(?i)\bapp\s*cat(?:\s*(?:id|number|code))?\s*[:#=|/-]?\s*([A-Za-z0-9][A-Za-z0-9._-]{1,59})',line)
        if match and match[1].casefold() not in ('name','number','code','id','change','description'):
            appcats.append({'code':match[1],'line':number,'evidence':line})
    document = {'metrics':metrics,'appcats':appcats,'text':text,'characters':len(text),'lines':len(lines),'sections':sections,
                'metadata':{k:v for k,v in fields.items() if k in ('sa_author','sa_version','external_key')},
                'coverage':round(len(found)/len(SECTION_RULES)*100),
                'missing_sections':[s for s in SECTION_RULES if s not in found],
                'parser':'regex','components':[]}
    warnings = ['Extracted with deterministic rules. Review the proposed fields and source evidence.']
    return {'rows':[{'row_id':'document:1','source':{'filename':filename},'raw':raw,'fields':clean_fields(fields,'intake'),
                     'evidence':evidence,'warnings':warnings,'errors':{},'selected':True}],
            'sheets':[],'columns':list(raw),'mapping':mapping or {},'document':document}


def parse_document(path: str | Path, filename: str | None = None, mapping: dict | None = None, kind: str = 'intake') -> dict:
    return parse_document_text(textract.extract_text(path),filename or Path(path).name,mapping,kind=kind)


def parse_funding_document_text(text: str, filename: str, mapping: dict | None = None) -> dict:
    """Extract explicit budget labels and estimate/actual tables from email or document text.

    We retain full text and line evidence. Narrative inference stays a warning: only
    labelled amounts, hours and codes become proposed financial values.
    """
    # Reuse the document reader for sections/metrics without treating its inferred
    # initiative title or author as financial evidence.
    base = parse_document_text(text, filename, mapping, kind='intake')
    document = base['document']
    lines = text.replace('\r\n','\n').replace('\r','\n').splitlines()
    raw_context, context_evidence = {},{}
    table_rows, active_headers = [],None
    all_columns = []
    allowed = FUNDING_FIELDS
    for line_number,line in enumerate(lines,1):
        stripped = line.strip().strip('|').strip()
        parts = [s.strip() for s in stripped.split('|')] if '|' in stripped else [s.strip() for s in stripped.split('\t')] if '\t' in stripped else []
        if parts and len(parts)>1:
            recognized = [((mapping or {}).get(value) if value in (mapping or {}) else field_for_header(value,'funding')) for value in parts]
            is_header = sum(bool(v) for v in recognized)>=2 and any(v in recognized for v in ('appcat','team','sto','hours','charged_hours','charged_amount','month','amount'))
            if is_header:
                active_headers = _unique_headers(parts)
                for column in active_headers:
                    if column not in all_columns:
                        all_columns.append(column)
                continue
            if active_headers and len(parts)>=2:
                if all(re.fullmatch(r'[-: ]*',p) for p in parts):
                    continue
                raw = {header:parts[index] if index<len(parts) else '' for index,header in enumerate(active_headers)}
                fields,evidence,warnings = mapped_record(raw,'funding',mapping)
                if any(fields.get(key) not in (None,'') for key in ('hours','amount','charged_hours','charged_amount')):
                    table_rows.append({'row_id':f'document:{line_number}','source':{'filename':filename,'line':line_number},
                       'raw':raw,'fields':fields,'evidence':{k:[{**v,'line':line_number} for v in values] for k,values in evidence.items()},
                       'warnings':warnings,'errors':{},'selected':True})
                    continue
            # Two-column label/value tables are document context rather than estimate rows.
            if len(parts)==2 and (field_for_header(parts[0],'funding') or (mapping or {}).get(parts[0])):
                key,value = parts
                raw_context[key] = value
                context_evidence[key] = {'line':line_number,'text':line}
                active_headers = None
                continue
        elif line.strip():
            active_headers = None
        match = re.match(r'^\s*(?:[-*#]+\s*)?([^:|=]{2,70})\s*[:|=]\s*(.+?)\s*$',stripped)
        if match:
            key,value = match.groups()
            field = (mapping or {}).get(key) or field_for_header(key,'funding')
            if field in allowed:
                raw_context[key] = value
                context_evidence[key] = {'line':line_number,'text':line}
    fields,evidence,warnings = mapped_record(raw_context,'funding',mapping)
    for field,items in evidence.items():
        for item in items:
            item.update(context_evidence.get(item['column'],{}))
    # An explicitly labelled PRN in an email subject is safe to capture even when
    # the subject also contains the project name.
    if not fields.get('prn_code'):
        match = re.search(r'(?i)\bPRN\s*[-:#]?\s*(\d{3,})\b',text)
        if match:
            fields['prn_code'] = 'PRN-'+match[1]
            evidence['prn_code'] = [{'line':text[:match.start()].count('\n')+1,'text':match[0]}]
    if not fields.get('name'):
        title = re.search(r'(?im)^\s*(?:subject|funding estimate|funding request|estimate)\s*:\s*(.+)$',text)
        if title:
            fields['name'] = title[1].strip()
            evidence['name'] = [{'line':text[:title.start()].count('\n')+1,'text':title[0]}]
    if not fields.get('name') and Path(filename).stem not in ('Pasted document','Funding document'):
        fields['name'] = Path(filename).stem.replace('_',' ')
        evidence['name'] = [{'filename':filename}]
    # Explicit "Phase: 12 hours @ $110" lines are a common compact estimate format.
    if not table_rows and any(fields.get(k) for k in ('appcat','team','sto')):
        for line_number,line in enumerate(lines,1):
            match = re.search(r'(?i)\b(Planning|Development|Support)\s*[:|=-]\s*(\d[\d,.]*)\s*(?:h(?:ours|rs?)?)(?:\s*@\s*[$£€]?\s*(\d[\d,.]*))?',line)
            if match:
                proposed = {'phase':match[1].title(),'hours':number_value(match[2])}
                if match[3]:
                    proposed['rate'] = number_value(match[3])
                table_rows.append({'row_id':f'document:{line_number}','source':{'filename':filename,'line':line_number},
                    'raw':{'Estimate line':line},'fields':proposed,'evidence':{'hours':[{'line':line_number,'text':line}]},
                    'warnings':['Read from a labelled estimate line. Confirm the AppCat/team and phase.'],'errors':{},'selected':True})
    context_warnings = warnings+['Extracted with deterministic rules. Review all financial values and source evidence before committing.']
    if table_rows:
        rows = []
        for row in table_rows:
            row['raw'] = {**raw_context,**row['raw']}
            row['fields'] = clean_fields({**fields,**row['fields']},'funding')
            row['evidence'] = {**evidence,**row['evidence']}
            row['warnings'] = context_warnings+row['warnings']
            rows.append(row)
    else:
        context_warnings.append('No structured estimate table was found. Only explicit labelled fields were proposed; add missing financial details in review.')
        rows = [{'row_id':'document:1','source':{'filename':filename},'raw':raw_context,'fields':fields,'evidence':evidence,
                 'warnings':context_warnings,'errors':{},'selected':True}]
    document['kind'] = 'funding'
    document['estimate_rows'] = len(table_rows)
    document['metadata'] = {key:fields[key] for key in ('prn_code','name','owner','decision','charge_type','currency') if fields.get(key)}
    for column in raw_context:
        if column not in all_columns:
            all_columns.append(column)
    return {'rows':rows,'document':document,'columns':all_columns,'sheets':[],
            'mapping':{col:field_for_header(col,'funding') for col in all_columns if field_for_header(col,'funding')} | (mapping or {})}
