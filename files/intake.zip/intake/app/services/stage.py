"""Initiative stage flow (owner B1), master plan round-2 decision 4:

Intake → Grooming (saved and slotted) → Solution (Mark as groomed) → Estimation (Change Summary accepted with at least
one component) → Planning (L2 approved) → Build → QA → Release → Closed.

advance() only ever moves forward, sets the matching Current Status and logs the transition. Call it inside the
caller's db.transaction(). B3's change-summary apply can call advance(iid, "Estimation", reason=...).
"""
from __future__ import annotations

from app import db
from app.activity import log_activity
from app.today import now_iso

ORDER = ("Intake", "Grooming", "Solution", "Estimation", "Planning", "Build", "QA", "Release", "Closed")
STATUS = {"Intake": "Backlog", "Grooming": "Backlog", "Solution": "Backlog", "Estimation": "Backlog",
          "Planning": "In progress", "Build": "In progress", "QA": "In progress", "Release": "In progress",
          "Closed": "Completed"}


def advance(initiative_id: int, stage: str, *, reason: str | None = None) -> dict | None:
    """Move the initiative forward to `stage` if it is earlier in the flow. Returns {from, to} or None."""
    if stage not in ORDER:
        raise ValueError(f"Unknown stage {stage}")
    row = db.query_one("SELECT rddc, stage FROM initiatives WHERE id = ?", (initiative_id,))
    if row is None or row["stage"] not in ORDER or ORDER.index(row["stage"]) >= ORDER.index(stage):
        return None
    db.update("initiatives", initiative_id, {"stage": stage, "status": STATUS[stage], "updated_at": now_iso()})
    text = f"Stage moved {row['stage']} → {stage}" + (f" ({reason})" if reason else "")
    log_activity("initiative", initiative_id, "update",
                 {"label": row["rddc"], "changes": {"stage": [row["stage"], stage]}, "summary": text}, initiative_id)
    return {"from": row["stage"], "to": stage}
