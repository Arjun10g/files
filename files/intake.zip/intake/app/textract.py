"""Text extraction for uploaded documents (owner B1): .docx (paragraphs and tables in order), .pdf, .md, .txt.

Any failure raises errors.unreadable_file (422, details.fallback = "paste_text") so the UI offers the paste box.
"""
from __future__ import annotations

import re
from pathlib import Path

from app import errors

SUPPORTED = (".docx", ".pdf", ".md", ".txt")


def _docx_text(path: Path) -> str:
    from docx import Document
    from docx.table import Table

    doc = Document(str(path))
    lines: list[str] = []
    def blocks(container):
        for block in container.iter_inner_content():
            if isinstance(block, Table):
                for row in block.rows:
                    seen = set()
                    cells = []
                    nested = []
                    for cell in row.cells:
                        if cell._tc in seen:
                            continue
                        seen.add(cell._tc)
                        cells.append(" ".join(cell.text.split()))
                        nested.extend(cell.tables)
                    if any(cells):
                        lines.append(" | ".join(cells))
                    for table in nested:
                        for nested_row in table.rows:
                            lines.append(" | ".join(" ".join(cell.text.split()) for cell in nested_row.cells))
                    lines.append("")
            else:
                lines.append(block.text)
    for section in doc.sections:
        blocks(section.header)
    blocks(doc)
    for section in doc.sections:
        blocks(section.footer)
    # Comments and footnotes are often where concurrence and open questions live.
    from zipfile import ZipFile

    from lxml import etree
    with ZipFile(path) as archive:
        for name in ("word/comments.xml", "word/footnotes.xml", "word/endnotes.xml"):
            if name in archive.namelist():
                xml = etree.fromstring(archive.read(name), parser=etree.XMLParser(resolve_entities=False, no_network=True))
                lines.append(name.rsplit("/", 1)[-1].replace(".xml", "").title())
                for paragraph in xml.xpath("//*[local-name()='p']"):
                    lines.append("".join(paragraph.xpath(".//*[local-name()='t']/text()")))
    return "\n".join(lines)


def _pdf_text(path: Path) -> str:
    from pypdf import PdfReader

    reader = PdfReader(str(path))
    if reader.is_encrypted:
        raise errors.unreadable_file("That PDF is password protected. Paste the text instead.")
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def _plain_text(path: Path) -> str:
    data = path.read_bytes()
    if b"\x00" in data:
        raise errors.unreadable_file("That file does not contain readable text. Paste the text instead.")
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise errors.unreadable_file()


def _normalise(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace(" ", " ")
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip() + "\n"


def extract_text(path, mime: str | None = None) -> str:
    """Plain text of a .docx/.pdf/.md/.txt file. Raises ApiError unreadable_file (422) when it cannot be read."""
    p = Path(path)
    ext = p.suffix.lower()
    if ext not in SUPPORTED:
        raise errors.unreadable_file("Attach a .docx, .pdf, .md or .txt file, or paste the text instead.")
    try:
        if ext == ".docx":
            text = _docx_text(p)
        elif ext == ".pdf":
            text = _pdf_text(p)
        else:
            text = _plain_text(p)
    except errors.ApiError:
        raise
    except Exception as exc:  # any parser failure (corrupt zip, bad xref, ...) becomes a friendly 422
        raise errors.unreadable_file() from exc
    if not text or not text.strip():
        raise errors.unreadable_file("We could not find any text in that file. Paste the text instead.")
    return _normalise(text)
