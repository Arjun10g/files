"""Environment -> Config. The only module allowed to read the real clock is app/today.py (via TODAY here)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

APP_VERSION = "2.0.0"

BASE_DIR = Path(__file__).resolve().parent.parent
APP_DIR = BASE_DIR / "app"
STATIC_DIR = BASE_DIR / "static"
DATA_DIR = BASE_DIR / "data"
SCHEMA_PATH = APP_DIR / "schema.sql"
SEED_DIR = APP_DIR / "seed"

AI_MODES = ("auto", "simulated", "live")
AI_SPEEDS = ("Realistic", "Fast")
DEFAULT_TODAY = "2026-10-19"
DEFAULT_TZ = "America/Toronto"


def _env(name: str, default: str) -> str:
    value = os.environ.get(name)
    return value if value not in (None, "") else default


def _env_int(name: str, default: int) -> int:
    try:
        return int(_env(name, str(default)))
    except ValueError:
        return default


@dataclass
class Config:
    PORT: int = 5055
    HOST: str = "127.0.0.1"
    DB_PATH: str = str(DATA_DIR / "portal.db")
    UPLOAD_DIR: str = str(DATA_DIR / "portal_uploads")
    TODAY: str = DEFAULT_TODAY            # default demo date; app_settings.demo_today overrides at runtime
    DEMO_NOW_TIME: str = "09:30"          # fixed wall-clock used by engines (grooming cut-off etc.)
    TIMEZONE: str = DEFAULT_TZ
    AI_MODE: str = "auto"                 # auto = live only when ANTHROPIC_API_KEY is set
    AI_SPEED: str = "Realistic"
    AI_MODEL_HEAVY: str = "claude-opus-5-5"
    AI_MODEL_FAST: str = "claude-sonnet-5-5"
    AI_TIMEOUT: int = 20                  # seconds, live calls use max_retries=0
    HAS_API_KEY: bool = False
    APP_VERSION: str = APP_VERSION
    MAX_UPLOAD_BYTES: int = 10 * 1024 * 1024      # per-file limit enforced by the upload handlers
    MAX_CONTENT_LENGTH: int = 11 * 1024 * 1024    # request cap; headroom for multipart overhead
    ALLOWED_UPLOAD_EXTENSIONS: tuple = (".docx", ".pdf", ".md", ".txt")
    TESTING: bool = False
    DEBUG: bool = False
    extra: dict = field(default_factory=dict)

    @classmethod
    def from_env(cls, **overrides) -> Config:
        ai_mode = _env("BMO_AI_MODE", "auto").lower()
        ai_speed = _env("BMO_AI_SPEED", "Realistic").capitalize()
        cfg = cls(
            PORT=_env_int("BMO_PORT", 5055),
            HOST=_env("BMO_HOST", "127.0.0.1"),
            DB_PATH=_env("BMO_DB_PATH", str(DATA_DIR / "portal.db")),
            UPLOAD_DIR=_env("BMO_UPLOAD_DIR", str(DATA_DIR / "portal_uploads")),
            TODAY=_env("BMO_TODAY", DEFAULT_TODAY),
            DEMO_NOW_TIME=_env("BMO_NOW_TIME", "09:30"),
            TIMEZONE=_env("BMO_TZ", DEFAULT_TZ),
            AI_MODE=ai_mode if ai_mode in AI_MODES else "auto",
            AI_SPEED=ai_speed if ai_speed in AI_SPEEDS else "Realistic",
            AI_MODEL_HEAVY=_env("BMO_AI_MODEL_HEAVY", "claude-opus-5-5"),
            AI_MODEL_FAST=_env("BMO_AI_MODEL_FAST", "claude-sonnet-5-5"),
            AI_TIMEOUT=_env_int("BMO_AI_TIMEOUT", 20),
            HAS_API_KEY=bool(os.environ.get("ANTHROPIC_API_KEY")),
        )
        for key, value in overrides.items():
            setattr(cfg, key.upper(), value)
        return cfg

    def as_flask(self) -> dict:
        """Upper-case keys copied into app.config."""
        out = {k: v for k, v in self.__dict__.items() if k.isupper()}
        out["JSON_SORT_KEYS"] = False
        return out


def load_config(**overrides) -> Config:
    return Config.from_env(**overrides)
