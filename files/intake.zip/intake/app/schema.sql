-- BMO DC Project Management Tool: SQLite schema (FROZEN CONTRACT, owner B0).
-- Conventions: dates 'YYYY-MM-DD'; datetimes ISO 8601 with offset (app/today.py now_iso());
-- months 'YYYY-MM'; JSON stored as TEXT (*_json columns); source IN ('manual','ai','derived','seed').
-- Enum spellings must match docs/00_MASTER_PLAN.md section 6.1 and GET /api/lookups exactly.

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------- settings & lookups
CREATE TABLE app_settings (
  key   TEXT PRIMARY KEY,                -- ai_mode, ai_speed, demo_today, persona, rddc_next
  value TEXT
);

CREATE TABLE lookups (
  category   TEXT NOT NULL,              -- see docs/contracts.md "Lookups payload"
  value      TEXT NOT NULL,              -- stored value (integers as text, e.g. priority '2')
  label      TEXT,                       -- display label when different (e.g. 'P2', 'Critical')
  sort       INTEGER DEFAULT 0,
  is_default INTEGER DEFAULT 0,
  PRIMARY KEY (category, value)
);

CREATE TABLE release_trains (
  code       TEXT PRIMARY KEY,           -- DC-2702
  train_date TEXT NOT NULL,              -- Saturday, 'YYYY-MM-DD'
  status     TEXT NOT NULL DEFAULT 'Planned' CHECK (status IN ('Planned','Done')),
  notes      TEXT
);

CREATE TABLE dc_intakes (
  code              TEXT PRIMARY KEY,    -- DCI-3391
  name              TEXT NOT NULL,
  lob               TEXT,
  requestor         TEXT,
  priority          INTEGER CHECK (priority BETWEEN 1 AND 4),
  requested_go_live TEXT,
  description       TEXT,
  -- contract change (QA-C-02): default people applied to an initiative created from this intake
  dc_pm_id          INTEGER REFERENCES resources(id),
  dc_sa_id          INTEGER REFERENCES resources(id),
  tech_lead_id      INTEGER REFERENCES resources(id),
  pm_id             INTEGER REFERENCES resources(id)
);

-- ---------------------------------------------------------------- people & catalogue
CREATE TABLE resources (
  id                    INTEGER PRIMARY KEY,
  name                  TEXT NOT NULL,
  email                 TEXT,
  role                  TEXT NOT NULL,
  team                  TEXT,            -- EAPI, CIAM, SRE, Mobile, Web, QA, DC SA, DC PM, Delivery, Change, Release, Business
  team_label            TEXT,            -- deck bar label, e.g. 'EAPI (Dev1)'
  component_id          INTEGER REFERENCES dc_components(id),
  location              TEXT,
  hourly_rate           REAL DEFAULT 110,
  default_monthly_hours REAL DEFAULT 140,
  capacity_eligible     INTEGER NOT NULL DEFAULT 1 CHECK (capacity_eligible IN (0,1)),
  active                INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1))
);

CREATE TABLE dc_components (
  id                INTEGER PRIMARY KEY,
  code              TEXT UNIQUE NOT NULL CHECK (code IN ('APIP','APIGW','EDP','CIAM','MOB_IOS','MOB_AND','OLB','PAYHUB','NOTIF','STMT','SRE','FRAUD')),
  name              TEXT NOT NULL,
  team              TEXT,
  ci_name           TEXT,                -- configuration item used for CRQ Affected CIs
  component_lead_id INTEGER REFERENCES resources(id),
  keywords          TEXT,                -- JSON array of lower-case match terms
  base_hours_low    REAL NOT NULL,
  base_hours_medium REAL NOT NULL,
  base_hours_high   REAL NOT NULL,
  description       TEXT
);

CREATE TABLE component_dependencies (
  from_component_id INTEGER NOT NULL REFERENCES dc_components(id),   -- upstream (changed) component
  to_component_id   INTEGER NOT NULL REFERENCES dc_components(id),   -- downstream consumer to regression-test
  kind              TEXT NOT NULL DEFAULT 'downstream' CHECK (kind IN ('downstream')),
  note              TEXT,
  PRIMARY KEY (from_component_id, to_component_id)
);

-- ---------------------------------------------------------------- budget
CREATE TABLE prn_budget (
  prn_code      TEXT PRIMARY KEY,        -- PRN-77310
  name          TEXT,
  lob           TEXT,
  funded_hours  REAL NOT NULL,
  rate          REAL NOT NULL DEFAULT 110,   -- CAD per hour (blended)
  budget_amount REAL,                    -- funded_hours * rate
  currency      TEXT NOT NULL DEFAULT 'CAD',
  owner_id      INTEGER REFERENCES resources(id),
  start_month   TEXT,
  end_month     TEXT
);

CREATE TABLE prn_charges (
  id             INTEGER PRIMARY KEY,
  prn_code       TEXT NOT NULL REFERENCES prn_budget(prn_code) ON DELETE CASCADE,
  month          TEXT NOT NULL,
  charged_hours  REAL NOT NULL,
  charged_amount REAL,
  source         TEXT NOT NULL DEFAULT 'seed',
  UNIQUE (prn_code, month)
);

-- ---------------------------------------------------------------- initiatives
CREATE TABLE initiatives (
  id                   INTEGER PRIMARY KEY,
  rddc                 TEXT UNIQUE NOT NULL,          -- RDDC-24817
  dc_intake            TEXT REFERENCES dc_intakes(code),
  name                 TEXT NOT NULL,
  lob                  TEXT,
  priority             INTEGER NOT NULL DEFAULT 3 CHECK (priority BETWEEN 1 AND 4),
  stage                TEXT NOT NULL DEFAULT 'Intake'
                       CHECK (stage IN ('Intake','Grooming','Solution','Estimation','Planning','Build','QA','Release','Closed')),
  status               TEXT NOT NULL DEFAULT 'Backlog' CHECK (status IN ('Backlog','In progress','Completed')),
  labels               TEXT,                          -- JSON array of strings
  requestor            TEXT,
  requestor_id         INTEGER REFERENCES resources(id),
  assigned_to_id       INTEGER REFERENCES resources(id),
  pm_id                INTEGER REFERENCES resources(id),
  tech_lead_id         INTEGER REFERENCES resources(id),
  dc_pm_id             INTEGER REFERENCES resources(id),
  dc_sa_id             INTEGER REFERENCES resources(id),
  sa_author            TEXT,
  sa_version           TEXT,
  sa_completeness      INTEGER CHECK (sa_completeness BETWEEN 0 AND 100),
  sa_missing_json      TEXT,                          -- JSON array of missing SA section names
  sa_doc_attachment_id INTEGER REFERENCES attachments(id),
  description          TEXT,
  platform             TEXT,
  region               TEXT,
  channel              TEXT,
  apt_number           TEXT,
  external_pr_code     TEXT,
  business_analyst      TEXT,
  solution_concurrence_date TEXT,
  jira_key             TEXT,
  jira_status          TEXT,
  project_key          TEXT,
  prn_code             TEXT REFERENCES prn_budget(prn_code),
  requested_go_live    TEXT,
  target_release       TEXT REFERENCES release_trains(code),
  planned_start        TEXT,
  planned_end          TEXT,
  readiness_date       TEXT,
  qa_date              TEXT,
  qa_signoff_date      TEXT,
  prod_date            TEXT,
  l2_hours             REAL,
  l2_low_hours         REAL,
  l2_high_hours        REAL,
  l2_tshirt            TEXT CHECK (l2_tshirt IN ('XS','S','M','L','XL')),
  l2_status            TEXT CHECK (l2_status IN ('Draft','Pending approval','Approved','Rejected')),
  l2_baseline_hours    REAL,                          -- locked at approval; delta = l2_hours - baseline
  l2_submitted_at      TEXT,
  l2_approved_at       TEXT,
  l2_approved_by       TEXT,
  l2_reminders_sent    INTEGER NOT NULL DEFAULT 0,
  baseline_set_at      TEXT,
  rag_cached           TEXT CHECK (rag_cached IN ('Red','Amber','Green')),
  health_cached_json   TEXT,                          -- last engines.health output (written by derive.py only)
  rag_overrides_json   TEXT,                          -- {"schedule":{"rag":"Green","reason":"..","by":"..","at":".."}}
  comments             TEXT,
  created_at           TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at           TEXT DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------- AI audit (referenced by many tables)
CREATE TABLE ai_runs (
  id                 INTEGER PRIMARY KEY,
  feature            TEXT NOT NULL CHECK (feature IN ('intake_analysis','change_summary','l2_estimate','wbs','resources','rebalance',
                       'risks','exec_summary','cr_compliance','skill_matrix','nudges','meeting_extract','lessons','intake_autofill','assistant')),
  initiative_id      INTEGER REFERENCES initiatives(id) ON DELETE SET NULL,
  scope              TEXT NOT NULL DEFAULT 'initiative' CHECK (scope IN ('initiative','portfolio','draft')),
  input_hash         TEXT NOT NULL,
  input_json         TEXT,
  output_json        TEXT,
  edited_output_json TEXT,
  mode               TEXT NOT NULL CHECK (mode IN ('simulated_fixture','simulated_generated','live','live_fallback')),
  model              TEXT,
  prompt_version     TEXT,
  fixture_key        TEXT,
  variant_index      INTEGER NOT NULL DEFAULT 0,
  confidence         REAL CHECK (confidence IS NULL OR (confidence >= 0 AND confidence <= 1)),
  sources_json       TEXT,                            -- JSON array [{type,id,label,field?,excerpt?}]
  warnings_json      TEXT,                            -- JSON array of strings
  status             TEXT NOT NULL DEFAULT 'generated' CHECK (status IN ('generated','accepted','rejected','superseded')),
  instruction        TEXT,                            -- Regenerate instruction
  regen_of           INTEGER REFERENCES ai_runs(id),
  reject_reason      TEXT,
  error              TEXT,                            -- live failure reason when mode = live_fallback
  latency_ms         INTEGER,
  tokens_in          INTEGER,
  tokens_out         INTEGER,
  minutes_saved      REAL NOT NULL DEFAULT 0,         -- credited on accept
  applied_json       TEXT,                            -- counts written on accept, e.g. {"tasks":14}
  actor              TEXT,
  decided_at         TEXT,
  created_at         TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX ix_ai_runs_init ON ai_runs(initiative_id, feature, created_at);

CREATE TABLE initiative_components (
  id                INTEGER PRIMARY KEY,
  initiative_id     INTEGER NOT NULL REFERENCES initiatives(id) ON DELETE CASCADE,
  component_id      INTEGER NOT NULL REFERENCES dc_components(id),
  approval          TEXT NOT NULL DEFAULT 'Pending' CHECK (approval IN ('Pending','Approved','Not required','Rejected')),
  change_summary    TEXT,
  complexity        TEXT NOT NULL DEFAULT 'Medium' CHECK (complexity IN ('Low','Medium','High')),
  est_hours         REAL,                             -- dev hours = catalogue base_hours_<complexity> unless edited
  component_lead_id INTEGER REFERENCES resources(id),
  sort              INTEGER DEFAULT 0,
  source            TEXT NOT NULL DEFAULT 'manual',
  ai_run_id         INTEGER REFERENCES ai_runs(id),
  UNIQUE (initiative_id, component_id)
);

-- ---------------------------------------------------------------- plan
CREATE TABLE wbs_tasks (
  id                      INTEGER PRIMARY KEY,
  initiative_id           INTEGER NOT NULL REFERENCES initiatives(id) ON DELETE CASCADE,
  initiative_component_id INTEGER REFERENCES initiative_components(id) ON DELETE SET NULL,
  wbs_code                TEXT NOT NULL,              -- WBS-100, child WBS-210
  parent_id               INTEGER REFERENCES wbs_tasks(id) ON DELETE CASCADE,
  step                    TEXT NOT NULL,
  phase                   TEXT CHECK (phase IN ('Estimation','Development','Integration','QA','UAT','Readiness','Production','Hypercare')),
  description             TEXT,
  owner_id                INTEGER REFERENCES resources(id),   -- SME / Owner
  resource_id             INTEGER REFERENCES resources(id),   -- Resource doing the work
  planned_start           TEXT,                       -- current schedule (edited in the grid, drawn on the Gantt)
  planned_end             TEXT,
  baseline_start          TEXT,                       -- locked snapshot (plan accept after L2 approval, or Re-baseline)
  baseline_end            TEXT,
  actual_start            TEXT,
  actual_end              TEXT,
  est_hours               REAL NOT NULL DEFAULT 0,
  allocation_pct          INTEGER CHECK (allocation_pct IS NULL OR allocation_pct BETWEEN 1 AND 100),
  status                  TEXT NOT NULL DEFAULT 'Backlog' CHECK (status IN ('Backlog','In progress','Completed','Blocked')),
  pct                     INTEGER NOT NULL DEFAULT 0 CHECK (pct BETWEEN 0 AND 100),
  at_risk                 INTEGER NOT NULL DEFAULT 0 CHECK (at_risk IN (0,1)),
  comments                TEXT,
  is_milestone            INTEGER NOT NULL DEFAULT 0 CHECK (is_milestone IN (0,1)),
  sort                    INTEGER DEFAULT 0,
  source                  TEXT NOT NULL DEFAULT 'manual',
  ai_run_id               INTEGER REFERENCES ai_runs(id),
  updated_at              TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (initiative_id, wbs_code)
);

CREATE TABLE wbs_dependencies (
  task_id            INTEGER NOT NULL REFERENCES wbs_tasks(id) ON DELETE CASCADE,
  depends_on_task_id INTEGER NOT NULL REFERENCES wbs_tasks(id) ON DELETE CASCADE,
  type               TEXT NOT NULL DEFAULT 'FS' CHECK (type IN ('FS')),
  lag_days           INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (task_id, depends_on_task_id),
  CHECK (task_id <> depends_on_task_id)
);

-- ---------------------------------------------------------------- capacity
CREATE TABLE resource_availability (
  resource_id     INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  month           TEXT NOT NULL,
  available_hours REAL NOT NULL CHECK (available_hours >= 0),
  note            TEXT,
  updated_by      TEXT,
  PRIMARY KEY (resource_id, month)
);

CREATE TABLE allocations (
  id            INTEGER PRIMARY KEY,
  resource_id   INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  initiative_id INTEGER NOT NULL REFERENCES initiatives(id) ON DELETE CASCADE,
  task_id       INTEGER REFERENCES wbs_tasks(id) ON DELETE CASCADE,
  month         TEXT NOT NULL,
  hours         REAL NOT NULL CHECK (hours >= 0),
  firmness      TEXT NOT NULL DEFAULT 'tentative' CHECK (firmness IN ('tentative','confirmed')),
  source        TEXT NOT NULL DEFAULT 'derived' CHECK (source IN ('derived','manual','seed'))
);
CREATE INDEX ix_alloc_month ON allocations(month, resource_id);
CREATE INDEX ix_alloc_init ON allocations(initiative_id);

CREATE TABLE skills (
  id       INTEGER PRIMARY KEY,
  name     TEXT UNIQUE NOT NULL,
  category TEXT
);

CREATE TABLE resource_skills (
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  skill_id    INTEGER NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  level       INTEGER NOT NULL CHECK (level BETWEEN 1 AND 3),   -- 1 working, 2 strong, 3 expert
  source      TEXT NOT NULL DEFAULT 'manual',
  evidence    TEXT,                                            -- e.g. 'RDDC-24310 WBS-210'
  ai_run_id   INTEGER REFERENCES ai_runs(id),
  PRIMARY KEY (resource_id, skill_id)
);

-- ---------------------------------------------------------------- risks
CREATE TABLE risks (
  id            INTEGER PRIMARY KEY,
  risk_code     TEXT UNIQUE,                                   -- RSK-001
  initiative_id INTEGER NOT NULL REFERENCES initiatives(id) ON DELETE CASCADE,
  task_id       INTEGER REFERENCES wbs_tasks(id) ON DELETE SET NULL,
  title         TEXT NOT NULL,
  description   TEXT,
  category      TEXT NOT NULL CHECK (category IN ('Schedule','Resource','Scope','Dependency','Budget','Technical','Compliance')),
  severity      INTEGER NOT NULL CHECK (severity BETWEEN 1 AND 4),     -- 1 Low · 2 Medium · 3 High · 4 Critical
  likelihood    INTEGER NOT NULL CHECK (likelihood BETWEEN 1 AND 4),   -- 1 Rare · 2 Unlikely · 3 Possible · 4 Likely
  score         INTEGER GENERATED ALWAYS AS (severity * likelihood) STORED,
  trigger_signal TEXT,
  mitigation    TEXT,
  owner_id      INTEGER REFERENCES resources(id),
  status        TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open','Mitigating','Closed')),
  due_date      TEXT,
  source        TEXT NOT NULL DEFAULT 'manual',
  ai_run_id     INTEGER REFERENCES ai_runs(id),
  created_at    TEXT DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------- files
CREATE TABLE attachments (
  id             INTEGER PRIMARY KEY,
  initiative_id  INTEGER REFERENCES initiatives(id) ON DELETE CASCADE,
  entity_type    TEXT NOT NULL CHECK (entity_type IN ('initiative','change_request','document','meeting_note')),
  entity_id      INTEGER,
  kind           TEXT NOT NULL CHECK (kind IN ('sa_doc','tech_validation','biz_validation','backout_plan','meeting_notes','other')),
  filename       TEXT NOT NULL,
  stored_path    TEXT NOT NULL,                                -- relative to data/uploads/
  mime           TEXT,
  size_bytes     INTEGER,
  extracted_text TEXT,
  version        TEXT,
  uploaded_by    TEXT,
  uploaded_at    TEXT DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------- change governance
CREATE TABLE change_requests (
  id                            INTEGER PRIMARY KEY,
  initiative_id                 INTEGER NOT NULL REFERENCES initiatives(id) ON DELETE CASCADE,
  crq_number                    TEXT UNIQUE,                   -- CRQ000001052216 (CRQ + 12 digits)
  raised_at                     TEXT,                          -- date the CRQ was raised (lead-time rule)
  crq_start                     TEXT,                          -- ISO datetime with offset
  crq_end                       TEXT,
  release_type                  TEXT CHECK (release_type IN ('Bundle','Independent')),
  release_train                 TEXT REFERENCES release_trains(code),
  target_release                TEXT REFERENCES release_trains(code),
  affected_cis                  TEXT,                          -- JSON array of CI names
  impacted_components           TEXT,                          -- JSON array of component codes
  implementation_status         TEXT NOT NULL DEFAULT 'Not Started'
                                CHECK (implementation_status IN ('Not Started','Scheduled','In progress','Implemented','Backed out')),
  crq_approval_status           TEXT NOT NULL DEFAULT 'Draft'
                                CHECK (crq_approval_status IN ('Draft','Submitted','CAB Review','Approved','Rejected')),
  sto_approval                  TEXT CHECK (sto_approval IN ('Tentative Go','Tentative No Go','Go','No-Go')),
  cms_lead_id                   INTEGER REFERENCES resources(id),
  rel_lead_id                   INTEGER REFERENCES resources(id),
  resource_id                   INTEGER REFERENCES resources(id),
  tech_validation_status        TEXT NOT NULL DEFAULT 'Not Started'
                                CHECK (tech_validation_status IN ('Not Started','In progress','Completed','Failed')),
  biz_validation_status         TEXT NOT NULL DEFAULT 'Not Started'
                                CHECK (biz_validation_status IN ('Not Started','In progress','Completed','Failed')),
  tech_validation_attachment_id INTEGER REFERENCES attachments(id),
  biz_validation_attachment_id  INTEGER REFERENCES attachments(id),
  backout_attachment_id         INTEGER REFERENCES attachments(id),
  implemented_at                TEXT,
  compliance_json               TEXT,                          -- cached engines.compliance output
  source                        TEXT NOT NULL DEFAULT 'manual',
  created_at                    TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at                    TEXT DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------- grooming & outbox
CREATE TABLE grooming_sessions (
  id           INTEGER PRIMARY KEY,
  session_date TEXT NOT NULL,                                  -- Tue/Thu
  start_time   TEXT NOT NULL DEFAULT '10:00',
  title        TEXT,
  capacity     INTEGER NOT NULL DEFAULT 6,
  status       TEXT NOT NULL DEFAULT 'Scheduled' CHECK (status IN ('Scheduled','Held','Cancelled')),
  UNIQUE (session_date, start_time)
);

CREATE TABLE grooming_slots (
  session_id      INTEGER NOT NULL REFERENCES grooming_sessions(id) ON DELETE CASCADE,
  initiative_id   INTEGER NOT NULL REFERENCES initiatives(id) ON DELETE CASCADE,
  slot_order      INTEGER NOT NULL DEFAULT 0,
  recipients_json TEXT,                                        -- JSON array of resource ids
  status          TEXT NOT NULL DEFAULT 'Proposed' CHECK (status IN ('Proposed','Confirmed','Discussed')),
  PRIMARY KEY (session_id, initiative_id)
);

CREATE TABLE notifications (                                   -- the Outbox; nothing is really emailed
  id               INTEGER PRIMARY KEY,
  rule             TEXT NOT NULL CHECK (rule IN ('grooming_invite','sa_action_required','component_approval','l2_approval',
                     'l2_escalation','cr_noncompliance','validation_missing','backout_missing','ai_nudge','manual')),
  trigger_event    TEXT,                                       -- human text: 'Saved RDDC-24817', 'SA Completeness 88%'
  initiative_id    INTEGER REFERENCES initiatives(id) ON DELETE CASCADE,
  entity_type      TEXT,
  entity_id        INTEGER,
  to_resource_id   INTEGER REFERENCES resources(id),
  to_name          TEXT NOT NULL,
  cc_names         TEXT,                                       -- JSON array of names
  subject          TEXT NOT NULL,
  body             TEXT NOT NULL,
  action_required_by TEXT,                                     -- date shown as "Action required by"
  due_at           TEXT,                                       -- when it is (or was) due to send
  sent_at          TEXT,
  status           TEXT NOT NULL DEFAULT 'Queued' CHECK (status IN ('Queued','Sent','Acknowledged','Dismissed')),
  escalation_level INTEGER NOT NULL DEFAULT 0,
  dedupe_key       TEXT UNIQUE,                                -- rule:entity:period
  ai_run_id        INTEGER REFERENCES ai_runs(id),
  created_at       TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX ix_notifications_status ON notifications(status, due_at);

-- ---------------------------------------------------------------- artifacts
CREATE TABLE decisions (
  id            INTEGER PRIMARY KEY,
  initiative_id INTEGER REFERENCES initiatives(id) ON DELETE CASCADE,
  title         TEXT NOT NULL,
  context       TEXT,
  decision      TEXT NOT NULL,
  decided_by    TEXT,
  decided_on    TEXT,
  status        TEXT NOT NULL DEFAULT 'Approved' CHECK (status IN ('Proposed','Approved','Superseded')),
  source        TEXT NOT NULL DEFAULT 'manual',               -- manual | ai | system (auto-entries)
  ai_run_id     INTEGER REFERENCES ai_runs(id),
  created_at    TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE lessons_learned (
  id             INTEGER PRIMARY KEY,
  initiative_id  INTEGER REFERENCES initiatives(id) ON DELETE CASCADE,
  category       TEXT,
  what_happened  TEXT,
  lesson         TEXT NOT NULL,
  recommendation TEXT,
  tags           TEXT,                                         -- JSON array (component codes, themes)
  source         TEXT NOT NULL DEFAULT 'manual',
  ai_run_id      INTEGER REFERENCES ai_runs(id),
  created_at     TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE meeting_notes (
  id                  INTEGER PRIMARY KEY,
  initiative_id       INTEGER REFERENCES initiatives(id) ON DELETE CASCADE,
  grooming_session_id INTEGER REFERENCES grooming_sessions(id) ON DELETE SET NULL,
  meeting_date        TEXT,
  title               TEXT NOT NULL,
  attendees           TEXT,                                    -- JSON array of names
  notes_md            TEXT,
  action_items_json   TEXT,                                    -- [{action, owner, due, status}]
  created_at          TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE documents (
  id            INTEGER PRIMARY KEY,
  initiative_id INTEGER REFERENCES initiatives(id) ON DELETE CASCADE,
  doc_type      TEXT NOT NULL CHECK (doc_type IN ('SA','Architecture','Test Plan','Runbook','Release Notes','Validation Evidence','Backout Plan','Other')),
  title         TEXT NOT NULL,
  version       TEXT,
  attachment_id INTEGER REFERENCES attachments(id) ON DELETE SET NULL,
  url           TEXT,
  owner_id      INTEGER REFERENCES resources(id),
  status        TEXT CHECK (status IN ('Draft','In review','Final')),
  components    TEXT,                                          -- JSON array of component codes (architecture search)
  updated_at    TEXT DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------- assistant & audit
CREATE TABLE assistant_messages (
  id              INTEGER PRIMARY KEY,
  conversation_id TEXT NOT NULL,
  role            TEXT NOT NULL CHECK (role IN ('user','assistant')),
  content         TEXT NOT NULL,
  initiative_id   INTEGER REFERENCES initiatives(id) ON DELETE SET NULL,
  ai_run_id       INTEGER REFERENCES ai_runs(id),
  created_at      TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX ix_assistant_conv ON assistant_messages(conversation_id, id);

CREATE TABLE activity_log (
  id            INTEGER PRIMARY KEY,
  ts            TEXT DEFAULT CURRENT_TIMESTAMP,
  actor         TEXT NOT NULL DEFAULT 'demo.user',
  persona       TEXT,                                          -- DC PM, Dev Lead, Requestor, STO, Account Manager
  entity_type   TEXT NOT NULL,
  entity_id     INTEGER,
  initiative_id INTEGER,
  action        TEXT NOT NULL,                                 -- create | update | delete | scope_change | approve | reject | ai_accept | ...
  detail_json   TEXT
);
CREATE INDEX ix_activity_init ON activity_log(initiative_id, id);
