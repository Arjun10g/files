"""Accept an AI run: write its (optionally edited or partially selected) output into the domain tables.

Every row written carries ``source='ai'`` and ``ai_run_id``. Derived data (allocations, health) is rebuilt by
``app.services.derive`` inside the same transaction, then the run is marked accepted.
"""
from __future__ import annotations

import importlib
import logging
import re
from typing import Any

from app import db
from app.ai import context as C
from app.ai import generators as G
from app.ai.provider import actor, envelope, get_run
from app.ai.schemas import validate
from app.errors import ApiError, conflict
from app.errors import validation as validation_error
from app.today import get_today, now_iso

log = logging.getLogger("bmo.ai.apply")
DB_PHASES = ("Estimation", "Development", "Integration", "QA", "UAT", "Readiness", "Production", "Hypercare")


# ------------------------------------------------------------------ helpers
def _optional(module: str):
    try:
        return importlib.import_module(module)
    except ModuleNotFoundError as exc:
        if exc.name in (module, module.rsplit(".", 1)[0]):
            return None
        raise


def log_activity(entity_type: str, entity_id: Any, action: str, detail: dict | None = None, initiative_id: int | None = None) -> None:
    mod = _optional("app.activity")
    if mod is not None and hasattr(mod, "log_activity"):
        mod.log_activity(entity_type, entity_id, action, detail, initiative_id=initiative_id)
        return
    db.insert("activity_log", {"ts": now_iso(), "actor": "demo.user", "persona": actor(), "entity_type": entity_type,
                               "entity_id": entity_id if isinstance(entity_id, int) else None, "initiative_id": initiative_id,
                               "action": action, "detail_json": db.to_json(detail or {})})


def derive_after(initiative_id: int | None) -> dict | None:
    if not initiative_id:
        return None
    mod = _optional("app.services.derive")
    if mod is None:
        log.info("services.derive not installed; allocations and health not refreshed")
        return None
    mod.rebuild_allocations(initiative_id)
    return mod.refresh_health(initiative_id)


def _pick(items: list, selected: list[int] | None) -> list[tuple[int, Any]]:
    if selected is None:
        return list(enumerate(items))
    wanted = {int(i) for i in selected}
    return [(i, x) for i, x in enumerate(items) if i in wanted]


def _require_initiative(row: dict) -> int:
    if not row["initiative_id"]:
        raise ApiError("bad_request", "This draft is not linked to an initiative.", 400)
    return int(row["initiative_id"])


def _initiative(iid: int) -> dict:
    return C.parse_row(db.query_one("SELECT * FROM initiatives WHERE id = ?", (iid,))) or {}


def _stage_at_least(iid: int, stage: str) -> None:
    order = ("Intake", "Grooming", "Solution", "Estimation", "Planning", "Build", "QA", "Release", "Closed")
    cur = db.scalar("SELECT stage FROM initiatives WHERE id = ?", (iid,))
    if cur in order and order.index(cur) < order.index(stage):
        db.update("initiatives", iid, {"stage": stage, "updated_at": now_iso()})


def _update_l2(iid: int) -> None:
    bundle = C.load_bundle(iid)
    est = G.l2_numbers(bundle)
    ini = bundle["initiative"]
    values = {"l2_hours": float(est["total_hours"]), "l2_low_hours": float(est["low_hours"]),
              "l2_high_hours": float(est["high_hours"]), "l2_tshirt": est["tshirt"], "updated_at": now_iso()}
    if ini.get("l2_status") in (None, "", "Rejected"):
        values["l2_status"] = "Draft"
    db.update("initiatives", iid, values)


# ------------------------------------------------------------------ appliers: each returns (applied counts, extra response fields)
def apply_change_summary(row, out, selected, inputs):
    iid = _require_initiative(row)
    ini = _initiative(iid)
    catalog = {c["code"]: c for c in C.component_catalog()}
    existing = {r["component_id"]: r for r in db.query("SELECT * FROM initiative_components WHERE initiative_id = ?", (iid,))}
    sort = max((r["sort"] or 0 for r in existing.values()), default=0)
    approved = bool(ini.get("l2_approved_at"))
    n = 0
    for _i, comp in _pick(out.get("components", []), selected):
        cat = catalog.get(comp["component_code"])
        if not cat:
            continue
        hours = comp.get("est_hours")
        if hours is None:
            hours = cat.get(f"base_hours_{comp['complexity'].lower()}")
        values = {"approval": comp["approval"], "change_summary": comp["change_summary"], "complexity": comp["complexity"],
                  "est_hours": float(hours or 0), "source": "ai", "ai_run_id": row["id"]}
        cur = existing.get(cat["id"])
        if cur:
            db.update("initiative_components", cur["id"], values)
            if approved and cur["complexity"] != comp["complexity"]:
                log_activity("initiative_component", cur["id"], "scope_change",
                             {"component_code": cat["code"], "change": "complexity", "from": cur["complexity"], "to": comp["complexity"]}, iid)
        else:
            sort += 10
            new_id = db.insert("initiative_components", {**values, "initiative_id": iid, "component_id": cat["id"],
                                                         "component_lead_id": cat.get("component_lead_id"), "sort": sort})
            if approved:
                log_activity("initiative_component", new_id, "scope_change", {"component_code": cat["code"], "change": "insert"}, iid)
        n += 1
    text = C.load_bundle(iid).get("sa_doc_text")
    updates: dict[str, Any] = {"updated_at": now_iso()}
    if text:
        score = C.sa_score(text)
        updates["sa_completeness"] = int(score.get("completeness") or 0)
        updates["sa_missing_json"] = db.to_json(list(score.get("missing") or []))
    db.update("initiatives", iid, updates)
    transition = None
    if n:
        stage_mod = _optional("app.services.stage")
        if stage_mod is not None and hasattr(stage_mod, "advance"):
            transition = stage_mod.advance(iid, "Estimation", reason=f"Change Summary accepted with {n} DC component{'s' if n != 1 else ''}")
        else:
            _stage_at_least(iid, "Estimation")
    _update_l2(iid)
    return {"initiative_components": n, "initiatives": 1}, ({"stage": transition} if transition else {})


def _supersede_decisions(iid: int | None, title_prefix: str) -> None:
    db.execute("UPDATE decisions SET status = 'Superseded' WHERE initiative_id IS ? AND title LIKE ? AND source = 'ai' "
               "AND status != 'Superseded'", (iid, f"{title_prefix}%"))


def _decision(iid: int | None, title: str, context: str, decision: str, run_id: int) -> int:
    return db.insert("decisions", {"initiative_id": iid, "title": G.clip(title, 120), "context": G.clip(context, 2000) or None,
                                   "decision": G.clip(decision, 3000), "decided_by": actor(),
                                   "decided_on": get_today().isoformat(), "status": "Approved", "source": "ai",
                                   "ai_run_id": run_id, "created_at": now_iso()})


def apply_l2_estimate(row, out, selected, inputs):
    """Stores the explanation in the Decision Log; L2 numbers and status are owned by the L2 workflow."""
    iid = _require_initiative(row)
    _supersede_decisions(iid, "L2 estimate rationale")
    assumptions = "Assumptions: " + "; ".join(out.get("assumptions") or []) if out.get("assumptions") else ""
    drivers = "Drivers: " + "; ".join(f"{d['factor']} ({d['effect']})" for d in out.get("drivers") or []) if out.get("drivers") else ""
    did = _decision(iid, f"L2 estimate rationale: {G.fmt_hours(out['total_hours'])} ({out['tshirt']})",
                    " ".join(x for x in (assumptions, drivers) if x), out["narrative"], row["id"])
    return {"decisions": 1}, {"decision_id": did}


def apply_wbs(row, out, selected, inputs):
    iid = _require_initiative(row)
    bundle = C.load_bundle(iid)
    ini = bundle["initiative"]
    tasks = list(out.get("tasks", []))
    if selected is not None:
        keep = {t["wbs_code"] for _, t in _pick(tasks, selected)}
        keep |= {t["parent_code"] for t in tasks if t["wbs_code"] in keep and t.get("parent_code")}
        tasks = [t for t in tasks if t["wbs_code"] in keep]
        codes = {t["wbs_code"] for t in tasks}
        tasks = [{**t, "depends_on": [d for d in t["depends_on"] if d in codes],
                  "parent_code": t["parent_code"] if t.get("parent_code") in codes else None} for t in tasks]
    if not tasks:
        raise validation_error("Select at least one plan step to accept.", {"selected": "No steps selected"})
    start = C.next_business_day(get_today()).isoformat()
    target = ini.get("target_release") or (bundle.get("target_train") or {}).get("code")
    sched = G.schedule_plan(tasks, start, C.release_trains(), target)
    dates = sched["dates"]
    approved = ini.get("l2_status") == "Approved"
    res_ids = {r["id"] for r in db.query("SELECT id FROM resources")}
    ic_by_code = {c["code"]: c["id"] for c in bundle.get("components", [])}
    ctx = {"data": {"people_rows": db.query("SELECT id, name, role, team FROM resources WHERE active = 1")}}
    db.execute("DELETE FROM wbs_tasks WHERE initiative_id = ?", (iid,))
    ids: dict[str, int] = {}
    stamp = now_iso()
    ordered = sorted(tasks, key=lambda t: (t.get("parent_code") is not None, 0))
    sort_of = {t["wbs_code"]: (i + 1) * 10 for i, t in enumerate(tasks)}
    for t in ordered:
        s, e = dates[t["wbs_code"]]
        rid = t.get("suggested_resource_id") if t.get("suggested_resource_id") in res_ids else None
        owner = G.resolve_owner(t, bundle, ctx)
        values = {
            "initiative_id": iid, "initiative_component_id": ic_by_code.get(t.get("component_code")), "wbs_code": t["wbs_code"],
            "parent_id": ids.get(t.get("parent_code")), "step": t["step"],
            "phase": t["phase"] if t["phase"] in DB_PHASES else "Estimation", "description": t.get("description") or None,
            "owner_id": owner if owner in res_ids else None, "resource_id": rid, "planned_start": s, "planned_end": e,
            "baseline_start": s if approved else None, "baseline_end": e if approved else None,
            "est_hours": float(t["est_hours"]), "allocation_pct": int(t["allocation_pct"]) if t.get("allocation_pct") else None,
            "status": "Backlog", "pct": 0, "is_milestone": 1 if t.get("is_milestone") else 0, "sort": sort_of[t["wbs_code"]],
            "source": "ai", "ai_run_id": row["id"], "updated_at": stamp,
        }
        ids[t["wbs_code"]] = db.insert("wbs_tasks", values)
    for t in tasks:
        if t.get("parent_code") and t["parent_code"] in ids:
            db.update("wbs_tasks", ids[t["wbs_code"]], {"parent_id": ids[t["parent_code"]]})
    deps = 0
    for t in tasks:
        for d in t.get("depends_on", []):
            if d in ids and d != t["wbs_code"]:
                db.execute("INSERT OR IGNORE INTO wbs_dependencies (task_id, depends_on_task_id) VALUES (?, ?)", (ids[t["wbs_code"]], ids[d]))
                deps += 1
    kd = G.key_dates(tasks, dates)
    updates = {k: kd[k] for k in ("planned_start", "planned_end", "readiness_date", "qa_date", "prod_date")}
    updates["updated_at"] = stamp
    if not ini.get("target_release") and sched["train"]:
        updates["target_release"] = sched["train"]
    if approved:
        updates["baseline_set_at"] = stamp
    db.update("initiatives", iid, updates)
    return {"wbs_tasks": len(ids), "wbs_dependencies": deps}, {}


def apply_resources(row, out, selected, inputs):
    iid = _require_initiative(row)
    res_ids = {r["id"] for r in db.query("SELECT id FROM resources")}
    n = 0
    # Accept fills unassigned steps only; replacing someone already assigned needs the user to select that row.
    guard = "" if selected is not None else " AND resource_id IS NULL"
    for _i, rec in _pick(out.get("recommendations", []), selected):
        rid = rec.get("recommended_resource_id")
        if rid is None and selected is not None and rec.get("candidates"):
            rid = rec["candidates"][0]["resource_id"]  # the user picked this row: assign the top-ranked person shown
        if rec.get("wbs_code") and rid in res_ids:
            n += db.get_db().execute("UPDATE wbs_tasks SET resource_id = ?, updated_at = ? WHERE initiative_id = ? AND wbs_code = ?"
                                     + guard, (rid, now_iso(), iid, rec["wbs_code"])).rowcount
    return {"wbs_tasks": n}, {}


def apply_rebalance(row, out, selected, inputs):
    iid = _require_initiative(row)
    options = out.get("options", [])
    if not options:
        return {}, {}
    idx = int(selected[0]) if selected else int(out.get("recommended_option_index") or 0)
    if not 0 <= idx < len(options):
        raise validation_error("Choose one of the suggested options.", {"selected": "Option not found"})
    opt = options[idx]
    task = db.query_one("SELECT id FROM wbs_tasks WHERE initiative_id = ? AND wbs_code = ?", (iid, opt["task_wbs_code"]))
    if task is None:
        raise conflict(f"{opt['task_wbs_code']} is no longer in the plan.")
    db.update("wbs_tasks", task["id"], {"resource_id": opt["to_resource_id"], "updated_at": now_iso()})
    db.insert("decisions", {"initiative_id": iid, "title": G.clip(f"Reassigned {opt['task_wbs_code']}", 120),
                            "context": G.clip(opt.get("effect") or "", 600), "decision": G.clip(opt["action"], 600),
                            "decided_by": actor(), "decided_on": get_today().isoformat(), "status": "Approved",
                            "source": "ai", "ai_run_id": row["id"], "created_at": now_iso()})
    return {"wbs_tasks": 1, "decisions": 1}, {"option_index": idx}


def _next_risk_code() -> str:
    nums = [int(m.group(1)) for r in db.query("SELECT risk_code FROM risks WHERE risk_code IS NOT NULL")
            if (m := re.match(r"RSK-(\d+)$", r["risk_code"] or ""))]
    return f"RSK-{(max(nums) + 1) if nums else 1:03d}"


def apply_risks(row, out, selected, inputs):
    iid = _require_initiative(row)
    tasks = {t["wbs_code"]: t["id"] for t in db.query("SELECT id, wbs_code FROM wbs_tasks WHERE initiative_id = ?", (iid,))}
    res_ids = {r["id"] for r in db.query("SELECT id FROM resources")}
    n = 0
    for _i, r in _pick(out.get("risks", []), selected):
        steps = r.get("mitigation_steps") or []
        dues = sorted(s["due"] for s in steps if s.get("due"))
        mitigation = "; ".join(f"{s['step']} ({s['owner_role']}{', by ' + G.fmt_date(s['due']) if s.get('due') else ''})" for s in steps)
        db.insert("risks", {"risk_code": _next_risk_code(), "initiative_id": iid, "task_id": tasks.get(r.get("wbs_code")),
                            "title": r["title"], "description": r["description"], "category": r["category"],
                            "severity": int(r["severity"]), "likelihood": int(r["likelihood"]), "trigger_signal": r["trigger_signal"],
                            "mitigation": G.clip(mitigation + (f". Contingency: {r['contingency']}" if r.get("contingency") else ""), 2000),
                            "owner_id": r.get("owner_resource_id") if r.get("owner_resource_id") in res_ids else None,
                            "status": "Open", "due_date": dues[0] if dues else None, "source": "ai", "ai_run_id": row["id"],
                            "created_at": now_iso()})
        n += 1
    return {"risks": n}, {}


def apply_skill_matrix(row, out, selected, inputs):
    res_ids = {r["id"] for r in db.query("SELECT id FROM resources")}
    skill_ids = {r["name"].lower(): r["id"] for r in db.query("SELECT id, name FROM skills")}
    new_skills = n = 0
    for _i, r in _pick(out.get("rows", []), selected):
        if r["resource_id"] not in res_ids:
            continue
        for s in r.get("skills", []):
            sid = skill_ids.get(s["skill"].lower())
            if sid is None:
                sid = db.insert("skills", {"name": s["skill"], "category": "Inferred"})
                skill_ids[s["skill"].lower()] = sid
                new_skills += 1
            evidence = "; ".join(s.get("evidence") or [])[:500] or None
            db.execute("""INSERT INTO resource_skills (resource_id, skill_id, level, source, evidence, ai_run_id)
                          VALUES (?, ?, ?, 'ai', ?, ?)
                          ON CONFLICT(resource_id, skill_id) DO UPDATE SET level = MAX(level, excluded.level),
                          evidence = COALESCE(excluded.evidence, evidence), ai_run_id = excluded.ai_run_id""",
                       (r["resource_id"], sid, int(s["level"]), evidence, row["id"]))
            n += 1
    return {"resource_skills": n, "skills": new_skills}, {}


REMINDER_RULES = ("sa_action_required", "component_approval", "l2_approval", "l2_escalation", "cr_noncompliance",
                  "validation_missing", "backout_missing")


def apply_nudges(row, out, selected, inputs):
    """One consolidated reminder per recipient, keyed like the reminders engine (rule:resource:<id>:<date>).

    The per-item reminders it consolidates (same recipient, same initiatives) are dismissed. A key already sent,
    dismissed or consolidated by an earlier accept is left alone, so accepting twice never adds rows.
    """
    existing = {r["dedupe_key"]: r for r in db.query(
        "SELECT id, dedupe_key, status, ai_run_id FROM notifications WHERE dedupe_key IS NOT NULL")}
    rddc_ids = {r["rddc"]: r["id"] for r in db.query("SELECT id, rddc FROM initiatives")}
    res_ids = {r["id"] for r in db.query("SELECT id FROM resources")}
    n = updated = dismissed = 0
    for _i, m in _pick(out.get("messages", []), selected):
        rid = m.get("recipient_resource_id") if m.get("recipient_resource_id") in res_ids else None
        key = G.nudge_key(m["rule"], rid, m["recipient_name"], m["action_required_by"])
        iids = sorted({rddc_ids[i["rddc"]] for i in m.get("items", []) if i.get("rddc") in rddc_ids})
        entity_type, entity_id = ("resource", rid) if rid else ("recipient", None)
        values = {"rule": m["rule"], "trigger_event": "Reminder drafted by AI and accepted",
                  "initiative_id": iids[0] if iids else None, "entity_type": entity_type, "entity_id": entity_id,
                  "to_resource_id": rid, "to_name": m["recipient_name"], "subject": m["subject"], "body": m["body"],
                  "action_required_by": m["action_required_by"], "due_at": m["action_required_by"],
                  "escalation_level": int(m.get("escalation_level") or 0), "ai_run_id": row["id"]}
        hit = existing.get(key)
        if hit and (hit["status"] != "Queued" or hit["ai_run_id"]):
            continue
        if hit:
            db.update("notifications", hit["id"], values)
            keep = hit["id"]
            updated += 1
        else:
            keep = db.insert("notifications", {**values, "status": "Queued", "dedupe_key": key, "created_at": now_iso()})
            n += 1
        existing[key] = {"id": keep, "dedupe_key": key, "status": "Queued", "ai_run_id": row["id"]}
        if iids:
            who = "to_resource_id = ?" if rid else "to_name = ?"
            dismissed += db.get_db().execute(
                f"""UPDATE notifications SET status = 'Dismissed' WHERE status = 'Queued' AND id != ? AND ai_run_id IS NULL
                     AND {who} AND initiative_id IN ({','.join('?' for _ in iids)})
                     AND rule IN ({','.join('?' for _ in REMINDER_RULES)})""",
                [keep, rid or m["recipient_name"], *iids, *REMINDER_RULES]).rowcount
    return {"notifications": n}, {"updated": updated, "dismissed": dismissed}


def apply_meeting_extract(row, out, selected, inputs):
    rddc_ids = {r["rddc"]: r["id"] for r in db.query("SELECT id, rddc FROM initiatives")}
    note = None
    if inputs.get("meeting_note_id"):
        note = C.parse_row(db.query_one("SELECT * FROM meeting_notes WHERE id = ?", (int(inputs["meeting_note_id"]),)))
    decisions, actions = out.get("decisions", []), out.get("actions", [])
    combined = [("decision", d) for d in decisions] + [("action", a) for a in actions]
    chosen = [x for _, x in _pick(combined, selected)]
    date_ = out.get("meeting_date") or (note or {}).get("meeting_date") or get_today().isoformat()
    default_iid = (note or {}).get("initiative_id")
    n_dec = 0
    for kind, d in chosen:
        if kind != "decision":
            continue
        db.insert("decisions", {"initiative_id": rddc_ids.get(d.get("rddc")) or default_iid,
                                "title": G.clip(d["decision"], 80), "context": d.get("rationale") or "Recorded from meeting notes",
                                "decision": d["decision"], "decided_by": d.get("made_by"), "decided_on": date_, "status": "Approved",
                                "source": "ai", "ai_run_id": row["id"], "created_at": now_iso()})
        n_dec += 1
    new_actions = [{"action": a["action"], "owner": a.get("owner_name"), "owner_resource_id": a.get("owner_resource_id"),
                    "due": a.get("due"), "status": "Open", "rddc": a.get("rddc"), "ai_run_id": row["id"]}
                   for kind, a in chosen if kind == "action"]
    notes_written = 0
    if new_actions or note is None:
        if note:
            items = list(note.get("action_items_json") or []) + new_actions
            db.update("meeting_notes", note["id"], {"action_items_json": db.to_json(items)})
        else:
            first = next((rddc_ids.get(x.get("rddc")) for _, x in chosen if x.get("rddc")), None)
            db.insert("meeting_notes", {"initiative_id": first, "meeting_date": date_, "title": f"Meeting notes {G.fmt_date(date_)}",
                                        "attendees": db.to_json(out.get("attendees") or []), "notes_md": inputs.get("text") or out["summary"],
                                        "action_items_json": db.to_json(new_actions), "created_at": now_iso()})
        notes_written = 1
    return {"decisions": n_dec, "meeting_notes": notes_written}, {"actions": len(new_actions)}


def apply_lessons(row, out, selected, inputs):
    if out.get("mode") != "draft":
        return {}, {}
    iid = db.scalar("SELECT id FROM initiatives WHERE rddc = ?", (out.get("initiative_rddc"),)) or row["initiative_id"]
    n = 0
    for _i, lesson in _pick(out.get("lessons", []), selected):
        db.insert("lessons_learned", {"initiative_id": iid, "category": lesson["category"], "what_happened": lesson["what_happened"],
                                      "lesson": lesson["lesson"], "recommendation": lesson["recommendation"],
                                      "tags": db.to_json(out.get("tags") or []), "source": "ai", "ai_run_id": row["id"],
                                      "created_at": now_iso()})
        n += 1
    return {"lessons_learned": n}, {}


def apply_intake_autofill(row, out, selected, inputs):
    return {}, {"fields": out.get("fields", {}), "likely_components": out.get("likely_components", [])}


def apply_intake_analysis(row, out, selected, inputs):
    labels = list(out.get("suggested_labels") or [])
    if selected is not None:
        labels = [x for _, x in _pick(labels, selected)]
    if not row["initiative_id"]:
        return {}, {"fields": {"labels": labels, "priority": out.get("suggested_priority")}}
    iid = int(row["initiative_id"])
    current = _initiative(iid).get("labels") or []
    merged = list(current) + [x for x in labels if x not in current]
    db.update("initiatives", iid, {"labels": db.to_json(merged), "updated_at": now_iso()})
    return {"initiatives": 1}, {"labels": merged}


def apply_cr_compliance(row, out, selected, inputs):
    cr = None
    if inputs.get("change_request_id"):
        cr = db.query_one("SELECT * FROM change_requests WHERE id = ?", (int(inputs["change_request_id"]),))
    if cr is None and out.get("crq_number"):
        cr = db.query_one("SELECT * FROM change_requests WHERE crq_number = ?", (out["crq_number"],))
    if cr is None:
        raise conflict("There is no change request to update. Create the CRQ draft first.")
    engine = C.check_cr(C.parse_row(cr), {})
    flags = (engine or {}).get("flags")
    if flags is None:
        flags = [{"code": f["rule_id"], "message": f["detail"]} for f in out.get("findings", []) if f["status"] == "Fail"]
    review = {"score": out["score"], "sto_readiness": out["sto_readiness"], "reviewer_note": out["reviewer_note"],
              "findings": out["findings"], "ai_run_id": row["id"], "reviewed_at": now_iso(), "reviewed_by": actor()}
    payload = {"ok": bool(engine["ok"]) if engine and "ok" in engine else bool(out["compliant"]), "flags": flags, "ai": review}
    db.update("change_requests", cr["id"], {"compliance_json": db.to_json(payload), "updated_at": now_iso()})
    number = cr["crq_number"] or f"change request {cr['id']}"
    _supersede_decisions(cr["initiative_id"], f"CR compliance review: {number}")
    _decision(cr["initiative_id"], f"CR compliance review: {number}",
              f"Score {out['score']}%, STO readiness {out['sto_readiness']}.", out["reviewer_note"], row["id"])
    return {"change_requests": 1, "decisions": 1}, {"compliance": payload}


def apply_exec_summary(row, out, selected, inputs):
    """Saved as a status note under Artifacts → Meeting Notes; the human Comments field is never touched."""
    iid = int(row["initiative_id"]) if out.get("scope") == "initiative" and row["initiative_id"] else None
    parts = [f"**{out['headline']}**", out["summary_md"]]
    for label, items in (("Highlights", out.get("highlights")), ("Concerns", out.get("concerns")), ("Asks", out.get("asks"))):
        if items:
            parts.append(f"{label}:\n" + "\n".join(f"- {x}" for x in items))
    title = f"Executive summary · week ending {G.fmt_date(out['period']['to'])}" + (f" · {out['rddc']}" if out.get("rddc") else "")
    note_id = db.insert("meeting_notes", {"initiative_id": iid, "meeting_date": out["period"]["to"], "title": G.clip(title, 200),
                                          "attendees": db.to_json([]), "notes_md": "\n\n".join(parts),
                                          "action_items_json": db.to_json([]), "created_at": now_iso()})
    return {"meeting_notes": 1}, {"meeting_note_id": note_id}


def apply_assistant(row, out, selected, inputs):
    return {}, {}


APPLIERS = {
    "change_summary": apply_change_summary, "l2_estimate": apply_l2_estimate, "wbs": apply_wbs, "resources": apply_resources,
    "rebalance": apply_rebalance, "risks": apply_risks, "skill_matrix": apply_skill_matrix, "nudges": apply_nudges,
    "meeting_extract": apply_meeting_extract, "lessons": apply_lessons, "intake_autofill": apply_intake_autofill,
    "intake_analysis": apply_intake_analysis, "cr_compliance": apply_cr_compliance, "exec_summary": apply_exec_summary,
    "assistant": apply_assistant,
}


# ------------------------------------------------------------------ entry points
def apply_run(run_id: int, selected: list[int] | None = None, edited_output: dict | None = None) -> dict:
    row = get_run(int(run_id))
    if row["status"] != "generated":
        raise conflict("This AI draft was already accepted, discarded or replaced. Generate a new one.",
                       {"status": row["status"]})
    feature = row["feature"]
    if edited_output is not None:
        problems = validate(feature, edited_output)
        if problems:
            raise validation_error("The edited draft has values that cannot be saved.", {"edited_output": "; ".join(problems[:3])})
    output = edited_output if edited_output is not None else (db.from_json(row["output_json"], {}) or {})
    inputs = (db.from_json(row.get("input_json"), {}) or {}).get("inputs") or {}
    if selected is not None and not isinstance(selected, list):
        raise validation_error("Selection must be a list of row numbers.", {"selected": "Expected a list"})
    iid = row["initiative_id"]
    with db.transaction():
        claimed = db.get_db().execute("UPDATE ai_runs SET status = 'accepted', decided_at = ? WHERE id = ? AND status = 'generated'",
                                      (now_iso(), row["id"])).rowcount
        if claimed != 1:
            raise conflict("This AI draft was already accepted, discarded or replaced. Generate a new one.", {"status": "accepted"})
        applied, extra = APPLIERS[feature](row, output, selected, inputs)
        health = derive_after(iid) if iid and applied else None
        db.update("ai_runs", row["id"], {"status": "accepted", "decided_at": now_iso(), "applied_json": db.to_json(applied),
                                         "edited_output_json": db.to_json(edited_output) if edited_output is not None else None,
                                         "actor": actor()})
        log_activity("ai_run", row["id"], "ai_accept",
                     {"feature": feature, "mode": row["mode"], "applied": applied, "edited": edited_output is not None}, iid)
    result = {"ai_run_id": row["id"], "status": "accepted", "initiative_id": iid, "applied": applied,
              "minutes_saved": row.get("minutes_saved") or 0, **extra}
    if health is not None:
        result["health"] = health
    return result


def reject_run(run_id: int, reason: str | None = None) -> dict:
    row = get_run(int(run_id))
    with db.transaction():
        claimed = db.get_db().execute(
            "UPDATE ai_runs SET status = 'rejected', reject_reason = ?, decided_at = ?, actor = ? WHERE id = ? AND status = 'generated'",
            ((reason or "")[:500] or None, now_iso(), actor(), row["id"])).rowcount
        if claimed != 1:
            raise conflict("This AI draft was already accepted, discarded or replaced.", {"status": row["status"]})
        log_activity("ai_run", row["id"], "ai_reject", {"feature": row["feature"], "reason": reason}, row["initiative_id"])
    return {"ai_run_id": row["id"], "status": "rejected"}


def run_envelope(run_id: int) -> dict:
    return envelope(get_run(run_id))
