"""Portfolio assistant: entity extraction, intent router and data-grounded handlers.

Every handler reads the live database and cites only the rows it returned, so an answer can never point at a
record that does not exist. The same query functions back the showcase-fixture ``bindings`` (simulated tier)
and the tool-use loop of the live tier (``TOOLS``).
"""
from __future__ import annotations

import difflib
import re
from datetime import date, timedelta
from typing import Any

from app import db
from app.ai import context as C
from app.ai import generators as G
from app.ai.schemas import ASSISTANT_INTENTS, COMPONENT_NAMES, STAGES

MONTH_WORDS = {"jan": 1, "january": 1, "feb": 2, "february": 2, "mar": 3, "march": 3, "apr": 4, "april": 4, "may": 5,
               "jun": 6, "june": 6, "jul": 7, "july": 7, "aug": 8, "august": 8, "sep": 9, "sept": 9, "september": 9,
               "oct": 10, "october": 10, "nov": 11, "november": 11, "dec": 12, "december": 12}
QUARTER_START = {"Q1": 11, "Q2": 2, "Q3": 5, "Q4": 8}
COMPONENT_SYNONYMS = {
    "APIP": ("api platform", "eapi", "enterprise api", "api work", "api"), "APIGW": ("api gateway", "gateway"),
    "EDP": ("edp", "enterprise data platform", "kafka", "data platform"), "CIAM": ("ciam", "identity", "iam", "security", "oauth"),
    "MOB_IOS": ("ios", "iphone"), "MOB_AND": ("android",), "OLB": ("olb", "online banking", "web"),
    "PAYHUB": ("payments hub", "payhub"), "NOTIF": ("notifications", "notification service"),
    "STMT": ("statements", "statement"), "SRE": ("sre", "observability"), "FRAUD": ("fraud",),
}
TEAM_BY_COMPONENT = {"APIP": "EAPI", "APIGW": "EAPI", "EDP": "EAPI", "PAYHUB": "EAPI", "NOTIF": "EAPI", "CIAM": "CIAM",
                     "FRAUD": "CIAM", "MOB_IOS": "Mobile", "MOB_AND": "Mobile", "OLB": "Web", "STMT": "Web", "SRE": "SRE"}
TEAM_WORDS = {"eapi": "EAPI", "ciam": "CIAM", "sre": "SRE", "mobile": "Mobile", "web": "Web", "qa": "QA", "testing": "QA",
              "dc sa": "DC SA", "solution architect": "DC SA", "architects": "DC SA"}
STOP = {"the", "and", "for", "with", "what", "which", "who", "is", "are", "of", "in", "on", "to", "a", "an", "me", "us",
        "this", "that", "how", "many", "much", "does", "do", "any", "our", "be", "it", "its", "by", "at", "from", "about",
        "show", "tell", "list", "give", "next", "week", "month", "project", "initiative", "initiatives", "projects"}

INTENT_PATTERNS: dict[str, list[tuple[str, float]]] = {
    "explain_health": [(r"\bwhy\b.*\b(red|amber|green|rag|health|at risk|over)", 3), (r"what'?s driving|drivers? of", 3),
                       (r"management attention|needs? attention", 2), (r"explain.*(health|rag|red|amber)", 3)],
    "list_by_rag": [(r"\b(red|amber|green)\b", 2), (r"\bat risk\b|off track|on track|in trouble", 2.5),
                    (r"\b(which|list|show|what)\b.*\b(projects?|initiatives?)\b", 0.5)],
    "overallocated_resources": [(r"over[- ]?allocat|overbook|over[- ]?capacity|over 100|overloaded|stretched|too much work", 4)],
    "summarize_initiative": [(r"summar|overview|status of|tell me about|where (are we|is)|update on|how is .* going", 3)],
    "blockers": [(r"block|stuck|holding .* up|imped|what'?s stopping|issues? with", 4)],
    "suggest_resource": [(r"suggest|recommend|who should|best (person|developer|fit)|assign|staff", 3.5)],
    "availability": [(r"capacity|availab|spare|free\b|bandwidth|who can take|room for", 3)],
    "resource_workload": [(r"working on|workload|assigned to|doing|busy with|allocated to|booked on", 3)],
    "upcoming_releases": [(r"release|going (to|into) prod|production|deploy|go[- ]live|\btrain\b|implement", 2.5)],
    "cr_noncompliance": [(r"non[- ]?complian|compliance|complian", 4), (r"\bcrq?s?\b.*(flag|issue|missing|problem)", 2)],
    "top_risks": [(r"\brisks?\b", 3), (r"biggest (concern|threat)", 2)],
    "milestone_dates": [(r"\bwhen\b", 2.5), (r"\bdates?\b|deadline|qa date|readiness|milestone|prod date|go[- ]live date", 2.5)],
    "component_demand": [(r"demand|how (much|many) hours|load on|hours (on|for)|workload for (the )?team", 3)],
    "pending_approvals": [(r"approv|sign[- ]?off|waiting on|pending", 3)],
    "skill_lookup": [(r"who knows|skill|expert|experience (in|with)|who can do|proficien", 3.5)],
    "portfolio_stats": [(r"how many|count|per lob|by (stage|lob|rag|pm)|breakdown|number of|split by", 3.5)],
    "status_report": [(r"status report|exec(utive)? summary|weekly status|this week'?s status|steering|leadership (update|summary)|weekly update", 5)],
    "prn_status": [(r"\bprn\b|funding|funded|budget|\bburn|hours (are )?(left|remaining)|run(s)? out|overrun", 4)],
    "crq_sto_readiness": [(r"\bsto\b|go ?/ ?no[- ]?go|go[- ]no[- ]go", 3.5), (r"not ready|ready for", 1.5)],
    "prn_overrun": [(r"(prns?|budgets?|funding).*(overrun|over budget|exceed|run(ning)? out|over (their )?fund)", 4.5),
                    (r"(overrun|over budget|exceed).*(prns?|budgets?|funding)", 4.5)],
    "what_if_slip": [(r"what (happens|if)|what would happen", 2.5), (r"\bslip|\bdelay|push(ed)? (out|back)|late by", 3)],
}
MIN_SCORE = 2.5
NEEDS_INITIATIVE = {"summarize_initiative", "milestone_dates"}
EXAMPLES = ["Which initiatives are at risk for the Feb release and why?", "Who is over-allocated in November?",
            "Who has CIAM capacity in January?", "Draft this week's exec summary"]


# ------------------------------------------------------------------ helpers
def _route_init(iid: int, tab: str = "pg1") -> str:
    return f"#/initiative/{iid}/{tab}"


def cite(type_: str, id_: Any, label: str, route: str) -> dict:
    return {"type": type_, "id": id_, "label": G.clip(label, 200) or str(id_), "route": route}


def _today(ctx: dict | None = None) -> date:
    return C.to_date((ctx or {}).get("today") or C.get_today())


def _month_key(d: date) -> str:
    return d.strftime("%Y-%m")


def _add_months(month: str, n: int) -> str:
    y, m = (int(x) for x in month.split("-"))
    m += n
    while m > 12:
        m -= 12
        y += 1
    while m < 1:
        m += 12
        y -= 1
    return f"{y:04d}-{m:02d}"


def fiscal_quarter_months(q: str, today: date, next_q: bool = False) -> list[str]:
    start_month = QUARTER_START[q]
    y = today.year
    if start_month == 11 and today.month < 11:
        y -= 1
    first = f"{y:04d}-{start_month:02d}"
    if _add_months(first, 2) < _month_key(today):
        first = _add_months(first, 12)
    return [first, _add_months(first, 1), _add_months(first, 2)]


def current_fiscal_quarter(today: date) -> str:
    return {11: "Q1", 12: "Q1", 1: "Q1", 2: "Q2", 3: "Q2", 4: "Q2", 5: "Q3", 6: "Q3", 7: "Q3"}.get(today.month, "Q4")


def initiatives_all() -> list[dict]:
    return C.portfolio_rows()


def init_by_id(iid: int) -> dict | None:
    return next((r for r in initiatives_all() if r["id"] == iid), None)


def health_of(row: dict) -> dict:
    h = row.get("health_cached_json")
    return h if isinstance(h, dict) else {}


def rag_of(row: dict) -> str:
    return row.get("rag") if row.get("rag") in ("Red", "Amber", "Green") else "Not scored"


def top_reason(row: dict) -> str:
    h = health_of(row)
    if h.get("attention"):
        return h["attention"][0]
    for v in (h.get("dimensions") or {}).values():
        if isinstance(v, dict) and v.get("rag") in ("Red", "Amber") and v.get("reasons"):
            return v["reasons"][0]
    return ""


def people() -> list[dict]:
    return db.query("SELECT id, name, role, team, team_label, capacity_eligible FROM resources WHERE active = 1 ORDER BY id")


def skills_catalog() -> list[str]:
    names = {r["name"] for r in db.query("SELECT name FROM skills")}
    for lst in G.COMPONENT_SKILLS.values():
        names.update(lst)
    return sorted(names)


def train_dates() -> dict[str, str]:
    return {t["code"]: t["train_date"] for t in C.release_trains()}


# ------------------------------------------------------------------ entity extraction
def extract_entities(message: str, ctx: dict) -> dict:
    text = message or ""
    low = text.lower()
    today = _today(ctx)
    ents: dict[str, Any] = {"initiatives": [], "ambiguous": [], "resources": [], "components": [], "teams": [], "months": [],
                            "rag": [], "stages": [], "skills": [], "crqs": [], "trains": [], "wbs": [], "at_risk": False,
                            "group_by": None, "quarter": None}
    rows = initiatives_all()
    by_rddc = {r["rddc"]: r for r in rows}
    for m in re.finditer(r"\bRDDC[-\s]?(\d{5})\b|\b(2\d{4})\b", text, re.IGNORECASE):
        code = f"RDDC-{m.group(1) or m.group(2)}"
        if code in by_rddc and by_rddc[code] not in ents["initiatives"]:
            ents["initiatives"].append(by_rddc[code])
    if not ents["initiatives"]:
        scored = []
        msg_tokens = {w for w in re.findall(r"[a-z0-9&]+", low) if w not in STOP and len(w) > 2}
        for r in rows:
            name = r["name"].lower()
            if name in low:
                scored.append((1.0, r))
                continue
            name_tokens = {w for w in re.findall(r"[a-z0-9&]+", name) if w not in STOP and len(w) > 2}
            if not name_tokens:
                continue
            overlap = len(name_tokens & msg_tokens) / len(name_tokens)
            ratio = max((difflib.SequenceMatcher(None, name, low[i:i + len(name)]).ratio()
                         for i in range(0, max(len(low) - len(name), 0) + 1, 3)), default=0.0)
            score = max(overlap if len(name_tokens & msg_tokens) >= 2 else 0.0, ratio if ratio >= 0.8 else 0.0)
            if score >= 0.6:
                scored.append((score, r))
        scored.sort(key=lambda x: (-x[0], x[1]["rddc"]))
        if scored:
            best = scored[0][0]
            tied = [r for s, r in scored if best - s < 0.05]
            if len(tied) > 1 and best < 1.0:
                ents["ambiguous"] = tied[:3]
            else:
                ents["initiatives"].append(scored[0][1])
    page_iid = ctx.get("initiative_id")
    if not ents["initiatives"] and page_iid and re.search(r"\b(this|our|the current) (initiative|project|one|plan|intake)\b|\bits?\b", low):
        row = next((r for r in rows if r["id"] == int(page_iid)), None)
        if row:
            ents["initiatives"].append(row)
            ents["from_page"] = True
    ents["crqs"] = sorted({m.upper() for m in re.findall(r"\bCRQ\d{6,}\b", text, re.IGNORECASE)})
    ents["prns"] = sorted({m.upper() for m in re.findall(r"\bPRN-?\d{5}\b", text, re.IGNORECASE)})
    ents["prns"] = [p if "-" in p else p[:3] + "-" + p[3:] for p in ents["prns"]]
    ents["trains"] = sorted({m.upper() for m in re.findall(r"\bDC-\d{4}\b", text, re.IGNORECASE)})
    ents["wbs"] = sorted({m.upper() for m in re.findall(r"\bWBS[-\s]?\d{3}\b", text, re.IGNORECASE)})
    ents["wbs"] = [w.replace(" ", "-") if "-" in w else w[:3] + "-" + w[-3:] for w in ents["wbs"]]
    for p in people():
        full = p["name"].lower()
        first, last = full.split(" ")[0], full.split(" ")[-1]
        hit = full in low or re.search(rf"\b{re.escape(first)}\b", low) or re.search(rf"\b{re.escape(last)}\b", low)
        if hit and p not in ents["resources"]:
            ents["resources"].append(p)
    for code, syns in COMPONENT_SYNONYMS.items():
        if any(re.search(rf"(?<![a-z]){re.escape(s)}(?![a-z])", low) for s in syns) or code.lower() in low.split():
            ents["components"].append(code)
    if re.search(r"\bmobile\b", low):
        ents["components"] += [c for c in ("MOB_IOS", "MOB_AND") if c not in ents["components"]]
    if "APIGW" in ents["components"] and "api gateway" in low and "APIP" in ents["components"] and "api platform" not in low:
        ents["components"].remove("APIP")
    for word, team in TEAM_WORDS.items():
        if re.search(rf"\b{re.escape(word)}\b", low) and team not in ents["teams"]:
            ents["teams"].append(team)
    for word, num in MONTH_WORDS.items():
        if re.search(rf"\b{word}\b", low) and not (word == "may" and re.search(r"\bmay (i|we|you)\b", low)):
            y = today.year if num >= today.month else today.year + 1
            key = f"{y:04d}-{num:02d}"
            if key not in ents["months"]:
                ents["months"].append(key)
    if "next month" in low:
        ents["months"].append(_add_months(_month_key(today), 1))
    if "this month" in low:
        ents["months"].append(_month_key(today))
    qm = re.search(r"\bq([1-4])\b", low)
    if qm:
        ents["quarter"] = f"Q{qm.group(1)}"
        ents["months"] += fiscal_quarter_months(ents["quarter"], today)
    elif "next quarter" in low:
        cur = current_fiscal_quarter(today)
        nxt = {"Q1": "Q2", "Q2": "Q3", "Q3": "Q4", "Q4": "Q1"}[cur]
        ents["quarter"] = nxt
        ents["months"] += fiscal_quarter_months(nxt, today)
    elif "this quarter" in low:
        ents["quarter"] = current_fiscal_quarter(today)
        ents["months"] += [m for m in fiscal_quarter_months(ents["quarter"], today)]
    ents["months"] = sorted(set(ents["months"]))
    for rag in ("Red", "Amber", "Green"):
        if re.search(rf"\b{rag.lower()}\b", low):
            ents["rag"].append(rag)
    ents["at_risk"] = bool(re.search(r"\bat risk\b|off track|in trouble", low))
    for st in STAGES:
        if re.search(rf"\b{st.lower()}\b", low) and st not in ("QA",):
            ents["stages"].append(st)
    for sk in skills_catalog():
        if len(sk) > 2 and re.search(rf"(?<![a-z0-9]){re.escape(sk.lower())}(?![a-z0-9])", low):
            ents["skills"].append(sk)
    for k, words in (("lob", r"\blob\b|line of business"), ("stage", r"\bstage"), ("rag", r"\brag\b|health|colou?r"),
                     ("dc_pm", r"\bpm\b|dc pm|project manager"), ("release", r"release|train")):
        if re.search(words, low):
            ents["group_by"] = ents["group_by"] or k
    return ents


def route_intent(message: str, ents: dict) -> tuple[str, float]:
    low = (message or "").lower()
    scores = {}
    for intent, pats in INTENT_PATTERNS.items():
        s = sum(w for p, w in pats if re.search(p, low))
        if not s:
            continue
        if intent in ("summarize_initiative", "milestone_dates", "explain_health", "blockers") and ents["initiatives"]:
            s += 1.0
        if intent in ("availability", "component_demand") and (ents["components"] or ents["teams"]):
            s += 0.5
        if intent == "resource_workload" and ents["resources"]:
            s += 1.5
        if intent == "skill_lookup" and ents["skills"]:
            s += 1.0
        if intent == "suggest_resource" and (ents["components"] or ents["skills"] or ents["wbs"]):
            s += 1.0
        if intent == "list_by_rag" and ents["initiatives"] and not re.search(r"\bwhich|list|show\b", low):
            s -= 1.5
        if intent == "upcoming_releases" and re.search(r"\bat risk\b", low):
            s -= 1.0
        if intent == "portfolio_stats" and not (ents["group_by"] or re.search(r"initiative|project|intake|rddc", low)):
            s -= 2.0
        if intent == "prn_status" and ents.get("prns"):
            s += 2.0
        if intent == "prn_status" and not ents.get("prns") and not ents["initiatives"] and re.search(r"\bprns\b|which prn", low):
            s -= 2.0
        if intent == "prn_overrun" and ents.get("prns"):
            s -= 3.0
        if intent == "crq_sto_readiness" and re.search(r"\bcrq|change request|release", low):
            s += 1.0
        if intent == "what_if_slip" and (ents["initiatives"] or ents["wbs"] or ents["components"]):
            s += 1.0
        scores[intent] = s
    if not scores:
        # a bare name or id ("RDDC-24601", "Lena") is a clear request; anything else is not understood
        if ents["initiatives"] and len(low.split()) <= 6:
            return "summarize_initiative", MIN_SCORE
        if ents["resources"] and len(low.split()) <= 6:
            return "resource_workload", MIN_SCORE
        return "help", 0.0
    order = list(ASSISTANT_INTENTS)
    best = max(scores, key=lambda k: (scores[k], -order.index(k)))
    if scores[best] < MIN_SCORE:
        return "help", scores[best]
    return best, scores[best]


# ------------------------------------------------------------------ handlers
def _result(intent, md, citations=None, table=None, actions=None, follow=None, sources=None, confidence=0.9, warnings=None):
    seen, cites = set(), []
    for c in citations or []:
        key = (c["type"], str(c["id"]))
        if key not in seen:
            seen.add(key)
            cites.append(c)
    if table:
        table = {"columns": [G.clip(c, 60) for c in table["columns"][:10]],
                 "rows": [[(G.clip(v, 200) if isinstance(v, str) else v) for v in row[:10]] for row in table["rows"][:50]]}
        if not table["rows"]:
            table = None
    return {"answer_md": G.clip(md, 6000) if len(md) > 6000 else md, "intent": intent, "citations": cites[:30],
            "table": table, "suggested_actions": (actions or [])[:4], "follow_ups": [G.clip(f, 200) for f in (follow or [])][:4],
            "confidence": round(confidence, 2), "sources": (sources or [])[:40], "warnings": warnings or []}


def _init_cite(r: dict, tab: str = "pg1") -> dict:
    return cite("initiative", r["rddc"], f"{r['rddc']} {r['name']}", _route_init(r["id"], tab))


def _month_filter(rows: list[dict], months: list[str], trains: list[str]) -> list[dict]:
    if not months and not trains:
        return rows
    tdates = train_dates()
    out = []
    for r in rows:
        train_month = (tdates.get(r.get("target_release") or "") or "")[:7]
        prod_month = (r.get("prod_date") or "")[:7]
        if (trains and r.get("target_release") in trains) or (months and (train_month in months or prod_month in months)):
            out.append(r)
    return out


def h_list_by_rag(msg, ents, ctx):
    rags = ents["rag"] or (["Red", "Amber"] if ents["at_risk"] else ["Red", "Amber", "Green", "Not scored"])
    rows = [r for r in initiatives_all() if r["stage"] != "Closed" and rag_of(r) in rags]
    scoped = _month_filter(rows, [m for m in ents["months"]] if re.search(r"release|train|prod|go[- ]live|due", msg.lower()) or ents["trains"] else [], ents["trains"])
    label = " or ".join(rags) if len(rags) < 4 else "active"
    when = ""
    if ents["trains"] or (ents["months"] and scoped is not rows):
        when = " for " + (", ".join(ents["trains"]) or ", ".join(G.fmt_month(m) for m in ents["months"]))
    rows = scoped
    if not rows:
        md = f"No active initiative is {label}{when}."
        return _result("list_by_rag", md, follow=["Which initiatives are Amber?", "Show the portfolio breakdown by stage"],
                       actions=[{"label": "Open Portfolio View", "route": "#/portfolio"}], confidence=0.85)
    lines = [f"**{len(rows)}** initiative{'s are' if len(rows) != 1 else ' is'} {label}{when}:"]
    table_rows = []
    for r in rows:
        why = top_reason(r)
        lines.append(f"- **{r['rddc']} {r['name']}** — {rag_of(r)}" + (f": {why}" if why else ""))
        table_rows.append([r["rddc"], r["name"], rag_of(r), r["stage"], r.get("target_release") or "", why])
    first = rows[0]
    return _result("list_by_rag", "\n".join(lines), [_init_cite(r, "pg3") for r in rows],
                   {"columns": ["RDDC #", "Initiative", "RAG", "Stage", "Target release", "Why"], "rows": table_rows},
                   [{"label": "Open Portfolio View", "route": "#/portfolio"}],
                   [f"What is blocking {first['rddc']}?", f"Why is {first['rddc']} {rag_of(first)}?", "Draft this week's exec summary"],
                   [G.src("initiative", r["rddc"], f"{r['rddc']} health") for r in rows])


def h_explain_health(msg, ents, ctx):
    if not ents["initiatives"]:
        dim = next((d for d in DIMENSIONS if re.search(rf"\b{d.removesuffix('s')}s?\b", msg.lower())), None)
        if dim:
            return _explain_dimension(dim, ents)
        ents = {**ents, "at_risk": True}
        res = h_list_by_rag(msg, ents, ctx)
        res["intent"] = "explain_health"
        return res
    r = ents["initiatives"][0]
    h = health_of(r)
    if not h.get("scored", bool(h)) or rag_of(r) == "Not scored":
        md = f"**{r['rddc']} {r['name']}** is in {r['stage']}. Health is scored from Planning onward, so it shows Not scored yet."
        return _result("explain_health", md, [_init_cite(r)], follow=[f"Summarise {r['rddc']}", f"What approvals are pending on {r['rddc']}?"])
    lines = [f"**{r['rddc']} {r['name']}** is **{rag_of(r)}** overall."]
    rows = []
    for dim, v in (h.get("dimensions") or {}).items():
        if not isinstance(v, dict):
            continue
        reason = "; ".join(v.get("reasons") or [])
        lines.append(f"- **{dim.capitalize()}**: {v.get('rag')}" + (f" — {reason}" if reason else "") + (" (manual override)" if v.get("overridden") else ""))
        rows.append([dim.capitalize(), v.get("rag") or "", reason])
    if h.get("attention"):
        lines.append(f"\nManagement attention: {'; '.join(h['attention'])}.")
    actions = [{"label": "Open Pg 3 Resource Management", "route": _route_init(r["id"], "pg3")}]
    cites = [_init_cite(r, "pg3")]
    res_dim = (h.get("dimensions") or {}).get("resources") or {}
    if res_dim.get("rag") == "Red":
        actions.append({"label": "Suggest fix", "api": f"/api/initiatives/{r['id']}/ai/rebalance", "method": "POST"})
        pid = (res_dim.get("metrics") or {}).get("peak_resource_id")
        person = next((p for p in people() if p["id"] == pid), None)
        if person:
            cites.append(cite("resource", person["id"], person["name"], "#/resources"))
        for code in (res_dim.get("metrics") or {}).get("wbs_codes") or []:
            cites.append(cite("wbs_task", f"{r['rddc']}/{code}", code, _route_init(r["id"], "pg2")))
    return _result("explain_health", "\n".join(lines), cites, {"columns": ["Dimension", "RAG", "Reason"], "rows": rows}, actions,
                   [f"What is blocking {r['rddc']}?", "Who has spare capacity next month?", f"When is the QA date for {r['rddc']}?"],
                   [G.src("engine", "health", f"{r['rddc']} health (calculated)")])


def month_span(months: list[str]) -> str:
    if len(months) > 2:
        return f"{G.fmt_month(months[0])} – {G.fmt_month(months[-1])}"
    return " and ".join(G.fmt_month(m) for m in months)


def h_release_train(msg, ents, ctx):
    code = ents["trains"][0]
    train = next((t for t in C.release_trains() if t["code"] == code), None)
    if train is None:
        return _result("upcoming_releases", f"{code} is not a release train in the calendar.",
                       follow=["What's going to production in the next 2 weeks?"], confidence=0.6)
    rows = [r for r in initiatives_all() if r.get("target_release") == code and r["stage"] != "Closed"]
    crs = db.query("""SELECT c.id, c.crq_number, c.sto_approval, c.crq_start, i.id AS iid, i.rddc FROM change_requests c
                       JOIN initiatives i ON i.id = c.initiative_id AND i.id > 0 WHERE c.release_train = ? ORDER BY c.crq_start""", (code,))
    when = f"{code} (Sat {G.fmt_date(train['train_date'])})"
    if not rows and not crs:
        return _result("upcoming_releases", f"No active initiative targets {when}.", follow=["Which initiatives are at risk?"],
                       actions=[{"label": "Open Change Management", "route": "#/changes"}])
    hours = {r["id"]: float(db.scalar("SELECT COALESCE(SUM(est_hours), 0) FROM wbs_tasks WHERE initiative_id = ?", (r["id"],)) or 0)
             or float(r.get("l2_hours") or 0) for r in rows}
    total = sum(hours.values())
    lines = [f"**{len(rows)}** initiative{'s are' if len(rows) != 1 else ' is'} on {when}, **{G.fmt_hours(total)}** planned in total:"]
    table, cites = [], []
    for r in rows:
        fl = C.initiative_float(r)
        crq = next((c for c in crs if c["rddc"] == r["rddc"]), None)
        planned = db.scalar("SELECT COUNT(*) FROM wbs_tasks WHERE initiative_id = ?", (r["id"],))
        bits = [rag_of(r), r["stage"], f"{G.fmt_hours(hours[r['id']])} {'planned' if planned else 'L2 estimate'}"]
        if r.get("readiness_date"):
            bits.append(f"Readiness {G.fmt_date(r['readiness_date'])}" + (f", {fl} business days of float" if fl is not None else ""))
        if crq:
            bits.append(f"{crq['crq_number'] or 'CRQ'} STO {crq['sto_approval'] or 'not set'}")
        lines.append(f"- **{r['rddc']} {r['name']}** — " + " · ".join(bits))
        table.append([r["rddc"], r["name"], rag_of(r), r["stage"], G.fmt_hours(hours[r["id"]]),
                      G.fmt_date(r.get("readiness_date")) if r.get("readiness_date") else "",
                      fl if fl is not None else "", (crq or {}).get("crq_number") or ""])
        cites.append(_init_cite(r, "pg2"))
    for c in crs:
        cites.append(cite("change_request", c["crq_number"] or c["id"], c["crq_number"] or "Change request", _route_init(c["iid"], "pg4")))
    return _result("upcoming_releases", "\n".join(lines), cites,
                   {"columns": ["RDDC #", "Initiative", "RAG", "Stage", "Hours", "Readiness", "Float (bd)", "CRQ"], "rows": table},
                   [{"label": "Open Change Management", "route": "#/changes"}],
                   [f"Which initiatives are at risk for {code}?", "Which CRQs are non-compliant this week?"],
                   [G.src("release_train", code, f"Release train {when}")])


def _explain_dimension(dim: str, ents: dict) -> dict:
    rags = ents["rag"] or ["Red", "Amber"]
    rows = []
    for r in initiatives_all():
        v = (health_of(r).get("dimensions") or {}).get(dim) or {}
        if r["stage"] != "Closed" and v.get("rag") in rags:
            rows.append((r, v))
    label = dim.capitalize()
    if not rows:
        return _result("explain_health", f"No active initiative has {label} {' or '.join(rags)}.",
                       follow=["Which initiatives are at risk?"], actions=[{"label": "Open Portfolio View", "route": "#/portfolio"}])
    lines = [f"{label} is {' or '.join(rags)} on {len(rows)} initiative{'s' if len(rows) != 1 else ''}:"]
    table = []
    for r, v in rows:
        reason = "; ".join(v.get("reasons") or [])
        lines.append(f"- **{r['rddc']} {r['name']}** — {v['rag']}" + (f": {reason}" if reason else ""))
        table.append([r["rddc"], r["name"], v["rag"], reason])
    actions = [{"label": "Open Portfolio View", "route": "#/portfolio"}]
    first = rows[0][0]
    if dim == "resources" and rows[0][1].get("rag") == "Red":
        actions.append({"label": "Suggest fix", "api": f"/api/initiatives/{first['id']}/ai/rebalance", "method": "POST"})
    return _result("explain_health", "\n".join(lines), [_init_cite(r, "pg3") for r, _ in rows],
                   {"columns": ["RDDC #", "Initiative", label, "Reason"], "rows": table}, actions,
                   [f"What is blocking {first['rddc']}?", "Who has spare capacity next month?"],
                   [G.src("engine", "health", f"{r['rddc']} {label.lower()} health") for r, _ in rows])


def util_rows(months: list[str]) -> list[dict]:
    util = C.utilisation(months)
    names = {p["id"]: p for p in people()}
    out = []
    for rid, row in util.items():
        for m, c in row.items():
            if m in months:
                out.append({"resource_id": rid, "name": names[rid]["name"], "team": names[rid]["team"], "month": m, **c})
    return out


def contributions(rid: int, month: str) -> list[dict]:
    return db.query("""SELECT i.id, i.rddc, i.name, SUM(a.hours) AS hours FROM allocations a JOIN initiatives i ON i.id = a.initiative_id AND i.id > 0
                        WHERE a.resource_id = ? AND a.month = ? GROUP BY i.id ORDER BY hours DESC, i.rddc""", (rid, month))


def h_overallocated(msg, ents, ctx):
    today = _today(ctx)
    months = ents["months"] or [_add_months(_month_key(today), i) for i in range(6)]
    over = [u for u in util_rows(months) if u["util"] > 1.0]
    if ents["teams"]:
        over = [u for u in over if u["team"] in ents["teams"]]
    scope = ""
    if ents["initiatives"]:
        target = ents["initiatives"][0]
        held = {(a["resource_id"], a["month"]) for a in db.query(
            "SELECT DISTINCT resource_id, month FROM allocations WHERE initiative_id = ?", (target["id"],))}
        over = [u for u in over if (u["resource_id"], u["month"]) in held]
        scope = f" on {target['rddc']} {target['name']}"
    over.sort(key=lambda u: (-u["util"], u["month"], u["name"]))
    when = month_span(months) + scope
    if not over:
        return _result("overallocated_resources", f"No one is over-allocated in {when}.",
                       follow=["Who has spare capacity next month?", "Show the capacity by team"],
                       actions=[{"label": "Open Resources", "route": "#/resources"}])
    lines = [f"**{len({u['resource_id'] for u in over})}** {'people are' if len({u['resource_id'] for u in over}) != 1 else 'person is'} over-allocated in {when}:"]
    rows, cites = [], []
    for u in over[:12]:
        contrib = contributions(u["resource_id"], u["month"])
        parts = ", ".join(f"{c['rddc']} {c['hours']:.1f} h" for c in contrib[:4])
        lines.append(f"- **{u['name']}** at **{G.rint(u['util'] * 100)}%** in {G.fmt_month(u['month'])} "
                     f"({u['allocated']:.1f} h of {u['available']:.0f} h)" + (f": {parts}" if parts else ""))
        rows.append([u["name"], u["team"] or "", G.fmt_month(u["month"]), f"{G.rint(u['util'] * 100)}%", f"{u['allocated']:.1f} h", f"{u['available']:.0f} h"])
        cites.append(cite("resource", u["resource_id"], u["name"], "#/resources"))
        for c in contrib[:2]:
            cites.append(cite("initiative", c["rddc"], f"{c['rddc']} {c['name']}", _route_init(c["id"], "pg3")))
    seen_people: set[int] = set()
    for u in over:
        if u["resource_id"] in seen_people or len(seen_people) >= 3:
            continue
        seen_people.add(u["resource_id"])
        lines.append(_rebalance_suggestion(u))
    return _result("overallocated_resources", "\n".join(lines), cites,
                   {"columns": ["Person", "Team", "Month", "Utilisation", "Allocated", "Available"], "rows": rows},
                   [{"label": "Open Resources", "route": "#/resources"}],
                   [f"What is {over[0]['name'].split(' ')[0]} working on?", "Who has spare capacity next month?"],
                   [G.src("allocation", f"{u['resource_id']}:{u['month']}", f"{u['name']} · {G.fmt_month(u['month'])}") for u in over[:10]])


def _rebalance_suggestion(u: dict) -> str:
    """One Suggest fix line for an over-allocated person-month, from the rebalance generator on their biggest initiative."""
    first = u["name"].split(" ")[0]
    for c in contributions(u["resource_id"], u["month"]):
        ctx = C.build_context("rebalance", c["id"], {"resource_id": u["resource_id"]})
        out = G.generate("rebalance", ctx)
        if out["problem"]["resource_id"] != u["resource_id"] or not out["options"]:
            continue
        o = out["options"][out["recommended_option_index"] or 0]
        to_first = o["to_resource_name"].split(" ")[0]
        return (f"Suggested for {first}: move {o['task_wbs_code']} on {c['rddc']} to {o['to_resource_name']} — "
                f"{first} {G.fmt_month(o['month'])} {o['before']['from_pct']}% → {o['after']['from_pct']}%, "
                f"{to_first} {o['after']['to_pct']}%.")
    return (f"No one in {first}'s team can take a whole step in {G.fmt_month(u['month'])} without going over 100%; "
            "consider moving dates or reducing allocation %.")


def _next_milestone(iid: int, today: str) -> dict | None:
    return db.query_one("""SELECT wbs_code, step, planned_end FROM wbs_tasks WHERE initiative_id = ? AND planned_end >= ?
                            AND status != 'Completed' AND est_hours > 0 ORDER BY planned_end, sort LIMIT 1""", (iid, today))


def h_summarize(msg, ents, ctx):
    r = ents["initiatives"][0]
    today = _today(ctx).isoformat()
    comps = r.get("components") or []
    risk = db.query_one("SELECT id, risk_code, title, severity, likelihood, score FROM risks WHERE initiative_id = ? AND status != 'Closed' "
                        "ORDER BY score DESC, id LIMIT 1", (r["id"],))
    nxt = _next_milestone(r["id"], today)
    lines = [f"**{r['rddc']} {r['name']}** ({r.get('lob') or 'no LOB'}) is in **{r['stage']}**, health **{rag_of(r)}**."]
    lines.append(f"- DC PM {r.get('dc_pm_name') or 'not assigned'} · DC SA {r.get('dc_sa_name') or 'not assigned'}")
    if r.get("target_release"):
        lines.append(f"- Target release {r['target_release']}" + (f"; production {G.fmt_date(r['prod_date'])}" if r.get("prod_date") else ""))
    if r.get("readiness_date"):
        lines.append(f"- Readiness {G.fmt_date(r['readiness_date'])} · QA Date {G.fmt_date(r.get('qa_date'))}")
    if r.get("l2_hours"):
        lines.append(f"- L2 {G.fmt_hours(r['l2_hours'])} ({r.get('l2_status') or 'Draft'})")
    if comps:
        lines.append(f"- Components: {', '.join(COMPONENT_NAMES.get(c, c) for c in comps)}")
    if nxt:
        lines.append(f"- Next milestone: {nxt['wbs_code']} {nxt['step']} ends {G.fmt_date(nxt['planned_end'])}")
    if top_reason(r):
        lines.append(f"- Attention: {top_reason(r)}")
    cites = [_init_cite(r)]
    if risk:
        lines.append(f"- Top risk: {risk['risk_code'] or ''} {risk['title']} (score {risk['score']})".replace("  ", " "))
        cites.append(cite("risk", risk["risk_code"] or risk["id"], f"{risk['risk_code'] or 'Risk'} {risk['title']}", _route_init(r["id"], "risks")))
    if nxt:
        cites.append(cite("wbs_task", f"{r['rddc']}/{nxt['wbs_code']}", f"{nxt['wbs_code']} {nxt['step']}", _route_init(r["id"], "pg2")))
    return _result("summarize_initiative", "\n".join(lines), cites, None,
                   [{"label": f"Open {r['rddc']}", "route": _route_init(r["id"])}],
                   [f"What is blocking {r['rddc']}?", f"Why is {r['rddc']} {rag_of(r)}?" if rag_of(r) != "Not scored" else f"What approvals are pending on {r['rddc']}?"],
                   [G.src("initiative", r["rddc"], f"{r['rddc']} record")])


def _blockers_for(r: dict, today: str) -> list[tuple[str, dict]]:
    items = []
    for t in db.query("""SELECT wbs_code, step, planned_end, pct, status FROM wbs_tasks WHERE initiative_id = ?
                          AND ((planned_end < ? AND pct < 100 AND status != 'Completed') OR status = 'Blocked') ORDER BY planned_end""",
                      (r["id"], today)):
        why = "blocked" if t["status"] == "Blocked" else f"overdue since {G.fmt_date(t['planned_end'])} at {t['pct']}%"
        items.append((f"{t['wbs_code']} {t['step']} — {why}", cite("wbs_task", f"{r['rddc']}/{t['wbs_code']}", t["wbs_code"], _route_init(r["id"], "pg2"))))
    for c in db.query("""SELECT c.name, ic.approval, rr.name AS lead FROM initiative_components ic JOIN dc_components c ON c.id = ic.component_id
                          LEFT JOIN resources rr ON rr.id = COALESCE(ic.component_lead_id, c.component_lead_id)
                          WHERE ic.initiative_id = ? AND ic.approval IN ('Pending', 'Rejected')""", (r["id"],)):
        items.append((f"{c['name']} approval {c['approval'].lower()}" + (f" ({c['lead']})" if c["lead"] else ""), _init_cite(r)))
    if r.get("l2_status") == "Pending approval":
        items.append((f"L2 estimate waiting for approval by {r.get('requestor_name') or r.get('requestor') or 'the requestor'}", _init_cite(r)))
    for k in db.query("SELECT id, risk_code, title, score FROM risks WHERE initiative_id = ? AND status != 'Closed' AND score >= 9 ORDER BY score DESC",
                      (r["id"],)):
        items.append((f"Risk {k['risk_code'] or ''} {k['title']} (score {k['score']})".replace("  ", " "),
                      cite("risk", k["risk_code"] or k["id"], k["risk_code"] or k["title"], _route_init(r["id"], "risks"))))
    for cr in db.query("SELECT id, crq_number, compliance_json, sto_approval FROM change_requests WHERE initiative_id = ?", (r["id"],)):
        flags = (db.from_json(cr["compliance_json"], {}) or {}).get("flags") or []
        for f in flags[:2]:
            items.append((f"{cr['crq_number'] or 'CRQ'}: {f.get('message')}", cite("change_request", cr["crq_number"] or cr["id"],
                                                                                  cr["crq_number"] or "Change request", _route_init(r["id"], "pg4"))))
        if cr["sto_approval"] in ("Tentative No Go", "No-Go"):
            items.append((f"{cr['crq_number'] or 'CRQ'}: STO approval {cr['sto_approval']}", cite("change_request", cr["crq_number"] or cr["id"],
                                                                                              cr["crq_number"] or "Change request", _route_init(r["id"], "pg4"))))
    return items


def h_blockers(msg, ents, ctx):
    today = _today(ctx).isoformat()
    targets = ents["initiatives"] or [r for r in initiatives_all() if r["stage"] != "Closed" and rag_of(r) in ("Red", "Amber")]
    lines, cites, rows = [], [], []
    for r in targets[:6]:
        items = _blockers_for(r, today)
        if not items:
            if ents["initiatives"]:
                lines.append(f"Nothing is blocking **{r['rddc']} {r['name']}**: no overdue or blocked steps, pending approvals, high risks or CRQ flags.")
                cites.append(_init_cite(r))
            continue
        lines.append(f"**{r['rddc']} {r['name']}** ({rag_of(r)}):")
        cites.append(_init_cite(r))
        for text, c in items[:6]:
            lines.append(f"- {text}")
            cites.append(c)
            rows.append([r["rddc"], text])
    if not lines:
        lines = ["No overdue or blocked steps, pending approvals or high risks on the Red and Amber initiatives."]
    first = targets[0] if targets else None
    return _result("blockers", "\n".join(lines), cites, {"columns": ["RDDC #", "Blocker"], "rows": rows} if len(targets) > 1 else None,
                   [{"label": f"Open {first['rddc']}", "route": _route_init(first["id"], "pg2")}] if first else [],
                   ["What approvals are pending?", "Top risks across the portfolio"],
                   [G.src("initiative", r["rddc"], f"{r['rddc']} plan, approvals and risks") for r in targets[:6]])


def _pseudo_bundle(months: list[str]) -> dict:
    util = C.utilisation(months)
    avail = {}
    for a in db.query("SELECT resource_id, month, available_hours FROM resource_availability"):
        avail.setdefault(a["resource_id"], {})[a["month"]] = a["available_hours"]
    skills = C.resource_skills_map()
    res = []
    for p in C.resource_rows():
        res.append({"id": p["id"], "name": p["name"], "role": p["role"], "team": p["team"], "capacity_eligible": 1,
                    "default_monthly_hours": p["default_monthly_hours"], "availability": avail.get(p["id"], {}),
                    "committed": {m: c["allocated"] for m, c in util.get(p["id"], {}).items()},
                    "skills": [{"skill": s["skill"], "level": s["level"]} for s in skills.get(p["id"], [])]})
    return {"resources": res, "allocations": [], "initiative": {}, "components": [], "component_catalog": C.component_catalog()}


def h_suggest_resource(msg, ents, ctx):
    today = _today(ctx)
    start = C.next_business_day(today).isoformat()
    end = C.add_business_days(start, 40).isoformat()
    hours = 80.0
    required: list[str] = list(ents["skills"])
    team = None
    label = ", ".join(ents["skills"])
    if ents["wbs"] and ents["initiatives"]:
        r = ents["initiatives"][0]
        t = db.query_one("""SELECT t.*, c.code AS component_code FROM wbs_tasks t LEFT JOIN initiative_components ic ON ic.id = t.initiative_component_id
                             LEFT JOIN dc_components c ON c.id = ic.component_id WHERE t.initiative_id = ? AND t.wbs_code = ?""",
                         (r["id"], ents["wbs"][0]))
        if t:
            bundle = C.load_bundle(r["id"])
            required, team = G.wbs_requirements(t, bundle)
            start, end, hours = t["planned_start"] or start, t["planned_end"] or end, float(t["est_hours"] or hours)
            label = f"{r['rddc']} {t['wbs_code']} {t['step']}"
    if ents["components"] and not required:
        code = ents["components"][0]
        required = G.COMPONENT_SKILLS.get(code, [])
        team = TEAM_BY_COMPONENT.get(code)
        label = f"{COMPONENT_NAMES[code]} work"
    if ents["months"]:
        start = max(ents["months"][0] + "-01", start)
        last = ents["months"][-1]
        end = (C.to_date(_add_months(last, 1) + "-01") - timedelta(days=1)).isoformat()
    if not required and not team:
        return _result("suggest_resource", "Tell me the component, skill or WBS step, for example \"Suggest a developer for CIAM work\".",
                       follow=["Suggest a developer for CIAM work", "Who knows Kafka?"], confidence=0.5)
    months = sorted(C.spread_hours(start, end, 1.0))
    pctx = {"bundle": _pseudo_bundle(months), "data": {"task_history": C._task_history()}, "initiative_id": None}
    cands = G.score_candidates(pctx, required=required, team=team, start=start, end=end, hours=hours, exclude={},
                               component_code=ents["components"][0] if ents["components"] else None, phase="Development",
                               continuity_ids=set(), limit=3)
    if not cands:
        return _result("suggest_resource", f"No capacity-tracked person matches {label}.", follow=["Who has spare capacity next month?"], confidence=0.6)
    lines = [f"Best fit for **{label}** ({G.fmt_date(start)} – {G.fmt_date(end)}, about {G.fmt_hours(hours)}):"]
    rows = []
    for c in cands:
        lines.append(f"{c['rank']}. **{c['resource_name']}** ({c['team']}) — fit {G.rint(c['fit_score'])}%, skills {G.rint(c['skill_match_pct'])}%, "
                     f"{G.fmt_hours(c['free_hours'])} free" + (f"; {c['concerns'][0]}" if c["concerns"] else ""))
        rows.append([c["rank"], c["resource_name"], c["team"], f"{G.rint(c['fit_score'])}%", ", ".join(c["matched_skills"]), G.fmt_hours(c["free_hours"])])
    return _result("suggest_resource", "\n".join(lines), [cite("resource", c["resource_id"], c["resource_name"], "#/resources") for c in cands],
                   {"columns": ["Rank", "Person", "Team", "Fit", "Matched skills", "Free hours"], "rows": rows},
                   [{"label": "Open Resources", "route": "#/resources"}],
                   [f"What is {cands[0]['resource_name'].split(' ')[0]} working on?", "Who is over-allocated next month?"],
                   [G.src("resource", c["resource_id"], f"{c['resource_name']} · skills and availability") for c in cands], 0.85)


def h_availability(msg, ents, ctx):
    today = _today(ctx)
    months = ents["months"] or [_add_months(_month_key(today), 1)]
    rows_u = util_rows(months)
    teams = list(ents["teams"]) + [TEAM_BY_COMPONENT[c] for c in ents["components"] if c in TEAM_BY_COMPONENT]
    teams = [t for i, t in enumerate(teams) if t not in teams[:i]]
    if teams:
        rows_u = [u for u in rows_u if u["team"] in teams]
    agg: dict[int, dict] = {}
    for u in rows_u:
        a = agg.setdefault(u["resource_id"], {"name": u["name"], "team": u["team"], "available": 0.0, "allocated": 0.0})
        a["available"] += u["available"]
        a["allocated"] += u["allocated"]
    ranked = sorted(agg.items(), key=lambda kv: (-(kv[1]["available"] - kv[1]["allocated"]), kv[1]["name"]))
    ranked = [(rid, a) for rid, a in ranked if a["available"] - a["allocated"] > 0]
    when = month_span(months)
    scope = f"{' / '.join(teams)} " if teams else ""
    if not ranked:
        return _result("availability", f"No {scope}capacity is free in {when}; everyone is at or above 100%.",
                       follow=["Who is over-allocated next month?"], actions=[{"label": "Open Resources", "route": "#/resources"}])
    lines = [f"Spare {scope}capacity in {when}:"]
    rows = []
    for rid, a in ranked[:6]:
        free = a["available"] - a["allocated"]
        pct = G.rint(a["allocated"] / a["available"] * 100) if a["available"] else 0
        lines.append(f"- **{a['name']}** ({a['team']}): {G.fmt_hours(free)} free ({pct}% booked)")
        rows.append([a["name"], a["team"] or "", G.fmt_hours(free), f"{pct}%"])
    top = ranked[0][1]
    return _result("availability", "\n".join(lines), [cite("resource", rid, a["name"], "#/resources") for rid, a in ranked[:6]],
                   {"columns": ["Person", "Team", "Free hours", "Booked"], "rows": rows},
                   [{"label": "Open Resources", "route": "#/resources"}],
                   [f"What is {top['name'].split(' ')[0]} working on?", "Who is over-allocated next month?"],
                   [G.src("availability", rid, f"{a['name']} · {when}") for rid, a in ranked[:6]])


def h_workload(msg, ents, ctx):
    if not ents["resources"]:
        return h_help(msg, ents, ctx)
    p = ents["resources"][0]
    today = _today(ctx).isoformat()
    tasks = db.query("""SELECT t.wbs_code, t.step, t.planned_start, t.planned_end, t.est_hours, t.status, i.id AS iid, i.rddc, i.name
                          FROM wbs_tasks t JOIN initiatives i ON i.id = t.initiative_id AND i.id > 0
                         WHERE t.resource_id = ? AND (t.planned_end IS NULL OR t.planned_end >= ?) AND t.status != 'Completed'
                         ORDER BY t.planned_start, i.rddc""", (p["id"], today))
    months = [_add_months(today[:7], i) for i in range(4)]
    util = C.utilisation(months).get(p["id"], {})
    lines = [f"**{p['name']}** ({p['role']}) has {len(tasks)} open WBS step{'s' if len(tasks) != 1 else ''}:"]
    rows, cites = [], [cite("resource", p["id"], p["name"], "#/resources")]
    for t in tasks[:10]:
        lines.append(f"- {t['rddc']} {t['wbs_code']} {t['step']} ({G.fmt_date(t['planned_start'])} – {G.fmt_date(t['planned_end'])}, {G.fmt_hours(t['est_hours'])})")
        rows.append([t["rddc"], t["wbs_code"], t["step"], G.fmt_date(t["planned_start"]), G.fmt_date(t["planned_end"]), G.fmt_hours(t["est_hours"])])
        cites.append(cite("wbs_task", f"{t['rddc']}/{t['wbs_code']}", f"{t['rddc']} {t['wbs_code']}", _route_init(t["iid"], "pg2")))
    if util:
        lines.append("Utilisation: " + " · ".join(f"{G.fmt_month(m)} {G.rint(c['util'] * 100)}%" for m, c in sorted(util.items())))
    if not tasks:
        lines[0] = f"**{p['name']}** has no open WBS steps assigned."
    return _result("resource_workload", "\n".join(lines), cites,
                   {"columns": ["RDDC #", "WBS", "Step", "Start", "End", "Hours"], "rows": rows},
                   [{"label": "Open Resources", "route": "#/resources"}],
                   [f"Who could take some of {p['name'].split(' ')[0]}'s work?", "Who is over-allocated next month?"],
                   [G.src("resource", p["id"], f"{p['name']} assignments")])


def h_upcoming_releases(msg, ents, ctx):
    today = _today(ctx)
    if ents["months"]:
        start = ents["months"][0] + "-01"
        end = (C.to_date(_add_months(ents["months"][-1], 1) + "-01") - timedelta(days=1)).isoformat()
    else:
        start, end = today.isoformat(), (today + timedelta(days=14)).isoformat()
    crs = db.query("""SELECT c.*, i.id AS iid, i.rddc, i.name FROM change_requests c JOIN initiatives i ON i.id = c.initiative_id AND i.id > 0
                       WHERE substr(c.crq_start, 1, 10) BETWEEN ? AND ? ORDER BY c.crq_start""", (start, end))
    prods = db.query("""SELECT id, rddc, name, prod_date, target_release, rag_cached FROM initiatives
                         WHERE prod_date BETWEEN ? AND ? AND stage != 'Closed' AND id > 0 ORDER BY prod_date""", (start, end))
    with_cr = {c["rddc"] for c in crs}
    window = f"{G.fmt_date(start)} – {G.fmt_date(end)}"
    lines, rows, cites = [], [], []
    for c in crs:
        lines.append(f"- **{c['rddc']} {c['name']}** · {c['crq_number'] or 'CRQ'} · {G.fmt_date(str(c['crq_start'])[:10])} · "
                     f"{c['release_train'] or c['release_type'] or ''} · STO {c['sto_approval'] or 'not set'}")
        rows.append([c["rddc"], c["crq_number"] or "", G.fmt_date(str(c["crq_start"])[:10]), c["release_train"] or "", c["sto_approval"] or ""])
        cites.append(cite("change_request", c["crq_number"] or c["id"], c["crq_number"] or "Change request", _route_init(c["iid"], "pg4")))
        cites.append(cite("initiative", c["rddc"], f"{c['rddc']} {c['name']}", _route_init(c["iid"], "pg4")))
    for p in prods:
        if p["rddc"] not in with_cr:
            lines.append(f"- **{p['rddc']} {p['name']}** · production {G.fmt_date(p['prod_date'])} on {p['target_release'] or 'release train'} · no CRQ yet")
            rows.append([p["rddc"], "", G.fmt_date(p["prod_date"]), p["target_release"] or "", ""])
            cites.append(cite("initiative", p["rddc"], f"{p['rddc']} {p['name']}", _route_init(p["id"], "pg4")))
    if not lines:
        nxt = next((t for t in C.release_trains() if t["train_date"] > end and (t.get("status") or "Planned") != "Done"), None)
        md = f"Nothing is scheduled for production between {window}."
        if nxt:
            md += f" The next release train is {nxt['code']} on {G.fmt_date(nxt['train_date'])}."
        return _result("upcoming_releases", md, follow=["Which CRQs are non-compliant?"], actions=[{"label": "Open Change Management", "route": "#/changes"}])
    head = f"**{len(rows)}** change{'s' if len(rows) != 1 else ''} going to production {window}:"
    return _result("upcoming_releases", "\n".join([head] + lines), cites,
                   {"columns": ["RDDC #", "CRQ", "Date", "Train", "STO approval"], "rows": rows},
                   [{"label": "Open Change Management", "route": "#/changes"}],
                   ["Which CRQs are non-compliant?", "What approvals are pending?"],
                   [G.src("change_request", c["crq_number"] or c["id"], c["crq_number"] or "CRQ") for c in crs])


def _cr_flags(cr: dict) -> list[dict]:
    """Live compliance flags (same source as Pg 4); the cached JSON only when no engine is installed."""
    comp = C.check_cr(C.parse_row(cr))
    if not isinstance(comp, dict):
        cached = cr.get("compliance_json")
        comp = db.from_json(cached, None) if isinstance(cached, str) else cached
    return (comp or {}).get("flags") or []


def h_cr_noncompliance(msg, ents, ctx):
    today = _today(ctx)
    since = (today - timedelta(days=7)).isoformat()
    crs = db.query("""SELECT c.*, i.id AS iid, i.rddc, i.name FROM change_requests c JOIN initiatives i ON i.id = c.initiative_id AND i.id > 0
                       WHERE c.crq_start IS NULL OR substr(c.crq_start, 1, 10) >= ? ORDER BY c.crq_start""", (since,))
    if ents["initiatives"]:
        crs = [c for c in crs if c["iid"] in {r["id"] for r in ents["initiatives"]}]
    if ents["crqs"]:
        crs = [c for c in crs if (c["crq_number"] or "") in ents["crqs"]] or crs
    bad = [(c, _cr_flags(c)) for c in crs]
    bad = [(c, f) for c, f in bad if f]
    if not bad:
        return _result("cr_noncompliance", f"All {len(crs)} upcoming CRQ{'s are' if len(crs) != 1 else ' is'} compliant.",
                       follow=["What's going to production in the next 2 weeks?"], actions=[{"label": "Open Change Management", "route": "#/changes"}])
    lines = [f"**{len(bad)}** of {len(crs)} upcoming CRQs {'are' if len(bad) != 1 else 'is'} non-compliant:"]
    rows, cites = [], []
    for c, flags in bad:
        lines.append(f"- **{c['crq_number'] or 'CRQ'}** ({c['rddc']} {c['name']}, {G.fmt_date(str(c['crq_start'] or '')[:10]) if c['crq_start'] else 'no window'}): "
                     + "; ".join(f.get("message", "") for f in flags[:3]))
        rows.append([c["crq_number"] or "", c["rddc"], "; ".join(f.get("message", "") for f in flags[:3])])
        cites.append(cite("change_request", c["crq_number"] or c["id"], c["crq_number"] or "Change request", _route_init(c["iid"], "pg4")))
    return _result("cr_noncompliance", "\n".join(lines), cites, {"columns": ["CRQ", "RDDC #", "Flags"], "rows": rows},
                   [{"label": "Open Change Management", "route": "#/changes"}],
                   ["What's going to production in the next 2 weeks?", "What approvals are pending?"],
                   [G.src("rule", "compliance", "Change governance compliance rules")])


def h_top_risks(msg, ents, ctx):
    params: list[Any] = []
    sql = """SELECT k.*, i.id AS iid, i.rddc, i.name, t.wbs_code FROM risks k JOIN initiatives i ON i.id = k.initiative_id AND i.id > 0
              LEFT JOIN wbs_tasks t ON t.id = k.task_id WHERE k.status != 'Closed'"""
    if ents["initiatives"]:
        sql += f" AND k.initiative_id IN ({','.join('?' for _ in ents['initiatives'])})"
        params += [r["id"] for r in ents["initiatives"]]
    sql += " ORDER BY k.score DESC, k.severity DESC, k.id LIMIT 5"
    rows_db = db.query(sql, params)
    scope = f" on {ents['initiatives'][0]['rddc']}" if ents["initiatives"] else " across the portfolio"
    if not rows_db:
        return _result("top_risks", f"No open risks are logged{scope}.", follow=["Which initiatives are Red?"],
                       actions=[{"label": "Open Risk Register", "route": "#/risks"}])
    lines = [f"Top {len(rows_db)} open risk{'s' if len(rows_db) != 1 else ''}{scope}:"]
    rows, cites = [], []
    for k in rows_db:
        lines.append(f"- **{k['risk_code'] or 'Risk'} {k['title']}** ({k['rddc']}) — "
                     f"severity {k['severity']} × likelihood {k['likelihood']} = {k['score']}" + (f", {k['wbs_code']}" if k["wbs_code"] else ""))
        rows.append([k["risk_code"] or "", k["rddc"], k["title"], k["category"], k["score"], k["status"]])
        cites.append(cite("risk", k["risk_code"] or k["id"], f"{k['risk_code'] or 'Risk'} {k['title']}", _route_init(k["iid"], "risks")))
    return _result("top_risks", "\n".join(lines), cites,
                   {"columns": ["Risk", "RDDC #", "Title", "Category", "Score", "Status"], "rows": rows},
                   [{"label": "Open Risk Register", "route": "#/risks"}],
                   [f"What is blocking {rows_db[0]['rddc']}?", "Which initiatives are Red?"],
                   [G.src("risk", k["risk_code"] or k["id"], k["title"]) for k in rows_db])


def h_milestones(msg, ents, ctx):
    r = ents["initiatives"][0]
    if ents["wbs"]:
        t = db.query_one("SELECT wbs_code, step, planned_start, planned_end, baseline_end FROM wbs_tasks WHERE initiative_id = ? AND wbs_code = ?",
                         (r["id"], ents["wbs"][0]))
        if t:
            md = (f"**{r['rddc']} {t['wbs_code']} {t['step']}** runs {G.fmt_date(t['planned_start'])} – {G.fmt_date(t['planned_end'])}"
                  + (f" (baseline end {G.fmt_date(t['baseline_end'])})" if t["baseline_end"] else "") + ".")
            return _result("milestone_dates", md, [cite("wbs_task", f"{r['rddc']}/{t['wbs_code']}", t["wbs_code"], _route_init(r["id"], "pg2")), _init_cite(r, "pg2")],
                           follow=[f"Summarise {r['rddc']}"])
    if not r.get("readiness_date") and not r.get("prod_date"):
        md = f"**{r['rddc']} {r['name']}** has no plan yet, so no milestone dates. Generate the project plan on Pg 2."
        return _result("milestone_dates", md, [_init_cite(r, "pg2")], actions=[{"label": "Open Pg 2 Project Plan", "route": _route_init(r["id"], "pg2")}],
                       follow=[f"Summarise {r['rddc']}"])
    fl = C.initiative_float(r)
    rows = [["Plan start", G.fmt_date(r.get("planned_start"))], ["QA Date", G.fmt_date(r.get("qa_date"))],
            ["Readiness Date", G.fmt_date(r.get("readiness_date"))],
            ["Production", f"{G.fmt_date(r.get('prod_date'))}{' (' + r['target_release'] + ')' if r.get('target_release') else ''}"],
            ["Plan end", G.fmt_date(r.get("planned_end"))]]
    md = (f"**{r['rddc']} {r['name']}**: QA Date {G.fmt_date(r.get('qa_date'))}, Readiness {G.fmt_date(r.get('readiness_date'))}, "
          f"production {G.fmt_date(r.get('prod_date'))}" + (f" on {r['target_release']}" if r.get("target_release") else "")
          + (f" — {fl} business days of float." if fl is not None and fl >= 0 else
             f" — readiness misses the train by {-fl} business days." if fl is not None else "."))
    return _result("milestone_dates", md, [_init_cite(r, "pg2")], {"columns": ["Milestone", "Date"], "rows": rows},
                   [{"label": "Open Pg 2 Project Plan", "route": _route_init(r["id"], "pg2")}],
                   [f"What is blocking {r['rddc']}?", f"Why is {r['rddc']} {rag_of(r)}?" if rag_of(r) != "Not scored" else f"Summarise {r['rddc']}"],
                   [G.src("initiative", r["rddc"], f"{r['rddc']} plan dates")])


def h_component_demand(msg, ents, ctx):
    today = _today(ctx)
    months = ents["months"] or [_add_months(_month_key(today), i) for i in range(1, 4)]
    comps = ents["components"]
    teams = list(ents["teams"]) or sorted({TEAM_BY_COMPONENT[c] for c in comps if c in TEAM_BY_COMPONENT})
    if not teams:
        return _result("component_demand", "Name a component or team, for example \"How much EAPI demand next quarter?\".",
                       follow=["How much EAPI demand next quarter?"], confidence=0.5)
    ph = ",".join("?" for _ in months)
    lines, rows = [], []
    for team in teams:
        members = [p for p in C.resource_rows() if p["team"] == team]
        ids = [p["id"] for p in members]
        if not ids:
            continue
        idph = ",".join("?" for _ in ids)
        alloc = db.query(f"""SELECT firmness, SUM(hours) AS h FROM allocations WHERE month IN ({ph}) AND resource_id IN ({idph})
                              GROUP BY firmness""", [*months, *ids])
        conf = sum(a["h"] for a in alloc if a["firmness"] == "confirmed")
        tent = sum(a["h"] for a in alloc if a["firmness"] == "tentative")
        util = C.utilisation(months)
        avail = sum(c["available"] for rid in ids for m, c in util.get(rid, {}).items() if m in months)
        pct = G.rint((conf + tent) / avail * 100) if avail else 0
        lines.append(f"- **{team}**: {G.fmt_hours(conf)} confirmed + {G.fmt_hours(tent)} tentative against {G.fmt_hours(avail)} available ({pct}%)")
        rows.append([team, G.fmt_hours(conf), G.fmt_hours(tent), G.fmt_hours(avail), f"{pct}%"])
    if comps:
        cph = ",".join("?" for _ in comps)
        by_init = db.query(f"""SELECT i.id, i.rddc, i.name, SUM(t.est_hours) AS h FROM wbs_tasks t JOIN initiative_components ic ON ic.id = t.initiative_component_id
                               JOIN dc_components c ON c.id = ic.component_id JOIN initiatives i ON i.id = t.initiative_id AND i.id > 0
                              WHERE c.code IN ({cph}) AND i.stage != 'Closed' GROUP BY i.id ORDER BY h DESC""", comps)
    else:
        by_init = []
    when = ", ".join(G.fmt_month(m) for m in months)
    md = f"Demand in {when}:\n" + "\n".join(lines)
    if by_init:
        md += "\nPlanned " + "/".join(COMPONENT_NAMES[c] for c in comps) + " work: " + ", ".join(f"{b['rddc']} {G.fmt_hours(b['h'])}" for b in by_init[:5])
    return _result("component_demand", md, [cite("initiative", b["rddc"], f"{b['rddc']} {b['name']}", _route_init(b["id"], "pg2")) for b in by_init[:5]]
                   + [cite("page", "capacity", "Resources · capacity by team", "#/resources")],
                   {"columns": ["Team", "Confirmed", "Tentative", "Available", "Utilisation"], "rows": rows},
                   [{"label": "Open Resources", "route": "#/resources"}],
                   ["Who has spare capacity next month?", "Who is over-allocated next month?"],
                   [G.src("engine", "capacity", f"Team capacity {when}")])


def h_pending_approvals(msg, ents, ctx):
    today = _today(ctx)
    ids = {r["id"] for r in ents["initiatives"]}
    items = []
    for c in db.query("""SELECT i.id, i.rddc, i.name AS iname, c.name, rr.name AS lead FROM initiative_components ic
                           JOIN initiatives i ON i.id = ic.initiative_id AND i.id > 0 JOIN dc_components c ON c.id = ic.component_id
                           LEFT JOIN resources rr ON rr.id = COALESCE(ic.component_lead_id, c.component_lead_id)
                          WHERE ic.approval = 'Pending' AND i.stage != 'Closed' ORDER BY i.rddc, c.id"""):
        if not ids or c["id"] in ids:
            items.append(("Component", c, f"{c['name']} change", c["lead"] or "Component lead", None))
    for r in initiatives_all():
        if r.get("l2_status") == "Pending approval" and (not ids or r["id"] in ids):
            waited = C.business_days_from(str(r["l2_submitted_at"])[:10], today) if r.get("l2_submitted_at") else None
            items.append(("L2", {"id": r["id"], "rddc": r["rddc"], "iname": r["name"]}, f"L2 estimate {G.fmt_hours(r.get('l2_hours'))}",
                          r.get("requestor_name") or r.get("requestor") or "Requestor", waited))
    for cr in db.query("""SELECT c.crq_number, c.sto_approval, c.crq_start, i.id, i.rddc, i.name AS iname FROM change_requests c
                           JOIN initiatives i ON i.id = c.initiative_id AND i.id > 0 WHERE c.sto_approval IN ('Tentative Go', 'Tentative No Go')
                            AND substr(c.crq_start, 1, 10) >= ? ORDER BY c.crq_start""", (today.isoformat(),)):
        if not ids or cr["id"] in ids:
            items.append(("STO", cr, f"{cr['crq_number']} STO decision ({cr['sto_approval']})", "STO board", None))
    if not items:
        return _result("pending_approvals", "No approvals are pending.", follow=["Which initiatives are at risk?"])
    lines = [f"**{len(items)}** approval{'s are' if len(items) != 1 else ' is'} pending:"]
    rows, cites = [], []
    for kind, rec, what, who, waited in items[:20]:
        lines.append(f"- {rec['rddc']} {rec['iname']}: {what} — waiting on {who}" + (f" ({waited} business days)" if waited else ""))
        rows.append([kind, rec["rddc"], what, who, waited if waited is not None else ""])
        cites.append(cite("initiative", rec["rddc"], f"{rec['rddc']} {rec['iname']}", _route_init(rec["id"], "pg4" if kind == "STO" else "pg1")))
    return _result("pending_approvals", "\n".join(lines), cites,
                   {"columns": ["Type", "RDDC #", "Item", "Approver", "Business days waiting"], "rows": rows},
                   [{"label": "Open Change Management", "route": "#/changes"}],
                   ["Draft reminders for pending approvals", "Which initiatives are at risk?"],
                   [G.src("initiative", rec["rddc"], what) for _, rec, what, _w, _x in items[:10]])


def h_skill_lookup(msg, ents, ctx):
    skills = ents["skills"]
    if not skills:
        words = [w for w in re.findall(r"[A-Za-z0-9/+.#]{3,}", msg) if w.lower() not in STOP and w.lower() not in ("knows", "who", "skill", "skills", "expert")]
        cat = skills_catalog()
        for w in words:
            m = difflib.get_close_matches(w.lower(), [s.lower() for s in cat], n=1, cutoff=0.75)
            if m:
                skills.append(next(s for s in cat if s.lower() == m[0]))
    if not skills:
        return _result("skill_lookup", "Which skill? For example \"Who knows Kafka?\" or \"Who has OAuth2 experience?\".",
                       follow=["Who knows Kafka?", "Who knows OAuth2 / OIDC?"], confidence=0.5)
    norms = {G.norm(s) for s in skills}
    holders = [h for h in db.query("""SELECT r.id, r.name, r.team, s.name AS skill, rs.level, rs.evidence FROM resource_skills rs
                                         JOIN resources r ON r.id = rs.resource_id JOIN skills s ON s.id = rs.skill_id
                                        WHERE rs.level >= 2 ORDER BY rs.level DESC, r.name""") if G.norm(h["skill"]) in norms]
    label = ", ".join(skills)
    if not holders:
        return _result("skill_lookup", f"No one is recorded at working level or above in {label}.",
                       follow=["Generate the skill matrix"], actions=[{"label": "Open Resources", "route": "#/resources"}], confidence=0.7)
    lines = [f"People with **{label}** (level 2 working, 3 expert):"]
    rows = []
    for h in holders[:10]:
        lines.append(f"- **{h['name']}** ({h['team']}): {h['skill']} level {h['level']}" + (f" — {h['evidence']}" if h["evidence"] else ""))
        rows.append([h["name"], h["team"] or "", h["skill"], h["level"]])
    return _result("skill_lookup", "\n".join(lines), [cite("resource", h["id"], h["name"], "#/resources") for h in holders[:10]],
                   {"columns": ["Person", "Team", "Skill", "Level"], "rows": rows}, [{"label": "Open Resources", "route": "#/resources"}],
                   [f"What is {holders[0]['name'].split(' ')[0]} working on?", f"Suggest a developer for {label}"],
                   [G.src("resource", h["id"], f"{h['name']} skills") for h in holders[:10]])


def h_portfolio_stats(msg, ents, ctx):
    group = ents["group_by"] or "stage"
    rows_all = [r for r in initiatives_all()]
    key = {"lob": lambda r: r.get("lob") or "No LOB", "stage": lambda r: r["stage"], "rag": rag_of,
           "dc_pm": lambda r: r.get("dc_pm_name") or "Unassigned", "release": lambda r: r.get("target_release") or "Not set"}[group]
    counts: dict[str, list[dict]] = {}
    for r in rows_all:
        counts.setdefault(key(r), []).append(r)
    order = list(STAGES) if group == "stage" else ["Red", "Amber", "Green", "Not scored"] if group == "rag" else sorted(counts)
    label = {"lob": "LOB", "stage": "stage", "rag": "health", "dc_pm": "DC PM", "release": "release train"}[group]
    lines = [f"**{len(rows_all)}** initiatives by {label}:"]
    rows = []
    for k in order:
        if k in counts:
            lines.append(f"- {k}: {len(counts[k])} ({', '.join(r['rddc'] for r in counts[k])})")
            rows.append([k, len(counts[k]), ", ".join(r["rddc"] for r in counts[k])])
    return _result("portfolio_stats", "\n".join(lines), [cite("page", "portfolio", "Portfolio View", "#/portfolio")],
                   {"columns": [label.capitalize(), "Initiatives", "RDDC #"], "rows": rows},
                   [{"label": "Open Portfolio View", "route": "#/portfolio"}],
                   ["How many initiatives per LOB?" if group != "lob" else "How many initiatives per stage?", "Which initiatives are Red?"],
                   [G.src("initiative", "portfolio", "All initiatives")])


def h_status_report(msg, ents, ctx):
    """Same content as the Write Executive Summary button: the exec_summary feature (fixture or rules engine)."""
    from app.ai import provider

    r = ents["initiatives"][0] if ents["initiatives"] and not re.search(r"portfolio|all initiatives|leadership", msg.lower()) else None
    out = provider.preview_feature("exec_summary", r["id"] if r else None, {})
    by_rddc = {x["rddc"]: x for x in initiatives_all()}
    attention = [p for p in out.get("per_initiative") or [] if p["rag"] in ("Red", "Amber")]
    # the same text as the Write Executive Summary card: headline, body, then highlights, concerns and asks
    lines = [f"**{out['headline']}**", "", out["summary_md"]]
    named = out["summary_md"] + " " + " ".join(out.get("concerns") or [])
    missing = [p for p in attention if p["rddc"] not in named]
    for label, items in (("Highlights", out.get("highlights")), ("Concerns", out.get("concerns")), ("Asks", out.get("asks"))):
        if items:
            lines += ["", f"**{label}**"] + [f"- {_clean(x)}" for x in items]
    if missing:
        lines += ["", "**Also Amber or Red**"] + [f"- **{p['rddc']} {p['name']}** — {p['rag']}: {_clean(p['one_liner'])}" for p in missing]
    releases = out.get("upcoming_releases") or []
    if releases:
        lines += ["", "**Going to production**"] + [
            f"- {r['rddc']} on {r['release_train']} {G.fmt_date(r['date'])}" + (f" (STO {r['sto_approval']})" if r.get("sto_approval") else "")
            for r in releases[:6]]
    cites = [_init_cite(r, "pg5")] if r else []
    cites += [cite("initiative", p["rddc"], f"{p['rddc']} {p['name']}", _route_init(by_rddc[p["rddc"]]["id"], "pg5"))
              for p in attention if p["rddc"] in by_rddc]
    return _result("status_report", "\n".join(lines), cites, None,
                   [{"label": "Write Executive Summary", "route": f"#/initiative/{r['id']}/pg5" if r else "#/portfolio"}],
                   ["Which initiatives are at risk?", "What approvals are pending?"], out.get("sources"), 0.85)


# ------------------------------------------------------------------ round 2 intents: PRN burn, STO readiness, what-if
WORD_NUMBERS = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8,
                "nine": 9, "ten": 10}


def _planned_by_month(prn_code: str) -> dict:
    rows = db.query("SELECT a.month, SUM(a.hours) AS hours FROM allocations a JOIN initiatives i ON i.id = a.initiative_id AND i.id > 0 "
                    "WHERE i.prn_code = ? GROUP BY a.month", (prn_code,))
    return {r["month"]: r["hours"] for r in rows}


def prn_burndown(prn_code: str) -> dict | None:
    """The same numbers as the PRN burndown chart (engines.burndown over charges and planned allocations)."""
    prn = db.query_one("SELECT * FROM prn_budget WHERE prn_code = ?", (prn_code,))
    if prn is None:
        return None
    charges = db.query("SELECT month, charged_hours FROM prn_charges WHERE prn_code = ? ORDER BY month", (prn_code,))
    eng = C._engine("burndown")
    if eng is not None and hasattr(eng, "burndown"):
        out = dict(eng.burndown(prn, charges, _planned_by_month(prn_code), C.get_today()))
    else:
        charged = sum(float(c["charged_hours"] or 0) for c in charges)
        forecast = charged + sum(float(h or 0) for m, h in _planned_by_month(prn_code).items() if m >= _month_key(C.get_today()))
        funded = float(prn["funded_hours"] or 0)
        out = {"funded_hours": funded, "charged_hours": round(charged, 1), "forecast_hours": round(forecast, 1),
               "remaining_hours": round(funded - forecast, 1), "exhaust_month": None,
               "status": "overrun" if forecast > funded else "on_track"}
    if out.get("burn_rate") is None:
        recent = [float(c["charged_hours"] or 0) for c in charges if c["month"] < _month_key(C.get_today())][-3:]
        out["burn_rate"] = round(sum(recent) / len(recent), 1) if recent else 0.0
        out.setdefault("burn_rate_window", 3)
    out["charges_left"] = round(float(out["funded_hours"]) - float(out["charged_hours"]), 1)
    out["name"] = prn.get("name")
    return out


def h_prn_status(msg, ents, ctx):
    codes = list(ents.get("prns") or [])
    for r in ents["initiatives"]:
        if r.get("prn_code") and r["prn_code"] not in codes:
            codes.append(r["prn_code"])
    if not codes:
        options = [r["prn_code"] for r in db.query("SELECT prn_code FROM prn_budget ORDER BY prn_code")][:3]
        return _result("prn_status", "Which PRN? Give the PRN number or the initiative, for example \"How many hours are left on "
                       f"{options[0] if options else 'PRN-77310'}?\".", follow=[f"How is {c} tracking?" for c in options],
                       confidence=0.5)
    lines, rows, cites, sources = [], [], [], []
    for code in codes[:3]:
        b = prn_burndown(code)
        if b is None:
            lines.append(f"{code} is not a PRN in the budget list.")
            continue
        funded, charged, forecast = float(b["funded_hours"]), float(b["charged_hours"]), float(b["forecast_hours"])
        inits = db.query("SELECT id, rddc, name FROM initiatives WHERE prn_code = ? AND id > 0 ORDER BY rddc", (code,))
        head = f"**{code}**" + (f" ({', '.join(i['rddc'] + ' ' + i['name'] for i in inits)})" if inits else "")
        pct = G.rint(charged / funded * 100) if funded else 0
        lines.append(f"{head}: {G.fmt_hours(charged)} charged of {G.fmt_hours(funded)} funded ({pct}% burned), "
                     f"{G.fmt_hours(max(b['charges_left'], 0))} left before charges reach the funding.")
        if b.get("burn_rate"):
            window = b.get("burn_rate_window") or 3
            window_txt = f"{window}-month average" if isinstance(window, int) else str(window)
            lines.append(f"- Burn rate: {G.fmt_hours(b['burn_rate'])} a month ({window_txt}, same as the burndown chart).")
        over = forecast - funded
        lines.append(f"- Forecast to finish: {G.fmt_hours(forecast)} (charged plus remaining plan) — "
                     + (f"**{G.fmt_hours(over)} over** the funded hours." if over > 0.05 else
                        f"{G.fmt_hours(-over)} under the funded hours."))
        if b.get("exhaust_month"):
            lines.append(f"- Funding runs out in **{G.fmt_month(b['exhaust_month'])}** on the current forecast.")
        elif over <= 0.05:
            lines.append("- Funding lasts to the end of the plan on the current forecast.")
        status = {"overrun": "Overrun", "at_risk": "At risk", "on_track": "On track"}.get(b.get("status"), b.get("status") or "")
        rows.append([code, G.fmt_hours(funded), G.fmt_hours(charged), G.fmt_hours(forecast),
                     G.fmt_month(b["exhaust_month"]) if b.get("exhaust_month") else "Not in plan", status])
        cites.append(cite("prn", code, f"{code} burndown", _route_init(inits[0]["id"], "pg3") if inits else "#/portfolio"))
        cites += [_init_cite(i, "pg3") for i in inits]
        sources.append(G.src("prn", code, f"{code} burndown (charged vs forecast)"))
    return _result("prn_status", "\n".join(lines), cites,
                   {"columns": ["PRN", "Funded", "Charged", "Forecast", "Runs out", "Status"], "rows": rows} if rows else None,
                   [{"label": "Open Portfolio View", "route": "#/portfolio"}],
                   ["Which initiatives are at risk?", "What needs management attention this week?"], sources)


def h_prn_overrun(msg, ents, ctx):
    rows_out, lines, cites, table = [], [], [], []
    for p in db.query("SELECT prn_code FROM prn_budget ORDER BY prn_code"):
        b = prn_burndown(p["prn_code"])
        if b and float(b["forecast_hours"]) > float(b["funded_hours"]) + 0.05:
            rows_out.append((p["prn_code"], b))
    if not rows_out:
        return _result("prn_overrun", "No PRN is forecast to overrun its funded hours.",
                       follow=["How is PRN-77310 tracking?"], actions=[{"label": "Open Portfolio View", "route": "#/portfolio"}])
    rows_out.sort(key=lambda x: -(float(x[1]["forecast_hours"]) - float(x[1]["funded_hours"])))
    lines.append(f"**{len(rows_out)}** PRN{'s are' if len(rows_out) != 1 else ' is'} forecast to overrun:")
    for code, b in rows_out:
        over = float(b["forecast_hours"]) - float(b["funded_hours"])
        inits = db.query("SELECT id, rddc, name FROM initiatives WHERE prn_code = ? AND id > 0 ORDER BY rddc", (code,))
        lines.append(f"- **{code}** ({', '.join(i['rddc'] + ' ' + i['name'] for i in inits) or 'no initiative'}): forecast "
                     f"{G.fmt_hours(b['forecast_hours'])} against {G.fmt_hours(b['funded_hours'])} funded, **{G.fmt_hours(over)} over**"
                     + (f"; funding runs out {G.fmt_month(b['exhaust_month'])}" if b.get("exhaust_month") else "") + ".")
        table.append([code, ", ".join(i["rddc"] for i in inits), G.fmt_hours(b["funded_hours"]), G.fmt_hours(b["charged_hours"]),
                      G.fmt_hours(b["forecast_hours"]), G.fmt_hours(over), G.fmt_month(b["exhaust_month"]) if b.get("exhaust_month") else ""])
        cites.append(cite("prn", code, f"{code} burndown", _route_init(inits[0]["id"], "pg3") if inits else "#/portfolio"))
        cites += [_init_cite(i, "pg3") for i in inits]
    first = rows_out[0][0]
    return _result("prn_overrun", "\n".join(lines), cites,
                   {"columns": ["PRN", "Initiatives", "Funded", "Charged", "Forecast", "Over", "Runs out"], "rows": table},
                   [{"label": "Open Portfolio View", "route": "#/portfolio"}],
                   [f"How many hours are left on {first}?", "What needs management attention this week?"],
                   [G.src("prn", code, f"{code} burndown") for code, _b in rows_out])


def _week_window(msg: str, today: date) -> tuple[str, str, str]:
    low = msg.lower()
    if "this week" in low:
        monday = today - timedelta(days=today.weekday())
        return today.isoformat(), (monday + timedelta(days=6)).isoformat(), "this week"
    m = re.search(r"next (\d+|two|three|four) (days|weeks)", low)
    if m:
        n = int(m.group(1)) if m.group(1).isdigit() else WORD_NUMBERS[m.group(1)]
        days = n * 7 if m.group(2) == "weeks" else n
        return today.isoformat(), (today + timedelta(days=days)).isoformat(), f"in the next {n} {m.group(2)}"
    return today.isoformat(), (today + timedelta(days=14)).isoformat(), "in the next 14 days"


RULE_LABELS = {"CR-01": "STO Go", "CR-02": "CRQ approval", "CR-03": "Affected CIs", "CR-04": "Technical validation evidence",
               "CR-05": "Business validation evidence", "CR-06": "Change window check", "CR-07": "CMS and Rel leads",
               "CR-08": "Release train", "CR-09": "Implementation status", "CR-10": "CRQ lead time", "CR-11": "Backout plan",
               "CR-12": "Window on the production date", "CR-13": "Production on the target train"}


def _rule_label(f: dict) -> str:
    return RULE_LABELS.get(f.get("rule_id"), _clean(f.get("rule") or f.get("rule_id") or "Check"))


def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip().rstrip(".;, ")


def _readiness_text(review: dict, readiness: str) -> str:
    detail = review.get("sto_readiness_detail")
    label = detail.get("label") if isinstance(detail, dict) else None
    return _clean(label) if label else readiness.lower()


def _cr_review(cr: dict) -> dict:
    return C.check_cr(C.parse_row(dict(cr))) or {"ok": not _cr_flags(cr), "flags": _cr_flags(cr), "findings": []}


def h_crq_sto_readiness(msg, ents, ctx):
    start, end, label = _week_window(msg, _today(ctx))
    crs = db.query("""SELECT c.*, i.id AS iid, i.rddc, i.name FROM change_requests c JOIN initiatives i ON i.id = c.initiative_id AND i.id > 0
                       WHERE substr(c.crq_start, 1, 10) BETWEEN ? AND ? ORDER BY c.crq_start""", (start, end))
    if ents["initiatives"]:
        crs = [c for c in crs if c["iid"] in {r["id"] for r in ents["initiatives"]}]
    if not crs:
        return _result("crq_sto_readiness", f"No CRQ starts {label} ({G.fmt_date(start)} – {G.fmt_date(end)}).",
                       follow=["What's going to production in the next 2 weeks?", "Which CRQs are non-compliant?"],
                       actions=[{"label": "Open Change Management", "route": "#/changes"}])
    lines, rows, cites = [], [], []
    not_ready = 0
    for c in crs:
        review = _cr_review(c)
        blocking = [f for f in review.get("findings") or [] if f.get("status") == "Fail"] or \
            [{"rule_id": f.get("code", ""), "detail": f.get("message", "")} for f in review.get("flags") or [] if f.get("blocking")]
        readiness = C.sto_status(review.get("sto_readiness")) or ("Ready for Go" if not blocking else "Not ready")
        ready = readiness == "Ready for Go" and not blocking
        if not ready:
            not_ready += 1
        warns = [f for f in review.get("findings") or [] if f.get("status") == "Warn"]
        not_due = [f for f in review.get("findings") or [] if f.get("status") == "Not due yet"]
        parts = []
        if blocking:
            parts.append("blocking: " + "; ".join(_clean(f.get("detail") or f.get("rule") or "") for f in blocking[:3]))
        if warns:
            parts.append("open: " + "; ".join(_clean(f.get("detail") or "") for f in warns[:3]))
        if not_due:
            parts.append("; ".join(f"{_rule_label(f)} due {G.fmt_day(f['due_date'])}" if f.get("due_date")
                                   else f"{_rule_label(f)} still to come" for f in not_due[:4]))
        if not parts and review.get("flags"):
            parts.append("; ".join(_clean(f.get("message", "")) for f in review["flags"][:2]))
        why = "; ".join(p for p in parts if p)
        lines.append(f"- **{c['crq_number'] or 'CRQ'}** ({c['rddc']} {c['name']}, {G.fmt_day(str(c['crq_start'])[:10])}): "
                     f"{'ready for the STO decision' if ready else _readiness_text(review, readiness)}" + (f" — {why}" if why and not ready else "")
                     + f". STO now {c['sto_approval'] or 'not requested'}.".replace("..", "."))
        rows.append([c["crq_number"] or "", c["rddc"], G.fmt_date(str(c["crq_start"])[:10]), readiness, why])
        cites.append(cite("change_request", c["crq_number"] or c["id"], c["crq_number"] or "Change request", _route_init(c["iid"], "pg4")))
    head = (f"**{not_ready}** of {len(crs)} CRQ{'s' if len(crs) != 1 else ''} starting {label} "
            f"{'are' if not_ready != 1 else 'is'} not ready for the STO go/no-go:")
    return _result("crq_sto_readiness", "\n".join([head] + lines), cites,
                   {"columns": ["CRQ", "RDDC #", "Window", "STO readiness", "Blocking results"], "rows": rows},
                   [{"label": "Open Change Management", "route": "#/changes"}],
                   ["Which CRQs are non-compliant?", "What approvals are pending?"],
                   [G.src("rule", "compliance", "Change governance rules (calculated)")])


def _slip_days(msg: str) -> int | None:
    m = re.search(r"\b(\d+|a|an|one|two|three|four|five|six|seven|eight|nine|ten)\s*(business days?|working days?|bd|days?|weeks?)\b",
                  msg.lower())
    if not m:
        return None
    n = int(m.group(1)) if m.group(1).isdigit() else WORD_NUMBERS[m.group(1)]
    return n * 5 if m.group(2).startswith("week") else n


def h_what_if_slip(msg, ents, ctx):
    if not ents["initiatives"]:
        return _result("what_if_slip", "Which initiative? For example \"What happens to RDDC-24817 if WBS-230 slips two weeks?\".",
                       follow=["What happens to RDDC-24817 if CIAM approval slips two weeks?"], confidence=0.5)
    r = ents["initiatives"][0]
    days = _slip_days(msg)
    bundle = C.load_bundle(r["id"])
    tasks = [dict(t) for t in bundle.get("tasks", [])]
    if not tasks:
        return _result("what_if_slip", f"**{r['rddc']} {r['name']}** has no plan yet, so there is nothing to slip. "
                       "Generate the project plan on Pg 2 first.", [_init_cite(r, "pg2")], confidence=0.6)
    target = None
    if ents["wbs"]:
        target = next((t for t in tasks if t["wbs_code"] == ents["wbs"][0]), None)
    if target is None and ents["components"]:
        target = next((t for t in tasks if t.get("component_code") in ents["components"] and float(t.get("est_hours") or 0) > 0), None)
    if target is None or days is None:
        need = "which step slips" if target is None else "by how much"
        return _result("what_if_slip", f"Tell me {need}, for example \"What happens to {r['rddc']} if WBS-230 slips 10 business days?\".",
                       [_init_cite(r, "pg2")], follow=[f"What happens to {r['rddc']} if WBS-230 slips two weeks?"], confidence=0.5)
    eng = C._engine("schedule")
    if eng is None or not hasattr(eng, "propagate_slip"):
        return _result("what_if_slip", "The schedule engine is not available, so I can't run the what-if.", confidence=0.3)
    old_start = target["planned_start"]
    new_start = C.add_business_days(target["planned_start"], days).isoformat()
    new_end = C.add_business_days(target["planned_end"], days).isoformat()
    for t in tasks:
        if t["id"] == target["id"]:
            t["planned_start"], t["planned_end"] = new_start, new_end
    moved = eng.propagate_slip(tasks, target["id"])
    for t in tasks:
        if t["id"] in moved:
            t["planned_start"], t["planned_end"] = moved[t["id"]]
    before = (bundle["initiative"].get("readiness_date"), bundle["initiative"].get("prod_date"))
    kd = eng.key_dates(tasks) if hasattr(eng, "key_dates") else {}
    train = bundle.get("target_train") or {}
    train_date = train.get("train_date")
    old_float = C.initiative_float(bundle["initiative"])
    new_ready = kd.get("readiness_date") or before[0]
    new_float = C.readiness_float_bd(new_ready, train_date or kd.get("prod_date"))
    health_before = bundle["initiative"].get("health_cached_json") if isinstance(bundle["initiative"].get("health_cached_json"), dict) else {}
    sim = {**bundle, "tasks": tasks, "initiative": {**bundle["initiative"], "readiness_date": new_ready,
                                                    "prod_date": kd.get("prod_date") or before[1]}}
    health_after = C.compute_health(sim) or {}

    def rag(h, dim):
        return ((h.get("dimensions") or {}).get(dim) or {}).get("rag") if dim != "overall" else h.get("overall")

    why = f"{target['wbs_code']} {target['step']}"
    if ents["components"] and re.search(r"approv", msg.lower()):
        why = f"{COMPONENT_NAMES[target['component_code']]} approval gates {target['wbs_code']} {target['step']}"
    lines = [f"If {why} slips **{days} business days** (starts {G.fmt_date(new_start)} instead of {G.fmt_date(old_start)}):",
             f"- Readiness moves from {G.fmt_date(before[0])} to **{G.fmt_date(new_ready)}**."]
    if new_float is not None:
        if new_float >= 0:
            lines.append(f"- Float before {train.get('code') or 'the train'} drops from {old_float} to **{new_float} business days**; "
                         f"the train still holds.")
        else:
            nxt = next((t for t in C.release_trains() if t["train_date"] > new_ready and not C.in_freeze(t["train_date"])), None)
            lines.append(f"- Readiness **misses {train.get('code') or 'the train'}** by {-new_float} business days"
                         + (f"; the next train is {nxt['code']} on {G.fmt_date(nxt['train_date'])}." if nxt else "."))
    if health_after:
        lines.append(f"- Health: Schedule {rag(health_before, 'schedule') or 'not scored'} → **{rag(health_after, 'schedule')}**, "
                     f"overall {rag(health_before, 'overall') or 'not scored'} → **{rag(health_after, 'overall')}**.")
    shifted = sorted((t for t in tasks if t["id"] in moved and float(t.get("est_hours") or 0) > 0), key=lambda t: t.get("sort") or 0)
    if shifted:
        lines.append(f"- Steps that move: {', '.join(t['wbs_code'] for t in shifted[:8])}.")
    lines.append("This is a what-if only; the plan is unchanged.")
    return _result("what_if_slip", "\n".join(lines),
                   [_init_cite(r, "pg2"), cite("wbs_task", f"{r['rddc']}/{target['wbs_code']}", target["wbs_code"], _route_init(r["id"], "pg2"))],
                   {"columns": ["Measure", "Now", "After the slip"],
                    "rows": [["Readiness", G.fmt_date(before[0]), G.fmt_date(new_ready)],
                             ["Float (business days)", old_float if old_float is not None else "", new_float if new_float is not None else ""],
                             ["Schedule", rag(health_before, "schedule") or "", rag(health_after, "schedule") or ""],
                             ["Overall", rag(health_before, "overall") or "", rag(health_after, "overall") or ""]]},
                   [{"label": "Open Pg 2 Project Plan", "route": _route_init(r["id"], "pg2")}],
                   [f"What is blocking {r['rddc']}?", f"Why is {r['rddc']} {rag_of(r)}?"],
                   [G.src("engine", "schedule", f"{r['rddc']} schedule what-if (not saved)")])


def h_help(msg, ents, ctx):
    md = ("I can't answer that yet. Here is what I can do: initiative health and blockers, people and capacity, PRN burn, "
          "release trains and CRQ readiness, risks, approvals, and simple schedule what-ifs. Try one of these:")
    return _result("help", md, [], None, [{"label": "Open Portfolio View", "route": "#/portfolio"}], EXAMPLES, [], 0.3)


def h_disambiguate(intent, msg, ents, ctx):
    opts = ents["ambiguous"]
    md = "Which initiative do you mean? " + " or ".join(f"**{r['rddc']} {r['name']}**" for r in opts) + "?"
    return _result(intent, md, [_init_cite(r) for r in opts], None, [],
                   [re.sub(r"\s+", " ", f"{msg.rstrip('?')} ({r['rddc']})?") for r in opts][:4], [], 0.5)


HANDLERS = {
    "list_by_rag": h_list_by_rag, "explain_health": h_explain_health, "overallocated_resources": h_overallocated,
    "summarize_initiative": h_summarize, "blockers": h_blockers, "suggest_resource": h_suggest_resource,
    "availability": h_availability, "resource_workload": h_workload, "upcoming_releases": h_upcoming_releases,
    "cr_noncompliance": h_cr_noncompliance, "top_risks": h_top_risks, "milestone_dates": h_milestones,
    "component_demand": h_component_demand, "pending_approvals": h_pending_approvals, "skill_lookup": h_skill_lookup,
    "portfolio_stats": h_portfolio_stats, "status_report": h_status_report, "help": h_help,
    "prn_status": h_prn_status, "crq_sto_readiness": h_crq_sto_readiness, "what_if_slip": h_what_if_slip,
    "prn_overrun": h_prn_overrun,
}


PAGE_SCOPED = {"explain_health", "blockers", "summarize_initiative", "milestone_dates", "top_risks",
               "overallocated_resources", "pending_approvals", "cr_noncompliance", "status_report", "prn_status",
               "crq_sto_readiness", "what_if_slip"}
DIMENSIONS = ("schedule", "resources", "scope", "dependencies", "budget")


_QUOTES = str.maketrans({"\u2019": "'", "\u2018": "'", "\u201c": '"', "\u201d": '"', "\u2013": "-", "\u2014": "-",
                         "\u2026": "...", "\u00a0": " "})


def normalize_message(message: str) -> str:
    """Typographic quotes, dashes and spacing to plain ASCII before any matching."""
    return re.sub(r"\s+", " ", (message or "").translate(_QUOTES)).strip()


def page_initiative(message: str, ctx: dict, intent: str, ents: dict) -> dict | None:
    """The workspace initiative an initiative-scoped question is about, unless the user asked portfolio-wide."""
    if intent not in PAGE_SCOPED or ents["initiatives"] or ents["ambiguous"] or not ctx.get("initiative_id"):
        return None
    if re.search(r"portfolio|across|all initiatives|\bwhich (initiatives|projects)\b|everyone|\bteam\b", message.lower()):
        return None
    return init_by_id(int(ctx["initiative_id"]))


def resolve(message: str, ctx: dict) -> tuple[str, dict]:
    """(intent, entities) after page-context scoping; shared by the router and the showcase matcher."""
    message = normalize_message(message)
    ents = extract_entities(message, ctx)
    intent, score = route_intent(message, ents)
    ents["_score"] = score
    if ents["trains"] and not ents["rag"] and not ents["at_risk"] and intent in ("list_by_rag", "upcoming_releases", "help",
                                                                                  "milestone_dates", "portfolio_stats"):
        intent = "release_train"
    row = page_initiative(message, ctx, intent, ents)
    if row:
        ents["initiatives"].append(row)
        ents["from_page"] = True
    return intent, ents


def answer(message: str, ctx: dict, variant: int = 0) -> dict:
    message = normalize_message(message)
    intent, ents = resolve(message, ctx)
    if intent == "release_train":
        return h_release_train(message, ents, ctx)
    if intent in NEEDS_INITIATIVE | {"blockers", "explain_health"} and ents["ambiguous"] and not ents["initiatives"]:
        return h_disambiguate(intent, message, ents, ctx)
    if intent in NEEDS_INITIATIVE and not ents["initiatives"]:
        if intent == "milestone_dates" and re.search(r"release|train|prod", (message or "").lower()):
            intent = "upcoming_releases"
        else:
            out = _result(intent, "Which initiative? Give the RDDC # or the name, for example \"When is the QA date for RDDC-24817?\".",
                          follow=[f"{G.clip(message.rstrip('?'), 120)} for {r['rddc']}?" for r in initiatives_all()
                                  if r["stage"] not in ("Closed",)][:3], confidence=0.5)
            return out
    out = HANDLERS[intent](message, ents, ctx)
    # confidence reflects how well the question matched, never a fixed "High"
    score = float(ents.get("_score") or 0)
    match_conf = 0.9 if score >= 5 else 0.8 if score >= 3.5 else 0.7 if score >= MIN_SCORE else 0.3
    out["confidence"] = round(min(out["confidence"], match_conf), 2)
    return out


# ------------------------------------------------------------------ bindings for showcase fixtures
# A binding spec is "name" or "name:arg1:arg2". Every value is read from the live database at answer time.
def num(x: Any) -> str:
    x = float(x or 0)
    return f"{x:,.0f}" if abs(x - round(x)) < 0.05 else f"{x:,.1f}"


def _active() -> list[dict]:
    return [r for r in initiatives_all() if r["stage"] != "Closed"]


def _init_by_key(key: str) -> dict | None:
    key = key.strip()
    return next((r for r in initiatives_all() if r["rddc"] == key or str(r["id"]) == key), None)


def _kpi_window() -> list[str]:
    start = _month_key(C.get_today())
    return [_add_months(start, i) for i in range(6)]


def _overallocated(month: str | None = None) -> list[dict]:
    months = [month] if month else _kpi_window()
    return sorted([u for u in util_rows(months) if u["util"] > 1.0], key=lambda u: (-u["util"], u["name"], u["month"]))


def _person_month(rid: str, month: str) -> dict | None:
    return C.utilisation([month]).get(int(rid), {}).get(month)


def _b_util(rid: str, month: str) -> str | None:
    c = _person_month(rid, month)
    return f"{G.rint(c['util'] * 100)}%" if c else None


def _b_free(rid: str, month: str) -> str | None:
    c = _person_month(rid, month)
    return num(max(c["available"] - c["allocated"], 0)) if c else None


def _b_alloc(rid: str, month: str) -> str | None:
    c = _person_month(rid, month)
    return num(c["allocated"]) if c else None


def _b_team_util(team: str, month: str) -> str | None:
    util = C.utilisation([month])
    ids = [p["id"] for p in C.resource_rows() if team in (p["team"], p["team_label"])]
    avail = sum(util.get(i, {}).get(month, {}).get("available", 0) for i in ids)
    alloc = sum(util.get(i, {}).get(month, {}).get("allocated", 0) for i in ids)
    return f"{G.rint(alloc / avail * 100)}%" if avail else None


def _b_component_hours(code: str) -> str:
    return num(db.scalar("""SELECT COALESCE(SUM(ic.est_hours), 0) FROM initiative_components ic
                             JOIN dc_components c ON c.id = ic.component_id JOIN initiatives i ON i.id = ic.initiative_id AND i.id > 0
                            WHERE c.code = ? AND i.stage != 'Closed'""", (code,)))


def _b_train(code: str) -> list[dict]:
    return [r for r in _active() if r.get("target_release") == code]


def _b_health(key: str, dim: str = "overall") -> str | None:
    r = _init_by_key(key)
    if not r:
        return None
    if dim == "overall":
        return rag_of(r)
    v = (health_of(r).get("dimensions") or {}).get(dim) or {}
    return v.get("rag") or "Not scored"


def _b_health_reason(key: str, dim: str = "overall") -> str | None:
    r = _init_by_key(key)
    if not r:
        return None
    if dim == "overall":
        return top_reason(r) or None
    reasons = ((health_of(r).get("dimensions") or {}).get(dim) or {}).get("reasons") or []
    return reasons[0] if reasons else None


def _b_float(key: str) -> str | None:
    r = _init_by_key(key)
    fl = C.initiative_float(r) if r else None
    return None if fl is None else str(fl)


def _b_init(key: str, field: str) -> str | None:
    r = _init_by_key(key)
    if not r:
        row = None
    else:
        row = C.parse_row(db.query_one("SELECT * FROM initiatives WHERE id = ?", (r["id"],)))
    if not row or field not in row:
        return None
    val = row[field]
    if val is None or val == "":
        return None
    if field.endswith("_date") or field in ("planned_start", "planned_end", "requested_go_live"):
        return G.fmt_date(val)
    if isinstance(val, (int, float)) and field.endswith("hours"):
        return num(val)
    if isinstance(val, list):
        return ", ".join(str(x) for x in val)
    return str(val)


def _b_l2_wait(key: str) -> str | None:
    r = _init_by_key(key)
    if not r or not r.get("l2_submitted_at"):
        return None
    return str(max(C.business_days_from(str(r["l2_submitted_at"])[:10], C.get_today()), 0))


def _b_attention(key: str) -> str | None:
    r = _init_by_key(key)
    att = health_of(r).get("attention") if r else None
    return att[0] if att else None


def _noncompliant() -> list[dict]:
    since = (C.get_today() - timedelta(days=7)).isoformat()
    crs = db.query("""SELECT c.*, i.rddc FROM change_requests c JOIN initiatives i ON i.id = c.initiative_id AND i.id > 0
                       WHERE c.crq_start IS NULL OR substr(c.crq_start, 1, 10) >= ? ORDER BY c.crq_start""", (since,))
    return [c for c in crs if _cr_flags(c)]


def _b_overallocated_list() -> str:
    worst: dict[int, dict] = {}
    for u in _overallocated():
        if u["resource_id"] not in worst:
            worst[u["resource_id"]] = u
    return ", ".join(f"{u['name']} ({G.rint(u['util'] * 100)}% in {G.fmt_month(u['month'])})" for u in worst.values()) or "no one"


def _b_kpi(name: str) -> str | None:
    if name == "overallocated_people":
        return str(len({u["resource_id"] for u in _overallocated()}))
    if name == "active":
        return str(len(_active()))
    if name in ("red", "amber", "green"):
        return str(sum(1 for r in _active() if rag_of(r) == name.capitalize()))
    if name == "crqs_this_week":
        t = C.get_today()
        return str(db.scalar("SELECT COUNT(*) FROM change_requests WHERE substr(crq_start, 1, 10) BETWEEN ? AND ?",
                             (t.isoformat(), (t + timedelta(days=6)).isoformat())) or 0)
    return None


def _b_next_grooming() -> str | None:
    today = C.get_today().isoformat()
    s = db.query_one("""SELECT session_date, start_time FROM grooming_sessions WHERE status = 'Scheduled' AND session_date > ?
                         ORDER BY session_date, start_time LIMIT 1""", (today,))
    return f"{G.fmt_day(s['session_date'])} {s['session_date'][:4]}, {s['start_time']}" if s else None


def _pending_items() -> list[str]:
    items = [f"{c['rddc']} {c['name']} ({c['lead'] or 'component lead'})" for c in db.query(
        """SELECT i.rddc, c.name, rr.name AS lead FROM initiative_components ic JOIN initiatives i ON i.id = ic.initiative_id AND i.id > 0
             JOIN dc_components c ON c.id = ic.component_id LEFT JOIN resources rr ON rr.id = COALESCE(ic.component_lead_id, c.component_lead_id)
            WHERE ic.approval = 'Pending' AND i.stage != 'Closed' ORDER BY i.rddc, c.id""")]
    items += [f"{r['rddc']} L2 estimate ({r.get('requestor_name') or r.get('requestor') or 'requestor'})"
              for r in _active() if r.get("l2_status") == "Pending approval"]
    return items


def _b_plan_hours(key: str) -> str | None:
    r = _init_by_key(key)
    if not r:
        return None
    return num(db.scalar("SELECT COALESCE(SUM(est_hours), 0) FROM wbs_tasks WHERE initiative_id = ?", (r["id"],)))


def _b_assignments(rid: str) -> str:
    rows = db.query("""SELECT i.rddc, t.wbs_code, t.planned_start, t.planned_end FROM wbs_tasks t JOIN initiatives i ON i.id = t.initiative_id AND i.id > 0
                        WHERE t.resource_id = ? AND t.status != 'Completed' AND (t.planned_end IS NULL OR t.planned_end >= ?)
                        ORDER BY t.planned_start, i.rddc""", (int(rid), C.get_today().isoformat()))
    return ", ".join(f"{r['rddc']} {r['wbs_code']}" + (f" ({G.fmt_day(r['planned_start'])} – {G.fmt_day(r['planned_end'])})"
                                                        if r["planned_start"] and r["planned_end"] else "") for r in rows) or "none"


def _b_top_risks(n: str = "5") -> str:
    rows = db.query("""SELECT k.risk_code, k.title, k.score, i.rddc FROM risks k JOIN initiatives i ON i.id = k.initiative_id AND i.id > 0
                        WHERE k.status != 'Closed' ORDER BY k.score DESC, k.id LIMIT ?""", (int(n),))
    return "; ".join(f"{r['risk_code'] or 'Risk'} {r['title']} ({r['rddc']}, score {r['score']})" for r in rows) or "none"


def _b_crqs_next(days: str = "14") -> str:
    t = C.get_today()
    rows = db.query("""SELECT c.crq_number, c.crq_start, c.sto_approval, i.rddc FROM change_requests c JOIN initiatives i ON i.id = c.initiative_id AND i.id > 0
                        WHERE substr(c.crq_start, 1, 10) BETWEEN ? AND ? ORDER BY c.crq_start""",
                    (t.isoformat(), (t + timedelta(days=int(days))).isoformat()))
    return ", ".join(f"{r['crq_number'] or 'CRQ'} ({r['rddc']}, {G.fmt_day(str(r['crq_start'])[:10])}, STO {r['sto_approval'] or 'not set'})"
                     for r in rows) or "none"


def _b_crq(number: str, field: str) -> str | None:
    row = db.query_one("SELECT * FROM change_requests WHERE crq_number = ?", (number,))
    if not row or field not in row or row[field] in (None, ""):
        return None
    return str(row[field])


def _b_crq_flags(key: str) -> str | None:
    r = _init_by_key(key)
    if not r:
        return None
    msgs = [f.get("message", "") for c in db.query("SELECT * FROM change_requests WHERE initiative_id = ?", (r["id"],)) for f in _cr_flags(c)]
    return "; ".join(m.rstrip(".") for m in msgs if m) or "none"


def _b_prn(code: str, what: str) -> str | None:
    prn = db.query_one("SELECT * FROM prn_budget WHERE prn_code = ?", (code,))
    if not prn:
        return None
    charged = float(db.scalar("SELECT COALESCE(SUM(charged_hours), 0) FROM prn_charges WHERE prn_code = ?", (code,)) or 0)
    if what == "funded":
        return num(prn["funded_hours"])
    if what == "charged":
        return num(charged)
    if what == "forecast":
        remaining = db.scalar("""SELECT COALESCE(SUM(t.est_hours * (100 - t.pct) / 100.0), 0) FROM wbs_tasks t
                                   JOIN initiatives i ON i.id = t.initiative_id AND i.id > 0 WHERE i.prn_code = ?""", (code,)) or 0
        return num(charged + float(remaining))
    if what == "remaining":
        return num(float(prn["funded_hours"]) - charged)
    return None


BINDINGS: dict[str, Any] = {
    "util": _b_util, "resource_util": _b_util, "free": _b_free, "alloc": _b_alloc, "team_util": _b_team_util,
    "component_hours": _b_component_hours,
    "count_train": lambda code: str(len(_b_train(code))),
    "train_list": lambda code: ", ".join(f"{r['rddc']} {r['name']}" for r in _b_train(code)) or "none",
    "health": _b_health, "health_reason": _b_health_reason, "float_bd": _b_float, "readiness_float": _b_float,
    "init": _b_init, "initiative_field": _b_init, "l2_waiting_bd": _b_l2_wait, "attention": _b_attention,
    "noncompliant_crqs": lambda: ", ".join(f"{c['crq_number'] or 'CRQ'} ({c['rddc']})" for c in _noncompliant()) or "none",
    "list_noncompliant_crqs": lambda: ", ".join(c["crq_number"] or "CRQ" for c in _noncompliant()) or "none",
    "count_noncompliant_crqs": lambda: str(len(_noncompliant())),
    "overallocated_list": _b_overallocated_list, "list_overallocated": _b_overallocated_list,
    "count_overallocated": lambda month=None: str(len({u["resource_id"] for u in _overallocated(month)})),
    "kpi": _b_kpi, "next_grooming": _b_next_grooming,
    "pending_approvals_count": lambda: str(len(_pending_items())), "count_pending_approvals": lambda: str(len(_pending_items())),
    "pending_approvals_list": lambda: ", ".join(_pending_items()) or "none",
    "plan_hours": _b_plan_hours,
    "rag_list": lambda rag: ", ".join(f"{r['rddc']} {r['name']}" for r in _active() if rag_of(r) == rag.capitalize()) or "none",
    "count_red_initiatives": lambda: _b_kpi("red"), "count_amber_initiatives": lambda: _b_kpi("amber"),
    "count_green_initiatives": lambda: _b_kpi("green"), "count_active_initiatives": lambda: _b_kpi("active"),
    "list_red_initiatives": lambda: ", ".join(f"{r['rddc']} {r['name']}" for r in _active() if rag_of(r) == "Red") or "none",
    "list_amber_initiatives": lambda: ", ".join(f"{r['rddc']} {r['name']}" for r in _active() if rag_of(r) == "Amber") or "none",
    "assignments": _b_assignments, "count_stage": lambda stage: str(sum(1 for r in initiatives_all() if r["stage"] == stage)),
    "count_open_risks": lambda: str(db.scalar("SELECT COUNT(*) FROM risks WHERE status != 'Closed'") or 0),
    "top_risks": _b_top_risks, "crqs_next_days": _b_crqs_next, "crq": _b_crq, "crq_flags": _b_crq_flags, "prn": _b_prn,
    "resource_name": lambda rid: next((p["name"] for p in people() if p["id"] == int(rid)), None),
    "today": lambda: G.fmt_date(C.get_today()),
    # single-field shortcuts: dates as "17 Feb 2027", hours as "1,000 h", RAG and stage as words
    "initiative_rag": lambda key: _b_health(key, "overall"), "initiative_stage": lambda key: _b_init(key, "stage"),
    "initiative_name": lambda key: _b_init(key, "name"),
    "readiness_date": lambda key: _b_init(key, "readiness_date"), "qa_date": lambda key: _b_init(key, "qa_date"),
    "prod_date": lambda key: _b_init(key, "prod_date"), "target_release": lambda key: _b_init(key, "target_release"),
    "l2_hours": lambda key: (f"{_b_init(key, 'l2_hours')} h" if _b_init(key, "l2_hours") else None),
    "sa_completeness": lambda key: _b_init(key, "sa_completeness"),
    "top_risk_title": lambda: (db.query_one("SELECT title FROM risks WHERE status != 'Closed' ORDER BY score DESC, id LIMIT 1")
                               or {}).get("title"),
    "count_crqs_next_14_days": lambda: str(len(db.query(
        "SELECT id FROM change_requests WHERE substr(crq_start, 1, 10) BETWEEN ? AND ?",
        (C.get_today().isoformat(), (C.get_today() + timedelta(days=14)).isoformat())))),
    "crqs_this_week": lambda: _b_kpi("crqs_this_week"),
    "count_initiatives": lambda: str(len(initiatives_all())),
}


def resolve_binding(spec: str) -> str | None:
    """'name' or 'name:arg1:arg2' -> display string; None when unknown or empty (the fixture is then skipped)."""
    name, *args = [p.strip() for p in str(spec).split(":")]
    fn = BINDINGS.get(name)
    if fn is None:
        return None
    try:
        val = fn(*args)
    except (TypeError, ValueError, KeyError, IndexError, AttributeError):
        return None
    if val is None or val == "":
        return None
    return str(val)


# ------------------------------------------------------------------ citation validation (all tiers)
def citation_exists(c: dict) -> bool:
    t, cid = c.get("type"), c.get("id")
    s = str(cid)
    if t == "initiative":
        return db.query_one("SELECT 1 AS x FROM initiatives WHERE (rddc = ? OR CAST(id AS TEXT) = ?) AND id > 0", (s, s)) is not None
    if t == "resource":
        return db.query_one("SELECT 1 AS x FROM resources WHERE CAST(id AS TEXT) = ? OR name = ?", (s, s)) is not None
    if t == "wbs_task":
        if "/" in s:
            rddc, code = s.split("/", 1)
            return db.query_one("SELECT 1 AS x FROM wbs_tasks t JOIN initiatives i ON i.id = t.initiative_id AND i.id > 0 WHERE i.rddc = ? AND t.wbs_code = ?",
                                (rddc, code)) is not None
        return db.query_one("SELECT 1 AS x FROM wbs_tasks WHERE CAST(id AS TEXT) = ?", (s,)) is not None
    if t == "change_request":
        return db.query_one("SELECT 1 AS x FROM change_requests WHERE crq_number = ? OR CAST(id AS TEXT) = ?", (s, s)) is not None
    if t == "risk":
        return db.query_one("SELECT 1 AS x FROM risks WHERE risk_code = ? OR CAST(id AS TEXT) = ?", (s, s)) is not None
    if t == "component":
        return db.query_one("SELECT 1 AS x FROM dc_components WHERE code = ? OR CAST(id AS TEXT) = ?", (s, s)) is not None
    if t in ("decision", "lesson", "meeting_note", "document"):
        table = {"decision": "decisions", "lesson": "lessons_learned", "meeting_note": "meeting_notes", "document": "documents"}[t]
        return db.query_one(f"SELECT 1 AS x FROM {table} WHERE CAST(id AS TEXT) = ?", (s,)) is not None
    if t == "prn":
        return db.query_one("SELECT 1 AS x FROM prn_budget WHERE prn_code = ?", (s,)) is not None
    if t == "grooming_session":
        return db.query_one("SELECT 1 AS x FROM grooming_sessions WHERE CAST(id AS TEXT) = ?", (s,)) is not None
    return t == "page"


# ------------------------------------------------------------------ live-mode tools (same data as the handlers)
def tool_search_initiatives(query: str = "", rag: str | None = None, stage: str | None = None, lob: str | None = None) -> list[dict]:
    q = (query or "").lower()
    out = []
    for r in initiatives_all():
        if q and q not in f"{r['rddc']} {r['name']} {r.get('description') or ''}".lower():
            continue
        if rag and rag_of(r) != rag or stage and r["stage"] != stage or lob and r.get("lob") != lob:
            continue
        out.append({k: r.get(k) for k in ("id", "rddc", "name", "lob", "stage", "status", "rag", "target_release", "readiness_date",
                                           "prod_date", "dc_pm_name", "l2_status", "l2_hours", "components")} | {"why": top_reason(r)})
    return out[:30]


def tool_get_initiative(rddc: str) -> dict:
    r = _init_by_key(rddc)
    if not r:
        return {"error": f"{rddc} not found"}
    return {**{k: v for k, v in r.items() if k not in ("health_cached_json",)}, "health": health_of(r)}


def tool_get_wbs(rddc: str) -> list[dict]:
    r = _init_by_key(rddc)
    if not r:
        return []
    return db.query("""SELECT t.wbs_code, t.step, t.phase, t.planned_start, t.planned_end, t.est_hours, t.allocation_pct, t.status, t.pct,
                              r.name AS resource_name FROM wbs_tasks t LEFT JOIN resources r ON r.id = t.resource_id
                        WHERE t.initiative_id = ? ORDER BY t.sort, t.wbs_code""", (r["id"],))


def tool_get_allocations(resource: str | None = None, month_from: str | None = None, month_to: str | None = None) -> list[dict]:
    today = C.get_today()
    month_from = month_from or _month_key(today)
    month_to = month_to or _add_months(month_from, 3)
    months = []
    m = month_from
    while m <= month_to and len(months) < 24:
        months.append(m)
        m = _add_months(m, 1)
    rows = util_rows(months)
    if resource:
        rows = [u for u in rows if resource.lower() in u["name"].lower() or str(u["resource_id"]) == str(resource)]
    return [{**u, "util_pct": round(u["util"] * 100, 1)} for u in rows]


def tool_find_resources(skills: list[str] | None = None, start: str | None = None, end: str | None = None, hours: float = 80) -> list[dict]:
    start = start or C.next_business_day(C.get_today()).isoformat()
    end = end or C.add_business_days(start, 40).isoformat()
    months = sorted(C.spread_hours(start, end, 1.0))
    pctx = {"bundle": _pseudo_bundle(months), "data": {"task_history": C._task_history()}, "initiative_id": None}
    return G.score_candidates(pctx, required=list(skills or []), team=None, start=start, end=end, hours=float(hours or 80),
                              exclude={}, component_code=None, phase="Development", continuity_ids=set(), limit=5)


def tool_get_risks(rddc: str | None = None, min_score: int = 0) -> list[dict]:
    sql = """SELECT k.risk_code, k.title, k.category, k.severity, k.likelihood, k.score, k.status, i.rddc, t.wbs_code
               FROM risks k JOIN initiatives i ON i.id = k.initiative_id AND i.id > 0 LEFT JOIN wbs_tasks t ON t.id = k.task_id
              WHERE k.score >= ?"""
    params: list[Any] = [int(min_score or 0)]
    if rddc:
        sql += " AND i.rddc = ?"
        params.append(rddc)
    return db.query(sql + " ORDER BY k.score DESC LIMIT 30", params)


def tool_get_crqs(date_from: str | None = None, date_to: str | None = None, rddc: str | None = None) -> list[dict]:
    t = C.get_today()
    date_from = date_from or t.isoformat()
    date_to = date_to or (t + timedelta(days=14)).isoformat()
    sql = """SELECT c.crq_number, c.crq_start, c.crq_end, c.release_type, c.release_train, c.sto_approval, c.implementation_status,
                    c.crq_approval_status, c.tech_validation_status, c.biz_validation_status, c.compliance_json, i.rddc, i.name
               FROM change_requests c JOIN initiatives i ON i.id = c.initiative_id AND i.id > 0 WHERE substr(c.crq_start, 1, 10) BETWEEN ? AND ?"""
    params: list[Any] = [date_from, date_to]
    if rddc:
        sql += " AND i.rddc = ?"
        params.append(rddc)
    return [C.parse_row(r) for r in db.query(sql + " ORDER BY c.crq_start", params)]


def tool_check_cr_compliance(crq: str) -> dict:
    cr = db.query_one("SELECT * FROM change_requests WHERE crq_number = ?", (crq,))
    if not cr:
        return {"error": f"{crq} not found"}
    return {"crq_number": crq, "flags": _cr_flags(cr)}


def tool_portfolio_stats(group_by: str = "stage") -> dict:
    out: dict[str, int] = {}
    for r in initiatives_all():
        k = {"lob": r.get("lob"), "stage": r["stage"], "rag": rag_of(r), "dc_pm": r.get("dc_pm_name"),
             "release": r.get("target_release")}.get(group_by, r["stage"]) or "Not set"
        out[k] = out.get(k, 0) + 1
    return out


def tool_get_skill_matrix(skill: str | None = None) -> list[dict]:
    rows = db.query("""SELECT r.id AS resource_id, r.name, r.team, s.name AS skill, rs.level FROM resource_skills rs
                        JOIN resources r ON r.id = rs.resource_id JOIN skills s ON s.id = rs.skill_id ORDER BY r.id, rs.level DESC""")
    if skill:
        rows = [x for x in rows if G.norm(skill) in G.norm(x["skill"])]
    return rows[:200]


def _schema(props: dict, required: tuple = ()) -> dict:
    return {"type": "object", "properties": props, "required": list(required)}


TOOLS: dict[str, tuple] = {
    "search_initiatives": (tool_search_initiatives, "Search initiatives by text and filter by RAG, stage or LOB.",
                           _schema({"query": {"type": "string"}, "rag": {"type": "string", "enum": ["Red", "Amber", "Green"]},
                                    "stage": {"type": "string"}, "lob": {"type": "string"}})),
    "get_initiative": (tool_get_initiative, "Get one initiative with its calculated health.", _schema({"rddc": {"type": "string"}}, ("rddc",))),
    "get_wbs": (tool_get_wbs, "Get the WBS plan rows of an initiative.", _schema({"rddc": {"type": "string"}}, ("rddc",))),
    "get_allocations": (tool_get_allocations, "Utilisation per person and month (YYYY-MM).",
                        _schema({"resource": {"type": "string"}, "month_from": {"type": "string"}, "month_to": {"type": "string"}})),
    "find_resources": (tool_find_resources, "Rank people for skills over a date window.",
                       _schema({"skills": {"type": "array", "items": {"type": "string"}}, "start": {"type": "string"},
                                "end": {"type": "string"}, "hours": {"type": "number"}})),
    "get_risks": (tool_get_risks, "Open and closed risks, optionally for one initiative.",
                  _schema({"rddc": {"type": "string"}, "min_score": {"type": "integer"}})),
    "get_crqs": (tool_get_crqs, "Change requests in a date window (YYYY-MM-DD).",
                 _schema({"date_from": {"type": "string"}, "date_to": {"type": "string"}, "rddc": {"type": "string"}})),
    "check_cr_compliance": (tool_check_cr_compliance, "Compliance flags of one CRQ.", _schema({"crq": {"type": "string"}}, ("crq",))),
    "portfolio_stats": (tool_portfolio_stats, "Count initiatives grouped by lob, stage, rag, dc_pm or release.",
                        _schema({"group_by": {"type": "string", "enum": ["lob", "stage", "rag", "dc_pm", "release"]}})),
    "get_skill_matrix": (tool_get_skill_matrix, "Skill levels (1-3) per person.", _schema({"skill": {"type": "string"}})),
}


def run_tool(name: str, args: dict) -> Any:
    fn = TOOLS[name][0]
    return fn(**{k: v for k, v in (args or {}).items() if v is not None})
