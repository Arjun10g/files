"""AI context building: engine adapters, initiative bundles, feature inputs, prompt context and input hash.

Every AI tier (live, fixture, generator) sees the same ``ctx`` dict built here:
``{feature, scope, initiative_id, today, inputs, bundle|None, subject|None, data, keys}``.
Numbers (L2, SA completeness, health, hours spread, business days) come from ``app.engines.*``
through the thin adapters below; the local fallbacks implement the same pinned rules
(master plan §1/§6) and are used only when an engine module is not installed yet.
"""
from __future__ import annotations

import hashlib
import importlib
import json
import logging
import math
from datetime import date, timedelta
from typing import Any

from app import db
from app.today import get_now, get_today, parse_date

log = logging.getLogger("bmo.ai.context")

# Fallback calendar data (single source is app/engines/calendar.py; used only when it is absent).
_FALLBACK_HOLIDAYS = {"2026-11-11", "2026-12-25", "2026-12-28", "2027-01-01", "2027-02-15"}
_FALLBACK_FREEZE = {"start": "2026-12-14", "end": "2027-01-08"}
_FALLBACK_TRAINS = [
    ("DC-2610", "2026-10-17"), ("DC-2611", "2026-11-21"), ("DC-2612", "2026-12-12"),
    ("DC-2701", "2027-01-16"), ("DC-2702", "2027-02-20"), ("DC-2703", "2027-03-20"),
]
SA_SECTIONS = ("Context", "Scope", "Impacted components", "Integration / sequence", "NFRs", "Security",
               "Data", "Backout", "Open questions resolved")
TEXT_LIMIT = 14000


# ------------------------------------------------------------------ engine adapters
def _engine(name: str):
    module_name = f"app.engines.{name}"
    try:
        return importlib.import_module(module_name)
    except ModuleNotFoundError as exc:
        if exc.name in (module_name, "app.engines"):
            return None
        raise


def _service(name: str):
    module_name = f"app.services.{name}"
    try:
        return importlib.import_module(module_name)
    except ModuleNotFoundError as exc:
        if exc.name in (module_name, "app.services"):
            return None
        raise


def to_date(value: Any) -> date:
    return parse_date(value)


def is_business_day(d: date | str) -> bool:
    d = to_date(d)
    cal = _engine("calendar")
    fn = getattr(cal, "is_business_day", None) if cal else None
    if fn is not None:
        return bool(fn(d))
    return d.weekday() < 5 and d.isoformat() not in _FALLBACK_HOLIDAYS


def next_business_day(d: date | str) -> date:
    d = to_date(d) + timedelta(days=1)
    while not is_business_day(d):
        d += timedelta(days=1)
    return d


def first_business_day_on_or_after(d: date | str) -> date:
    d = to_date(d)
    while not is_business_day(d):
        d += timedelta(days=1)
    return d


def add_business_days(d: date | str, n: int) -> date:
    """The n-th business day after ``d`` (n >= 0; n == 0 returns ``d`` rolled to a business day)."""
    d = first_business_day_on_or_after(d) if n == 0 else to_date(d)
    for _ in range(max(n, 0)):
        d = next_business_day(d)
    return d


def span_end(start: date | str, duration_bd: int) -> date:
    """Last business day of a task that starts on ``start`` and lasts ``duration_bd`` business days."""
    start = first_business_day_on_or_after(start)
    return add_business_days(start, max(duration_bd, 1) - 1) if duration_bd > 1 else start


def business_days_between(a: date | str, b: date | str) -> int:
    """Business days strictly between a and b (0 when b <= a + 1)."""
    a, b = to_date(a), to_date(b)
    count, d = 0, a + timedelta(days=1)
    while d < b:
        if is_business_day(d):
            count += 1
        d += timedelta(days=1)
    return count


def business_days_from(a: date | str, b: date | str) -> int:
    """Business days from a (exclusive) up to b (inclusive); negative when b < a."""
    a, b = to_date(a), to_date(b)
    if b == a:
        return 0
    sign, lo, hi = (1, a, b) if b > a else (-1, b, a)
    count, d = 0, lo + timedelta(days=1)
    while d <= hi:
        if is_business_day(d):
            count += 1
        d += timedelta(days=1)
    return sign * count


def freeze_window() -> dict:
    cal = _engine("calendar")
    if cal is not None and callable(getattr(cal, "freeze_window", None)):
        fz = cal.freeze_window()
        return {"start": str(fz["start"]), "end": str(fz["end"])}
    for attr in ("FREEZE", "CHANGE_FREEZE"):
        val = getattr(cal, attr, None) if cal else None
        if isinstance(val, dict) and val.get("start"):
            return {"start": str(val["start"]), "end": str(val["end"])}
        if isinstance(val, (tuple, list)) and len(val) == 2:
            return {"start": str(val[0]), "end": str(val[1])}
    return dict(_FALLBACK_FREEZE)


def in_freeze(d: date | str) -> bool:
    fz = freeze_window()
    return fz["start"] <= to_date(d).isoformat() <= fz["end"]


def release_trains() -> list[dict]:
    try:
        if db.db_ready() and db.table_exists("release_trains"):
            rows = db.query("SELECT code, train_date, status FROM release_trains ORDER BY train_date")
            if rows:
                return rows
    except Exception:
        log.debug("release_trains unavailable", exc_info=True)
    return [{"code": c, "train_date": d, "status": "Done" if c == "DC-2610" else "Planned"}
            for c, d in _FALLBACK_TRAINS]


def readiness_float_bd(readiness_date: Any, train_date: Any) -> int | None:
    """Business days strictly between readiness and the train; negative (business days late) when missed.
    Same rule as the gantt and health engines (engines.schedule.readiness_float)."""
    if not readiness_date or not train_date:
        return None
    eng = _engine("schedule")
    if eng is not None and hasattr(eng, "readiness_float"):
        return eng.readiness_float(str(readiness_date)[:10], str(train_date)[:10])
    r, t = to_date(readiness_date), to_date(train_date)
    if r < t:
        return business_days_between(r, t)
    return -(business_days_from(t, r) + (1 if is_business_day(t) else 0))


def initiative_float(ini: dict) -> int | None:
    """Readiness float exactly as Pg 2 and Health show it: the health engine's own metric when cached, else the
    engine rule against the target release train date (never the plan's own production date)."""
    health = ini.get("health_cached_json")
    if isinstance(health, str):
        health = db.from_json(health, None)
    metric = (((health or {}).get("dimensions") or {}).get("schedule") or {}).get("metrics", {}).get("float_bd") \
        if isinstance(health, dict) else None
    if isinstance(metric, int):
        return metric
    train_date = None
    if ini.get("target_release"):
        train_date = next((t["train_date"] for t in release_trains() if t["code"] == ini["target_release"]), None)
    return readiness_float_bd(ini.get("readiness_date"), train_date or ini.get("prod_date"))


def spread_hours(start: date | str, end: date | str, hours: float) -> dict[str, float]:
    cap = _engine("capacity")
    fn = getattr(cap, "spread_hours", None) if cap else None
    if fn is not None:
        return {str(k): float(v) for k, v in fn(to_date(start).isoformat(), to_date(end).isoformat(), hours).items()}
    start, end = to_date(start), to_date(end)
    days = []
    d = start
    while d <= end:
        if is_business_day(d):
            days.append(d)
        d += timedelta(days=1)
    if not days:
        return {start.strftime("%Y-%m"): round(float(hours), 1)}
    per = hours / len(days)
    months: dict[str, float] = {}
    for d in days:
        key = d.strftime("%Y-%m")
        months[key] = months.get(key, 0.0) + per
    keys = sorted(months)
    out = {k: round(months[k], 1) for k in keys}
    out[keys[-1]] = round(hours - sum(out[k] for k in keys[:-1]), 1)
    return out


def sa_score(text: str | None) -> dict:
    text = text or ""
    eng = _engine("sa_completeness")
    if eng is not None and hasattr(eng, "score"):
        res = dict(eng.score(text))
        res.setdefault("missing", [])
        return res
    lowered = text.lower()
    checks = {
        "Context": ("business context", "background", "context"),
        "Scope": ("scope",),
        "Impacted components": ("impacted component", "components"),
        "Integration / sequence": ("integration", "sequence"),
        "NFRs": ("non-functional", "nfr", "latency", "availability"),
        "Security": ("security",),
        "Data": ("data",),
        "Backout": ("backout", "back-out", "rollback plan"),
        "Open questions resolved": ("open items", "open questions"),
    }
    missing = [name for name, keys in checks.items() if not any(k in lowered for k in keys)]
    found = 9 - len(missing)
    return {"completeness": math.floor(found / 9 * 100), "sections_found": found, "missing": missing,
            "author": None, "version": None}


def tshirt(total: float) -> str:
    if total < 100:
        return "XS"
    if total <= 300:
        return "S"
    if total <= 700:
        return "M"
    if total <= 1500:
        return "L"
    return "XL"


def component_dev_hours(comp: dict, catalog_by_code: dict) -> float:
    if comp.get("est_hours") not in (None, ""):
        return float(comp["est_hours"])
    cat = catalog_by_code.get(comp.get("code") or comp.get("component_code"), {})
    return float(cat.get(f"base_hours_{(comp.get('complexity') or 'Medium').lower()}", 0) or 0)


def l2_estimate(components: list[dict], catalog: list[dict]) -> dict:
    """Engine L2 numbers normalised to the contracts.md L2Estimate shape."""
    eng = _engine("l2")
    if eng is not None and hasattr(eng, "estimate_l2"):
        res = eng.estimate_l2(components, catalog)
        res = dict(res) if not isinstance(res, dict) else res
        if "total_hours" in res:
            return res
    by_code = {c["code"]: c for c in catalog}
    by_component = []
    for comp in components:
        code = comp.get("code") or comp.get("component_code")
        by_component.append({"code": code, "name": by_code.get(code, {}).get("name", code),
                             "complexity": comp.get("complexity") or "Medium",
                             "hours": component_dev_hours(comp, by_code)})
    dev = round(sum(c["hours"] for c in by_component), 1)
    arch, qa, pm = round(dev * 0.10, 1), round(dev * 0.35, 1), round(dev * 0.10, 1)
    subtotal = round(dev + arch + qa + pm, 1)
    total = float(round(subtotal * 1.15 / 50) * 50)
    return {"dev_hours": dev, "architecture_hours": arch, "qa_hours": qa, "pm_release_hours": pm,
            "subtotal": subtotal, "contingency_hours": round(subtotal * 0.15),
            "total_hours": total, "low_hours": round(total * 0.75), "high_hours": round(total * 1.25),
            "tshirt": tshirt(total), "by_component": by_component,
            "rule": "Dev = catalogue hours by complexity; + Architecture 10%, QA 35%, PM/Release 10%; "
                    "+15% contingency; rounded to nearest 50 h; range ±25%."}


def compute_health(bundle: dict) -> dict | None:
    eng = _engine("health")
    if eng is not None and hasattr(eng, "compute_health"):
        return eng.compute_health(bundle, to_date(bundle.get("today") or get_today()))
    cached = (bundle.get("initiative") or {}).get("health_cached_json")
    if isinstance(cached, str):
        cached = db.from_json(cached)
    return cached if isinstance(cached, dict) else None


STO_STATES = ("Ready for Go", "Tentative", "Not ready", "Not requested")


def sto_status(value: Any) -> str | None:
    """STO readiness as a status string, whether the engine returns a string or {status, suggest_from, label}."""
    if isinstance(value, dict):
        value = value.get("status")
    return value if value in STO_STATES else None


def check_cr(cr: dict, context: dict | None = None) -> dict | None:
    """Live compliance exactly as Pg 4 and Change Management show it (derive.compliance_for adds the plan rules)."""
    row = dict(cr)
    for key in ("affected_cis", "impacted_components"):
        if isinstance(row.get(key), str):
            row[key] = db.from_json(row[key], [])
    derive = _service("derive")
    if derive is not None and hasattr(derive, "compliance_for"):
        return derive.compliance_for(row)
    eng = _engine("compliance")
    if eng is None or not hasattr(eng, "check_cr"):
        return None
    return eng.check_cr(row, get_today(), context or {})


# ------------------------------------------------------------------ bundles
def load_bundle(initiative_id: int) -> dict:
    try:
        from app import repo
    except ModuleNotFoundError as exc:
        if exc.name not in ("app.repo",):
            raise
        return _fallback_bundle(initiative_id)
    return repo.get_initiative_bundle(initiative_id)


_JSON_COLS = ("labels", "keywords", "affected_cis", "impacted_components", "cc_names", "attendees", "tags",
              "components")


def parse_row(row: dict | None) -> dict | None:
    if row is None:
        return None
    out = dict(row)
    for k, v in row.items():
        if (k.endswith("_json") or k in _JSON_COLS) and isinstance(v, str):
            out[k] = db.from_json(v, v)
    return out


def _fallback_bundle(iid: int) -> dict:
    """Bundle per contracts.md §3, used only when app.repo is not installed."""
    from app.errors import not_found

    ini = parse_row(db.query_one(
        """SELECT i.*, rq.name AS requestor_name, a.name AS assigned_to_name, pm.name AS pm_name,
                  tl.name AS tech_lead_name, dp.name AS dc_pm_name, sa.name AS dc_sa_name
             FROM initiatives i
             LEFT JOIN resources rq ON rq.id = i.requestor_id LEFT JOIN resources a ON a.id = i.assigned_to_id
             LEFT JOIN resources pm ON pm.id = i.pm_id LEFT JOIN resources tl ON tl.id = i.tech_lead_id
             LEFT JOIN resources dp ON dp.id = i.dc_pm_id LEFT JOIN resources sa ON sa.id = i.dc_sa_id
            WHERE i.id = ?""", (iid,)))
    if ini is None:
        raise not_found("Initiative", iid)
    components = db.query(
        """SELECT ic.*, c.code, c.name, r.name AS component_lead_name FROM initiative_components ic
             JOIN dc_components c ON c.id = ic.component_id LEFT JOIN resources r ON r.id = ic.component_lead_id
            WHERE ic.initiative_id = ? ORDER BY ic.sort, ic.id""", (iid,))
    tasks = db.query(
        """SELECT t.*, o.name AS owner_name, r.name AS resource_name, c.code AS component_code
             FROM wbs_tasks t LEFT JOIN resources o ON o.id = t.owner_id LEFT JOIN resources r ON r.id = t.resource_id
             LEFT JOIN initiative_components ic ON ic.id = t.initiative_component_id
             LEFT JOIN dc_components c ON c.id = ic.component_id
            WHERE t.initiative_id = ? ORDER BY t.sort, t.wbs_code""", (iid,))
    code_by_id = {t["id"]: t["wbs_code"] for t in tasks}
    deps: dict[int, list[int]] = {}
    for d in db.query("""SELECT d.task_id, d.depends_on_task_id FROM wbs_dependencies d
                           JOIN wbs_tasks t ON t.id = d.task_id WHERE t.initiative_id = ?""", (iid,)):
        deps.setdefault(d["task_id"], []).append(d["depends_on_task_id"])
    for t in tasks:
        t["depends_on"] = sorted(deps.get(t["id"], []))
        t["depends_on_codes"] = [code_by_id[x] for x in t["depends_on"] if x in code_by_id]
    allocations = db.query("SELECT resource_id, task_id, month, hours, firmness FROM allocations WHERE initiative_id = ?",
                           (iid,))
    referenced = {x for t in tasks for x in (t["owner_id"], t["resource_id"]) if x}
    referenced |= {ini.get(k) for k in ("requestor_id", "dc_pm_id", "dc_sa_id", "tech_lead_id", "pm_id") if ini.get(k)}
    res_rows = [r for r in db.query("SELECT * FROM resources WHERE active = 1 ORDER BY id")
                if r["capacity_eligible"] or r["id"] in referenced]
    avail: dict[int, dict] = {}
    for a in db.query("SELECT resource_id, month, available_hours FROM resource_availability"):
        avail.setdefault(a["resource_id"], {})[a["month"]] = a["available_hours"]
    committed: dict[int, dict] = {}
    for a in db.query("SELECT resource_id, month, SUM(hours) AS h FROM allocations GROUP BY resource_id, month"):
        committed.setdefault(a["resource_id"], {})[a["month"]] = round(a["h"], 1)
    skills: dict[int, list] = {}
    for s in db.query("""SELECT rs.resource_id, s.name AS skill, rs.level FROM resource_skills rs
                           JOIN skills s ON s.id = rs.skill_id ORDER BY rs.level DESC, s.name"""):
        skills.setdefault(s["resource_id"], []).append({"skill": s["skill"], "level": s["level"]})
    resources = [{
        "id": r["id"], "name": r["name"], "role": r["role"], "team": r["team"], "team_label": r["team_label"],
        "component_id": r["component_id"], "capacity_eligible": r["capacity_eligible"],
        "default_monthly_hours": r["default_monthly_hours"], "availability": avail.get(r["id"], {}),
        "committed": committed.get(r["id"], {}), "skills": skills.get(r["id"], []),
    } for r in res_rows]
    risks = db.query("""SELECT k.*, r.name AS owner_name, t.wbs_code FROM risks k LEFT JOIN resources r ON r.id = k.owner_id
                          LEFT JOIN wbs_tasks t ON t.id = k.task_id WHERE k.initiative_id = ? ORDER BY k.id""", (iid,))
    crs = [parse_row(c) for c in db.query("SELECT * FROM change_requests WHERE initiative_id = ? ORDER BY id", (iid,))]
    for c in crs:
        c["compliance"] = c.get("compliance_json") or check_cr(c) or {"ok": True, "flags": []}
    prn = None
    if ini.get("prn_code"):
        prn = db.query_one("SELECT * FROM prn_budget WHERE prn_code = ?", (ini["prn_code"],))
        if prn:
            prn["charges"] = db.query("SELECT month, charged_hours, charged_amount FROM prn_charges WHERE prn_code = ? "
                                      "ORDER BY month", (ini["prn_code"],))
    attachments = db.query("SELECT id, initiative_id, entity_type, entity_id, kind, filename, stored_path, mime, "
                           "size_bytes, version, uploaded_by, uploaded_at FROM attachments WHERE initiative_id = ?", (iid,))
    grooming = db.query_one("""SELECT s.id AS session_id, s.session_date, s.start_time, g.status FROM grooming_slots g
                                 JOIN grooming_sessions s ON s.id = g.session_id WHERE g.initiative_id = ?
                                ORDER BY s.session_date LIMIT 1""", (iid,))
    scope_changes = [{"ts": a["ts"], "action": a["action"], "component_code": (db.from_json(a["detail_json"], {}) or {}).get("component_code"),
                      "detail": db.from_json(a["detail_json"], {})}
                     for a in db.query("SELECT ts, action, detail_json FROM activity_log WHERE initiative_id = ? "
                                       "AND action = 'scope_change' ORDER BY id", (iid,))]
    train = None
    if ini.get("target_release"):
        train = db.query_one("SELECT code, train_date FROM release_trains WHERE code = ?", (ini["target_release"],))
    sa_text = None
    if ini.get("sa_doc_attachment_id"):
        sa_text = db.scalar("SELECT extracted_text FROM attachments WHERE id = ?", (ini["sa_doc_attachment_id"],))
    return {"initiative": ini, "components": components, "tasks": tasks, "allocations": allocations,
            "resources": resources, "risks": risks, "change_requests": crs, "prn": prn, "attachments": attachments,
            "grooming": grooming, "scope_changes": scope_changes, "target_train": train,
            "component_catalog": component_catalog(), "sa_doc_text": sa_text,
            "today": get_today().isoformat(), "now": get_now().isoformat()}


def component_catalog() -> list[dict]:
    rows = [parse_row(r) for r in db.query("SELECT * FROM dc_components ORDER BY id")]
    down: dict[int, list[str]] = {}
    for d in db.query("""SELECT d.from_component_id, c.code FROM component_dependencies d
                           JOIN dc_components c ON c.id = d.to_component_id ORDER BY c.id"""):
        down.setdefault(d["from_component_id"], []).append(d["code"])
    for r in rows:
        r["keywords"] = r.get("keywords") if isinstance(r.get("keywords"), list) else []
        r["downstream"] = down.get(r["id"], [])
    return rows


# ------------------------------------------------------------------ shared portfolio data
def resource_rows(eligible_only: bool = True) -> list[dict]:
    sql = "SELECT * FROM resources WHERE active = 1" + (" AND capacity_eligible = 1" if eligible_only else "") + " ORDER BY id"
    return db.query(sql)


def resource_skills_map() -> dict[int, list[dict]]:
    out: dict[int, list[dict]] = {}
    for s in db.query("""SELECT rs.resource_id, s.name AS skill, rs.level, rs.source, rs.evidence FROM resource_skills rs
                           JOIN skills s ON s.id = rs.skill_id ORDER BY rs.level DESC, s.name"""):
        out.setdefault(s["resource_id"], []).append({"skill": s["skill"], "level": s["level"], "source": s["source"],
                                                     "evidence": s["evidence"]})
    return out


def utilisation(months: list[str] | None = None) -> dict[int, dict[str, dict]]:
    """{resource_id: {month: {available, allocated, util}}} across all initiatives (capacity-tracked people)."""
    people = resource_rows()
    avail: dict[tuple, float] = {(a["resource_id"], a["month"]): a["available_hours"]
                                 for a in db.query("SELECT resource_id, month, available_hours FROM resource_availability")}
    alloc: dict[tuple, float] = {(a["resource_id"], a["month"]): a["h"] for a in db.query(
        "SELECT resource_id, month, SUM(hours) AS h FROM allocations GROUP BY resource_id, month")}
    all_months = sorted({m for (_, m) in avail} | {m for (_, m) in alloc})
    if months:
        all_months = [m for m in all_months if m in months] or list(months)
    out: dict[int, dict[str, dict]] = {}
    for p in people:
        row = {}
        for m in all_months:
            a = avail.get((p["id"], m), p["default_monthly_hours"] or 140)
            h = round(alloc.get((p["id"], m), 0.0), 1)
            row[m] = {"available": a, "allocated": h, "util": (h / a) if a else 0.0}
        out[p["id"]] = row
    return out


def portfolio_rows(include_closed: bool = True) -> list[dict]:
    rows = [parse_row(r) for r in db.query(
        """SELECT i.id, i.rddc, i.name, i.lob, i.stage, i.status, i.priority, i.labels, i.description,
                  i.rag_cached, i.health_cached_json, i.target_release, i.readiness_date, i.qa_date, i.prod_date,
                  i.planned_start, i.planned_end, i.l2_status, i.l2_hours, i.l2_submitted_at, i.l2_reminders_sent,
                  i.sa_completeness, i.sa_missing_json, i.prn_code, i.dc_pm_id, i.dc_sa_id, i.requestor_id,
                  i.requestor, i.tech_lead_id, i.comments, i.created_at,
                  dp.name AS dc_pm_name, sa.name AS dc_sa_name, rq.name AS requestor_name
             FROM initiatives i LEFT JOIN resources dp ON dp.id = i.dc_pm_id
             LEFT JOIN resources sa ON sa.id = i.dc_sa_id LEFT JOIN resources rq ON rq.id = i.requestor_id
            WHERE i.id > 0 ORDER BY i.rddc""")]
    comps: dict[int, list[str]] = {}
    for c in db.query("""SELECT ic.initiative_id, c.code FROM initiative_components ic
                           JOIN dc_components c ON c.id = ic.component_id ORDER BY ic.sort, ic.id"""):
        comps.setdefault(c["initiative_id"], []).append(c["code"])
    for r in rows:
        r["components"] = comps.get(r["id"], [])
        r["rag"] = r.get("rag_cached")
    if not include_closed:
        rows = [r for r in rows if r["stage"] != "Closed"]
    return rows


# ------------------------------------------------------------------ feature context
def _text_from_inputs(inputs: dict) -> tuple[str | None, str | None]:
    """(text, label) from options.text or options.attachment_id."""
    if inputs.get("attachment_id"):
        row = db.query_one("SELECT filename, extracted_text FROM attachments WHERE id = ?", (int(inputs["attachment_id"]),))
        if row and row.get("extracted_text"):
            return row["extracted_text"], row["filename"]
    if inputs.get("text"):
        return str(inputs["text"]), inputs.get("filename") or "Pasted text"
    return None, None


def _completed_history() -> list[dict]:
    """Closed/completed initiatives with components and actual hours (PRN charges, else planned)."""
    out = []
    for r in portfolio_rows():
        if r["stage"] != "Closed" and r["status"] != "Completed":
            continue
        actual = None
        if r.get("prn_code"):
            actual = db.scalar("SELECT SUM(charged_hours) FROM prn_charges WHERE prn_code = ?", (r["prn_code"],))
        if not actual:
            actual = db.scalar("SELECT SUM(est_hours) FROM wbs_tasks WHERE initiative_id = ?", (r["id"],)) or r.get("l2_hours")
        out.append({"id": r["id"], "rddc": r["rddc"], "name": r["name"], "components": r["components"],
                    "actual_hours": round(float(actual or 0), 1), "l2_hours": r.get("l2_hours")})
    return out


def _task_history() -> list[dict]:
    return db.query(
        """SELECT t.id, t.initiative_id, i.rddc, i.name AS initiative_name, i.stage, t.wbs_code, t.step, t.description,
                  t.phase, t.resource_id, t.est_hours, t.status, t.planned_start, t.planned_end, t.baseline_end,
                  t.actual_end, c.code AS component_code
             FROM wbs_tasks t JOIN initiatives i ON i.id = t.initiative_id AND i.id > 0
             LEFT JOIN initiative_components ic ON ic.id = t.initiative_component_id
             LEFT JOIN dc_components c ON c.id = ic.component_id
            WHERE t.resource_id IS NOT NULL ORDER BY i.rddc, t.sort, t.wbs_code""")


def _people() -> list[dict]:
    return db.query("SELECT id, name, role, team, team_label, capacity_eligible, component_id FROM resources "
                    "WHERE active = 1 ORDER BY id")


def build_context(feature: str, initiative_id: int | None, inputs: dict | None) -> dict:
    inputs = dict(inputs or {})
    today = get_today().isoformat()
    ctx: dict[str, Any] = {"feature": feature, "initiative_id": initiative_id, "today": today, "inputs": inputs,
                           "bundle": None, "subject": None, "data": {}, "scope": "initiative" if initiative_id else "portfolio",
                           "keys": {}}
    if feature == "lessons" and not initiative_id and inputs.get("initiative_id"):
        initiative_id = int(inputs["initiative_id"])
        ctx["initiative_id"] = initiative_id
        ctx["scope"] = "initiative"
    if feature == "assistant":
        ctx["scope"] = "portfolio"
        ctx["keys"] = {"name": str(inputs.get("message") or "")[:120]}
        return ctx
    if initiative_id:
        bundle = load_bundle(int(initiative_id))
        text, label = _text_from_inputs(inputs)
        if text and feature in ("change_summary", "intake_analysis", "intake_autofill"):
            bundle = {**bundle, "sa_doc_text": text}
            ctx["data"]["sa_label"] = label
        ctx["bundle"] = bundle
        ini = bundle["initiative"]
        ctx["keys"] = {"rddc": ini["rddc"], "name": ini["name"]}
        ctx["data"]["people_rows"] = _people()
    data = ctx["data"]
    if feature == "intake_analysis":
        if not initiative_id:
            text, label = _text_from_inputs(inputs)
            ctx["scope"] = "draft"
            ctx["subject"] = {k: inputs.get(k) for k in ("name", "description", "lob", "requestor", "priority", "labels",
                                                         "prn_code", "dc_sa_name", "target_release", "requested_go_live",
                                                         "dc_intake")}
            ctx["subject"]["sa_text"] = text
            title = next((ln.strip() for ln in (text or "").splitlines() if ln.strip()), "")
            ctx["keys"] = {"name": f"{inputs.get('name') or ''} {label or ''} {title[:160]}".strip()}
        data["others"] = [r for r in portfolio_rows() if r["id"] != initiative_id]
        data["catalog"] = component_catalog()
    elif feature == "l2_estimate":
        data["history"] = _completed_history()
    elif feature in ("wbs",):
        data["trains"] = release_trains()
    elif feature in ("resources", "rebalance", "risks"):
        data["task_history"] = _task_history()
        data["trains"] = release_trains()
    elif feature == "cr_compliance":
        crs = ctx["bundle"]["change_requests"] if ctx["bundle"] else []
        cid = inputs.get("change_request_id")
        cr = next((c for c in crs if cid is not None and c["id"] == int(cid)), None) or (crs[0] if crs else None)
        if cr is None and cid:
            cr = parse_row(db.query_one("SELECT * FROM change_requests WHERE id = ?", (int(cid),)))
        data["cr"] = cr
        data["trains"] = release_trains()
        data["people"] = {p["id"]: p["name"] for p in _people()}
        if cr:
            ctx["keys"]["name"] = cr.get("crq_number") or ctx["keys"].get("name", "")
            ctx["keys"]["crq"] = cr.get("crq_number")
            data["attachments"] = {a["id"]: a for a in db.query(
                "SELECT id, kind, filename FROM attachments WHERE initiative_id = ?", (cr["initiative_id"],))}
    elif feature == "exec_summary":
        if not initiative_id:
            ctx["keys"] = {"name": "portfolio"}
            data["portfolio"] = portfolio_rows()
            data["utilisation"] = utilisation()
            data["people"] = {p["id"]: p["name"] for p in _people()}
        data["change_requests"] = [parse_row(c) for c in db.query(
            """SELECT c.*, i.rddc, i.name AS initiative_name FROM change_requests c JOIN initiatives i ON i.id = c.initiative_id AND i.id > 0
                ORDER BY c.crq_start""")]
        data["risks"] = db.query("""SELECT k.*, i.rddc FROM risks k JOIN initiatives i ON i.id = k.initiative_id AND i.id > 0
                                     WHERE k.status != 'Closed' ORDER BY k.score DESC, k.id""")
        data["trains"] = release_trains()
        data["recent_runs"] = db.query("""SELECT feature, initiative_id, status FROM ai_runs WHERE status = 'accepted'
                                           ORDER BY id DESC LIMIT 50""")
    elif feature == "skill_matrix":
        ctx["keys"] = {"name": "portfolio"}
        data["task_history"] = _task_history()
        data["resources"] = resource_rows()
        data["declared"] = resource_skills_map()
    elif feature == "nudges":
        ctx["keys"] = {"name": "portfolio"}
        data["portfolio"] = portfolio_rows(include_closed=False)
        data["pending_components"] = db.query(
            """SELECT ic.id, ic.initiative_id, i.rddc, i.name AS initiative_name, c.code, c.name AS component_name,
                      COALESCE(ic.component_lead_id, c.component_lead_id) AS lead_id, r.name AS lead_name, r.role AS lead_role
                 FROM initiative_components ic JOIN initiatives i ON i.id = ic.initiative_id AND i.id > 0
                 JOIN dc_components c ON c.id = ic.component_id
                 LEFT JOIN resources r ON r.id = COALESCE(ic.component_lead_id, c.component_lead_id)
                WHERE ic.approval = 'Pending' AND i.stage != 'Closed' ORDER BY i.rddc, c.id""")
        data["change_requests"] = [parse_row(c) for c in db.query(
            """SELECT c.*, i.rddc, i.name AS initiative_name FROM change_requests c JOIN initiatives i ON i.id = c.initiative_id AND i.id > 0
                ORDER BY c.crq_start""")]
        data["people"] = {p["id"]: p for p in _people()}
        data["existing_keys"] = {r["dedupe_key"]: {"status": r["status"], "ai": r["ai_run_id"] is not None} for r in db.query(
            "SELECT dedupe_key, status, ai_run_id FROM notifications WHERE dedupe_key IS NOT NULL")}
    elif feature == "meeting_extract":
        note = None
        if inputs.get("meeting_note_id"):
            note = parse_row(db.query_one("SELECT * FROM meeting_notes WHERE id = ?", (int(inputs["meeting_note_id"]),)))
        text = inputs.get("text") or (note or {}).get("notes_md") or ""
        data["note"] = note
        data["text"] = str(text)
        data["people"] = _people()
        data["initiatives"] = db.query("SELECT id, rddc, name FROM initiatives WHERE id > 0 ORDER BY rddc")
        ctx["keys"] = {"name": (note or {}).get("title") or (str(text).strip().splitlines() or [""])[0][:120]}
        if note and note.get("initiative_id") and not initiative_id:
            rddc = db.scalar("SELECT rddc FROM initiatives WHERE id = ?", (note["initiative_id"],))
            if rddc:
                ctx["keys"]["rddc"] = rddc
        ctx["scope"] = "portfolio"
    elif feature == "lessons":
        data["lessons"] = [parse_row(r) for r in db.query(
            """SELECT l.*, i.rddc, i.name AS initiative_name FROM lessons_learned l
                 LEFT JOIN initiatives i ON i.id = l.initiative_id AND i.id > 0 ORDER BY l.id""")]
        if initiative_id:
            data["decisions"] = db.query("SELECT * FROM decisions WHERE initiative_id = ? ORDER BY decided_on, id",
                                         (initiative_id,))
        else:
            ctx["keys"] = {"name": "portfolio"}
            data["portfolio"] = portfolio_rows()
    elif feature == "intake_autofill":
        text, label = _text_from_inputs(inputs)
        if text is None and ctx["bundle"]:
            text, label = ctx["bundle"].get("sa_doc_text"), "SA document"
        data["text"] = text or ""
        data["label"] = label or "SA document"
        data["catalog"] = component_catalog()
        data["people"] = _people()
        data["trains"] = release_trains()
        data["intakes"] = db.query("SELECT * FROM dc_intakes ORDER BY code") if db.table_exists("dc_intakes") else []
        title = next((ln.strip() for ln in (text or "").splitlines() if ln.strip()), "")
        ctx["keys"] = {**ctx["keys"], "name": f"{label or ''} {title[:160]}".strip()}
        ctx["scope"] = "draft" if not initiative_id else "initiative"
    return ctx


# ------------------------------------------------------------------ prompt context + hash
_TASK_KEYS = ("wbs_code", "parent_id", "step", "phase", "description", "owner_id", "owner_name", "resource_id",
              "resource_name", "component_code", "planned_start", "planned_end", "baseline_end", "est_hours",
              "allocation_pct", "status", "pct", "is_milestone", "depends_on_codes")
_INI_KEYS = ("id", "rddc", "name", "lob", "priority", "stage", "status", "labels", "requestor", "requestor_name",
             "dc_pm_name", "dc_sa_id", "dc_sa_name", "tech_lead_name", "description", "prn_code", "requested_go_live",
             "target_release", "planned_start", "planned_end", "readiness_date", "qa_date", "prod_date",
             "sa_author", "sa_version", "sa_completeness", "sa_missing_json", "l2_hours", "l2_low_hours",
             "l2_high_hours", "l2_tshirt", "l2_status", "l2_approved_at", "rag_cached")


def compact(ctx: dict) -> dict:
    """Prompt-sized, deterministic view of the context (also the basis of the input hash)."""
    out: dict[str, Any] = {"feature": ctx["feature"], "today": ctx["today"], "scope": ctx["scope"],
                           "inputs": {k: v for k, v in sorted(ctx["inputs"].items()) if k not in ("text",)}}
    b = ctx.get("bundle")
    if b:
        ini = b["initiative"]
        out["initiative"] = {k: ini.get(k) for k in _INI_KEYS}
        out["components"] = [{k: c.get(k) for k in ("code", "name", "approval", "complexity", "est_hours",
                                                     "change_summary", "component_lead_id", "component_lead_name")}
                             for c in b.get("components", [])]
        out["tasks"] = [{k: t.get(k) for k in _TASK_KEYS} for t in b.get("tasks", [])]
        out["resources"] = [{k: r.get(k) for k in ("id", "name", "role", "team", "team_label", "capacity_eligible",
                                                    "availability", "committed", "skills")}
                            for r in b.get("resources", [])]
        out["allocations"] = b.get("allocations", [])
        out["risks"] = [{k: r.get(k) for k in ("risk_code", "title", "category", "severity", "likelihood", "status",
                                                "wbs_code", "owner_name")} for r in b.get("risks", [])]
        out["change_requests"] = [{k: c.get(k) for k in ("id", "crq_number", "crq_start", "crq_end", "release_type",
                                                          "release_train", "sto_approval", "implementation_status",
                                                          "crq_approval_status", "tech_validation_status",
                                                          "biz_validation_status", "compliance")}
                                  for c in b.get("change_requests", [])]
        out["prn"] = b.get("prn")
        out["target_train"] = b.get("target_train")
        out["component_catalog"] = [{k: c.get(k) for k in ("id", "code", "name", "team", "component_lead_id",
                                                            "keywords", "base_hours_low", "base_hours_medium",
                                                            "base_hours_high", "downstream")}
                                    for c in b.get("component_catalog", [])]
        out["sa_doc_text"] = (b.get("sa_doc_text") or "")[:TEXT_LIMIT] or None
        out["scope_changes"] = b.get("scope_changes", [])
    if ctx.get("subject"):
        out["subject"] = {k: (v[:TEXT_LIMIT] if isinstance(v, str) else v) for k, v in ctx["subject"].items()}
    data = ctx.get("data") or {}
    for key, val in data.items():
        if key in ("existing_keys",):
            continue
        if key == "text":
            out["text"] = str(val)[:TEXT_LIMIT]
        elif key == "utilisation":
            out["utilisation"] = {str(rid): {m: round(c["util"] * 100, 1) for m, c in months.items()}
                                  for rid, months in val.items()}
        else:
            out[key] = val
    if ctx["inputs"].get("text") and "text" not in out:
        out["text"] = str(ctx["inputs"]["text"])[:TEXT_LIMIT]
    return json.loads(json.dumps(out, default=str, sort_keys=True))


def input_hash(ctx: dict) -> str:
    payload = json.dumps(compact(ctx), sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]
