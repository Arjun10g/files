"""The single entry point for every AI feature: ``run_feature``.

build context -> choose tier (live when allowed, else simulated) -> validate -> fall back -> post-validate
(ids exist, owners exist, engine numbers kept, hours sum) -> write ``ai_runs`` -> return the AiRun envelope.
Nothing is written to domain tables here; ``apply.apply_run`` does that when the user accepts.
"""
from __future__ import annotations

import logging
import re
import time
from typing import Any

from app import db
from app.ai import claude, generators, simulated
from app.ai import context as C
from app.ai.prompts import PROMPT_VERSION
from app.ai.schemas import COMPONENT_NAMES, FEATURES, SCHEMAS, validate
from app.errors import ApiError, not_found
from app.today import now_iso

log = logging.getLogger("bmo.ai.provider")

MODE_LABELS = {"simulated_fixture": "Simulated AI · prepared response", "simulated_generated": "Simulated AI · rules engine",
               "live": "Live Claude", "live_fallback": "Live → Simulated"}
LIVE_BUDGET_S = 20.0


# ------------------------------------------------------------------ settings
def setting(key: str, default: str | None = None) -> str | None:
    try:
        row = db.query_one("SELECT value FROM app_settings WHERE key = ?", (key,))
    except Exception:  # noqa: BLE001 - settings table missing during early boot
        return default
    return row["value"] if row and row.get("value") not in (None, "") else default


def ai_mode() -> str:
    mode = setting("ai_mode")
    if mode in ("auto", "simulated", "live"):
        return mode
    return claude._config().get("AI_MODE") or "auto"


def live_allowed(force_mode: str | None = None) -> bool:
    if force_mode == "simulated":
        return False
    mode = force_mode or ai_mode()
    return mode in ("auto", "live") and claude.api_key_present()


def actor() -> str:
    return setting("persona", "DC PM") or "DC PM"


# ------------------------------------------------------------------ post-validators
def _ids(table: str, col: str = "id") -> set:
    return {r[col] for r in db.query(f"SELECT {col} FROM {table}")}


def _initiative_facts() -> dict[str, dict]:
    rows = {r["rddc"]: dict(r, components=[]) for r in db.query(
        "SELECT id, rddc, stage, status, l2_hours, l2_baseline_hours FROM initiatives WHERE id > 0")}
    by_id = {r["id"]: r for r in rows.values()}
    for c in db.query("SELECT ic.initiative_id, c.code FROM initiative_components ic JOIN dc_components c ON c.id = ic.component_id"):
        if c["initiative_id"] in by_id:
            by_id[c["initiative_id"]]["components"].append(c["code"])
    return rows


def _fix_comparables(out: dict, mine: list[str]) -> None:
    """Decision 8: one Jaccard score per pair everywhere; an undelivered comparable shows its approved L2, never 'actual'."""
    facts = _initiative_facts()
    keep = []
    for c in out.get("comparables", []):
        f = facts.get(c["rddc"])
        if f is None:
            continue
        c["similarity"] = generators.component_similarity(mine, f["components"])
        delivered = f["stage"] == "Closed" or f["status"] == "Completed"
        if not delivered:
            approved = float(f.get("l2_baseline_hours") or f.get("l2_hours") or 0)
            c["actual_hours"] = approved
            c["note"] = generators.clip(f"Approved L2 {generators.fmt_hours(approved)} (in delivery)", 300)
        keep.append(c)
    keep.sort(key=lambda c: (-c["similarity"], c["rddc"]))
    out["comparables"] = keep[:5]


def post_validate(feature: str, out: dict, ctx: dict) -> tuple[dict, list[str]]:
    """Keep engine-owned numbers, drop references to records that do not exist. Returns (output, notes)."""
    notes: list[str] = []
    res_ids = _ids("resources")
    b = ctx.get("bundle") or {}
    task_codes = {t["wbs_code"] for t in b.get("tasks", [])}
    if feature == "change_summary" and b:
        text = b.get("sa_doc_text")
        if text:
            out["sa_completeness"] = int(C.sa_score(text).get("completeness") or 0)
        cat = {c["code"]: c for c in b.get("component_catalog", [])}
        for row in out.get("components", []):
            if row.get("est_hours") is None and row["component_code"] in cat:
                row["est_hours"] = float(cat[row["component_code"]].get(f"base_hours_{row['complexity'].lower()}") or 0)
            row.setdefault("component_name", COMPONENT_NAMES[row["component_code"]])
    elif feature == "l2_estimate" and b:
        eng = generators.gen_l2_estimate(ctx)
        for k in ("total_hours", "low_hours", "high_hours", "tshirt", "dev_hours", "by_phase"):
            out[k] = eng[k]
        out["contingency_pct"] = 15
        eng_comp = {c["component_code"]: c for c in eng["by_component"]}
        kept = []
        for row in out.get("by_component", []):
            if row["component_code"] in eng_comp:
                row["dev_hours"] = eng_comp[row["component_code"]]["dev_hours"]
                row["complexity"] = eng_comp[row["component_code"]]["complexity"]
                kept.append(row)
        for code, row in eng_comp.items():
            if code not in {r["component_code"] for r in kept}:
                kept.append(row)
        out["by_component"] = kept[:12]
        _fix_comparables(out, [c["code"] for c in b.get("components", [])])
    elif feature == "wbs":
        for t in out.get("tasks", []):
            if t.get("suggested_resource_id") is not None and t["suggested_resource_id"] not in res_ids:
                notes.append(f"{t['wbs_code']}: suggested person not found; left unassigned.")
                t["suggested_resource_id"] = None
                t["suggested_resource_name"] = None
            if t.get("is_milestone"):
                t["duration_days"] = 0
            elif not t.get("duration_days"):
                t["duration_days"] = generators.duration_for(float(t["est_hours"]), int(t.get("allocation_pct") or 100))
        out["total_est_hours"] = round(sum(float(t["est_hours"]) for t in out.get("tasks", [])), 1)
    elif feature == "resources":
        wanted = (ctx.get("inputs") or {}).get("wbs_code")
        if wanted and any(r.get("wbs_code") == wanted for r in out.get("recommendations", [])):
            out["recommendations"] = [r for r in out["recommendations"] if r.get("wbs_code") == wanted]
            # checks and sources speak only about the selected step and its candidates
            others = {t for t in task_codes if t != wanted}
            names = {c["resource_name"] for r in out["recommendations"] for c in r["candidates"]}
            all_names = {r["name"] for r in db.query("SELECT name FROM resources")}
            out["warnings"] = [w for w in out.get("warnings", []) if not any(o in w for o in others)
                               and not any(n in w for n in all_names - names)]
            ids = {c["resource_id"] for r in out["recommendations"] for c in r["candidates"]}
            out["sources"] = [src for src in out.get("sources", []) if src["type"] != "resource" or src["id"] in ids
                              or str(src["id"]) in {str(i) for i in ids}]
            out["sources"] = [src for src in out["sources"] if not any(o in src.get("label", "") for o in others)]
        for rec in out.get("recommendations", []):
            for c in rec["candidates"]:
                c["concerns"] = [re.sub(r"^Best fit · over capacity", "Over capacity", x) for x in c.get("concerns", [])]
            cands = [c for c in rec["candidates"] if c["resource_id"] in res_ids]
            for i, c in enumerate(cands, start=1):
                c["rank"] = i
            rec["candidates"] = cands
            rid = rec.get("recommended_resource_id")
            if rid is not None and rid not in {c["resource_id"] for c in cands}:
                rec["recommended_resource_id"] = cands[0]["resource_id"] if cands else None
            if rec.get("wbs_code") and task_codes and rec["wbs_code"] not in task_codes:
                rec["wbs_code"] = None
    elif feature == "rebalance":
        opts = [o for o in out.get("options", []) if o["from_resource_id"] in res_ids and o["to_resource_id"] in res_ids
                and (not task_codes or o["task_wbs_code"] in task_codes)]
        if b:
            tasks = {t["wbs_code"]: t for t in b.get("tasks", [])}
            for o in opts:
                t = tasks.get(o["task_wbs_code"])
                if t and t.get("id") is not None:
                    sim = generators.simulate_move(b, t, o["to_resource_id"])
                    m = o["month"]
                    o["before"] = {"from_pct": round(generators.person_month_util(b, o["from_resource_id"], m)),
                                   "to_pct": round(generators.person_month_util(b, o["to_resource_id"], m))}
                    o["after"] = {"from_pct": round(generators.person_month_util(sim, o["from_resource_id"], m)),
                                  "to_pct": round(generators.person_month_util(sim, o["to_resource_id"], m))}
                    ha = generators.health_after(sim)
                    claimed = o.get("health_after")
                    if ha:
                        o["health_after"] = ha
                    if ha != claimed or not ha:
                        # wording must match the live numbers shown under it
                        now = (b["initiative"].get("health_cached_json") or {}).get("overall") \
                            if isinstance(b["initiative"].get("health_cached_json"), dict) else None
                        text = (f"{o['from_resource_name']} drops to {o['after']['from_pct']}% and {o['to_resource_name']} rises to "
                                f"{o['after']['to_pct']}% in {generators.fmt_month(m)}.")
                        if ha:
                            text += (f" Resources turns {ha['resources']}; overall health "
                                     f"{'stays' if ha['overall'] == now else 'becomes'} {ha['overall']}.")
                        o["effect"] = generators.clip(text, 300)
                        o.pop("tradeoffs", None)
        out["options"] = opts[:5]
        idx = out.get("recommended_option_index")
        out["recommended_option_index"] = (idx if idx is not None and idx < len(opts) else 0) if opts else None
    elif feature == "risks":
        for r in out.get("risks", []):
            if r.get("owner_resource_id") is not None and r["owner_resource_id"] not in res_ids:
                r["owner_resource_id"] = None
            if r.get("wbs_code") and task_codes and r["wbs_code"] not in task_codes:
                r["wbs_code"] = None
    elif feature == "exec_summary" and b:
        health = b["initiative"].get("health_cached_json")
        if isinstance(health, dict) and health.get("overall") in ("Red", "Amber", "Green"):
            out["rag"] = health["overall"]
    elif feature == "cr_compliance":
        cr = (ctx.get("data") or {}).get("cr")
        if cr:
            eng = C.check_cr(cr, {"bundle": b})
            if eng and "ok" in eng:
                out["compliant"] = bool(eng["ok"])
            if eng and eng.get("findings"):
                # rule results are the engine's truth in every tier; the AI keeps only its fix wording and reviewer note
                fixes = {f["rule_id"]: f.get("fix") for f in out.get("findings", []) if f.get("fix")}
                merged = []
                for f in eng["findings"][:20]:
                    row = {"rule_id": f["rule_id"], "rule": generators.clip(f.get("rule") or f["rule_id"], 200),
                           "status": f["status"], "field": f.get("field"),
                           "detail": generators.clip(f.get("detail") or f.get("rule") or "Checked", 400),
                           "fix": None, "blocking": bool(f.get("blocking"))}
                    if f["status"] != "Pass":
                        fix = fixes.get(f["rule_id"]) or f.get("fix")
                        row["fix"] = generators.clip(fix, 400) if fix else None
                    if f.get("due_date") or f["status"] == "Not due yet":
                        row["due_date"] = str(f["due_date"])[:10] if f.get("due_date") else None
                    merged.append(row)
                out["findings"] = merged
                if eng.get("score") is not None:
                    out["score"] = int(eng["score"])
                if C.sto_status(eng.get("sto_readiness")):
                    out["sto_readiness"] = C.sto_status(eng["sto_readiness"])
                out["crq_number"] = cr.get("crq_number")
    elif feature == "skill_matrix":
        out["rows"] = [r for r in out.get("rows", []) if r["resource_id"] in res_ids] or out.get("rows", [])
    elif feature == "nudges":
        for m in out.get("messages", []):
            if m.get("recipient_resource_id") is not None and m["recipient_resource_id"] not in res_ids:
                m["recipient_resource_id"] = None
            m["dedupe_key"] = generators.nudge_key(m["rule"], m.get("recipient_resource_id"), m["recipient_name"],
                                                   m["action_required_by"])
    elif feature == "meeting_extract":
        rddcs = _ids("initiatives", "rddc")
        for a in out.get("actions", []):
            if a.get("owner_resource_id") is not None and a["owner_resource_id"] not in res_ids:
                a["owner_resource_id"] = None
            if a.get("rddc") and a["rddc"] not in rddcs:
                a["rddc"] = None
        for d in out.get("decisions", []):
            if d.get("rddc") and d["rddc"] not in rddcs:
                d["rddc"] = None
        for r in out.get("risks_raised", []):
            if r.get("rddc") and r["rddc"] not in rddcs:
                r["rddc"] = None
    elif feature == "lessons":
        rddcs = _ids("initiatives", "rddc")
        lesson_ids = _ids("lessons_learned")
        out["relevant_lessons"] = [x for x in out.get("relevant_lessons", []) if x["rddc"] in rddcs]
        for x in out["relevant_lessons"]:
            if x.get("lesson_id") is not None and x["lesson_id"] not in lesson_ids:
                x["lesson_id"] = None
        if out.get("initiative_rddc") and out["initiative_rddc"] not in rddcs:
            out["initiative_rddc"] = None
    elif feature == "assistant":
        from app.ai.assistant import citation_exists

        before = len(out.get("citations", []))
        out["citations"] = [c for c in out.get("citations", []) if citation_exists(c)]
        out["follow_ups"] = [f for f in out.get("follow_ups", []) if follow_up_holds(f, ctx)]
        if len(out["citations"]) < before:
            notes.append("Some references could not be matched to records and were removed.")
    if feature == "intake_analysis":
        facts = _initiative_facts()
        mine = [c["code"] for c in b.get("components", [])] or [c["component_code"] for c in out.get("likely_components", [])]
        for d in out.get("possible_duplicates", []):
            if d["rddc"] in facts:
                d["similarity"] = generators.component_similarity(mine, facts[d["rddc"]]["components"])
    out["confidence"] = max(0.0, min(1.0, float(out.get("confidence") or 0)))
    return out, notes


INTAKE_FIELDS = {"prn_code": "prn_code", "prn": "prn_code", "dc_sa_id": "dc_sa_name", "dc_sa": "dc_sa_name",
                 "dc_sa_name": "dc_sa_name", "target_release": "target_release", "requested_go_live": "requested_go_live",
                 "requestor": "requestor", "lob": "lob", "name": "name", "sa_document": "sa_text", "sa_doc": "sa_text"}


def _intake_fixture_fits(out: dict, ctx: dict) -> bool:
    """Reconcile a prepared intake analysis with the form, then serve it only if nothing it says is contradicted.

    A field check that calls a field missing while the form now has it (for example Target Release prefilled from the
    DC intake) is corrected to present with the live value; prose that asks for a field the form has is not served."""
    subject = generators._intake_subject(ctx)
    for fc in out.get("field_checks", []):
        key = INTAKE_FIELDS.get(fc["field"])
        if key and fc["status"] in ("missing", "weak") and subject.get(key) and key != "sa_text":
            value = subject[key]
            fc["status"] = "present"
            fc["note"] = generators.clip(generators.fmt_date(value) if re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(value)) else str(value), 300)
        elif key == "sa_text" and fc["status"] == "missing" and subject.get(key):
            return False
    if subject.get("prn_code"):
        texts = [m["item"] for m in out.get("missing_info", [])] + [q["question"] for q in out.get("clarifying_questions", [])]
        if any(re.search(r"\bPRN\b", t) and subject["prn_code"] not in t for t in texts):
            return False
    return not (subject.get("dc_sa_name") and any(re.search(r"\bDC SA\b.*\b(missing|not (named|assigned))|who is the dc sa", m["item"], re.IGNORECASE) for m in out.get("missing_info", [])))


def fixture_fits(feature: str, out: dict, ctx: dict) -> bool:
    """A prepared response is served only while the records it describes still match the live data."""
    b = ctx.get("bundle") or {}
    tasks = {t["wbs_code"] for t in b.get("tasks", [])}
    comps = {c["code"] for c in b.get("components", [])}
    if feature == "cr_compliance":
        cr = (ctx.get("data") or {}).get("cr")
        return bool(cr) and out.get("crq_number") in (None, cr.get("crq_number"))
    if feature == "rebalance":
        if not tasks or not set(out["problem"]["wbs_codes"]) <= tasks or not all(o["task_wbs_code"] in tasks for o in out["options"]):
            return False
        prob = out["problem"]
        owners = {t["wbs_code"]: t.get("resource_id") for t in b.get("tasks", [])}
        if any(owners.get(code) != prob["resource_id"] for code in prob["wbs_codes"][:1]):
            return False
        live = generators.person_month_util(b, prob["resource_id"], prob["month"])
        return live > 100 and abs(live - float(prob["util_pct"])) <= 1.0
    if feature == "resources":
        wanted = (ctx.get("inputs") or {}).get("wbs_code")
        if wanted and not any(r["wbs_code"] == wanted for r in out["recommendations"]):
            return False
        return {r["wbs_code"] for r in out["recommendations"] if r["wbs_code"]} <= tasks
    if feature == "intake_analysis":
        return _intake_fixture_fits(out, ctx)
    if feature == "risks":
        return {r["wbs_code"] for r in out["risks"] if r["wbs_code"]} <= tasks
    if feature in ("wbs", "l2_estimate"):
        used = {t["component_code"] for t in out.get("tasks", []) if t.get("component_code")} if feature == "wbs" else \
            {c["component_code"] for c in out.get("by_component", [])}
        return bool(comps) and used <= comps
    if feature == "exec_summary" and b:
        health = b["initiative"].get("health_cached_json")
        scored = isinstance(health, dict) and health.get("scored", True) and health.get("overall") in ("Red", "Amber", "Green")
        return out.get("rag") == (health["overall"] if scored else "Not scored")
    return True


DIMENSIONS = ("schedule", "resources", "scope", "dependencies", "budget")


def follow_up_holds(text: str, ctx: dict) -> bool:
    """A suggested follow-up whose premise is false right now (e.g. 'Why is Resources red?' after the fix) is not offered."""
    m = re.search(r"why is (?:the )?([\w-]+)(?: rag)? (red|amber|green)", text, re.IGNORECASE)
    if not m:
        return True
    subject, rag = m.group(1).lower(), m.group(2).capitalize()
    rows = [C.parse_row(r) for r in db.query("SELECT id, rddc, stage, rag_cached, health_cached_json FROM initiatives WHERE id > 0")]
    rddc = re.search(r"RDDC-\d{5}", text)
    if rddc:
        row = next((r for r in rows if r["rddc"] == rddc.group(0)), None)
        return bool(row) and row.get("rag_cached") == rag
    if subject in DIMENSIONS:
        page = ctx.get("initiative_id")
        scope = [r for r in rows if not page or r["id"] == page]
        return any(((r.get("health_cached_json") or {}).get("dimensions") or {}).get(subject, {}).get("rag") == rag
                   for r in scope if isinstance(r.get("health_cached_json"), dict))
    return True


# ------------------------------------------------------------------ envelope
def mode_label(row: dict) -> str:
    """CR compliance verdicts come from rules in every tier, so the chip says so."""
    if row["feature"] == "cr_compliance" and row["mode"] != "live_fallback":
        return "Rules check"
    return MODE_LABELS[row["mode"]]


def envelope(row: dict) -> dict:
    out = db.from_json(row.get("output_json"), {}) or {}
    edited = db.from_json(row.get("edited_output_json"), None)
    env = {
        "ai_run_id": row["id"], "feature": row["feature"], "initiative_id": row["initiative_id"], "scope": row["scope"],
        "mode": row["mode"], "mode_label": mode_label(row), "model": row["model"],
        "fixture_key": row.get("fixture_key"), "variant_index": row["variant_index"],
        "confidence": row["confidence"] if row["confidence"] is not None else out.get("confidence", 0),
        "sources": db.from_json(row.get("sources_json"), []) or [], "warnings": db.from_json(row.get("warnings_json"), []) or [],
        "output": out, "status": row["status"], "latency_ms": row.get("latency_ms") or 0,
        "minutes_saved": row.get("minutes_saved") or 0, "regen_of": row.get("regen_of"), "created_at": row.get("created_at"),
        "applied": row["status"] == "accepted", "instruction": row.get("instruction"),
        "title": FEATURES[row["feature"]]["title"],
        "deterministic": row["mode"] == "simulated_generated" or row["feature"] == "cr_compliance",
    }
    if edited is not None:
        env["edited_output"] = edited
    return env


def get_run(run_id: int) -> dict:
    row = db.query_one("SELECT * FROM ai_runs WHERE id = ?", (run_id,))
    if row is None:
        raise not_found("AI run", run_id)
    return row


# ------------------------------------------------------------------ main entry point
def run_feature(feature: str, initiative_id: int | None, payload: dict | None = None, *, instruction: str | None = None,
                regen_of: int | None = None, force_mode: str | None = None) -> dict:
    if feature not in SCHEMAS:
        raise ApiError("bad_request", "That AI feature is not available.", 400, {"feature": feature})
    t0 = time.monotonic()
    payload = dict(payload or {})
    prev = get_run(int(regen_of)) if regen_of else None
    if prev and initiative_id is None and prev.get("initiative_id") and feature != "assistant":
        initiative_id = prev["initiative_id"]
    if prev and not payload:
        payload = (db.from_json(prev.get("input_json"), {}) or {}).get("inputs", {}) or {}
    ctx = C.build_context(feature, initiative_id, payload)
    ihash = C.input_hash(ctx)
    result: dict[str, Any] | None = None
    error = None
    tokens = (None, None)
    if live_allowed(force_mode):
        try:
            result = _run_live(feature, ctx, instruction)
            tokens = (result.get("tokens_in"), result.get("tokens_out"))
        except Exception as exc:  # noqa: BLE001 - any live-tier failure falls back; the server never answers 500 here
            error = str(exc) if isinstance(exc, claude.LiveError) else f"{type(exc).__name__}: {str(exc)[:200]}"
            log.warning("Live AI failed for %s: %s", feature, error)
            result = None
    if result is None:
        result = simulated.run(feature, ctx, ihash, prev)
        if result["mode"] == "simulated_fixture" and not fixture_fits(feature, result["output"], ctx):
            result = {**result, "output": generators.generate(feature, ctx, int(result.get("variant_index") or 0)),
                      "mode": "simulated_generated", "fixture_key": None, "model": None, "latency_ms": None}
        if error:
            result["mode"] = "live_fallback"
    out, notes = post_validate(feature, result["output"], ctx)
    problems = validate(feature, out)
    if problems and result["mode"] in ("simulated_fixture", "live_fallback", "live"):
        log.warning("Output for %s failed validation after checks: %s", feature, problems[:3])
        out, notes = post_validate(feature, generators.generate(feature, ctx, int(result.get("variant_index") or 0)), ctx)
        result.update({"fixture_key": None, "model": None})
        if result["mode"] == "simulated_fixture":
            result["mode"] = "simulated_generated"
        elif result["mode"] == "live":
            result["mode"] = "live_fallback"
            error = error or "live answer failed the record checks"
        problems = validate(feature, out)
    if problems:
        log.error("Generator output for %s is invalid: %s", feature, problems[:5])
        raise ApiError("ai_error", "The AI draft could not be prepared. Try again.", 502, {"feature": feature})
    warnings = list(out.get("warnings") or [])
    for n in notes:
        if n not in warnings and len(warnings) < 20:
            warnings.append(n)
    if result["mode"] == "live_fallback" and len(warnings) < 20:
        warnings.append("Live Claude was unavailable; this draft comes from the simulated tier.")
    latency = int((time.monotonic() - t0) * 1000)
    if result["mode"].startswith("simulated") and result.get("latency_ms"):
        latency = int(result["latency_ms"])
    row = {
        "feature": feature, "initiative_id": ctx.get("initiative_id"), "scope": ctx["scope"] if ctx["scope"] in ("initiative", "portfolio", "draft") else "portfolio",
        "input_hash": ihash, "input_json": db.to_json({"inputs": payload, "context": C.compact(ctx)}),
        "output_json": db.to_json(out), "mode": result["mode"], "model": result.get("model"), "prompt_version": PROMPT_VERSION,
        "fixture_key": result.get("fixture_key"), "variant_index": int(result.get("variant_index") or 0),
        "confidence": float(out.get("confidence") or 0), "sources_json": db.to_json(out.get("sources") or []),
        "warnings_json": db.to_json(warnings), "status": "generated", "instruction": instruction, "regen_of": prev["id"] if prev else None,
        "error": error, "latency_ms": latency, "tokens_in": tokens[0], "tokens_out": tokens[1],
        "minutes_saved": float(FEATURES[feature]["minutes_saved"]), "actor": actor(), "created_at": now_iso(),
    }
    with db.transaction():
        run_id = db.insert("ai_runs", row)
        if prev and prev["status"] == "generated":
            db.update("ai_runs", prev["id"], {"status": "superseded", "decided_at": now_iso()})
    return envelope(get_run(run_id))


def preview_feature(feature: str, initiative_id: int | None, payload: dict | None = None) -> dict:
    """The simulated output a feature button would show right now (fixture when it still fits, else rules engine),
    post-validated, without writing an ai_runs row. Used where another surface must say the same thing."""
    ctx = C.build_context(feature, initiative_id, dict(payload or {}))
    result = simulated.run(feature, ctx, C.input_hash(ctx), None)
    out = result["output"]
    if result["mode"] == "simulated_fixture" and not fixture_fits(feature, out, ctx):
        out = generators.generate(feature, ctx)
    out, _notes = post_validate(feature, out, ctx)
    if validate(feature, out):
        out, _notes = post_validate(feature, generators.generate(feature, ctx), ctx)
    return out


def _run_live(feature: str, ctx: dict, instruction: str | None) -> dict:
    if feature == "assistant":
        page = {"today": ctx["today"], "initiative_id": ctx.get("initiative_id"), "page": ctx["inputs"].get("page")}
        res = claude.run_assistant(ctx["inputs"].get("message") or "", page, LIVE_BUDGET_S)
    else:
        engine: dict[str, Any] = {"draft": generators.generate(feature, ctx)}
        b = ctx.get("bundle")
        if feature == "l2_estimate" and b:
            engine["l2"] = generators.l2_numbers(b)
        if feature == "change_summary" and b and b.get("sa_doc_text"):
            engine["sa_completeness"] = C.sa_score(b["sa_doc_text"]).get("completeness")
        res = claude.run(feature, C.compact(ctx), engine, instruction, LIVE_BUDGET_S)
    out = res["output"]
    problems = validate(feature, out)
    if problems:
        raise claude.LiveError(f"answer did not match the expected shape: {problems[:2]}")
    return {"output": out, "mode": "live", "fixture_key": None, "variant_index": 0, "model": res["model"],
            "latency_ms": None, "tokens_in": res.get("tokens_in"), "tokens_out": res.get("tokens_out")}
