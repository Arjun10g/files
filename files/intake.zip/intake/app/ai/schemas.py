"""Frozen AI output contract (B0). Do not edit without an orchestrator-approved contract change.

Every AI feature returns an ``output`` object that validates against ``SCHEMAS[feature]``.
The same schema is used by:
  * live Claude (passed as the forced tool ``emit_<feature>`` input_schema),
  * test-agent fixtures (``app/ai/fixtures/<feature>/<key>.json``, each variant),
  * deterministic generators (``app/ai/generators.py``),
  * ``app/ai/apply.py`` when the user clicks Accept.

Every output carries ``confidence`` (0-1), ``sources`` and ``warnings`` so the AI Result Card
renders uniformly. Dates are ISO ``YYYY-MM-DD``; months ``YYYY-MM``. Numbers for hours, dates,
capacity, RAG and compliance verdicts are computed by Python engines; the model writes wording.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

SCHEMA_VERSION = "1.0"
DIALECT = "https://json-schema.org/draft/2020-12/schema"

# --------------------------------------------------------------------------------------------
# API response envelope (what /api/.../ai/<feature> returns around ``output``)
# --------------------------------------------------------------------------------------------
ENVELOPE_FIELDS: dict[str, str] = {
    "ai_run_id": "int - ai_runs.id; pass to POST /api/ai-runs/{id}/apply to Accept",
    "feature": "str - snake_case feature key (one of FEATURE_KEYS)",
    "mode": "str - one of MODES; drives the mode chip on the AI Result Card",
    "model": "str|null - Claude model id when live, else the emulated model name or null",
    "fixture_key": "str|null - fixture key served in simulated_fixture mode",
    "latency_ms": "int - server-side latency (simulated modes report the fixture's simulated_latency_ms)",
    "output": "object - validates against SCHEMAS[feature]; always has confidence, sources, warnings",
    "applied": "bool - false until the user Accepts",
}
MODES = ("simulated_fixture", "simulated_generated", "live", "live_fallback")

# --------------------------------------------------------------------------------------------
# Enums (exact spellings from the master plan; the UI reads its copies from /api/lookups)
# --------------------------------------------------------------------------------------------
COMPONENT_CODES = ("APIP", "APIGW", "EDP", "CIAM", "MOB_IOS", "MOB_AND", "OLB", "PAYHUB",
                   "NOTIF", "STMT", "SRE", "FRAUD")
COMPONENT_NAMES = {
    "APIP": "API Platform", "APIGW": "API Gateway", "EDP": "Enterprise Data Platform",
    "CIAM": "CIAM / Security", "MOB_IOS": "Mobile App – iOS", "MOB_AND": "Mobile App – Android",
    "OLB": "Online Banking Web", "PAYHUB": "Payments Hub", "NOTIF": "Notifications Service",
    "STMT": "Statements & Documents", "SRE": "SRE / Observability", "FRAUD": "Fraud Signals Integration",
}
COMPLEXITY = ("Low", "Medium", "High")
TSHIRT = ("XS", "S", "M", "L", "XL")
APPROVAL = ("Pending", "Approved", "Not required", "Rejected")
RAG = ("Red", "Amber", "Green")
STAGES = ("Intake", "Grooming", "Solution", "Estimation", "Planning", "Build", "QA", "Release", "Closed")
WBS_PHASES = ("Estimation", "Architecture", "Development", "Integration", "QA", "UAT", "Readiness",
              "Production", "Hypercare")
L2_PHASES = ("Development", "Architecture", "QA", "PM / Release", "Contingency")
RISK_CATEGORIES = ("Schedule", "Resource", "Scope", "Dependency", "Budget", "Technical", "Compliance")
SEVERITY_LABELS = {1: "Low", 2: "Medium", 3: "High", 4: "Critical"}
LIKELIHOOD_LABELS = {1: "Rare", 2: "Unlikely", 3: "Possible", 4: "Likely"}
STO_APPROVAL = ("Tentative Go", "Tentative No Go", "Go", "No-Go")
SKILL_LEVELS = {1: "Exposure", 2: "Working", 3: "Expert"}
QUESTION_ROLES = ("Requestor", "DC SA", "DC PM", "Tech Lead", "Delivery Lead", "Account Manager",
                  "CMS Lead", "Rel Lead")
NOTIFICATION_RULES = ("grooming_invite", "sa_action_required", "l2_approval", "cr_noncompliance",
                      "validation_missing")
SOURCE_TYPES = ("initiative", "component", "sa_doc", "attachment", "document", "wbs_task", "resource",
                "allocation", "availability", "change_request", "risk", "meeting_note", "decision",
                "lesson", "prn", "grooming_session", "notification", "release_train", "rule", "engine")
CITATION_TYPES = ("initiative", "wbs_task", "resource", "change_request", "risk", "component",
                  "decision", "lesson", "meeting_note", "document", "prn", "grooming_session", "page")
ASSISTANT_INTENTS = (
    "list_by_rag", "explain_health", "overallocated_resources", "summarize_initiative", "blockers",
    "suggest_resource", "availability", "resource_workload", "upcoming_releases", "cr_noncompliance",
    "top_risks", "milestone_dates", "component_demand", "pending_approvals", "skill_lookup",
    "portfolio_stats", "status_report", "help",
    # round 2 (additive): PRN burn, CRQ STO readiness, schedule what-if
    "prn_status", "crq_sto_readiness", "what_if_slip", "prn_overrun",
)

# Confidence pill bands (UX §2.7)
CONFIDENCE_BANDS = (("High", 0.80), ("Medium", 0.60), ("Low", 0.0))


def confidence_band(value: float) -> str:
    for label, floor in CONFIDENCE_BANDS:
        if value >= floor:
            return label
    return "Low"


# --------------------------------------------------------------------------------------------
# Schema building blocks (inlined, no $ref, so the dicts work as Anthropic tool input_schema)
# --------------------------------------------------------------------------------------------
def _str(max_len: int = 500, min_len: int = 1) -> dict:
    return {"type": "string", "minLength": min_len, "maxLength": max_len}


def _text(max_len: int = 2000) -> dict:
    """Free text that may legitimately be empty."""
    return {"type": "string", "maxLength": max_len}


def _enum(values) -> dict:
    return {"type": "string", "enum": list(values)}


def _int(lo: int | None = None, hi: int | None = None) -> dict:
    s: dict[str, Any] = {"type": "integer"}
    if lo is not None:
        s["minimum"] = lo
    if hi is not None:
        s["maximum"] = hi
    return s


def _num(lo: float | None = None, hi: float | None = None) -> dict:
    s: dict[str, Any] = {"type": "number"}
    if lo is not None:
        s["minimum"] = lo
    if hi is not None:
        s["maximum"] = hi
    return s


def _nullable(schema: dict) -> dict:
    return {"anyOf": [schema, {"type": "null"}]}


def _arr(items: dict, min_items: int = 0, max_items: int | None = None) -> dict:
    s: dict[str, Any] = {"type": "array", "items": items, "minItems": min_items}
    if max_items is not None:
        s["maxItems"] = max_items
    return s


def _obj(props: dict, optional: tuple[str, ...] = ()) -> dict:
    return {
        "type": "object",
        "properties": props,
        "required": [k for k in props if k not in optional],
        "additionalProperties": False,
    }


DATE = {"type": "string", "pattern": r"^\d{4}-\d{2}-\d{2}$"}
MONTH = {"type": "string", "pattern": r"^\d{4}-\d{2}$"}
RDDC = {"type": "string", "pattern": r"^RDDC-\d{5}$"}
WBS_CODE = {"type": "string", "pattern": r"^WBS-\d{3}$"}
CONFIDENCE = _num(0, 1)
PCT = _num(0, 100)
HOURS = _num(0, 20000)
RESOURCE_ID = _int(1)
COMPONENT_CODE = _enum(COMPONENT_CODES)
RAG_OR_UNSCORED = _enum(RAG + ("Not scored",))
ROUTE = {"type": "string", "pattern": r"^#/"}

SOURCE = _obj(
    {
        "type": _enum(SOURCE_TYPES),
        "id": {"type": ["string", "integer"]},
        "label": _str(200),
        "excerpt": _str(400),
    },
    optional=("excerpt",),
)

COMMON_PROPS = {
    "confidence": CONFIDENCE,
    "sources": _arr(SOURCE, 0, 40),
    "warnings": _arr(_str(300), 0, 20),
}


def _output(props: dict, optional: tuple[str, ...] = ()) -> dict:
    schema = _obj({**props, **COMMON_PROPS}, optional=optional)
    return {"$schema": DIALECT, **schema}


# --------------------------------------------------------------------------------------------
# Per-feature output schemas
# --------------------------------------------------------------------------------------------
INTAKE_ANALYSIS = _output(
    {
        "summary": _str(600),
        "completeness_score": _int(0, 100),
        "readiness": _enum(("Ready for grooming", "Needs info", "Not ready")),
        "field_checks": _arr(_obj({
            "field": _str(60),
            "label": _str(80),
            "status": _enum(("present", "missing", "weak")),
            "note": _text(300),
        }), 0, 20),
        "ambiguities": _arr(_obj({
            "text": _str(200),
            "why": _str(300),
            "source_field": _str(60),
        }), 0, 12),
        "missing_info": _arr(_obj({
            "item": _str(200),
            "impact": _enum(("High", "Medium", "Low")),
        }), 0, 12),
        "clarifying_questions": _arr(_obj({
            "question": _str(300),
            "addressed_to": _enum(QUESTION_ROLES),
            "priority": _int(1, 3),
        }), 0, 8),
        "suggested_labels": _arr(_str(40), 0, 10),
        "likely_components": _arr(_obj({
            "component_code": COMPONENT_CODE,
            "complexity": _enum(COMPLEXITY),
            "reason": _str(300),
        }), 0, 12),
        "suggested_priority": _nullable(_int(1, 4)),
        "possible_duplicates": _arr(_obj({
            "rddc": RDDC,
            "name": _str(200),
            "similarity": _num(0, 1),
            "reason": _str(300),
        }), 0, 5),
    },
)

CHANGE_SUMMARY = _output(
    {
        "components": _arr(_obj(
            {
                "component_code": COMPONENT_CODE,
                "component_name": _str(80),
                "approval": _enum(APPROVAL),
                "approver": _nullable(_str(120)),
                "complexity": _enum(COMPLEXITY),
                "change_type": _enum(("New", "Modify", "Config", "Decommission")),
                "change_summary": _str(600),
                "est_hours": _nullable(HOURS),
                "evidence": _arr(_obj({"section": _str(120), "excerpt": _str(400)}), 0, 6),
            },
            optional=("component_name", "approver", "change_type", "est_hours"),
        ), 0, 12),
        "sa_completeness": _int(0, 100),
        "sa_sections": _arr(_obj({"section": _str(80), "found": {"type": "boolean"}}), 0, 12),
        "gaps": _arr(_str(300), 0, 15),
        "open_items": _arr(_str(300), 0, 15),
        "out_of_scope": _arr(_str(300), 0, 15),
    },
    optional=("sa_sections", "out_of_scope"),
)

L2_ESTIMATE = _output(
    {
        "total_hours": HOURS,
        "low_hours": HOURS,
        "high_hours": HOURS,
        "tshirt": _enum(TSHIRT),
        "dev_hours": HOURS,
        "contingency_pct": PCT,
        "by_component": _arr(_obj({
            "component_code": COMPONENT_CODE,
            "complexity": _enum(COMPLEXITY),
            "dev_hours": HOURS,
            "rationale": _str(400),
        }), 0, 12),
        "by_phase": _arr(_obj({"phase": _enum(L2_PHASES), "hours": HOURS}), 0, 5),
        "drivers": _arr(_obj({"factor": _str(200), "effect": _str(200)}), 0, 10),
        "comparables": _arr(_obj({
            "rddc": RDDC,
            "name": _str(200),
            "actual_hours": HOURS,
            "similarity": _num(0, 1),
            "note": _text(300),
        }, optional=("note",)), 0, 5),
        "assumptions": _arr(_str(300), 0, 12),
        "narrative": _str(1500),
    },
    optional=("contingency_pct", "drivers", "comparables"),
)

WBS_TASK = _obj(
    {
        "wbs_code": WBS_CODE,
        "parent_code": _nullable(WBS_CODE),
        "step": _str(160),
        "phase": _enum(WBS_PHASES),
        "description": _text(600),
        "component_code": _nullable(COMPONENT_CODE),
        "owner_role": _str(80),
        "suggested_resource_id": _nullable(RESOURCE_ID),
        "suggested_resource_name": _nullable(_str(120)),
        "est_hours": HOURS,
        "allocation_pct": _int(0, 100),
        "duration_days": _int(0, 260),
        "offset_days": _int(0, 400),
        "depends_on": _arr(WBS_CODE, 0, 12),
        "is_milestone": {"type": "boolean"},
    },
    optional=("suggested_resource_name", "offset_days"),
)

WBS = _output(
    {
        "summary": _str(600),
        "tasks": _arr(WBS_TASK, 1, 60),
        "total_est_hours": HOURS,
        "dependency_impacts": _arr(_obj({
            "component_code": COMPONENT_CODE,
            "direction": _enum(("upstream", "downstream")),
            "impact": _str(300),
            "action": _str(300),
            "wbs_code": _nullable(WBS_CODE),
        }), 0, 20),
        "assumptions": _arr(_str(300), 0, 12),
    },
)

CANDIDATE = _obj(
    {
        "rank": _int(1, 10),
        "resource_id": RESOURCE_ID,
        "resource_name": _str(120),
        "team": _str(60),
        "fit_score": PCT,
        "skill_match_pct": PCT,
        "free_hours": _num(-2000, 20000),
        "peak_util_after_pct": _num(0, 500),
        "matched_skills": _arr(_str(60), 0, 15),
        "missing_skills": _arr(_str(60), 0, 15),
        "prior_work": _arr(RDDC, 0, 10),
        "reasons": _arr(_str(300), 1, 5),
        "concerns": _arr(_str(300), 0, 5),
    },
)

RESOURCES = _output(
    {
        "recommendations": _arr(_obj({
            "wbs_code": _nullable(WBS_CODE),
            "role_needed": _str(120),
            "required_skills": _arr(_str(60), 0, 15),
            "hours_needed": HOURS,
            "window": _obj({"start": DATE, "end": DATE}),
            "candidates": _arr(CANDIDATE, 0, 5),
            "recommended_resource_id": _nullable(RESOURCE_ID),
        }), 1, 40),
    },
)

PCT_PAIR = _obj({"from_pct": _num(0, 500), "to_pct": _num(0, 500)})

REBALANCE = _output(
    {
        "problem": _obj({
            "resource_id": RESOURCE_ID,
            "resource_name": _str(120),
            "month": MONTH,
            "util_pct": _num(0, 500),
            "wbs_codes": _arr(WBS_CODE, 0, 20),
            "summary": _str(300),
        }),
        "options": _arr(_obj(
            {
                "action": _str(300),
                "task_wbs_code": WBS_CODE,
                "from_resource_id": RESOURCE_ID,
                "from_resource_name": _str(120),
                "to_resource_id": RESOURCE_ID,
                "to_resource_name": _str(120),
                "month": MONTH,
                "before": PCT_PAIR,
                "after": PCT_PAIR,
                "effect": _str(300),
                "health_after": _obj({"resources": _enum(RAG), "overall": _enum(RAG)}),
                "tradeoffs": _arr(_str(300), 0, 5),
            },
            optional=("health_after", "tradeoffs"),
        ), 0, 5),
        "recommended_option_index": _nullable(_int(0, 4)),
    },
)

RISKS = _output(
    {
        "risks": _arr(_obj(
            {
                "title": _str(160),
                "description": _str(600),
                "category": _enum(RISK_CATEGORIES),
                "severity": _int(1, 4),
                "likelihood": _int(1, 4),
                "trigger_signal": _str(300),
                "wbs_code": _nullable(WBS_CODE),
                "owner_role": _str(80),
                "owner_resource_id": _nullable(RESOURCE_ID),
                "mitigation_steps": _arr(_obj({
                    "step": _str(300),
                    "owner_role": _str(80),
                    "due": _nullable(DATE),
                }), 1, 5),
                "contingency": _text(400),
            },
            optional=("contingency",),
        ), 0, 12),
        "management_attention": _text(200),
        "overall_level": _enum(tuple(SEVERITY_LABELS.values())),
    },
)

EXEC_SUMMARY = _output(
    {
        "scope": _enum(("initiative", "portfolio")),
        "rddc": _nullable(RDDC),
        "period": _obj({"from": DATE, "to": DATE}),
        "headline": _str(200),
        "rag": RAG_OR_UNSCORED,
        "summary_md": _str(3000),
        "highlights": _arr(_str(300), 0, 5),
        "concerns": _arr(_str(300), 0, 5),
        "asks": _arr(_str(300), 0, 5),
        "per_initiative": _arr(_obj({
            "rddc": RDDC,
            "name": _str(200),
            "rag": RAG_OR_UNSCORED,
            "one_liner": _str(200),
        }), 0, 30),
        "upcoming_releases": _arr(_obj({
            "rddc": RDDC,
            "release_train": _str(20),
            "date": DATE,
            "sto_approval": _nullable(_enum(STO_APPROVAL)),
        }), 0, 20),
        "capacity_watch": _arr(_str(300), 0, 8),
    },
    optional=("rddc", "per_initiative", "upcoming_releases", "capacity_watch"),
)

CR_COMPLIANCE = _output(
    {
        "crq_number": _nullable(_str(40)),
        "compliant": {"type": "boolean"},
        "score": _int(0, 100),
        "sto_readiness": _enum(("Ready for Go", "Tentative", "Not ready", "Not requested")),
        "findings": _arr(_obj({
            "rule_id": {"type": "string", "pattern": r"^CR-\d{2}$"},
            "rule": _str(200),
            "status": _enum(("Pass", "Fail", "Warn", "Not due yet")),
            "field": _nullable(_str(60)),
            "detail": _str(400),
            "fix": _nullable(_str(400)),
            "blocking": {"type": "boolean"},
            "due_date": _nullable(DATE),
        }, optional=("due_date",)), 1, 20),
        "reviewer_note": _str(600),
    },
)

SKILL_MATRIX = _output(
    {
        "skills": _arr(_str(60), 1, 60),
        "rows": _arr(_obj({
            "resource_id": RESOURCE_ID,
            "resource_name": _str(120),
            "team": _str(60),
            "skills": _arr(_obj({
                "skill": _str(60),
                "level": _int(1, 3),
                "evidence": _arr(_str(200), 0, 6),
                "source": _enum(("history", "declared", "both")),
            }), 0, 30),
            "top_skills": _arr(_str(60), 0, 5),
        }), 1, 40),
        "team_gaps": _arr(_obj({
            "skill": _str(60),
            "holders": _int(0),
            "holder_names": _arr(_str(120), 0, 10),
            "note": _str(300),
        }), 0, 20),
    },
)

NUDGES = _output(
    {
        "messages": _arr(_obj({
            "recipient_name": _str(120),
            "recipient_resource_id": _nullable(RESOURCE_ID),
            "recipient_role": _str(80),
            "rule": _enum(NOTIFICATION_RULES),
            "subject": _str(200),
            "body": _str(1500),
            "action_required_by": DATE,
            "urgency": _enum(("High", "Normal")),
            "escalation_level": _int(0, 3),
            "dedupe_key": _str(200),
            "items": _arr(_obj({
                "type": _enum(("sa_input", "approval", "l2_approval", "question", "action",
                               "validation", "grooming")),
                "rddc": _nullable(RDDC),
                "label": _str(300),
                "age_days": _int(0),
            }), 1, 20),
        }), 0, 40),
    },
)

MEETING_EXTRACT = _output(
    {
        "summary": _str(800),
        "meeting_date": _nullable(DATE),
        "attendees": _arr(_str(120), 0, 30),
        "decisions": _arr(_obj({
            "decision": _str(400),
            "made_by": _nullable(_str(120)),
            "rationale": _nullable(_str(400)),
            "rddc": _nullable(RDDC),
        }), 0, 20),
        "actions": _arr(_obj({
            "action": _str(400),
            "owner_name": _nullable(_str(120)),
            "owner_resource_id": _nullable(RESOURCE_ID),
            "due": _nullable(DATE),
            "rddc": _nullable(RDDC),
            "source_line": _nullable(_int(1)),
        }), 0, 30),
        "risks_raised": _arr(_obj({"title": _str(200), "rddc": _nullable(RDDC)}), 0, 10),
        "open_questions": _arr(_str(300), 0, 10),
    },
    optional=("attendees",),
)

LESSONS = _output(
    {
        "mode": _enum(("draft", "relevant")),
        "initiative_rddc": _nullable(RDDC),
        "lessons": _arr(_obj({
            "category": _str(60),
            "kind": _enum(("went_well", "improve")),
            "what_happened": _str(600),
            "lesson": _str(400),
            "recommendation": _str(400),
            "evidence": _text(300),
        }), 0, 12),
        "relevant_lessons": _arr(_obj({
            "lesson_id": _nullable(_int(1)),
            "rddc": RDDC,
            "lesson": _str(400),
            "why_relevant": _str(300),
        }), 0, 8),
        "estimate_accuracy": _nullable(_obj({
            "planned_hours": HOURS,
            "actual_hours": HOURS,
            "variance_pct": _num(-100, 1000),
            "worst_phases": _arr(_str(60), 0, 5),
        })),
        "tags": _arr(_str(40), 0, 10),
    },
    optional=("tags",),
)

AUTOFILL_FIELD_NAMES = ("name", "lob", "requestor", "priority", "description", "labels", "dc_intake",
                        "target_release", "requested_go_live", "sa_author", "dc_sa_name", "prn_code",
                        "sa_version")
AUTOFILL_FIELD = _obj({
    "value": {"type": ["string", "integer", "null"]},
    "confidence": CONFIDENCE,
    "source": _str(200),
})
INTAKE_AUTOFILL = _output(
    {
        "fields": {
            "type": "object",
            "properties": {k: AUTOFILL_FIELD for k in AUTOFILL_FIELD_NAMES},
            "additionalProperties": False,
        },
        "likely_components": _arr(COMPONENT_CODE, 0, 12),
    },
)

SUGGESTED_ACTION = {
    "type": "object",
    "properties": {
        "label": _str(80),
        "route": ROUTE,
        "api": {"type": "string", "pattern": r"^/api/"},
        "method": _enum(("GET", "POST")),
    },
    "required": ["label"],
    "anyOf": [{"required": ["route"]}, {"required": ["api"]}],
    "additionalProperties": False,
}
ASSISTANT = _output(
    {
        "answer_md": _str(6000),
        "intent": _enum(ASSISTANT_INTENTS),
        "citations": _arr(_obj({
            "type": _enum(CITATION_TYPES),
            "id": {"type": ["string", "integer"]},
            "label": _str(200),
            "route": ROUTE,
        }), 0, 30),
        "table": _nullable(_obj({
            "columns": _arr(_str(60), 1, 10),
            "rows": _arr(_arr({"type": ["string", "number", "null"]}, 1, 10), 0, 50),
        })),
        "suggested_actions": _arr(SUGGESTED_ACTION, 0, 4),
        "follow_ups": _arr(_str(200), 0, 4),
    },
)

SCHEMAS: dict[str, dict] = {
    "intake_analysis": INTAKE_ANALYSIS,
    "change_summary": CHANGE_SUMMARY,
    "l2_estimate": L2_ESTIMATE,
    "wbs": WBS,
    "resources": RESOURCES,
    "rebalance": REBALANCE,
    "risks": RISKS,
    "exec_summary": EXEC_SUMMARY,
    "cr_compliance": CR_COMPLIANCE,
    "skill_matrix": SKILL_MATRIX,
    "nudges": NUDGES,
    "meeting_extract": MEETING_EXTRACT,
    "lessons": LESSONS,
    "intake_autofill": INTAKE_AUTOFILL,
    "assistant": ASSISTANT,
}
FEATURE_KEYS = tuple(SCHEMAS)

# --------------------------------------------------------------------------------------------
# Feature metadata (UI labels, model tier, time-saved baseline, thinking steps shown by client)
# --------------------------------------------------------------------------------------------
FEATURES: dict[str, dict] = {
    "intake_analysis": {
        "title": "Intake Analysis", "button": "Analyse intake", "slug": "intake-analysis",
        "scope": "both", "model_tier": "fast", "minutes_saved": 30, "applies_to": "initiatives (labels, priority)",
        "description": "Assess an intake for grooming readiness: completeness, ambiguities, missing information, "
                       "likely DC components, duplicates and clarifying questions.",
        "thinking_steps": ["Reading intake details…", "Checking required information…",
                           "Looking for similar initiatives…", "Drafting clarifying questions…"],
    },
    "change_summary": {
        "title": "Change Summary", "button": "Generate Change Summary", "slug": "change-summary",
        "scope": "initiative", "model_tier": "heavy", "minutes_saved": 60, "applies_to": "initiative_components",
        "description": "Read the SA document and list each impacted DC component with approval status, "
                       "complexity and a delivery-language change summary, plus SA completeness and gaps.",
        "thinking_steps": ["Reading SA document…", "Identifying impacted DC components…",
                           "Matching components to approvers…", "Drafting change summary…",
                           "Scoring SA completeness…"],
    },
    "l2_estimate": {
        "title": "L2 Estimate", "button": "How we got this", "slug": "l2-estimate",
        "scope": "initiative", "model_tier": "fast", "minutes_saved": 45, "applies_to": "initiatives (l2 narrative)",
        "description": "Explain the engine-calculated L2 estimate: per-component rationale, drivers, comparables "
                       "and assumptions. Numbers come from the estimate engine and must be kept as given.",
        "thinking_steps": ["Reading change summary…", "Applying L2 hours by complexity…",
                           "Comparing with past initiatives…", "Writing estimate rationale…"],
    },
    "wbs": {
        "title": "Project Plan", "button": "Generate Plan", "slug": "wbs",
        "scope": "initiative", "model_tier": "heavy", "minutes_saved": 90, "applies_to": "wbs_tasks",
        "description": "Turn the change summary into an actionable WBS with phases, owners, hours, durations, "
                       "dependencies and downstream regression steps. Dates are computed by the system.",
        "thinking_steps": ["Reading change summary…", "Applying DC WBS template…", "Sequencing dependencies…",
                           "Mapping downstream impacts…", "Estimating effort from L2…", "Proposing owners…"],
    },
    "resources": {
        "title": "Suggested Resources", "button": "Suggest Resources", "slug": "resources",
        "scope": "initiative", "model_tier": "fast", "minutes_saved": 30, "applies_to": "wbs_tasks.resource_id",
        "description": "Rank the most suitable people for each WBS step by skill match and availability, "
                       "with reasons and concerns.",
        "thinking_steps": ["Checking skill matrix…", "Checking availability…", "Ranking candidates…"],
    },
    "rebalance": {
        "title": "Resource Fix", "button": "Suggest fix", "slug": "rebalance",
        "scope": "initiative", "model_tier": "fast", "minutes_saved": 20, "applies_to": "wbs_tasks.resource_id",
        "description": "Propose moving work from an over-allocated person to the best alternative, showing "
                       "utilisation before and after.",
        "thinking_steps": ["Finding over-allocated months…", "Checking who has spare capacity…",
                           "Comparing before and after…"],
    },
    "risks": {
        "title": "Risk Prediction", "button": "Identify Risks", "slug": "risks",
        "scope": "initiative", "model_tier": "heavy", "minutes_saved": 45, "applies_to": "risks",
        "description": "Predict delivery risks with severity and likelihood (1-4), the data signal that raised "
                       "each one, linked WBS and actionable mitigation steps.",
        "thinking_steps": ["Reviewing plan dates and allocations…", "Comparing with past initiatives…",
                           "Rating severity and likelihood…"],
    },
    "exec_summary": {
        "title": "Executive Summary", "button": "Write Executive Summary", "slug": "exec-summary",
        "scope": "both", "model_tier": "fast", "minutes_saved": 60, "applies_to": "none (copy/export)",
        "description": "Write a weekly executive status for an initiative or the portfolio: headline, "
                       "highlights, concerns, asks and upcoming releases.",
        "thinking_steps": ["Collecting health and milestones…", "Checking this week's changes…",
                           "Writing the summary…"],
    },
    "cr_compliance": {
        "title": "CR Compliance", "button": "Check CR Compliance", "slug": "cr-compliance",
        "scope": "initiative", "model_tier": "fast", "minutes_saved": 20, "applies_to": "change_requests.compliance_json",
        "description": "Explain the rule-based compliance findings for a change request and write fixes and a "
                       "reviewer note. Pass/Fail verdicts come from the rules and must be kept as given.",
        "thinking_steps": ["Reading change request…", "Checking approvals and evidence…",
                           "Checking release window…", "Writing reviewer note…"],
    },
    "skill_matrix": {
        "title": "Skill Matrix", "button": "Generate Skill Matrix", "slug": "skill-matrix",
        "scope": "global", "model_tier": "fast", "minutes_saved": 120, "applies_to": "resource_skills",
        "description": "Infer each person's skills (level 1-3) from the work they have done, with evidence, "
                       "and flag skills held by one person or fewer.",
        "thinking_steps": ["Reading past WBS assignments…", "Mapping work to skills…", "Rating skill levels…"],
    },
    "nudges": {
        "title": "Reminders", "button": "Draft reminders", "slug": "nudges",
        "scope": "global", "model_tier": "fast", "minutes_saved": 15, "applies_to": "notifications",
        "description": "Draft one consolidated 'Action required by' reminder per recipient for pending inputs "
                       "and approvals.",
        "thinking_steps": ["Finding pending actions and approvals…", "Grouping by recipient…",
                           "Drafting reminders…"],
    },
    "meeting_extract": {
        "title": "Meeting Actions", "button": "Extract actions", "slug": "meeting-extract",
        "scope": "global", "model_tier": "fast", "minutes_saved": 20, "applies_to": "decisions, meeting_notes",
        "description": "Extract decisions, action items with owners and due dates, raised risks and open "
                       "questions from meeting notes.",
        "thinking_steps": ["Reading meeting notes…", "Finding decisions…", "Finding actions and owners…"],
    },
    "lessons": {
        "title": "Lessons Learned", "button": "Draft lessons learned", "slug": "lessons",
        "scope": "global", "model_tier": "fast", "minutes_saved": 45, "applies_to": "lessons_learned",
        "description": "Draft lessons learned for a closed initiative, or surface relevant past lessons for a "
                       "new intake.",
        "thinking_steps": ["Comparing planned and actual effort…", "Reviewing risks and decisions…",
                           "Drafting lessons…"],
    },
    "intake_autofill": {
        "title": "Intake Autofill", "button": "Fill from SA document", "slug": "intake-autofill",
        "scope": "global", "model_tier": "fast", "minutes_saved": 10, "applies_to": "new initiative form",
        "description": "Pre-fill new initiative fields from an SA document with per-field confidence.",
        "thinking_steps": ["Reading SA document…", "Finding intake details…", "Filling the form…"],
    },
    "assistant": {
        "title": "Assistant", "button": "Ask Assistant", "slug": "assistant",
        "scope": "global", "model_tier": "heavy", "minutes_saved": 5, "applies_to": "none",
        "description": "Answer a question about the portfolio from live records, citing every record used.",
        "thinking_steps": ["Understanding the question…", "Checking portfolio records…", "Writing the answer…"],
    },
}

# --------------------------------------------------------------------------------------------
# Validation
# --------------------------------------------------------------------------------------------
_VALIDATORS = {k: Draft202012Validator(v) for k, v in SCHEMAS.items()}
for _s in SCHEMAS.values():
    Draft202012Validator.check_schema(_s)


def _path(err) -> str:
    parts = [str(p) for p in err.absolute_path]
    return "/".join(parts) if parts else "(root)"


def _semantic_checks(feature: str, output: dict) -> list[str]:
    errors: list[str] = []
    if feature == "wbs":
        codes = [t["wbs_code"] for t in output.get("tasks", [])]
        seen: set[str] = set()
        for c in codes:
            if c in seen:
                errors.append(f"tasks: duplicate wbs_code {c}")
            seen.add(c)
        for t in output.get("tasks", []):
            if t["parent_code"] is not None and t["parent_code"] not in seen:
                errors.append(f"tasks/{t['wbs_code']}: parent_code {t['parent_code']} not in plan")
            for d in t["depends_on"]:
                if d == t["wbs_code"]:
                    errors.append(f"tasks/{t['wbs_code']}: depends on itself")
                elif d not in seen:
                    errors.append(f"tasks/{t['wbs_code']}: depends_on {d} not in plan")
    elif feature == "change_summary":
        codes = [c["component_code"] for c in output.get("components", [])]
        if len(codes) != len(set(codes)):
            errors.append("components: duplicate component_code")
    elif feature == "rebalance":
        idx = output.get("recommended_option_index")
        if idx is not None and idx >= len(output.get("options", [])):
            errors.append("recommended_option_index: out of range")
        if idx is None and output.get("options"):
            errors.append("recommended_option_index: required when options are present")
    elif feature == "resources":
        for i, rec in enumerate(output.get("recommendations", [])):
            ranks = [c["rank"] for c in rec["candidates"]]
            if ranks != list(range(1, len(ranks) + 1)):
                errors.append(f"recommendations/{i}: candidate ranks must be 1..n in order")
            rid = rec["recommended_resource_id"]
            if rid is not None and rid not in {c["resource_id"] for c in rec["candidates"]}:
                errors.append(f"recommendations/{i}: recommended_resource_id not among candidates")
    elif feature == "l2_estimate":
        if not (output["low_hours"] <= output["total_hours"] <= output["high_hours"]):
            errors.append("l2_estimate: expected low_hours <= total_hours <= high_hours")
    return errors


def validate(feature: str, output: Any) -> list[str]:
    """Return a list of human-readable problems; an empty list means valid."""
    validator = _VALIDATORS.get(feature)
    if validator is None:
        return [f"unknown feature '{feature}'"]
    errors = [f"{_path(e)}: {e.message}" for e in sorted(validator.iter_errors(output), key=lambda e: list(e.absolute_path))]
    if not errors and isinstance(output, dict):
        errors = _semantic_checks(feature, output)
    return errors


FIXTURE_WRAPPER_SCHEMA = {
    "$schema": DIALECT,
    "type": "object",
    "properties": {
        "fixture_version": {"const": 1},
        "feature": _enum(FEATURE_KEYS),
        "key": _str(120),
        "match": {
            "type": "object",
            "properties": {
                "rddc": RDDC,
                "name_contains": _str(120),
                "intent": _enum(ASSISTANT_INTENTS),
                "patterns": _arr(_str(200), 1, 20),
                "question": _str(300),
                "input_hash": {"type": "string", "pattern": r"^[0-9a-f]{16}$"},
                # live-data preconditions checked before the fixture is served (contract change, round 1b)
                "requires": {
                    "type": "object",
                    "properties": {
                        "initiatives_exist": _arr(RDDC), "initiatives_absent": _arr(RDDC),
                        "health": {"type": "object", "additionalProperties": {
                            "type": "object", "additionalProperties": RAG_OR_UNSCORED}},
                        "stage_in": {"type": "object", "additionalProperties": _arr(_enum(STAGES), 1)},
                        "float_bd": {"type": "object", "additionalProperties": {"type": "integer"}},
                    },
                    "additionalProperties": False,
                },
            },
            "minProperties": 1,
            "additionalProperties": False,
        },
        "variants": {"type": "array", "minItems": 1, "maxItems": 5, "items": {"type": "object"}},
        "authored_by": _str(80),
        "model_emulated": _str(80),
        "simulated_latency_ms": _int(0, 20000),
        "notes": _text(1000),
        "bindings": {"type": "object", "additionalProperties": _str(120)},
    },
    "required": ["fixture_version", "feature", "key", "match", "variants"],
    "additionalProperties": False,
}
_WRAPPER_VALIDATOR = Draft202012Validator(FIXTURE_WRAPPER_SCHEMA)
_PLACEHOLDER = re.compile(r"\{([a-z_][a-z0-9_]*)\}")


def validate_fixture_data(data: Any, path: Path | None = None) -> list[str]:
    """Validate a parsed fixture wrapper and each of its variants."""
    if isinstance(data, dict) and "output" in data:
        return ["fixture uses the void single 'output' key; put outputs in 'variants': [...]"]
    errors = [f"wrapper {_path(e)}: {e.message}" for e in _WRAPPER_VALIDATOR.iter_errors(data)]
    if errors:
        return errors
    feature = data["feature"]
    if path is not None:
        if path.parent.name in SCHEMAS and path.parent.name != feature:
            errors.append(f"wrapper: feature '{feature}' does not match folder '{path.parent.name}'")
        if path.stem != data["key"]:
            errors.append(f"wrapper: key '{data['key']}' does not match file name '{path.stem}'")
    match = data["match"]
    if "intent" in match and feature != "assistant":
        errors.append("wrapper match: 'intent' is only valid for assistant fixtures")
    if feature == "assistant" and not ({"intent", "patterns", "question"} & set(match)):
        errors.append("wrapper match: assistant fixtures need intent, patterns or question")
    for i, variant in enumerate(data["variants"]):
        errors += [f"variants[{i}] {msg}" for msg in validate(feature, variant)]
        if feature == "assistant":
            used = set(_PLACEHOLDER.findall(json.dumps(variant)))
            missing = used - set(data.get("bindings", {}))
            if missing:
                errors.append(f"variants[{i}]: placeholders without bindings: {sorted(missing)}")
    return errors


def validate_fixture_file(path: str | Path) -> list[str]:
    """Load and validate a fixture file; returns error messages (empty = valid)."""
    p = Path(path)
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"cannot read fixture: {exc}"]
    return validate_fixture_data(data, p)


# --------------------------------------------------------------------------------------------
# Anthropic tool definition (forced tool-use structured output)
# --------------------------------------------------------------------------------------------
def tool_definition(feature: str) -> dict:
    schema = {k: v for k, v in SCHEMAS[feature].items() if k != "$schema"}
    meta = FEATURES[feature]
    return {
        "name": f"emit_{feature}",
        "description": f"{meta['title']}: {meta['description']} Always include confidence (0-1), "
                       f"sources (records used) and warnings (missing or doubtful inputs).",
        "input_schema": schema,
    }
