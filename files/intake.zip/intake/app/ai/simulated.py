"""Simulated tier: test-agent fixtures first, then the deterministic generators.

Fixture lookup (master plan §6.1), first match wins:
  1. ``fixtures/<feature>/<RDDC>.json`` (or ``<CRQ>.json`` for cr_compliance; meeting notes match by title only)
  2. a fixture whose ``match.rddc`` equals the initiative, or whose ``match.name_contains`` occurs in the subject name
     (initiative name; "portfolio" for portfolio-wide features; meeting title; SA file name; draft intake name)
  3. ``fixtures/<feature>/<input_hash>.json`` or a fixture whose ``match.input_hash`` equals the input hash
  4. the generator.
A fixture with ``match.input_hash`` only matches that exact input. Regenerate serves the next variant, then
generator variants. Assistant fixtures are showcase Q&A matched on wording (token-set ratio >= 0.88) whose
``bindings`` are re-evaluated against the live database; any unresolved binding or missing citation skips it.
Nothing here reads the clock or a random source, so output is identical run to run.
"""
from __future__ import annotations

import difflib
import json
import logging
import re
from pathlib import Path
from typing import Any

from app import db
from app.ai import assistant, generators, schemas
from app.ai import context as C

log = logging.getLogger("bmo.ai.simulated")
FIXTURE_DIR = Path(__file__).resolve().parent / "fixtures"
DEFAULT_LATENCY_MS = 1400
SHOWCASE_THRESHOLD = 0.88
NAME_ONLY = ("meeting_extract",)  # one initiative has many meeting notes: match on the note title only


_CACHE: dict[str, tuple[int, dict | None]] = {}


def _load(path: Path) -> dict | None:
    """Parsed, validated fixture (cached until the file changes); None when unreadable or invalid."""
    try:
        stamp = path.stat().st_mtime_ns
    except OSError:
        return None
    hit = _CACHE.get(str(path))
    if hit and hit[0] == stamp:
        return json.loads(json.dumps(hit[1])) if hit[1] is not None else None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        log.warning("Unreadable fixture %s", path)
        data = None
    if data is not None:
        errors = schemas.validate_fixture_data(data, path)
        if errors:
            log.warning("Invalid fixture %s: %s", path, errors[:3])
            data = None
    _CACHE[str(path)] = (stamp, data)
    return json.loads(json.dumps(data)) if data is not None else None


def fixtures_for(feature: str) -> list[tuple[Path, dict]]:
    folder = FIXTURE_DIR / feature
    if not folder.is_dir():
        return []
    out = []
    for path in sorted(folder.glob("*.json")):
        data = _load(path)
        if data is not None:
            out.append((path, data))
    return out


def _initiative_state(rddc: str) -> dict | None:
    row = db.query_one("SELECT id, stage, rag_cached, health_cached_json, readiness_date, prod_date, target_release "
                       "FROM initiatives WHERE rddc = ?", (rddc,))
    if row is None:
        return None
    row["health_cached_json"] = db.from_json(row["health_cached_json"], None) if isinstance(row["health_cached_json"], str) \
        else row["health_cached_json"]
    return row


def _live_rag(state: dict, dim: str) -> str:
    health = state.get("health_cached_json") if isinstance(state.get("health_cached_json"), dict) else {}
    if dim == "overall":
        scored = health.get("scored", bool(health)) and health.get("overall") in ("Red", "Amber", "Green")
        return health["overall"] if scored else "Not scored"
    rag = ((health.get("dimensions") or {}).get(dim) or {}).get("rag")
    return rag if rag in ("Red", "Amber", "Green") else "Not scored"


def requirements_met(data: dict) -> bool:
    """Evaluate ``match.requires`` against the live database; a fixture is served only when every requirement holds."""
    req = (data.get("match") or {}).get("requires")
    if not req:
        return True
    known = {"initiatives_exist", "initiatives_absent", "health", "stage_in", "float_bd"}
    if set(req) - known:
        return False
    states: dict[str, dict | None] = {}

    def state(rddc: str) -> dict | None:
        if rddc not in states:
            states[rddc] = _initiative_state(rddc)
        return states[rddc]

    if any(state(r) is None for r in req.get("initiatives_exist", [])):
        return False
    if any(state(r) is not None for r in req.get("initiatives_absent", [])):
        return False
    for rddc, dims in (req.get("health") or {}).items():
        st = state(rddc)
        if st is None or any(_live_rag(st, dim) != want for dim, want in dims.items()):
            return False
    for rddc, stages in (req.get("stage_in") or {}).items():
        st = state(rddc)
        if st is None or st["stage"] not in stages:
            return False
    for rddc, want in (req.get("float_bd") or {}).items():
        st = state(rddc)
        if st is None or C.initiative_float(st) != want:
            return False
    return True


def _hash_ok(data: dict, input_hash: str) -> bool:
    want = (data.get("match") or {}).get("input_hash")
    return (want is None or want == input_hash) and requirements_met(data)


def find_fixture(feature: str, ctx: dict, input_hash: str) -> dict | None:
    keys = ctx.get("keys") or {}
    rddc = keys.get("rddc")
    folder = FIXTURE_DIR / feature
    for stem in [k for k in (keys.get("crq") if feature == "cr_compliance" else None, rddc) if k]:
        path = folder / f"{stem}.json"
        if path.is_file():
            data = _load(path)
            if data and _hash_ok(data, input_hash):
                return data
    candidates = fixtures_for(feature)
    name = str(keys.get("name") or "").lower()
    if feature not in NAME_ONLY:
        for _path, data in candidates:
            match = data.get("match") or {}
            if rddc and match.get("rddc") == rddc and _hash_ok(data, input_hash):
                return data
    for _path, data in candidates:
        match = data.get("match") or {}
        needle = str(match.get("name_contains") or "").lower()
        if needle and name and needle in name and _hash_ok(data, input_hash):
            return data
    path = folder / f"{input_hash}.json"
    if path.is_file():
        data = _load(path)
        if data and requirements_met(data):
            return data
    for _path, data in candidates:
        if (data.get("match") or {}).get("input_hash") == input_hash and requirements_met(data):
            return data
    return None


def fixture_by_key(feature: str, key: str) -> dict | None:
    path = FIXTURE_DIR / feature / f"{key}.json"
    data = _load(path) if path.is_file() else None
    return data if data and requirements_met(data) else None


# ------------------------------------------------------------------ assistant showcase matching
def _normal(text: str) -> str:
    text = assistant.normalize_message(text).lower().replace("'", "")
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9&/\- ]", " ", text)).strip()


def token_set_ratio(a: str, b: str) -> float:
    ta, tb = set(_normal(a).split()), set(_normal(b).split())
    if not ta or not tb:
        return 0.0
    inter = " ".join(sorted(ta & tb))
    diff_a = " ".join(sorted(ta - tb))
    diff_b = " ".join(sorted(tb - ta))
    t1 = f"{inter} {diff_a}".strip()
    t2 = f"{inter} {diff_b}".strip()

    def r(x: str, y: str) -> float:
        return difflib.SequenceMatcher(None, x, y).ratio() if x and y else 0.0

    return max(r(inter, t1), r(inter, t2), r(t1, t2))


def _looks_like_regex(p: str) -> bool:
    return bool(re.search(r"[\\^$*+?()\[\]|{}]", p))


def _specific_tokens(text: str) -> set[str]:
    """Words that change the meaning of a question: months, quarters, ids, people and components."""
    words = set(_normal(text).split())
    vocab = set(assistant.MONTH_WORDS) | {"q1", "q2", "q3", "q4"} | set(assistant.TEAM_WORDS)
    for syns in assistant.COMPONENT_SYNONYMS.values():
        vocab |= {s for s in syns if " " not in s}
    for p in assistant.people():
        vocab |= set(_normal(p["name"]).split())
    out = {w for w in words if w in vocab or re.fullmatch(r"(rddc-)?\d{5}|crq\d+|dc-\d{4}|wbs-\d{3}", w)}
    return out


def showcase_score(message: str, data: dict, specific: set[str] | None = None) -> float:
    match = data.get("match") or {}
    texts = [match["question"]] if match.get("question") else []
    texts += [p for p in match.get("patterns") or [] if not _looks_like_regex(p)]
    fixture_words = set().union(*(set(_normal(t).split()) for t in texts)) if texts else set()
    if (_specific_tokens(message) if specific is None else specific) - fixture_words:
        return 0.0
    best = 0.0
    msg_n = _normal(message)
    for t in texts:
        tsr = token_set_ratio(message, t)
        plain = difflib.SequenceMatcher(None, msg_n, _normal(t)).ratio()
        if tsr >= SHOWCASE_THRESHOLD and plain >= 0.6:
            best = max(best, (tsr + plain) / 2)
    return best


def _substitute(obj: Any, values: dict[str, str]) -> Any:
    if isinstance(obj, str):
        def fill(m: re.Match) -> str:
            val = values.get(m.group(1))
            if val is None:
                return m.group(0)
            # "{util}%" and "{util}" both read right whether or not the bound value carries its own % sign
            return val if (m.group(2) and val.endswith("%")) else val + m.group(2)
        return re.sub(r"\{([a-z_][a-z0-9_]*)\}(%?)", fill, obj)
    if isinstance(obj, list):
        return [_substitute(x, values) for x in obj]
    if isinstance(obj, dict):
        return {k: _substitute(v, values) for k, v in obj.items()}
    return obj


def render_showcase(data: dict, variant_index: int) -> dict | None:
    """Fixture variant with live-bound numbers; None when a binding or a citation does not hold."""
    values: dict[str, str] = {}
    for placeholder, spec in (data.get("bindings") or {}).items():
        val = assistant.resolve_binding(spec)
        if val is None:
            return None
        values[placeholder] = val
    variants = data["variants"]
    out = _substitute(variants[min(variant_index, len(variants) - 1)], values)
    if schemas.validate("assistant", out):
        return None
    if not all(assistant.citation_exists(c) for c in out.get("citations", [])):
        return None
    return out


def match_showcase(message: str, ctx: dict) -> dict | None:
    scored = []
    ents = None
    routed = None
    specific = _specific_tokens(message)
    for _path, data in fixtures_for("assistant"):
        if not requirements_met(data):
            continue
        s = showcase_score(message, data, specific)
        match = data.get("match") or {}
        if not s and not match.get("question") and match.get("intent") and match.get("patterns"):
            regexes = [p for p in match["patterns"] if _looks_like_regex(p)]
            if regexes and any(re.search(p, message, re.IGNORECASE) for p in regexes):
                if ents is None:
                    ents = assistant.extract_entities(message, ctx)
                    routed, _ = assistant.route_intent(message, ents)
                if routed == match["intent"] and not ents["initiatives"] and not ents["resources"]:
                    s = 0.5
        if s:
            scored.append((s, data["key"], data))
    scored.sort(key=lambda x: (-x[0], x[1]))
    return scored[0][2] if scored else None


# ------------------------------------------------------------------ entry point
def run(feature: str, ctx: dict, input_hash: str, prev: dict | None = None) -> dict:
    """Returns {output, mode, fixture_key, variant_index, model, latency_ms}."""
    if prev and prev.get("feature") == feature:
        next_index = int(prev.get("variant_index") or 0) + 1
        if prev.get("mode") in ("simulated_fixture",) and prev.get("fixture_key"):
            data = fixture_by_key(feature, prev["fixture_key"])
            if data and next_index < len(data["variants"]):
                out = _fixture_output(feature, data, next_index)
                if out is not None:
                    return _fixture_result(data, out, next_index)
        return _generated(feature, ctx, next_index, next_index)
    if feature == "assistant":
        message = assistant.normalize_message(ctx["inputs"].get("message") or "")
        intent, ents = assistant.resolve(message, ctx)
        # a question asked inside an initiative workspace is about that initiative: no portfolio showcase answers
        # page-scoped questions answer for that initiative; the weekly summary must match the Write Executive Summary button
        data = None if (ents.get("from_page") or intent in ("release_train", "status_report")) else match_showcase(message, ctx)
        if data:
            out = render_showcase(data, 0)
            if out is not None:
                return _fixture_result(data, out, 0)
        return _generated(feature, ctx, 0, 0)
    data = find_fixture(feature, ctx, input_hash)
    if data:
        out = _fixture_output(feature, data, 0)
        if out is not None:
            return _fixture_result(data, out, 0)
    return _generated(feature, ctx, 0, 0)


def _fixture_output(feature: str, data: dict, index: int) -> dict | None:
    if feature == "assistant":
        return render_showcase(data, index)
    out = json.loads(json.dumps(data["variants"][index]))
    return None if schemas.validate(feature, out) else out


def _fixture_result(data: dict, out: dict, index: int) -> dict:
    return {"output": out, "mode": "simulated_fixture", "fixture_key": data["key"], "variant_index": index,
            "model": data.get("model_emulated"), "latency_ms": int(data.get("simulated_latency_ms") or DEFAULT_LATENCY_MS)}


def _generated(feature: str, ctx: dict, gen_variant: int, index: int) -> dict:
    out = generators.generate(feature, ctx, gen_variant)
    return {"output": out, "mode": "simulated_generated", "fixture_key": None, "variant_index": index, "model": None,
            "latency_ms": None}
