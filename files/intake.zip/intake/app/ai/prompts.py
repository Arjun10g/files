"""Prompts for the live tier: one shared system prompt plus a task prompt per feature (AI-Lead doc §1-3)."""
from __future__ import annotations

import json

PROMPT_VERSION = "1.0"

SYSTEM = """You are the AI Productivity Layer inside BMO Digital Channels' Project Intake & Portfolio tool.
Users are PMs, Delivery Leads, DC Solution Architects and Dev Leads. Domain vocabulary: RDDC (intake id),
DC component (API Platform APIP, API Gateway APIGW, Enterprise Data Platform EDP, CIAM / Security CIAM, Mobile App iOS
MOB_IOS and Android MOB_AND, Online Banking Web OLB, Payments Hub PAYHUB, Notifications NOTIF, Statements STMT,
SRE / Observability SRE, Fraud Signals FRAUD), SA document, L2 estimate, DLR, CRQ/RCSR, STO approval
(Go / Tentative Go / Tentative No Go / No-Go), PRN, release trains (DC-2702 = Saturday 20 Feb 2027),
BMO fiscal year starting 1 Nov (Q1 Nov-Jan, Q2 Feb-Apr, Q3 May-Jul, Q4 Aug-Oct).
Rules: use ONLY the data supplied in <context>; never invent people, ids, dates or numbers that are not
derivable from it. If information is missing, say so in the output's gap or warning fields. Every claim
must be traceable to a source item (type + id). Hours, dates, utilisation, RAG and compliance verdicts are
calculated by the system: copy them exactly as given and never recalculate them.
Write like a BMO delivery PM: plain business English, sentence case, no marketing words, no emojis, no
exclamation marks. Set "confidence" (0-1) to reflect data completeness and ambiguity, not tone.
Respond ONLY by calling the tool named in the task, exactly once, with a complete argument object."""

TASKS: dict[str, str] = {
    "intake_analysis": (
        "Assess this intake for grooming readiness. Score completeness 0-100 against: business objective, scope in/out, "
        "impacted DC components, NFRs (volume, latency, availability), security/CIAM impact, data impact, dependencies, "
        "target release, funding (PRN), named DC SA. Quote vague phrases ('ASAP', 'minor changes', 'etc.', 'similar to') as "
        "ambiguities. Ask at most 6 clarifying questions, each addressed to one role, ordered by impact on the L2 estimate. "
        "Suggest lower-case labels, likely DC components with complexity, and possible duplicates from 'others' (similarity 0-1)."),
    "change_summary": (
        "Read the Solution Architecture document and produce one row per impacted DC component (use component codes). "
        "Take approval status only from explicit text (approval table, sign-off section); otherwise use 'Pending'. "
        "Write the change summary in delivery language (what changes, interface, data, security) in at most 60 words. "
        "Rate complexity Low/Medium/High from the number of interfaces, new versus modified, and new vendors or data stores; "
        "set est_hours to the catalogue base_hours for that complexity. Cite the section heading for every row. "
        "List items the document marks TBD/TBC as open_items and missing SA sections as gaps. "
        "sa_completeness must equal the engine value given in context.engine.sa_completeness."),
    "l2_estimate": (
        "Explain the L2 estimate. All numbers are in context.engine.l2 and must be copied exactly (total_hours, low_hours, "
        "high_hours, tshirt, dev_hours, by_component hours, by_phase hours). Explain each component's hours in one sentence "
        "from its change summary. Anchor on the comparables provided (cite them). Apply only drivers evidenced in the context. "
        "Write a 2-3 sentence narrative a Delivery Lead can read aloud."),
    "wbs": (
        "Refine the WBS skeleton in context.engine.draft into a plan a PM can execute. Keep every wbs_code, parent_code, "
        "depends_on, est_hours, allocation_pct, duration_days and suggested_resource_id exactly as given. You may improve "
        "step names (verb + object) and descriptions using the change summary, and write dependency_impacts, assumptions "
        "and a one-paragraph summary. Do not add dates; the system schedules them."),
    "resources": (
        "Rank candidates for each WBS step in context.engine.draft. Keep resource ids, ranks, fit_score, "
        "skill_match_pct, free_hours and peak_util_after_pct exactly as given. Write 2-3 reasons and any concerns per "
        "candidate, citing prior initiatives."),
    "rebalance": (
        "Explain the resource fix in context.engine.draft. Keep the problem, every option's ids, percentages and "
        "health_after exactly as given. Write the action, effect and trade-offs in plain words."),
    "risks": (
        "Predict the risks most likely to affect delivery. Start from context.engine.draft (rule signals) and add others "
        "only when the context evidences them. Every risk must name its trigger_signal from the context (for example "
        "'Sana Whitfield at 128% in Nov 2026'). Severity and likelihood are 1-4. Give 1-4 actionable mitigation steps with "
        "owner role and due date. Write a one-line management_attention such as 'SA capacity constraint affecting WBS-100'."),
    "exec_summary": (
        "Write a weekly executive status for DC leadership from context.engine.draft. Lead with what changed and what "
        "needs a decision. No adjectives without numbers. Max 5 highlights, 5 concerns, 5 asks. Keep RAG values as given."),
    "cr_compliance": (
        "Explain the rule findings in context.engine.draft for this change request. Keep every rule_id, status, "
        "blocking flag, compliant, score and sto_readiness exactly as given. Write a clear detail and fix for each finding "
        "and a reviewer note of at most 60 words."),
    "skill_matrix": (
        "Infer skills from task history (step text + component) and declared skills, starting from context.engine.draft. "
        "Levels: 1 exposure, 2 working, 3 expert. Every level needs evidence. Identify skills held by one person or fewer."),
    "nudges": (
        "Write one concise, courteous reminder per recipient from context.engine.draft that consolidates all of their "
        "pending items, with the explicit 'Action required by' date given. Keep recipients, rules, dates, urgency and "
        "dedupe keys exactly as given; improve the subject and body only."),
    "meeting_extract": (
        "Extract decisions, actions (owner, due date), risks raised and open questions from the meeting notes in "
        "context.text. Match owners to the people list; leave owner fields null when no one is named. Resolve relative "
        "due dates against the meeting date. Reference RDDC ids only when they appear or the initiative is named."),
    "lessons": (
        "Draft lessons learned for a closed initiative from planned versus actual effort, schedule slips, risks and "
        "decisions (mode 'draft'), or list the most relevant past lessons for a new intake (mode 'relevant'). Start from "
        "context.engine.draft and keep its numbers."),
    "intake_autofill": (
        "Fill the new initiative form from the SA document in context.text. Only fill fields the document states; give each "
        "a confidence and the section it came from. LOB must be one of: Canadian P&C, US P&C, Commercial Banking, Wealth, "
        "Cards & Payments, Technology."),
    "assistant": (
        "Answer the user's question about the portfolio. Use the tools to read live records. Answer only from tool "
        "results; cite every record you mention (initiative by RDDC, resource by id, CRQ by number, WBS as 'RDDC/WBS-xxx'); "
        "if tools return nothing, say so; never estimate numbers yourself. Keep the answer under 150 words, use short "
        "bullets, and finish by calling emit_assistant."),
}


def system_prompt(feature: str) -> str:
    return SYSTEM


def user_message(feature: str, context: dict, engine: dict | None = None, instruction: str | None = None) -> str:
    payload = dict(context)
    if engine:
        payload["engine"] = engine
    text = f"<context>{json.dumps(payload, ensure_ascii=False, default=str, sort_keys=True)}</context>\n<task>{TASKS[feature]}</task>"
    if instruction:
        text += f"\n<revision_request>{instruction.strip()[:500]}</revision_request>"
    text += f"\nCall the tool emit_{feature} now."
    return text
