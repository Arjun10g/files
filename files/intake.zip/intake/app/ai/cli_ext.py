"""AI command-line tools: ``validate-fixtures`` and ``capture-fixtures``.

Run directly (``python -m app.ai.cli_ext validate-fixtures``) or through ``app.cli`` via ``register(subparsers)``.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

from app import db
from app.ai import assistant, claude, generators, schemas
from app.ai import context as C
from app.ai.simulated import FIXTURE_DIR

RESOURCE_KEYS = ("suggested_resource_id", "resource_id", "owner_resource_id", "recipient_resource_id", "from_resource_id",
                 "to_resource_id", "recommended_resource_id")
RDDC_KEYS = ("rddc", "initiative_rddc")


def _walk(obj: Any, found: dict[str, set]) -> None:
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in RESOURCE_KEYS and isinstance(v, int):
                found["resources"].add(v)
            elif k in RDDC_KEYS and isinstance(v, str):
                found["rddc"].add(v)
            elif k == "prior_work" and isinstance(v, list):
                found["rddc"].update(x for x in v if isinstance(x, str))
            else:
                _walk(v, found)
    elif isinstance(obj, list):
        for x in obj:
            _walk(x, found)


def reference_problems(data: dict, known_rddc: set[str], hero_rddc: str = "RDDC-24817") -> list[str]:
    """Seed references a fixture makes that do not exist (the hero RDDC is created live, so it is allowed)."""
    problems = []
    found: dict[str, set] = {"resources": set(), "rddc": set()}
    _walk(data.get("variants"), found)
    if (data.get("match") or {}).get("rddc"):
        found["rddc"].add(data["match"]["rddc"])
    res_ids = {r["id"] for r in db.query("SELECT id FROM resources")}
    missing_res = sorted(found["resources"] - res_ids)
    if missing_res:
        problems.append(f"unknown resource ids {missing_res}")
    missing_rddc = sorted(r for r in found["rddc"] - known_rddc if r != hero_rddc)
    if missing_rddc:
        problems.append(f"unknown RDDC {missing_rddc}")
    for spec in (data.get("bindings") or {}).values():
        name = str(spec).split(":")[0]
        if name not in assistant.BINDINGS:
            problems.append(f"binding '{spec}' is not a known query")
    return problems


def validate_fixtures(fixture_dir: Path = FIXTURE_DIR, check_references: bool = True, out=sys.stdout) -> int:
    files = sorted(p for p in fixture_dir.rglob("*.json") if p.name != "manifest.json")
    check = check_references and db.db_ready()
    known = {r["rddc"] for r in db.query("SELECT rddc FROM initiatives")} if check else set()
    bad = 0
    for path in files:
        problems = schemas.validate_fixture_file(path)
        if not problems and check:
            problems = reference_problems(json.loads(path.read_text(encoding="utf-8")), known)
        if problems:
            bad += 1
            out.write(f"FAIL {path.relative_to(fixture_dir)}\n")
            for p in problems[:8]:
                out.write(f"     {p}\n")
    out.write(f"{len(files) - bad}/{len(files)} fixture files valid"
              f"{'' if check else ' (schema only; database not ready for reference checks)'}\n")
    return 1 if bad else 0


def capture_fixtures(features: list[str], initiatives: list[str], out=sys.stdout) -> int:
    """Run the live tier and save each answer as fixtures/<feature>/<input_hash>.json."""
    if not claude.api_key_present():
        out.write("Live Claude is not configured on this machine (set ANTHROPIC_API_KEY).\n")
        return 1
    rows = db.query("SELECT id, rddc FROM initiatives WHERE id > 0 ORDER BY id")
    targets = [r for r in rows if r["rddc"] in initiatives or str(r["id"]) in initiatives] if initiatives else rows
    written = 0
    for feature in features:
        scope = schemas.FEATURES[feature]["scope"]
        ids: list[int | None] = [t["id"] for t in targets] if scope in ("initiative", "both") else [None]
        for iid in ids:
            ctx = C.build_context(feature, iid, {})
            ihash = C.input_hash(ctx)
            t0 = time.monotonic()
            try:
                engine = {"draft": generators.generate(feature, ctx)}
                res = claude.run(feature, C.compact(ctx), engine)
            except claude.LiveError as exc:
                out.write(f"skip {feature} {iid or 'portfolio'}: {exc}\n")
                continue
            problems = schemas.validate(feature, res["output"])
            if problems:
                out.write(f"skip {feature} {iid or 'portfolio'}: {problems[:2]}\n")
                continue
            data = {"fixture_version": 1, "feature": feature, "key": ihash, "match": {"input_hash": ihash},
                    "authored_by": "capture-fixtures", "model_emulated": res["model"],
                    "simulated_latency_ms": min(int((time.monotonic() - t0) * 1000), 20000), "variants": [res["output"]]}
            path = FIXTURE_DIR / feature / f"{ihash}.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
            written += 1
            out.write(f"saved {path.relative_to(FIXTURE_DIR)}\n")
    out.write(f"{written} fixture files written\n")
    return 0


def _cmd_validate(args) -> int:
    return validate_fixtures(Path(args.dir) if args.dir else FIXTURE_DIR, not args.schema_only)


def _cmd_capture(args) -> int:
    features = args.feature or [f for f in schemas.FEATURE_KEYS if f != "assistant"]
    unknown = [f for f in features if f not in schemas.SCHEMAS]
    if unknown:
        sys.stdout.write(f"Unknown feature: {', '.join(unknown)}\n")
        return 2
    return capture_fixtures(features, args.initiative or [])


def register(subparsers) -> None:
    p = subparsers.add_parser("validate-fixtures", help="Check every AI fixture against the output schemas and seed ids")
    p.add_argument("--dir", default=None, help="Fixture folder (default app/ai/fixtures)")
    p.add_argument("--schema-only", action="store_true", help="Skip the seed reference checks")
    p.set_defaults(func=_cmd_validate)
    c = subparsers.add_parser("capture-fixtures", help="Record live Claude answers as input-hash fixtures")
    c.add_argument("--feature", action="append", help="Feature key (repeatable); default all except assistant")
    c.add_argument("--initiative", action="append", help="RDDC or id (repeatable); default all")
    c.set_defaults(func=_cmd_capture)


COMMANDS = {"validate-fixtures": _cmd_validate, "capture-fixtures": _cmd_capture}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m app.ai.cli_ext")
    sub = parser.add_subparsers(dest="command", required=True)
    register(sub)
    args = parser.parse_args(argv)
    return int(args.func(args) or 0)


if __name__ == "__main__":
    sys.exit(main())
