"""Deterministic generators: the rules-engine tier for every AI feature.

``generate(feature, ctx, variant=0)`` returns an output that validates against ``schemas.SCHEMAS[feature]``
for any initiative, including unseen intakes. No randomness and no clock reads: everything derives from
``ctx`` (built by ``context.build_context``), so two runs over the same data are byte-identical.
``variant`` only changes wording (Regenerate after the fixture variants run out).
"""
from __future__ import annotations

import difflib
import math
import re
from datetime import date, timedelta
from typing import Any

from app.ai import context as C
from app.ai.schemas import COMPONENT_NAMES

# ------------------------------------------------------------------ formatting helpers
MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")


def fmt_date(value: Any) -> str:
    if not value:
        return "not set"
    d = C.to_date(value)
    return f"{d.day} {MONTHS[d.month - 1]} {d.year}"


def fmt_day(value: Any) -> str:
    d = C.to_date(value)
    return f"{('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun')[d.weekday()]} {d.day} {MONTHS[d.month - 1]}"


def fmt_month(month: str) -> str:
    y, m = month.split("-")
    return f"{MONTHS[int(m) - 1]} {y}"


def fmt_hours(h: Any) -> str:
    h = float(h or 0)
    return f"{h:,.0f} h" if abs(h - round(h)) < 0.05 else f"{h:,.1f} h"


def clip(text: Any, n: int) -> str:
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    if len(text) <= n:
        return text
    cut = text[: n - 1].rsplit(" ", 1)[0].rstrip(",;:")
    return cut + "…"


def words(text: str, n: int) -> str:
    parts = re.sub(r"\s+", " ", text or "").strip().split(" ")
    return " ".join(parts[:n]) + ("…" if len(parts) > n else "")


def rint(x: float) -> int:
    return math.floor(float(x) + 0.5)


def src(type_: str, id_: Any, label: str, excerpt: str | None = None) -> dict:
    s = {"type": type_, "id": id_ if isinstance(id_, (int, str)) else str(id_), "label": clip(label, 200) or str(id_)}
    if excerpt:
        s["excerpt"] = clip(excerpt, 400)
    return s


def norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (text or "").lower())


def pick(variant: int, *options: str) -> str:
    return options[variant % len(options)]


def month_of(d: Any) -> str:
    return C.to_date(d).strftime("%Y-%m")


def bd_after_today(ctx: dict, n: int) -> str:
    return C.add_business_days(ctx["today"], n).isoformat()


def _cap(lst: list, n: int) -> list:
    return lst[:n]


# ------------------------------------------------------------------ domain lexicons
COMPONENT_ALIASES = {
    "APIP": ["api platform", "eapi", "enterprise api"], "APIGW": ["api gateway"],
    "EDP": ["enterprise data platform", "edp"], "CIAM": ["ciam", "identity and access"],
    "MOB_IOS": ["ios app", "iphone"], "MOB_AND": ["android app"], "OLB": ["online banking"],
    "PAYHUB": ["payments hub"], "NOTIF": ["notifications service", "push notification"],
    "STMT": ["statements & documents", "statements"], "SRE": ["sre / observability", "observability"],
    "FRAUD": ["fraud signals"],
}
COMPONENT_SKILLS = {
    "APIP": ["OpenAPI", "API design", "Java / Spring", "Idempotency"],
    "APIGW": ["Gateway policy", "API design"],
    "EDP": ["Kafka", "Event streams", "EDP feeds"],
    "CIAM": ["OAuth2 / OIDC", "Scopes", "Step-up MFA"],
    "MOB_IOS": ["Swift", "Accessibility", "Biometrics"],
    "MOB_AND": ["Kotlin", "Push notifications"],
    "OLB": ["React", "WCAG 2.1", "Design system"],
    "PAYHUB": ["Payments APIs", "Idempotency", "Java / Spring"],
    "NOTIF": ["Push notifications", "Event streams", "Node.js"],
    "STMT": ["Statements", "Node BFF", "React"],
    "SRE": ["SLOs", "Dashboards", "Alerting"],
    "FRAUD": ["MFA", "Session management", "Biometrics"],
}
SA_SKILL_BY_COMPONENT = {"APIP": "API", "APIGW": "API", "PAYHUB": "Payments", "FRAUD": "Payments", "EDP": "Data",
                         "STMT": "Data", "CIAM": "Identity", "MOB_IOS": "Mobile", "MOB_AND": "Mobile", "OLB": "Web",
                         "NOTIF": "Mobile"}
PHASE_SKILLS = {
    "Integration": ["API design", "Code review"], "QA": ["API automation", "Regression", "Performance testing"],
    "Hypercare": ["SLOs", "Alerting", "Dashboards"], "mobile_regression": ["Mobile testing"],
    "web_regression": ["React", "WCAG 2.1"],
}
STEP_TEMPLATES = {
    "APIP": "build and version the APIs", "APIGW": "gateway policies and rate limits",
    "EDP": "publish data feeds and events", "CIAM": "scopes, consent and access policies",
    "MOB_IOS": "iOS app changes", "MOB_AND": "Android app changes", "OLB": "Online Banking web changes",
    "PAYHUB": "payment processing changes", "NOTIF": "notification templates and delivery",
    "STMT": "statement and document changes", "SRE": "SLO dashboards and alerting",
    "FRAUD": "fraud signal integration",
}
VAGUE_PHRASES = (
    "asap", "as soon as possible", "minor changes", "minor ui changes", "small change", "simple change", "etc",
    "similar to", "like the existing", "and so on", "tbd", "tbc", "to be confirmed", "to be determined",
    "some", "various", "several", "a few", "quickly", "user friendly", "user-friendly", "seamless", "robust",
    "scalable", "best practice", "industry standard", "as needed", "if possible", "where possible",
    "nice to have", "improve", "enhance", "optimize", "optimise", "modernize", "modernise", "real-time",
    "real time", "high volume", "fast", "all channels",
)
LOB_ALIASES = {
    "US P&C": ("us p&c", "u.s. personal & commercial", "us personal and commercial", "u.s. p&c", "us personal & commercial"),
    "Canadian P&C": ("canadian p&c", "canadian personal & commercial", "canadian personal and commercial", "cdn p&c"),
    "Commercial Banking": ("commercial banking",),
    "Wealth": ("wealth", "wealth management", "bmo wealth"),
    "Cards & Payments": ("cards & payments", "cards and payments", "cards"),
    "Technology": ("technology", "tech"),
}
LOB_LABEL = {"US P&C": "us-p&c", "Canadian P&C": "cdn-p&c", "Commercial Banking": "commercial",
             "Wealth": "wealth", "Cards & Payments": "cards", "Technology": "technology"}
# Business-domain labels in priority order (decision 10: an accounts/transactions API is not "payments").
THEME_LABELS = (
    (r"\baccounts?\b|/v\d/accounts", "accounts"), (r"open banking|aggregator", "open-banking"),
    (r"\bpartners?\b", "partner-api"), (r"\bpayments? (hub|processing|initiation|rail)|e-transfer|bill pay|send money", "payments"),
    (r"\bcredit cards?\b|\binstal?lments?\b", "cards"), (r"\bstatements?\b|e-delivery", "statements"),
    (r"\balerts?\b|notification", "alerts"), (r"accessib|wcag", "accessibility"),
    (r"\bmfa\b|passkey|biometric|step-up", "authentication"), (r"\bmobile app\b|\bios app\b|\bandroid app\b", "mobile"),
    (r"regulat|\baml\b", "regulatory"), (r"observab|\bslos?\b|monitoring uplift", "observability"),
)
MAX_THEME_LABELS = 3


def label_corpus(name: str, description: str, sa_text: str) -> str:
    """Text that describes what is being built: name, description, SA context and in-scope items (never out of scope)."""
    parts = [name or "", description or ""]
    for sec in split_sections(sa_text or ""):
        head = sec["heading"].lower()
        if "context" in head or "background" in head or "overview" in head or head.endswith("scope"):
            body = re.split(r"(?im)^\s*out of scope", sec["body"])[0]
            parts.append(body)
    return "\n".join(parts).lower()


def suggest_labels(name: str, description: str, sa_text: str, lob: str | None) -> list[str]:
    text = label_corpus(name, description, sa_text)
    labels = [label for pattern, label in THEME_LABELS if re.search(pattern, text)][:MAX_THEME_LABELS]
    if lob in LOB_LABEL:
        labels.append(LOB_LABEL[lob])
    return labels


def catalog_by_code(catalog: list[dict]) -> dict[str, dict]:
    return {c["code"]: c for c in catalog}


def component_terms(cat: dict) -> list[str]:
    terms = [cat["name"].lower()] + COMPONENT_ALIASES.get(cat["code"], []) + [k.lower() for k in cat.get("keywords") or []]
    return sorted({t for t in terms if t}, key=len, reverse=True)


def _term_hits(text: str, term: str) -> int:
    if term.startswith("/"):
        return text.count(term)
    return len(re.findall(r"(?<![a-z0-9])" + re.escape(term) + r"(?![a-z0-9])", text))


def mentioned_component(segment: str, catalog: list[dict]) -> str | None:
    """Best component named in a short segment (names/aliases only, longest first)."""
    low = segment.lower()
    best, best_len = None, 0
    for cat in catalog:
        for term in [cat["name"].lower(), cat["code"].lower().replace("_", " ")] + COMPONENT_ALIASES.get(cat["code"], []):
            if len(term) > best_len and _term_hits(low, term):
                best, best_len = cat["code"], len(term)
    return best


# ------------------------------------------------------------------ SA document parsing
HEADING_RE = re.compile(r"^\s*(?:#{1,6}\s+(?P<md>.+?)|(?P<num>\d{1,2}(?:\.\d{1,2})*)[.)]?\s+(?P<title>[A-Z][^.:]{1,80}))\s*$")


def split_sections(text: str) -> list[dict]:
    sections: list[dict] = [{"heading": "Document", "lines": []}]
    for line in (text or "").splitlines():
        m = HEADING_RE.match(line)
        if m and len(line.strip()) <= 90:
            heading = (m.group("md") or f"{m.group('num')} {m.group('title')}").strip()
            sections.append({"heading": heading, "lines": []})
        else:
            sections[-1]["lines"].append(line)
    out = []
    for s in sections:
        body = "\n".join(s["lines"]).strip()
        if body or s["heading"] != "Document":
            out.append({"heading": s["heading"], "body": body})
    return out


def sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+|\n+", text or "")
    return [p.strip(" -•\t") for p in parts if len(p.strip()) > 3]


def find_section(sections: list[dict], *keys: str) -> dict | None:
    for s in sections:
        h = s["heading"].lower()
        if any(k in h for k in keys):
            return s
    return None


TABLE_GAP = re.compile(r"\S {2,}\S")  # PDF text keeps table columns apart with runs of spaces
APPROVAL_RE = re.compile(r"\b(approved|pending|not required|rejected|n/?a)\b", re.IGNORECASE)
APPROVAL_MAP = {"approved": "Approved", "pending": "Pending", "not required": "Not required", "rejected": "Rejected",
                "n/a": "Not required", "na": "Not required"}


def parse_approvals(sections: list[dict], catalog: list[dict], people: list[str]) -> dict[str, dict]:
    sec = find_section(sections, "approval", "sign-off", "signoff")
    if not sec:
        return {}
    out: dict[str, dict] = {}
    segments: list[str] = []
    for line in sec["body"].splitlines():
        if "|" in line or TABLE_GAP.search(line):
            segments.append(line)
        else:
            segments.extend(re.split(r"\s*[·;•]\s*", line))
    for seg in segments:
        code = mentioned_component(seg, catalog)
        m = APPROVAL_RE.search(seg)
        if not code or not m or code in out:
            continue
        approver = next((p for p in people if p.lower() in seg.lower()), None)
        word = re.sub(r"\s+", " ", m.group(1).lower())
        out[code] = {"approval": APPROVAL_MAP.get(word, "Pending"), "approver": approver, "excerpt": seg.strip(" |")}
    return out


def parse_explicit_components(sections: list[dict], catalog: list[dict]) -> list[tuple[str, str, str]]:
    """[(code, complexity, excerpt)] from an 'Impacted components' section: table rows or 'Name (High)' lists."""
    sec = find_section(sections, "impacted component", "components impacted", "component impact")
    if not sec:
        return []
    out, seen = [], set()
    plain = []
    for line in sec["body"].splitlines():
        if "|" in line:
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
        elif TABLE_GAP.search(line):
            cells = [c.strip() for c in re.split(r"\s{2,}", line.strip())]
        else:
            plain.append(line)
            continue
        cx = next((c.capitalize() for c in cells if c.lower() in ("high", "medium", "low")), None)
        code = next((found for found in (mentioned_component(c, catalog) for c in cells) if found), None)
        if code and cx and code not in seen:
            seen.add(code)
            out.append((code, cx, " · ".join(c for c in cells if c)))
    for m in re.finditer(r"([A-Za-z][A-Za-z0-9&/–\- ]{1,60}?)\s*[(\-–:]\s*(High|Medium|Low)\b\)?", "\n".join(plain)):
        code = mentioned_component(m.group(1), catalog)
        if code and code not in seen:
            seen.add(code)
            out.append((code, m.group(2).capitalize(), m.group(0).strip()))
    return out


def open_items(text: str, sections: list[dict]) -> list[str]:
    sec = find_section(sections, "open item", "open question", "outstanding")
    pool = sentences(sec["body"]) if sec else sentences(text)
    items = []
    for s in pool:
        if re.search(r"\bTBD\b|\bTBC\b|to be confirmed|to be determined", s, re.IGNORECASE) or (sec and len(s) > 5):
            items.append(clip(s.rstrip("."), 300))
    seen, out = set(), []
    for i in items:
        if i.lower() not in seen:
            seen.add(i.lower())
            out.append(i)
    return out[:15]


def out_of_scope(text: str) -> list[str]:
    lines = (text or "").splitlines()
    for i, line in enumerate(lines):
        m = re.search(r"out of scope\s*[:\-–]\s*(.*)$", line, re.IGNORECASE)
        if not m:
            continue
        rest = m.group(1).strip()
        if rest:
            body = rest.split(".")[0]
            parts = [p.strip() for p in re.split(r",|;| and ", body) if p.strip()]
            return [clip(p[0].upper() + p[1:], 300) for p in parts][:15]
        items = []
        for nxt in lines[i + 1:]:
            stripped = nxt.strip()
            if not stripped:
                if items:
                    break
                continue
            if not re.match(r"^[-*•]\s+", stripped):
                break
            items.append(clip(re.sub(r"^[-*•]\s+", "", stripped).rstrip("."), 300))
        return items[:15]
    return []


def sa_sections_flags(score: dict) -> list[dict]:
    if isinstance(score.get("found"), list):
        eng = C._engine("sa_completeness")
        order = [name for name, _ in getattr(eng, "RULES", {}).get("sections", ())] if eng else []
        flags = {str(n): True for n in score["found"]} | {str(n): False for n in score.get("missing") or []}
        names = [n for n in order if n in flags] + [n for n in flags if n not in order]
        return [{"section": clip(n, 80), "found": flags[n]} for n in names][:12]
    missing = [str(m).lower() for m in score.get("missing") or []]

    def is_missing(section: str) -> bool:
        s = section.lower()
        return any(m[:5] == s[:5] or m in s or s in m for m in missing)

    return [{"section": s, "found": not is_missing(s)} for s in C.SA_SECTIONS]


# ------------------------------------------------------------------ people, capacity and candidate scoring
def people_index(ctx: dict) -> dict[int, dict]:
    out = {p["id"]: p for p in (ctx.get("data", {}).get("people_rows") or [])}
    b = ctx.get("bundle") or {}
    for r in b.get("resources", []):
        out[r["id"]] = {**out.get(r["id"], {}), **r}
    return out


def first_with_role(ctx: dict, role: str) -> dict | None:
    for p in sorted(people_index(ctx).values(), key=lambda p: p["id"]):
        if (p.get("role") or "").lower() == role.lower():
            return p
    return None


def own_alloc(bundle: dict) -> dict[tuple[int, str], float]:
    out: dict[tuple[int, str], float] = {}
    for a in bundle.get("allocations", []):
        key = (a["resource_id"], a["month"])
        out[key] = out.get(key, 0.0) + float(a["hours"])
    return out


def task_alloc(bundle: dict, task_id: int | None) -> dict[tuple[int, str], float]:
    out: dict[tuple[int, str], float] = {}
    for a in bundle.get("allocations", []):
        if task_id is not None and a.get("task_id") == task_id:
            key = (a["resource_id"], a["month"])
            out[key] = out.get(key, 0.0) + float(a["hours"])
    return out


def available(res: dict, month: str) -> float:
    val = (res.get("availability") or {}).get(month)
    return float(val if val is not None else (res.get("default_monthly_hours") or 140))


def skill_level(res: dict, skill: str) -> int:
    target = norm(skill)
    for s in res.get("skills") or []:
        if norm(s["skill"]) == target:
            return int(s["level"])
    return 0


def score_candidates(ctx: dict, *, required: list[str], team: str | None, start: str, end: str, hours: float,
                     exclude: dict[tuple[int, str], float], component_code: str | None, phase: str,
                     continuity_ids: set[int], limit: int = 5) -> list[dict]:
    """Rank capacity-tracked people for a piece of work (fit = 0.5 skill + 0.3 free + 0.15 history + 0.05 continuity)."""
    b = ctx["bundle"]
    pool = [r for r in b.get("resources", []) if r.get("capacity_eligible")]
    in_team = [r for r in pool if team and (r.get("team") == team)]
    if not in_team:
        in_team = [r for r in pool if any(skill_level(r, s) for s in required)]
    spread = C.spread_hours(start, end, hours) if hours > 0 else {month_of(start): 0.0}
    history = ctx.get("data", {}).get("task_history") or []
    iid = ctx.get("initiative_id")
    out = []
    for r in in_team:
        levels = {s: skill_level(r, s) for s in required}
        coverage = (sum(min(lv, 3) / 3 for lv in levels.values()) / len(required)) if required else 0.0
        free = 0.0
        peak = 0.0
        for m, h in spread.items():
            avail = available(r, m)
            base = float((r.get("committed") or {}).get(m, 0.0)) - exclude.get((r["id"], m), 0.0)
            free += max(avail - base, 0.0)
            peak = max(peak, (base + h) / avail * 100 if avail else 0.0)
        prior = [t for t in history if t["resource_id"] == r["id"] and t["initiative_id"] != iid
                 and ((component_code and t.get("component_code") == component_code) or (not component_code and t["phase"] == phase))]
        hist = min(len(prior) / 3, 1.0)
        cont = 1.0 if r["id"] in continuity_ids else 0.0
        fit = 0.5 * coverage + 0.3 * (min(free / hours, 1.0) if hours > 0 else 1.0) + 0.15 * hist + 0.05 * cont
        matched = [s for s, lv in levels.items() if lv]
        missing = [s for s, lv in levels.items() if not lv]
        prior_rddc = sorted({t["rddc"] for t in prior})[:10]
        reasons = []
        if matched:
            reasons.append(f"Skills: {', '.join(f'{s} (level {levels[s]})' for s in matched)}")
        if prior_rddc:
            reasons.append(f"Prior work on {', '.join(prior_rddc[:3])}")
        reasons.append(f"{fmt_hours(free)} free across {', '.join(fmt_month(m) for m in sorted(spread))}")
        if cont:
            reasons.append("Already named on this initiative")
        concerns = []
        if peak > 100:
            months_over = [fmt_month(m) for m, h in sorted(spread.items())
                           if available(r, m) and (float((r.get('committed') or {}).get(m, 0.0)) - exclude.get((r['id'], m), 0.0) + h) / available(r, m) > 1.0]
            concerns.append(f"Would be at {rint(peak)}% in {', '.join(months_over) or 'the window'}")
        if missing:
            concerns.append(f"No recorded skill in {', '.join(missing)}")
        out.append({"resource_id": r["id"], "resource_name": r["name"], "team": r.get("team") or "Unassigned",
                    "fit_score": round(fit * 100, 1), "skill_match_pct": round(coverage * 100, 1),
                    "free_hours": round(free, 1), "peak_util_after_pct": round(min(peak, 500.0), 1),
                    "matched_skills": matched[:15], "missing_skills": missing[:15], "prior_work": prior_rddc,
                    "reasons": [clip(x, 300) for x in reasons[:5]], "concerns": [clip(x, 300) for x in concerns[:5]]})
    out.sort(key=lambda c: (-c["fit_score"], c["resource_id"]))
    # decision 9: someone who would go over 100% ranks below an in-capacity alternative with >= 60% skill match
    has_alternative = any(c["peak_util_after_pct"] <= 100 and c["skill_match_pct"] >= 60 for c in out)
    for c in out:
        if c["peak_util_after_pct"] > 100:
            c["concerns"] = [clip(f"Over capacity: {c['concerns'][0]}" if c["concerns"] else "Over capacity", 300)] + c["concerns"][1:]
    if has_alternative:
        out.sort(key=lambda c: (c["peak_util_after_pct"] > 100, -c["fit_score"], c["resource_id"]))
    for i, c in enumerate(out[:limit], start=1):
        c["rank"] = i
    return [{"rank": c["rank"], **{k: v for k, v in c.items() if k != "rank"}} for c in out[:limit]]


# ------------------------------------------------------------------ plan scheduling (shared with apply.py)
def duration_for(hours: float, pct: int, is_milestone: bool = False) -> int:
    if is_milestone or hours <= 0 or not pct:
        return 0
    return max(1, math.ceil(hours * 100 / (7 * pct) - 1e-9))


def choose_prod_date(after: date, trains: list[dict], target_code: str | None) -> tuple[str, str | None, list[str]]:
    """Production milestone date: target train if after readiness and outside the freeze, else the next train."""
    warnings = []
    planned = [t for t in trains if (t.get("status") or "Planned") != "Done"]
    target = next((t for t in planned if t["code"] == target_code), None)
    if target and C.to_date(target["train_date"]) > after and not C.in_freeze(target["train_date"]):
        return target["train_date"], target["code"], warnings
    for t in planned:
        if C.to_date(t["train_date"]) > after and not C.in_freeze(t["train_date"]):
            if target_code:
                warnings.append(f"Readiness misses {target_code}; production moved to {t['code']} ({fmt_date(t['train_date'])}).")
            return t["train_date"], t["code"], warnings
    d = after + timedelta(days=1)
    while d.weekday() != 5 or C.in_freeze(d):
        d += timedelta(days=1)
    warnings.append("No release train after readiness; production set to the next Saturday outside the freeze.")
    return d.isoformat(), None, warnings


def schedule_plan(tasks: list[dict], plan_start: str, trains: list[dict], target_code: str | None) -> dict:
    """Forward pass over business days. tasks: wbs output rows. Returns {dates:{code:(start,end)}, train, warnings}.

    Uses ``app.engines.schedule.schedule_plan`` when installed; the local pass below implements the same pinned rules.
    """
    eng = C._engine("schedule")
    if eng is not None and hasattr(eng, "schedule_plan"):
        target = next((t for t in trains if t["code"] == target_code), None)
        try:
            res = eng.schedule_plan(tasks, plan_start, target_train=target, trains=[t for t in trains if (t.get("status") or "Planned") != "Done"] or None)
        except Exception as exc:  # noqa: BLE001 - a dependency loop falls back to the tolerant local pass
            local = _schedule_plan_local(tasks, plan_start, trains, target_code)
            local["warnings"].insert(0, f"Plan could not be sequenced as given ({clip(str(exc), 120)}).")
            return local
        dates = {c: (v["planned_start"], v["planned_end"]) for c, v in res.items()}
        prod = next((dates[t["wbs_code"]][0] for t in tasks if t.get("is_milestone") and t.get("phase") == "Production"
                     and t["wbs_code"] in dates), None)
        train = next((t["code"] for t in trains if prod and t["train_date"] == prod), None)
        warnings = []
        if target_code and train and train != target_code:
            warnings.append(f"Readiness misses {target_code}; production moved to {train} ({fmt_date(prod)}).")
        return {"dates": dates, "train": train or (target_code if not prod else None), "warnings": warnings}
    return _schedule_plan_local(tasks, plan_start, trains, target_code)


def _schedule_plan_local(tasks: list[dict], plan_start: str, trains: list[dict], target_code: str | None) -> dict:
    by_code = {t["wbs_code"]: t for t in tasks}
    children: dict[str, list[str]] = {}
    for t in tasks:
        if t.get("parent_code") in by_code:
            children.setdefault(t["parent_code"], []).append(t["wbs_code"])
    summary = {c for c, kids in children.items() if float(by_code[c].get("est_hours") or 0) == 0}
    dates: dict[str, tuple[str, str]] = {}
    warnings: list[str] = []
    chosen_train = target_code
    start0 = C.first_business_day_on_or_after(plan_start)
    pending = [t["wbs_code"] for t in tasks]
    guard = 0
    while pending and guard < 10000:
        guard += 1
        progressed = False
        for code in list(pending):
            t = by_code[code]
            prereq = [d for d in t.get("depends_on", []) if d in by_code]
            if code in summary:
                prereq = prereq + children[code]
            if any(p not in dates for p in prereq):
                continue
            if code in summary:
                kids = [dates[k] for k in children[code]]
                dates[code] = (min(k[0] for k in kids), max(k[1] for k in kids))
            else:
                deps = [d for d in t.get("depends_on", []) if d in by_code]
                parent = t.get("parent_code")
                if not deps and parent in by_code:
                    deps = [d for d in by_code[parent].get("depends_on", []) if d in by_code]
                    if any(d not in dates for d in deps):
                        continue
                after = max((C.to_date(dates[d][1]) for d in deps), default=None)
                if t.get("is_milestone") and t.get("phase") == "Production":
                    prod, train, warns = choose_prod_date(after or start0, trains, target_code)
                    chosen_train = train or chosen_train
                    warnings += warns
                    dates[code] = (prod, prod)
                else:
                    start = C.next_business_day(after) if after else start0
                    if t.get("offset_days"):
                        start = max(start, C.add_business_days(start0, int(t["offset_days"])))
                    dur = int(t.get("duration_days") or 0) or duration_for(float(t.get("est_hours") or 0),
                                                                           int(t.get("allocation_pct") or 100))
                    end = start if t.get("is_milestone") else C.span_end(start, max(dur, 1))
                    dates[code] = (start.isoformat(), end.isoformat())
            pending.remove(code)
            progressed = True
        if not progressed:
            for code in pending:
                dates[code] = (start0.isoformat(), start0.isoformat())
            warnings.append("Some dependencies form a loop; those steps start on the plan start date.")
            break
    return {"dates": dates, "train": chosen_train, "warnings": warnings}


def key_dates(tasks: list[dict], dates: dict[str, tuple[str, str]]) -> dict:
    def end_of(phase: str, parent_only: bool = True) -> str | None:
        ends = [dates[t["wbs_code"]][1] for t in tasks if t["phase"] == phase and t["wbs_code"] in dates
                and (not parent_only or not t.get("parent_code"))]
        return max(ends) if ends else None
    return {"qa_date": end_of("QA"), "readiness_date": end_of("Readiness"),
            "prod_date": next((dates[t["wbs_code"]][0] for t in tasks if t.get("is_milestone") and t["phase"] == "Production"
                               and t["wbs_code"] in dates), None),
            "planned_start": min((s for s, _ in dates.values()), default=None),
            "planned_end": max((e for _, e in dates.values()), default=None)}


def plan_start_for(ctx: dict) -> str:
    return C.next_business_day(ctx["today"]).isoformat()


def resolve_owner(task: dict, bundle: dict, ctx: dict | None = None) -> int | None:
    """Owner (SME) id for a WBS row: component lead, DC SA, Tech Lead, QA Lead, requestor, Rel Lead."""
    ini = bundle["initiative"]
    cat = catalog_by_code(bundle.get("component_catalog", []))
    comps = {c["code"]: c for c in bundle.get("components", [])}
    people = list(bundle.get("resources", []))
    if ctx:
        people += list((ctx.get("data") or {}).get("people_rows") or [])

    def role(name: str) -> int | None:
        return next((p["id"] for p in sorted(people, key=lambda p: p["id"]) if (p.get("role") or "").lower() == name.lower()), None)

    code, phase = task.get("component_code"), task.get("phase")
    if code and code in comps and comps[code].get("component_lead_id"):
        return comps[code]["component_lead_id"]
    if code and code in cat:
        return cat[code].get("component_lead_id")
    if phase in ("Estimation", "Architecture"):
        return ini.get("dc_sa_id") or task.get("suggested_resource_id")
    if phase == "Development" or (phase == "Integration" and not task.get("parent_code")):
        return ini.get("tech_lead_id") or task.get("suggested_resource_id")
    if phase in ("Integration", "QA"):
        return role("QA Lead") or task.get("suggested_resource_id")
    if phase == "UAT":
        return ini.get("requestor_id") or task.get("suggested_resource_id")
    if phase in ("Readiness", "Production"):
        return role("Rel Lead") or task.get("suggested_resource_id")
    if phase == "Hypercare":
        return (cat.get("SRE") or {}).get("component_lead_id") or task.get("suggested_resource_id")
    return task.get("suggested_resource_id")


# ================================================================== F1 intake_analysis
CHECKLIST = (
    ("objective", "Business objective", 10, "description_words", "High",
     "What business outcome must this initiative deliver, and how will success be measured?", "Requestor"),
    ("scope", "Scope in and out", 10, r"\bin scope\b|\bout of scope\b|\bscope\b", "High",
     "What is in scope and explicitly out of scope for the first release?", "Requestor"),
    ("components", "Impacted DC components", 15, "components", "High",
     "Which DC components (API Platform, CIAM, EDP, Mobile, Web) are expected to change?", "DC SA"),
    ("nfr", "Non-functional requirements", 10, r"\b(tps|latency|p9\d|availability|sla|rto|rpo|volume|throughput)\b", "Medium",
     "What volumes, response times and availability targets apply?", "DC SA"),
    ("security", "Security and CIAM impact", 10, r"\b(oauth|security|mfa|tls|mtls|consent|token|authentication|passkey|threat)\b", "Medium",
     "Does this change authentication, consent or customer data access?", "DC SA"),
    ("data", "Data impact", 10, r"\b(data|kafka|cdc|retention|warehouse|event|statement|record)\b", "Medium",
     "What data is created, changed or retained, and for how long?", "DC SA"),
    ("dependencies", "Dependencies", 5, r"\b(depend|consumer|upstream|downstream|integration|vendor|partner)\w*", "Low",
     "Which upstream systems, vendors or other initiatives does this depend on?", "Tech Lead"),
    ("release", "Target release or go-live", 10, "release", "Medium",
     "Which release train or go-live date is the business committed to?", "Requestor"),
    ("funding", "Funding (PRN)", 10, "prn", "Medium",
     "Which PRN funds this work, and how many hours are approved?", "DC PM"),
    ("dc_sa", "Named DC SA", 10, "dc_sa", "Low",
     "Who is the DC Solution Architect for this initiative?", "Delivery Lead"),
)


def _intake_subject(ctx: dict) -> dict:
    if ctx.get("subject"):
        s = dict(ctx["subject"])
        s.setdefault("components", [])
        return s
    b = ctx["bundle"]
    ini = b["initiative"]
    return {"name": ini.get("name"), "description": ini.get("description"), "lob": ini.get("lob"),
            "requestor": ini.get("requestor_name") or ini.get("requestor"), "priority": ini.get("priority"),
            "labels": ini.get("labels") or [], "prn_code": ini.get("prn_code"), "dc_sa_name": ini.get("dc_sa_name"),
            "target_release": ini.get("target_release"), "requested_go_live": ini.get("requested_go_live"),
            "sa_text": b.get("sa_doc_text"), "components": [c["code"] for c in b.get("components", [])],
            "rddc": ini.get("rddc"), "id": ini.get("id"), "dc_intake": ini.get("dc_intake"),
            "prn_funded": (b.get("prn") or {}).get("funded_hours"), "l2_hours": ini.get("l2_hours")}


def evidence_snippet(text: str, term: str) -> str:
    """The clause around the first mention of ``term`` (split on commas and full stops outside brackets)."""
    flat = re.sub(r"\s+", " ", text).strip()
    m = re.search(re.escape(term), flat, re.IGNORECASE)
    if not m:
        return clip(flat, 120)
    depth = [0] * (len(flat) + 1)
    level = 0
    for i, ch in enumerate(flat):
        if ch == "(":
            level += 1
        depth[i] = level
        if ch == ")":
            level = max(level - 1, 0)

    def boundary(i: int) -> bool:
        return flat[i] in ",.;" and depth[i] == 0 and (i + 1 >= len(flat) or flat[i + 1] == " ")

    left = m.start()
    while left > 0 and not boundary(left - 1):
        left -= 1
    right = m.end()
    while right < len(flat) and not boundary(right):
        right += 1
    clause = flat[left:right].strip(" ,;.")
    clause = re.sub(r"^(and|with|or|to|for)\s+", "", clause, flags=re.IGNORECASE)
    return clip(clause[0].upper() + clause[1:] if clause else flat, 140)


def likely_components(text: str, catalog: list[dict]) -> list[dict]:
    low = (text or "").lower()
    sections = split_sections(text or "")
    explicit = {code: cx for code, cx, _ in parse_explicit_components(sections, catalog)}
    out = []
    for cat in catalog:
        hits = {t: _term_hits(low, t) for t in component_terms(cat)}
        found = [t for t, n in hits.items() if n]
        total = sum(hits.values())
        if cat["code"] in explicit or total >= 1:
            cx = explicit.get(cat["code"]) or ("High" if total >= 6 else "Medium" if total >= 3 else "Low")
            reason = (f"Listed as an impacted component ({cx}) in the SA document" if cat["code"] in explicit
                      else f"{evidence_snippet(text or '', found[0])} → {cat['name']}")
            rank = 10000 - catalog.index(cat) if cat["code"] in explicit else total
            out.append({"component_code": cat["code"], "complexity": cx, "reason": clip(reason, 300), "_score": rank})
    out.sort(key=lambda c: (-c["_score"], c["component_code"]))
    return [{k: v for k, v in c.items() if k != "_score"} for c in out[:12]]


def component_similarity(a: set[str] | list[str], b: set[str] | list[str]) -> float:
    """Jaccard similarity of two DC component sets, 2 dp: the single comparable score used on every card."""
    a, b = set(a or []), set(b or [])
    return round(len(a & b) / len(a | b), 2) if (a | b) else 0.0


def _tokens(text: str) -> set[str]:
    stop = {"the", "and", "for", "with", "from", "into", "this", "that", "will", "are", "our", "new", "to", "of", "in", "on", "a", "an"}
    return {w for w in re.findall(r"[a-z0-9]{3,}", (text or "").lower()) if w not in stop}


def gen_intake_analysis(ctx: dict, variant: int = 0) -> dict:
    s = _intake_subject(ctx)
    catalog = ctx["data"].get("catalog") or (ctx.get("bundle") or {}).get("component_catalog") or []
    desc = s.get("description") or ""
    sa_text = s.get("sa_text") or ""
    corpus = f"{s.get('name') or ''}\n{desc}\n{sa_text}"
    low = corpus.lower()
    comps = likely_components(corpus, catalog)
    present: dict[str, bool] = {}
    for key, _label, _w, rule, *_ in CHECKLIST:
        if rule == "description_words":
            present[key] = len(desc.split()) >= 15
        elif rule == "components":
            present[key] = bool(s.get("components")) or bool(comps)
        elif rule == "release":
            present[key] = bool(s.get("target_release") or s.get("requested_go_live"))
        elif rule == "prn":
            present[key] = bool(s.get("prn_code")) or bool(re.search(r"\bPRN-\d{4,6}\b", corpus))
        elif rule == "dc_sa":
            present[key] = bool(s.get("dc_sa_name"))
        else:
            present[key] = bool(re.search(rule, low))
    score = sum(w for key, _l, w, *_ in CHECKLIST if present[key])
    readiness = "Ready for grooming" if score >= 75 else "Needs info" if score >= 50 else "Not ready"
    field_checks = [
        {"field": "name", "label": "Project Name", "status": "present" if s.get("name") else "missing",
         "note": clip(s.get("name") or "Add a short project name", 300)},
        {"field": "lob", "label": "LOB", "status": "present" if s.get("lob") else "missing", "note": s.get("lob") or "Select the line of business"},
        {"field": "requestor", "label": "Requestor", "status": "present" if s.get("requestor") else "missing",
         "note": clip(s.get("requestor") or "Name the business requestor", 300)},
        {"field": "description", "label": "Description of Change",
         "status": "present" if len(desc.split()) >= 25 else "weak" if desc else "missing",
         "note": "Describes the change in enough detail" if len(desc.split()) >= 25 else
                 ("Short description; add business outcome, volumes and timing" if desc else "Add a description of the change")},
        {"field": "requested_go_live", "label": "Requested Go-live", "status": "present" if s.get("requested_go_live") else "missing",
         "note": fmt_date(s["requested_go_live"]) if s.get("requested_go_live") else "Add the requested go-live date"},
        {"field": "target_release", "label": "Target Release", "status": "present" if s.get("target_release") else "missing",
         "note": s.get("target_release") or "Set once the plan is generated"},
        {"field": "prn_code", "label": "PRN", "status": "present" if s.get("prn_code") else "missing",
         "note": s.get("prn_code") or "Funding PRN needed by Planning"},
        {"field": "dc_sa_id", "label": "DC SA", "status": "present" if s.get("dc_sa_name") else "missing",
         "note": clip(s.get("dc_sa_name") or "Assign a DC SA before Solution", 300)},
        {"field": "sa_document", "label": "SA document", "status": "present" if sa_text else "missing",
         "note": "SA document attached" if sa_text else "Attach the SA document to generate the Change Summary"},
    ]
    ambiguities = []
    seen_phrases: set[str] = set()
    for field, text in (("description", desc), ("sa_document", sa_text)):
        for sent in sentences(text or ""):
            low_sent = sent.lower()
            if re.search(r"\b(tbd|tbc)\b|to be confirmed", low_sent) and field == "sa_document":
                continue
            for phrase in VAGUE_PHRASES:
                if phrase in seen_phrases or len(ambiguities) >= 8:
                    continue
                if re.search(r"(?<![a-z])" + re.escape(phrase) + r"(?![a-z])", low_sent):
                    seen_phrases.add(phrase)
                    ambiguities.append({"text": clip(sent, 200),
                                        "why": clip(f"'{phrase}' does not state a measurable requirement or a fixed scope", 300),
                                        "source_field": field})
    missing_info = [{"item": label, "impact": impact} for key, label, _w, _r, impact, *_ in CHECKLIST if not present[key]]
    questions = [{"question": q, "addressed_to": role, "priority": {"High": 1, "Medium": 2, "Low": 3}[impact]}
                 for key, _l, _w, _r, impact, q, role in CHECKLIST if not present[key]]
    if s.get("prn_code") and s.get("prn_funded"):
        l2 = f" against the L2 of {fmt_hours(s['l2_hours'])}" if s.get("l2_hours") else " once the L2 is estimated"
        questions.append({"question": clip(f"Confirm {s['prn_code']} funded hours ({fmt_hours(s['prn_funded'])}) cover the work{l2}.", 300),
                          "addressed_to": "DC PM", "priority": 3})
    questions.sort(key=lambda q: q["priority"])
    labels = suggest_labels(s.get("name") or "", desc, sa_text, s.get("lob"))
    my_tokens = _tokens(f"{s.get('name')} {desc}")
    my_comps = set(s.get("components") or [c["component_code"] for c in comps[:4]])
    dups = []
    closest = None
    for o in ctx["data"].get("others") or []:
        ot = _tokens(f"{o['name']} {o.get('description') or ''}")
        jt = len(my_tokens & ot) / len(my_tokens | ot) if (my_tokens | ot) else 0.0
        oc = set(o.get("components") or [])
        name_ratio = difflib.SequenceMatcher(None, (s.get("name") or "").lower(), o["name"].lower()).ratio()
        sim = component_similarity(my_comps, oc)  # decision 8: one score per pair, same as the L2 comparables
        if closest is None or sim > closest[0] or (sim == closest[0] and o["rddc"] < closest[1]["rddc"]):
            closest = (sim, o)
        if sim >= 0.5 and (jt >= 0.25 or name_ratio >= 0.6):
            shared = sorted(my_comps & oc)
            dups.append({"rddc": o["rddc"], "name": clip(o["name"], 200), "similarity": min(sim, 1.0),
                         "reason": clip(f"Similar wording{'; shares ' + ', '.join(COMPONENT_NAMES[c] for c in shared) if shared else ''}", 300)})
    dups.sort(key=lambda d: (-d["similarity"], d["rddc"]))
    name = s.get("name") or "This intake"
    summary = f"{name} scores {score}% for grooming readiness ({readiness.lower()})."
    if missing_info:
        summary += f" Missing: {', '.join(m['item'].lower() for m in missing_info[:3])}."
    if comps:
        summary += f" Likely components: {', '.join(COMPONENT_NAMES[c['component_code']] for c in comps[:4])}."
    if dups:
        summary += f" Possible duplicate: {dups[0]['rddc']}."
    elif closest:
        summary += f" No duplicate found (closest {closest[1]['rddc']}, {rint(closest[0] * 100)}%)."
    sources = []
    if s.get("rddc"):
        sources.append(src("initiative", s["rddc"], f"{s['rddc']} Description of Change", desc[:200] or None))
    else:
        sources.append(src("initiative", "draft", "New intake (not saved yet)", desc[:200] or None))
    if sa_text:
        sources.append(src("sa_doc", ctx["data"].get("sa_label") or "SA document", "SA document text"))
    if closest:
        sources.append(src("initiative", closest[1]["rddc"], f"{closest[1]['rddc']} {closest[1]['name']} (closest match)"))
    warnings = [] if sa_text else ["No SA document yet; analysis uses the intake fields only."]
    pri = s.get("priority")
    try:
        pri = int(pri) if pri not in (None, "") else None
    except (TypeError, ValueError):
        pri = None
    if pri is None:
        pri = 2 if re.search(r"regulat|compliance|deadline|mandatory", low) else 3
    return {
        "summary": clip(summary, 600), "completeness_score": int(score), "readiness": readiness,
        "field_checks": field_checks[:20], "ambiguities": ambiguities[:12], "missing_info": missing_info[:12],
        "clarifying_questions": questions[:6], "suggested_labels": [clip(x, 40) for x in labels[:10]],
        "likely_components": comps[:12], "suggested_priority": pri, "possible_duplicates": dups[:5],
        "confidence": round(min(0.5 + 0.4 * (1 if sa_text else 0) + 0.05 * (score >= 75), 0.95), 2),
        "sources": sources, "warnings": warnings,
    }


# ================================================================== F2 change_summary
def gen_change_summary(ctx: dict, variant: int = 0) -> dict:
    b = ctx["bundle"]
    ini = b["initiative"]
    catalog = b.get("component_catalog") or []
    cat = catalog_by_code(catalog)
    text = b.get("sa_doc_text") or ""
    warnings = []
    sa_label = ctx["data"].get("sa_label") or next((a["filename"] for a in b.get("attachments", [])
                                                    if a.get("id") == ini.get("sa_doc_attachment_id")), "SA document")
    if not text:
        text = ini.get("description") or ""
        warnings.append("No SA document attached; components are inferred from the description only.")
    sections = split_sections(text)
    people = [p["name"] for p in b.get("resources", [])]
    approvals = parse_approvals(sections, catalog, people)
    explicit = parse_explicit_components(sections, catalog)
    list_heads = ("approval", "impacted component", "open item", "open question", "sign-off")
    body_sentences = [(s["heading"], clause.strip()) for s in sections if s["heading"] != "Document"
                      and not any(k in s["heading"].lower() for k in list_heads) for sent in sentences(s["body"]) for clause in sent.split(";") if len(clause.strip()) > 12]
    chosen: list[tuple[str, str, str | None]] = []
    if explicit:
        chosen = [(code, cx, f"Listed under impacted components: {ex}") for code, cx, ex in explicit]
    else:
        low_full = text.lower()
        for c in catalog:
            hits = sum(_term_hits(low_full, t) for t in component_terms(c))
            if hits >= 2:
                cx = "High" if hits >= 6 else "Medium" if hits >= 3 else "Low"
                chosen.append((c["code"], cx, None))
        chosen.sort(key=lambda x: list(cat).index(x[0]))
    rows = []
    for code, cx, explicit_excerpt in chosen[:12]:
        c = cat[code]
        terms = component_terms(c)
        others = [component_terms(cat[o]) for o, _, _ in chosen if o != code]
        scored = []
        for idx, (heading, sent) in enumerate(body_sentences):
            low_sent = sent.lower()
            own = sum(_term_hits(low_sent, t) for t in terms)
            rival = max((sum(_term_hits(low_sent, t) for t in ot) for ot in others), default=0)
            if own and mentioned_component(heading, catalog) == code:
                own += 2
            sc = own - 0.5 * rival
            if own and sc > 0:
                scored.append((sc, idx, heading, sent))
        top = sorted(scored, key=lambda x: (-x[0], x[1]))[:2]
        top.sort(key=lambda x: x[1])
        if top:
            summary = words(" ".join(t[3][0].upper() + t[3][1:].rstrip(".") + "." for t in top), 45)
        else:
            mentions = [h for _, h in body_sentences if any(_term_hits(h.lower(), t) for t in terms)]
            summary = (f"{c['name']} changes: {words(mentions[0], 35)}" if mentions
                       else f"{c['name']} changes as described in the SA document.")
        evidence = [{"section": clip(t[2], 120), "excerpt": clip(t[3], 400)} for t in top]
        if explicit_excerpt:
            evidence.insert(0, {"section": "Impacted components", "excerpt": clip(explicit_excerpt, 400)})
        appr = approvals.get(code)
        if appr:
            evidence.append({"section": "Approvals", "excerpt": clip(appr["excerpt"], 400)})
        joined = " ".join(t[3] for t in top).lower()
        change_type = "New" if re.search(r"\bnew\b|introduc|expose|create|add\b", joined) else \
            "Config" if re.search(r"config|dashboard|alert|policy", joined) else "Modify"
        rows.append({"component_code": code, "component_name": c["name"],
                     "approval": appr["approval"] if appr else "Pending", "approver": appr["approver"] if appr else None,
                     "complexity": cx, "change_type": change_type, "change_summary": clip(summary, 600),
                     "est_hours": float(c.get(f"base_hours_{cx.lower()}") or 0), "evidence": evidence[:6]})
    score = C.sa_score(b.get("sa_doc_text") or "")
    flags = sa_sections_flags(score)
    items = open_items(text, sections)
    gaps = [f"No {f['section'].lower()}{' plan' if f['section'] == 'Backout' else ''} section in the SA document"
            for f in flags if not f["found"]]
    if items:
        gaps.append(f"{len(items)} open item{'s' if len(items) != 1 else ''} still to be confirmed")
    for r in rows:
        if r["approval"] == "Pending":
            gaps.append(f"{r['component_name']} approval is pending")
    if not rows:
        warnings.append("No DC components could be identified; add them manually or attach a fuller SA document.")
    matched = sum(1 for r in rows if r["component_code"] in approvals)
    confidence = min(0.85, 0.45 + 0.05 * matched + (0.15 if explicit else 0) + (0.1 if b.get("sa_doc_text") else 0))
    sources = [src("sa_doc", sa_label, f"{sa_label}{' v' + str(ini['sa_version']) if ini.get('sa_version') else ''}")]
    if approvals:
        sources.append(src("sa_doc", sa_label, "SA document · Approvals", "; ".join(a["excerpt"] for a in approvals.values())))
    sources.append(src("engine", "sa_completeness", f"SA Completeness {score.get('completeness', 0)}% (9-section checklist)"))
    return {"components": rows, "sa_completeness": int(score.get("completeness") or 0), "sa_sections": flags,
            "gaps": [clip(g, 300) for g in gaps[:15]], "open_items": items[:15], "out_of_scope": out_of_scope(text),
            "confidence": round(confidence, 2), "sources": sources[:40], "warnings": warnings}


# ================================================================== F3 l2_estimate
def l2_numbers(bundle: dict) -> dict:
    return C.l2_estimate(bundle.get("components", []), bundle.get("component_catalog", []))


def gen_l2_estimate(ctx: dict, variant: int = 0) -> dict:
    b = ctx["bundle"]
    ini = b["initiative"]
    est = l2_numbers(b)
    comps = {c["code"]: c for c in b.get("components", [])}
    by_component = []
    for bc in est.get("by_component", []):
        code = bc.get("code") or bc.get("component_code")
        comp = comps.get(code, {})
        why = comp.get("change_summary") or f"{COMPONENT_NAMES.get(code, code)} changes"
        by_component.append({"component_code": code, "complexity": bc.get("complexity") or comp.get("complexity") or "Medium",
                             "dev_hours": float(bc.get("hours", 0)),
                             "rationale": clip(f"{words(why, 18).rstrip('.')}; {(bc.get('complexity') or 'Medium')} "
                                               f"catalogue rate {fmt_hours(bc.get('hours', 0))}.", 400)})
    total = float(est["total_hours"])
    subtotal = float(est.get("subtotal") or 0)
    by_phase = [{"phase": "Development", "hours": float(est.get("dev_hours", 0))},
                {"phase": "Architecture", "hours": float(est.get("architecture_hours", 0))},
                {"phase": "QA", "hours": float(est.get("qa_hours", 0))},
                {"phase": "PM / Release", "hours": float(est.get("pm_release_hours", 0))},
                {"phase": "Contingency", "hours": float(est.get("contingency_hours") or round(subtotal * 0.15))}]
    rounding = round(total - subtotal - by_phase[-1]["hours"], 1)
    history = ctx["data"].get("history") or []
    mine = set(comps)
    comparables = []
    for h in history:
        hs = set(h.get("components") or [])
        if not (mine | hs):
            continue
        sim = component_similarity(mine, hs)
        if sim > 0 and h["rddc"] != ini["rddc"]:
            note = f"Delivered at {fmt_hours(h['actual_hours'])} actual" + (
                f" against an approved L2 of {fmt_hours(h['l2_hours'])}" if h.get("l2_hours") else "")
            note += f"; shares {', '.join(COMPONENT_NAMES[c] for c in sorted(mine & hs))}"
            comparables.append({"rddc": h["rddc"], "name": clip(h["name"], 200), "actual_hours": float(h["actual_hours"] or 0),
                                "similarity": round(sim, 2), "note": clip(note, 300)})
    comparables.sort(key=lambda c: (-c["similarity"], c["rddc"]))
    comparables = comparables[:3]
    highs = [c for c in by_component if c["complexity"] == "High"]
    drivers = []
    if highs:
        drivers.append({"factor": f"{len(highs)} High-complexity component{'s' if len(highs) > 1 else ''}",
                        "effect": f"{fmt_hours(sum(c['dev_hours'] for c in highs))} of development at catalogue High rates"})
    downstream = sorted({d for c in highs for d in (catalog_by_code(b.get('component_catalog', [])).get(c['component_code'], {}).get('downstream') or [])
                         if d not in comps})
    if downstream:
        drivers.append({"factor": "Downstream consumers need regression",
                        "effect": clip(f"{', '.join(COMPONENT_NAMES[d] for d in downstream)} covered within the QA 35%", 200)})
    sa = ini.get("sa_completeness")
    if sa is not None:
        drivers.append({"factor": f"SA Completeness {sa}%", "effect": "Contingency held at 15%" if sa >= 80 else
                        "Open SA sections add estimate risk; contingency stays at the standard 15%"})
    assumptions = ["Hours use the DC component catalogue rates for the agreed complexity",
                   "Architecture 10%, QA 35% and PM / Release 10% of development, plus 15% contingency"]
    if b.get("sa_doc_text") and re.search(r"\bTBD\b", b["sa_doc_text"]):
        assumptions.append("Open SA items marked TBD are assumed not to add components")
    if comparables:
        assumptions.append(f"Comparable delivery: {comparables[0]['rddc']} ({fmt_hours(comparables[0]['actual_hours'])} actual)")
    dev = float(est.get("dev_hours", 0))
    narrative = pick(variant,
                     f"{fmt_hours(dev)} of development across {len(by_component)} component{'s' if len(by_component) != 1 else ''}, "
                     f"plus architecture, QA and release effort ({fmt_hours(subtotal)}) and 15% contingency "
                     f"({fmt_hours(by_phase[-1]['hours'])}), rounds to {fmt_hours(total)} "
                     f"{'(' + ('+' if rounding >= 0 else '−') + fmt_hours(abs(rounding)) + ' rounding) ' if rounding else ''}"
                     f"(T-shirt {est['tshirt']}, range {fmt_hours(est['low_hours'])}–{fmt_hours(est['high_hours'])}).",
                     f"The estimate is {fmt_hours(total)} ({est['tshirt']}). It starts from {fmt_hours(dev)} of catalogue "
                     f"development hours, adds architecture 10%, QA 35% and PM / Release 10% ({fmt_hours(subtotal)}), then 15% "
                     f"contingency ({fmt_hours(by_phase[-1]['hours'])}), rounded to the nearest 50 h"
                     f"{' (' + ('+' if rounding >= 0 else '−') + fmt_hours(abs(rounding)) + ')' if rounding else ''}. Range {fmt_hours(est['low_hours'])}–{fmt_hours(est['high_hours'])}.")
    if not by_component:
        narrative = "No DC components are listed yet. Generate the Change Summary first; the estimate is 0 h until then."
    confidence = 0.6 + 0.1 * bool(by_component) + 0.1 * bool(sa is not None and sa >= 80) + 0.1 * bool(comparables)
    sources = [src("engine", "l2", "L2 calculation", est.get("rule"))]
    sources += [src("component", c["component_code"], f"Change Summary · {COMPONENT_NAMES[c['component_code']]}") for c in by_component]
    sources += [src("initiative", c["rddc"], f"{c['rddc']} {c['name']} (comparable)") for c in comparables]
    out = {"total_hours": total, "low_hours": float(est["low_hours"]), "high_hours": float(est["high_hours"]),
           "tshirt": est["tshirt"], "dev_hours": dev, "contingency_pct": 15, "by_component": by_component[:12],
           "by_phase": by_phase, "drivers": drivers[:10], "comparables": comparables,
           "assumptions": [clip(a, 300) for a in assumptions[:12]], "narrative": clip(narrative, 1500),
           "confidence": round(min(confidence, 0.9), 2), "sources": sources[:40],
           "warnings": [] if by_component else ["No Change Summary rows yet."]}
    return out


# ================================================================== F4 wbs
def _task(code, parent, step, phase, description, comp, owner_role, est, pct, depends, milestone=False):
    return {"wbs_code": code, "parent_code": parent, "step": clip(step, 160), "phase": phase,
            "description": clip(description, 600), "component_code": comp, "owner_role": owner_role,
            "suggested_resource_id": None, "suggested_resource_name": None, "est_hours": float(est),
            "allocation_pct": int(pct), "duration_days": duration_for(est, pct, milestone) if not milestone else 0,
            "depends_on": list(depends), "is_milestone": bool(milestone)}


def wbs_skeleton(ctx: dict) -> tuple[list[dict], list[dict], dict]:
    """Hero-shaped WBS for any component set. Returns (tasks, dependency_impacts, meta)."""
    b = ctx["bundle"]
    ini = b["initiative"]
    catalog = b.get("component_catalog") or []
    cat = catalog_by_code(catalog)
    comps = sorted(b.get("components", []), key=lambda c: (c.get("sort") or 0, c.get("id") or 0))[:9]
    dev_hours = {c["code"]: C.component_dev_hours(c, cat) for c in comps}
    dev_total = sum(dev_hours.values())
    if not comps:
        dev_total = float(ini.get("l2_hours") or 0) / 1.785 if ini.get("l2_hours") else 120.0
    est_hours = max(14, rint(dev_total * 0.125))
    tasks = [_task("WBS-100", None, "Estimation & solution finalization", "Estimation",
                   "Close the open SA items, add any missing SA sections, confirm component approvals and finalize the L2 estimate.",
                   None, "DC SA", est_hours, 50, [])]
    window = max(10, math.ceil(max(dev_hours.values(), default=dev_total) / 7))
    dev_codes = []
    if comps:
        tasks.append({**_task("WBS-200", None, "Development", "Development", "Component build work across the impacted DC components.",
                              None, "Tech Lead", 0, 0, ["WBS-100"]), "duration_days": window})
        top = max(dev_hours.values())
        for i, comp in enumerate(comps, start=1):
            code = f"WBS-2{i}0"
            h = dev_hours[comp["code"]]
            target = math.ceil(window / 2) if (comp.get("complexity") == "Low" and h < top) else window
            pct = 100 if h >= top else min(100, max(10, math.ceil(h * 100 / (7 * target) - 1e-9)))
            name = cat.get(comp["code"], {}).get("name", comp["code"])
            tasks.append(_task(code, "WBS-200", f"{name} – {STEP_TEMPLATES.get(comp['code'], 'component changes')}", "Development",
                               comp.get("change_summary") or f"{name} changes from the Change Summary.", comp["code"],
                               f"{name} lead", h, pct, ["WBS-100"]))
            dev_codes.append(code)
    else:
        tasks.append(_task("WBS-200", None, "Development", "Development",
                           "Build work; add DC components through the Change Summary to split it by component.",
                           None, "Tech Lead", rint(dev_total), 100, ["WBS-100"]))
        dev_codes.append("WBS-200")
    sit_deps = list(dev_codes)
    tasks.append(_task("WBS-300", None, "Integration / SIT", "Integration",
                       "System integration testing across the changed components in the SIT environment.",
                       None, "Tech Lead", max(14, rint(dev_total * 0.10)), 80, sit_deps))
    # downstream regression for High components (grouped Mobile / Web / others)
    in_init = {c["code"] for c in comps}
    groups: dict[str, dict] = {}
    for comp in comps:
        if comp.get("complexity") != "High":
            continue
        for d in cat.get(comp["code"], {}).get("downstream") or []:
            if d in in_init:
                continue
            key = "MOBILE" if d in ("MOB_IOS", "MOB_AND") else d
            g = groups.setdefault(key, {"codes": [], "after": []})
            if d not in g["codes"]:
                g["codes"].append(d)
            idx = [c["code"] for c in comps].index(comp["code"])
            dep = dev_codes[idx] if idx < len(dev_codes) else dev_codes[0]
            if dep not in g["after"]:
                g["after"].append(dep)
    order = sorted(groups, key=lambda k: (0 if k == "MOBILE" else 1 if k == "OLB" else 2,
                                         list(cat).index(k) if k in cat else 0))
    impacts = []
    regression_codes = []
    for i, key in enumerate(order[:8], start=1):
        g = groups[key]
        code = f"WBS-3{i}0"
        if key == "MOBILE":
            label = "Mobile App (iOS and Android)" if len(g["codes"]) > 1 else COMPONENT_NAMES[g["codes"][0]]
        else:
            label = COMPONENT_NAMES[key]
        tasks.append(_task(code, "WBS-300", f"Regression test: {label}", "Integration",
                           f"Regression test {label} against the changed services before QA.", None, "QA Lead", 24, 70, g["after"]))
        regression_codes.append(code)
        for d in g["codes"]:
            for dep in g["after"]:
                src_comp = next((t["component_code"] for t in tasks if t["wbs_code"] == dep), None)
                impacts.append({"component_code": d, "direction": "downstream",
                                "impact": clip(f"{COMPONENT_NAMES[d]} consumes {COMPONENT_NAMES.get(src_comp, 'the changed')} services", 300),
                                "action": clip(f"Regression test {COMPONENT_NAMES[d]} ({code})", 300), "wbs_code": code})
    for comp in comps:
        if comp.get("complexity") == "High":
            continue
        for d in cat.get(comp["code"], {}).get("downstream") or []:
            if d not in in_init and len(impacts) < 20:
                impacts.append({"component_code": d, "direction": "downstream",
                                "impact": clip(f"{COMPONENT_NAMES[d]} reads from {COMPONENT_NAMES[comp['code']]}; "
                                               f"{comp.get('complexity', 'Medium')} change, no regression step added", 300),
                                "action": "Confirm no interface change with the component lead", "wbs_code": None})
    tasks.append(_task("WBS-400", None, "QA – functional, performance and security testing", "QA",
                       "Functional, performance and security testing; QA sign-off sets the QA Date.", None, "QA Lead",
                       max(14, rint(dev_total * 0.10)), 100, ["WBS-300"] + regression_codes))
    tasks.append(_task("WBS-500", None, "UAT / business validation", "UAT",
                       "Business validation by the requestor in the UAT environment.", None, "Requestor",
                       max(7, rint(dev_total * 0.025)), 100, ["WBS-400"]))
    tasks.append(_task("WBS-600", None, "Release readiness & CRQ", "Readiness",
                       "Raise the CRQ, attach validation evidence and backout plan, and obtain STO approval. Ends on the Readiness Date.",
                       None, "Rel Lead", 14, 100, ["WBS-500"]))
    tasks.append(_task("WBS-700", None, "Production implementation", "Production",
                       "Deploy under the approved CRQ on the release train date.", None, "Rel Lead", 6, 100, ["WBS-600"], True))
    hc = max(7, rint(dev_total * 0.0625))
    hc_pct = min(100, max(10, math.ceil(hc * 100 / 70 - 1e-9)))
    tasks.append(_task("WBS-800", None, "Hypercare", "Hypercare",
                       "Monitor SLOs and alerts, triage production issues and hand over to run teams (10 business days).",
                       None, "SRE", hc, hc_pct, ["WBS-700"]))
    return tasks, impacts, {"dev_total": dev_total, "window": window}


def wbs_requirements(task: dict, bundle: dict) -> tuple[list[str], str | None]:
    """(required skills, team) for a WBS row."""
    cat = catalog_by_code(bundle.get("component_catalog", []))
    comps = [c["code"] for c in bundle.get("components", [])]
    code, phase, step = task.get("component_code"), task.get("phase"), (task.get("step") or "").lower()
    if code:
        return COMPONENT_SKILLS.get(code, []), cat.get(code, {}).get("team")
    if phase in ("Estimation", "Architecture"):
        req = []
        for c in comps:
            s = SA_SKILL_BY_COMPONENT.get(c)
            if s and s not in req:
                req.append(s)
        return req or ["API"], "DC SA"
    if phase == "Integration" and task.get("parent_code"):
        if "mobile" in step or "ios" in step or "android" in step:
            return PHASE_SKILLS["mobile_regression"], "QA"
        if "online banking" in step or "web" in step:
            return PHASE_SKILLS["web_regression"], "Web"
        for c, cc in cat.items():
            if cc["name"].lower() in step:
                return COMPONENT_SKILLS.get(c, []), cc.get("team")
        return PHASE_SKILLS["QA"], "QA"
    if phase == "Integration":
        return PHASE_SKILLS["Integration"], "EAPI"
    if phase == "QA":
        return PHASE_SKILLS["QA"], "QA"
    if phase == "Hypercare":
        return PHASE_SKILLS["Hypercare"], "SRE"
    if phase == "Development":
        return [], None
    return [], None


def gen_wbs(ctx: dict, variant: int = 0) -> dict:
    b = ctx["bundle"]
    ini = b["initiative"]
    tasks, impacts, meta = wbs_skeleton(ctx)
    trains = ctx["data"].get("trains") or C.release_trains()
    target = ini.get("target_release") or (b.get("target_train") or {}).get("code")
    start = plan_start_for(ctx)
    sched = schedule_plan(tasks, start, trains, target)
    dates = sched["dates"]
    train = sched["train"]
    for t in tasks:
        if t["wbs_code"] == "WBS-700":
            t["step"] = f"Production implementation ({train})" if train else "Production implementation"
    people = people_index(ctx)
    exclude = own_alloc(b)
    roles = {"DC SA": ini.get("dc_sa_id"), "Tech Lead": ini.get("tech_lead_id"), "Requestor": ini.get("requestor_id")}
    rel = first_with_role(ctx, "Rel Lead")
    for t in tasks:
        s, e = dates[t["wbs_code"]]
        t["offset_days"] = max(0, min(400, C.business_days_from(start, s))) if s >= start else 0
        rid = None
        if t["phase"] == "Estimation" and roles["DC SA"]:
            rid = roles["DC SA"]
        elif t["phase"] == "Integration" and not t["parent_code"] and roles["Tech Lead"]:
            rid = roles["Tech Lead"]
        elif t["phase"] == "UAT":
            rid = roles["Requestor"]
        elif t["phase"] in ("Readiness", "Production"):
            rid = rel["id"] if rel else None
        elif t["est_hours"] > 0:
            req, team = wbs_requirements(t, b)
            cands = score_candidates(ctx, required=req, team=team, start=s, end=e, hours=t["est_hours"], exclude=exclude,
                                     component_code=t["component_code"], phase=t["phase"],
                                     continuity_ids={x for x in roles.values() if x}, limit=1)
            rid = cands[0]["resource_id"] if cands else None
        if rid and rid in people:
            t["suggested_resource_id"] = rid
            t["suggested_resource_name"] = clip(people[rid]["name"], 120)
        elif rid:
            t["suggested_resource_id"] = rid
            t["suggested_resource_name"] = None
    kd = key_dates(tasks, dates)
    float_bd = None
    if kd["readiness_date"] and kd["prod_date"]:
        float_bd = C.readiness_float_bd(kd["readiness_date"], kd["prod_date"])
    total = round(sum(t["est_hours"] for t in tasks), 1)
    summary = (f"{len(tasks)}-row plan from solution finalization to hypercare"
               f"{', targeting ' + train + ' (' + fmt_date(kd['prod_date']) + ')' if train and kd['prod_date'] else ''}. "
               f"Readiness {fmt_date(kd['readiness_date'])}, QA Date {fmt_date(kd['qa_date'])}"
               f"{', ' + str(float_bd) + ' business days of float' if float_bd is not None else ''}. "
               f"Developer hours {fmt_hours(meta['dev_total'])}; plan total {fmt_hours(total)}.")
    assumptions = [f"Plan starts {fmt_date(start)}, the next business day",
                   "Dates skip stat holidays; production avoids the 14 Dec–8 Jan change freeze",
                   "Duration = hours ÷ (7 h × allocation %); dependencies are finish-to-start",
                   "Estimation 12.5% of development hours; SIT and QA 10% each; hypercare 10 business days"]
    if impacts:
        assumptions.append("Regression steps added for downstream consumers of High-complexity components")
    comps = b.get("components", [])
    sa = ini.get("sa_completeness")
    confidence = 0.7 + 0.1 * bool(comps) + 0.05 * bool(sa is not None and sa >= 80) + 0.05 * bool(train)
    warnings = list(sched["warnings"])
    if not comps:
        warnings.append("No Change Summary rows; development is a single step. Generate the Change Summary first.")
    if not target and train:
        warnings.append(f"No target release was set; the plan targets {train}.")
    sources = [src("component", c["code"], f"Change Summary · {c.get('name') or COMPONENT_NAMES.get(c['code'], c['code'])}",
                   c.get("change_summary")) for c in comps]
    sources.append(src("rule", "wbs-template", "DC WBS template (100 Estimation … 800 Hypercare)"))
    if train:
        sources.append(src("release_train", train, f"Release train {train} · {fmt_date(kd['prod_date'])}"))
    return {"summary": clip(summary, 600), "tasks": tasks[:60], "total_est_hours": total,
            "dependency_impacts": impacts[:20], "assumptions": [clip(a, 300) for a in assumptions[:12]],
            "confidence": round(min(confidence, 0.92), 2), "sources": sources[:40], "warnings": warnings[:20]}


# ================================================================== F5 resources
def gen_resources(ctx: dict, variant: int = 0) -> dict:
    b = ctx["bundle"]
    ini = b["initiative"]
    wanted = ctx["inputs"].get("wbs_code")
    tasks = [t for t in b.get("tasks", []) if float(t.get("est_hours") or 0) > 0 and not t.get("is_milestone")]
    if wanted:
        tasks = [t for t in tasks if t["wbs_code"] == wanted] or tasks
    recs = []
    warnings = []
    continuity = {x for x in (ini.get("dc_sa_id"), ini.get("tech_lead_id")) if x}
    for t in tasks:
        req, team = wbs_requirements(t, b)
        if not req and not team:
            continue
        start = t.get("planned_start") or plan_start_for(ctx)
        end = t.get("planned_end") or C.add_business_days(start, 20).isoformat()
        exclude = task_alloc(b, t.get("id"))
        cands = score_candidates(ctx, required=req, team=team, start=start, end=end, hours=float(t["est_hours"]),
                                 exclude=exclude, component_code=t.get("component_code"), phase=t.get("phase"),
                                 continuity_ids=continuity | ({t["resource_id"]} if t.get("resource_id") else set()))
        if not cands:
            continue
        rec_id = cands[0]["resource_id"]
        if t["phase"] == "Estimation" and ini.get("dc_sa_id") in {c["resource_id"] for c in cands}:
            rec_id = ini["dc_sa_id"]
        role = {"Estimation": "DC Solution Architect", "QA": "QA Lead", "Hypercare": "Site Reliability Engineer"}.get(
            t["phase"], f"{COMPONENT_NAMES[t['component_code']]} developer" if t.get("component_code") else
            ("QA / regression tester" if t.get("parent_id") else "Integration lead"))
        recs.append({"wbs_code": t["wbs_code"], "role_needed": clip(role, 120), "required_skills": req[:15],
                     "hours_needed": float(t["est_hours"]), "window": {"start": start, "end": end},
                     "candidates": cands, "recommended_resource_id": rec_id})
    if not recs:
        start = plan_start_for(ctx)
        end = C.add_business_days(start, 40).isoformat()
        for comp in b.get("components", [])[:12] or [{"code": None}]:
            code = comp.get("code")
            req = COMPONENT_SKILLS.get(code, ["API"]) if code else ["API", "Data"]
            team = catalog_by_code(b.get("component_catalog", [])).get(code, {}).get("team") if code else "DC SA"
            hours = float(C.component_dev_hours(comp, catalog_by_code(b.get("component_catalog", [])))) if code else 70.0
            cands = score_candidates(ctx, required=req, team=team, start=start, end=end, hours=hours or 40.0, exclude={},
                                     component_code=code, phase="Development", continuity_ids=continuity)
            recs.append({"wbs_code": None, "role_needed": f"{COMPONENT_NAMES[code]} developer" if code else "DC Solution Architect",
                         "required_skills": req, "hours_needed": hours or 40.0, "window": {"start": start, "end": end},
                         "candidates": cands, "recommended_resource_id": cands[0]["resource_id"] if cands else None})
        warnings.append("No project plan yet; recommendations are per component over the next 40 business days.")
    over = [r for r in recs if r["candidates"] and r["candidates"][0]["peak_util_after_pct"] > 100]
    for r in over[:5]:
        c = next(c for c in r["candidates"] if c["resource_id"] == r["recommended_resource_id"]) if r["recommended_resource_id"] else r["candidates"][0]
        if c["peak_util_after_pct"] > 100:
            warnings.append(clip(f"{c['resource_name']} would be at {rint(c['peak_util_after_pct'])}% on {r['wbs_code'] or r['role_needed']}", 300))
    sources = []
    seen = set()
    for r in recs:
        for c in r["candidates"][:1]:
            if c["resource_id"] not in seen:
                seen.add(c["resource_id"])
                sources.append(src("resource", c["resource_id"], f"{c['resource_name']} · skills and availability"))
    sources.append(src("rule", "fit-score", "Fit = 50% skill match + 30% free hours + 15% prior work + 5% continuity"))
    avg_cov = sum(r["candidates"][0]["skill_match_pct"] for r in recs if r["candidates"]) / max(len(recs), 1)
    return {"recommendations": recs[:40], "confidence": round(min(0.55 + avg_cov / 400 + 0.1 * bool(b.get("tasks")), 0.9), 2),
            "sources": sources[:40], "warnings": list(dict.fromkeys(warnings))[:20]}


# ================================================================== F6 rebalance
def person_month_util(b: dict, rid: int, month: str, delta: float = 0.0) -> float:
    res = next((r for r in b.get("resources", []) if r["id"] == rid), None)
    if not res:
        return 0.0
    avail = available(res, month)
    return ((float((res.get("committed") or {}).get(month, 0.0)) + delta) / avail * 100) if avail else 0.0


def find_overallocation(b: dict, rid: int | None = None) -> tuple[int, str, float] | None:
    """(resource_id, month, util%) of the worst person-month among people holding allocation on this initiative."""
    held: dict[int, set[str]] = {}
    for a in b.get("allocations", []):
        held.setdefault(a["resource_id"], set()).add(a["month"])
    eligible = {r["id"] for r in b.get("resources", []) if r.get("capacity_eligible")}
    best = None
    for person, months in held.items():
        if person not in eligible or (rid and person != rid):
            continue
        for m in sorted(months):
            u = person_month_util(b, person, m)
            if best is None or u > best[2] + 1e-9:
                best = (person, m, u)
    return best


def simulate_move(b: dict, task: dict, to_id: int) -> dict:
    """Bundle copy with ``task`` reassigned to ``to_id`` (allocations and committed hours moved)."""
    moved = {}
    allocs = []
    for a in b.get("allocations", []):
        if a.get("task_id") == task["id"]:
            moved[a["month"]] = moved.get(a["month"], 0.0) + float(a["hours"])
            allocs.append({**a, "resource_id": to_id})
        else:
            allocs.append(a)
    if not moved and task.get("planned_start") and task.get("planned_end"):
        moved = C.spread_hours(task["planned_start"], task["planned_end"], float(task.get("est_hours") or 0))
    from_id = task.get("resource_id")
    resources = []
    for r in b.get("resources", []):
        com = dict(r.get("committed") or {})
        if r["id"] == from_id:
            for m, h in moved.items():
                com[m] = round(com.get(m, 0.0) - h, 1)
        if r["id"] == to_id:
            for m, h in moved.items():
                com[m] = round(com.get(m, 0.0) + h, 1)
        resources.append({**r, "committed": com})
    to_name = next((r["name"] for r in resources if r["id"] == to_id), None)
    tasks = [{**t, "resource_id": to_id, "resource_name": to_name} if t["id"] == task["id"] else t for t in b.get("tasks", [])]
    return {**b, "allocations": allocs, "resources": resources, "tasks": tasks, "_moved": moved}


def _local_resources_rag(b: dict) -> str:
    worst = find_overallocation(b)
    if worst is None:
        return "Green"
    return "Red" if worst[2] > 110 else "Amber" if worst[2] > 100 else "Green"


def _overall(dims: dict[str, str]) -> str:
    reds = sum(1 for v in dims.values() if v == "Red")
    if dims.get("schedule") == "Red" or reds >= 2:
        return "Red"
    if any(v in ("Red", "Amber") for v in dims.values()):
        return "Amber"
    return "Green"


def health_after(b: dict) -> dict | None:
    h = C.compute_health(b)
    if h and h.get("dimensions") and C._engine("health") is not None:
        res = h["dimensions"].get("resources", {}).get("rag")
        if res in ("Red", "Amber", "Green") and h.get("overall") in ("Red", "Amber", "Green"):
            return {"resources": res, "overall": h["overall"]}
    cached = (b.get("initiative") or {}).get("health_cached_json")
    if isinstance(cached, dict) and cached.get("dimensions"):
        dims = {k: v.get("rag") for k, v in cached["dimensions"].items() if isinstance(v, dict)}
        dims["resources"] = _local_resources_rag(b)
        if all(v in ("Red", "Amber", "Green") for v in dims.values()):
            return {"resources": dims["resources"], "overall": _overall(dims)}
    return None


def gen_rebalance(ctx: dict, variant: int = 0) -> dict:
    b = ctx["bundle"]
    opts = ctx["inputs"]
    tasks = b.get("tasks", [])
    rid = int(opts["resource_id"]) if opts.get("resource_id") else None
    if opts.get("wbs_code") and not rid:
        t = next((t for t in tasks if t["wbs_code"] == opts["wbs_code"]), None)
        rid = t.get("resource_id") if t else None
    health = (b["initiative"].get("health_cached_json") or {}) if isinstance(b["initiative"].get("health_cached_json"), dict) else {}
    metrics = ((health.get("dimensions") or {}).get("resources") or {}).get("metrics") or {}
    if not rid and metrics.get("peak_resource_id"):
        rid = metrics["peak_resource_id"]
    worst = find_overallocation(b, rid) or find_overallocation(b)
    people = people_index(ctx)
    if worst is None:
        fallback_id = rid or b["initiative"].get("dc_sa_id") or next((r["id"] for r in b.get("resources", [])), 1)
        name = people.get(fallback_id, {}).get("name", "No one")
        month = month_of(ctx["today"])
        return {"problem": {"resource_id": fallback_id, "resource_name": clip(name, 120), "month": month,
                            "util_pct": round(person_month_util(b, fallback_id, month), 1), "wbs_codes": [],
                            "summary": "No one assigned to this initiative is over-allocated; no change is needed."},
                "options": [], "recommended_option_index": None, "confidence": 0.8,
                "sources": [src("engine", "capacity", "Capacity by person and month")], "warnings": []}
    pid, month, util = worst
    person = people.get(pid, {"name": f"Resource {pid}"})
    res = next(r for r in b["resources"] if r["id"] == pid)
    avail = available(res, month)
    my_tasks = []
    for t in tasks:
        if t.get("resource_id") != pid:
            continue
        hrs = sum(float(a["hours"]) for a in b.get("allocations", []) if a.get("task_id") == t["id"] and a["month"] == month)
        if hrs > 0:
            my_tasks.append((hrs, t))
    my_tasks.sort(key=lambda x: (-x[0], x[1]["wbs_code"]))
    committed = float((res.get("committed") or {}).get(month, 0.0))
    problem = {"resource_id": pid, "resource_name": clip(person["name"], 120), "month": month, "util_pct": round(util, 1),
               "wbs_codes": [t["wbs_code"] for _, t in my_tasks][:20],
               "summary": clip(f"{person['name']} is at {rint(util)}% in {fmt_month(month)} ({committed:.1f} h of {avail:.0f} h).", 300)}
    options = []
    for hrs, t in my_tasks:
        req, team = wbs_requirements(t, b)
        team = team or res.get("team")
        alternatives = [r for r in b["resources"] if r.get("capacity_eligible") and r["id"] != pid and r.get("team") == team]
        for alt in sorted(alternatives, key=lambda r: r["id"]):
            sim = simulate_move(b, t, alt["id"])
            moved = sim["_moved"]
            after_to = max((person_month_util(sim, alt["id"], m) for m in moved), default=0.0)
            if after_to > 100:
                continue
            ha = health_after(sim)
            opt = {"action": clip(f"Move {t['wbs_code']} from {person['name']} to {alt['name']}", 300),
                   "task_wbs_code": t["wbs_code"], "from_resource_id": pid, "from_resource_name": clip(person["name"], 120),
                   "to_resource_id": alt["id"], "to_resource_name": clip(alt["name"], 120), "month": month,
                   "before": {"from_pct": round(util), "to_pct": round(person_month_util(b, alt["id"], month))},
                   "after": {"from_pct": round(person_month_util(sim, pid, month)), "to_pct": round(person_month_util(sim, alt["id"], month))},
                   "effect": "", "tradeoffs": []}
            skill_gap = [s for s in req if not skill_level(alt, s)]
            if skill_gap:
                opt["tradeoffs"].append(clip(f"{alt['name']} has no recorded skill in {', '.join(skill_gap)}", 300))
            if t.get("phase") == "Estimation":
                opt["tradeoffs"].append("Hand over SA context and open items before the move")
            if ha:
                opt["health_after"] = ha
                opt["effect"] = clip(f"Resources turns {ha['resources']}; overall health {'stays' if ha['overall'] == (health.get('overall') or ha['overall']) else 'becomes'} {ha['overall']}.", 300)
            else:
                opt["effect"] = clip(f"{person['name']} drops to {opt['after']['from_pct']}% and {alt['name']} rises to {opt['after']['to_pct']}% in {fmt_month(month)}.", 300)
            opt["_score"] = (opt["after"]["from_pct"] > 100, len(skill_gap), opt["after"]["to_pct"], t["wbs_code"], alt["id"])
            options.append(opt)
    options.sort(key=lambda o: o["_score"])
    options = [{k: v for k, v in o.items() if k != "_score"} for o in options[:5]]
    for o in options:
        if not o["tradeoffs"]:
            o.pop("tradeoffs")
    warnings = [] if options else [f"No one in the same team can take {', '.join(problem['wbs_codes']) or 'the work'} without going over 100%."]
    sources = [src("allocation", f"{pid}:{month}", f"{person['name']} · {fmt_month(month)} allocation")]
    sources += [src("resource", o["to_resource_id"], f"{o['to_resource_name']} · availability") for o in options[:3]]
    return {"problem": problem, "options": options, "recommended_option_index": 0 if options else None,
            "confidence": 0.88 if options else 0.7, "sources": sources, "warnings": warnings}


# ================================================================== F7 risks
def _risk(title, desc, cat, sev, lik, signal, wbs, owner_role, owner_id, steps, contingency=""):
    r = {"title": clip(title, 160), "description": clip(desc, 600), "category": cat, "severity": int(sev),
         "likelihood": int(lik), "trigger_signal": clip(signal, 300), "wbs_code": wbs, "owner_role": owner_role,
         "owner_resource_id": owner_id, "mitigation_steps": steps[:5]}
    if contingency:
        r["contingency"] = clip(contingency, 400)
    return r


def _step(text, role, due):
    return {"step": clip(text, 300), "owner_role": role, "due": due}


def gen_risks(ctx: dict, variant: int = 0) -> dict:
    b = ctx["bundle"]
    ini = b["initiative"]
    tasks = b.get("tasks", [])
    by_code = {t["wbs_code"]: t for t in tasks}
    people = people_index(ctx)
    today = ctx["today"]
    pm_id, sa_id, tl_id = ini.get("dc_pm_id"), ini.get("dc_sa_id"), ini.get("tech_lead_id")
    risks = []
    # 1 over-allocation of assigned people
    held: dict[int, set[str]] = {}
    for a in b.get("allocations", []):
        held.setdefault(a["resource_id"], set()).add(a["month"])
    for pid in sorted(held):
        res = next((r for r in b.get("resources", []) if r["id"] == pid and r.get("capacity_eligible")), None)
        if not res:
            continue
        worst = max(((person_month_util(b, pid, m), m) for m in held[pid]), default=(0, None))
        if worst[0] <= 100:
            continue
        task_codes = sorted({t["wbs_code"] for t in tasks if t.get("resource_id") == pid and any(
            a["month"] == worst[1] and a.get("task_id") == t["id"] for a in b.get("allocations", []))})
        wbs = task_codes[0] if task_codes else None
        role = "DC SA" if res.get("team") == "DC SA" else f"{res.get('team') or 'Team'} lead"
        risks.append(_risk(f"{'SA' if res.get('team') == 'DC SA' else res.get('team', '')} capacity constraint affecting {wbs or 'the plan'}".strip(),
                           f"{res['name']} is booked beyond available hours while working on {', '.join(task_codes) or 'this initiative'}.",
                           "Resource", 4 if worst[0] > 110 else 3, 4 if worst[0] > 120 else 3,
                           f"{res['name']} at {rint(worst[0])}% in {fmt_month(worst[1])}", wbs, "DC PM", pm_id,
                           [_step(f"Move {wbs or 'the task'} to a team member with spare capacity (Suggest fix)", "DC PM", bd_after_today(ctx, 2)),
                            _step(f"Confirm {res['name']}'s other commitments for {fmt_month(worst[1])}", role, bd_after_today(ctx, 3))],
                           "Reduce allocation % and accept a later end date if no one can take the work."))
    # 2 schedule float
    fl = C.initiative_float(ini) if ini.get("readiness_date") else None
    if fl is not None and fl < 5:
        risks.append(_risk(f"Readiness float of {fl} business days before {ini.get('target_release') or 'production'}"
                           if fl >= 0 else f"Readiness misses {ini.get('target_release') or 'the release train'} by {-fl} business days",
                           "Any slip in development or QA pushes readiness past the release train date.",
                           "Schedule", 3 if fl > 0 else 4, 3, f"Readiness {fmt_date(ini['readiness_date'])}, train {fmt_date(ini['prod_date'])}",
                           "WBS-600" if "WBS-600" in by_code else None, "DC PM", pm_id,
                           [_step("Track critical-path tasks weekly against the baseline", "DC PM", bd_after_today(ctx, 5)),
                            _step("Agree the fallback release train with the Rel Lead", "DC PM", bd_after_today(ctx, 10))],
                           "Move production to the next release train."))
    # 3 pending approvals
    for c in b.get("components", []):
        if c.get("approval") in ("Pending", "Rejected"):
            t = next((t for t in tasks if t.get("component_code") == c["code"]), None)
            need = fmt_date(t["planned_start"]) if t and t.get("planned_start") else "the start of development"
            risks.append(_risk(f"{c.get('name') or COMPONENT_NAMES[c['code']]} approval {c['approval'].lower()}",
                               f"Development on {COMPONENT_NAMES[c['code']]} cannot be confirmed until the component lead approves the change.",
                               "Dependency", 3, 2 if c["approval"] == "Pending" else 4,
                               f"Approval {c['approval']}; needed by {need}", t["wbs_code"] if t else None, "DC SA", sa_id,
                               [_step(f"Walk {c.get('component_lead_name') or 'the component lead'} through the change summary", "DC SA", bd_after_today(ctx, 3)),
                                _step("Record the approval on Pg 1", "DC PM", bd_after_today(ctx, 5))]))
    # 4 SA open items and missing sections
    text = b.get("sa_doc_text") or ""
    if text:
        sections = split_sections(text)
        for item in open_items(text, sections)[:2]:
            short = re.sub(r"\s*\(owner:[^)]*\)", "", re.sub(r"^(TBD|TBC)[:\s-]*", "", item, flags=re.IGNORECASE))
            risks.append(_risk(f"Open SA item: {clip(short, 120)}",
                               "The SA document leaves this item to be confirmed; it may change scope or design.",
                               "Scope", 2, 3, f"SA open item: {item}", "WBS-100" if "WBS-100" in by_code else None, "DC SA", sa_id,
                               [_step("Confirm the item with the requestor and update the SA document", "DC SA", bd_after_today(ctx, 5))]))
        missing = [str(m) for m in (ini.get("sa_missing_json") or C.sa_score(text).get("missing") or [])]
        if any("backout" in m.lower() for m in missing):
            risks.append(_risk("No backout plan in the SA document", "The CRQ cannot pass compliance without an approved backout plan.",
                               "Compliance", 3, 3, "SA Completeness check: backout section missing",
                               "WBS-600" if "WBS-600" in by_code else None, "DC SA", sa_id,
                               [_step("Add the backout plan section to the SA document", "DC SA", bd_after_today(ctx, 5)),
                                _step("Attach the backout plan to the CRQ", "Rel Lead", bd_after_today(ctx, 15))]))
        if re.search(r"pen(etration)? test", text, re.IGNORECASE):
            qa = "WBS-400" if "WBS-400" in by_code else None
            risks.append(_risk("Penetration test findings land late", "Security findings after QA would force rework before readiness.",
                               "Technical", 3, 2, "SA requires a penetration test before production", qa, "Tech Lead", tl_id,
                               [_step("Book the penetration test slot before QA starts", "Tech Lead", bd_after_today(ctx, 10))]))
    # 5 key-person skills
    for t in tasks:
        if not t.get("component_code") or not t.get("resource_id"):
            continue
        req = COMPONENT_SKILLS.get(t["component_code"], [])
        for s in req[:1]:
            holders = [r for r in b.get("resources", []) if r.get("capacity_eligible") and skill_level(r, s) >= 2]
            if len(holders) == 1:
                risks.append(_risk(f"Key-person dependency on {holders[0]['name']} ({s})",
                                   f"Only one person holds {s} at working level or above.", "Resource", 2, 2,
                                   f"Skill matrix: 1 holder of {s}", t["wbs_code"], "Tech Lead", tl_id,
                                   [_step(f"Pair a second developer on {t['wbs_code']}", "Tech Lead", bd_after_today(ctx, 10))]))
    # 6 overdue tasks
    for t in tasks:
        if t.get("planned_end") and t["planned_end"] < today and int(t.get("pct") or 0) < 100 and t.get("status") != "Completed":
            late = C.business_days_from(t["planned_end"], today)
            risks.append(_risk(f"{t['wbs_code']} is {late} business days late", f"{t['step']} has passed its end date at {t.get('pct') or 0}% complete.",
                               "Schedule", 3 if late <= 5 else 4, 4, f"Planned end {fmt_date(t['planned_end'])}, {t.get('pct') or 0}% complete",
                               t["wbs_code"], "DC PM", pm_id,
                               [_step("Re-plan the remaining work with the task owner", "DC PM", bd_after_today(ctx, 2))]))
    # 7 unassigned tasks starting soon
    for t in tasks:
        if (not t.get("resource_id") and float(t.get("est_hours") or 0) > 0 and t.get("planned_start")
                and 0 <= C.business_days_from(today, t["planned_start"]) <= 10):
            risks.append(_risk(f"{t['wbs_code']} has no resource", f"{t['step']} starts {fmt_date(t['planned_start'])} without anyone assigned.",
                               "Resource", 3, 3, f"Starts in {C.business_days_from(today, t['planned_start'])} business days, unassigned",
                               t["wbs_code"], "DC PM", pm_id, [_step("Assign a resource (Suggest Resources)", "DC PM", bd_after_today(ctx, 2))]))
    # 8 downstream regression
    regress = [t for t in tasks if t.get("parent_id") and (t.get("step") or "").startswith("Regression")]
    if regress:
        risks.append(_risk("Downstream channels break on the changed services",
                           f"{len(regress)} downstream regression step{'s' if len(regress) > 1 else ''} depend on channel teams' test capacity.",
                           "Technical", 2, 2, f"Regression steps {', '.join(t['wbs_code'] for t in regress)}", regress[0]["wbs_code"],
                           "QA Lead", None, [_step("Confirm channel test environments and data before SIT", "QA Lead", bd_after_today(ctx, 15))]))
    # 9 budget
    prn = b.get("prn")
    if prn:
        charged = sum(float(c.get("charged_hours") or 0) for c in prn.get("charges", []))
        remaining = sum(float(t.get("est_hours") or 0) * (1 - (t.get("pct") or 0) / 100) for t in tasks)
        if charged + remaining > float(prn.get("funded_hours") or 0) > 0:
            risks.append(_risk(f"Forecast exceeds {prn['prn_code']} funding",
                               f"Charged {fmt_hours(charged)} plus remaining plan {fmt_hours(remaining)} is above {fmt_hours(prn['funded_hours'])} funded.",
                               "Budget", 3, 3, f"Forecast {fmt_hours(charged + remaining)} vs funded {fmt_hours(prn['funded_hours'])}",
                               None, "DC PM", pm_id, [_step("Request additional funding or reduce scope", "DC PM", bd_after_today(ctx, 5))]))
    # 10 change requests
    for cr in b.get("change_requests", []):
        flags = (cr.get("compliance") or {}).get("flags") or []
        if flags:
            risks.append(_risk(f"{cr.get('crq_number') or 'CRQ'} not compliant", "; ".join(f.get("message", "") for f in flags[:3]) or "Compliance flags open",
                               "Compliance", 3, 3, f"{len(flags)} compliance flag{'s' if len(flags) > 1 else ''} on {cr.get('crq_number') or 'the CRQ'}",
                               "WBS-600" if "WBS-600" in by_code else None, "Rel Lead", None,
                               [_step("Clear the compliance flags before the STO review", "Rel Lead", bd_after_today(ctx, 5))]))
    # 11 freeze proximity
    if ini.get("prod_date"):
        fz = C.freeze_window()
        if C.in_freeze(ini["prod_date"]) or 0 <= C.business_days_from(fz["end"], ini["prod_date"]) <= 10:
            risks.append(_risk("Production close to the change freeze", "Little room to recover before or after the 14 Dec–8 Jan freeze.",
                               "Schedule", 3, 2, f"Production {fmt_date(ini['prod_date'])}; freeze ends {fmt_date(fz['end'])}",
                               "WBS-700" if "WBS-700" in by_code else None, "Rel Lead", None,
                               [_step("Book the CAB slot early", "Rel Lead", bd_after_today(ctx, 10))]))
    existing = {r["title"].lower() for r in b.get("risks", [])}
    risks = [r for r in risks if r["title"].lower() not in existing]
    seen, uniq = set(), []
    for r in risks:
        if r["title"].lower() not in seen:
            seen.add(r["title"].lower())
            uniq.append(r)
    uniq.sort(key=lambda r: (-(r["severity"] * r["likelihood"]), r["title"]))
    uniq = uniq[:8]
    for r in uniq:
        if r["owner_resource_id"] and r["owner_resource_id"] not in people:
            r["owner_resource_id"] = None
    health = ini.get("health_cached_json") if isinstance(ini.get("health_cached_json"), dict) else C.compute_health(b) or {}
    attention = (health or {}).get("attention") or []
    if attention:
        mgmt = attention[0]
    elif uniq:
        mgmt = f"{uniq[0]['title']}{' affecting ' + uniq[0]['wbs_code'] if uniq[0]['wbs_code'] and uniq[0]['wbs_code'] not in uniq[0]['title'] else ''}"
    else:
        mgmt = ""
    top = max((r["severity"] * r["likelihood"] for r in uniq), default=0)
    level = "Critical" if top >= 12 else "High" if top >= 8 else "Medium" if top >= 4 else "Low"
    sources = [src("initiative", ini["rddc"], f"{ini['rddc']} plan, allocations and health")]
    if text:
        sources.append(src("sa_doc", "sa_doc", "SA document open items and sections"))
    sources.append(src("rule", "risk-rules", "Risk rules: capacity, float, approvals, SA gaps, key person, overdue, budget, compliance"))
    warnings = [] if tasks else ["No project plan yet; schedule and resource risks will appear once the plan exists."]
    return {"risks": uniq, "management_attention": clip(mgmt, 200), "overall_level": level,
            "confidence": round(0.6 + 0.2 * bool(tasks) + 0.1 * bool(text), 2), "sources": sources, "warnings": warnings}


# ================================================================== F8 exec_summary
def _period(ctx: dict) -> dict:
    t = C.to_date(ctx["today"])
    return {"from": (t - timedelta(days=6)).isoformat(), "to": t.isoformat()}


def gen_exec_summary(ctx: dict, variant: int = 0) -> dict:
    if ctx.get("bundle"):
        return _exec_initiative(ctx, variant)
    return _exec_portfolio(ctx, variant)


def _exec_initiative(ctx: dict, variant: int) -> dict:
    b = ctx["bundle"]
    ini = b["initiative"]
    health = ini.get("health_cached_json") if isinstance(ini.get("health_cached_json"), dict) else (C.compute_health(b) or {})
    scored = bool(health.get("scored", True)) and health.get("overall") in ("Red", "Amber", "Green")
    rag = health["overall"] if scored else "Not scored"
    dims = health.get("dimensions") or {}
    reds = [(k, v) for k, v in dims.items() if isinstance(v, dict) and v.get("rag") in ("Red", "Amber")]
    lead = (reds[0][1].get("reasons") or [""])[0] if reds else ""
    train = ini.get("target_release")
    if scored:
        headline = f"{ini['name']} is {rag}" + (f": {lead[0].lower() + lead[1:]}" if lead else f" for {train or 'its release'}")
    else:
        headline = f"{ini['name']} is in {ini['stage']}; health is scored from Planning onward"
    highlights, concerns, asks = [], [], []
    comps = b.get("components", [])
    if comps:
        highlights.append(f"Change Summary covers {len(comps)} DC component{'s' if len(comps) > 1 else ''}: "
                          f"{', '.join(c.get('name') or COMPONENT_NAMES[c['code']] for c in comps)}")
    if ini.get("l2_hours"):
        highlights.append(f"L2 estimate {fmt_hours(ini['l2_hours'])} ({ini.get('l2_tshirt') or '-'}), status {ini.get('l2_status') or 'Draft'}")
    if b.get("tasks"):
        highlights.append(f"Plan of {len(b['tasks'])} WBS steps; Readiness {fmt_date(ini.get('readiness_date'))}, "
                          f"QA Date {fmt_date(ini.get('qa_date'))}")
    if ini.get("prod_date"):
        highlights.append(f"Production on {train or 'the release train'} {fmt_date(ini['prod_date'])}")
    for k, v in reds:
        for reason in (v.get("reasons") or [])[:1]:
            concerns.append(f"{k.capitalize()} {v['rag']}: {reason}")
    for c in comps:
        if c.get("approval") == "Pending":
            asks.append(f"Confirm {c.get('name') or COMPONENT_NAMES[c['code']]} approval ({c.get('component_lead_name') or 'component lead'})")
    if ini.get("l2_status") == "Pending approval":
        asks.append(f"Approve the L2 estimate of {fmt_hours(ini.get('l2_hours'))} ({ini.get('requestor_name') or 'requestor'})")
    if dims.get("resources", {}).get("rag") == "Red":
        asks.append("Agree the resource fix for the over-allocated person (Suggest fix on Pg 3)")
    for r in sorted(b.get("risks", []), key=lambda r: -(r.get("score") or (r["severity"] * r["likelihood"])))[:2]:
        if r.get("status") != "Closed":
            concerns.append(f"Risk {r.get('risk_code') or ''} {r['title']}".replace("  ", " "))
    releases = []
    for cr in b.get("change_requests", []):
        if cr.get("release_train") and cr.get("crq_start"):
            releases.append({"rddc": ini["rddc"], "release_train": cr["release_train"], "date": str(cr["crq_start"])[:10],
                             "sto_approval": cr.get("sto_approval")})
    if not releases and ini.get("target_release") and ini.get("prod_date"):
        releases.append({"rddc": ini["rddc"], "release_train": ini["target_release"], "date": ini["prod_date"], "sto_approval": None})
    lines = [f"**{ini['rddc']} {ini['name']}** · {ini['stage']} · {rag}"]
    if ini.get("l2_hours"):
        lines.append(f"- L2 {fmt_hours(ini['l2_hours'])} ({ini.get('l2_tshirt')}), {ini.get('l2_status') or 'Draft'}")
    if ini.get("readiness_date"):
        fl = C.initiative_float(ini)
        lines.append(f"- Readiness {fmt_date(ini['readiness_date'])}" + (
            f", {fl} business days before {train}" if fl is not None and fl >= 0 else
            f", {-fl} business days after {train}" if fl is not None else ""))
    for k, v in dims.items():
        if isinstance(v, dict) and v.get("rag"):
            lines.append(f"- {k.capitalize()}: {v['rag']}" + (f" ({v['reasons'][0]})" if v.get("reasons") else ""))
    if health.get("attention"):
        lines.append(f"- Management attention: {health['attention'][0]}")
    sources = [src("initiative", ini["rddc"], f"{ini['rddc']} health and plan")]
    return {"scope": "initiative", "rddc": ini["rddc"], "period": _period(ctx), "headline": clip(headline, 200), "rag": rag,
            "summary_md": clip("\n".join(lines), 3000), "highlights": [clip(h, 300) for h in highlights[:5]],
            "concerns": [clip(c, 300) for c in concerns[:5]], "asks": [clip(a, 300) for a in asks[:5]],
            "upcoming_releases": releases[:20], "confidence": 0.85 if scored else 0.7, "sources": sources,
            "warnings": [] if scored else ["Health is not scored before Planning."]}


def _exec_portfolio(ctx: dict, variant: int) -> dict:
    rows = [r for r in ctx["data"].get("portfolio") or [] if r["stage"] != "Closed"]
    today = ctx["today"]
    counts = {k: sum(1 for r in rows if r.get("rag") == k) for k in ("Red", "Amber", "Green")}
    unscored = sum(1 for r in rows if r.get("rag") not in ("Red", "Amber", "Green"))
    reds = [r for r in rows if r.get("rag") == "Red"]
    ambers = [r for r in rows if r.get("rag") == "Amber"]
    overall = "Red" if reds else "Amber" if ambers else "Green" if rows else "Not scored"

    def reason(r):
        h = r.get("health_cached_json") if isinstance(r.get("health_cached_json"), dict) else {}
        att = h.get("attention") or []
        if att:
            return att[0]
        for v in (h.get("dimensions") or {}).values():
            if isinstance(v, dict) and v.get("rag") in ("Red", "Amber") and v.get("reasons"):
                return v["reasons"][0]
        return r.get("comments") or ""

    headline = pick(variant,
                    f"{len(rows)} active initiatives: {counts['Red']} Red, {counts['Amber']} Amber, {counts['Green']} Green",
                    f"{counts['Red'] + counts['Amber']} of {len(rows)} active initiatives need attention this week")
    if reds:
        headline += f"; {reds[0]['rddc']} needs a decision"
    per = []
    for r in rows:
        rag = r.get("rag") if r.get("rag") in ("Red", "Amber", "Green") else "Not scored"
        why = reason(r)
        line = f"{r['stage']}" + (f"; {why}" if why else "") + (f"; target {r['target_release']}" if r.get("target_release") else "")
        per.append({"rddc": r["rddc"], "name": clip(r["name"], 200), "rag": rag, "one_liner": clip(line, 200)})
    order = {"Red": 0, "Amber": 1, "Green": 2, "Not scored": 3}
    per.sort(key=lambda p: (order[p["rag"]], p["rddc"]))
    highlights = []
    for r in rows:
        if r.get("rag") == "Green" and r["stage"] in ("Build", "QA", "Release", "Planning"):
            highlights.append(f"{r['rddc']} {r['name']} on track in {r['stage']}")
    accepted = ctx["data"].get("recent_runs") or []
    if accepted:
        highlights.append(f"{len(accepted)} AI drafts accepted into initiative records")
    concerns = [f"{r['rddc']} {r['rag']}: {reason(r)}" for r in reds + ambers if reason(r)]
    asks = []
    for r in rows:
        if r.get("l2_status") == "Pending approval":
            asks.append(f"Approve the L2 estimate for {r['rddc']} ({fmt_hours(r.get('l2_hours'))})")
    horizon = (C.to_date(today) + timedelta(days=14)).isoformat()
    releases = []
    for cr in ctx["data"].get("change_requests") or []:
        start = str(cr.get("crq_start") or "")[:10]
        if start and today <= start <= horizon:
            releases.append({"rddc": cr["rddc"], "release_train": cr.get("release_train") or "Independent", "date": start,
                             "sto_approval": cr.get("sto_approval")})
            if cr.get("sto_approval") in ("Tentative No Go", "No-Go"):
                asks.append(f"STO decision on {cr.get('crq_number') or cr['rddc']} ({cr['sto_approval']})")
    util = ctx["data"].get("utilisation") or {}
    names = ctx["data"].get("people") or {}
    watch = []
    months = sorted({m for p in util.values() for m in p if m >= today[:7]})[:4]
    for rid in sorted(util):
        for m in months:
            c = util[rid].get(m)
            if c and c["util"] > 1.0:
                watch.append(f"{names.get(rid, rid)} at {rint(c['util'] * 100)}% in {fmt_month(m)}")
    md = [f"**Portfolio status · week ending {fmt_date(today)}**",
          f"- {counts['Red']} Red · {counts['Amber']} Amber · {counts['Green']} Green" + (f" · {unscored} not scored yet" if unscored else "")]
    md += [f"- {c}" for c in concerns[:4]]
    if releases:
        md.append(f"- {len(releases)} change{'s' if len(releases) > 1 else ''} going to production in the next 14 days")
    if watch:
        md.append(f"- Capacity: {'; '.join(watch[:3])}")
    sources = [src("initiative", r["rddc"], f"{r['rddc']} health") for r in (reds + ambers)[:10]]
    sources.append(src("engine", "health", "Portfolio health (calculated)"))
    return {"scope": "portfolio", "rddc": None, "period": _period(ctx), "headline": clip(headline, 200), "rag": overall,
            "summary_md": clip("\n".join(md), 3000), "highlights": [clip(h, 300) for h in highlights[:5]],
            "concerns": [clip(c, 300) for c in concerns[:5]], "asks": [clip(a, 300) for a in asks[:5]],
            "per_initiative": per[:30], "upcoming_releases": releases[:20], "capacity_watch": [clip(w, 300) for w in watch[:8]],
            "confidence": 0.85 if rows else 0.5, "sources": sources[:40],
            "warnings": [] if rows else ["No active initiatives found."]}


# ================================================================== F9 cr_compliance
def evaluate_cr(cr: dict, ctx: dict) -> list[dict]:
    """CR rules (CR-01..CR-10) evaluated in code; verdicts are never left to the model."""
    today = C.to_date(ctx["today"])
    atts = ctx["data"].get("attachments") or {}
    people = ctx["data"].get("people") or {}
    start = C.to_date(cr["crq_start"]) if cr.get("crq_start") else None
    end_raw = str(cr.get("crq_end") or "")
    findings = []

    def add(rid, rule, status, field, detail, fix, blocking):
        findings.append({"rule_id": rid, "rule": rule, "status": status, "field": field, "detail": clip(detail, 400),
                         "fix": clip(fix, 400) if fix else None, "blocking": bool(blocking)})

    lead = 10 if cr.get("release_type") == "Bundle" else 5
    if start and cr.get("raised_at"):
        bd = C.business_days_from(cr["raised_at"], start)
        ok = bd >= lead
        add("CR-01", f"Raised at least {lead} business days before the window", "Pass" if ok else "Fail", "raised_at",
            f"Raised {fmt_date(cr['raised_at'])}, {bd} business days before the window.",
            None if ok else "Record the late-raise justification and request CAB exception.", not ok)
    else:
        add("CR-01", f"Raised at least {lead} business days before the window", "Warn", "raised_at",
            "Raised date or window start not recorded.", "Record when the CRQ was raised.", False)
    if start:
        frozen = C.in_freeze(start)
        add("CR-02", "Window is outside the change freeze", "Fail" if frozen else "Pass", "crq_start",
            f"Window starts {fmt_date(start)}{' inside the 14 Dec–8 Jan freeze' if frozen else ''}.",
            "Move the window to a release train outside the freeze." if frozen else None, frozen)
        if end_raw[:10]:
            hours = None
            try:
                from datetime import datetime
                hours = (datetime.fromisoformat(end_raw) - datetime.fromisoformat(str(cr["crq_start"]))).total_seconds() / 3600
            except ValueError:
                hours = None
            if hours is not None and hours > 8:
                add("CR-02", "Window is outside the change freeze", "Warn", "crq_end", f"Window is {hours:.0f} h long (over 8 h).",
                    "Split the change or shorten the window.", False)
    else:
        add("CR-02", "Window is outside the change freeze", "Fail", "crq_start", "No CRQ window recorded.", "Set the CRQ start and end.", True)
    cis = cr.get("affected_cis") or []
    comps = cr.get("impacted_components") or []
    ok = bool(cis) and bool(comps)
    add("CR-03", "Affected CIs and impacted components are named", "Pass" if ok else "Fail", "affected_cis",
        f"{len(cis)} CI{'s' if len(cis) != 1 else ''}, {len(comps)} component{'s' if len(comps) != 1 else ''}.",
        None if ok else "Add the affected CIs from the Change Summary components.", not ok)
    has_backout = bool(cr.get("backout_attachment_id")) or any(a.get("kind") == "backout_plan" for a in atts.values())
    add("CR-04", "Backout plan attached", "Pass" if has_backout else "Fail", "backout_attachment_id",
        "Backout plan attached." if has_backout else "Backout plan not attached.",
        None if has_backout else "Attach the approved backout plan to the CRQ.", not has_backout)
    sto = cr.get("sto_approval")
    if start:
        bd_left = C.business_days_from(today, start)
        if sto == "Go":
            add("CR-05", "STO approval is Go by T-2 business days", "Pass", "sto_approval", "STO approval is Go.", None, False)
        elif sto == "No-Go":
            add("CR-05", "STO approval is Go by T-2 business days", "Fail", "sto_approval", "STO decision is No-Go.",
                "Resolve the STO concerns and request a new review.", True)
        elif bd_left <= 2:
            add("CR-05", "STO approval is Go by T-2 business days", "Fail", "sto_approval",
                f"STO approval is {sto or 'not set'} with {max(bd_left, 0)} business days to the window.",
                "Escalate to the STO board for a Go decision.", True)
        else:
            add("CR-05", "STO approval is Go by T-2 business days", "Warn", "sto_approval",
                f"STO approval is {sto or 'not set'}; Go needed by {fmt_date(C.add_business_days(today, max(bd_left - 2, 0)))}.",
                "Clear open flags so STO can move to Go.", False)
    for rid, label, status_key, att_key in (("CR-06", "Technical", "tech_validation_status", "tech_validation_attachment_id"),
                                            ("CR-07", "Business", "biz_validation_status", "biz_validation_attachment_id")):
        status = cr.get(status_key) or "Not Started"
        attached = bool(cr.get(att_key))
        implemented = cr.get("implementation_status") == "Implemented"
        if status == "Failed":
            add(rid, f"{label} validation passed with evidence attached", "Fail", status_key, f"{label} validation Failed.",
                f"Fix the {label.lower()} validation defects and re-test.", True)
        elif implemented and not attached:
            add(rid, f"{label} validation passed with evidence attached", "Fail", att_key,
                f"Implemented without {label.lower()} validation evidence.", f"Attach the {label.lower()} validation evidence.", True)
        elif status in ("In progress", "Completed") and not attached:
            add(rid, f"{label} validation passed with evidence attached", "Warn", att_key,
                f"{label} validation {status.lower()}; no evidence attached yet.", f"Attach the {label.lower()} validation evidence.", False)
        else:
            add(rid, f"{label} validation passed with evidence attached", "Pass", status_key,
                f"{label} validation {status}{' with evidence' if attached else ''}.", None, False)
    named = [people.get(cr.get("cms_lead_id")), people.get(cr.get("rel_lead_id"))]
    ok = all(named)
    add("CR-08", "CMS lead and Rel lead are named", "Pass" if ok else "Fail", None if ok else "cms_lead_id",
        f"{' and '.join(n for n in named if n)} named." if any(named) else "No CMS lead or Rel lead named.",
        None if ok else "Name the CMS lead and Rel lead.", not ok)
    if cr.get("release_type") == "Bundle":
        ok = bool(cr.get("release_train"))
        add("CR-09", "Bundle release names a release train", "Pass" if ok else "Fail", "release_train",
            f"Release train {cr.get('release_train')}." if ok else "Bundle release without a train.",
            None if ok else "Select the release train.", not ok)
    appr = cr.get("crq_approval_status") or "Draft"
    if appr == "Approved":
        add("CR-10", "CRQ approved before the window", "Pass", "crq_approval_status", "CRQ approved.", None, False)
    elif appr == "Rejected" or (start and C.business_days_from(today, start) <= 2):
        add("CR-10", "CRQ approved before the window", "Fail", "crq_approval_status", f"CRQ approval status is {appr}.",
            "Submit the CRQ to CAB for approval.", True)
    else:
        add("CR-10", "CRQ approved before the window", "Warn", "crq_approval_status", f"CRQ approval status is {appr}.",
            "Submit the CRQ to CAB in time for the window.", False)
    return findings[:20]


def gen_cr_compliance(ctx: dict, variant: int = 0) -> dict:
    cr = ctx["data"].get("cr")
    if not cr:
        return {"crq_number": None, "compliant": False, "score": 0, "sto_readiness": "Not ready",
                "findings": [{"rule_id": "CR-00", "rule": "A change request exists", "status": "Fail", "field": None,
                              "detail": "No change request is logged for this initiative.",
                              "fix": "Create the CRQ draft on Pg 4.", "blocking": True}],
                "reviewer_note": "No change request to review. Create the CRQ draft on Pg 4 first.",
                "confidence": 0.9, "sources": [src("rule", "CR-00", "Change request required")], "warnings": []}
    engine = C.check_cr(cr, {})
    if engine and engine.get("findings"):
        return _cr_from_engine(cr, engine, ctx)
    findings = evaluate_cr(cr, ctx)
    if engine and engine.get("flags"):
        msgs = " ".join(f.get("message", "").lower() for f in findings if f["status"] == "Fail")
        for flag in engine["flags"]:
            message = flag.get("message") or flag.get("code") or "Compliance flag"
            if message.lower()[:20] not in msgs:
                findings.append({"rule_id": "CR-11", "rule": "Change governance rule", "status": "Fail",
                                 "field": None, "detail": clip(message, 400), "fix": None, "blocking": True})
    findings = findings[:20]
    blocking = [f for f in findings if f["status"] == "Fail"]
    warns = [f for f in findings if f["status"] == "Warn"]
    compliant = bool(engine["ok"]) if engine and "ok" in engine else not blocking
    score = rint(sum(1 for f in findings if f["status"] == "Pass") / len(findings) * 100)
    readiness = "Not ready" if blocking else "Tentative" if warns else "Ready for Go"
    number = cr.get("crq_number") or f"CRQ for {(ctx.get('keys') or {}).get('rddc', 'initiative')}"
    if blocking:
        note = f"{number} is not ready for Go: {'; '.join(f['detail'].rstrip('.') for f in blocking[:3])}."
    elif warns:
        note = f"{number} has no blocking findings. Still open: {'; '.join(f['detail'].rstrip('.') for f in warns[:3])}."
    else:
        note = f"{number} passes every rule and is ready for the STO Go decision."
    sources = [src("change_request", cr.get("crq_number") or cr["id"], cr.get("crq_number") or f"Change request {cr['id']}")]
    sources += [src("rule", f["rule_id"], f["rule"]) for f in blocking[:5]]
    return {"crq_number": cr.get("crq_number"), "compliant": compliant, "score": int(score), "sto_readiness": readiness,
            "findings": findings, "reviewer_note": clip(note, 600), "confidence": 0.9, "sources": sources, "warnings": []}


def _cr_from_engine(cr: dict, engine: dict, ctx: dict) -> dict:
    findings = []
    for f in engine["findings"][:20]:
        findings.append({"rule_id": f["rule_id"], "rule": clip(f.get("rule") or f["rule_id"], 200), "status": f["status"],
                         "field": f.get("field"), "detail": clip(f.get("detail") or f.get("rule") or "Checked", 400),
                         "fix": clip(f["fix"], 400) if f.get("fix") else None, "blocking": bool(f.get("blocking"))})
        if f.get("due_date"):
            findings[-1]["due_date"] = str(f["due_date"])[:10]
    fails = [f for f in findings if f["status"] == "Fail"]
    warns = [f for f in findings if f["status"] == "Warn"]
    readiness = C.sto_status(engine.get("sto_readiness")) or \
        ("Not ready" if any(f["blocking"] for f in findings) else "Tentative" if fails or warns else "Ready for Go")
    number = cr.get("crq_number") or "This CRQ"
    if fails:
        note = f"{number} is {'not ready' if readiness == 'Not ready' else 'not yet compliant'}: " \
               f"{'; '.join(f['detail'].rstrip('.') for f in fails[:3])}."
    elif warns:
        note = f"{number} has no failed rules. Still open: {'; '.join(f['detail'].rstrip('.') for f in warns[:3])}."
    else:
        note = f"{number} passes every rule and is ready for the STO Go decision."
    if cr.get("sto_approval") and engine.get("sto_suggestion") and cr["sto_approval"] in ("Tentative Go", "Tentative No Go") \
            and engine["sto_suggestion"] != cr["sto_approval"]:
        note += f" Suggested STO status: {engine['sto_suggestion']}."
    sources = [src("change_request", cr.get("crq_number") or cr["id"], cr.get("crq_number") or f"Change request {cr['id']}")]
    sources += [src("rule", f["rule_id"], f["rule"]) for f in fails[:5]]
    return {"crq_number": cr.get("crq_number"), "compliant": bool(engine.get("ok")), "score": int(engine.get("score") or 0),
            "sto_readiness": readiness, "findings": findings or [{"rule_id": "CR-00", "rule": "Rules checked", "status": "Pass",
                                                                  "field": None, "detail": "No rules applied.", "fix": None,
                                                                  "blocking": False}],
            "reviewer_note": clip(note, 600), "confidence": 0.9, "sources": sources, "warnings": []}


# ================================================================== F10 skill_matrix
def task_skills(task: dict) -> list[str]:
    code, phase, step = task.get("component_code"), task.get("phase"), (task.get("step") or "").lower()
    if code:
        return COMPONENT_SKILLS.get(code, [])
    if phase == "Estimation":
        return ["Solution design"]
    if phase == "Integration" and "regression" in step:
        if "mobile" in step:
            return ["Mobile testing", "Regression"]
        return ["Regression"]
    return {"Integration": ["API design", "Code review"], "QA": ["API automation", "Regression"],
            "Hypercare": ["SLOs", "Alerting"], "Development": []}.get(phase, [])


def gen_skill_matrix(ctx: dict, variant: int = 0) -> dict:
    data = ctx["data"]
    people = {r["id"]: r for r in data.get("resources") or []}
    declared = data.get("declared") or {}
    hours: dict[tuple[int, str], float] = {}
    evidence: dict[tuple[int, str], list[str]] = {}
    for t in data.get("task_history") or []:
        if t["resource_id"] not in people:
            continue
        for s in task_skills(t):
            key = (t["resource_id"], s)
            hours[key] = hours.get(key, 0.0) + float(t.get("est_hours") or 0)
            evidence.setdefault(key, []).append(f"{t['rddc']} {t['wbs_code']} ({fmt_hours(t.get('est_hours'))})")
    rows = []
    all_skills: list[str] = []
    for rid in sorted(people):
        p = people[rid]
        skills: dict[str, dict] = {}
        for d in declared.get(rid, []):
            skills[d["skill"]] = {"skill": d["skill"], "level": int(d["level"]), "evidence": [], "source": "declared", "_h": 0.0}
        for (r, s), h in hours.items():
            if r != rid:
                continue
            lvl = 3 if h >= 80 else 2 if h >= 20 else 1
            match = next((k for k in skills if norm(k) == norm(s)), None)
            if match:
                e = skills[match]
                e["level"] = max(e["level"], lvl)
                e["source"] = "both"
                e["evidence"] = evidence[(r, s)][:6]
                e["_h"] = h
            else:
                skills[s] = {"skill": s, "level": lvl, "evidence": evidence[(r, s)][:6], "source": "history", "_h": h}
        ordered = sorted(skills.values(), key=lambda e: (-e["level"], -e["_h"], e["skill"]))[:30]
        for e in ordered:
            if e["skill"] not in all_skills:
                all_skills.append(e["skill"])
        rows.append({"resource_id": rid, "resource_name": clip(p["name"], 120), "team": p.get("team") or "Unassigned",
                     "skills": [{k: (clip(v, 60) if k == "skill" else v) for k, v in e.items() if k != "_h"} for e in ordered],
                     "top_skills": [e["skill"] for e in ordered[:3]]})
    all_skills = sorted(all_skills)[:60] or ["Solution design"]
    gaps = []
    for s in all_skills:
        holders = [r["resource_name"] for r in rows if any(e["skill"] == s and e["level"] >= 2 for e in r["skills"])]
        if len(holders) <= 1:
            gaps.append({"skill": s, "holders": len(holders), "holder_names": holders,
                         "note": "Key-person risk" if holders else "No one at working level"})
    gaps = sorted(gaps, key=lambda g: (g["holders"], g["skill"]))[:20]
    n_hist = sum(1 for r in rows for e in r["skills"] if e["source"] in ("history", "both"))
    sources = [src("wbs_task", "history", f"{len(data.get('task_history') or [])} assigned WBS steps across the portfolio"),
               src("resource", "declared", "Declared skills in the resource inventory")]
    return {"skills": all_skills, "rows": rows[:40] or [{"resource_id": 1, "resource_name": "Unassigned", "team": "Unassigned",
                                                          "skills": [], "top_skills": []}],
            "team_gaps": gaps, "confidence": round(min(0.6 + n_hist / 200, 0.85), 2), "sources": sources,
            "warnings": [] if data.get("task_history") else ["No WBS history yet; levels come from declared skills only."]}


# ================================================================== F11 nudges
def gen_nudges(ctx: dict, variant: int = 0) -> dict:
    data = ctx["data"]
    people = data.get("people") or {}
    today = ctx["today"]
    action_by = C.add_business_days(today, 2).isoformat()
    buckets: dict[tuple, dict] = {}

    def add(rid, name, role, rule, item):
        if not name:
            return
        key = (rid or name)
        b = buckets.setdefault(key, {"rid": rid, "name": name, "role": role, "rules": [], "items": []})
        b["rules"].append(rule)
        b["items"].append(item)

    def age(ts):
        if not ts:
            return 0
        return max(0, (C.to_date(today) - C.to_date(str(ts)[:10])).days)

    for r in data.get("portfolio") or []:
        if r["stage"] in ("Solution", "Estimation", "Grooming") and (r.get("sa_completeness") is None or r["sa_completeness"] < 100) and r.get("dc_sa_id"):
            missing = r.get("sa_missing_json") or []
            label = f"SA document at {r['sa_completeness']}%" if r.get("sa_completeness") is not None else "SA document not attached"
            if missing:
                label += f"; missing {', '.join(missing[:3])}"
            add(r["dc_sa_id"], r.get("dc_sa_name"), "DC SA", "sa_action_required",
                {"type": "sa_input", "rddc": r["rddc"], "label": clip(label, 300), "age_days": age(r.get("created_at"))})
        if r.get("l2_status") == "Pending approval":
            who = r.get("requestor_id")
            add(who, r.get("requestor_name") or r.get("requestor"), "Requestor", "l2_approval",
                {"type": "l2_approval", "rddc": r["rddc"], "label": clip(f"Approve L2 estimate of {fmt_hours(r.get('l2_hours'))} for {r['name']}", 300),
                 "age_days": age(r.get("l2_submitted_at"))})
    for c in data.get("pending_components") or []:
        add(c.get("lead_id"), c.get("lead_name"), c.get("lead_role") or "Component Lead", "sa_action_required",
            {"type": "approval", "rddc": c["rddc"], "label": clip(f"Approve the {c['component_name']} change for {c['initiative_name']}", 300), "age_days": 0})
    horizon = (C.to_date(today) + timedelta(days=14)).isoformat()
    for cr in data.get("change_requests") or []:
        start = str(cr.get("crq_start") or "")[:10]
        if not start or not (today <= start <= horizon):
            continue
        missing = [lbl for lbl, st, att in (("technical", "tech_validation_status", "tech_validation_attachment_id"),
                                            ("business", "biz_validation_status", "biz_validation_attachment_id"))
                   if cr.get(st) != "Completed" or not cr.get(att)]
        target = people.get(cr.get("resource_id")) or people.get(cr.get("rel_lead_id"))
        if missing and target:
            add(target["id"], target["name"], target.get("role") or "Resource", "validation_missing",
                {"type": "validation", "rddc": cr["rddc"], "label": clip(f"{cr.get('crq_number') or 'CRQ'}: attach {' and '.join(missing)} validation evidence", 300),
                 "age_days": 0})
        flags = ((cr.get("compliance_json") or {}) if isinstance(cr.get("compliance_json"), dict) else {}).get("flags") or []
        cms = people.get(cr.get("cms_lead_id"))
        if flags and cms:
            add(cms["id"], cms["name"], cms.get("role") or "CMS Lead", "cr_noncompliance",
                {"type": "action", "rddc": cr["rddc"], "label": clip(f"{cr.get('crq_number') or 'CRQ'}: {flags[0].get('message', 'compliance flag open')}", 300),
                 "age_days": 0})
    messages = []
    for key in sorted(buckets, key=lambda k: str(k)):
        b = buckets[key]
        items = b["items"][:20]
        rule = max(set(b["rules"]), key=lambda r: (b["rules"].count(r), r))
        first = b["name"].split(" ")[0]
        rddcs = sorted({i["rddc"] for i in items if i["rddc"]})
        subject = f"Action required by {fmt_date(action_by)}: {len(items)} item{'s' if len(items) > 1 else ''}" + (f" for {', '.join(rddcs[:3])}" if rddcs else "")
        lines = "\n".join(f"- {i['rddc'] + ': ' if i['rddc'] else ''}{i['label']}" for i in items)
        body = pick(variant,
                    f"Hi {first},\n\nThe following {'items are' if len(items) > 1 else 'item is'} waiting on you:\n{lines}\n\n"
                    f"Please action by {fmt_date(action_by)} so the plan stays on track.\n\nThanks,\nDigital Channels PMO",
                    f"Hi {first},\n\nQuick reminder — please close these by {fmt_date(action_by)}:\n{lines}\n\nThanks,\nDigital Channels PMO")
        oldest = max(i["age_days"] for i in items)
        level = 0
        if rule == "l2_approval":
            level = min(3, max((r.get("l2_reminders_sent") or 0) for r in (data.get("portfolio") or []) if r["rddc"] in rddcs) if rddcs else 0)
        messages.append({"recipient_name": clip(b["name"], 120), "recipient_resource_id": b["rid"] if b["rid"] in people else None,
                         "recipient_role": clip(b["role"], 80), "rule": rule, "subject": clip(subject, 200), "body": clip(body, 1500),
                         "action_required_by": action_by, "urgency": "High" if oldest > 5 or level >= 2 else "Normal",
                         "escalation_level": int(level),
                         "dedupe_key": nudge_key(rule, b["rid"] if b["rid"] in people else None, b["name"], action_by),
                         "items": items})
    existing = data.get("existing_keys") or {}
    warnings = []
    # a key already handled (sent, dismissed, or already consolidated by an accepted draft) is not drafted again
    fresh = [m for m in messages if not (m["dedupe_key"] in existing and
                                         (existing[m["dedupe_key"]]["status"] != "Queued" or existing[m["dedupe_key"]]["ai"]))]
    if len(fresh) < len(messages):
        warnings.append(f"{len(messages) - len(fresh)} reminder{'s' if len(messages) - len(fresh) > 1 else ''} already queued for {fmt_date(action_by)}.")
    sources = [src("rule", "action-required", "Action required by = today + 2 business days")]
    sources += [src("initiative", r, r) for r in sorted({i["rddc"] for m in fresh for i in m["items"] if i["rddc"]})[:20]]
    return {"messages": fresh[:40], "confidence": 0.9 if fresh else 0.8, "sources": sources[:40], "warnings": warnings}


def nudge_key(rule: str, rid: int | None, name: str, action_by: str) -> str:
    """Reminders-engine dedupe format (rule:entity_type:entity_id:date) with the recipient as the entity, so one
    consolidated reminder per person per date is ever queued, however often the draft is accepted."""
    return f"{rule}:resource:{rid}:{action_by}" if rid else f"{rule}:recipient:{norm(name)}:{action_by}"


# ================================================================== F12 meeting_extract
DAY_NAMES = {"mon": 0, "monday": 0, "tue": 1, "tuesday": 1, "wed": 2, "wednesday": 2, "thu": 3, "thursday": 3,
             "fri": 4, "friday": 4}


def _resolve_due(token: str, base: date) -> str | None:
    t = token.strip().lower().rstrip(".,")
    if re.match(r"\d{4}-\d{2}-\d{2}$", t):
        return t
    if t in ("eod", "today"):
        return base.isoformat()
    if t in ("eow", "end of week", "friday") or t in DAY_NAMES:
        target = DAY_NAMES.get(t, 4)
        d = base + timedelta(days=1)
        while d.weekday() != target:
            d += timedelta(days=1)
        return d.isoformat()
    m = re.match(r"(\d{1,2})\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)", t)
    if m:
        month = [x.lower() for x in MONTHS].index(m.group(2)) + 1
        year = base.year + (1 if month < base.month - 6 else 0)
        try:
            return date(year, month, int(m.group(1))).isoformat()
        except ValueError:
            return None
    return None


def _match_person(token: str, people: list[dict]) -> dict | None:
    token = token.strip().lower()
    if not token:
        return None
    for p in people:
        full = p["name"].lower()
        if token == full or token == full.split(" ")[0] or token == full.split(" ")[-1]:
            return p
    best, score = None, 0.0
    for p in people:
        r = difflib.SequenceMatcher(None, token, p["name"].lower()).ratio()
        if r > score:
            best, score = p, r
    return best if score >= 0.8 else None


def gen_meeting_extract(ctx: dict, variant: int = 0) -> dict:
    data = ctx["data"]
    text = data.get("text") or ""
    note = data.get("note") or {}
    people = data.get("people") or []
    inits = data.get("initiatives") or []
    m = re.search(r"\b(20\d{2}-\d{2}-\d{2})\b", text)
    meeting_date = note.get("meeting_date") or (m.group(1) if m else None)
    base = C.to_date(meeting_date or ctx["today"])
    default_rddc = None
    if note.get("initiative_id"):
        default_rddc = next((i["rddc"] for i in inits if i["id"] == note["initiative_id"]), None)
    attendees = list(note.get("attendees") or [])
    decisions, actions, risks, questions = [], [], [], []
    for n, raw in enumerate(text.splitlines(), start=1):
        line = raw.strip(" -*•\t")
        if not line:
            continue
        low = line.lower()
        if low.startswith(("attendees", "present")) and ":" in line:
            attendees = [a.strip() for a in line.split(":", 1)[1].split(",") if a.strip()]
            continue
        rm = re.search(r"RDDC-\d{5}", line)
        rddc = rm.group(0) if rm else next((i["rddc"] for i in inits if i["name"].lower() in low), default_rddc)
        if rddc and not any(i["rddc"] == rddc for i in inits):
            rddc = default_rddc
        if re.match(r"^(decision|agreed|decided)\b[:\-\s]", low) or re.search(r"\bwe (agreed|decided)\b", low):
            body = re.sub(r"^(decision|agreed|decided)\s*[:\-–]\s*", "", line, flags=re.IGNORECASE)
            who = re.search(r"\((?:by\s+)?([A-Z][a-z]+(?: [A-Z][a-z]+)?)\)", line)
            maker = _match_person(who.group(1), people) if who else None
            parts = re.split(r"\s+(?:because|as|since)\s+", body, maxsplit=1)
            decisions.append({"decision": clip(parts[0], 400), "made_by": maker["name"] if maker else None,
                              "rationale": clip(parts[1], 400) if len(parts) > 1 else None, "rddc": rddc})
            continue
        am = re.match(r"^(ai|action|todo|action item)\s*[:\-–]\s*(.+)$", line, re.IGNORECASE)
        owner_tok = None
        body = None
        if am:
            body = am.group(2)
            om = re.match(r"@?([A-Z][a-z]+(?: [A-Z][a-z]+)?)\s+(?:to|will)\s+(.+)", body)
            if om:
                owner_tok, body = om.group(1), om.group(2)
            else:
                at = re.search(r"@([A-Za-z]+)", body)
                owner_tok = at.group(1) if at else None
        else:
            om = re.match(r"^@?([A-Z][a-z]+(?: [A-Z][a-z]+)?)\s+(will|to)\s+(.+)$", line)
            if om and _match_person(om.group(1), people):
                owner_tok, body = om.group(1), om.group(3)
        if body:
            owner = _match_person(owner_tok, people) if owner_tok else None
            dm = re.search(r"\bby\s+(\d{4}-\d{2}-\d{2}|\d{1,2}\s+[A-Za-z]{3}\w*|mon\w*|tue\w*|wed\w*|thu\w*|fri\w*|eow|eod|end of week)", body, re.IGNORECASE)
            due = None
            if dm:
                token = dm.group(1)
                due = _resolve_due(token[:3] if token[:3].lower() in DAY_NAMES else token, base)
            actions.append({"action": clip(body[0].upper() + body[1:], 400), "owner_name": owner["name"] if owner else (owner_tok or None),
                            "owner_resource_id": owner["id"] if owner else None, "due": due, "rddc": rddc, "source_line": n})
            continue
        if re.search(r"\brisk\b|\bconcern\b|\bblocker\b", low):
            risks.append({"title": clip(re.sub(r"^(risk|concern|blocker)\s*[:\-–]\s*", "", line, flags=re.IGNORECASE), 200), "rddc": rddc})
        elif line.endswith("?") or low.startswith(("q:", "open question", "question")):
            questions.append(clip(re.sub(r"^(q|open question|question)\s*[:\-–]\s*", "", line, flags=re.IGNORECASE), 300))
    title = note.get("title") or "Meeting"
    summary = (f"{title}{' on ' + fmt_date(meeting_date) if meeting_date else ''}: {len(decisions)} decision{'s' if len(decisions) != 1 else ''}, "
               f"{len(actions)} action{'s' if len(actions) != 1 else ''}"
               + (f" ({sum(1 for a in actions if not a['owner_resource_id'])} without a named owner)" if any(not a['owner_resource_id'] for a in actions) else "")
               + (f", {len(risks)} risk{'s' if len(risks) != 1 else ''} raised" if risks else "") + ".")
    warnings = []
    if not text.strip():
        warnings.append("No meeting notes text to read.")
    unowned = [a for a in actions if not a["owner_resource_id"]]
    if unowned:
        warnings.append(f"{len(unowned)} action{'s have' if len(unowned) > 1 else ' has'} no matched owner; assign before accepting.")
    sources = [src("meeting_note", note.get("id") or "pasted", f"{title}{' ' + fmt_date(meeting_date) if meeting_date else ''}")]
    out = {"summary": clip(summary, 800), "meeting_date": meeting_date, "decisions": decisions[:20], "actions": actions[:30],
           "risks_raised": risks[:10], "open_questions": questions[:10],
           "confidence": round(0.55 + 0.3 * bool(decisions or actions) - 0.05 * min(len(unowned), 3), 2),
           "sources": sources, "warnings": warnings}
    if attendees:
        out["attendees"] = [clip(a, 120) for a in attendees[:30]]
    return out


# ================================================================== F13 lessons
def gen_lessons(ctx: dict, variant: int = 0) -> dict:
    b = ctx.get("bundle")
    data = ctx["data"]
    if b and (b["initiative"]["stage"] == "Closed" or b["initiative"]["status"] == "Completed"):
        return _lessons_draft(ctx, variant)
    ini = b["initiative"] if b else None
    my_tags = set()
    corpus = ""
    if ini:
        my_tags = {c["code"].lower() for c in b.get("components", [])} | {str(x).lower() for x in ini.get("labels") or []}
        corpus = f"{ini['name']} {ini.get('description') or ''}"
    my_tokens = _tokens(corpus)
    scored = []
    for lesson in data.get("lessons") or []:
        if ini and lesson.get("initiative_id") == ini["id"]:
            continue
        tags = {str(t).lower() for t in lesson.get("tags") or []}
        lt = _tokens(f"{lesson.get('lesson')} {lesson.get('what_happened') or ''} {lesson.get('recommendation') or ''}")
        overlap = tags & my_tags
        tok = len(my_tokens & lt)
        score = 2 * len(overlap) + tok * 0.5 + (0.5 if not ini else 0)
        if score > 0 and lesson.get("rddc"):
            why = (f"Shares {', '.join(sorted(COMPONENT_NAMES.get(t.upper(), t) for t in overlap))}" if overlap
                   else "Similar delivery context")
            scored.append((score, lesson, why))
    scored.sort(key=lambda x: (-x[0], x[1]["id"]))
    relevant = [{"lesson_id": lesson["id"], "rddc": lesson["rddc"], "lesson": clip(lesson["lesson"], 400), "why_relevant": clip(why, 300)}
                for _, lesson, why in scored[:5]]
    sources = [src("lesson", r["lesson_id"], f"{r['rddc']} lesson") for r in relevant]
    return {"mode": "relevant", "initiative_rddc": ini["rddc"] if ini else None, "lessons": [], "relevant_lessons": relevant,
            "estimate_accuracy": None, "tags": sorted(my_tags)[:10], "confidence": 0.75 if relevant else 0.6,
            "sources": sources or [src("lesson", "library", "Lessons learned library")],
            "warnings": [] if relevant else ["No closely related lessons found in the library."]}


def _lessons_draft(ctx: dict, variant: int) -> dict:
    b = ctx["bundle"]
    ini = b["initiative"]
    tasks = b.get("tasks", [])
    planned = float(ini.get("l2_baseline_hours") or ini.get("l2_hours") or sum(float(t.get("est_hours") or 0) for t in tasks))
    prn = b.get("prn") or {}
    actual = sum(float(c.get("charged_hours") or 0) for c in prn.get("charges", [])) or sum(float(t.get("est_hours") or 0) for t in tasks)
    variance = round((actual - planned) / planned * 100, 1) if planned else 0.0
    late = []
    for t in tasks:
        end = t.get("actual_end") or t.get("planned_end")
        if end and t.get("baseline_end") and end > t["baseline_end"]:
            late.append((C.business_days_from(t["baseline_end"], end), t))
    late.sort(key=lambda x: (-x[0], x[1]["wbs_code"]))
    lessons = []
    if abs(variance) > 10:
        lessons.append({"category": "Estimation", "kind": "improve",
                        "what_happened": f"Delivered at {fmt_hours(actual)} against {fmt_hours(planned)} planned ({variance:+.1f}%).",
                        "lesson": "The L2 estimate under-called effort for this component mix." if variance > 0 else "The L2 estimate was conservative for this component mix.",
                        "recommendation": "Use this initiative as a comparable when estimating similar component sets.",
                        "evidence": clip(f"PRN {prn.get('prn_code', '')} charged {fmt_hours(actual)}; L2 {fmt_hours(planned)}", 300)})
    else:
        lessons.append({"category": "Estimation", "kind": "went_well",
                        "what_happened": f"Delivered within {abs(variance):.1f}% of the {fmt_hours(planned)} estimate.",
                        "lesson": "Catalogue hours by complexity held for this component mix.",
                        "recommendation": "Keep the same complexity ratings for similar components.",
                        "evidence": clip(f"Charged {fmt_hours(actual)} vs L2 {fmt_hours(planned)}", 300)})
    for days, t in late[:3]:
        lessons.append({"category": "Schedule", "kind": "improve",
                        "what_happened": clip(f"{t['wbs_code']} {t['step']} finished {days} business days after baseline.", 600),
                        "lesson": clip(f"{t['phase']} work slipped and pushed dependants.", 400),
                        "recommendation": clip(f"Add buffer or earlier readiness checks before {t['phase']}.", 400),
                        "evidence": clip(f"Baseline end {fmt_date(t['baseline_end'])}, actual {fmt_date(t.get('actual_end') or t['planned_end'])}", 300)})
    for r in [r for r in b.get("risks", []) if r.get("status") == "Closed"][:2]:
        lessons.append({"category": r["category"], "kind": "went_well", "what_happened": clip(f"Risk {r['title']} was closed.", 600),
                        "lesson": clip(f"Mitigation worked: {r.get('mitigation') or 'actions completed'}", 400),
                        "recommendation": "Reuse the mitigation on similar initiatives.", "evidence": clip(r.get("risk_code") or r["title"], 300)})
    for d in (ctx["data"].get("decisions") or [])[:2]:
        lessons.append({"category": "Governance", "kind": "went_well", "what_happened": clip(d["decision"], 600),
                        "lesson": clip(f"Decision recorded: {d['title']}", 400), "recommendation": "Record decisions at the time they are made.",
                        "evidence": clip(f"Decision log {fmt_date(d.get('decided_on'))}", 300)})
    for cr in b.get("change_requests", []):
        if cr.get("implementation_status") == "Backed out" or "Failed" in (cr.get("tech_validation_status"), cr.get("biz_validation_status")):
            lessons.append({"category": "Release", "kind": "improve", "what_happened": clip(f"{cr.get('crq_number')} had a failed validation or backout.", 600),
                            "lesson": "Validation readiness was not proven before the window.", "recommendation": "Run a dress rehearsal in pre-production.",
                            "evidence": clip(cr.get("crq_number") or "CRQ", 300)})
    phases = sorted({t["phase"] for _, t in late[:5]})
    tags = sorted({c["code"].lower() for c in b.get("components", [])} | {str(x) for x in ini.get("labels") or []})[:10]
    return {"mode": "draft", "initiative_rddc": ini["rddc"], "lessons": lessons[:12], "relevant_lessons": [],
            "estimate_accuracy": {"planned_hours": round(planned, 1), "actual_hours": round(actual, 1),
                                  "variance_pct": max(min(variance, 1000.0), -100.0), "worst_phases": phases[:5]},
            "tags": [clip(t, 40) for t in tags], "confidence": 0.75,
            "sources": [src("initiative", ini["rddc"], f"{ini['rddc']} planned vs actual")], "warnings": []}


# ================================================================== F14 intake_autofill
def gen_intake_autofill(ctx: dict, variant: int = 0) -> dict:
    data = ctx["data"]
    text = data.get("text") or ""
    label = data.get("label") or "SA document"
    fields: dict[str, dict] = {}
    first_lines = [ln.strip() for ln in text.splitlines() if ln.strip()][:6]
    head = "\n".join(first_lines)

    def put(name, value, conf, source):
        if value not in (None, "") and name not in fields:
            fields[name] = {"value": value if isinstance(value, int) else clip(value, 1500 if name == "description" else 200),
                            "confidence": conf, "source": clip(source, 200)}

    if first_lines:
        first = first_lines[0].lstrip("#* ").strip()
        title = re.sub(r"^(solution architecture|sa document|solution design)\s*[:\-–]\s*", "", first, flags=re.IGNORECASE)
        if (title and title != first) or len(first) < 80:
            put("name", title.strip(), 0.9 if title != first else 0.6, "SA document title")
    patterns = {
        "sa_author": r"author\s*[:\-]\s*([A-Z][A-Za-z.'\- ]+?)(?:\s*\(|\s*[·|,\n]|$)",
        "sa_version": r"\bversion\s*[:\-]?\s*v?(\d+(?:\.\d+)*)",
        "prn_code": r"\b(PRN-\d{4,6})\b",
        "dc_intake": r"\b(DCI-\d{3,5})\b",
        "target_release": r"target release\s*[:\-]\s*(DC-\d{4})",
        "requestor": r"(?:requestor|business owner|sponsor)\s*[:\-]\s*([A-Z][A-Za-z.'\- ]+?)(?:\s*\(|\s*[·|,\n]|$)",
    }
    for name, pat in patterns.items():
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            put(name, m.group(1).strip(), 0.9, "SA §1 Document control" if m.start() < 600 else "SA document")
    m = re.search(r"\bLOB\s*[:\-]\s*([^\n·|]+)", text, re.IGNORECASE)
    if m:
        raw = m.group(1).strip().lower()
        lob = next((k for k, aliases in LOB_ALIASES.items() if any(raw.startswith(a) for a in aliases)), None)
        if lob:
            put("lob", lob, 0.9, "SA §1 Document control")
    m = re.search(r"\bpriority\s*[:\-]\s*P?([1-4])\b", text, re.IGNORECASE)
    if m:
        put("priority", int(m.group(1)), 0.8, "SA document")
    m = re.search(r"(?:go-live|go live|launch)\s*(?:date)?\s*[:\-]?\s*(20\d{2}-\d{2}-\d{2}|\d{1,2} [A-Za-z]{3}[a-z]* 20\d{2})", text, re.IGNORECASE)
    if m:
        raw = m.group(1)
        if not re.match(r"20\d{2}-", raw):
            day, mon, year = raw.split()
            try:
                raw = date(int(year), [x.lower() for x in MONTHS].index(mon[:3].lower()) + 1, int(day)).isoformat()
            except ValueError:
                raw = ""
        if raw:
            put("requested_go_live", raw, 0.8, "SA document")
    elif fields.get("target_release"):
        train = next((t for t in data.get("trains") or [] if t["code"] == fields["target_release"]["value"]), None)
        if train:
            put("requested_go_live", train["train_date"], 0.5, f"Release train {train['code']} date")
    if fields.get("dc_intake"):
        intake = next((i for i in data.get("intakes") or [] if i["code"] == fields["dc_intake"]["value"]), None)
        if intake:
            put("lob", intake.get("lob"), 0.95, f"DC Intake {intake['code']}")
            put("requestor", intake.get("requestor"), 0.95, f"DC Intake {intake['code']}")
            if intake.get("priority"):
                put("priority", int(intake["priority"]), 0.9, f"DC Intake {intake['code']}")
    author = (fields.get("sa_author") or {}).get("value")
    if author:
        person = next((p for p in data.get("people") or [] if p["name"].lower() == str(author).lower() and p.get("team") == "DC SA"), None)
        if person:
            put("dc_sa_name", person["name"], 0.85, "SA author is a DC Solution Architect")
    sections = split_sections(text)
    ctx_sec = find_section(sections, "business context", "background", "context", "overview")
    if ctx_sec:
        put("description", " ".join(sentences(ctx_sec["body"])[:2]), 0.75, f"SA {ctx_sec['heading']}")
    comps = likely_components(text, data.get("catalog") or [])
    likely = [c["component_code"] for c in comps if "Listed" in c["reason"]] or [c["component_code"] for c in comps[:4]]
    labels = []
    lob_val = (fields.get("lob") or {}).get("value")
    if lob_val in LOB_LABEL:
        labels.append(LOB_LABEL[lob_val])
    for pattern, lab in THEME_LABELS:
        if re.search(pattern, text.lower()) and lab not in labels:
            labels.append(lab)
    if labels:
        put("labels", ", ".join(labels[:6]), 0.6, "Themes in the SA document")
    warnings = [] if text else ["No document text to read."]
    if text and len(fields) < 4:
        warnings.append("Few intake details found; check the document control section.")
    conf = round(min(0.4 + 0.05 * len(fields), 0.9), 2)
    return {"fields": fields, "likely_components": likely[:12], "confidence": conf,
            "sources": [src("sa_doc", label, f"{label} §1 Document control", head[:300] or None)], "warnings": warnings}


# ================================================================== F15 assistant
def gen_assistant(ctx: dict, variant: int = 0) -> dict:
    from app.ai import assistant

    return assistant.answer(ctx["inputs"].get("message") or "", ctx, variant=variant)


GENERATORS = {
    "intake_analysis": gen_intake_analysis, "change_summary": gen_change_summary, "l2_estimate": gen_l2_estimate,
    "wbs": gen_wbs, "resources": gen_resources, "rebalance": gen_rebalance, "risks": gen_risks,
    "exec_summary": gen_exec_summary, "cr_compliance": gen_cr_compliance, "skill_matrix": gen_skill_matrix,
    "nudges": gen_nudges, "meeting_extract": gen_meeting_extract, "lessons": gen_lessons,
    "intake_autofill": gen_intake_autofill, "assistant": gen_assistant,
}


def generate(feature: str, ctx: dict, variant: int = 0) -> dict:
    return GENERATORS[feature](ctx, variant)
