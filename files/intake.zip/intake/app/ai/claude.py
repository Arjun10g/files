"""Live tier: Claude via the anthropic SDK with structured tool output.

Claude Opus 5.5 / Sonnet 5.5 reject a forced ``tool_choice`` and sampling parameters, so each call offers the
``emit_<feature>`` tool with ``tool_choice=auto`` and an explicit instruction to call it; the reply is then
validated in ``provider`` like every other tier. The client uses ``timeout`` <= 20 s and ``max_retries=0`` so the
server always answers within 22 s, falling back to the simulated tier on any failure.
"""
from __future__ import annotations

import json
import os
import time
from typing import Any

from app.ai import assistant, prompts
from app.ai.schemas import FEATURES, tool_definition
from app.config import load_config

MAX_TOKENS = 8000
ASSISTANT_TURNS = 6
REFUSAL_BETA = "server-side-fallback-2026-07-01"


class LiveError(Exception):
    """Any live-tier failure; the provider falls back to the simulated tier."""


def _config() -> dict:
    try:
        from flask import current_app, has_app_context
        if has_app_context():
            return current_app.config
    except ImportError:  # pragma: no cover
        pass
    return load_config().as_flask()


def api_key_present() -> bool:
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def model_for(feature: str) -> str:
    cfg = _config()
    tier = FEATURES[feature]["model_tier"]
    if tier == "heavy":
        return os.environ.get("BMO_AI_MODEL_HEAVY") or cfg.get("AI_MODEL_HEAVY") or "claude-opus-5-5"
    return os.environ.get("BMO_AI_MODEL_FAST") or cfg.get("AI_MODEL_FAST") or "claude-sonnet-5-5"


def _timeout() -> float:
    return float(min(int(_config().get("AI_TIMEOUT") or 20), 20))


def _client(timeout: float):
    try:
        import anthropic
    except ImportError as exc:  # pragma: no cover
        raise LiveError("anthropic SDK not installed") from exc
    try:
        return anthropic.Anthropic(timeout=timeout, max_retries=0)
    except Exception as exc:
        raise LiveError(f"client unavailable: {type(exc).__name__}") from exc


def _create(client, deadline: float, **kwargs):
    remaining = deadline - time.monotonic()
    if remaining < 2:
        raise LiveError("live time budget exhausted")
    try:
        resp = client.with_options(timeout=min(remaining, _timeout())).beta.messages.create(
            max_tokens=MAX_TOKENS, betas=[REFUSAL_BETA], fallbacks="default",
            output_config={"effort": "low"}, **kwargs)
    except Exception as exc:
        raise LiveError(f"{type(exc).__name__}: {str(exc)[:300]}") from exc
    if getattr(resp, "stop_reason", None) == "refusal":
        raise LiveError("request declined")
    return resp


def _tool_input(resp, name: str) -> dict | None:
    for block in resp.content or []:
        if getattr(block, "type", None) == "tool_use" and getattr(block, "name", None) == name:
            data = block.input
            try:
                parsed = json.loads(data) if isinstance(data, str) else dict(data)
            except (TypeError, ValueError) as exc:
                raise LiveError("structured answer could not be read") from exc
            if not isinstance(parsed, dict):
                raise LiveError("structured answer could not be read")
            return parsed
    return None


def _usage(resp) -> tuple[int, int]:
    u = getattr(resp, "usage", None)
    return int(getattr(u, "input_tokens", 0) or 0), int(getattr(u, "output_tokens", 0) or 0)


def run(feature: str, context: dict, engine: dict | None, instruction: str | None = None, budget_s: float = 20.0) -> dict:
    """One structured call. Returns {output, model, tokens_in, tokens_out}; raises LiveError."""
    deadline = time.monotonic() + min(budget_s, 20.0)
    model = model_for(feature)
    client = _client(_timeout())
    tool = tool_definition(feature)
    resp = _create(client, deadline, model=model, system=prompts.system_prompt(feature), tools=[tool],
                   tool_choice={"type": "auto"},
                   messages=[{"role": "user", "content": prompts.user_message(feature, context, engine, instruction)}])
    out = _tool_input(resp, tool["name"])
    if out is None:
        raise LiveError("no structured answer returned")
    tin, tout = _usage(resp)
    return {"output": out, "model": model, "tokens_in": tin, "tokens_out": tout}


def run_assistant(message: str, page_context: dict, budget_s: float = 20.0) -> dict:
    """Tool-use loop (at most 6 turns) over the assistant query tools, finishing with emit_assistant."""
    deadline = time.monotonic() + min(budget_s, 20.0)
    model = model_for("assistant")
    client = _client(_timeout())
    emit = tool_definition("assistant")
    query_tools = [{"name": name, "description": desc, "input_schema": schema}
                   for name, (_fn, desc, schema) in assistant.TOOLS.items()]
    system = prompts.system_prompt("assistant") + "\n" + prompts.TASKS["assistant"]
    messages: list[dict[str, Any]] = [{"role": "user", "content": (
        f"<context>{json.dumps(page_context, default=str)}</context>\n<question>{message.strip()[:1000]}</question>\n"
        "Use the tools, then call emit_assistant with the final answer.")}]
    tin = tout = 0
    tool_log: list[dict] = []
    for turn in range(ASSISTANT_TURNS):
        if turn == ASSISTANT_TURNS - 1:
            prior = messages[-1]["content"]
            prior = [{"type": "text", "text": prior}] if isinstance(prior, str) else list(prior)
            messages[-1]["content"] = prior + [
                {"type": "text", "text": "This is the last turn: call emit_assistant now."}]
        resp = _create(client, deadline, model=model, system=system, tools=query_tools + [emit],
                       tool_choice={"type": "auto"}, messages=messages)
        a, b = _usage(resp)
        tin, tout = tin + a, tout + b
        final = _tool_input(resp, "emit_assistant")
        if final is not None:
            return {"output": final, "model": model, "tokens_in": tin, "tokens_out": tout, "tool_log": tool_log}
        calls = [blk for blk in resp.content or [] if getattr(blk, "type", None) == "tool_use"]
        if not calls:
            messages.append({"role": "assistant", "content": resp.content})
            messages.append({"role": "user", "content": "Call emit_assistant now with your final answer."})
            continue
        messages.append({"role": "assistant", "content": resp.content})
        results = []
        for call in calls:
            args = call.input if isinstance(call.input, dict) else {}
            try:
                data = assistant.run_tool(call.name, args)
                content, is_error = json.dumps(data, default=str)[:20000], False
            except Exception as exc:  # noqa: BLE001 - tool errors go back to the model, not the user
                content, is_error = f"Tool failed: {type(exc).__name__}", True
            tool_log.append({"tool": call.name, "input": args})
            results.append({"type": "tool_result", "tool_use_id": call.id, "content": content, "is_error": is_error})
        messages.append({"role": "user", "content": results})
    raise LiveError("assistant did not finish within the turn limit")
