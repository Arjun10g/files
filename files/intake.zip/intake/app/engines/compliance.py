"""Change request (CRQ) compliance: PO §5 governance rules merged with the AI Lead's CR-01..CR-09.

Every rule returns Pass, Fail or Warn with a user-facing message and a fix. Fail and Warn findings become flags.
A flag is "blocking" when it should hold the STO decision at Tentative No Go.
"""
from __future__ import annotations

from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from app.engines import calendar as cal

RULES = {
    "sto_go_by_bd": 2,                       # STO must be Go by T-2 business days
    "approval_by_bd": 2,                     # CRQ approval must be Approved by T-2 business days
    "lead_time_bd": {"Bundle": 10, "Independent": 5},
    "max_window_hours": 8,
    "validation_grace_hours": 24,            # evidence due 24 h after Implemented
    "backout_blocking_bd": 5,                # missing backout plan blocks from T-5 business days
    "sto_decision_bd": 5,                    # from T-5 the STO suggestion needs every flag clear (PO §5)
    "window": {"start": "02:00", "end": "06:00"},  # standard Saturday train window
    "timezone": "America/Toronto",
}

RULE_TEXT = {
    "CR-01": "STO approval is Go by 2 business days before the CRQ start",
    "CR-02": "CRQ approval is Approved by 2 business days before the CRQ start",
    "CR-03": "Affected CIs and impacted components are listed",
    "CR-04": "Technical validation evidence is attached and not failed",
    "CR-05": "Business validation evidence is attached and not failed",
    "CR-06": "Change window is outside the change freeze and no longer than 8 hours",
    "CR-07": "CMS Lead and Rel Lead are named",
    "CR-08": "Release type is set and a Bundle release names its release train",
    "CR-09": "Implementation status matches the change window dates",
    "CR-10": "CRQ raised at least 10 business days (Bundle) or 5 (Independent) before the start",
    "CR-11": "Backout plan is attached",
    "CR-12": "Bundle CRQ window is on the plan's production date (WBS-700)",
    "CR-13": "Production date is on or before the target release train (Bundle CRQs)",
}


def _dt(value) -> datetime | None:
    if not value:
        return None
    text = str(value)
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    if len(text) == 10:
        dt = datetime.combine(dt.date(), time(0, 0))
    return dt


def _naive(dt: datetime | None) -> datetime | None:
    """Toronto wall-clock time: offsets are converted (a UTC window is judged in ET), never just dropped."""
    return cal.local_naive(dt)


def _list(value) -> list:
    if value is None:
        return []
    if isinstance(value, str):
        return [v.strip() for v in value.split(",") if v.strip()]
    return [v for v in value if v]


CHECKED = ("Pass", "Fail", "Warn")
NOT_DUE = "Not due yet"


def _finding(rule_id, status, detail, fix=None, field=None, blocking=False, due_date=None) -> dict:
    out = {"rule_id": rule_id, "rule": RULE_TEXT[rule_id], "status": status, "field": field, "detail": detail,
           "fix": fix if status in ("Fail", "Warn") else None,
           "blocking": bool(blocking and status in ("Fail", "Warn"))}
    if status == NOT_DUE:
        out["due_date"] = cal.iso(due_date) if due_date else None
        out["reason"] = detail
    return out


def _not_due(rule_id, due, what, field) -> dict:
    """A rule whose deadline has not arrived: grey "Not due yet" with the date, excluded from the score."""
    text = f"Due by {cal.fmt_day_long(due)} ({what})." if due else f"Due {what}."
    return _finding(rule_id, NOT_DUE, text, field=field, due_date=due)


def _plan_facts(context: dict) -> tuple:
    """(production date, target train) from explicit context keys, else from a bundle in the context."""
    prod = context.get("plan_prod_date")
    train = context.get("target_train")
    bundle = context.get("bundle") or {}
    if prod is None and bundle:
        rows = [t for t in bundle.get("tasks") or [] if t.get("is_milestone") and t.get("planned_start")]
        rows.sort(key=lambda t: (t.get("phase") != "Production", t["planned_start"]))
        prod = rows[0]["planned_start"] if rows else (bundle.get("initiative") or {}).get("prod_date")
    if train is None and bundle:
        train = bundle.get("target_train")
    return cal.to_date(prod), (train or {})


def check_cr(cr: dict, today, context: dict | None = None) -> dict:
    """{ok, flags:[{code, rule, message, fix, field, blocking}], findings:[...all rules...], score,
        sto_suggestion, sto_readiness} for one change_requests row.

    context (optional): {now: ISO datetime, plan_prod_date: WBS-700 date, target_train: {code, train_date}} or
    {bundle: initiative bundle} (plan facts are read from its WBS-700 row and target train). Attachment ids on the
    row decide whether evidence exists. Each finding is Pass, Fail, Warn or "Not due yet" (with due_date and reason);
    only Fail and Warn become flags. Callers with database access should use derive.compliance_for(cr).
    """
    context = context or {}
    today = cal.to_date(today)
    now = _naive(_dt(context.get("now"))) or datetime.combine(today, time(9, 30))
    start_dt, end_dt = _naive(_dt(cr.get("crq_start"))), _naive(_dt(cr.get("crq_end")))
    start = start_dt.date() if start_dt else None
    bd_to_start = cal.business_days_after(today, start) if start else None
    near = bd_to_start is not None and bd_to_start <= RULES["sto_go_by_bd"]
    # T-2: the business day from which only 2 business days remain before the window (Wed 17 Feb for Sat 20 Feb).
    t_minus_2 = (cal.add_business_days(cal.prev_business_day(start, include_self=True), -RULES["sto_go_by_bd"])
                 if start else None)
    # QA-B-09 ruling: "Due by <date>" is inclusive, so STO / CRQ approval fail only from the day after T-2.
    near = t_minus_2 is not None and today > t_minus_2
    findings = []

    sto = cr.get("sto_approval")
    if sto == "No-Go":
        findings.append(_finding("CR-01", "Fail", "STO decision is No-Go.", "Resolve the STO concerns and request "
                                 "a new decision, or move the change to a later train.", "sto_approval", True))
    elif sto != "Go" and near:
        findings.append(_finding("CR-01", "Fail", f"STO approval is {sto or 'not set'} with the change "
                                 f"{'under way or past' if bd_to_start < 0 else f'{bd_to_start} business days away'}.",
                                 "Ask the STO for a Go decision before the window.", "sto_approval", True))
    elif sto == "Go":
        findings.append(_finding("CR-01", "Pass", "STO approval is Go."))
    else:
        findings.append(_not_due("CR-01", t_minus_2, "T-2 business days", "sto_approval"))

    appr = cr.get("crq_approval_status")
    if appr == "Rejected":
        findings.append(_finding("CR-02", "Fail", "CRQ approval was rejected.", "Address the CAB comments and "
                                 "resubmit the CRQ.", "crq_approval_status", True))
    elif appr != "Approved" and near:
        findings.append(_finding("CR-02", "Fail", f"CRQ approval is {appr or 'Draft'} close to the window.",
                                 "Get CAB approval before the change window.", "crq_approval_status", True))
    elif appr == "Approved":
        findings.append(_finding("CR-02", "Pass", "CRQ approval is Approved."))
    else:
        findings.append(_not_due("CR-02", t_minus_2, "T-2 business days", "crq_approval_status"))

    cis, comps = _list(cr.get("affected_cis")), _list(cr.get("impacted_components"))
    if not cis or not comps:
        missing = " and ".join(x for x, v in (("Affected CIs", cis), ("Impacted components", comps)) if not v)
        findings.append(_finding("CR-03", "Fail", f"{missing} empty.", "List the configuration items and DC "
                                 "components this change touches.", "affected_cis" if not cis else
                                 "impacted_components", True))
    else:
        findings.append(_finding("CR-03", "Pass", f"{len(cis)} CI{'s' if len(cis) != 1 else ''} and "
                                 f"{len(comps)} component{'s' if len(comps) != 1 else ''} listed."))

    implemented_at = _naive(_dt(cr.get("implemented_at")))
    grace_over = (cr.get("implementation_status") == "Implemented" and implemented_at is not None
                  and now > implemented_at + timedelta(hours=RULES["validation_grace_hours"]))
    for rule_id, key, label in (("CR-04", "tech", "Technical"), ("CR-05", "biz", "Business")):
        status = cr.get(f"{key}_validation_status") or "Not Started"
        has_file = bool(cr.get(f"{key}_validation_attachment_id"))
        field = f"{key}_validation_status"
        if status == "Failed":
            findings.append(_finding(rule_id, "Fail", f"{label} validation failed.",
                                     f"Fix the {label.lower()} validation issues and re-test before Go.", field, True))
        elif status == "Completed" and not has_file:
            findings.append(_finding(rule_id, "Fail", f"{label} validation is Completed but no evidence is attached.",
                                     f"Attach the {label.lower()} validation evidence on Pg 4.",
                                     f"{key}_validation_attachment_id", False))
        elif grace_over and (status != "Completed" or not has_file):
            findings.append(_finding(rule_id, "Fail", f"{label} validation evidence missing more than 24 h after "
                                     "implementation.", f"Complete {label.lower()} validation and attach the "
                                     "evidence.", field, True))
        elif status == "Completed":
            findings.append(_finding(rule_id, "Pass", f"{label} validation is Completed with evidence attached."))
        else:
            due = (implemented_at.date() if implemented_at else (end_dt.date() if end_dt else None))
            due = due + timedelta(days=1) if due else None
            findings.append(_not_due(rule_id, due, "24 h after implementation", field))

    # The window end is exclusive: a window ending at 00:00 on the first freeze day stays outside the freeze.
    end_day = (end_dt - timedelta(microseconds=1)).date() if end_dt and start_dt and end_dt > start_dt else None
    in_frz = bool(start and (cal.in_freeze(start) or (end_day and cal.in_freeze(end_day))))
    hours = (end_dt - start_dt).total_seconds() / 3600 if start_dt and end_dt else None
    if in_frz:
        findings.append(_finding("CR-06", "Fail", f"Change window {cal.fmt_date(start)} falls in the change freeze "
                                 f"({cal.fmt_date(cal.FREEZE_START)} – {cal.fmt_date(cal.FREEZE_END)}).",
                                 "Move the change to a release train outside the freeze.", "crq_start", True))
    elif hours is not None and (hours <= 0 or hours > RULES["max_window_hours"]):
        findings.append(_finding("CR-06", "Fail", f"Change window is {hours:.1f} hours long.",
                                 "Keep the window between the start and end within 8 hours.", "crq_end", False))
    elif not start_dt:
        findings.append(_finding("CR-06", "Fail", "Change window start is not set.",
                                 "Set the CRQ start and end date and time.", "crq_start", True))
    else:
        findings.append(_finding("CR-06", "Pass", "Window is outside the freeze and within 8 hours."))

    leads = [x for x, k in (("CMS Lead", "cms_lead_id"), ("Rel Lead", "rel_lead_id")) if not cr.get(k)]
    if leads:
        findings.append(_finding("CR-07", "Fail", f"{' and '.join(leads)} not named.",
                                 f"Name the {' and '.join(leads)} on Pg 4.", "cms_lead_id" if "CMS Lead" in leads
                                 else "rel_lead_id", False))
    else:
        findings.append(_finding("CR-07", "Pass", "CMS Lead and Rel Lead are named."))

    rtype = cr.get("release_type")
    if not rtype:
        findings.append(_finding("CR-08", "Fail", "Release type not set.", "Choose Bundle or Independent.",
                                 "release_type", False))
    elif rtype == "Bundle" and not cr.get("release_train"):
        findings.append(_finding("CR-08", "Fail", "Bundle release has no release train.",
                                 "Pick the release train for this bundle.", "release_train", True))
    else:
        findings.append(_finding("CR-08", "Pass", f"{rtype} release" + (f" on {cr['release_train']}"
                                                                         if cr.get("release_train") else "") + "."))

    impl = cr.get("implementation_status") or "Not Started"
    if end_dt and now > end_dt and impl not in ("Implemented", "Backed out"):
        findings.append(_finding("CR-09", "Warn", f"Window ended {cal.fmt_date(end_dt)} but status is {impl}.",
                                 "Update the implementation status.", "implementation_status", False))
    elif impl == "Implemented" and start_dt and now < start_dt:
        findings.append(_finding("CR-09", "Warn", "Marked Implemented before the window starts.",
                                 "Check the implementation status and window dates.", "implementation_status", False))
    else:
        findings.append(_finding("CR-09", "Pass", f"Implementation status {impl} matches the dates."))

    raised = cal.to_date(cr.get("raised_at") or cr.get("created_at"))
    need = RULES["lead_time_bd"].get(rtype or "Bundle", RULES["lead_time_bd"]["Bundle"])
    if start and raised:
        lead = cal.business_days_after(raised, start)
        if lead < need:
            findings.append(_finding("CR-10", "Fail", f"Raised {lead} business days before the window; "
                                     f"{rtype or 'Bundle'} changes need {need}.", "Raise CRQs earlier, or get "
                                     "an exception approved by CAB.", "raised_at", False))
        else:
            findings.append(_finding("CR-10", "Pass", f"Raised {lead} business days ahead."))
    else:
        findings.append(_finding("CR-10", "Pass", "Lead time not measurable yet."))

    if not cr.get("backout_attachment_id"):
        blocking = bd_to_start is not None and bd_to_start <= RULES["backout_blocking_bd"]
        findings.append(_finding("CR-11", "Fail", "Backout plan not attached.",
                                 "Attach the backout plan on Pg 4.", "backout_attachment_id", blocking))
    else:
        findings.append(_finding("CR-11", "Pass", "Backout plan attached."))

    # CR-12/CR-13 judge the production release change only; Independent CRQs (pre-staging, config) are exempt.
    plan_prod, target = _plan_facts(context)
    if rtype != "Bundle":
        plan_prod = None
    if plan_prod and start and start != plan_prod:
        findings.append(_finding("CR-12", "Fail", f"CRQ window doesn't match the plan's production date "
                                 f"({cal.fmt_day_long(plan_prod)}).", "Move the CRQ window to the production date, "
                                 "or re-plan WBS-700.", "crq_start", True))
    elif plan_prod and start:
        findings.append(_finding("CR-12", "Pass", f"Window matches WBS-700 on {cal.fmt_day_long(plan_prod)}."))
    else:
        findings.append(_finding("CR-12", "Pass", "No production date in the plan yet." if rtype == "Bundle"
                                 else "Independent change; not tied to the production date."))

    target_day = cal.to_date(target.get("train_date"))
    if plan_prod and target_day and plan_prod > target_day:
        findings.append(_finding("CR-13", "Fail", f"Production date is after target release {target.get('code')} "
                                 f"({cal.fmt_day_long(plan_prod)} vs {cal.fmt_day_long(target_day)}).",
                                 "Recover the schedule or move the target release on Pg 1.", "target_release", True))
    else:
        findings.append(_finding("CR-13", "Pass", "Production is on or before the target release."
                                 if plan_prod and target_day else "Target release or production date not set."))

    flags = [{"code": f["rule_id"], "rule": f["rule"], "message": f["detail"] if f["rule_id"] != "CR-11"
              else "Backout plan not attached", "fix": f["fix"], "field": f["field"], "blocking": f["blocking"],
              "status": f["status"]}
             for f in findings if f["status"] in ("Fail", "Warn")]
    blocking = any(f["blocking"] for f in flags)
    decision_window = bd_to_start is not None and bd_to_start <= RULES["sto_decision_bd"]
    hold = blocking or (decision_window and bool(flags))
    passed = sum(1 for f in findings if f["status"] == "Pass")
    checked = sum(1 for f in findings if f["status"] in CHECKED)
    not_due = sum(1 for f in findings if f["status"] == NOT_DUE)
    if decision_window:
        suggestion = "Tentative No Go" if hold else "Tentative Go"
    else:
        suggestion = None  # decision 2: the STO suggestion starts at T-5; a fresh draft shows "Not requested"
    readiness = _sto_readiness(cr, start, decision_window, hold, flags, not_due, suggestion)
    return {
        "ok": not flags,
        "flags": flags,
        "findings": findings,
        # Score = passes ÷ (passes + fails + warns); "Not due yet" rules are excluded.
        "score": round(passed / checked * 100) if checked else 100,
        "passed": passed,
        "checked": checked,
        "not_due": not_due,
        "sto_suggestion": suggestion,
        # `sto_readiness` stays the plain status string existing callers expect ("Not requested", "Tentative",
        # "Not ready", "Ready for Go"); `sto_readiness_detail` adds suggest_from and the display label.
        "sto_readiness": readiness["status"],
        "sto_readiness_detail": readiness,
        "as_of": today.isoformat(),
    }


def _sto_readiness(cr, start, decision_window, hold, flags, not_due, suggestion) -> dict:
    """{status, suggest_from, label}. An STO decision nobody has asked for yet reads "Not requested" until T-5
    business days, never "Tentative" next to an empty STO field (Director round 3, N4)."""
    suggest_from = None
    if start:
        # T-5: the first day with only 5 business days left before the window (holidays skipped).
        suggest_from = cal.add_business_days(cal.prev_business_day(start, include_self=True),
                                             -RULES["sto_decision_bd"])
    if not cr.get("sto_approval") and not decision_window:
        when = f" ({cal.fmt_day_long(suggest_from)})" if suggest_from else ""
        return {"status": "Not requested", "suggest_from": cal.iso(suggest_from),
                "label": f"Not requested · auto-suggest from T-5 business days{when}"}
    if hold:
        status = "Not ready"
    elif flags or not_due:
        status = "Tentative"
    else:
        status = "Ready for Go"
    label = status
    if not cr.get("sto_approval") and suggestion:
        label = f"{status} · suggested {suggestion}"
    return {"status": status, "suggest_from": cal.iso(suggest_from), "label": label}


def crq_window(train_date) -> tuple[str, str]:
    """Standard Saturday train window, 02:00–06:00 Toronto time, as ISO datetimes with offset."""
    d = cal.to_date(train_date)
    try:
        tz = ZoneInfo(RULES["timezone"])
    except ZoneInfoNotFoundError:  # pragma: no cover - tz database missing
        tz = None
    sh, sm = (int(x) for x in RULES["window"]["start"].split(":"))
    eh, em = (int(x) for x in RULES["window"]["end"].split(":"))
    start = datetime.combine(d, time(sh, sm), tzinfo=tz)
    end = datetime.combine(d, time(eh, em), tzinfo=tz)
    return start.isoformat(), end.isoformat()
