"""Grooming slotter: Tue/Thu 10:00 sessions, cut-off 17:00 the prior business day, max 6 per session, P1 first."""
from __future__ import annotations

from datetime import date, datetime, time, timedelta

from app.engines import calendar as cal

RULES = {
    "weekdays": (1, 3),            # Tuesday, Thursday
    "start_time": "10:00",
    "cutoff_time": "17:00",        # on the business day before the session
    "capacity": 6,
    "horizon_weeks": 12,
    "candidate_stages": ("Intake", "Grooming"),
    "open_statuses": ("Scheduled",),
}


def _hm(text: str) -> time:
    hh, mm = (int(x) for x in str(text).split(":")[:2])
    return time(hh, mm)


def _wall(now) -> datetime:
    """Toronto wall-clock datetime without tzinfo; aware datetimes are converted, not just stripped."""
    if isinstance(now, str):
        now = datetime.fromisoformat(now)
    if isinstance(now, date) and not isinstance(now, datetime):
        now = datetime.combine(now, time(9, 30))
    return cal.local_naive(now)


def cutoff(session_date) -> datetime:
    """Latest moment an intake can still join a session: 17:00 on the prior business day."""
    prior = cal.prev_business_day(session_date)
    return datetime.combine(prior, _hm(RULES["cutoff_time"]))


def is_eligible(session_date, now) -> bool:
    return _wall(now) < cutoff(session_date)


def session_dates(start, weeks: int | None = None) -> list[date]:
    """Tue/Thu business days from `start` (inclusive) for `weeks` weeks."""
    d = cal.to_date(start)
    end = d + timedelta(weeks=weeks or RULES["horizon_weeks"])
    out = []
    while d <= end:
        if d.weekday() in RULES["weekdays"] and cal.is_business_day(d):
            out.append(d)
        d += timedelta(days=1)
    return out


def next_session_date(now) -> date:
    for d in session_dates(_wall(now).date()):
        if is_eligible(d, now):
            return d
    raise ValueError("No grooming session in the planning horizon.")


def label(session_date, start_time: str | None = None) -> str:
    """'Tue 20 Oct, 10:00'"""
    return f"{cal.fmt_day(session_date)}, {start_time or RULES['start_time']}"


def _calendar(sessions, now) -> list[dict]:
    """Existing open sessions plus generated Tue/Thu dates, all eligible for `now`, in date order."""
    by_date, taken = {}, set()
    for s in sessions or []:
        key = (str(s["session_date"])[:10], s.get("start_time") or RULES["start_time"])
        taken.add(key)
        if s.get("status", "Scheduled") not in RULES["open_statuses"]:
            continue
        by_date[key] = {
            "session_id": s.get("id"),
            "session_date": key[0],
            "start_time": key[1],
            "capacity": int(s.get("capacity") or RULES["capacity"]),
            "slots": [dict(x) for x in (s.get("slots") or [])],
        }
    for d in session_dates(_wall(now).date()):
        key = (d.isoformat(), RULES["start_time"])
        if key in taken:
            continue
        by_date.setdefault(key, {"session_id": None, "session_date": key[0], "start_time": key[1],
                                 "capacity": RULES["capacity"], "slots": []})
    out = [s for s in by_date.values() if is_eligible(s["session_date"], now)]
    out.sort(key=lambda s: (s["session_date"], s["start_time"]))
    return out


def _sort_key(item) -> tuple:
    return (int(item.get("priority") or 4), str(item.get("submitted_at") or item.get("created_at") or ""),
            int(item.get("initiative_id") or item.get("id") or 0))


def slot_one(initiative: dict, sessions, now) -> dict:
    """Where one newly saved intake goes.

    Returns {session_id|None, session_date, start_time, label, slot_order, bumped|None}. A P1 intake that finds the
    earliest session full takes the place of the lowest-priority proposed slot, which moves to the next free session.
    """
    cal_sessions = _calendar(sessions, now)
    if not cal_sessions:
        raise ValueError("No grooming session in the planning horizon.")
    prio = int(initiative.get("priority") or 4)
    for i, s in enumerate(cal_sessions):
        if len(s["slots"]) < s["capacity"]:
            return _placement(s, len(s["slots"]) + 1, None)
        if prio == 1 and i == 0:
            movable = [x for x in s["slots"] if x.get("status", "Proposed") == "Proposed"
                       and int(x.get("priority") or 4) > 1]
            if movable:
                victim = max(movable, key=_sort_key)
                target = next((t for t in cal_sessions[1:] if len(t["slots"]) < t["capacity"]), None)
                if target is not None:
                    bumped = {"initiative_id": victim.get("initiative_id"), "to_session_id": target["session_id"],
                              "to_session_date": target["session_date"], "to_start_time": target["start_time"],
                              "to_slot_order": len(target["slots"]) + 1}
                    return _placement(s, int(victim.get("slot_order") or s["capacity"]), bumped)
    raise ValueError("Every grooming session in the planning horizon is full.")


def _placement(s: dict, order: int, bumped) -> dict:
    return {"session_id": s["session_id"], "session_date": s["session_date"], "start_time": s["start_time"],
            "label": label(s["session_date"], s["start_time"]), "slot_order": order, "bumped": bumped}


def auto_slot(candidates, sessions, now) -> dict:
    """Slot every unslotted intake: P1 first, then by submitted time, earliest eligible session with room.

    candidates: [{initiative_id, rddc, priority, submitted_at}]; sessions: existing rows with their slots.
    Returns {assignments:[{session_id|None, session_date, start_time, label, initiative_id, rddc, slot_order}],
             unslotted:[{initiative_id, rddc, reason}]}.
    """
    cal_sessions = _calendar(sessions, now)
    assignments, unslotted = [], []
    for c in sorted(candidates, key=_sort_key):
        target = next((s for s in cal_sessions if len(s["slots"]) < s["capacity"]), None)
        if target is None:
            unslotted.append({"initiative_id": c.get("initiative_id"), "rddc": c.get("rddc"),
                              "reason": f"Every session in the next {RULES['horizon_weeks']} weeks is full"})
            continue
        target["slots"].append({"initiative_id": c.get("initiative_id"), "priority": c.get("priority")})
        assignments.append({
            "session_id": target["session_id"], "session_date": target["session_date"],
            "start_time": target["start_time"], "label": label(target["session_date"], target["start_time"]),
            "initiative_id": c.get("initiative_id"), "rddc": c.get("rddc"), "priority": c.get("priority"),
            "slot_order": len(target["slots"]),
        })
    return {"assignments": assignments, "unslotted": unslotted}
