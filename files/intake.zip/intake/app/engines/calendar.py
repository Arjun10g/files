"""BMO delivery calendar: business days, stat holidays, change freeze, release trains, fiscal quarters.

This is the only module that knows which days are working days. Everything else asks it.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

RULES = {
    "workdays": (0, 1, 2, 3, 4),  # Mon–Fri
    "holidays": ("2026-11-11", "2026-12-25", "2026-12-28", "2027-01-01", "2027-02-15"),
    "freeze": {"start": "2026-12-14", "end": "2027-01-08"},
    "release_trains": (
        ("DC-2610", "2026-10-17"),
        ("DC-2611", "2026-11-21"),
        ("DC-2612", "2026-12-12"),
        ("DC-2701", "2027-01-16"),
        ("DC-2702", "2027-02-20"),
        ("DC-2703", "2027-03-20"),
    ),
    "fy_start_month": 11,
    "quarter_labels": {"Q1": "Nov–Jan", "Q2": "Feb–Apr", "Q3": "May–Jul", "Q4": "Aug–Oct"},
    "hours_per_day": 7.0,
    "timezone": "America/Toronto",
}

HOLIDAYS = frozenset(date.fromisoformat(d) for d in RULES["holidays"])
FREEZE_START = date.fromisoformat(RULES["freeze"]["start"])
FREEZE_END = date.fromisoformat(RULES["freeze"]["end"])
RELEASE_TRAINS = tuple((code, date.fromisoformat(d)) for code, d in RULES["release_trains"])
MONTH_ABBR = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
DAY_ABBR = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")


# ------------------------------------------------------------------ parsing
def to_date(value) -> date | None:
    """Accept a date, datetime or 'YYYY-MM-DD…' string; None stays None."""
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value)[:10])


def local_naive(dt: datetime | None) -> datetime | None:
    """Wall-clock time in Toronto without tzinfo. Aware datetimes are converted first; naive ones are taken as
    Toronto time already."""
    if dt is None:
        return None
    if dt.tzinfo is not None:
        dt = dt.astimezone(ZoneInfo(RULES["timezone"]))
    return dt.replace(tzinfo=None)


def iso(value) -> str | None:
    d = to_date(value)
    return d.isoformat() if d else None


# ------------------------------------------------------------------ business days
def is_business_day(d) -> bool:
    d = to_date(d)
    return d.weekday() in RULES["workdays"] and d not in HOLIDAYS


def is_holiday(d) -> bool:
    return to_date(d) in HOLIDAYS


def next_business_day(d, include_self: bool = False) -> date:
    d = to_date(d)
    if not include_self:
        d += timedelta(days=1)
    while not is_business_day(d):
        d += timedelta(days=1)
    return d


def prev_business_day(d, include_self: bool = False) -> date:
    d = to_date(d)
    if not include_self:
        d -= timedelta(days=1)
    while not is_business_day(d):
        d -= timedelta(days=1)
    return d


def add_business_days(d, n: int) -> date:
    """Move n business days forward (n>0) or back (n<0). n == 0 rolls forward to a business day."""
    d = to_date(d)
    if n == 0:
        return next_business_day(d, include_self=True)
    step = 1 if n > 0 else -1
    remaining = abs(n)
    while remaining:
        d += timedelta(days=step)
        if is_business_day(d):
            remaining -= 1
    return d


def business_days(start, end) -> list[date]:
    """Business days in [start, end], both inclusive."""
    a, b = to_date(start), to_date(end)
    out = []
    while a <= b:
        if is_business_day(a):
            out.append(a)
        a += timedelta(days=1)
    return out


def count_business_days(start, end) -> int:
    """Number of business days in [start, end], inclusive. 0 when end < start."""
    a, b = to_date(start), to_date(end)
    if b < a:
        return 0
    return len(business_days(a, b))


def business_days_after(a, b) -> int:
    """Business days in (a, b]: how many working days from a until b. Negative when b < a."""
    a, b = to_date(a), to_date(b)
    if b >= a:
        return count_business_days(a + timedelta(days=1), b)
    return -count_business_days(b + timedelta(days=1), a)


def business_days_strictly_between(a, b) -> int:
    """Business days strictly between a and b (exclusive both ends). 0 when b <= a + 1 day."""
    a, b = to_date(a), to_date(b)
    if b <= a:
        return 0
    return count_business_days(a + timedelta(days=1), b - timedelta(days=1))


def end_after_business_days(start, n: int) -> date:
    """Last day of a task that starts on `start` (rolled to a business day) and lasts n business days."""
    first = next_business_day(start, include_self=True)
    return add_business_days(first, max(n, 1) - 1)


# ------------------------------------------------------------------ months & fiscal
def month_key(d) -> str:
    d = to_date(d)
    return f"{d.year:04d}-{d.month:02d}"


def parse_month(month: str) -> tuple[int, int]:
    y, m = str(month)[:7].split("-")
    return int(y), int(m)


def add_months(month: str, n: int) -> str:
    y, m = parse_month(month)
    total = y * 12 + (m - 1) + n
    return f"{total // 12:04d}-{total % 12 + 1:02d}"


def month_range(start_month: str, end_month: str) -> list[str]:
    """Inclusive list of 'YYYY-MM' from start to end."""
    out = []
    cur = str(start_month)[:7]
    end = str(end_month)[:7]
    while cur <= end:
        out.append(cur)
        cur = add_months(cur, 1)
    return out


def month_label(month: str) -> str:
    y, m = parse_month(month)
    return f"{MONTH_ABBR[m - 1]} {y}"


def month_first_day(month: str) -> date:
    y, m = parse_month(month)
    return date(y, m, 1)


def month_last_day(month: str) -> date:
    return month_first_day(add_months(month, 1)) - timedelta(days=1)


def fiscal_year(d) -> str:
    """BMO fiscal year label: FY starts 1 Nov, so 2026-11-01 is FY27 and 2026-10-31 is FY26."""
    y, m = parse_month(d if isinstance(d, str) and len(d) == 7 else month_key(d))
    fy = y + 1 if m >= RULES["fy_start_month"] else y
    return f"FY{fy % 100:02d}"


def _fy_number(fy: str) -> int:
    return 2000 + int(str(fy).upper().replace("FY", ""))


def fiscal_quarter(value) -> dict:
    """{fy:'FY27', q:'Q1', label:'Nov–Jan', months:[...]} for a date or a 'YYYY-MM' month."""
    month = value if isinstance(value, str) and len(value) == 7 else month_key(value)
    _y, m = parse_month(month)
    offset = (m - RULES["fy_start_month"]) % 12  # 0 = Nov
    q = f"Q{offset // 3 + 1}"
    fy = fiscal_year(month)
    return quarter(fy, q)


def quarter(fy: str, q: str) -> dict:
    fy_num = _fy_number(fy)
    first = f"{fy_num - 1:04d}-{RULES['fy_start_month']:02d}"
    idx = int(q[1]) - 1
    start = add_months(first, idx * 3)
    fy_label = f"FY{fy_num % 100:02d}"
    return {
        "fy": fy_label,
        "q": q,
        "label": RULES["quarter_labels"][q],
        "short": f"{q} {fy_label}",
        "months": month_range(start, add_months(start, 2)),
    }


def fiscal_quarters(fy: str) -> list[dict]:
    return [quarter(fy, f"Q{i}") for i in range(1, 5)]


def quarter_key(qobj: dict) -> str:
    return f"{qobj['fy']}-{qobj['q']}"


def quarter_short(qobj: dict) -> str:
    """'Q4 FY26' — the label used on heatmaps and capacity columns."""
    return f"{qobj['q']} {qobj['fy']}"


# ------------------------------------------------------------------ freeze & trains
def in_freeze(d) -> bool:
    d = to_date(d)
    return FREEZE_START <= d <= FREEZE_END


def freeze_window() -> dict:
    return {"start": FREEZE_START.isoformat(), "end": FREEZE_END.isoformat()}


def holidays() -> list[str]:
    return sorted(d.isoformat() for d in HOLIDAYS)


def release_trains(today=None) -> list[dict]:
    t = to_date(today)
    return [
        {
            "code": code,
            "train_date": d.isoformat(),
            "status": "Done" if t is not None and d < t else "Planned",
            "in_freeze": in_freeze(d),
        }
        for code, d in RELEASE_TRAINS
    ]


def train_date(code: str, trains=None) -> date | None:
    for c, d in _trains(trains):
        if c == code:
            return d
    return None


def _trains(trains=None) -> list[tuple[str, date]]:
    if trains is None:
        return list(RELEASE_TRAINS)
    out = []
    for t in trains:
        if isinstance(t, dict):
            out.append((t["code"], to_date(t["train_date"])))
        else:
            out.append((t[0], to_date(t[1])))
    return sorted(out, key=lambda x: x[1])


def next_train_after(d, trains=None, *, allow_freeze: bool = False) -> tuple[str, date] | None:
    """First release train strictly after `d` whose date is outside the change freeze."""
    d = to_date(d)
    for code, td in _trains(trains):
        if td > d and (allow_freeze or not in_freeze(td)):
            return code, td
    return None


def train_for_date(d, trains=None) -> tuple[str, date] | None:
    d = to_date(d)
    for code, td in _trains(trains):
        if td == d:
            return code, td
    return None


# ------------------------------------------------------------------ weeks
def week_monday(d) -> date:
    d = to_date(d)
    return d - timedelta(days=d.weekday())


def iso_week(d) -> str:
    y, w, _ = to_date(d).isocalendar()
    return f"{y:04d}-W{w:02d}"


def parse_iso_week(week: str) -> date:
    """'2026-W43' -> Monday of that ISO week. Raises ValueError for anything else."""
    text = str(week).strip().upper()
    if len(text) != 8 or text[4:6] != "-W":
        raise ValueError("Week must look like 2026-W43.")
    y, w = int(text[:4]), int(text[6:])
    if not 1 <= w <= 53:
        raise ValueError("Week number must be between 1 and 53.")
    return date.fromisocalendar(y, w, 1)


# ------------------------------------------------------------------ display
def fmt_date(d) -> str:
    """'19 Oct 2026'"""
    d = to_date(d)
    return f"{d.day} {MONTH_ABBR[d.month - 1]} {d.year}" if d else ""


def fmt_day(d) -> str:
    """'Tue 20 Oct'"""
    d = to_date(d)
    return f"{DAY_ABBR[d.weekday()]} {d.day} {MONTH_ABBR[d.month - 1]}" if d else ""


def fmt_day_long(d) -> str:
    """'Sat 20 Feb 2027'"""
    d = to_date(d)
    return f"{DAY_ABBR[d.weekday()]} {d.day} {MONTH_ABBR[d.month - 1]} {d.year}" if d else ""


def fmt_hours(h) -> str:
    """'1,100' / '137.5' (no unit)"""
    if h is None:
        return "0"
    h = float(h)
    return f"{h:,.0f}" if abs(h - round(h)) < 0.05 else f"{h:,.1f}"
