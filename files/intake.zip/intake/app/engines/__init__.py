"""Pure calculation engines: dicts in, dicts out. No Flask or database imports; `today` is always a parameter."""
