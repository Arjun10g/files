"""PRN burndown: funded hours vs cumulative charged and forecast (charged + remaining planned hours), by month."""
from __future__ import annotations

from app.engines import calendar as cal

RULES = {
    "at_risk_ratio": 0.90,   # forecast above 90% of funded hours
    "rate": 110.0,           # CAD per hour, blended
    "burn_rate_months": 3,   # burn rate = average of the last three charged months, used everywhere
    "burn_rate_window": "3-month average",
}


def burndown(prn: dict, charges, planned_by_month: dict, today) -> dict:
    """Burndown payload (docs/contracts.md "Burndown").

    prn: {prn_code, funded_hours, start_month, end_month}; charges: [{month, charged_hours}];
    planned_by_month: {YYYY-MM: hours} planned demand of the initiatives on this PRN. Months before the current
    month are treated as charged; the current month onward is forecast from the plan.
    """
    current = cal.month_key(today)
    funded = float(prn.get("funded_hours") or 0)
    charged_by = {}
    for c in charges or []:
        m = str(c["month"])[:7]
        charged_by[m] = charged_by.get(m, 0.0) + float(c.get("charged_hours") or 0)
    planned = {str(m)[:7]: float(h or 0) for m, h in (planned_by_month or {}).items() if str(m)[:7] >= current}

    candidates = [current]
    for v in (prn.get("start_month"), prn.get("end_month")):
        if v:
            candidates.append(str(v)[:7])
    candidates += list(charged_by) + [m for m, h in planned.items() if h]
    months = cal.month_range(min(candidates), max(candidates))

    charged_cum, forecast_cum, funded_line = [], [], []
    running = 0.0
    for m in months:
        if m <= current:
            running += charged_by.get(m, 0.0)
            charged_cum.append(round(running, 1))
        else:
            charged_cum.append(None)
    charged_total = round(sum(charged_by.values()), 1)
    fc = 0.0
    for m in months:
        if m < current:
            fc += charged_by.get(m, 0.0)
        elif m == current:
            # Forecast = charged + remaining plan: this month's charges already burn part of this month's plan.
            got = charged_by.get(m, 0.0)
            fc += got + max(planned.get(m, 0.0) - got, 0.0)
        else:
            fc += planned.get(m, 0.0) + charged_by.get(m, 0.0)
        forecast_cum.append(round(fc, 1))
        funded_line.append(funded)

    charged_months = sorted(m for m in charged_by if m <= current)
    recent = charged_months[-RULES["burn_rate_months"]:]
    burn_rate = round(sum(charged_by[m] for m in recent) / len(recent), 1) if recent else 0.0
    forecast_total = forecast_cum[-1] if forecast_cum else 0.0
    exhaust = next((m for m, v in zip(months, forecast_cum) if funded and v > funded + 1e-9), None)
    if funded and forecast_total > funded + 1e-9:
        status = "overrun"
    elif funded and forecast_total > funded * RULES["at_risk_ratio"]:
        status = "at_risk"
    else:
        status = "on_track"
    return {
        "prn_code": prn.get("prn_code"),
        "name": prn.get("name"),
        "funded_hours": funded,
        "budget_amount": prn.get("budget_amount") if prn.get("budget_amount") is not None
        else round(funded * float(prn.get("rate") or RULES["rate"]), 2),
        "months": months,
        "month_labels": [cal.month_label(m) for m in months],
        "charged_cum": charged_cum,
        "forecast_cum": forecast_cum,
        "funded_line": funded_line,
        "charged_hours": charged_total,
        "forecast_hours": round(forecast_total, 1),
        "remaining_hours": round(funded - forecast_total, 1),
        "burn_pct": round(charged_total / funded * 100, 1) if funded else None,
        "exhaust_month": exhaust,
        "burn_rate": burn_rate,
        "burn_rate_window": RULES["burn_rate_window"],
        "burn_rate_months": recent,
        "status": status,
        "today": cal.iso(today),
    }
