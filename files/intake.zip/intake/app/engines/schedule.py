"""Scheduling: forward-pass dates for a proposed WBS, CPM critical path with float, slip propagation, Gantt payload.

Durations are business days (calendar.py). Production (WBS-700) is a milestone on the Saturday release train date and
is exempt from business-day maths. The change freeze blocks only production milestones (and CRQ windows), never
development or QA work.
"""
from __future__ import annotations

import math
from collections import defaultdict

from app.engines import calendar as cal

RULES = {
    "hours_per_day": 7.0,
    "default_allocation_pct": 100,
    "milestone_phases": ("Production",),
    "readiness_phase": "Readiness",
    "qa_phase": "QA",
}


class ScheduleError(ValueError):
    """Raised for a dependency loop; `cycle` lists the WBS codes (or ids) involved."""

    def __init__(self, message: str, cycle: list | None = None):
        super().__init__(message)
        self.cycle = cycle or []


# ------------------------------------------------------------------ helpers
def duration_from_hours(est_hours, allocation_pct) -> int:
    """duration_bd = ceil(est_hours / (7 h × allocation_pct/100)), at least 1."""
    hours = float(est_hours or 0)
    pct = float(allocation_pct or RULES["default_allocation_pct"])
    if hours <= 0 or pct <= 0:
        return 1
    return max(1, math.ceil(round(hours / (RULES["hours_per_day"] * pct / 100.0), 9)))


def _is_milestone(t: dict) -> bool:
    return bool(t.get("is_milestone"))


def _children_map(tasks, key="id", parent_key="parent_id") -> dict:
    out = defaultdict(list)
    for t in tasks:
        if t.get(parent_key) is not None:
            out[t[parent_key]].append(t[key])
    return out


def _is_summary(t: dict, children: dict, key="id") -> bool:
    return bool(children.get(t[key])) and not float(t.get("est_hours") or 0)


def _topo(nodes: list, preds: dict, label: dict) -> list:
    """Kahn topological order; raises ScheduleError naming the loop."""
    indeg = {n: 0 for n in nodes}
    succ = defaultdict(list)
    for n in nodes:
        for p in preds.get(n, ()):
            if p in indeg:
                indeg[n] += 1
                succ[p].append(n)
    ready = [n for n in nodes if indeg[n] == 0]
    order = []
    while ready:
        n = ready.pop(0)
        order.append(n)
        for s in succ[n]:
            indeg[s] -= 1
            if indeg[s] == 0:
                ready.append(s)
    if len(order) != len(nodes):
        stuck = [n for n in nodes if indeg[n] > 0]
        cycle = _find_cycle(stuck, preds)
        names = [str(label.get(n, n)) for n in cycle]
        raise ScheduleError(
            "These steps depend on each other in a loop: " + " → ".join(names + names[:1]) + ". Remove one dependency.",
            names,
        )
    return order


def _find_cycle(stuck: list, preds: dict) -> list:
    stuck_set = set(stuck)
    start = stuck[0]
    path, seen = [start], {start: 0}
    node = start
    while True:
        nxt = next((p for p in preds.get(node, ()) if p in stuck_set), None)
        if nxt is None:
            return path
        if nxt in seen:
            return list(reversed(path[seen[nxt]:]))
        seen[nxt] = len(path)
        path.append(nxt)
        node = nxt


def _leaf_expand(node, children: dict, summaries: set) -> list:
    if node not in summaries:
        return [node]
    out = []
    for c in children.get(node, ()):
        out.extend(_leaf_expand(c, children, summaries))
    return out


def _milestone_date(after, target_train, trains):
    """First train strictly after `after`, outside the freeze; the target train wins when it is still reachable."""
    after = cal.to_date(after)
    if target_train:
        td = cal.to_date(target_train.get("train_date"))
        if td and td > after and not cal.in_freeze(td):
            return td
    nxt = cal.next_train_after(after, trains)
    if nxt:
        return nxt[1]
    return cal.next_business_day(after)


# ------------------------------------------------------------------ forward pass for a proposed WBS
def schedule_plan(tasks, plan_start, *, target_train: dict | None = None, trains=None) -> dict:
    """Dates for an AI-proposed WBS (no dates): {wbs_code: {planned_start, planned_end, duration_bd}}.

    tasks: [{wbs_code, parent_code?, duration_days?, offset_days?, depends_on:[wbs_code], is_milestone,
             est_hours?, allocation_pct?}]. Duration comes from hours and allocation % when both are set,
    otherwise from duration_days. Children inherit their summary parent's dependencies. A milestone lands on the
    target train (or the next train after its predecessors, never inside the freeze).
    """
    codes = [t["wbs_code"] for t in tasks]
    by_code = {t["wbs_code"]: t for t in tasks}
    children = _children_map(tasks, key="wbs_code", parent_key="parent_code")
    summaries = {c for c in codes if _is_summary(by_code[c], children, key="wbs_code")}
    start0 = cal.next_business_day(plan_start, include_self=True)

    def effective_deps(code):
        t = by_code[code]
        deps = list(t.get("depends_on") or [])
        parent = t.get("parent_code")
        while parent and parent in by_code:
            deps.extend(d for d in (by_code[parent].get("depends_on") or []) if d not in deps)
            parent = by_code[parent].get("parent_code")
        return [d for d in deps if d in by_code and d != code]

    leaf_preds = {}
    for c in codes:
        if c in summaries:
            continue
        expanded = []
        for d in effective_deps(c):
            for leaf in _leaf_expand(d, children, summaries):
                if leaf != c and leaf not in expanded:
                    expanded.append(leaf)
        leaf_preds[c] = expanded
    leaves = [c for c in codes if c not in summaries]
    order = _topo(leaves, leaf_preds, {c: c for c in codes})

    out: dict[str, dict] = {}
    for c in order:
        t = by_code[c]
        earliest = start0
        if t.get("offset_days"):
            earliest = cal.add_business_days(start0, int(t["offset_days"]))
        pred_ends = [cal.to_date(out[p]["planned_end"]) for p in leaf_preds[c]]
        if _is_milestone(t):
            after = max(pred_ends) if pred_ends else cal.prev_business_day(earliest)
            d = _milestone_date(after, target_train, trains)
            out[c] = {"planned_start": d.isoformat(), "planned_end": d.isoformat(), "duration_bd": 0}
            continue
        if pred_ends:
            earliest = max(earliest, cal.next_business_day(max(pred_ends)))
        if float(t.get("est_hours") or 0) > 0 and t.get("allocation_pct"):
            dur = duration_from_hours(t["est_hours"], t["allocation_pct"])
        else:
            dur = max(1, int(t.get("duration_days") or 1))
        end = cal.end_after_business_days(earliest, dur)
        out[c] = {"planned_start": earliest.isoformat(), "planned_end": end.isoformat(), "duration_bd": dur}

    for c in _summaries_bottom_up(codes, children, summaries):
        kids = [out[k] for k in children.get(c, ()) if k in out]
        if kids:
            s = min(k["planned_start"] for k in kids)
            e = max(k["planned_end"] for k in kids)
            out[c] = {"planned_start": s, "planned_end": e, "duration_bd": cal.count_business_days(s, e)}
    return {c: out[c] for c in codes if c in out}


def _summaries_bottom_up(nodes, children, summaries) -> list:
    depth = {}

    def d(n):
        if n not in depth:
            depth[n] = 1 + max((d(k) for k in children.get(n, ()) if k in summaries), default=0)
        return depth[n]

    return sorted((n for n in nodes if n in summaries), key=d)


# ------------------------------------------------------------------ CPM on dated tasks
def _dated_network(tasks):
    by_id = {t["id"]: t for t in tasks}
    children = _children_map(tasks)
    summaries = {t["id"] for t in tasks if _is_summary(t, children)}
    nodes = [t["id"] for t in tasks
             if t["id"] not in summaries and t.get("planned_start") and t.get("planned_end")]
    node_set = set(nodes)
    preds = {}
    for n in nodes:
        expanded = []
        for d in by_id[n].get("depends_on") or []:
            if d not in by_id:
                continue
            for leaf in _leaf_expand(d, children, summaries):
                if leaf in node_set and leaf != n and leaf not in expanded:
                    expanded.append(leaf)
        preds[n] = expanded
    return by_id, children, summaries, nodes, preds


def cpm(tasks) -> dict:
    """{task_id: {es, ef, ls, lf, float_bd, duration_bd}} in business-day index space.

    Durations come from the planned dates (milestones are 0). Tasks with predecessors start as early as their
    predecessors allow (logical network), so float shows how far a step can slip before it moves the plan's end.
    """
    by_id, _children, _summaries, nodes, preds = _dated_network(tasks)
    if not nodes:
        return {}
    labels = {n: by_id[n].get("wbs_code", n) for n in nodes}
    order = _topo(nodes, preds, labels)
    base = min(cal.to_date(by_id[n]["planned_start"]) for n in nodes)
    base = cal.prev_business_day(base)

    def idx(d):
        return cal.count_business_days(cal.next_business_day(base), cal.next_business_day(d, include_self=True)) - 1

    dur = {}
    for n in nodes:
        t = by_id[n]
        dur[n] = 0 if _is_milestone(t) else max(1, cal.count_business_days(t["planned_start"], t["planned_end"]))
    es, ef = {}, {}
    for n in order:
        if preds[n]:
            es[n] = max(ef[p] for p in preds[n]) + 1
        else:
            es[n] = idx(by_id[n]["planned_start"])
        ef[n] = es[n] + dur[n] - 1
    project_end = max(ef.values())
    succ = defaultdict(list)
    for n in nodes:
        for p in preds[n]:
            succ[p].append(n)
    ls, lf = {}, {}
    for n in reversed(order):
        lf[n] = min((ls[s] - 1 for s in succ[n]), default=project_end)
        ls[n] = lf[n] - dur[n] + 1
    return {n: {"es": es[n], "ef": ef[n], "ls": ls[n], "lf": lf[n], "float_bd": ls[n] - es[n], "duration_bd": dur[n]}
            for n in nodes}


def critical_path(tasks) -> list:
    """Task ids with zero float, in schedule order."""
    result = cpm(tasks)
    crit = [n for n, r in result.items() if r["float_bd"] <= 0]
    return sorted(crit, key=lambda n: (result[n]["es"], result[n]["ef"], str(n)))


# ------------------------------------------------------------------ slip propagation
def propagate_slip(tasks, changed_id) -> dict:
    """After task `changed_id` got new dates (already in `tasks`), move its dependants.

    A dependant that now starts before its predecessors finish is pushed out, keeping its business-day duration.
    A dependant that has room to come back moves earlier, but never before its baseline start, so editing a date
    back restores the original plan. Production milestones move to the next release train outside the freeze.
    Summary rows are re-derived from their children. Returns {task_id: (planned_start, planned_end)} for every row
    whose dates changed (not including `changed_id`).
    """
    by_id = {t["id"]: dict(t) for t in tasks}
    if changed_id not in by_id:
        return {}
    children = _children_map(tasks)
    summaries = {i for i, t in by_id.items() if _is_summary(t, children)}
    own = {i: [d for d in (t.get("depends_on") or []) if d in by_id and d != i] for i, t in by_id.items()}

    def inherited(i):
        """Own dependencies plus every ancestor's (children inherit their parent's predecessors)."""
        ps = list(own[i])
        p = by_id[i].get("parent_id")
        while p is not None and p in by_id:
            ps.extend(x for x in own[p] if x not in ps and x != i)
            p = by_id[p].get("parent_id")
        return ps

    eff = {i: inherited(i) for i in by_id}
    # Ordering also waits for every row inside a summary predecessor, whose end is derived from its children.
    preds = {}
    for i, ps in eff.items():
        full = list(ps)
        for p in ps:
            if p in summaries:
                full.extend(k for k in _all_descendants(p, children) if k != i and k not in full)
        preds[i] = full
    labels = {i: t.get("wbs_code", i) for i, t in by_id.items()}
    order = _topo(list(by_id), preds, labels)
    succ = defaultdict(list)
    for i, ps in preds.items():
        for p in ps:
            succ[p].append(i)

    affected = set()
    stack = [changed_id]
    parent = by_id[changed_id].get("parent_id")
    while parent is not None and parent in by_id:
        stack.append(parent)
        parent = by_id[parent].get("parent_id")
    while stack:
        n = stack.pop()
        for s in succ[n]:
            if s not in affected:
                affected.add(s)
                stack.append(s)
                for k in _all_descendants(s, children):
                    if k not in affected:
                        affected.add(k)
                        stack.append(k)

    original = {i: (t.get("planned_start"), t.get("planned_end")) for i, t in by_id.items()}

    def end_of(i):
        if i in summaries:
            kids = [end_of(k) for k in children.get(i, ())]
            kids = [k for k in kids if k]
            return max(kids) if kids else cal.to_date(by_id[i].get("planned_end"))
        return cal.to_date(by_id[i].get("planned_end"))

    for i in order:
        if i == changed_id or i not in affected or i in summaries:
            continue
        t = by_id[i]
        if not t.get("planned_start") or not t.get("planned_end"):
            continue
        ends = [end_of(p) for p in eff[i]]
        ends = [e for e in ends if e]
        if not ends:
            continue
        pred_end = max(ends)
        if _is_milestone(t):
            d = cal.next_train_after(pred_end)
            new = d[1] if d else cal.next_business_day(pred_end)
            base = cal.to_date(t.get("baseline_start"))
            if base and new < base:
                new = base
            t["planned_start"] = t["planned_end"] = new.isoformat()
            continue
        dur = max(1, cal.count_business_days(t["planned_start"], t["planned_end"]))
        cur = cal.next_business_day(t["planned_start"], include_self=True)
        earliest = cal.next_business_day(pred_end)
        if cur < earliest:
            new_start = earliest
        elif cur > earliest:
            base = cal.to_date(t.get("baseline_start"))
            floor = cal.next_business_day(base, include_self=True) if base else cur
            new_start = min(cur, max(earliest, floor))
        else:
            new_start = cur
        t["planned_start"] = new_start.isoformat()
        t["planned_end"] = cal.end_after_business_days(new_start, dur).isoformat()

    for i in _summaries_bottom_up(list(by_id), children, summaries):
        kids = [by_id[k] for k in children.get(i, ()) if by_id[k].get("planned_start")]
        if kids:
            by_id[i]["planned_start"] = min(k["planned_start"] for k in kids)
            by_id[i]["planned_end"] = max(k["planned_end"] for k in kids)

    return {i: (t["planned_start"], t["planned_end"]) for i, t in by_id.items()
            if i != changed_id and (t.get("planned_start"), t.get("planned_end")) != original[i]}


def _all_descendants(i, children) -> list:
    out = []
    for k in children.get(i, ()):
        out.append(k)
        out.extend(_all_descendants(k, children))
    return out


# ------------------------------------------------------------------ key dates & Gantt
def key_dates(tasks) -> dict:
    """{readiness_date, qa_date, prod_date, start, end} from the plan rows."""
    def max_end(phase):
        ends = [t["planned_end"] for t in tasks if t.get("phase") == phase and t.get("planned_end")]
        return max(ends) if ends else None

    prod = [t["planned_start"] for t in tasks
            if t.get("planned_start") and (_is_milestone(t) and t.get("phase") in RULES["milestone_phases"])]
    if not prod:
        prod = [t["planned_start"] for t in tasks if _is_milestone(t) and t.get("planned_start")]
    starts = [t["planned_start"] for t in tasks if t.get("planned_start")]
    ends = [t["planned_end"] for t in tasks if t.get("planned_end")]
    return {
        "readiness_date": max_end(RULES["readiness_phase"]),
        "qa_date": max_end(RULES["qa_phase"]),
        "prod_date": min(prod) if prod else None,
        "start": min(starts) if starts else None,
        "end": max(ends) if ends else None,
    }


def readiness_float(readiness_date, train_date) -> int | None:
    """Business days strictly between readiness and the train. Negative (business days late) when missed."""
    r, t = cal.to_date(readiness_date), cal.to_date(train_date)
    if r is None or t is None:
        return None
    if r < t:
        return cal.business_days_strictly_between(r, t)
    return -cal.count_business_days(t, r)


def build_gantt(tasks, today, *, target_train: dict | None = None, trains=None) -> dict:
    """Gantt payload (docs/contracts.md "Gantt") from bundle task rows."""
    tasks = list(tasks)
    children = _children_map(tasks)
    summaries = {t["id"] for t in tasks if _is_summary(t, children)}
    try:
        net = cpm(tasks)
        loop = None
    except ScheduleError as exc:
        net, loop = {}, str(exc)
    crit = {n for n, r in net.items() if r["float_bd"] <= 0}
    kd = key_dates(tasks)
    train_d = (target_train or {}).get("train_date")

    rows = []
    for t in tasks:
        tid = t["id"]
        if tid in summaries:
            kid_floats = [net[k]["float_bd"] for k in _all_descendants(tid, children) if k in net]
            fl = min(kid_floats) if kid_floats else None
        else:
            fl = net[tid]["float_bd"] if tid in net else None
        slip = None
        if t.get("baseline_end") and t.get("planned_end"):
            slip = cal.business_days_after(t["baseline_end"], t["planned_end"])
        rows.append({
            "id": tid,
            "wbs_code": t.get("wbs_code"),
            "parent_id": t.get("parent_id"),
            "step": t.get("step"),
            "phase": t.get("phase"),
            "resource_name": t.get("resource_name"),
            "owner_name": t.get("owner_name"),
            "planned_start": t.get("planned_start"),
            "planned_end": t.get("planned_end"),
            "baseline_start": t.get("baseline_start"),
            "baseline_end": t.get("baseline_end"),
            "est_hours": t.get("est_hours"),
            "pct": t.get("pct") or 0,
            "status": t.get("status"),
            "at_risk": bool(t.get("at_risk")),
            "is_milestone": bool(t.get("is_milestone")),
            "is_summary": tid in summaries,
            "critical": tid in crit,
            "float_bd": fl,
            "slip_bd": slip,
            "depends_on": list(t.get("depends_on") or []),
        })

    trains_out = [{"code": c, "train_date": d.isoformat()} for c, d in cal._trains(trains)]
    starts = [kd["start"]] if kd["start"] else []
    ends = [kd["end"]] if kd["end"] else []
    return {
        "start": min(starts) if starts else None,
        "end": max(ends) if ends else None,
        "today": cal.iso(today),
        "freeze": cal.freeze_window(),
        "trains": trains_out,
        "target_train": target_train,
        "readiness_date": kd["readiness_date"],
        "qa_date": kd["qa_date"],
        "prod_date": kd["prod_date"],
        "float_bd": readiness_float(kd["readiness_date"], train_d),
        "critical_path": [n for n in critical_path(tasks)] if loop is None else [],
        "dependency_loop": loop,
        "tasks": rows,
    }
