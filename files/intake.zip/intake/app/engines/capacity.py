"""Capacity: spread task hours over business days into months, then demand vs availability per person, team or quarter."""
from __future__ import annotations

from collections import defaultdict

from app.engines import calendar as cal

RULES = {
    # Bands on unrounded utilisation (demand / available).
    "bands": (("spare", 0.70, "<"), ("ok", 1.00, "<="), ("stretched", 1.10, "<=")),
    "over_band": "over",
    "band_labels": {"spare": "Spare", "ok": "On plan", "stretched": "Stretched", "over": "Over-allocated"},
    # Deck bars first, then the rest of the full view.
    "team_order": ("EAPI (Dev1)", "EAPI (Dev2)", "EAPI Tech Lead", "CIAM", "SRE", "Mobile", "Web", "QA", "DC SA"),
    # Bare team labels that read like a duplicate team next to its sub-teams (Director round 2 #21).
    "team_label_overrides": {"EAPI": "EAPI Tech Lead"},
    "deck_teams": ("EAPI (Dev1)", "EAPI (Dev2)", "CIAM", "SRE"),
    "month_round": 1,  # decimals per month bucket
}


def band(util: float | None, demand: float = 0.0) -> str:
    """spare < 0.70 · ok ≤ 1.00 · stretched ≤ 1.10 · over > 1.10. No availability with demand is over."""
    if util is None:
        return RULES["over_band"] if demand > 0 else "spare"
    util = round(util, 9)  # 147.0 / 147.0 must read as exactly 100%
    for name, limit, op in RULES["bands"]:
        if (op == "<" and util < limit) or (op == "<=" and util <= limit):
            return name
    return RULES["over_band"]


def utilisation(demand: float, available: float) -> float | None:
    if not available:
        return None
    return demand / available


def spread_hours(start, end, hours) -> dict[str, float]:
    """Spread `hours` evenly over the business days in [start, end] and bucket by month.

    Each month is rounded to 0.1 h and the last month absorbs the remainder, so the months sum to `hours`.
    A task with no business days (a Saturday milestone) books all its hours to its own month.
    """
    hours = float(hours or 0)
    s, e = cal.to_date(start), cal.to_date(end)
    if s is None or hours <= 0:
        return {}
    if e is None or e < s:
        e = s
    days = cal.business_days(s, e)
    if not days:
        return {cal.month_key(s): round(hours, RULES["month_round"])}
    per_day = hours / len(days)
    counts: dict[str, int] = defaultdict(int)
    for d in days:
        counts[cal.month_key(d)] += 1
    months = sorted(counts)
    out: dict[str, float] = {}
    booked = 0.0
    for m in months[:-1]:
        h = round(per_day * counts[m], RULES["month_round"])
        out[m] = h
        booked += h
    out[months[-1]] = round(hours - booked, RULES["month_round"])
    return out


def _cell(month_or_key: str, available: float, confirmed: float, tentative: float) -> dict:
    demand = confirmed + tentative
    util = utilisation(demand, available)
    return {
        "month": month_or_key,
        "available": round(available, 1),
        "confirmed": round(confirmed, 1),
        "tentative": round(tentative, 1),
        "util": util,
        "band": band(util, demand),
    }


def team_label(res: dict) -> str:
    label = res.get("team_label") or res.get("team") or "Other"
    return RULES["team_label_overrides"].get(label, label)


def _team_key(res: dict) -> str:
    return team_label(res)


def month_columns(months) -> list[dict]:
    """Column meta for month views: [{month, label:'Oct 2026', quarter:'Q4 FY26', quarter_range:'Aug–Oct'}]."""
    out = []
    for m in months:
        q = cal.fiscal_quarter(m)
        out.append({"month": m, "label": cal.month_label(m), "quarter": cal.quarter_short(q),
                    "quarter_range": q["label"]})
    return out


def _team_sort(team: str) -> tuple[int, str]:
    order = RULES["team_order"]
    return (order.index(team), team) if team in order else (len(order), team)


def demand_by_resource_month(allocations) -> dict[tuple[int, str], dict[str, float]]:
    """{(resource_id, month): {'confirmed': h, 'tentative': h}} from allocation rows."""
    out: dict[tuple[int, str], dict[str, float]] = defaultdict(lambda: {"confirmed": 0.0, "tentative": 0.0})
    for a in allocations:
        firm = "confirmed" if a.get("firmness") == "confirmed" else "tentative"
        out[(a["resource_id"], str(a["month"])[:7])][firm] += float(a.get("hours") or 0)
    return out


def available_hours(res: dict, month: str) -> float:
    avail = res.get("availability") or {}
    if month in avail and avail[month] is not None:
        return float(avail[month])
    return float(res.get("default_monthly_hours") or 0)


def compute_capacity(resources, allocations, months, group: str = "resource") -> dict:
    """Capacity payload: {months, rows:[{key,label,team,cells:[...]}], teams:[...]}.

    resources: [{id, name, team, team_label, availability:{YYYY-MM:h}, default_monthly_hours}]
    allocations: [{resource_id, month, hours, firmness}] across all initiatives.
    group: 'resource' (person × month), 'team' (team × month) or 'quarter' (person × fiscal quarter).
    """
    months = list(months)
    demand = demand_by_resource_month(allocations)

    def person_month(res, m):
        d = demand.get((res["id"], m), {"confirmed": 0.0, "tentative": 0.0})
        return available_hours(res, m), d["confirmed"], d["tentative"]

    rows = []
    if group == "team":
        teams: dict[str, list] = defaultdict(list)
        for r in resources:
            teams[_team_key(r)].append(r)
        for team in sorted(teams, key=_team_sort):
            cells = []
            for m in months:
                a = c = t = 0.0
                for r in teams[team]:
                    pa, pc, pt = person_month(r, m)
                    a, c, t = a + pa, c + pc, t + pt
                cells.append(_cell(m, a, c, t))
            rows.append({"key": team, "label": team, "team": team, "members": len(teams[team]), "cells": cells})
        columns = months
    elif group == "quarter":
        quarters = []
        for m in months:
            q = cal.fiscal_quarter(m)
            if not quarters or cal.quarter_key(quarters[-1]) != cal.quarter_key(q):
                quarters.append(q)
        columns = [cal.quarter_key(q) for q in quarters]
        for r in sorted(resources, key=lambda x: (_team_sort(_team_key(x)), x["name"])):
            cells = []
            for q in quarters:
                a = c = t = 0.0
                for m in q["months"]:
                    pa, pc, pt = person_month(r, m)
                    a, c, t = a + pa, c + pc, t + pt
                cell = _cell(cal.quarter_key(q), a, c, t)
                cell.update({"quarter": q["q"], "fy": q["fy"], "label": q["label"], "short": q["short"]})
                cells.append(cell)
            rows.append({"key": str(r["id"]), "label": r["name"], "team": _team_key(r), "resource_id": r["id"],
                         "cells": cells})
    else:
        columns = months
        for r in sorted(resources, key=lambda x: (_team_sort(_team_key(x)), x["name"])):
            cells = [_cell(m, *person_month(r, m)) for m in months]
            rows.append({"key": str(r["id"]), "label": r["name"], "team": _team_key(r), "resource_id": r["id"],
                         "role": r.get("role"), "cells": cells})

    if group == "quarter":
        meta = [{"month": cal.quarter_key(q), "label": f"{q['short']} ({q['label']})", "quarter": q["short"],
                 "quarter_range": q["label"]} for q in quarters]
    else:
        meta = month_columns(columns)
    return {"months": columns, "columns": meta, "rows": rows,
            "teams": team_totals(resources, allocations, months)}


def team_totals(resources, allocations, months) -> list[dict]:
    """One bar per team over the whole window: {team, available, confirmed, tentative, util, band}."""
    demand = demand_by_resource_month(allocations)
    agg: dict[str, list[float]] = defaultdict(lambda: [0.0, 0.0, 0.0])
    for r in resources:
        key = _team_key(r)
        for m in months:
            d = demand.get((r["id"], m), {"confirmed": 0.0, "tentative": 0.0})
            agg[key][0] += available_hours(r, m)
            agg[key][1] += d["confirmed"]
            agg[key][2] += d["tentative"]
    out = []
    for team in sorted(agg, key=_team_sort):
        a, c, t = agg[team]
        util = utilisation(c + t, a)
        out.append({"team": team, "available": round(a, 1), "confirmed": round(c, 1), "tentative": round(t, 1),
                    "util": util, "band": band(util, c + t), "deck": team in RULES["deck_teams"]})
    return out


def person_peaks(resources, allocations, months) -> list[dict]:
    """Every person-month with util > 1.00: [{resource_id, name, month, util, demand, available}]."""
    demand = demand_by_resource_month(allocations)
    out = []
    for r in resources:
        for m in months:
            d = demand.get((r["id"], m))
            if not d:
                continue
            total = d["confirmed"] + d["tentative"]
            avail = available_hours(r, m)
            util = utilisation(total, avail)
            if (util is None and total > 0) or (util is not None and util > 1.0):
                out.append({"resource_id": r["id"], "name": r["name"], "month": m, "util": util,
                            "demand": round(total, 1), "available": avail})
    return out
