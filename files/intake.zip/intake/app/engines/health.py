"""Project health: five RAG dimensions plus overall, each with reasons, metrics and a "How we got this" explanation.

Rules follow master plan §1 (RAG rules) and §6.2 (hero parity pins). Inputs are the initiative bundle
(docs/contracts.md §3) and `today`; nothing here reads a clock or a database.
"""
from __future__ import annotations

from collections import defaultdict

from app.engines import calendar as cal
from app.engines import l2 as l2_engine
from app.engines import schedule as sched

RULES = {
    "scored_stages": ("Planning", "Build", "QA", "Release", "Closed"),
    "no_plan_reason": "Generate the project plan to score health.",
    "dimensions": ("schedule", "resources", "scope", "dependencies", "budget"),
    "schedule": {"green_float_bd": 5, "overdue_amber_max_bd": 5},
    "resources": {"amber_util": 1.00, "red_util": 1.10, "unassigned_red_bd": 5, "unassigned_amber_bd": 10},
    "scope": {"green_sa": 80, "amber_sa": 60, "red_changes": 2, "red_delta_pct": 20.0},
    "dependencies": {"need_by_amber_bd": 15, "l2_pending_amber_bd": 10},
    "budget": {"amber_gap_pts": 10.0, "red_gap_pts": 20.0},
    "overall": "Red if Schedule is Red or two or more dimensions are Red; Amber if any dimension is Red or Amber; "
               "otherwise Green.",
    # Round 2 decision 7: management attention = every Red dimension plus Schedule Amber with float <= 2 bd.
    "attention_float_bd": 2,
    "attention_rule": "Management attention lists every Red dimension and any Amber schedule with 2 or fewer "
                      "business days of readiness float.",
}

RULE_TEXT = {
    "schedule": "Readiness float = business days strictly between the Readiness Date and the target release train. "
                "Green: float 5 or more and nothing overdue. Amber: float 0–4, or a step overdue by up to 5 business "
                "days. Red: the plan misses the target train, a critical-path step is more than 5 business days "
                "overdue, or Production falls in the change freeze.",
    "resources": "Each person is checked only in the months they work on this initiative, against everything they "
                 "are booked on. Green: everyone at or under 100%. Amber: anyone 101–110%, or a step starting within "
                 "10 business days with nobody assigned. Red: anyone over 110%, or a step starting within 5 business "
                 "days with nobody assigned.",
    "scope": "Green: no scope change since L2 approval and SA Completeness 80% or more. Amber: SA Completeness "
             "60–79%, one scope change, or the L2 estimate differing from the approved baseline by up to 20% "
             "(|current − baseline| ÷ baseline). Red: SA Completeness under 60%, two or more scope changes, or the L2 "
             "estimate differing from the baseline by more than 20%.",
    "dependencies": "Green unless a trigger fires. Amber: a component approval is pending and its work starts within "
                    "15 business days, L2 approval has been pending more than 10 business days, or a step is "
                    "blocked. Red: a component approval was rejected, or a step that others depend on is overdue.",
    "budget": "Compares PRN burn with plan completion. Green: burn % minus completion % is 10 points or less. Amber: "
              "11–20 points. Red: more than 20 points, or the forecast (charged plus remaining plan hours) exceeds "
              "the funded hours.",
}

RULE_TEXT_OVERALL = ("Overall is Red if Schedule is Red or two or more dimensions are Red; Amber if any dimension is Red "
                     "or Amber; otherwise Green.")

DIM_LABELS = {"schedule": "Schedule", "resources": "Resources", "scope": "Scope",
              "dependencies": "Dependencies", "budget": "Budget"}


def _pct(util: float | None) -> int:
    return int(util * 100 + 0.5) if util is not None else 0


def _dim(rag, reasons, metrics, explanation, attention=None, dim=None) -> dict:
    return {
        "rag": rag,
        "reasons": reasons,
        "metrics": metrics,
        "overridden": False,
        "rule": RULE_TEXT[dim],
        "explanation": explanation,
        "_attention": attention or [],
    }


def _leaf_tasks(tasks) -> list:
    parents = {t.get("parent_id") for t in tasks if t.get("parent_id") is not None}
    return [t for t in tasks if not (t["id"] in parents and not float(t.get("est_hours") or 0))]


def _is_open(t) -> bool:
    return t.get("status") != "Completed" and int(t.get("pct") or 0) < 100


# ------------------------------------------------------------------ schedule
def schedule_dimension(bundle, today) -> dict:
    ini = bundle["initiative"]
    tasks = bundle.get("tasks") or []
    leaves = _leaf_tasks(tasks)
    train = bundle.get("target_train") or None
    if not train and ini.get("target_release"):
        td = cal.train_date(ini["target_release"])
        train = {"code": ini["target_release"], "train_date": td.isoformat()} if td else None
    dated = [t for t in leaves if t.get("planned_start") and t.get("planned_end")]
    if not dated:
        return _dim("Amber", ["No project plan yet. Generate the plan on Pg 2."],
                    {"readiness_date": ini.get("readiness_date"), "train_date": (train or {}).get("train_date"),
                     "float_bd": None},
                    "Schedule needs plan dates; none are set yet.", dim="schedule")

    kd = sched.key_dates(tasks)
    readiness = kd["readiness_date"] or ini.get("readiness_date")
    prod = kd["prod_date"] or ini.get("prod_date")
    train_d = (train or {}).get("train_date")
    fl = sched.readiness_float(readiness, train_d)

    try:
        net = sched.cpm(tasks)
        loop = None
    except sched.ScheduleError as exc:
        net, loop = {}, str(exc)
    critical = {n for n, r in net.items() if r["float_bd"] <= 0}

    overdue = []
    for t in dated:
        if _is_open(t) and cal.to_date(t["planned_end"]) < cal.to_date(today):
            overdue.append((t, cal.business_days_after(t["planned_end"], today)))
    overdue.sort(key=lambda x: -x[1])

    reasons, attention, watch = [], [], []
    red = amber = False
    rules = RULES["schedule"]
    code = (train or {}).get("code")
    if train_d and readiness and fl is not None and fl < 0:
        red = True
        reasons.append(f"Readiness {cal.fmt_date(readiness)} misses {code} ({cal.fmt_day_long(train_d)}) "
                       f"by {-fl} business day{'s' if -fl != 1 else ''}")
        attention.append(f"Schedule slip affecting {_slip_root(tasks, net) or _readiness_code(tasks) or 'the plan'}")
    elif train_d and prod and cal.to_date(prod) > cal.to_date(train_d):
        red = True
        reasons.append(f"Production {cal.fmt_date(prod)} is after {code} ({cal.fmt_day_long(train_d)})")
        attention.append(f"Production date misses {code} affecting {_prod_code(tasks) or 'WBS-700'}")
    elif fl is not None and train_d:
        msg = f"Readiness float {fl} business day{'s' if fl != 1 else ''} before {code} ({cal.fmt_day_long(train_d)})"
        reasons.append(msg)
        if fl < rules["green_float_bd"]:
            amber = True
        if fl <= RULES["attention_float_bd"]:
            watch.append(f"Readiness float {fl} business day{'s' if fl != 1 else ''} to {code} affecting "
                         f"{_readiness_code(tasks) or 'the plan'}")
    else:
        amber = True
        reasons.append("No target release train set. Pick one on Pg 1 to measure readiness float.")

    if prod and cal.in_freeze(prod):
        red = True
        reasons.append(f"Production {cal.fmt_date(prod)} falls in the change freeze "
                       f"({cal.fmt_date(cal.FREEZE_START)} – {cal.fmt_date(cal.FREEZE_END)})")
        attention.append(f"Production in change freeze affecting {_prod_code(tasks) or 'WBS-700'}")

    for t, bd in overdue:
        crit = t["id"] in critical
        if crit and bd > rules["overdue_amber_max_bd"]:
            red = True
            reasons.append(f"{t['wbs_code']} is {bd} business days overdue on the critical path")
            attention.append(f"Overdue critical-path step {t['wbs_code']}")
        else:
            amber = True
            reasons.append(f"{t['wbs_code']} is {bd} business day{'s' if bd != 1 else ''} overdue")
    if loop:
        amber = True
        reasons.append(loop)

    rag = "Red" if red else ("Amber" if amber else "Green")
    metrics = {"readiness_date": readiness, "train_date": train_d, "float_bd": fl, "prod_date": prod,
               "overdue_steps": len(overdue), "critical_path": [tid for tid in sched.critical_path(tasks)]
               if not loop else []}
    explanation = (f"Readiness Date {cal.fmt_date(readiness) or 'not set'}; target train "
                   f"{code or 'not set'}{' on ' + cal.fmt_day_long(train_d) if train_d else ''}; float "
                   f"{fl if fl is not None else 'not measurable'} business days; {len(overdue)} overdue "
                   f"step{'s' if len(overdue) != 1 else ''}.")
    out = _dim(rag, reasons, metrics, explanation, attention, dim="schedule")
    out["_watch"] = watch if rag == "Amber" else []
    return out


def _slip_root(tasks, net) -> str | None:
    slipped = [t for t in tasks if t.get("baseline_end") and t.get("planned_end")
               and t["planned_end"] > t["baseline_end"] and t["id"] in net]
    if not slipped:
        return None
    slipped.sort(key=lambda t: (net[t["id"]]["es"], t.get("planned_start") or "", t.get("wbs_code") or ""))
    return slipped[0].get("wbs_code")


def _readiness_code(tasks) -> str | None:
    rows = [t for t in tasks if t.get("phase") == "Readiness"]
    return rows[-1]["wbs_code"] if rows else None


def _prod_code(tasks) -> str | None:
    rows = [t for t in tasks if t.get("is_milestone")]
    return rows[0]["wbs_code"] if rows else None


# ------------------------------------------------------------------ resources
def _team_short(res: dict) -> str:
    team = res.get("team") or res.get("team_label") or "Team"
    return team.removeprefix("DC ")


def resources_dimension(bundle, today) -> dict:
    tasks = {t["id"]: t for t in bundle.get("tasks") or []}
    people = {r["id"]: r for r in bundle.get("resources") or []}
    this_month = cal.month_key(today)
    rules = RULES["resources"]

    own: dict[tuple, set] = defaultdict(set)
    own_hours: dict[tuple, float] = defaultdict(float)
    for a in bundle.get("allocations") or []:
        m = str(a["month"])[:7]
        if m < this_month:
            continue
        own[(a["resource_id"], m)].add(a.get("task_id"))
        own_hours[(a["resource_id"], m)] += float(a.get("hours") or 0)

    checks = []
    for (rid, m), task_ids in own.items():
        res = people.get(rid)
        if not res or not res.get("capacity_eligible"):
            continue
        avail_map = res.get("availability") or {}
        avail = float(avail_map[m]) if avail_map.get(m) is not None else float(res.get("default_monthly_hours") or 0)
        committed_map = res.get("committed") or {}
        booked = float(committed_map[m]) if committed_map.get(m) is not None else own_hours[(rid, m)]
        util = booked / avail if avail else None
        codes = sorted({tasks[t]["wbs_code"] for t in task_ids if t in tasks and tasks[t].get("wbs_code")})
        checks.append({"resource_id": rid, "name": res["name"], "team": _team_short(res), "month": m,
                       "util": util, "booked": booked, "available": avail, "wbs_codes": codes})

    def over(c, limit):
        return (c["util"] is None and c["booked"] > 0) or (c["util"] is not None and round(c["util"], 9) > limit)

    reds = [c for c in checks if over(c, rules["red_util"])]
    ambers = [c for c in checks if over(c, rules["amber_util"]) and c not in reds]
    reds.sort(key=lambda c: (-(c["util"] or 99), c["month"], c["name"]))
    ambers.sort(key=lambda c: (-(c["util"] or 99), c["month"], c["name"]))

    reasons, attention = [], []
    for c in reds + ambers:
        pct = f"{_pct(c['util'])}%" if c["util"] is not None else "booked with no availability"
        codes = ", ".join(c["wbs_codes"])
        reasons.append(f"{c['name']} at {pct} in {cal.month_label(c['month'])}" + (f" ({codes})" if codes else ""))
    by_person: dict[int, dict] = {}
    for c in reds:
        p = by_person.setdefault(c["resource_id"], {"team": c["team"], "codes": []})
        p["codes"].extend(x for x in c["wbs_codes"] if x not in p["codes"])
    for p in by_person.values():
        attention.append(f"{p['team']} capacity constraint affecting {', '.join(p['codes']) or 'this plan'}")

    unassigned_red = unassigned_amber = 0
    for t in _leaf_tasks(bundle.get("tasks") or []):
        if t.get("resource_id") or t.get("is_milestone") or not _is_open(t) or not t.get("planned_start"):
            continue
        if not float(t.get("est_hours") or 0):
            continue
        bd = max(0, cal.business_days_after(today, t["planned_start"]))
        if bd <= rules["unassigned_red_bd"]:
            unassigned_red += 1
            reasons.append(f"{t['wbs_code']} starts {cal.fmt_date(t['planned_start'])} with nobody assigned")
            attention.append(f"No resource assigned to {t['wbs_code']}")
        elif bd <= rules["unassigned_amber_bd"]:
            unassigned_amber += 1
            reasons.append(f"{t['wbs_code']} starts in {bd} business days with nobody assigned")

    peak = max(checks, key=lambda c: (c["util"] if c["util"] is not None else 99), default=None)
    if not reds and not ambers and not unassigned_red and not unassigned_amber:
        if peak:
            reasons.append(f"Everyone on this plan is at or under 100%; peak {peak['name']} "
                           f"{_pct(peak['util'])}% in {cal.month_label(peak['month'])}")
        else:
            reasons.append("Nobody is booked on this plan from this month on")
    rag = "Red" if reds or unassigned_red else ("Amber" if ambers or unassigned_amber else "Green")
    metrics = {
        "peak_util": round(peak["util"], 4) if peak and peak["util"] is not None else None,
        "peak_resource_id": peak["resource_id"] if peak else None,
        "peak_month": peak["month"] if peak else None,
        "wbs_codes": sorted({x for c in reds + ambers for x in c["wbs_codes"]}),
        "people_checked": len({c["resource_id"] for c in checks}),
        "over": [{k: c[k] for k in ("resource_id", "name", "month", "util", "booked", "available", "wbs_codes")}
                 for c in reds + ambers],
        "unassigned_steps": unassigned_red + unassigned_amber,
    }
    if peak:
        explanation = (f"Checked {metrics['people_checked']} people in the months they work on this initiative. "
                       f"Peak: {peak['name']} {cal.fmt_hours(peak['booked'])} h of {cal.fmt_hours(peak['available'])}"
                       f" h in {cal.month_label(peak['month'])} ({_pct(peak['util'])}%).")
    else:
        explanation = "No one holds hours on this initiative from this month on."
    return _dim(rag, reasons, metrics, explanation, attention, dim="resources")


# ------------------------------------------------------------------ scope
def scope_dimension(bundle, today) -> dict:
    ini = bundle["initiative"]
    rules = RULES["scope"]
    sa = ini.get("sa_completeness")
    approved_at = ini.get("l2_approved_at")
    changes = []
    if approved_at:
        for ch in bundle.get("scope_changes") or []:
            if not ch.get("ts") or str(ch["ts"]) >= str(approved_at):
                changes.append(ch)
    baseline = ini.get("l2_baseline_hours")
    delta_pct = 0.0
    current = None
    if baseline:
        if bundle.get("components"):
            current = l2_engine.estimate_l2(bundle["components"], bundle.get("component_catalog") or [])["total_hours"]
        else:
            current = ini.get("l2_hours")
        if current is not None:
            delta_pct = round((float(current) - float(baseline)) / float(baseline) * 100.0, 1)

    reasons, attention = [], []
    red = amber = False
    if sa is None:
        amber = True
        reasons.append("SA Completeness not scored yet. Attach the SA document on Pg 1.")
    elif sa < rules["amber_sa"]:
        red = True
        reasons.append(f"SA Completeness {sa}% (below 60%)")
        attention.append(f"Incomplete SA document affecting {_first_code(bundle, 'Estimation') or 'WBS-100'}")
    elif sa < rules["green_sa"]:
        amber = True
        reasons.append(f"SA Completeness {sa}% (below 80%)")
    n = len(changes)
    if n >= rules["red_changes"]:
        red = True
        reasons.append(f"{n} scope changes since L2 approval")
    elif n == 1:
        amber = True
        reasons.append("1 scope change since L2 approval")
    if abs(delta_pct) > rules["red_delta_pct"]:
        red = True
        reasons.append(f"L2 estimate {delta_pct:+.0f}% against the approved baseline")
    elif delta_pct:
        amber = True
        reasons.append(f"L2 estimate {delta_pct:+.0f}% against the approved baseline")
    if red and (n >= rules["red_changes"] or abs(delta_pct) > rules["red_delta_pct"]):
        codes = _codes_for_components(bundle, {c.get("component_code") for c in changes})
        attention.append(f"Scope change since L2 approval affecting {', '.join(codes) or 'the plan'}")
    if not reasons:
        reasons.append(f"SA Completeness {sa}%; no scope change since L2 approval")
    elif not red and not amber:
        reasons.insert(0, f"SA Completeness {sa}%")
    rag = "Red" if red else ("Amber" if amber else "Green")
    metrics = {"sa_completeness": sa, "scope_changes": n, "l2_delta_pct": delta_pct,
               "l2_baseline_hours": baseline, "l2_current_hours": current}
    explanation = (f"SA Completeness {sa if sa is not None else 'not scored'}%; {n} scope change"
                   f"{'s' if n != 1 else ''} since L2 approval; L2 now "
                   f"{cal.fmt_hours(current) + ' h' if current is not None else 'not set'} against a baseline of "
                   f"{cal.fmt_hours(baseline) + ' h' if baseline else 'not set'}.")
    return _dim(rag, reasons, metrics, explanation, attention, dim="scope")


def _first_code(bundle, phase) -> str | None:
    for t in bundle.get("tasks") or []:
        if t.get("phase") == phase:
            return t.get("wbs_code")
    return None


def _codes_for_components(bundle, codes: set) -> list:
    out = []
    comp_ids = {c["id"] for c in bundle.get("components") or [] if c.get("code") in codes}
    for t in bundle.get("tasks") or []:
        if t.get("component_code") in codes or t.get("initiative_component_id") in comp_ids:
            out.append(t["wbs_code"])
    return out


# ------------------------------------------------------------------ dependencies
def _component_tasks(bundle, comp) -> list:
    return [t for t in bundle.get("tasks") or []
            if (t.get("initiative_component_id") is not None and t.get("initiative_component_id") == comp.get("id"))
            or (t.get("component_code") and t.get("component_code") == comp.get("code"))]


def dependencies_dimension(bundle, today) -> dict:
    ini = bundle["initiative"]
    rules = RULES["dependencies"]
    reasons, attention = [], []
    red = amber = False
    pending = 0
    min_bd = None

    for comp in bundle.get("components") or []:
        name = comp.get("name") or comp.get("code")
        ctasks = _component_tasks(bundle, comp)
        codes = ", ".join(t["wbs_code"] for t in ctasks)
        if comp.get("approval") == "Rejected":
            red = True
            reasons.append(f"{name} approval rejected")
            attention.append(f"{name} approval rejected affecting {codes or 'the plan'}")
        elif comp.get("approval") == "Pending":
            pending += 1
            starts = [t["planned_start"] for t in ctasks if t.get("planned_start")]
            if starts:
                need_by = min(starts)
                bd = cal.business_days_after(today, need_by)
                min_bd = bd if min_bd is None else min(min_bd, bd)
                reasons.append(f"{name} approval pending; needed by {cal.fmt_date(need_by)} "
                               f"({bd} business day{'s' if bd != 1 else ''})")
                if bd <= rules["need_by_amber_bd"]:
                    amber = True
            else:
                reasons.append(f"{name} approval pending")

    if ini.get("l2_status") == "Pending approval" and ini.get("l2_submitted_at"):
        waited = cal.business_days_after(ini["l2_submitted_at"], today)
        if waited > rules["l2_pending_amber_bd"]:
            amber = True
            reasons.append(f"L2 approval pending for {waited} business days")

    tasks = bundle.get("tasks") or []
    by_id = {t["id"]: t for t in tasks}
    has_dependants = defaultdict(list)
    for t in tasks:
        for d in t.get("depends_on") or []:
            if d in by_id:
                has_dependants[d].append(t)
    for tid, deps in has_dependants.items():
        t = by_id[tid]
        if _is_open(t) and t.get("planned_end") and cal.to_date(t["planned_end"]) < cal.to_date(today):
            red = True
            waiting = ", ".join(sorted(x["wbs_code"] for x in deps))
            reasons.append(f"{t['wbs_code']} is overdue and {waiting} wait on it")
            attention.append(f"Overdue dependency {t['wbs_code']} affecting {waiting}")
    for t in tasks:
        if t.get("status") == "Blocked":
            amber = True
            reasons.append(f"{t['wbs_code']} is blocked")

    if not reasons:
        reasons.append("All component approvals in; nothing waiting on another step")
    rag = "Red" if red else ("Amber" if amber else "Green")
    metrics = {"pending_approvals": pending, "min_need_by_bd": min_bd}
    explanation = (f"{pending} component approval{'s' if pending != 1 else ''} pending"
                   + (f"; nearest need-by date is {min_bd} business days away" if min_bd is not None else "")
                   + ". Amber when work needing a pending approval starts within 15 business days.")
    return _dim(rag, reasons, metrics, explanation, attention, dim="dependencies")


# ------------------------------------------------------------------ budget
def budget_dimension(bundle, today) -> dict:
    prn = bundle.get("prn")
    rules = RULES["budget"]
    leaves = _leaf_tasks(bundle.get("tasks") or [])
    planned = sum(float(t.get("est_hours") or 0) for t in leaves)
    done = sum(float(t.get("est_hours") or 0) * int(t.get("pct") or 0) / 100.0 for t in leaves)
    completion = (done / planned * 100.0) if planned else 0.0
    if not prn:
        return _dim("Amber", ["No PRN linked. Add the PRN on Pg 1."],
                    {"funded_hours": None, "charged_hours": None, "planned_hours": planned,
                     "burn_minus_complete_pts": None},
                    "Budget needs a PRN with funded hours.", dim="budget")
    funded = float(prn.get("funded_hours") or 0)
    charged = sum(float(c.get("charged_hours") or 0) for c in prn.get("charges") or [])
    burn = (charged / funded * 100.0) if funded else 0.0
    gap = round(burn - completion, 1)
    forecast = charged + (planned - done)

    reasons, attention = [], []
    reasons.append(f"{cal.fmt_hours(charged)} of {cal.fmt_hours(funded)} funded hours charged; "
                   f"plan totals {cal.fmt_hours(planned)} h")
    red = amber = False
    if funded and forecast > funded + 1e-9:
        red = True
        reasons.append(f"Forecast {cal.fmt_hours(forecast)} h exceeds the {cal.fmt_hours(funded)} h funded")
        attention.append(f"{prn.get('prn_code')} forecast exceeds funded hours")
    if gap > rules["red_gap_pts"]:
        red = True
        reasons.append(f"Burn {burn:.0f}% against {completion:.0f}% complete ({gap:.0f} points)")
        if not attention:
            attention.append(f"{prn.get('prn_code')} burn running ahead of delivery")
    elif gap > rules["amber_gap_pts"]:
        amber = True
        reasons.append(f"Burn {burn:.0f}% against {completion:.0f}% complete ({gap:.0f} points)")
    rag = "Red" if red else ("Amber" if amber else "Green")
    metrics = {"funded_hours": funded, "charged_hours": charged, "planned_hours": planned,
               "burn_minus_complete_pts": gap, "burn_pct": round(burn, 1), "complete_pct": round(completion, 1),
               "forecast_hours": round(forecast, 1)}
    explanation = (f"{prn.get('prn_code')}: burn {burn:.0f}% of {cal.fmt_hours(funded)} h, plan {completion:.0f}% "
                   f"complete, gap {gap:.0f} points; forecast {cal.fmt_hours(forecast)} h.")
    return _dim(rag, reasons, metrics, explanation, attention, dim="budget")


# ------------------------------------------------------------------ roll-up
def overall_rag(rags: dict) -> str:
    values = list(rags.values())
    reds = sum(1 for v in values if v == "Red")
    if rags.get("schedule") == "Red" or reds >= 2:
        return "Red"
    if any(v in ("Red", "Amber") for v in values):
        return "Amber"
    return "Green"


def not_scored(bundle, today, reason: str | None = None) -> dict:
    stage = bundle["initiative"].get("stage")
    reason = reason or f"Health is scored from Planning onward; this initiative is at {stage}."
    return {
        "scored": False,
        "overall": None,
        "dimensions": {d: {"rag": None, "reasons": [reason], "metrics": {}, "overridden": False,
                           "rule": RULE_TEXT[d], "explanation": reason} for d in RULES["dimensions"]},
        "attention": [],
        "as_of": cal.iso(today),
        "rule": RULES["overall"],
    }


def compute_health(bundle, today) -> dict:
    """Health payload (docs/contracts.md "Health") for one initiative bundle."""
    ini = bundle["initiative"]
    if ini.get("stage") not in RULES["scored_stages"]:
        return not_scored(bundle, today)
    if not bundle.get("tasks"):
        return not_scored(bundle, today, RULES["no_plan_reason"])

    dims = {
        "schedule": schedule_dimension(bundle, today),
        "resources": resources_dimension(bundle, today),
        "scope": scope_dimension(bundle, today),
        "dependencies": dependencies_dimension(bundle, today),
        "budget": budget_dimension(bundle, today),
    }
    overrides = ini.get("rag_overrides_json") or {}
    attention = []
    watch = []
    for name, d in dims.items():
        computed_attention = d.pop("_attention")
        amber_watch = d.pop("_watch", [])
        d["computed_rag"] = d["rag"]
        ov = overrides.get(name) if isinstance(overrides, dict) else None
        if ov and ov.get("rag") in ("Red", "Amber", "Green"):
            d["rag"] = ov["rag"]
            d["overridden"] = True
            d["override_reason"] = ov.get("reason") or ""
            d["override_by"] = ov.get("by")
            d["override_at"] = ov.get("at")
            if ov["rag"] == "Red":
                if d["computed_rag"] == "Red" and computed_attention:
                    attention.extend(computed_attention)
                else:
                    attention.append(f"{DIM_LABELS[name]} set to Red by the DC PM: {ov.get('reason') or 'no reason'}")
        elif d["rag"] == "Red":
            attention.extend(computed_attention)
        if d["rag"] == "Amber" and d["computed_rag"] == "Amber":
            watch.extend(amber_watch)
    attention.extend(watch)

    rags = {k: v["rag"] for k, v in dims.items()}
    return {
        "scored": True,
        "overall": overall_rag(rags),
        "dimensions": dims,
        "attention": list(dict.fromkeys(attention)),
        "attention_rule": RULES["attention_rule"],
        "as_of": cal.iso(today),
        "rule": RULES["overall"],
    }
