"""L2 estimate: dev hours from the Change Summary plus fixed uplifts, contingency, rounding, T-shirt and range."""
from __future__ import annotations

import math

from app.engines import calendar as cal

RULES = {
    "architecture_pct": 0.10,
    "qa_pct": 0.35,
    "pm_release_pct": 0.10,
    "contingency_pct": 0.15,
    "round_to": 50,
    "range_pct": 0.25,
    # (upper bound inclusive, size); anything above the last bound is XL.
    "tshirt": ((99.999, "XS"), (300, "S"), (700, "M"), (1500, "L")),
    "complexities": ("Low", "Medium", "High"),
}


def _round_half_up(x: float, step: float = 1.0) -> float:
    return math.floor(x / step + 0.5) * step


def tshirt(total_hours: float) -> str:
    for upper, size in RULES["tshirt"]:
        if total_hours <= upper:
            return size
    return "XL"


def _catalog_index(catalog) -> tuple[dict, dict]:
    by_code, by_id = {}, {}
    for c in catalog or []:
        by_code[c.get("code")] = c
        if c.get("id") is not None:
            by_id[c["id"]] = c
    return by_code, by_id


def component_hours(component: dict, catalog_row: dict | None) -> float:
    """Est. hours on the Change Summary row, else the catalogue base hours for its complexity."""
    if component.get("est_hours") is not None:
        return float(component["est_hours"])
    if not catalog_row:
        return 0.0
    complexity = (component.get("complexity") or "Medium").lower()
    return float(catalog_row.get(f"base_hours_{complexity}") or 0)


def estimate_l2(components, catalog) -> dict:
    """L2Estimate for Change Summary rows.

    components: [{code|component_code|component_id, complexity, est_hours?, name?}]
    catalog: dc_components rows with base_hours_low/medium/high.
    """
    by_code, by_id = _catalog_index(catalog)
    rows = []
    for comp in components or []:
        code = comp.get("code") or comp.get("component_code")
        cat = by_code.get(code) or by_id.get(comp.get("component_id"))
        if cat and not code:
            code = cat.get("code")
        hours = component_hours(comp, cat)
        rows.append({
            "code": code,
            "name": comp.get("name") or (cat or {}).get("name") or code,
            "complexity": comp.get("complexity") or "Medium",
            "hours": round(hours, 1),
            "catalogue_hours": float((cat or {}).get(f"base_hours_{(comp.get('complexity') or 'Medium').lower()}") or 0),
        })

    dev = round(sum(r["hours"] for r in rows), 1)
    arch = _round_half_up(dev * RULES["architecture_pct"])
    qa = _round_half_up(dev * RULES["qa_pct"])
    pm = _round_half_up(dev * RULES["pm_release_pct"])
    subtotal = dev + arch + qa + pm
    contingency = _round_half_up(subtotal * RULES["contingency_pct"])
    raw_total = subtotal * (1 + RULES["contingency_pct"])
    total = _round_half_up(raw_total, RULES["round_to"])
    rounding = round(total - subtotal - contingency, 1)
    low = _round_half_up(total * (1 - RULES["range_pct"]))
    high = _round_half_up(total * (1 + RULES["range_pct"]))
    size = tshirt(total)

    h = cal.fmt_hours
    steps = [
        f"Development: {' + '.join(h(r['hours']) for r in rows) or '0'} = {h(dev)} h",
        f"Architecture 10% of development = {h(arch)} h",
        f"QA 35% of development = {h(qa)} h",
        f"PM / Release 10% of development = {h(pm)} h",
        f"Subtotal = {h(subtotal)} h",
        f"Contingency 15% of subtotal = {h(contingency)} h (subtotal plus contingency {h(round(raw_total, 1))} h)",
        (f"Rounding to the nearest 50 h {'+' if rounding >= 0 else '−'}{h(abs(rounding))} h = {h(total)} h, "
        f"T-shirt {size}"),
        f"Range ±25% = {h(low)}–{h(high)} h",
    ]
    warnings = [] if rows else ["No DC components yet. Add the Change Summary to calculate the L2 estimate."]
    return {
        "dev_hours": dev,
        "architecture_hours": arch,
        "qa_hours": qa,
        "pm_release_hours": pm,
        "subtotal": subtotal,
        "contingency_hours": contingency,
        "rounding_hours": rounding,
        "total_hours": total,
        "low_hours": low,
        "high_hours": high,
        "tshirt": size,
        "by_component": [{k: r[k] for k in ("code", "name", "complexity", "hours")} for r in rows],
        "by_phase": [
            {"phase": "Development", "hours": dev},
            {"phase": "Architecture", "hours": arch},
            {"phase": "QA", "hours": qa},
            {"phase": "PM / Release", "hours": pm},
            {"phase": "Contingency", "hours": contingency},
            {"phase": "Rounding", "hours": rounding},
        ],
        "steps": steps,
        "warnings": warnings,
        "rule": ("Development = sum of DC component hours by complexity. Add Architecture 10%, QA 35% and "
                 "PM / Release 10% of development, then 15% contingency on the subtotal, rounded to the nearest "
                 "50 h. T-shirt: XS under 100, S 100–300, M 301–700, L 701–1,500, XL over 1,500. Range ±25%."),
    }
