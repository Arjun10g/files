"""SA Completeness: a 9-section checklist detected from SA document headings. completeness = floor(found / 9 × 100)."""
from __future__ import annotations

import re

RULES = {
    "max_heading_chars": 90,
    "max_heading_words": 10,
    # (section shown to users, heading patterns matched at the start of a heading line)
    "sections": (
        ("Business context", (r"(business )?context\b", r"background\b", r"overview\b", r"problem statement\b",
                              r"purpose\b", r"executive summary\b")),
        ("Scope", (r"(project |solution )?scope\b", r"in[- ]scope\b", r"out[- ]of[- ]scope\b")),
        ("Impacted components", (r"impacted (dc )?(components|systems|applications)\b",
                                 r"affected (components|systems|applications)\b", r"(dc )?components impacted\b",
                                 r"systems impacted\b", r"component impact\b")),
        ("Integration and sequence", (r"integration\b", r"sequence\b", r"interaction(s)?\b", r"interfaces?\b",
                                      r"end[- ]to[- ]end flow\b")),
        ("Non-functional requirements", (r"non[- ]?functional\b", r"nfrs?\b", r"performance and availability\b",
                                         r"service levels?\b")),
        ("Security", (r"security\b", r"threat model\b", r"access control\b")),
        ("Data", (r"data\b",)),
        ("Backout plan", (r"back[- ]?out\b", r"roll[- ]?back\b", r"fallback plan\b", r"reversal plan\b")),
        ("Open questions", (r"open (items|questions|issues|points)\b", r"outstanding (items|questions)\b",
                            r"assumptions and open\b", r"questions\b", r"tbds?\b")),
    ),
}

_NUMBERING = re.compile(r"^\s*(#{1,6}\s*)?(\*\*)?\s*(section\s+)?(§\s*)?([0-9]+(\.[0-9]+)*[.)]?|[ivx]+[.)]|[a-h][.)])?\s*",
                        re.IGNORECASE)
_SECTION_NUMBER = re.compile(r"^\s*(section\s+\d+|§\s*\d+|\d+(\.\d+)*[.)]?\s+\S)", re.IGNORECASE)
_AUTHOR = re.compile(r"author\s*[:\-–]\s*([^\n|·;,]+)", re.IGNORECASE)
_VERSION = re.compile(r"\bversion\s*[:\-–]?\s*v?\s*([0-9]+(?:\.[0-9]+)*)", re.IGNORECASE)
_VERSION_SHORT = re.compile(r"\bv([0-9]+\.[0-9]+(?:\.[0-9]+)?)\b", re.IGNORECASE)


def _heading_text(line: str) -> str | None:
    """Heading text when the line has heading form, else None.

    Heading form: a markdown `#` line, a numbered section line ("3.", "3.2", "§3", "Section 3:"), a bold line, or a
    short line that starts with a capital and has no terminal sentence punctuation (how .docx and .pdf headings
    arrive as plain lines). In every form the text is at most ten words and does not end like a sentence, so body
    sentences such as "Rollback is not defined yet." never count.
    """
    raw = line.strip()
    if not raw or len(raw) > RULES["max_heading_chars"]:
        return None
    marked = raw.startswith(("#", "**")) or bool(_SECTION_NUMBER.match(raw))
    text = _NUMBERING.sub("", raw, count=1).strip(" *_\t")
    if not text:
        return None
    if text.endswith((".", "!", "?", ";", ",")) or len(text.split()) > RULES["max_heading_words"]:
        return None
    if not marked:
        first = next((ch for ch in text if ch.isalpha()), "")
        if not first.isupper():
            return None
    return text.rstrip(" :-–—").lower() or None


def sections_present(text: str) -> list[str]:
    """Section names whose heading appears in the document, in checklist order."""
    headings = [h for h in (_heading_text(line) for line in (text or "").splitlines()) if h]
    found = []
    for name, patterns in RULES["sections"]:
        regs = [re.compile("^" + p, re.IGNORECASE) for p in patterns]
        if any(r.search(h) for h in headings for r in regs):
            found.append(name)
    return found


def _author(text: str) -> str | None:
    m = _AUTHOR.search(text or "")
    if not m:
        return None
    value = re.sub(r"\(.*?\)", "", m.group(1)).strip(" .")
    return value or None


def _version(text: str) -> str | None:
    m = _VERSION.search(text or "") or _VERSION_SHORT.search(text or "")
    return m.group(1) if m else None


def score(text: str) -> dict:
    """{completeness, sections_found, missing:[str], author, version} for SA document text."""
    names = [n for n, _ in RULES["sections"]]
    found = sections_present(text)
    total = len(names)
    return {
        "completeness": (len(found) * 100) // total,
        "sections_found": len(found),
        "sections_total": total,
        "found": found,
        "missing": [n for n in names if n not in found],
        "author": _author(text),
        "version": _version(text),
        "rule": "Nine sections, equal weight: Business context, Scope, Impacted components, Integration and "
                "sequence, Non-functional requirements, Security, Data, Backout plan, Open questions. "
                "Completeness = sections found ÷ 9, rounded down.",
    }
