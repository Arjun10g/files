"""Reminder scheduler: "Action required by" nudges, L2 approval reminders with escalation, CRQ notices.

Pure: takes a state snapshot and `today`, returns notification dicts with dedupe keys (rule:entity:period).
The caller inserts the ones whose dedupe key does not exist yet; nothing is ever emailed.
"""
from __future__ import annotations

from app.engines import calendar as cal

RULES = {
    "sa_every_bd": 2,
    "approval_every_bd": 2,
    "cc_dc_pm_from": 3,              # the 3rd "Action required by" reminder copies the DC PM
    "l2_every_bd": 3,
    "l2_escalate_after": 3,          # reminders after the 3rd go to the Delivery Lead
    "pre_planning_stages": ("Intake", "Grooming", "Solution", "Estimation"),
    "sa_waiting_stages": ("Solution", "Estimation"),
    "cr_window_days": 14,
    "validation_before_bd": 2,
    "backout_before_bd": 5,
}


def due_dates(since, every_bd: int, today) -> tuple[list, object]:
    """([reminder dates on or before today], next reminder date after today) for a wait that began on `since`."""
    since, today = cal.to_date(since), cal.to_date(today)
    past = []
    k = 1
    while True:
        d = cal.add_business_days(since, k * every_bd)
        if d > today:
            return past, d
        past.append(d)
        k += 1


def next_reminder(since, every_bd: int, today):
    return due_dates(since, every_bd, today)[1]


def _window(past: list, nxt, today) -> list[tuple[int, object]]:
    """(reminder number, date) pairs to queue now: today's reminder if one falls today, plus the next one.
    Earlier reminders are history; re-running the scheduler never back-fills them."""
    today = cal.to_date(today)
    out = [(k, d) for k, d in enumerate(past, start=1) if d == today]
    return out + [(len(past) + 1, nxt)]


def _note(rule, key, *, initiative, to_id, to_name, subject, body, due, trigger, entity_type, entity_id,
          cc=None, level=0, action_by=None) -> dict:
    return {
        "rule": rule,
        "dedupe_key": key,
        "initiative_id": initiative.get("id") if initiative else None,
        "entity_type": entity_type,
        "entity_id": entity_id,
        "to_resource_id": to_id,
        "to_name": to_name,
        "cc_names": [c for c in (cc or []) if c and c != to_name],
        "subject": subject,
        "body": body,
        "trigger_event": trigger,
        "action_required_by": cal.iso(action_by or due),
        "due_at": cal.iso(due),
        "escalation_level": level,
    }


def _sa_items(ini, today) -> list:
    stage = ini.get("stage")
    if stage not in RULES["pre_planning_stages"] or not ini.get("dc_sa_id"):
        return []
    sa = ini.get("sa_completeness")
    attached = bool(ini.get("sa_attached"))
    if sa is not None and sa >= 100:
        return []
    if not attached and stage not in RULES["sa_waiting_stages"]:
        return []
    since = ini.get("sa_since") or ini.get("created_at") or today
    past, nxt = due_dates(since, RULES["sa_every_bd"], today)
    out = []
    missing = ", ".join(ini.get("sa_missing") or [])
    for k, d in _window(past, nxt, today):
        cc = [ini.get("dc_pm_name")] if k >= RULES["cc_dc_pm_from"] else []
        score_txt = f"SA Completeness {sa}%" if sa is not None else "SA document not attached"
        out.append(_note(
            "sa_action_required", f"sa_action_required:initiative:{ini['id']}:{d.isoformat()}",
            initiative=ini, to_id=ini.get("dc_sa_id"), to_name=ini.get("dc_sa_name") or "DC SA",
            subject=f"Action required by {cal.fmt_day(d)}: SA document for {ini['rddc']}",
            body=(f"{ini['rddc']} {ini.get('name') or ''} is waiting on the SA document. {score_txt}"
                  + (f"; missing: {missing}." if missing else ".")
                  + f" Please update it by {cal.fmt_day_long(d)}. Reminder {k}."),
            due=d, trigger=score_txt, entity_type="initiative", entity_id=ini["id"], cc=cc,
            level=1 if cc else 0,
        ))
    return out


def _approval_items(ini, today) -> list:
    if ini.get("stage") == "Closed":
        return []
    out = []
    for comp in ini.get("components") or []:
        if comp.get("approval") != "Pending" or not comp.get("component_lead_id"):
            continue
        since = comp.get("since") or ini.get("created_at") or today
        past, nxt = due_dates(since, RULES["approval_every_bd"], today)
        for k, d in _window(past, nxt, today):
            cc = [ini.get("dc_pm_name")] if k >= RULES["cc_dc_pm_from"] else []
            out.append(_note(
                "component_approval", f"component_approval:component:{comp['id']}:{d.isoformat()}",
                initiative=ini, to_id=comp["component_lead_id"], to_name=comp.get("component_lead_name") or "Lead",
                subject=f"Action required by {cal.fmt_day(d)}: {comp.get('name')} approval for {ini['rddc']}",
                body=(f"{ini['rddc']} {ini.get('name') or ''} needs your approval for {comp.get('name')}. "
                      f"Approve or reject the Change Summary row by {cal.fmt_day_long(d)}. Reminder {k}."),
                due=d, trigger=f"{comp.get('name')} approval pending", entity_type="initiative_component",
                entity_id=comp["id"], cc=cc, level=1 if cc else 0,
            ))
    return out


def l2_reminder_count(ini, today) -> int:
    if ini.get("l2_status") != "Pending approval" or not ini.get("l2_submitted_at"):
        return 0
    return len(due_dates(ini["l2_submitted_at"], RULES["l2_every_bd"], today)[0])


def _l2_items(ini, today, delivery_lead) -> list:
    if ini.get("l2_status") != "Pending approval" or not ini.get("l2_submitted_at"):
        return []
    past, nxt = due_dates(ini["l2_submitted_at"], RULES["l2_every_bd"], today)
    out = []
    hours = cal.fmt_hours(ini.get("l2_hours") or 0)
    for k, d in _window(past, nxt, today):
        escalate = k > RULES["l2_escalate_after"] and delivery_lead
        if escalate:
            out.append(_note(
                "l2_escalation", f"l2_escalation:initiative:{ini['id']}:{d.isoformat()}",
                initiative=ini, to_id=delivery_lead.get("id"), to_name=delivery_lead.get("name"),
                subject=f"Escalation: L2 approval for {ini['rddc']} waiting since {cal.fmt_day(ini['l2_submitted_at'])}",
                body=(f"The L2 estimate for {ini['rddc']} {ini.get('name') or ''} ({hours} h) has waited for approval "
                      f"through {k - 1} reminders to {ini.get('requestor_name') or 'the requestor'}. "
                      f"Please follow up by {cal.fmt_day_long(d)}."),
                due=d, trigger=f"L2 pending approval, reminder {k}", entity_type="initiative", entity_id=ini["id"],
                cc=[ini.get("requestor_name"), ini.get("dc_pm_name")], level=k - RULES["l2_escalate_after"],
            ))
        else:
            out.append(_note(
                "l2_approval", f"l2_approval:initiative:{ini['id']}:{d.isoformat()}",
                initiative=ini, to_id=ini.get("requestor_id"), to_name=ini.get("requestor_name") or "Requestor",
                subject=f"Action required by {cal.fmt_day(d)}: approve the L2 estimate for {ini['rddc']}",
                body=(f"The L2 estimate for {ini['rddc']} {ini.get('name') or ''} is {hours} h "
                      f"(T-shirt {ini.get('l2_tshirt') or 'not set'}). Approve or reject it by "
                      f"{cal.fmt_day_long(d)}. Reminder {k}."),
                due=d, trigger="L2 pending approval", entity_type="initiative", entity_id=ini["id"],
                cc=[ini.get("dc_pm_name")], level=0,
            ))
    return out


def _cr_items(cr, today) -> list:
    out = []
    start = cal.to_date(cr.get("crq_start"))
    if start is None:
        return out
    today = cal.to_date(today)
    days_to = (start - today).days
    ini = {"id": cr.get("initiative_id")}
    label = cr.get("crq_number") or f"CRQ for {cr.get('rddc')}"
    flags = (cr.get("compliance") or {}).get("flags") or []
    lead_id = cr.get("cms_lead_id") or cr.get("rel_lead_id")
    lead_name = cr.get("cms_lead_name") or cr.get("rel_lead_name") or "CMS Lead"
    if flags and 0 <= days_to <= RULES["cr_window_days"]:
        week = cal.iso_week(today)
        out.append(_note(
            "cr_noncompliance", f"cr_noncompliance:cr:{cr['id']}:{week}", initiative=ini,
            to_id=lead_id, to_name=lead_name,
            subject=f"{label} has {len(flags)} compliance flag{'s' if len(flags) != 1 else ''} before {cal.fmt_day(start)}",
            body=f"{label} ({cr.get('rddc')}) starts {cal.fmt_day_long(start)}. Open flags: "
                 + "; ".join(f.get("message", "") for f in flags) + ".",
            due=today, trigger="Weekly change review", entity_type="change_request", entity_id=cr["id"],
            cc=[cr.get("rel_lead_name")], action_by=cal.add_business_days(start, -RULES["validation_before_bd"]),
        ))
    bd_to = cal.business_days_after(today, start)
    validation_open = any(
        cr.get(f"{k}_validation_status") != "Completed" or not cr.get(f"{k}_validation_attachment_id")
        for k in ("tech", "biz"))
    implemented = cr.get("implementation_status") == "Implemented"
    if validation_open and (0 <= bd_to <= RULES["validation_before_bd"] or implemented):
        to_id = cr.get("resource_id") or lead_id
        to_name = cr.get("resource_name") or lead_name
        out.append(_note(
            "validation_missing", f"validation_missing:cr:{cr['id']}", initiative=ini, to_id=to_id, to_name=to_name,
            subject=f"Validation evidence needed for {label}",
            body=(f"Attach technical and business validation evidence for {label} ({cr.get('rddc')}); "
                  f"the change window is {cal.fmt_day_long(start)}."),
            due=today, trigger="Validation evidence missing", entity_type="change_request", entity_id=cr["id"],
            cc=[lead_name],
        ))
    if not cr.get("backout_attachment_id") and 0 <= bd_to <= RULES["backout_before_bd"]:
        out.append(_note(
            "backout_missing", f"backout_missing:cr:{cr['id']}", initiative=ini, to_id=lead_id, to_name=lead_name,
            subject=f"Backout plan not attached for {label}",
            body=(f"{label} ({cr.get('rddc')}) runs {cal.fmt_day_long(start)} without a backout plan. "
                  "Attach it on Pg 4."),
            due=today, trigger="Backout plan not attached", entity_type="change_request", entity_id=cr["id"],
            cc=[cr.get("rel_lead_name")],
        ))
    return out


def due_reminders(state: dict, today) -> list[dict]:
    """All reminders that should exist on `today` (latest due one and the next upcoming one per wait).

    state = {initiatives:[{id, rddc, name, stage, created_at, dc_sa_id, dc_sa_name, dc_pm_name, requestor_id,
                           requestor_name, sa_completeness, sa_missing, sa_attached, sa_since, l2_status,
                           l2_submitted_at, l2_hours, l2_tshirt,
                           components:[{id, name, approval, component_lead_id, component_lead_name, since}]}],
             change_requests:[{id, initiative_id, rddc, crq_number, crq_start, ..., compliance:{flags}}],
             delivery_lead:{id, name}|None}
    """
    out = []
    for ini in state.get("initiatives") or []:
        out.extend(_sa_items(ini, today))
        out.extend(_approval_items(ini, today))
        out.extend(_l2_items(ini, today, state.get("delivery_lead")))
    for cr in state.get("change_requests") or []:
        out.extend(_cr_items(cr, today))
    seen, unique = set(), []
    for n in out:
        if n["dedupe_key"] not in seen:
            seen.add(n["dedupe_key"])
            unique.append(n)
    return unique
