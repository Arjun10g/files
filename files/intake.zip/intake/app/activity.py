"""Activity log (owner B1). Every write records who did what, as which persona.

The acting persona comes from app_settings.persona (top-bar persona switcher). The actor is the person that persona
stands for on the initiative in question (DC PM -> its DC PM, Dev Lead -> its tech lead, Requestor -> its requestor).
"""
from __future__ import annotations

from app import db
from app.today import now_iso

DEFAULT_PERSONA = "DC PM"

VERBS = {
    "create": "created", "update": "updated", "delete": "deleted", "scope_change": "changed the scope of",
    "approve": "approved", "reject": "rejected", "upload": "attached", "reset": "reset", "send": "sent",
    "ack": "acknowledged", "dismiss": "dismissed", "baseline": "re-baselined", "move": "moved",
    "ai_accept": "accepted the AI proposal for", "ai_reject": "rejected the AI proposal for", "submit": "submitted",
    "fast_forward": "fast-forwarded",
}
ENTITY_LABELS = {
    "initiative": "initiative", "initiative_component": "DC component", "task": "WBS step", "attachment": "document",
    "change_request": "change request", "risk": "risk", "grooming_session": "grooming session",
    "grooming_slot": "grooming slot", "notification": "Outbox message", "decision": "decision",
    "lesson": "lesson learned", "meeting_note": "meeting notes", "document": "document", "resource": "resource",
    "availability": "availability", "allocation": "allocation", "skills": "skills", "settings": "settings",
    "demo": "demo data", "plan": "project plan",
}


def current_persona() -> str:
    row = db.query_one("SELECT value FROM app_settings WHERE key = 'persona'")
    return (row or {}).get("value") or DEFAULT_PERSONA


def _first_by_role(role_like: str) -> str | None:
    row = db.query_one("SELECT name FROM resources WHERE role LIKE ? AND active = 1 ORDER BY id LIMIT 1", (role_like,))
    return row["name"] if row else None


def actor_name(initiative_id=None, persona: str | None = None) -> str:
    """The person acting under the current persona, in the context of an initiative when given."""
    persona = persona or current_persona()
    ini = None
    if initiative_id:
        ini = db.query_one(
            "SELECT i.requestor, rq.name AS requestor_name, pm.name AS dc_pm_name, tl.name AS tech_lead_name "
            "FROM initiatives i LEFT JOIN resources rq ON rq.id = i.requestor_id "
            "LEFT JOIN resources pm ON pm.id = i.dc_pm_id LEFT JOIN resources tl ON tl.id = i.tech_lead_id "
            "WHERE i.id = ?", (initiative_id,))
    ini = ini or {}
    if persona == "DC PM":
        return ini.get("dc_pm_name") or _first_by_role("DC PM") or "DC PM"
    if persona == "Dev Lead":
        return ini.get("tech_lead_name") or _first_by_role("%Tech Lead%") or "Dev Lead"
    if persona == "Requestor":
        return ini.get("requestor_name") or ini.get("requestor") or "Requestor"
    if persona == "STO":
        return "STO Board"
    if persona == "Account Manager":
        return _first_by_role("Account Manager") or "Account Manager"
    return "demo.user"


def log_activity(entity_type: str, entity_id, action: str, detail: dict | None = None, initiative_id=None) -> int:
    """Append one activity row. `detail` is stored as JSON; put a short human label in detail['label']."""
    persona = current_persona()
    return db.insert("activity_log", {
        "ts": now_iso(),
        "actor": actor_name(initiative_id, persona),
        "persona": persona,
        "entity_type": entity_type,
        "entity_id": entity_id,
        "initiative_id": initiative_id,
        "action": action,
        "detail_json": db.to_json(detail or {}),
    })


def summarize(row: dict) -> str:
    """One readable sentence for the activity feed."""
    detail = row.get("detail_json")
    if isinstance(detail, str):
        detail = db.from_json(detail, {}) or {}
    detail = detail or {}
    if detail.get("summary"):
        return str(detail["summary"])
    verb = VERBS.get(row.get("action") or "", (row.get("action") or "updated").replace("_", " "))
    entity = ENTITY_LABELS.get(row.get("entity_type") or "", (row.get("entity_type") or "").replace("_", " "))
    label = detail.get("label")
    target = f"{entity} {label}".strip() if label else entity
    return f"{row.get('actor') or 'demo.user'} {verb} {target}".strip()
