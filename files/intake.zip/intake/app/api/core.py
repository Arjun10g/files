"""Core endpoints (owner B1): health, lookups, settings, demo reset, fast-forward hero, activity, release trains,
DC intakes. Contracts: docs/contracts.md §2 "core".
"""
from __future__ import annotations

import logging
import sqlite3
from datetime import timedelta

from flask import Blueprint, current_app, request

from app import db, errors, repo
from app.activity import actor_name, log_activity, summarize
from app.api._shared import Fields, json_body, listed, valid_date
from app.config import AI_MODES, AI_SPEEDS
from app.today import get_today

bp = Blueprint("core", __name__, url_prefix="/api")
log = logging.getLogger("bmo.core")

INT_CATEGORIES = {"priority", "risk_severity", "risk_likelihood", "skill_level"}
HIDDEN_CATEGORIES = {"holiday", "change_freeze"}
PERSONAS = ("DC PM", "Dev Lead", "Requestor", "STO", "Account Manager")
HERO_INTAKE = "DCI-3391"


# ------------------------------------------------------------------ database busy (demo reset in progress)
@bp.app_errorhandler(sqlite3.OperationalError)
def _database_busy(err: sqlite3.OperationalError):
    text = str(err).lower()
    if any(k in text for k in ("no such table", "locked", "busy", "schema has changed")):
        return errors.error_response("unavailable", "The demo data is being reset. Try again in a moment.", 503)
    log.exception("Database error: %s", err)
    return errors.error_response("internal", "Something went wrong. Try again, or reset the demo from Settings.", 500)


# ------------------------------------------------------------------ helpers
def effective_ai_mode() -> str:
    mode = current_app.config["AI_MODE"]
    if db.db_ready():
        mode = repo.setting("ai_mode", mode)
    if mode == "simulated" or not current_app.config["HAS_API_KEY"]:
        return "simulated"
    return "live"


def freeze_window() -> dict:
    rows = db.query("SELECT value, label FROM lookups WHERE category = 'change_freeze'")
    bounds = {r["label"]: r["value"] for r in rows}
    return {"start": bounds.get("start"), "end": bounds.get("end")}


def holidays() -> list[str]:
    return [r["value"] for r in db.query("SELECT value FROM lookups WHERE category = 'holiday' ORDER BY value")]


def fiscal_quarters() -> list[dict]:
    """Quarters of the planning fiscal year (the FY that next month falls in; FY27 on 19 Oct 2026)."""
    cal = repo.optional_module("app.engines.calendar")
    nxt = (get_today().replace(day=1) + timedelta(days=32)).replace(day=1)
    fy_num = nxt.year + 1 if nxt.month >= 11 else nxt.year
    if cal is not None:
        return cal.fiscal_quarters(f"FY{fy_num % 100:02d}")
    labels = {"Q1": "Nov–Jan", "Q2": "Feb–Apr", "Q3": "May–Jul", "Q4": "Aug–Oct"}
    out, first = [], f"{fy_num - 1:04d}-11"
    for i in range(4):
        start = repo.shift_month(first, i * 3)
        out.append({"fy": f"FY{fy_num % 100:02d}", "q": f"Q{i + 1}", "label": labels[f"Q{i + 1}"],
                    "months": [repo.shift_month(start, k) for k in range(3)]})
    return out


ENGINEERING_TEAMS = ("EAPI", "CIAM", "SRE", "Mobile", "Web")


def role_options(resources: list[dict]) -> dict:
    """Resource ids that make sense for each person field, so dropdowns only offer the relevant roles."""
    def ids(pred):
        return [r["id"] for r in resources if pred(r)]
    dc_pm = ids(lambda r: r["role"] == "DC PM")
    return {
        "dc_pm_id": dc_pm, "pm_id": dc_pm,
        "assigned_to_id": dc_pm + ids(lambda r: r["role"] == "Delivery Lead"),
        "dc_sa_id": ids(lambda r: r["team"] == "DC SA"),
        "tech_lead_id": ids(lambda r: r["team"] in ENGINEERING_TEAMS),
        "requestor_id": ids(lambda r: r["role"] == "Requestor"),
        "cms_lead_id": ids(lambda r: r["role"] == "CMS Lead"),
        "rel_lead_id": ids(lambda r: r["role"] == "Rel Lead"),
        "resource_id": ids(lambda r: r["capacity_eligible"] == 1),
        "component_lead_id": ids(lambda r: r["team"] in ENGINEERING_TEAMS),
    }


def settings_payload() -> dict:
    cfg = current_app.config
    return {
        "ai_mode": repo.setting("ai_mode", cfg["AI_MODE"]),
        "ai_speed": repo.setting("ai_speed", cfg["AI_SPEED"]),
        "demo_today": get_today().isoformat(),
        "persona": repo.setting("persona", "DC PM"),
        "live_available": bool(cfg["HAS_API_KEY"]),
        "model_heavy": cfg["AI_MODEL_HEAVY"],
        "model_fast": cfg["AI_MODEL_FAST"],
    }


def _put_setting(key: str, value: str) -> None:
    db.execute("INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
               (key, value))


# ------------------------------------------------------------------ health, lookups, settings
@bp.get("/health")
def health():
    ready = db.db_ready()
    return {
        "status": "ok",
        "db": ready,
        "ai_mode": effective_ai_mode(),
        "model": current_app.config["AI_MODEL_HEAVY"],
        "today": get_today().isoformat() if ready else current_app.config["TODAY"],
        "version": current_app.config["APP_VERSION"],
        "modules": list(getattr(current_app, "registered_api_modules", [])),
    }


@bp.get("/lookups")
def lookups():
    out: dict = {}
    for r in db.query("SELECT category, value, label FROM lookups ORDER BY category, sort"):
        if r["category"] in HIDDEN_CATEGORIES:
            continue
        value = int(r["value"]) if r["category"] in INT_CATEGORIES else r["value"]
        out.setdefault(r["category"], []).append({"value": value, "label": r["label"] or r["value"]})
    out["components"] = db.query(
        "SELECT c.id, c.code, c.name, c.team, c.component_lead_id, r.name AS component_lead_name "
        "FROM dc_components c LEFT JOIN resources r ON r.id = c.component_lead_id ORDER BY c.id")
    out["resources"] = db.query(
        "SELECT id, name, role, team, team_label, capacity_eligible FROM resources WHERE active = 1 ORDER BY id")
    out["roles"] = sorted({r["role"] for r in out["resources"]})
    out["role_options"] = role_options(out["resources"])
    out["release_trains"] = db.query("SELECT code, train_date, status FROM release_trains ORDER BY train_date")
    out["fiscal_quarters"] = fiscal_quarters()
    out["freeze"] = freeze_window()
    out["holidays"] = holidays()
    return out


@bp.get("/settings")
def get_settings():
    return settings_payload()


@bp.put("/settings")
def put_settings():
    data = json_body()
    f = Fields(data)
    f.enum("ai_mode", AI_MODES, label="AI mode")
    f.enum("ai_speed", AI_SPEEDS, label="response speed")
    f.enum("persona", PERSONAS, label="persona")
    f.date("demo_today")
    values = {k: v for k, v in f.check().items() if v is not None}
    if values.get("ai_mode") == "live" and not current_app.config["HAS_API_KEY"]:
        raise errors.validation("Live Claude is not configured on this machine.",
                                {"ai_mode": "Live Claude is not configured on this machine."})
    if not values:
        raise errors.validation("Nothing to update.", {})
    today_changed = "demo_today" in values and values["demo_today"] != get_today().isoformat()
    with db.transaction():
        for key, value in values.items():
            _put_setting(key, str(value))
        log_activity("settings", None, "update", {"label": ", ".join(sorted(values)), "changes": values})
        if today_changed:
            derive = repo.optional_module("app.services.derive")
            if derive is not None and hasattr(derive, "refresh_all_health"):
                derive.refresh_all_health()
    return settings_payload()


# ------------------------------------------------------------------ admin
@bp.post("/admin/reset")
def admin_reset():
    from app.seed.seed import reset_database

    cfg = current_app.config
    counts = reset_database(db.get_db(), upload_dir=cfg["UPLOAD_DIR"], today=cfg["TODAY"], ai_mode=cfg["AI_MODE"])
    log_activity("demo", None, "reset", {"summary": f"{actor_name()} reset the demo data to the starting sample"})
    return {"ok": True, "counts": counts}


def _internal(method: str, path: str, body: dict | None = None) -> dict:
    """Call one of this app's own endpoints in-process (used for steps owned by other modules)."""
    resp = current_app.test_client().open(path, method=method, json=body or {})
    data = resp.get_json(silent=True) or {}
    if resp.status_code >= 400:
        err = data.get("error") or {}
        raise errors.ApiError(err.get("code") or "internal", err.get("message") or "That step could not finish.",
                              resp.status_code, err.get("details") or {})
    return data


def _with_persona(persona: str, fn):
    previous = repo.setting("persona", "DC PM")
    _put_setting("persona", persona)
    try:
        return fn()
    finally:
        _put_setting("persona", previous)


def _ai_step(feature: str, initiative_id: int) -> int:
    provider = repo.optional_module("app.ai.provider")
    applier = repo.optional_module("app.ai.apply")
    if provider is None or applier is None:
        raise errors.ApiError("ai_error", "The AI layer is not installed on this machine.", 502)
    run = provider.run_feature(feature, initiative_id, {}, force_mode="simulated")
    run_id = run.get("ai_run_id") if isinstance(run, dict) else getattr(run, "ai_run_id", None)
    if run_id is None:
        raise errors.ApiError("ai_error", "The AI step did not return a proposal.", 502)
    applier.apply_run(run_id)
    return run_id


def _sample_sa_file():
    from app.seed.seed import FILES_DIR

    for name in ("SA_US_API_Enhancement_v1.2.docx", "SA_US_API_Enhancement_v1.2.pdf", "SA_US_API_Enhancement_v1.2.md"):
        path = FILES_DIR / name
        if path.is_file():
            return path
    return None


@bp.post("/admin/fast-forward-hero")
def fast_forward_hero():
    """Run the hero pipeline server-side in simulated mode, continuing from the first missing step."""
    from app.api import initiatives as ini_api

    steps: list[dict] = []

    def record(step, fn):
        try:
            result = fn() or {}
            steps.append({"step": step, "ok": True, **result})
            return True
        except errors.ApiError as exc:
            steps.append({"step": step, "ok": False, "message": exc.message})
        except Exception:  # keep the presenter's recovery button from ever showing a server error
            log.exception("Fast-forward step failed: %s", step)
            steps.append({"step": step, "ok": False, "message": "This step could not finish. Try again."})
        return False

    hero = db.query_one("SELECT id FROM initiatives WHERE dc_intake = ? ORDER BY id LIMIT 1", (HERO_INTAKE,))
    state = {"id": hero["id"] if hero else None}

    def create():
        if state["id"]:
            return {"message": "Already created"}
        intake = db.query_one("SELECT * FROM dc_intakes WHERE code = ?", (HERO_INTAKE,))
        if intake is None:
            raise errors.not_found("DC intake", HERO_INTAKE)

        def person(name):
            row = db.query_one("SELECT id FROM resources WHERE name = ?", (name,))
            return row["id"] if row else None

        payload = {"dc_intake": HERO_INTAKE, "name": intake["name"], "lob": intake["lob"], "priority": intake["priority"],
                   "requestor": intake["requestor"], "requested_go_live": intake["requested_go_live"],
                   "description": intake["description"], "dc_pm_id": person("Grace Ellingham"),
                   "dc_sa_id": person("Sana Whitfield"), "tech_lead_id": person("Devon Achterberg"),
                   "labels": ["accounts", "open-banking", "partner-api", "us-p&c"]}
        result = ini_api.create_initiative(payload)
        state["id"] = result["initiative"]["id"]
        return {"message": f"Created {result['initiative']['rddc']}"}

    def attach():
        ini = repo.get_initiative(state["id"])
        if ini.get("sa_doc_attachment_id"):
            return {"message": "SA document already attached"}
        path = _sample_sa_file()
        if path is None:
            raise errors.ApiError("not_found", "The sample SA document is not installed.", 404)
        result = ini_api.store_upload(state["id"], path.name, path.read_bytes(), "sa_doc")
        sa = result.get("sa") or {}
        return {"message": f"SA Completeness {sa.get('completeness')}%" if sa.get("completeness") is not None
                else "SA document attached"}

    def change_summary():
        if db.scalar("SELECT COUNT(*) FROM initiative_components WHERE initiative_id = ?", (state["id"],)):
            return {"message": "Change Summary already in place"}
        return {"ai_run_id": _ai_step("change_summary", state["id"])}

    def l2():
        ini = repo.get_initiative(state["id"])
        if ini.get("l2_status") == "Approved":
            return {"message": "L2 already approved"}
        if ini.get("l2_status") != "Pending approval":
            _with_persona("Dev Lead", lambda: _internal("POST", f"/api/initiatives/{state['id']}/l2/submit"))
        _with_persona("Requestor", lambda: _internal("POST", f"/api/initiatives/{state['id']}/l2/approve",
                                                     {"comment": "Approved for DC-2702."}))
        return {"message": "L2 approved"}

    def wbs():
        if db.scalar("SELECT COUNT(*) FROM wbs_tasks WHERE initiative_id = ?", (state["id"],)):
            return {"message": "Project plan already in place"}
        return {"ai_run_id": _ai_step("wbs", state["id"])}

    def resources():
        done = db.scalar("SELECT COUNT(*) FROM ai_runs WHERE initiative_id = ? AND feature = 'resources' "
                         "AND status = 'accepted'", (state["id"],))
        if done:
            return {"message": "Resources already assigned"}
        return {"ai_run_id": _ai_step("resources", state["id"])}

    for label, fn in (("Create initiative", create), ("Attach SA document", attach),
                      ("Generate Change Summary", change_summary), ("L2 approval", l2),
                      ("Generate Project Plan", wbs), ("Suggest Resources", resources)):
        if not record(label, fn):
            break
    rddc = None
    if state["id"]:
        rddc = db.scalar("SELECT rddc FROM initiatives WHERE id = ?", (state["id"],))
        log_activity("initiative", state["id"], "fast_forward", {"label": rddc}, state["id"])
    return {"initiative_id": state["id"], "rddc": rddc, "steps": steps}


# ------------------------------------------------------------------ activity, trains, intakes
@bp.get("/activity")
def activity():
    f = Fields(dict(request.args))
    f.integer("initiative_id", lo=1)
    f.integer("limit", lo=1, hi=500)
    args = f.check("Some filters need attention.")
    sql, params = "SELECT * FROM activity_log ", []
    if args.get("initiative_id"):
        sql += "WHERE initiative_id = ? "
        params.append(args["initiative_id"])
    rows = db.query(sql + "ORDER BY id DESC LIMIT ?", params + [args.get("limit") or 50])
    for r in rows:
        r["detail_json"] = db.from_json(r["detail_json"], {}) or {}
        r["summary"] = summarize(r)
    return listed(rows)


@bp.get("/release-trains")
def release_trains():
    freeze = freeze_window()
    trains = db.query("SELECT code, train_date, status, notes FROM release_trains ORDER BY train_date")
    inits = db.query("SELECT id, rddc, name, rag_cached AS rag, target_release, stage FROM initiatives "
                     "WHERE target_release IS NOT NULL ORDER BY rddc")
    for t in trains:
        t["in_freeze"] = bool(freeze["start"] and freeze["start"] <= t["train_date"] <= freeze["end"])
        t["initiatives"] = [{"id": i["id"], "rddc": i["rddc"], "name": i["name"], "rag": i["rag"], "stage": i["stage"]}
                            for i in inits if i["target_release"] == t["code"]]
    return {"items": trains, "total": len(trains), "freeze": freeze, "holidays": holidays()}


def _intake_row(row: dict) -> dict:
    linked = db.query_one("SELECT id FROM initiatives WHERE dc_intake = ? ORDER BY id LIMIT 1", (row["code"],))
    person = db.query_one("SELECT id FROM resources WHERE name = ?", (row["requestor"],)) if row.get("requestor") else None
    prn = db.query_one(
        "SELECT p.prn_code FROM prn_budget p WHERE p.name = ? AND NOT EXISTS "
        "(SELECT 1 FROM initiatives i WHERE i.prn_code = p.prn_code)", (row["name"],))
    for col in ("dc_pm_id", "dc_sa_id", "tech_lead_id", "pm_id"):
        row[col.replace("_id", "_name")] = repo.resource_name(row.get(col))
    return {**row, "initiative_id": linked["id"] if linked else None,
            "requestor_id": person["id"] if person else None,
            "prn_code": prn["prn_code"] if prn else None,
            "target_release": suggest_train(row.get("requested_go_live"))}


def suggest_train(requested_go_live) -> str | None:
    """Latest planned train on or before the requested go-live; else the first one after it."""
    if not requested_go_live or not valid_date(str(requested_go_live)):
        return None
    row = db.query_one("SELECT code FROM release_trains WHERE status = 'Planned' AND train_date <= ? "
                       "ORDER BY train_date DESC LIMIT 1", (requested_go_live,))
    if row is None:
        row = db.query_one("SELECT code FROM release_trains WHERE status = 'Planned' AND train_date > ? "
                           "ORDER BY train_date LIMIT 1", (requested_go_live,))
    return row["code"] if row else None


@bp.get("/dc-intakes")
def list_dc_intakes():
    q = (request.args.get("q") or "").strip()
    sql, params = "SELECT * FROM dc_intakes ", []
    if q:
        like = repo._like(q)
        sql += ("WHERE code LIKE ? ESCAPE '\\' OR name LIKE ? ESCAPE '\\' OR requestor LIKE ? ESCAPE '\\' "
                "OR lob LIKE ? ESCAPE '\\' ")
        params = [like] * 4
    return listed([_intake_row(r) for r in db.query(sql + "ORDER BY code", params)])


@bp.get("/dc-intakes/<code>")
def get_dc_intake(code: str):
    row = db.query_one("SELECT * FROM dc_intakes WHERE code = ?", (code.strip().upper(),))
    if row is None:
        raise errors.not_found("DC intake", code)
    return _intake_row(row)
