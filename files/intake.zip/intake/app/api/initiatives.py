"""Initiatives (owner B1): search, create (RDDC auto-number, DC intake pre-fill, grooming slot), bundle, edit,
delete, Change Summary rows (initiative_components), attachments and SA document text.
Contracts: docs/contracts.md §2 "initiatives".
"""
from __future__ import annotations

import re
import shutil
from pathlib import Path

from flask import Blueprint, current_app, request, send_file
from werkzeug.utils import secure_filename

from app import db, errors, repo, textract
from app.activity import actor_name, log_activity
from app.api._shared import Fields, json_body, listed, lookup_values
from app.today import get_today, now_iso

bp = Blueprint("initiatives", __name__, url_prefix="/api")

STAGE_STATUS = {"Intake": "Backlog", "Grooming": "Backlog", "Solution": "Backlog", "Estimation": "Backlog",
                "Planning": "In progress", "Build": "In progress", "QA": "In progress", "Release": "In progress",
                "Closed": "Completed"}
PERSON_FIELDS = ("requestor_id", "assigned_to_id", "pm_id", "tech_lead_id", "dc_pm_id", "dc_sa_id")
MIME = {".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".pdf": "application/pdf", ".md": "text/markdown", ".txt": "text/plain"}
ATTACHMENT_KINDS = ("sa_doc", "tech_validation", "biz_validation", "backout_plan", "meeting_notes", "other")
CR_ATTACHMENT_COLUMN = {"tech_validation": "tech_validation_attachment_id",
                        "biz_validation": "biz_validation_attachment_id", "backout_plan": "backout_attachment_id"}


# ------------------------------------------------------------------ validation
def _initiative_fields(data: dict, *, creating: bool) -> Fields:
    f = Fields(data)
    f.text("name", required=creating, max_len=80)
    f.lookup("lob", "lob", required=creating, label="line of business")
    f.integer("priority", required=creating, lo=1, hi=4)
    f.text("requestor", max_len=120)
    for col in PERSON_FIELDS:
        f.ref(col, "resources", label="person")
    f.ref("dc_intake", "dc_intakes", label="DC intake", key="code")
    f.text("description", max_len=8000)
    f.date("requested_go_live")
    f.ref("target_release", "release_trains", label="release train", key="code")
    f.ref("prn_code", "prn_budget", label="PRN", key="prn_code")
    f.strings("labels", max_items=20, max_len=60)
    f.text("comments", max_len=4000)
    if not creating:
        f.lookup("stage", "stage", label="stage")
        f.lookup("status", "status", label="status")
        for col in ("planned_start", "planned_end", "readiness_date", "qa_date", "qa_signoff_date", "prod_date"):
            f.date(col)
        f.text("sa_author", max_len=120)
        f.text("sa_version", max_len=20)
    return f


def _changes(before: dict, after: dict) -> dict:
    return {k: [before.get(k), v] for k, v in after.items() if before.get(k) != v}


# ------------------------------------------------------------------ initiatives
def _max_upload() -> int:
    return int(current_app.config.get("MAX_UPLOAD_BYTES") or 10 * 1024 * 1024)


def _check_filters(filters: dict) -> None:
    """422 for filter values that cannot match anything (non-numeric ids, values outside the lookup lists)."""
    problems = {}
    enums = {"stage": "stage", "lob": "lob", "status": "status"}
    for key, raw in filters.items():
        if raw in (None, "") or key in ("q", "release"):
            continue
        values = [v.strip() for v in str(raw).split(",") if v.strip()]
        if key in ("dc_pm_id", "priority"):
            if not all(v.isdigit() for v in values):
                problems[key] = "Use a number."
        elif key == "rag":
            if any(v not in ("Red", "Amber", "Green") and v.lower() not in ("none", "not scored", "unscored")
                   for v in values):
                problems[key] = "Choose Red, Amber, Green or Not scored."
        elif key in enums:
            allowed = set(lookup_values(enums[key]))
            if any(v not in allowed for v in values):
                problems[key] = "Choose a value from the list."
    if problems:
        raise errors.validation("Some filters need attention.", problems)


@bp.get("/initiatives")
def list_initiatives():
    filters = {k: request.args.get(k) for k in ("q", "stage", "lob", "status", "rag", "dc_pm_id", "release", "priority")}
    _check_filters(filters)
    return listed(repo.list_initiatives(filters))


def _next_rddc() -> str:
    raw = repo.setting("rddc_next", "24817")
    n = int(raw) if str(raw).isdigit() else 24817
    while db.query_one("SELECT 1 AS x FROM initiatives WHERE rddc = ?", (f"RDDC-{n}",)):
        n += 1
    db.execute("INSERT INTO app_settings (key, value) VALUES ('rddc_next', ?) "
               "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (str(n + 1),))
    return f"RDDC-{n}"


def _ensure_intake_free(code: str) -> None:
    linked = db.query_one("SELECT id, rddc FROM initiatives WHERE dc_intake = ? ORDER BY id LIMIT 1", (code,))
    if linked:
        raise errors.conflict(f"{code} is already registered as {linked['rddc']}.",
                              {"initiative_id": linked["id"], "rddc": linked["rddc"]})


def create_initiative(data: dict) -> dict:
    """Create an intake. Returns {initiative, grooming, queued_notifications}."""
    data = dict(data or {})
    intake = None
    if data.get("dc_intake"):
        code = str(data["dc_intake"]).strip().upper()
        data["dc_intake"] = code
        intake = db.query_one("SELECT * FROM dc_intakes WHERE code = ?", (code,))
        if intake is None:
            raise errors.validation("Some fields need attention.", {"dc_intake": "That DC intake does not exist."})
        _ensure_intake_free(code)
        for key in ("name", "lob", "priority", "requestor", "requested_go_live", "description", "dc_pm_id", "dc_sa_id",
                    "tech_lead_id", "pm_id"):
            if data.get(key) in (None, "") and intake.get(key) not in (None, ""):
                data[key] = intake[key]
    f = _initiative_fields(data, creating=True)
    if not data.get("requestor") and not data.get("requestor_id"):
        f.error("requestor", "This field is required.")
    values = f.check()
    if values.get("requestor_id") and not values.get("requestor"):
        values["requestor"] = repo.resource_name(values["requestor_id"])
    if values.get("requestor") and not values.get("requestor_id"):
        person = db.query_one("SELECT id FROM resources WHERE name = ?", (values["requestor"],))
        values["requestor_id"] = person["id"] if person else None
    if values.get("dc_pm_id"):
        values.setdefault("assigned_to_id", values["dc_pm_id"])
        values.setdefault("pm_id", values["dc_pm_id"])
    if not values.get("target_release") and values.get("requested_go_live"):
        from app.api.core import suggest_train
        values["target_release"] = suggest_train(values["requested_go_live"])
    if not values.get("prn_code") and intake is not None:
        prn = db.query_one("SELECT p.prn_code FROM prn_budget p WHERE p.name = ? AND NOT EXISTS "
                           "(SELECT 1 FROM initiatives i WHERE i.prn_code = p.prn_code)", (intake["name"],))
        values["prn_code"] = prn["prn_code"] if prn else None
    stamp = now_iso()
    with db.transaction():  # BEGIN IMMEDIATE: the intake check and the insert are one serialized step
        if values.get("dc_intake"):
            _ensure_intake_free(values["dc_intake"])
        values.update({"rddc": _next_rddc(), "stage": "Intake", "status": "Backlog", "l2_status": "Draft",
                       "labels": db.to_json(values.get("labels") or []), "rag_overrides_json": db.to_json({}),
                       "created_at": stamp, "updated_at": stamp})
        iid = db.insert("initiatives", values)
        log_activity("initiative", iid, "create", {"label": f"{values['rddc']} {values['name']}"}, iid)
        grooming, notes = None, []
        derive = repo.optional_module("app.services.derive")
        if derive is not None:
            slot = derive.slot_grooming(iid)
            if slot:
                db.execute("UPDATE initiatives SET stage = 'Grooming' WHERE id = ? AND stage = 'Intake'", (iid,))
                grooming = {k: slot.get(k) for k in ("session_id", "session_date", "start_time", "label")}
                notes = slot.get("notifications") or [
                    {"id": n["id"], "to_name": n["to_name"], "subject": n["subject"]}
                    for n in db.query("SELECT id, to_name, subject FROM notifications WHERE initiative_id = ? "
                                      "AND status = 'Queued' ORDER BY id", (iid,))]
            repo.sync_derived(iid, reminders=True)
    return {"initiative": repo.get_initiative(iid), "grooming": grooming, "queued_notifications": notes}


@bp.post("/initiatives")
def post_initiative():
    return create_initiative(json_body()), 201


@bp.get("/initiatives/<int:iid>")
def get_initiative(iid: int):
    return repo.get_initiative_bundle(iid)


@bp.put("/initiatives/<int:iid>")
def put_initiative(iid: int):
    before = repo.get_initiative(iid)
    data = json_body()
    values = _initiative_fields(data, creating=False).check()
    for required in ("name", "lob", "priority"):
        if required in values and values[required] is None:
            raise errors.validation("Some fields need attention.", {required: "This field is required."})
    if "labels" in values:
        values["labels"] = db.to_json(values["labels"] or [])
    if "stage" in values and "status" not in values and values["stage"] != before["stage"]:
        values["status"] = STAGE_STATUS.get(values["stage"], before["status"])
    if values.get("dc_intake") and values["dc_intake"] != before.get("dc_intake"):
        linked = db.query_one("SELECT rddc FROM initiatives WHERE dc_intake = ? AND id <> ?", (values["dc_intake"], iid))
        if linked:
            raise errors.conflict(f"{values['dc_intake']} is already registered as {linked['rddc']}.")
    raw_before = db.query_one("SELECT * FROM initiatives WHERE id = ?", (iid,))
    changes = _changes(raw_before, values)
    if not changes:
        return repo.get_initiative(iid)
    with db.transaction():
        values["updated_at"] = now_iso()
        db.update("initiatives", iid, values)
        log_activity("initiative", iid, "update", {"label": before["rddc"], "changes": changes}, iid)
        repo.sync_derived(iid)
    return repo.get_initiative(iid)


@bp.delete("/initiatives/<int:iid>")
def delete_initiative(iid: int):
    ini = repo.get_initiative(iid)
    with db.transaction():
        db.execute("DELETE FROM initiatives WHERE id = ?", (iid,))
        log_activity("initiative", iid, "delete", {"label": f"{ini['rddc']} {ini['name']}"}, iid)
    folder = Path(current_app.config["UPLOAD_DIR"]) / str(iid)
    if folder.is_dir():
        shutil.rmtree(folder, ignore_errors=True)
    return {"ok": True}


@bp.post("/initiatives/<int:iid>/groomed")
def mark_groomed(iid: int):
    """Pg 1 "Mark as groomed": stage Grooming → Solution.

    On or after the slotted session date the slot becomes Discussed ("Groomed in session Tue 20 Oct, 10:00").
    Before it (or with no slot) it is recorded as an ad-hoc walk-through today, and the future slot and its queued
    invites are released so Intake & Grooming no longer lists the item for that session.
    """
    from app.services import stage as stage_flow

    ini = repo.get_initiative(iid)
    if ini["stage"] not in ("Intake", "Grooming"):
        raise errors.conflict(f"{ini['rddc']} is already past grooming ({ini['stage']}).")
    today = get_today().isoformat()
    slot = db.query_one(
        "SELECT s.session_id, g.session_date, g.start_time FROM grooming_slots s JOIN grooming_sessions g "
        "ON g.id = s.session_id WHERE s.initiative_id = ? AND s.status <> 'Discussed' ORDER BY g.session_date LIMIT 1",
        (iid,))
    cal = repo.optional_module("app.engines.calendar")

    def day(value, long=False):
        if cal is None:
            return value
        return cal.fmt_day_long(value) if long else cal.fmt_day(value)

    with db.transaction():
        if slot is not None and slot["session_date"] <= today:
            when = f"{day(slot['session_date'])}, {slot['start_time']}"
            db.execute("UPDATE grooming_slots SET status = 'Discussed' WHERE session_id = ? AND initiative_id = ?",
                       (slot["session_id"], iid))
            summary = f"Groomed in session {when}"
            message = f"Groomed in session {when}."
            session_id = slot["session_id"]
        else:
            summary = f"Groomed · ad-hoc walk-through {day(today, long=True)}"
            message = f"Groomed in an ad-hoc walk-through today ({day(today, long=True)})."
            session_id = None
            if slot is not None:
                db.execute("DELETE FROM grooming_slots WHERE session_id = ? AND initiative_id = ?",
                           (slot["session_id"], iid))
                db.execute("UPDATE notifications SET status = 'Dismissed' WHERE initiative_id = ? "
                           "AND rule = 'grooming_invite' AND status = 'Queued'", (iid,))
                message += f" The {day(slot['session_date'])} slot is free again."
        log_activity("grooming_slot", session_id, "update", {"label": ini["rddc"], "summary": summary}, iid)
        moved = stage_flow.advance(iid, "Solution", reason=summary[0].lower() + summary[1:])
        repo.sync_derived(iid, reminders=True)
    if moved:
        message += f" Stage moved {moved['from']} → {moved['to']}."
    return {"initiative": repo.get_initiative(iid), "session_id": session_id, "message": message}


# ------------------------------------------------------------------ Change Summary rows
def _catalogue(component_id) -> dict:
    return repo.require("dc_components", component_id, "DC component")


def _log_scope(iid: int, change: str, code: str, text: str) -> None:
    approved = db.scalar("SELECT l2_approved_at FROM initiatives WHERE id = ?", (iid,))
    if approved:
        log_activity("initiative_component", None, "scope_change",
                     {"change": change, "component_code": code, "text": text, "label": code}, iid)


def _component_fields(data: dict, *, creating: bool) -> Fields:
    if creating and not data.get("component_id") and data.get("component_code"):
        row = db.query_one("SELECT id FROM dc_components WHERE code = ?", (str(data["component_code"]).upper(),))
        if row:
            data = {**data, "component_id": row["id"]}
    f = Fields(data)
    f.ref("component_id", "dc_components", required=creating, label="DC component")
    f.lookup("approval", "approval", label="approval")
    f.lookup("complexity", "complexity", label="complexity")
    f.text("change_summary", max_len=2000)
    f.number("est_hours", lo=0, hi=20000)
    f.ref("component_lead_id", "resources", label="person")
    f.integer("sort", lo=0, hi=100000)
    return f


@bp.get("/initiatives/<int:iid>/components")
def list_components(iid: int):
    repo.require("initiatives", iid, "Initiative")
    return listed(repo.list_components(iid))


@bp.post("/initiatives/<int:iid>/components")
def add_component(iid: int):
    repo.require("initiatives", iid, "Initiative")
    values = _component_fields(json_body(), creating=True).check()
    cat = _catalogue(values["component_id"])
    if db.query_one("SELECT 1 AS x FROM initiative_components WHERE initiative_id = ? AND component_id = ?",
                    (iid, cat["id"])):
        raise errors.conflict(f"{cat['name']} is already in the Change Summary.")
    complexity = values.get("complexity") or "Medium"
    values["complexity"] = complexity
    values["approval"] = values.get("approval") or "Pending"
    if values.get("est_hours") is None:
        values["est_hours"] = float(cat[f"base_hours_{complexity.lower()}"])
    if values.get("component_lead_id") is None:
        values["component_lead_id"] = cat["component_lead_id"]
    if values.get("sort") is None:
        values["sort"] = (db.scalar("SELECT MAX(sort) FROM initiative_components WHERE initiative_id = ?", (iid,)) or 0) + 10
    with db.transaction():
        icid = db.insert("initiative_components", {**values, "initiative_id": iid, "source": "manual"})
        log_activity("initiative_component", icid, "create", {"label": cat["name"]}, iid)
        _log_scope(iid, "insert", cat["code"], f"{cat['name']} added ({complexity})")
        repo.sync_derived(iid, reminders=True)
    return repo.get_component(icid), 201


@bp.put("/initiative-components/<int:icid>")
def update_component(icid: int):
    row = repo.get_component(icid)
    values = _component_fields(json_body(), creating=False).check()
    for required in ("component_id", "approval", "complexity"):
        if required in values and values[required] is None:
            raise errors.validation("Some fields need attention.", {required: "This field is required."})
    iid = row["initiative_id"]
    cat = _catalogue(values.get("component_id") or row["component_id"])
    if values.get("component_id") and values["component_id"] != row["component_id"] and db.query_one(
            "SELECT 1 AS x FROM initiative_components WHERE initiative_id = ? AND component_id = ? AND id <> ?",
            (iid, values["component_id"], icid)):
        raise errors.conflict(f"{cat['name']} is already in the Change Summary.")
    complexity_changed = "complexity" in values and values["complexity"] != row["complexity"]
    if complexity_changed and "est_hours" not in values:
        values["est_hours"] = float(cat[f"base_hours_{values['complexity'].lower()}"])
    changes = _changes(row, values)
    if not changes:
        return row
    with db.transaction():
        db.update("initiative_components", icid, values)
        action = "update"
        if "approval" in changes and values["approval"] in ("Approved", "Rejected"):
            action = "approve" if values["approval"] == "Approved" else "reject"
        log_activity("initiative_component", icid, action, {"label": cat["name"], "changes": changes}, iid)
        if "component_id" in changes:
            _log_scope(iid, "delete", row["code"], f"{row['name']} replaced")
            _log_scope(iid, "insert", cat["code"], f"{cat['name']} added")
        elif complexity_changed:
            _log_scope(iid, "complexity", cat["code"],
                       f"{cat['name']} complexity {row['complexity']} → {values['complexity']}")
        repo.sync_derived(iid, reminders="approval" in changes)
    return repo.get_component(icid)


@bp.delete("/initiative-components/<int:icid>")
def delete_component(icid: int):
    row = repo.get_component(icid)
    iid = row["initiative_id"]
    with db.transaction():
        db.execute("DELETE FROM initiative_components WHERE id = ?", (icid,))
        log_activity("initiative_component", icid, "delete", {"label": row["name"]}, iid)
        _log_scope(iid, "delete", row["code"], f"{row['name']} removed")
        repo.sync_derived(iid)
    return {"ok": True}


# ------------------------------------------------------------------ attachments
def _local_sa_fields(text: str) -> dict:
    author = re.search(r"author\s*[:\-–]\s*([^\n|·;,(]+)", text, re.IGNORECASE)
    version = re.search(r"\bversion\s*[:\-–]?\s*v?\s*([0-9]+(?:\.[0-9]+)*)", text, re.IGNORECASE)
    return {"author": author.group(1).strip() if author else None, "version": version.group(1) if version else None,
            "completeness": None, "missing": []}


def _score_sa(text: str) -> dict:
    engine = repo.optional_module("app.engines.sa_completeness")
    if engine is None:
        return _local_sa_fields(text)
    result = engine.score(text)
    return {"author": result.get("author"), "version": result.get("version"),
            "completeness": result.get("completeness"), "missing": result.get("missing") or []}


def _unique_target(folder: Path, filename: str) -> Path:
    target = folder / filename
    stem, suffix = target.stem, target.suffix
    n = 2
    while target.exists():
        target = folder / f"{stem}-{n}{suffix}"
        n += 1
    return target


def _validate_entity(iid: int, entity_type: str, entity_id) -> int:
    if entity_type == "initiative":
        return iid
    table = {"change_request": "change_requests", "document": "documents", "meeting_note": "meeting_notes"}[entity_type]
    if entity_id is None:
        raise errors.validation("Some fields need attention.", {"entity_id": "Choose the item this file belongs to."})
    row = db.query_one(f"SELECT id, initiative_id FROM {table} WHERE id = ?", (entity_id,))
    if row is None or (row["initiative_id"] not in (None, iid)):
        raise errors.validation("Some fields need attention.", {"entity_id": "That item is not on this initiative."})
    return row["id"]


def store_upload(iid: int, filename: str, data: bytes, kind: str, entity_type: str = "initiative",
                 entity_id=None) -> dict:
    """Save, read and register one uploaded file. Returns {attachment, extracted_chars, sa}."""
    ini = repo.get_initiative(iid)
    allowed = current_app.config["ALLOWED_UPLOAD_EXTENSIONS"]
    original = (filename or "").replace("\\", "/").rsplit("/", 1)[-1]
    ext = Path(original).suffix.lower()
    safe = secure_filename(original)
    if not Path(safe).stem or Path(safe).suffix.lower() != ext:
        safe = f"upload{ext}"
    if ext not in allowed:
        raise errors.validation("Attach a .docx, .pdf, .md or .txt file.",
                                {"file": "Attach a .docx, .pdf, .md or .txt file."})
    if not data:
        raise errors.validation("The file is empty.", {"file": "The file is empty."})
    if len(data) > _max_upload():
        raise errors.ApiError("payload_too_large", "The file is larger than 10 MB. Attach a smaller file.", 413)
    if kind not in ATTACHMENT_KINDS:
        raise errors.validation("Some fields need attention.", {"kind": "Choose a document type from the list."})
    if entity_type not in ("initiative", "change_request", "document", "meeting_note"):
        raise errors.validation("Some fields need attention.", {"entity_type": "Choose what this file belongs to."})
    entity_id = _validate_entity(iid, entity_type, entity_id)
    folder = Path(current_app.config["UPLOAD_DIR"]) / str(iid)
    folder.mkdir(parents=True, exist_ok=True)
    target = _unique_target(folder, safe)
    target.write_bytes(data)
    try:
        text = textract.extract_text(target, MIME.get(ext))
    except errors.ApiError:
        target.unlink(missing_ok=True)
        raise
    sa = _score_sa(text) if kind == "sa_doc" else None
    with db.transaction():
        aid = db.insert("attachments", {
            "initiative_id": iid, "entity_type": entity_type, "entity_id": entity_id, "kind": kind,
            "filename": target.name, "stored_path": f"{iid}/{target.name}", "mime": MIME.get(ext),
            "size_bytes": len(data), "extracted_text": text, "version": (sa or {}).get("version"),
            "uploaded_by": actor_name(iid), "uploaded_at": now_iso()})
        if sa is not None:
            updates = {"sa_doc_attachment_id": aid, "updated_at": now_iso()}
            if sa.get("author"):
                updates["sa_author"] = sa["author"]
            if sa.get("version"):
                updates["sa_version"] = sa["version"]
            if sa.get("completeness") is not None:
                updates["sa_completeness"] = sa["completeness"]
                updates["sa_missing_json"] = db.to_json(sa["missing"])
            db.update("initiatives", iid, updates)
            codes = [c["code"] for c in repo.list_components(iid)]
            existing = db.query_one("SELECT id FROM documents WHERE initiative_id = ? AND doc_type = 'SA'", (iid,))
            doc = {"title": f"SA document – {ini['name']}", "version": sa.get("version"), "attachment_id": aid,
                   "owner_id": ini.get("dc_sa_id"), "status": "In review", "components": db.to_json(codes),
                   "updated_at": now_iso()}
            if existing:
                db.update("documents", existing["id"], doc)
            else:
                db.insert("documents", {**doc, "initiative_id": iid, "doc_type": "SA"})
        if entity_type == "change_request" and kind in CR_ATTACHMENT_COLUMN:
            column = CR_ATTACHMENT_COLUMN[kind]
            db.execute(f"UPDATE change_requests SET {column} = ?, updated_at = ? WHERE id = ?", (aid, now_iso(), entity_id))
            repo.cache_compliance(entity_id)
        log_activity("attachment", aid, "upload", {"label": target.name, "kind": kind}, iid)
        repo.sync_derived(iid, reminders=True)
    attachment = db.query_one(
        "SELECT id, initiative_id, entity_type, entity_id, kind, filename, stored_path, mime, size_bytes, version, "
        "uploaded_by, uploaded_at FROM attachments WHERE id = ?", (aid,))
    return {"attachment": attachment, "extracted_chars": len(text), "sa": sa}


@bp.get("/initiatives/<int:iid>/attachments")
def list_attachments(iid: int):
    repo.require("initiatives", iid, "Initiative")
    return listed(repo.list_attachments(iid))


@bp.post("/initiatives/<int:iid>/attachments")
def upload_attachment(iid: int):
    repo.require("initiatives", iid, "Initiative")
    upload = request.files.get("file")
    if upload is None or not upload.filename:
        raise errors.validation("Choose a file to attach.", {"file": "Choose a file to attach."})
    kind = request.form.get("kind") or ""
    entity_type = request.form.get("entity_type") or "initiative"
    raw_entity = request.form.get("entity_id")
    entity_id = None
    if raw_entity not in (None, ""):
        if not str(raw_entity).isdigit():
            raise errors.validation("Some fields need attention.", {"entity_id": "Choose the item this file belongs to."})
        entity_id = int(raw_entity)
    data = upload.read(_max_upload() + 1)
    return store_upload(iid, upload.filename, data, kind, entity_type, entity_id), 201


@bp.post("/initiatives/<int:iid>/sa-text")
def paste_sa_text(iid: int):
    repo.require("initiatives", iid, "Initiative")
    f = Fields(json_body())
    f.text("text", required=True, max_len=500_000)
    f.text("filename", max_len=120)
    values = f.check()
    if len(values["text"]) < 20:
        raise errors.validation("Paste the full SA document text.", {"text": "Paste the full SA document text."})
    name = secure_filename(values.get("filename") or "") or "SA_document_pasted.txt"
    if Path(name).suffix.lower() not in (".md", ".txt"):
        name = f"{Path(name).stem or 'SA_document_pasted'}.txt"
    return store_upload(iid, name, values["text"].encode("utf-8"), "sa_doc"), 201


@bp.get("/attachments/<int:aid>/download")
def download_attachment(aid: int):
    row = repo.require("attachments", aid, "Attachment")
    root = Path(current_app.config["UPLOAD_DIR"]).resolve()
    path = (root / row["stored_path"]).resolve()
    if root not in path.parents or not path.is_file():
        raise errors.not_found("Attachment file", aid)
    return send_file(path, mimetype=row.get("mime") or "application/octet-stream", as_attachment=True,
                     download_name=row["filename"], max_age=0)
