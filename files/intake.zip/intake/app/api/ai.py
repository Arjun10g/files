"""AI endpoints (B3): feature runs, accept/reject/regenerate, AI activity, assistant chat.

Every feature endpoint returns an AiRun envelope and writes nothing but the ``ai_runs`` row; domain tables change
only through ``POST /api/ai-runs/{id}/apply``.
"""
from __future__ import annotations

from flask import Blueprint, jsonify, request

from app import db
from app.ai import apply as ai_apply
from app.ai import provider
from app.ai.schemas import FEATURES, SCHEMAS
from app.errors import ApiError, not_found, validation
from app.today import now_iso

bp = Blueprint("ai", __name__, url_prefix="/api")

INITIATIVE_FEATURES = ("intake-analysis", "change-summary", "l2-estimate", "wbs", "resources", "rebalance", "risks",
                       "exec-summary", "cr-compliance")
GLOBAL_FEATURES = ("intake-analysis", "intake-autofill", "skill-matrix", "exec-summary", "nudges", "meeting-extract", "lessons")
RESERVED = ("instruction", "regen_of", "options")


def _body() -> dict:
    """JSON object body; {} when empty, 400 when unreadable or not an object."""
    if not request.get_data(cache=True):
        return {}
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise ApiError("bad_request", "The request could not be read.", 400)
    return data


ID_OPTIONS = {"change_request_id": ("change_requests", "Change request"), "meeting_note_id": ("meeting_notes", "Meeting note"),
              "attachment_id": ("attachments", "Attachment"), "resource_id": ("resources", "Person"),
              "initiative_id": ("initiatives", "Initiative")}
TEXT_OPTIONS = {"text": 200000, "name": 200, "description": 20000, "lob": 80, "filename": 255, "wbs_code": 20, "page": 40,
                "requestor": 120, "requested_go_live": 10, "target_release": 20, "prn_code": 20, "dc_intake": 20,
                "dc_sa_name": 120}


def _check_options(inputs: dict, initiative_id: int | None) -> dict:
    """Validate the documented AI options: ids are positive integers naming existing records, text is text."""
    fields: dict[str, str] = {}
    clean = dict(inputs)
    for key, (table, label) in ID_OPTIONS.items():
        val = inputs.get(key)
        if val in (None, ""):
            clean.pop(key, None)
            continue
        if isinstance(val, bool) or not isinstance(val, (int, str)) or not str(val).isdigit() or int(val) < 1:
            fields[key] = "Expected a record number"
            continue
        clean[key] = int(val)
    for key, limit in TEXT_OPTIONS.items():
        val = inputs.get(key)
        if val is None:
            continue
        if not isinstance(val, str):
            fields[key] = "Expected text"
        elif len(val) > limit:
            fields[key] = f"Keep this under {limit:,} characters"
    if inputs.get("priority") not in (None, ""):
        pri = inputs["priority"]
        if isinstance(pri, bool) or not str(pri).isdigit() or not 1 <= int(pri) <= 4:
            fields["priority"] = "Expected P1 to P4"
    if fields:
        raise validation("Some options need attention.", fields)
    for key, (table, label) in ID_OPTIONS.items():
        if key in clean and db.query_one(f"SELECT id FROM {table} WHERE id = ?", (clean[key],)) is None:
            raise not_found(label, clean[key])
    if "change_request_id" in clean and initiative_id is not None:
        owner = db.scalar("SELECT initiative_id FROM change_requests WHERE id = ?", (clean["change_request_id"],))
        if owner != initiative_id:
            raise not_found("Change request", clean["change_request_id"])
    return clean


def _inputs(body: dict) -> dict:
    opts = body.get("options") or {}
    if not isinstance(opts, dict):
        raise validation("Options must be an object.", {"options": "Expected an object"})
    merged = {k: v for k, v in body.items() if k not in RESERVED}
    merged.update(opts)
    return merged


def _int_or_none(value, field: str) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise validation("Some fields need attention.", {field: "Expected a number"}) from exc


def _run(feature: str, initiative_id: int | None, body: dict):
    instruction = body.get("instruction")
    if instruction is not None and not isinstance(instruction, str):
        raise validation("Some fields need attention.", {"instruction": "Expected text"})
    env = provider.run_feature(feature, initiative_id, _check_options(_inputs(body), initiative_id), instruction=(instruction or "").strip()[:500] or None,
                               regen_of=_int_or_none(body.get("regen_of"), "regen_of"))
    return jsonify(env)


@bp.post("/initiatives/<int:iid>/ai/<slug>")
def run_initiative_feature(iid: int, slug: str):
    if slug not in INITIATIVE_FEATURES:
        raise not_found("AI feature", slug)
    if db.query_one("SELECT id FROM initiatives WHERE id = ?", (iid,)) is None:
        raise not_found("Initiative", iid)
    return _run(slug.replace("-", "_"), iid, _body())


@bp.post("/ai/<slug>")
def run_global_feature(slug: str):
    if slug not in GLOBAL_FEATURES:
        raise not_found("AI feature", slug)
    body = _body()
    inputs = _check_options(_inputs(body), None)
    feature = slug.replace("-", "_")
    iid = _int_or_none(inputs.get("initiative_id"), "initiative_id") if feature in ("intake_analysis", "exec_summary", "lessons") else None
    if iid is not None and db.query_one("SELECT id FROM initiatives WHERE id = ?", (iid,)) is None:
        raise not_found("Initiative", iid)
    if feature == "intake_autofill" and not (inputs.get("text") or inputs.get("attachment_id")):
        raise validation("Attach an SA document or paste its text first.", {"text": "Required"})
    if feature == "meeting_extract" and not (inputs.get("text") or inputs.get("meeting_note_id")):
        raise validation("Paste the meeting notes or pick a saved meeting first.", {"text": "Required"})
    if feature == "intake_analysis" and iid is None and not (inputs.get("name") or inputs.get("description")):
        raise validation("Add a name or description before analysing the intake.", {"name": "Required"})
    return _run(feature, iid, body)


@bp.get("/ai/features")
def list_features():
    items = [{"feature": k, **{f: v for f, v in FEATURES[k].items()}} for k in SCHEMAS]
    return jsonify({"items": items, "total": len(items)})


@bp.post("/ai-runs/<int:run_id>/apply")
def apply_run(run_id: int):
    body = _body()
    selected = body.get("selected")
    if selected is not None and (not isinstance(selected, list) or not all(isinstance(i, int) for i in selected)):
        raise validation("Selection must be a list of row numbers.", {"selected": "Expected a list of numbers"})
    edited = body.get("edited_output")
    if edited is not None and not isinstance(edited, dict):
        raise validation("The edited draft could not be read.", {"edited_output": "Expected an object"})
    return jsonify(ai_apply.apply_run(run_id, selected=selected, edited_output=edited))


@bp.post("/ai-runs/<int:run_id>/reject")
def reject_run(run_id: int):
    reason = _body().get("reason")
    return jsonify(ai_apply.reject_run(run_id, reason if isinstance(reason, str) else None))


@bp.post("/ai-runs/<int:run_id>/regenerate")
def regenerate_run(run_id: int):
    body = _body()
    prev = provider.get_run(run_id)
    body["regen_of"] = run_id
    return _run(prev["feature"], prev["initiative_id"], body)


def _summary(row: dict) -> dict:
    return {"id": row["id"], "ai_run_id": row["id"], "feature": row["feature"], "title": FEATURES[row["feature"]]["title"],
            "initiative_id": row["initiative_id"], "rddc": row.get("rddc"), "initiative_name": row.get("initiative_name"),
            "scope": row["scope"], "mode": row["mode"], "mode_label": provider.mode_label(row), "model": row["model"],
            "status": row["status"], "confidence": row["confidence"], "latency_ms": row["latency_ms"] or 0,
            "minutes_saved": row["minutes_saved"] or 0, "variant_index": row["variant_index"], "regen_of": row["regen_of"],
            "instruction": row["instruction"], "actor": row["actor"], "created_at": row["created_at"], "decided_at": row["decided_at"],
            "applied": db.from_json(row.get("applied_json"), None),
            "deterministic": row["mode"] == "simulated_generated" or row["feature"] == "cr_compliance"}


@bp.get("/ai-runs")
def list_runs():
    args = request.args
    where, params = [], []
    if args.get("feature"):
        where.append("r.feature = ?")
        params.append(args["feature"].replace("-", "_"))
    if args.get("initiative_id"):
        where.append("r.initiative_id = ?")
        params.append(_int_or_none(args["initiative_id"], "initiative_id"))
    if args.get("status"):
        where.append("r.status = ?")
        params.append(args["status"])
    limit = min(max(_int_or_none(args.get("limit"), "limit") or 100, 1), 500)
    sql = ("SELECT r.*, i.rddc, i.name AS initiative_name FROM ai_runs r LEFT JOIN initiatives i ON i.id = r.initiative_id"
           + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY r.id DESC")
    total = db.scalar(f"SELECT COUNT(*) FROM ({sql})", params)
    rows = db.query(sql + " LIMIT ?", [*params, limit])
    return jsonify({"items": [_summary(r) for r in rows], "total": total})


@bp.get("/ai-runs/stats")
def run_stats():
    rows = db.query("SELECT feature, status, minutes_saved FROM ai_runs")
    by: dict[str, dict] = {}
    for r in rows:
        f = by.setdefault(r["feature"], {"feature": r["feature"], "title": FEATURES[r["feature"]]["title"], "runs": 0,
                                         "accepted": 0, "rejected": 0, "minutes_saved": 0.0})
        f["runs"] += 1
        if r["status"] == "accepted":
            f["accepted"] += 1
        if r["status"] == "rejected":
            f["rejected"] += 1
        if r["status"] == "accepted" or r["feature"] == "assistant":
            f["minutes_saved"] += float(r["minutes_saved"] or 0)
    accepted = sum(f["accepted"] for f in by.values())
    rejected = sum(f["rejected"] for f in by.values())
    order = list(SCHEMAS)
    return jsonify({"runs": len(rows), "accepted": accepted, "rejected": rejected,
                    "acceptance_rate": round(accepted / (accepted + rejected), 3) if accepted + rejected else 0.0,
                    "minutes_saved": round(sum(f["minutes_saved"] for f in by.values()), 1),
                    "by_feature": sorted(by.values(), key=lambda f: order.index(f["feature"]))})


@bp.get("/ai-runs/<int:run_id>")
def get_run(run_id: int):
    row = provider.get_run(run_id)
    env = provider.envelope(row)
    stored = db.from_json(row.get("input_json"), {}) or {}
    env.update({"input_json": stored.get("inputs", {}), "edited_output_json": db.from_json(row.get("edited_output_json"), None),
                "tokens_in": row.get("tokens_in"), "tokens_out": row.get("tokens_out"), "prompt_version": row.get("prompt_version"),
                "input_hash": row.get("input_hash"), "applied_json": db.from_json(row.get("applied_json"), None),
                "reject_reason": row.get("reject_reason"), "decided_at": row.get("decided_at"), "actor": row.get("actor")})
    return jsonify(env)


# ------------------------------------------------------------------ assistant
def _new_conversation_id() -> str:
    n = db.scalar("SELECT COUNT(DISTINCT conversation_id) FROM assistant_messages") or 0
    cid = f"conv-{n + 1:04d}"
    while db.query_one("SELECT 1 AS x FROM assistant_messages WHERE conversation_id = ?", (cid,)):
        n += 1
        cid = f"conv-{n + 1:04d}"
    return cid


@bp.post("/assistant/chat")
def chat():
    body = _body()
    message = body.get("message")
    if not isinstance(message, str) or not message.strip():
        raise validation("Type a question first.", {"message": "Required"})
    message = message.strip()[:1000]
    iid = _int_or_none(body.get("initiative_id"), "initiative_id")
    if iid is not None and db.query_one("SELECT id FROM initiatives WHERE id = ?", (iid,)) is None:
        iid = None
    cid = body.get("conversation_id") if isinstance(body.get("conversation_id"), str) and body.get("conversation_id") else _new_conversation_id()
    page = body.get("page") if isinstance(body.get("page"), str) else None
    env = provider.run_feature("assistant", iid, {"message": message, "page": page},
                               regen_of=_int_or_none(body.get("regen_of"), "regen_of"))
    out = env["output"]
    with db.transaction():
        db.insert("assistant_messages", {"conversation_id": cid[:80], "role": "user", "content": message, "initiative_id": iid,
                                         "created_at": now_iso()})
        db.insert("assistant_messages", {"conversation_id": cid[:80], "role": "assistant", "content": out["answer_md"],
                                         "initiative_id": iid, "ai_run_id": env["ai_run_id"], "created_at": now_iso()})
    return jsonify({"conversation_id": cid[:80], "answer_md": out["answer_md"], "intent": out["intent"],
                    "citations": out["citations"], "table": out.get("table"), "suggested_actions": out["suggested_actions"],
                    "follow_ups": out["follow_ups"], "confidence": env["confidence"], "sources": env["sources"],
                    "warnings": env["warnings"], "ai_run_id": env["ai_run_id"], "mode": env["mode"], "mode_label": env["mode_label"],
                    "deterministic": env["deterministic"]})


@bp.get("/assistant/conversations/<cid>")
def conversation(cid: str):
    rows = db.query("SELECT id, role, content, initiative_id, ai_run_id, created_at FROM assistant_messages WHERE conversation_id = ? "
                    "ORDER BY id", (cid,))
    if not rows:
        raise not_found("Conversation", cid)
    runs = {r["id"]: db.from_json(r["output_json"], {}) for r in db.query(
        f"SELECT id, output_json FROM ai_runs WHERE id IN ({','.join('?' for _ in rows)})", [r["ai_run_id"] or 0 for r in rows])}
    messages = []
    for r in rows:
        msg = dict(r)
        out = runs.get(r["ai_run_id"]) if r["ai_run_id"] else None
        if out:
            msg.update({"citations": out.get("citations", []), "table": out.get("table"),
                        "suggested_actions": out.get("suggested_actions", []), "follow_ups": out.get("follow_ups", [])})
        messages.append(msg)
    return jsonify({"conversation_id": cid, "messages": messages})
