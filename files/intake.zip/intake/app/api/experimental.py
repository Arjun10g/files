"""Password-protected integration lab. Jira credentials stay in the server environment."""
from __future__ import annotations

import base64
import functools
import json
import os
import re
import secrets
import time
from datetime import timedelta
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from flask import Blueprint, request, session
from werkzeug.security import check_password_hash, generate_password_hash

from app import db, errors, repo
from app.api._shared import json_body

bp = Blueprint("experimental", __name__, url_prefix="/api/experimental")


def _csrf():
    origin = request.headers.get("Origin")
    if origin and urlsplit(origin).netloc != request.host:
        raise errors.ApiError("forbidden", "Open the portal directly to continue.", 403)
    token = session.get("lab_csrf")
    supplied = request.headers.get("X-Portal-CSRF", "")
    if not isinstance(token, str) or not token or not secrets.compare_digest(supplied.encode(), token.encode()):
        raise errors.ApiError("forbidden", "Refresh the Experimental tab and try again.", 403)


def protected(fn):
    @functools.wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("lab_authenticated") or time.time() > session.get("lab_expires", 0):
            raise errors.ApiError("unauthorized", "Sign in to use the integration lab.", 401)
        if request.method != "GET":
            _csrf()
        return fn(*args, **kwargs)
    return wrapped


@bp.get("/status")
def status():
    from app.ai.bedrock import configuration
    session.setdefault("lab_csrf", secrets.token_urlsafe(32))
    base = _jira_base()
    return {"configured": bool(repo.setting("lab_password_hash")),
            "authenticated": bool(session.get("lab_authenticated") and time.time() < session.get("lab_expires", 0)),
            "csrf": session["lab_csrf"], "jira_configured": bool(base and os.environ.get("BMO_JIRA_TOKEN")),
            "jira_base_url": base, "bedrock": configuration()}


def _jira_base() -> str:
    """Only expose/use a valid server-configured HTTPS base, without URL credentials."""
    base = os.environ.get("BMO_JIRA_BASE_URL", "").strip().rstrip("/")
    try:
        parsed = urlsplit(base)
        valid_port = parsed.port is None or 1 <= parsed.port <= 65535
    except ValueError:
        return ""
    if (parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password
            or parsed.query or parsed.fragment or not valid_port or re.search(r"[\x00-\x20]", base)):
        return ""
    return base


@bp.post("/setup")
def setup():
    _csrf()
    if request.remote_addr not in ("127.0.0.1", "::1"):
        raise errors.ApiError("forbidden", "Create the lab password from the local machine.", 403)
    password = json_body().get("password", "")
    if not isinstance(password, str) or len(password) < 12 or len(password) > 256:
        raise errors.validation("Choose a password of 12–256 characters.", {"password": "Use at least 12 characters."})
    with db.transaction():
        if repo.setting("lab_password_hash"):
            raise errors.conflict("The integration lab already has a password. Sign in instead.")
        db.execute("INSERT INTO app_settings(key,value) VALUES ('lab_password_hash',?)", (generate_password_hash(password),))
    return _signed_in()


def _signed_in():
    session.clear()
    session.update(lab_authenticated=True, lab_expires=time.time() + 8 * 3600, lab_csrf=secrets.token_urlsafe(32))
    session.permanent = True
    from flask import current_app
    current_app.permanent_session_lifetime = timedelta(hours=8)
    return status()


@bp.post("/login")
def login():
    _csrf()
    # Persist throttling across requests and server restarts; no credentials are logged.
    db.execute("CREATE TABLE IF NOT EXISTS lab_attempts (address TEXT PRIMARY KEY, attempts INTEGER, started REAL)")
    address = request.remote_addr or "unknown"
    with db.transaction():
        row = db.query_one("SELECT * FROM lab_attempts WHERE address=?", (address,))
        if row and time.time() - row["started"] < 900 and row["attempts"] >= 5:
            raise errors.ApiError("rate_limited", "Too many attempts. Try again in 15 minutes.", 429)
        password = json_body().get("password", "")
        encoded = repo.setting("lab_password_hash")
        if not isinstance(password, str) or not encoded or not check_password_hash(encoded, password[:256]):
            attempts = row["attempts"] + 1 if row and time.time() - row["started"] < 900 else 1
            started = row["started"] if attempts > 1 else time.time()
            db.execute("INSERT INTO lab_attempts VALUES (?,?,?) ON CONFLICT(address) DO UPDATE SET attempts=excluded.attempts,started=excluded.started", (address, attempts, started))
            failed = True
        else:
            db.execute("DELETE FROM lab_attempts WHERE address=?", (address,))
            failed = False
    if failed:
        raise errors.ApiError("unauthorized", "The password is incorrect.", 401)
    return _signed_in()


@bp.post("/logout")
@protected
def logout():
    session.clear()
    return {"ok": True}


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


@bp.post("/jira-fetch")
@protected
def jira_fetch():
    key = str(json_body().get("issue_key", "")).strip().upper()
    if not re.fullmatch(r"[A-Z][A-Z0-9_]{1,30}-[1-9][0-9]{0,10}", key):
        raise errors.validation("Enter a Jira issue key.", {"issue_key": "For example, BIDC-123."})
    base = _jira_base()
    token = os.environ.get("BMO_JIRA_TOKEN", "")
    if not token or not base:
        raise errors.ApiError("not_configured", "Configure a valid HTTPS BMO_JIRA_BASE_URL and BMO_JIRA_TOKEN on the server first.", 422)
    api_version = os.environ.get("BMO_JIRA_API_VERSION", "3")
    if api_version not in ("2", "3"):
        api_version = "3"
    email = os.environ.get("BMO_JIRA_EMAIL", "")
    authorization = "Basic " + base64.b64encode(f"{email}:{token}".encode()).decode() if email else "Bearer " + token
    req = Request(f"{base}/rest/api/{api_version}/issue/{key}?expand=names", headers={"Authorization": authorization, "Accept": "application/json"})
    try:
        with build_opener(NoRedirect()).open(req, timeout=12) as response:
            raw = response.read(10 * 1024 * 1024 + 1)
        if len(raw) > 10 * 1024 * 1024:
            raise errors.ApiError("payload_too_large", "The Jira response exceeds 10 MB. Export a smaller set of fields.", 413)
        payload = json.loads(raw)
    except HTTPError as exc:
        raise errors.ApiError("jira_error", f"Jira returned HTTP {exc.code}. Check the host, token, and issue access.", 502) from None
    except (URLError, TimeoutError, OSError, ValueError):
        raise errors.ApiError("jira_error", "Jira could not be reached or did not return JSON. Check server connectivity and configuration.", 502) from None
    if not isinstance(payload, dict) or payload.get("key") != key or not isinstance(payload.get("fields"), dict):
        raise errors.ApiError("jira_error", "Jira returned an unexpected issue payload.", 502)
    return {"payload": payload, "source": f"{base}/browse/{key}"}


@bp.post("/json-preview")
@protected
def json_preview():
    from app.api.imports import preview_import
    return preview_import()
