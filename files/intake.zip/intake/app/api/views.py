"""Computed views: portfolio, health, Gantt, capacity, Pg 3 grid, burndown, L2 workflow, grooming, reminders,
governance. Numbers come from app.engines; derived writes go through app.services.derive."""
from __future__ import annotations

import json
from collections import defaultdict
from datetime import timedelta

from flask import Blueprint, jsonify, request

from app import db, errors
from app.engines import burndown as burndown_engine
from app.engines import calendar as cal
from app.engines import capacity, health, l2, reminders, schedule
from app.services import derive
from app.today import get_today, now_iso

bp = Blueprint("views", __name__, url_prefix="/api")

DIMENSIONS = health.RULES["dimensions"]
RAGS = ("Red", "Amber", "Green")
JSON_COLUMNS = ("labels", "sa_missing_json", "health_cached_json", "rag_overrides_json")


# ------------------------------------------------------------------ helpers
def _body() -> dict:
    """JSON object body; an empty body is {}. Malformed JSON or a non-object is 400 bad_request."""
    raw = request.get_data(cache=True)
    if not raw or not raw.strip():
        return {}
    try:
        data = json.loads(raw)
    except (ValueError, UnicodeDecodeError) as exc:
        raise errors.ApiError("bad_request", "The request could not be read.", 400) from exc
    if not isinstance(data, dict):
        raise errors.ApiError("bad_request", "Send the details as a set of named fields.", 400)
    return data


def _text(body: dict, key: str, max_len: int = 500) -> str:
    """Optional text field: missing is '', anything but text (or text over max_len) is 422."""
    value = body.get(key)
    if value is None:
        return ""
    if not isinstance(value, str):
        raise errors.validation(f"{key.replace('_', ' ').capitalize()} must be text.", {key: "Enter text."})
    value = value.strip()
    if len(value) > max_len:
        raise errors.validation(f"Keep {key.replace('_', ' ')} under {max_len} characters.", {key: "Too long."})
    return value


def _int_arg(name: str):
    value = request.args.get(name)
    if value in (None, ""):
        return None
    try:
        return int(value)
    except ValueError as exc:
        raise errors.validation(f"{name.replace('_', ' ').capitalize()} must be a number.",
                                {name: "Must be a whole number."}) from exc


def _month_arg(name: str, default: str) -> str:
    value = request.args.get(name)
    if value in (None, ""):
        return default
    try:
        _y, m = cal.parse_month(value)
        if len(value) != 7 or value[4] != "-" or not 1 <= m <= 12:
            raise ValueError
    except ValueError as exc:
        raise errors.validation("Months look like 2026-11.", {name: "Use the format YYYY-MM."}) from exc
    return value


def _persona() -> str:
    row = db.query_one("SELECT value FROM app_settings WHERE key = 'persona'")
    return (row or {}).get("value") or "DC PM"


def _log(entity_type, entity_id, action, detail=None, initiative_id=None) -> None:
    try:
        from app.activity import log_activity
    except ImportError:
        db.insert("activity_log", {"ts": now_iso(), "actor": "demo.user", "persona": _persona(),
                                   "entity_type": entity_type, "entity_id": entity_id, "initiative_id": initiative_id,
                                   "action": action, "detail_json": db.to_json(detail)})
        return
    log_activity(entity_type, entity_id, action, detail, initiative_id=initiative_id)


def _initiative_row(initiative_id) -> dict:
    row = db.query_one(
        "SELECT i.*, rq.name AS requestor_name, asg.name AS assigned_to_name, pm.name AS pm_name, "
        "tl.name AS tech_lead_name, dpm.name AS dc_pm_name, dsa.name AS dc_sa_name FROM initiatives i "
        "LEFT JOIN resources rq ON rq.id = i.requestor_id LEFT JOIN resources asg ON asg.id = i.assigned_to_id "
        "LEFT JOIN resources pm ON pm.id = i.pm_id LEFT JOIN resources tl ON tl.id = i.tech_lead_id "
        "LEFT JOIN resources dpm ON dpm.id = i.dc_pm_id LEFT JOIN resources dsa ON dsa.id = i.dc_sa_id "
        "WHERE i.id = ?", (initiative_id,))
    if row is None:
        raise errors.not_found("Initiative", initiative_id)
    if not row.get("requestor_name"):
        row["requestor_name"] = row.get("requestor")
    for k in JSON_COLUMNS:
        row[k] = db.from_json(row.get(k), [] if k in ("labels", "sa_missing_json") else None)
    if row.get("rag_overrides_json") is None:
        row["rag_overrides_json"] = {}
    return row


def _bundle(initiative_id) -> dict:
    from app import repo
    return repo.get_initiative_bundle(initiative_id)


def _health(initiative_id) -> dict:
    return health.compute_health(_bundle(initiative_id), get_today())


def _window(months_ahead: int = 5) -> list[str]:
    start = cal.month_key(get_today())
    return cal.month_range(start, cal.add_months(start, months_ahead))


def _capacity_people(team: str | None = None) -> list[dict]:
    people = db.query(
        "SELECT id, name, role, team, team_label, default_monthly_hours FROM resources "
        "WHERE capacity_eligible = 1 AND active = 1 ORDER BY id")
    if team:
        people = [p for p in people if team in (p["team"], p["team_label"])]
    avail = defaultdict(dict)
    for a in db.query("SELECT resource_id, month, available_hours FROM resource_availability"):
        avail[a["resource_id"]][a["month"]] = a["available_hours"]
    for p in people:
        p["availability"] = avail.get(p["id"], {})
    return people


def _allocations(months: list[str]) -> list[dict]:
    if not months:
        return []
    return db.query(
        "SELECT resource_id, month, firmness, SUM(hours) AS hours FROM allocations WHERE month BETWEEN ? AND ? "
        "GROUP BY resource_id, month, firmness", (months[0], months[-1]))


def _capacity_quarter(today) -> dict:
    """Quarter for the deck bars: the current fiscal quarter, or the next one in its last month."""
    q = cal.fiscal_quarter(today)
    if cal.month_key(today) == q["months"][-1]:
        q = cal.fiscal_quarter(cal.add_months(cal.month_key(today), 1))
    return q


def _scored_stage(stage) -> bool:
    return stage in health.RULES["scored_stages"]


# ------------------------------------------------------------------ portfolio
def portfolio_filters() -> dict:
    """Portfolio filters from the query string, validated."""
    filters = {k: request.args.get(k) or None for k in ("lob", "stage", "rag", "release")}
    filters["dc_pm_id"] = _int_arg("dc_pm_id")
    if filters["rag"] and filters["rag"] not in RAGS:
        raise errors.validation("RAG must be Red, Amber or Green.", {"rag": "Choose Red, Amber or Green."})
    return filters


def auto_comment(ini: dict, h: dict | None) -> str:
    """One-line status for a dashboard row with no PM comment, e.g.
    "Planned for DC-2702; L2 1,000 h approved; 2 business days float"."""
    stage = ini.get("stage")
    train = ini.get("target_release")
    hours = f"{cal.fmt_hours(ini['l2_hours'])} h" if ini.get("l2_hours") else None
    if stage == "Closed":
        return f"Delivered on {train}" if train else "Delivered"
    if stage in ("Intake", "Grooming"):
        return "Awaiting grooming"
    if stage == "Solution":
        sa = ini.get("sa_completeness")
        return f"Solution in progress; SA Completeness {sa}%" if sa is not None else "Solution in progress"
    if stage == "Estimation":
        if ini.get("l2_status") == "Pending approval" and hours:
            return f"L2 {hours} pending approval"
        return f"L2 {hours} {(ini.get('l2_status') or 'draft').lower()}" if hours else "L2 estimate not sent yet"
    parts = [f"Planned for {train}" if train else "No target release"]
    if hours and ini.get("l2_status") == "Approved":
        parts.append(f"L2 {hours} approved")
    fl = ((h or {}).get("dimensions", {}).get("schedule", {}).get("metrics") or {}).get("float_bd")
    if h is None or not h.get("scored"):
        parts.append("plan not generated yet")
    elif fl is not None and fl >= 0:
        parts.append(f"{fl} business day{'s' if fl != 1 else ''} float")
    elif fl is not None:
        parts.append(f"misses {train} by {-fl} business day{'s' if fl != -1 else ''}")
    return "; ".join(parts)


def build_portfolio(filters: dict | None = None) -> dict:
    """Portfolio payload (projects, KPIs, change management, team capacity, featured health)."""
    filters = filters or {}
    today = get_today()
    dc_pm_id = filters.get("dc_pm_id")
    rows = db.query(
        "SELECT i.*, dpm.name AS dc_pm_name FROM initiatives i LEFT JOIN resources dpm ON dpm.id = i.dc_pm_id "
        "WHERE i.id > 0 "
        "ORDER BY i.rddc")
    projects, healths = [], {}
    for i in rows:
        h = _health(i["id"]) if _scored_stage(i["stage"]) else None
        healths[i["id"]] = h
        rag = h["overall"] if h else None
        projects.append({
            "id": i["id"], "rddc": i["rddc"], "name": i["name"], "lob": i["lob"], "dc_pm_id": i["dc_pm_id"],
            "dc_pm_name": i["dc_pm_name"], "stage": i["stage"], "status": i["status"], "priority": i["priority"],
            "rag": rag, "scored": h is not None,
            "dimensions": {d: h["dimensions"][d]["rag"] for d in DIMENSIONS} if h else {},
            "attention": h["attention"] if h else [],
            "target_release": i["target_release"], "readiness_date": i["readiness_date"],
            "qa_signoff_date": i["qa_signoff_date"], "prod_date": i["prod_date"],
            "comments": (i["comments"] or "").strip() or auto_comment(i, h),
            "comments_auto": not (i["comments"] or "").strip(),
        })
    kpis = {
        "active": sum(1 for p in projects if p["stage"] != "Closed"),
        "red": sum(1 for p in projects if p["rag"] == "Red"),
        "amber": sum(1 for p in projects if p["rag"] == "Amber"),
        "green": sum(1 for p in projects if p["rag"] == "Green"),
    }

    def keep(p):
        return ((not filters.get("lob") or p["lob"] == filters["lob"])
                and (not filters.get("stage") or p["stage"] == filters["stage"])
                and (not filters.get("rag") or p["rag"] == filters["rag"])
                and (not filters.get("release") or p["target_release"] == filters["release"])
                and (dc_pm_id is None or p["dc_pm_id"] == dc_pm_id))

    projects = [p for p in projects if keep(p)]
    ids = {p["id"] for p in projects}

    monday = cal.week_monday(today)
    crs = derive.change_requests_with_compliance()
    kpis["crqs_this_week"] = sum(
        1 for c in crs if c.get("crq_start")
        and monday <= cal.to_date(c["crq_start"]) <= monday + timedelta(days=6))
    window = _window()
    people = _capacity_people()
    allocs = _allocations(window)
    kpis["overallocated_people"] = len({p["resource_id"] for p in capacity.person_peaks(people, allocs, window)})

    change_mgmt = [{
        "id": c["id"], "initiative_id": c["initiative_id"], "rddc": c["rddc"], "name": c["initiative_name"],
        "crq_number": c["crq_number"], "crq_start": c["crq_start"], "release_train": c["release_train"],
        "cms_lead_name": c["cms_lead_name"], "rel_lead_name": c["rel_lead_name"],
        "resource_name": c["resource_name"], "implementation_status": c["implementation_status"],
        "tech_validation_status": c["tech_validation_status"], "biz_validation_status": c["biz_validation_status"],
        "sto_approval": c["sto_approval"], "compliance_flags": [f["message"] for f in c["compliance"]["flags"]],
    } for c in crs if c["initiative_id"] in ids]

    q = _capacity_quarter(today)
    teams = capacity.team_totals(people, _allocations(q["months"]), q["months"])

    featured = None
    scored = [p for p in rows if healths.get(p["id"]) and p["stage"] != "Closed"]
    if scored:
        pick = max(scored, key=lambda r: r["id"])
        featured = {"initiative_id": pick["id"], "rddc": pick["rddc"], "name": pick["name"],
                    "health": healths[pick["id"]]}
    return {
        "kpis": kpis, "projects": projects, "change_mgmt": change_mgmt, "capacity_teams": teams,
        "capacity_period": q, "health_tiles": {"overall": featured}, "today": today.isoformat(),
        "rule_text": health.RULE_TEXT_OVERALL, "attention_rule": health.RULES["attention_rule"],
    }


@bp.get("/portfolio")
def portfolio():
    return jsonify(build_portfolio(portfolio_filters()))


@bp.get("/portfolio/gantt")
def portfolio_gantt():
    today = get_today()
    rows = db.query(
        "SELECT i.id, i.rddc, i.name, i.stage, i.lob, i.planned_start, i.planned_end, i.readiness_date, "
        "i.prod_date, i.target_release, MIN(t.planned_start) AS t_start, MAX(t.planned_end) AS t_end "
        "FROM initiatives i LEFT JOIN wbs_tasks t ON t.initiative_id = i.id WHERE i.id > 0 GROUP BY i.id "
        "ORDER BY i.rddc")
    out = []
    for r in rows:
        start = r["t_start"] or r["planned_start"]
        end = r["t_end"] or r["planned_end"]
        if not start or not end:
            continue
        h = _health(r["id"]) if _scored_stage(r["stage"]) else None
        out.append({"initiative_id": r["id"], "rddc": r["rddc"], "name": r["name"], "lob": r["lob"],
                    "rag": h["overall"] if h else None, "stage": r["stage"], "start": start, "end": end,
                    "readiness_date": r["readiness_date"], "prod_date": r["prod_date"],
                    "target_release": r["target_release"]})
    return jsonify({
        "start": min((r["start"] for r in out), default=today.isoformat()),
        "end": max((r["end"] for r in out), default=today.isoformat()),
        "today": today.isoformat(), "freeze": cal.freeze_window(),
        "trains": [{"code": t["code"], "train_date": t["train_date"]} for t in _trains()],
        "rows": out,
    })


def _trains() -> list[dict]:
    rows = db.query("SELECT code, train_date, status FROM release_trains ORDER BY train_date")
    return rows or [{"code": t["code"], "train_date": t["train_date"], "status": t["status"]}
                    for t in cal.release_trains(get_today())]


# ------------------------------------------------------------------ intake queue
def _waiting(ini: dict, comps: list[dict], today) -> tuple[str | None, str | None]:
    if ini["l2_status"] == "Pending approval" and ini["l2_submitted_at"]:
        return (reminders.next_reminder(ini["l2_submitted_at"], reminders.RULES["l2_every_bd"], today).isoformat(),
                ini["requestor_name"] or ini["requestor"])
    sa = ini["sa_completeness"]
    if ini["dc_sa_id"] and (sa is None or sa < 100) and (ini["sa_doc_attachment_id"] or ini["stage"] in
                                                          reminders.RULES["sa_waiting_stages"]):
        since = ini["sa_uploaded_at"] or ini["created_at"] or today
        return (reminders.next_reminder(since, reminders.RULES["sa_every_bd"], today).isoformat(), ini["dc_sa_name"])
    pending = [c for c in comps if c["approval"] == "Pending" and c["lead_name"]]
    if pending:
        since = ini["l2_submitted_at"] or ini["created_at"] or today
        return (reminders.next_reminder(since, reminders.RULES["approval_every_bd"], today).isoformat(),
                pending[0]["lead_name"])
    return None, None


def _sessions_payload(today) -> list[dict]:
    sessions = db.query("SELECT * FROM grooming_sessions WHERE session_date >= ? ORDER BY session_date, start_time",
                        (today.isoformat(),))
    names = {r["id"]: r["name"] for r in db.query("SELECT id, name FROM resources")}
    slots = db.query(
        "SELECT s.*, i.rddc, i.name, i.priority FROM grooming_slots s JOIN initiatives i ON i.id = s.initiative_id "
        "ORDER BY s.session_id, s.slot_order")
    by_session = defaultdict(list)
    for s in slots:
        ids = db.from_json(s.pop("recipients_json"), []) or []
        s["recipients"] = [{"id": i, "name": names.get(i)} for i in ids if names.get(i)]
        by_session[s["session_id"]].append(s)
    for s in sessions:
        s["label"] = f"{cal.fmt_day(s['session_date'])}, {s['start_time']}"
        s["slots"] = by_session.get(s["id"], [])
        s["free"] = max(0, int(s["capacity"] or 0) - len(s["slots"]))
    return sessions


@bp.get("/intake-queue")
def intake_queue():
    return jsonify(build_intake_queue())


def build_intake_queue() -> dict:
    """Pre-planning intakes with their grooming slot and who they are waiting on, plus upcoming sessions."""
    today = get_today()
    inis = db.query(
        "SELECT i.*, sa.name AS dc_sa_name, rq.name AS requestor_name, a.uploaded_at AS sa_uploaded_at "
        "FROM initiatives i LEFT JOIN resources sa ON sa.id = i.dc_sa_id LEFT JOIN resources rq ON "
        "rq.id = i.requestor_id LEFT JOIN attachments a ON a.id = i.sa_doc_attachment_id "
        "WHERE i.id > 0 AND i.stage IN ('Intake', 'Grooming', 'Solution', 'Estimation') "
        "ORDER BY i.priority, i.created_at, i.id")
    comps = defaultdict(list)
    for c in db.query("SELECT ic.initiative_id, ic.approval, r.name AS lead_name FROM initiative_components ic "
                      "LEFT JOIN resources r ON r.id = ic.component_lead_id"):
        comps[c["initiative_id"]].append(c)
    sessions = _sessions_payload(today)
    slot_of = {}
    for s in sessions:
        for slot in s["slots"]:
            slot_of.setdefault(slot["initiative_id"], {"id": s["id"], "session_date": s["session_date"],
                                                       "start_time": s["start_time"], "label": s["label"],
                                                       "status": slot["status"]})
    items = []
    for i in inis:
        by, who = _waiting(i, comps.get(i["id"], []), today)
        items.append({"initiative_id": i["id"], "rddc": i["rddc"], "name": i["name"], "lob": i["lob"],
                      "priority": i["priority"], "stage": i["stage"], "submitted_at": i["created_at"],
                      "session": slot_of.get(i["id"]), "action_required_by": by, "waiting_on": who,
                      "sa_completeness": i["sa_completeness"], "l2_status": i["l2_status"]})
    return {"items": items, "total": len(items), "sessions": sessions}


# ------------------------------------------------------------------ health & gantt
@bp.get("/initiatives/<int:initiative_id>/health")
def initiative_health(initiative_id):
    return jsonify(_health(initiative_id))


@bp.put("/initiatives/<int:initiative_id>/health/override")
def health_override(initiative_id):
    body = _body()
    dim = body.get("dimension")
    rag = body.get("rag")
    reason = _text(body, "reason")
    if not isinstance(dim, str) or dim not in DIMENSIONS:
        raise errors.validation("Choose a health dimension.",
                                {"dimension": "Use schedule, resources, scope, dependencies or budget."})
    if rag is not None and (not isinstance(rag, str) or rag not in RAGS):
        raise errors.validation("RAG must be Red, Amber or Green.", {"rag": "Choose Red, Amber or Green."})
    if rag is not None and not reason:
        raise errors.validation("Add a reason for the override.", {"reason": "A reason is required."})
    ini = _initiative_row(initiative_id)
    overrides = dict(ini["rag_overrides_json"] or {})
    if rag is None:
        overrides.pop(dim, None)
    else:
        overrides[dim] = {"rag": rag, "reason": reason, "by": _persona(), "at": now_iso()}
    with db.transaction():
        db.execute("UPDATE initiatives SET rag_overrides_json = ?, updated_at = ? WHERE id = ?",
                   (db.to_json(overrides), now_iso(), initiative_id))
        _log("initiative", initiative_id, "update",
             {"label": f"{ini['rddc']} {dim} health ({'override ' + rag if rag else 'override cleared'})",
              "dimension": dim, "rag": rag, "reason": reason}, initiative_id)
        result = derive.refresh_health(initiative_id)
    return jsonify(result)


def gantt_payload(bundle: dict) -> dict:
    return schedule.build_gantt(bundle.get("tasks") or [], get_today(),
                                target_train=bundle.get("target_train"), trains=_trains())


@bp.get("/initiatives/<int:initiative_id>/gantt")
def initiative_gantt(initiative_id):
    return jsonify(gantt_payload(_bundle(initiative_id)))


# ------------------------------------------------------------------ capacity
@bp.get("/capacity")
def capacity_view():
    this_month = cal.month_key(get_today())
    start = _month_arg("from", this_month)
    end = _month_arg("to", cal.add_months(start, 5))
    if end < start:
        raise errors.validation("The end month is before the start month.", {"to": "Pick a later month."})
    if len(cal.month_range(start, end)) > 36:
        raise errors.validation("Pick a range of three years or less.", {"to": "Range too long."})
    group = request.args.get("group") or "resource"
    if group not in ("resource", "team", "quarter"):
        raise errors.validation("Group by resource, team or quarter.", {"group": "Use resource, team or quarter."})
    initiative_id = _int_arg("initiative_id")
    months = cal.month_range(start, end)
    if group == "quarter":
        months = cal.month_range(cal.fiscal_quarter(start)["months"][0], cal.fiscal_quarter(end)["months"][-1])
    people = _capacity_people(request.args.get("team") or None)
    if initiative_id is not None:
        _initiative_row(initiative_id)
        on_plan = {r["resource_id"] for r in db.query(
            "SELECT DISTINCT resource_id FROM allocations WHERE initiative_id = ?", (initiative_id,))}
        people = [p for p in people if p["id"] in on_plan]
    result = capacity.compute_capacity(people, _allocations(months), months, group)
    result.update({"from": start, "to": end, "group": group,
                   "bands": {"spare": "Under 70%", "ok": "70–100%", "stretched": "101–110%", "over": "Over 110%"}})
    return jsonify(result)


@bp.get("/initiatives/<int:initiative_id>/resource-grid")
def resource_grid(initiative_id):
    return jsonify(build_resource_grid(initiative_id))


def build_resource_grid(initiative_id) -> dict:
    """Pg 3 grid: people on this initiative × fiscal quarters (with month drill-down) plus assignments."""
    ini = _initiative_row(initiative_id)
    today = get_today()
    own = db.query("SELECT resource_id, month, SUM(hours) AS hours FROM allocations WHERE initiative_id = ? "
                   "GROUP BY resource_id, month", (initiative_id,))
    by_fy = defaultdict(float)
    for a in own:
        by_fy[cal.fiscal_year(a["month"])] += a["hours"]
    if by_fy:
        fy = min(by_fy.items(), key=lambda kv: (-kv[1], kv[0]))[0]
    else:
        fy = _capacity_quarter(today)["fy"]
    quarters = cal.fiscal_quarters(fy)
    months = [m for q in quarters for m in q["months"]]
    on_plan = {a["resource_id"] for a in own}
    own_by = defaultdict(float)
    for a in own:
        own_by[(a["resource_id"], a["month"])] += a["hours"]
    people = [p for p in _capacity_people() if p["id"] in on_plan]
    demand = capacity.demand_by_resource_month(_allocations(months))

    rows = []
    for p in people:
        month_cells = []
        for m in months:
            d = demand.get((p["id"], m), {"confirmed": 0.0, "tentative": 0.0})
            avail = capacity.available_hours(p, m)
            total = d["confirmed"] + d["tentative"]
            util = capacity.utilisation(total, avail)
            month_cells.append({"month": m, "label": cal.month_label(m),
                                "quarter": cal.quarter_short(cal.fiscal_quarter(m)), "availability": round(avail, 1),
                                "allocation": round(total, 1), "confirmed": round(d["confirmed"], 1),
                                "tentative": round(d["tentative"], 1), "this_initiative": round(own_by[(p["id"], m)], 1),
                                "util": util, "band": capacity.band(util, total)})
        cells = []
        for q in quarters:
            mc = [c for c in month_cells if c["month"] in q["months"]]
            avail = sum(c["availability"] for c in mc)
            conf = sum(c["confirmed"] for c in mc)
            tent = sum(c["tentative"] for c in mc)
            util = capacity.utilisation(conf + tent, avail)
            peak = max(mc, key=lambda c: (c["util"] if c["util"] is not None else (99 if c["allocation"] else -1)))
            cells.append({"quarter": q["q"], "fy": q["fy"], "label": q["label"], "availability": round(avail, 1),
                          "allocation": round(conf + tent, 1), "confirmed": round(conf, 1), "tentative": round(tent, 1),
                          "this_initiative": round(sum(c["this_initiative"] for c in mc), 1),
                          "util": util, "band": capacity.band(util, conf + tent),
                          "peak_month": peak["month"], "peak_util": peak["util"], "peak_band": peak["band"]})
        rows.append({"resource_id": p["id"], "name": p["name"], "team": capacity.team_label(p),
                     "role": p["role"], "cells": cells, "months": month_cells})

    firmness = "confirmed" if ini["l2_status"] == "Approved" else "tentative"
    tasks = db.query(
        "SELECT t.id, t.wbs_code, t.resource_id, r.name AS resource_name, t.est_hours, t.allocation_pct, "
        "t.planned_start, t.planned_end, t.parent_id FROM wbs_tasks t LEFT JOIN resources r ON r.id = t.resource_id "
        "WHERE t.initiative_id = ? ORDER BY t.sort, t.id", (initiative_id,))
    assignments = [{"task_id": t["id"], "resource_id": t["resource_id"], "resource_name": t["resource_name"],
                    "wbs_code": t["wbs_code"], "hours": t["est_hours"], "allocation_pct": t["allocation_pct"],
                    "from": t["planned_start"], "to": t["planned_end"], "firmness": firmness}
                   for t in tasks if t["resource_id"] and float(t["est_hours"] or 0) > 0]
    return {"fy": fy, "quarters": quarters, "rows": rows, "assignments": assignments, "firmness": firmness}


# ------------------------------------------------------------------ PRN burndown
def _planned_by_month(prn_code) -> dict:
    rows = db.query("SELECT a.month, SUM(a.hours) AS hours FROM allocations a JOIN initiatives i ON "
                    "i.id = a.initiative_id WHERE i.prn_code = ? GROUP BY a.month", (prn_code,))
    return {r["month"]: r["hours"] for r in rows}


def _prn_burndown(prn_code) -> dict:
    prn = db.query_one("SELECT * FROM prn_budget WHERE prn_code = ?", (prn_code,))
    if prn is None:
        raise errors.not_found("PRN", prn_code)
    charges = db.query("SELECT month, charged_hours, charged_amount FROM prn_charges WHERE prn_code = ? "
                       "ORDER BY month", (prn_code,))
    result = burndown_engine.burndown(prn, charges, _planned_by_month(prn_code), get_today())
    result["initiatives"] = db.query("SELECT id, rddc, name FROM initiatives WHERE prn_code = ? AND id > 0 ORDER BY rddc",
                                     (prn_code,))
    return result


@bp.get("/prns")
def prns():
    items = []
    for p in db.query("SELECT * FROM prn_budget ORDER BY prn_code"):
        b = _prn_burndown(p["prn_code"])
        items.append({"prn_code": p["prn_code"], "name": p["name"], "lob": p["lob"],
                      "funded_hours": p["funded_hours"], "charged_hours": b["charged_hours"],
                      "forecast_hours": b["forecast_hours"], "status": b["status"],
                      "exhaust_month": b["exhaust_month"], "initiatives": b["initiatives"]})
    return jsonify({"items": items, "total": len(items)})


@bp.get("/prn/<path:prn_code>/burndown")
def prn_burndown(prn_code):
    return jsonify(_prn_burndown(prn_code))


@bp.get("/initiatives/<int:initiative_id>/burndown")
def initiative_burndown(initiative_id):
    ini = _initiative_row(initiative_id)
    if not ini.get("prn_code"):
        raise errors.ApiError("not_found", "This initiative has no PRN yet. Add the PRN on Pg 1.", 404,
                              {"entity": "PRN", "id": None})
    return jsonify(_prn_burndown(ini["prn_code"]))


# ------------------------------------------------------------------ L2 workflow
def _l2_estimate(initiative_id) -> dict:
    comps = db.query(
        "SELECT ic.*, c.code, c.name FROM initiative_components ic JOIN dc_components c ON c.id = ic.component_id "
        "WHERE ic.initiative_id = ? ORDER BY ic.sort, ic.id", (initiative_id,))
    catalog = db.query("SELECT * FROM dc_components ORDER BY id")
    return l2.estimate_l2(comps, catalog)


@bp.post("/initiatives/<int:initiative_id>/l2/calculate")
def l2_calculate(initiative_id):
    _initiative_row(initiative_id)
    return jsonify(_l2_estimate(initiative_id))


def _dismiss_l2_reminders(initiative_id) -> None:
    db.execute("UPDATE notifications SET status = 'Dismissed' WHERE initiative_id = ? AND status = 'Queued' "
               "AND rule IN ('l2_approval', 'l2_escalation')", (initiative_id,))


@bp.post("/initiatives/<int:initiative_id>/l2/submit")
def l2_submit(initiative_id):
    _body()
    ini = _initiative_row(initiative_id)
    if ini["l2_status"] == "Approved":
        raise errors.conflict("The L2 estimate is already approved.")
    est = _l2_estimate(initiative_id)
    if not est["by_component"]:
        raise errors.validation("Add at least one DC component before sending L2 for approval.",
                                {"components": "No DC components yet."})
    sa = ini.get("sa_completeness")
    if sa is None or sa < 70:
        raise errors.validation(
            "SA Completeness must be at least 70% before L2 goes for approval.",
            {"sa_completeness": f"SA Completeness is {sa}%." if sa is not None else "No SA document scored yet."})
    today = get_today()
    stamp = now_iso()
    with db.transaction():
        values = {"l2_hours": est["total_hours"], "l2_low_hours": est["low_hours"],
                  "l2_high_hours": est["high_hours"], "l2_tshirt": est["tshirt"], "l2_status": "Pending approval",
                  "l2_submitted_at": stamp, "l2_reminders_sent": 0, "updated_at": stamp}
        if ini["stage"] in ("Intake", "Grooming", "Solution"):
            values["stage"] = "Estimation"
        db.update("initiatives", initiative_id, values)
        due = cal.add_business_days(today, reminders.RULES["l2_every_bd"])
        note = derive.queue_notification({
            "rule": "l2_approval", "dedupe_key": f"l2_approval:initiative:{initiative_id}:request:{stamp}",
            "initiative_id": initiative_id, "entity_type": "initiative", "entity_id": initiative_id,
            "to_resource_id": ini.get("requestor_id"), "to_name": ini.get("requestor_name") or "Requestor",
            "cc_names": [ini.get("dc_pm_name")] if ini.get("dc_pm_name") else [],
            "subject": f"Action required by {cal.fmt_day(due)}: approve the L2 estimate for {ini['rddc']}",
            "body": (f"The L2 estimate for {ini['rddc']} {ini['name']} is {cal.fmt_hours(est['total_hours'])} h "
                     f"(T-shirt {est['tshirt']}, range {cal.fmt_hours(est['low_hours'])}–"
                     f"{cal.fmt_hours(est['high_hours'])} h). Please approve or reject it by "
                     f"{cal.fmt_day_long(due)}."),
            "trigger_event": "L2 sent for approval", "action_required_by": due.isoformat(),
            "due_at": today.isoformat(),
        })
        _log("initiative", initiative_id, "submit", {"label": f"{ini['rddc']} L2 estimate for approval",
                                                     "total_hours": est["total_hours"], "tshirt": est["tshirt"]},
             initiative_id)
        derive.rebuild_allocations(initiative_id)
        derive.refresh_health(initiative_id)
    return jsonify({"initiative": _initiative_row(initiative_id), "notifications": [note] if note else [],
                    "estimate": est})


@bp.post("/initiatives/<int:initiative_id>/l2/approve")
def l2_approve(initiative_id):
    body = _body()
    comment = _text(body, "comment")
    ini = _initiative_row(initiative_id)
    if ini["l2_status"] == "Approved":
        raise errors.conflict("The L2 estimate is already approved.")
    if ini["l2_status"] != "Pending approval":
        raise errors.conflict("Send the L2 estimate for approval first.")
    stamp = now_iso()
    approver = _text(body, "approved_by", 120) or ini.get("requestor_name") or _persona()
    with db.transaction():
        values = {"l2_status": "Approved", "l2_approved_at": stamp, "l2_approved_by": approver,
                  "l2_baseline_hours": ini["l2_hours"], "updated_at": stamp}
        if ini["stage"] in derive.PRE_PLANNING:
            values["stage"] = "Planning"
        if ini["status"] == "Backlog":
            values["status"] = "In progress"
        db.update("initiatives", initiative_id, values)
        unbased = db.scalar("SELECT COUNT(*) FROM wbs_tasks WHERE initiative_id = ? AND baseline_end IS NULL "
                            "AND planned_end IS NOT NULL", (initiative_id,))
        if unbased:
            db.execute("UPDATE wbs_tasks SET baseline_start = planned_start, baseline_end = planned_end "
                       "WHERE initiative_id = ? AND baseline_end IS NULL", (initiative_id,))
            db.execute("UPDATE initiatives SET baseline_set_at = ? WHERE id = ?", (stamp, initiative_id))
        hours = cal.fmt_hours(ini["l2_hours"])
        db.insert("decisions", {
            "initiative_id": initiative_id, "title": "L2 estimate approved",
            "context": comment or f"L2 sent for approval {cal.fmt_date(ini['l2_submitted_at'])}.",
            "decision": (f"L2 approved at {hours} h (T-shirt {ini['l2_tshirt']}, range "
                         f"{cal.fmt_hours(ini['l2_low_hours'])}–{cal.fmt_hours(ini['l2_high_hours'])} h). "
                         "Baseline hours locked; demand is now confirmed."),
            "decided_by": approver, "decided_on": get_today().isoformat(), "status": "Approved",
            "source": "system", "created_at": stamp,
        })
        _dismiss_l2_reminders(initiative_id)
        _log("initiative", initiative_id, "approve", {"label": f"{ini['rddc']} L2 estimate", "l2_hours": ini["l2_hours"],
                                                      "comment": comment}, initiative_id)
        derive.rebuild_allocations(initiative_id)
        result = derive.refresh_health(initiative_id)
    return jsonify({"initiative": _initiative_row(initiative_id), "health": result})


@bp.post("/initiatives/<int:initiative_id>/l2/reject")
def l2_reject(initiative_id):
    body = _body()
    reason = _text(body, "reason")
    if not reason:
        raise errors.validation("Add a reason for rejecting the L2 estimate.", {"reason": "A reason is required."})
    ini = _initiative_row(initiative_id)
    if ini["l2_status"] != "Pending approval":
        raise errors.conflict("Only an L2 estimate waiting for approval can be rejected.")
    stamp = now_iso()
    with db.transaction():
        db.update("initiatives", initiative_id, {"l2_status": "Rejected", "updated_at": stamp})
        db.insert("decisions", {
            "initiative_id": initiative_id, "title": "L2 estimate rejected", "context": reason,
            "decision": f"L2 estimate of {cal.fmt_hours(ini['l2_hours'])} h rejected; re-estimate required.",
            "decided_by": ini.get("requestor_name") or _persona(), "decided_on": get_today().isoformat(),
            "status": "Approved", "source": "system", "created_at": stamp,
        })
        _dismiss_l2_reminders(initiative_id)
        _log("initiative", initiative_id, "reject", {"label": f"{ini['rddc']} L2 estimate", "reason": reason},
             initiative_id)
        derive.rebuild_allocations(initiative_id)
        derive.refresh_health(initiative_id)
    return jsonify({"initiative": _initiative_row(initiative_id)})


# ------------------------------------------------------------------ grooming & reminders
@bp.post("/grooming/auto-slot")
def grooming_auto_slot():
    body = _body()
    dry_run = body.get("dry_run", False)
    if not isinstance(dry_run, bool):
        raise errors.validation("Dry run must be true or false.", {"dry_run": "Use true or false."})
    result = derive.auto_slot_grooming(dry_run=dry_run)
    if not dry_run and result["assignments"]:
        n = len(result["assignments"])
        _log("grooming_slot", None, "create", {"label": f"{n} intake{'s' if n != 1 else ''} on the grooming agenda",
                                               "slotted": n})
    return jsonify({**result, "dry_run": dry_run})


@bp.post("/reminders/run")
def reminders_run():
    body = _body()
    now = body.get("now")
    if now is not None and not isinstance(now, str):
        raise errors.validation("Use a date like 2026-10-21.", {"now": "Not a valid date."})
    if now:
        try:
            cal.to_date(now)
        except ValueError as exc:
            raise errors.validation("Use a date like 2026-10-21.", {"now": "Not a valid date."}) from exc
    return jsonify(derive.run_reminders(now))


# ------------------------------------------------------------------ governance
@bp.get("/governance/weekly")
def governance_weekly():
    week = request.args.get("week")
    try:
        monday = cal.parse_iso_week(week) if week else cal.week_monday(get_today())
    except ValueError as exc:
        raise errors.validation("Weeks look like 2026-W43.", {"week": str(exc)}) from exc
    end = monday + timedelta(days=13)
    items = [c for c in derive.change_requests_with_compliance()
             if c.get("crq_start") and monday <= cal.to_date(c["crq_start"]) <= end]
    return jsonify({"week": cal.iso_week(monday), "from": monday.isoformat(), "to": end.isoformat(),
                    "items": items, "total": len(items),
                    "noncompliant_count": sum(1 for c in items if not c["compliance"]["ok"])})


@bp.get("/governance/approvals")
def governance_approvals():
    today = get_today()
    items = []
    for i in db.query("SELECT i.*, rq.name AS requestor_name FROM initiatives i LEFT JOIN resources rq ON "
                      "rq.id = i.requestor_id WHERE i.id > 0 AND i.l2_status = 'Pending approval'"):
        items.append({"kind": "l2", "initiative_id": i["id"], "rddc": i["rddc"], "name": i["name"],
                      "entity_id": i["id"], "title": f"L2 estimate {cal.fmt_hours(i['l2_hours'])} h "
                                                     f"({i['l2_tshirt'] or 'size not set'})",
                      "requested_at": i["l2_submitted_at"],
                      "waiting_days": max(0, cal.business_days_after(i["l2_submitted_at"] or today, today)),
                      "approver": i["requestor_name"] or i["requestor"]})
    comps = db.query(
        "SELECT ic.id, ic.initiative_id, c.name AS component_name, r.name AS lead_name, i.rddc, i.name, "
        "i.l2_submitted_at, i.created_at FROM initiative_components ic JOIN initiatives i ON i.id = ic.initiative_id "
        "JOIN dc_components c ON c.id = ic.component_id LEFT JOIN resources r ON r.id = ic.component_lead_id "
        "WHERE ic.approval = 'Pending' AND i.stage <> 'Closed' AND i.id > 0")
    for c in comps:
        since = derive._component_since(c["id"], c["l2_submitted_at"] or c["created_at"]) or today.isoformat()
        items.append({"kind": "component", "initiative_id": c["initiative_id"], "rddc": c["rddc"], "name": c["name"],
                      "entity_id": c["id"], "title": f"{c['component_name']} approval", "requested_at": since,
                      "waiting_days": max(0, cal.business_days_after(since, today)),
                      "approver": c["lead_name"] or "Component Lead"})
    for cr in derive.change_requests_with_compliance():
        start = cal.to_date(cr.get("crq_start"))
        if cr.get("sto_approval") in ("Go", "No-Go") or start is None or start < today:
            continue
        since = cr.get("raised_at") or cr.get("created_at") or today.isoformat()
        items.append({"kind": "sto", "initiative_id": cr["initiative_id"], "rddc": cr["rddc"],
                      "name": cr["initiative_name"], "entity_id": cr["id"],
                      "title": f"STO decision for {cr['crq_number'] or 'CRQ'} ({cal.fmt_date(start)})"
                               + (f"; suggested {cr['compliance']['sto_suggestion']}"
                                  if cr["compliance"].get("sto_suggestion") else ""),
                      "requested_at": since, "waiting_days": max(0, cal.business_days_after(since, today)),
                      "approver": "STO Board"})
    items.sort(key=lambda x: (-x["waiting_days"], x["rddc"]))
    return jsonify({"items": items, "total": len(items)})
