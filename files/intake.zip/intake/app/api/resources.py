"""Resources (owner B1): people, monthly availability (Account Manager), allocations, skills and the skill matrix.
Contracts: docs/contracts.md §2 "resources".
"""
from __future__ import annotations

import math

from flask import Blueprint, request

from app import db, errors, repo
from app.activity import actor_name, log_activity
from app.api._shared import MONTH_RE, Fields, json_body, listed
from app.today import get_today

bp = Blueprint("resources", __name__, url_prefix="/api")

RESOURCE_COLUMNS = ("name", "email", "role", "team", "team_label", "component_id", "location", "hourly_rate",
                    "default_monthly_hours", "capacity_eligible", "active")


def _resource_fields(data: dict, *, creating: bool) -> Fields:
    f = Fields(data)
    f.text("name", required=creating, max_len=120)
    f.text("role", required=creating, max_len=80)
    f.text("email", max_len=200)
    f.text("team", max_len=40)
    f.text("team_label", max_len=40)
    f.ref("component_id", "dc_components", label="DC component")
    f.text("location", max_len=80)
    f.number("hourly_rate", lo=0, hi=1000)
    f.number("default_monthly_hours", lo=0, hi=744)
    f.flag("capacity_eligible")
    f.flag("active")
    if not creating:
        for required in ("name", "role"):
            if required in f.out and f.out[required] is None:
                f.error(required, "This field is required.")
    return f


def _hydrate(rows: list[dict]) -> list[dict]:
    ids = [r["id"] for r in rows]
    month = get_today().isoformat()[:7]
    avail = repo.availability_map(ids)
    committed = repo.committed_map(ids, [month])
    skills = repo.resource_skills(ids)
    for r in rows:
        r["availability"] = avail.get(r["id"], {})
        r["skills"] = [{"skill": s["skill"], "level": s["level"]} for s in skills.get(r["id"], [])]
        available = r["availability"].get(month)
        allocated = committed.get(r["id"], {}).get(month, 0.0)
        r["current_load"] = None if not r["capacity_eligible"] else {
            "month": month, "allocated": allocated, "available": available,
            "util": (allocated / available) if available else None}
    return rows


def _resource(rid) -> dict:
    row = db.query_one("SELECT r.*, c.code AS component_code FROM resources r LEFT JOIN dc_components c "
                       "ON c.id = r.component_id WHERE r.id = ?", (rid,))
    if row is None:
        raise errors.not_found("Resource", rid)
    return _hydrate([row])[0]


def _affected_initiatives(rid) -> list[int]:
    return [r["initiative_id"] for r in db.query("SELECT DISTINCT initiative_id FROM allocations WHERE resource_id = ?",
                                                  (rid,))]


@bp.get("/resources")
def list_resources():
    sql, where, params = ("SELECT r.*, c.code AS component_code FROM resources r LEFT JOIN dc_components c "
                          "ON c.id = r.component_id "), [], []
    tracked = request.args.get("tracked")
    if tracked in ("0", "1"):
        where.append("r.capacity_eligible = ?")
        params.append(int(tracked))
    elif tracked not in (None, ""):
        raise errors.validation("Some filters need attention.", {"tracked": "Use 1 or 0."})
    team = request.args.get("team")
    if team:
        clause = repo._in_clause("r.team", team, params)
        if clause:
            where.append(clause)
    if request.args.get("active", "1") != "all":
        where.append("r.active = 1")
    rows = db.query(sql + ("WHERE " + " AND ".join(where) + " " if where else "") + "ORDER BY r.id", params)
    return listed(_hydrate(rows))


@bp.post("/resources")
def create_resource():
    values = _resource_fields(json_body(), creating=True).check()
    if db.query_one("SELECT 1 AS x FROM resources WHERE name = ?", (values["name"],)):
        raise errors.conflict(f"{values['name']} is already in the resource list.")
    values.setdefault("capacity_eligible", 1)
    if values.get("default_monthly_hours") is None:
        values["default_monthly_hours"] = 140.0 if values["capacity_eligible"] else 0.0
    if not values.get("team_label"):
        values["team_label"] = values.get("team")
    with db.transaction():
        rid = db.insert("resources", {k: v for k, v in values.items() if k in RESOURCE_COLUMNS})
        if values["capacity_eligible"]:
            bounds = db.query_one("SELECT MIN(month) AS first, MAX(month) AS last FROM resource_availability")
            first = bounds["first"] or get_today().isoformat()[:7]
            last = bounds["last"] or repo.shift_month(first, 12)
            db.executemany(
                "INSERT INTO resource_availability (resource_id, month, available_hours, updated_by) VALUES (?, ?, ?, ?)",
                [(rid, m, values["default_monthly_hours"], actor_name()) for m in repo.month_span(first, last)])
        log_activity("resource", rid, "create", {"label": values["name"]})
    return _resource(rid), 201


@bp.put("/resources/<int:rid>")
def update_resource(rid: int):
    current = _resource(rid)
    values = _resource_fields(json_body(), creating=False).check()
    if values.get("name") and values["name"] != current["name"] and db.query_one(
            "SELECT 1 AS x FROM resources WHERE name = ? AND id <> ?", (values["name"], rid)):
        raise errors.conflict(f"{values['name']} is already in the resource list.")
    changes = {k: [current.get(k), v] for k, v in values.items() if current.get(k) != v}
    if not changes:
        return current
    with db.transaction():
        db.update("resources", rid, {k: v for k, v in values.items() if k in RESOURCE_COLUMNS})
        log_activity("resource", rid, "update", {"label": current["name"], "changes": changes})
        for iid in _affected_initiatives(rid):
            repo.sync_derived(iid)
    return _resource(rid)


def _months_payload(rid: int, first: str | None = None, last: str | None = None) -> dict:
    sql, params = "SELECT month, available_hours FROM resource_availability WHERE resource_id = ? ", [rid]
    if first:
        sql += "AND month >= ? "
        params.append(first)
    if last:
        sql += "AND month <= ? "
        params.append(last)
    rows = db.query(sql + "ORDER BY month", params)
    return {"resource_id": rid, "months": {r["month"]: float(r["available_hours"]) for r in rows}}


def _month_arg(name: str):
    raw = request.args.get(name)
    if raw in (None, ""):
        return None
    if not MONTH_RE.match(raw):
        raise errors.validation("Some filters need attention.", {name: "Use a month like 2026-11."})
    return raw


@bp.get("/resources/<int:rid>/availability")
def get_availability(rid: int):
    repo.require("resources", rid, "Resource")
    return _months_payload(rid, _month_arg("from"), _month_arg("to"))


@bp.put("/resources/<int:rid>/availability")
def put_availability(rid: int):
    res = repo.require("resources", rid, "Resource")
    body = json_body()
    months = body.get("months")
    if not isinstance(months, dict) or not months:
        raise errors.validation("Send the monthly hours to update.", {"months": "Send hours by month, e.g. 2026-11: 120."})
    field_errors, clean = {}, {}
    for month, hours in months.items():
        if not isinstance(month, str) or not MONTH_RE.match(month):
            field_errors[str(month)] = "Use a month like 2026-11."
            continue
        if isinstance(hours, bool) or not isinstance(hours, (int, float)) or math.isnan(hours) or not 0 <= hours <= 744:
            field_errors[month] = "Enter hours between 0 and 744."
            continue
        clean[month] = float(hours)
    if field_errors:
        raise errors.validation("Some months need attention.", field_errors)
    note = body.get("note") if isinstance(body.get("note"), str) else None
    who = actor_name()
    with db.transaction():
        db.executemany(
            "INSERT INTO resource_availability (resource_id, month, available_hours, note, updated_by) VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(resource_id, month) DO UPDATE SET available_hours = excluded.available_hours, "
            "note = COALESCE(excluded.note, resource_availability.note), updated_by = excluded.updated_by",
            [(rid, m, h, note, who) for m, h in clean.items()])
        log_activity("availability", rid, "update", {"label": res["name"], "months": clean})
        for iid in _affected_initiatives(rid):
            repo.sync_derived(iid)
    return _months_payload(rid)


# ------------------------------------------------------------------ allocations
_ALLOC_SELECT = (
    "SELECT a.*, r.name AS resource_name, i.rddc, i.name AS initiative_name, t.wbs_code FROM allocations a "
    "JOIN resources r ON r.id = a.resource_id JOIN initiatives i ON i.id = a.initiative_id "
    "LEFT JOIN wbs_tasks t ON t.id = a.task_id ")


def _allocation(aid) -> dict:
    row = db.query_one(_ALLOC_SELECT + "WHERE a.id = ?", (aid,))
    if row is None:
        raise errors.not_found("Allocation", aid)
    return row


@bp.get("/allocations")
def list_allocations():
    f = Fields(dict(request.args))
    f.integer("initiative_id", lo=1)
    f.integer("resource_id", lo=1)
    f.month("month")
    args = f.check("Some filters need attention.")
    where, params = [], []
    for key in ("initiative_id", "resource_id", "month"):
        if args.get(key) is not None:
            where.append(f"a.{key} = ?")
            params.append(args[key])
    rows = db.query(_ALLOC_SELECT + ("WHERE " + " AND ".join(where) + " " if where else "")
                    + "ORDER BY a.month, r.name, t.sort, a.id", params)
    return listed(rows)


def _alloc_fields(data: dict, *, creating: bool) -> Fields:
    f = Fields(data)
    f.ref("resource_id", "resources", required=creating, label="person")
    f.ref("initiative_id", "initiatives", required=creating, label="initiative")
    f.integer("task_id", lo=1)
    f.month("month", required=creating)
    f.number("hours", required=creating, lo=0, hi=744)
    f.enum("firmness", ("tentative", "confirmed"), label="demand type")
    for required in ("resource_id", "initiative_id", "month", "hours"):
        if not creating and required in f.out and f.out[required] is None:
            f.error(required, "This field is required.")
    return f


def _check_task_link(values: dict, current: dict | None = None) -> None:
    task_id = values.get("task_id", (current or {}).get("task_id"))
    iid = values.get("initiative_id", (current or {}).get("initiative_id"))
    if task_id:
        row = db.query_one("SELECT initiative_id FROM wbs_tasks WHERE id = ?", (task_id,))
        if row is None or row["initiative_id"] != iid:
            raise errors.validation("Some fields need attention.", {"task_id": "That WBS step is not on this initiative."})


@bp.post("/allocations")
def create_allocation():
    values = _alloc_fields(json_body(), creating=True).check()
    _check_task_link(values)
    if not values.get("firmness"):
        status = db.scalar("SELECT l2_status FROM initiatives WHERE id = ?", (values["initiative_id"],))
        values["firmness"] = "confirmed" if status == "Approved" else "tentative"
    with db.transaction():
        aid = db.insert("allocations", {**values, "source": "manual"})
        name = repo.resource_name(values["resource_id"])
        log_activity("allocation", aid, "create", {"label": f"{name} {values['month']} {values['hours']:g} h"},
                     values["initiative_id"])
        repo.sync_derived(values["initiative_id"])
    return _allocation(aid), 201


def _manual_only(row: dict) -> None:
    if row["source"] != "manual":
        raise errors.conflict("This allocation comes from the project plan. Change the WBS step on Pg 2 instead.")


@bp.put("/allocations/<int:aid>")
def update_allocation(aid: int):
    current = _allocation(aid)
    _manual_only(current)
    values = _alloc_fields(json_body(), creating=False).check()
    _check_task_link(values, current)
    changes = {k: [current.get(k), v] for k, v in values.items() if current.get(k) != v}
    if not changes:
        return current
    with db.transaction():
        db.update("allocations", aid, values)
        log_activity("allocation", aid, "update", {"label": current["resource_name"], "changes": changes},
                     current["initiative_id"])
        for iid in {current["initiative_id"], values.get("initiative_id") or current["initiative_id"]}:
            repo.sync_derived(iid)
    return _allocation(aid)


@bp.delete("/allocations/<int:aid>")
def delete_allocation(aid: int):
    current = _allocation(aid)
    _manual_only(current)
    with db.transaction():
        db.execute("DELETE FROM allocations WHERE id = ?", (aid,))
        log_activity("allocation", aid, "delete", {"label": current["resource_name"]}, current["initiative_id"])
        repo.sync_derived(current["initiative_id"])
    return {"ok": True}


@bp.get("/resources/<int:rid>/calendar")
def resource_calendar(rid: int):
    return repo.resource_calendar(rid, _month_arg("from"), _month_arg("to"))


# ------------------------------------------------------------------ skills
@bp.get("/skills/matrix")
def skill_matrix():
    skills = db.query("SELECT id, name, category FROM skills ORDER BY category, name")
    people = db.query("SELECT id, name, team FROM resources WHERE capacity_eligible = 1 AND active = 1 ORDER BY id")
    by_person = repo.resource_skills([p["id"] for p in people])
    rows = []
    for p in people:
        entries = by_person.get(p["id"], [])
        rows.append({"resource_id": p["id"], "name": p["name"], "team": p["team"],
                     "levels": {s["skill"]: s["level"] for s in entries},
                     "evidence": {s["skill"]: s["evidence"] for s in entries if s.get("evidence")}})
    return {"skills": skills, "rows": rows}


@bp.put("/resources/<int:rid>/skills")
def set_skills(rid: int):
    res = repo.require("resources", rid, "Resource")
    body = json_body()
    skills = body.get("skills")
    if not isinstance(skills, dict) or not skills:
        raise errors.validation("Send the skills to update.", {"skills": "Send skill levels, e.g. Kafka: 2."})
    field_errors = {}
    for name, level in skills.items():
        if not isinstance(name, str) or not name.strip() or len(name) > 60:
            field_errors[str(name)] = "Enter a skill name of up to 60 characters."
        elif level not in (None, 0, 1, 2, 3) or isinstance(level, bool):
            field_errors[name] = "Choose a level from 1 to 3, or clear it."
    if field_errors:
        raise errors.validation("Some skills need attention.", field_errors)
    with db.transaction():
        for name, level in skills.items():
            name = name.strip()
            skill = db.query_one("SELECT id FROM skills WHERE name = ?", (name,))
            if not level:
                if skill:
                    db.execute("DELETE FROM resource_skills WHERE resource_id = ? AND skill_id = ?", (rid, skill["id"]))
                continue
            sid = skill["id"] if skill else db.insert("skills", {"name": name, "category": "Other"})
            db.execute(
                "INSERT INTO resource_skills (resource_id, skill_id, level, source) VALUES (?, ?, ?, 'manual') "
                "ON CONFLICT(resource_id, skill_id) DO UPDATE SET level = excluded.level, source = 'manual'",
                (rid, sid, level))
        log_activity("skills", rid, "update", {"label": res["name"], "skills": skills})
    rows = repo.resource_skills([rid]).get(rid, [])
    return {"resource_id": rid, "skills": [{"skill": s["skill"], "level": s["level"], "source": s["source"]} for s in rows]}
