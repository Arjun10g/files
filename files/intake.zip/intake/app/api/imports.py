"""Offline imports: persisted preview, explicit review, transactional and idempotent commit."""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import shutil
import uuid
from pathlib import Path

from flask import Blueprint, current_app, request, send_file
from werkzeug.utils import secure_filename

from app import db, errors, repo
from app.activity import log_activity
from app.api import funding
from app.api._shared import json_body, lookup_values
from app.services import intake_connections
from app.services import intake_parser as parser
from app.today import now_iso

bp = Blueprint('imports',__name__,url_prefix='/api/imports')
PERSON_MAP = {'pm':'pm_id','dc_pm':'dc_pm_id','dc_sa':'dc_sa_id','tech_lead':'tech_lead_id','assigned_to':'assigned_to_id','owner':'owner_id'}
BUDGET_KEYS = {'prn_code','name','lob','funded_hours','rate','budget_amount','currency','owner_id','start_month','end_month',*funding.META_FIELDS}
ESTIMATE_KEYS = {'appcat','team','sto','phase','hours','rate','amount','decision','notes'}


def ensure_schema():
    db.execute('''CREATE TABLE IF NOT EXISTS import_batches (
        id TEXT PRIMARY KEY, type TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'preview', filename TEXT,
        source_kind TEXT, source_path TEXT, file_sha256 TEXT, payload_json TEXT NOT NULL,
        result_json TEXT, created_at TEXT NOT NULL, committed_at TEXT)''')
    db.execute('''CREATE TABLE IF NOT EXISTS import_records (
        id INTEGER PRIMARY KEY, batch_id TEXT NOT NULL REFERENCES import_batches(id), row_id TEXT NOT NULL,
        type TEXT NOT NULL, natural_key TEXT, initiative_id INTEGER REFERENCES initiatives(id) ON DELETE SET NULL,
        prn_code TEXT REFERENCES prn_budget(prn_code) ON DELETE SET NULL, source_json TEXT NOT NULL,
        created_at TEXT NOT NULL, UNIQUE(batch_id,row_id))''')
    db.execute('CREATE INDEX IF NOT EXISTS ix_import_records_key ON import_records(type,natural_key)')


def _kind(value):
    if value not in ('intake','funding'):
        raise errors.validation('Choose an import type.',{'type':'Choose intake or funding.'})
    return value


def _mapping(value,kind):
    if isinstance(value,str):
        try:
            value = json.loads(value)
        except ValueError:
            raise errors.validation('The column mapping could not be read.',{'mapping':'Use a JSON object of column names and target fields.'}) from None
    if value is None:
        return {}
    allowed = parser.FUNDING_FIELDS if kind == 'funding' else parser.INTAKE_FIELDS
    if not isinstance(value,dict) or not all(isinstance(k,str) and isinstance(v,str) and (not v or v in allowed) for k,v in value.items()):
        raise errors.validation('Check the column mapping.',{'mapping':'Map source column names to valid target field names.'})
    return value


def _batch(row):
    payload = db.from_json(row['payload_json'],{})
    result = db.from_json(row.get('result_json'))
    return {**payload,'id':row['id'],'type':row['type'],'status':row['status'],'filename':row['filename'],
            'source_kind':row['source_kind'],'created_at':row['created_at'],'committed_at':row['committed_at'],
            'result':result,'file_sha256':row.get('file_sha256'),'source_url':f'/api/imports/{row["id"]}/source' if row.get('source_path') else None}


def _require(bid):
    ensure_schema()
    row = db.query_one('SELECT * FROM import_batches WHERE id=?',(bid,))
    if not row:
        raise errors.not_found('Import preview',bid)
    return row


def _natural_key(fields,kind):
    if kind == 'intake':
        external = fields.get('external_key') or fields.get('jira_key')
        if external:
            return 'external:' + str(external).strip().upper()
        if fields.get('dc_intake'):
            return 'intake:' + str(fields['dc_intake']).strip().upper()
        return 'name:' + str(fields.get('name') or '').strip().casefold() + ':' + str(fields.get('lob') or '').strip().casefold()
    code = str(fields.get('prn_code') or '').strip().upper()
    if fields.get('month'):
        return f'charge:{code}:{fields["month"]}'
    if any(fields.get(k) for k in ('appcat','team','sto')):
        return ':'.join(['estimate',code,*[str(fields.get(k) or '').strip().casefold() for k in ('appcat','team','sto','phase')]])
    return 'budget:' + code


def _resolve_people(fields,warnings,*,commit=False):
    if intake_connections.portal_mode():
        values,connections = intake_connections.resolve_people(fields,commit=commit)
        warnings.extend(connections['warnings'])
        return values
    values = dict(fields)
    for name,target in PERSON_MAP.items():
        if not values.get(name) or values.get(target):
            continue
        matches = db.query('SELECT id,name FROM resources WHERE lower(name)=lower(?)',(str(values[name]).strip(),))
        if len(matches)==1:
            values[target] = matches[0]['id']
        else:
            warnings.append(f'{name.replace("_"," ").title()} "{values[name]}" is not a unique portal person; preserved as source text. Add the person in Resources to link them.')
    # A person's full name is valid requestor text even when they have no resource record.
    return values


def _canonical_lookup(fields,key,category):
    raw = fields.get(key)
    if raw in (None,''):
        return
    options = lookup_values(category)
    matches = [v for v in options if v.casefold()==str(raw).strip().casefold()]
    if len(matches)==1:
        fields[key] = matches[0]


def _validate_intake(fields,warnings):
    from app.api.initiatives import _initiative_fields
    values = dict(fields)
    connection_errors = {}
    if intake_connections.portal_mode():
        details = intake_connections.funding_from_import(values)
        if details:
            values['funding'] = details
        try:
            values,connections = intake_connections.connect(values,commit=False)
            warnings.extend(connections['warnings'])
        except errors.ApiError as exc:
            connection_errors.update(exc.details.get('fields') or {'connections':exc.message})
    else:
        values = _resolve_people(fields,warnings)
    _canonical_lookup(values,'lob','lob')
    if values.get('priority') in (None,''):
        values['priority'] = 3
        warnings.append('Priority was not supplied; proposed P3. Change it if needed.')
    external = values.get('external_key')
    if external and not values.get('jira_key'):
        values['jira_key'] = external
    # A foreign intake code from Jira is evidence, not an invented local DC intake reference.
    if values.get('dc_intake') and not db.query_one('SELECT code FROM dc_intakes WHERE code=?',(values['dc_intake'],)):
        warnings.append(f'DC intake {values["dc_intake"]} is not registered locally; retained in source evidence.')
        values.pop('dc_intake')
    f = _initiative_fields(values,creating=True,allow_new_prn=intake_connections.portal_mode())
    if not values.get('requestor') and not values.get('requestor_id'):
        f.error('requestor','Enter the requestor or reporter.')
    return values, {**f.errors,**connection_errors}


def _duplicate_intake(fields):
    external = fields.get('external_key') or fields.get('jira_key')
    row = None
    if external:
        # Source keys never replace the portal's own RDDC identifier.
        columns = {c['name'] for c in db.query('PRAGMA table_info(initiatives)')}
        if 'jira_key' in columns:
            row = db.query_one('SELECT id,rddc,name FROM initiatives WHERE upper(rddc)=upper(?) OR upper(jira_key)=upper(?)',(str(external),str(external)))
        else:
            row = db.query_one('SELECT id,rddc,name FROM initiatives WHERE upper(rddc)=upper(?)',(str(external),))
        if not row:
            source = db.query_one('SELECT initiative_id FROM import_records WHERE type=\'intake\' AND natural_key=? AND initiative_id IS NOT NULL ORDER BY id LIMIT 1',(_natural_key(fields,'intake'),))
            if source:
                row = db.query_one('SELECT id,rddc,name FROM initiatives WHERE id=?',(source['initiative_id'],))
    if not row and fields.get('dc_intake'):
        row = db.query_one('SELECT id,rddc,name FROM initiatives WHERE dc_intake=?',(fields['dc_intake'],))
    if not row and fields.get('name'):
        row = db.query_one("SELECT id,rddc,name FROM initiatives WHERE lower(trim(name))=lower(trim(?)) AND lower(COALESCE(lob,''))=lower(?) LIMIT 1",(fields['name'],fields.get('lob') or ''))
    return {'kind':'initiative','id':row['id'],'label':f'{row["rddc"]} {row["name"]}'} if row else None


def _funding_class(fields):
    return 'charge' if fields.get('month') else 'estimate' if any(fields.get(k) for k in ('appcat','team','sto')) else 'budget'


def _validate_funding(fields,warnings,planned_budgets):
    connection_errors = {}
    try:
        fields = _resolve_people(fields,warnings)
    except errors.ApiError as exc:
        connection_errors.update(exc.details.get('fields') or {'people':exc.message})
    _canonical_lookup(fields,'lob','lob')
    for field,allowed in [('decision',funding.DECISIONS),('charge_type',('Project','POD')),('phase',funding.PHASES)]:
        if fields.get(field):
            fields[field] = next((v for v in allowed if v.casefold()==str(fields[field]).casefold()),fields[field])
    code = fields.get('prn_code')
    kind = _funding_class(fields)
    problems = dict(connection_errors)
    existing = db.query_one('SELECT * FROM prn_budget WHERE prn_code=?',(code,)) if code else None
    duplicate = None
    budget = None
    # A row can define a new budget and its first charge/estimate at once.
    if not existing and code not in planned_budgets:
        try:
            budget_data = {k:v for k,v in fields.items() if k in BUDGET_KEYS}
            if intake_connections.portal_mode():
                supplied_rate = budget_data.get('rate')
                can_derive_hours = (isinstance(budget_data.get('budget_amount'),(int,float)) and
                                    isinstance(supplied_rate,(int,float)) and supplied_rate > 0)
                can_derive_amount = (isinstance(budget_data.get('funded_hours'),(int,float)) and
                                     isinstance(supplied_rate,(int,float)))
                for key in ('rate','funded_hours','budget_amount'):
                    if budget_data.get(key) in (None,''):
                        if (key == 'funded_hours' and can_derive_hours) or (key == 'budget_amount' and can_derive_amount):
                            warnings.append(f'{key.replace("_"," ").title()} was calculated from the supplied funding values.')
                            continue
                        budget_data[key] = 0
                        warnings.append(f'{key.replace("_"," ").title()} was not supplied; kept at zero for review.')
                budget_data.setdefault('name',code)
            budget,budget_metadata = funding.budget_fields(budget_data)
            if not intake_connections.portal_mode():
                if fields.get('rate') in (None,''):
                    warnings.append('Hourly rate was not supplied; proposed 110. Review it before committing.')
                if fields.get('funded_hours') in (None,''):
                    warnings.append('Funded hours were calculated from the budget amount and hourly rate.')
                if fields.get('budget_amount') in (None,''):
                    warnings.append('Budget amount was calculated from funded hours and the hourly rate.')
            if fields.get('currency') in (None,''):
                warnings.append('Currency was not supplied; proposed CAD. Review it before committing.')
            fields.update(budget)
            fields.update(budget_metadata)
        except errors.ApiError as exc:
            problems.update(exc.details.get('fields') or {'budget':exc.message})
    elif kind == 'budget':
        duplicate = {'kind':'budget','id':code,'label':f'{code} already exists. Edit its budget in Funding.'}
    elif existing:
        warnings.append(f'{code} already exists. Its budget will be kept; this import only adds the {kind}.')
    if (fields.get('charged_hours') is not None or fields.get('charged_amount') is not None) and not fields.get('month'):
        problems['month'] = 'Enter the month for these actual charges.'
    if (fields.get('hours') is not None or fields.get('amount') is not None or fields.get('phase')) and not any(fields.get(k) for k in ('appcat','team','sto')):
        problems['appcat'] = 'Identify the AppCat, team or STO for this estimate.'
    if kind == 'charge':
        try:
            # Amount-only actuals can be converted to hours using the explicit or existing budget rate.
            rate = fields.get('rate', (existing or planned_budgets.get(code) or {}).get('rate',110))
            if fields.get('charged_hours') in (None,'') and isinstance(fields.get('charged_amount'),(int,float)) and isinstance(rate,(int,float)) and rate>0:
                fields['charged_hours'] = fields['charged_amount']/rate
                warnings.append('Charged hours were calculated from the amount and hourly rate; review before committing.')
            funding.charge_fields(fields)
        except errors.ApiError as exc:
            problems.update(exc.details.get('fields') or {'charge':exc.message})
        charge = db.query_one('SELECT id FROM prn_charges WHERE prn_code=? AND month=?',(code,fields.get('month')))
        if charge:
            duplicate = {'kind':'charge','id':charge['id'],'label':f'A charge exists for {code} / {fields.get("month")}. Edit it in Funding.'}
    if any(fields.get(k) for k in ('appcat','team','sto')):
        try:
            proposed_estimate = funding.estimate_fields(fields)
            fields.update(proposed_estimate)
        except errors.ApiError as exc:
            problems.update(exc.details.get('fields') or {'estimate':exc.message})
        source = db.query_one("SELECT id FROM funding_estimates WHERE prn_code=? AND lower(COALESCE(appcat,''))=lower(?) AND lower(COALESCE(team,''))=lower(?) AND lower(COALESCE(sto,''))=lower(?) AND phase=? LIMIT 1",
                              (code,fields.get('appcat') or '',fields.get('team') or '',fields.get('sto') or '',fields.get('phase','Development')))
        if source:
            duplicate = {'kind':'estimate','id':source['id'],'label':f'This {code} component/team/phase estimate already exists. Edit it in Funding.'}
    if not code:
        problems['prn_code'] = 'Enter the PRN or funding code.'
    return fields,problems,duplicate,budget


def _components(document):
    text = document.get('text','')
    matches = []
    for cat in db.query('SELECT id,code,name FROM dc_components ORDER BY id'):
        code = re.search(r'(?<![A-Za-z0-9_])'+re.escape(cat['code'])+r'(?![A-Za-z0-9_])',text,re.IGNORECASE)
        name = re.search(re.escape(cat['name']),text,re.IGNORECASE)
        match = code or name
        if match:
            matches.append({**cat,'evidence':text[max(0,match.start()-60):min(len(text),match.end()+100)],
                            'line':text[:match.start()].count('\n')+1,'selected':False,
                            'warning':'Mentioned in the document. Confirm it is in scope before adding.'})
    return matches


def _validate(payload,kind):
    seen,planned_budgets = {},{}
    for row in payload['rows']:
        fields = parser.clean_fields(row.get('fields') or {},kind)
        warnings = list(row.get('extraction_warnings',row.get('warnings') or []))
        row['extraction_warnings'] = list(warnings)
        duplicate = None
        if kind == 'intake':
            fields,problems = _validate_intake(fields,warnings)
            duplicate = _duplicate_intake(fields)
        else:
            fields,problems,duplicate,budget = _validate_funding(fields,warnings,planned_budgets)
            if budget and row.get('selected',True) and not problems:
                planned_budgets[fields['prn_code']] = budget
        key = _natural_key(fields,kind)
        if key in seen and row.get('selected',True):
            duplicate = {'kind':'batch','row_id':seen[key],'label':f'Duplicates selected row {seen[key]} in this file.'}
        elif row.get('selected',True):
            seen[key] = row['row_id']
        if duplicate:
            problems['_duplicate'] = duplicate['label']
        row.update({'fields':fields,'warnings':list(dict.fromkeys(warnings)),'errors':problems,
                    'duplicate':duplicate,'natural_key':key,'record_type':kind if kind=='intake' else _funding_class(fields)})
    selected = [r for r in payload['rows'] if r.get('selected',True)]
    payload['summary'] = {'rows':len(payload['rows']),'selected':len(selected),
                          'valid':sum(not r['errors'] for r in selected),'invalid':sum(bool(r['errors']) for r in selected),
                          'warnings':sum(bool(r['warnings']) for r in selected),'duplicates':sum(bool(r['duplicate']) for r in selected)}
    return payload


def create_preview(kind: str, parsed: dict, *, filename: str, source_kind: str,
                   data: bytes | None = None) -> dict:
    """Public harness for adapters; preview only, no initiative/funding writes."""
    ensure_schema()
    funding.ensure_schema()
    kind = _kind(kind)
    bid = uuid.uuid4().hex
    source_path = None
    if data is not None:
        folder = Path(current_app.config['UPLOAD_DIR']) / '_imports' / bid
        folder.mkdir(parents=True,exist_ok=True)
        path = folder / (secure_filename(filename) or 'source.txt')
        path.write_bytes(data)
        source_path = f'_imports/{bid}/{path.name}'
    if parsed.get('document'):
        parsed['document']['components'] = _components(parsed['document'])
    parsed = _validate(parsed,kind)
    stamp = now_iso()
    try:
        with db.transaction():
            db.insert('import_batches',{'id':bid,'type':kind,'status':'preview','filename':filename,'source_kind':source_kind,
                                       'source_path':source_path,'file_sha256':hashlib.sha256(data).hexdigest() if data is not None else None,
                                       'payload_json':db.to_json(parsed),'created_at':stamp})
    except BaseException:
        if source_path:
            shutil.rmtree(Path(current_app.config['UPLOAD_DIR'])/'_imports'/bid,ignore_errors=True)
        raise
    return _batch(_require(bid))


@bp.post('/preview')
def preview_import():
    ensure_schema()
    funding.ensure_schema()
    upload = request.files.get('file')
    if upload is not None:
        kind = _kind(request.form.get('type','intake'))
        mapping = _mapping(request.form.get('mapping'),kind)
        filename = (upload.filename or 'upload').replace('\\','/').rsplit('/',1)[-1]
        limit = int(current_app.config.get('MAX_UPLOAD_BYTES') or 10*1024*1024)
        data = upload.read(limit+1)
        if len(data)>limit:
            raise errors.ApiError('payload_too_large','The file is larger than 10 MB. Split it into smaller files.',413)
        if not data:
            raise errors.validation('The file is empty.',{'file':'Choose a file with records.'})
        ext = Path(filename).suffix.lower()
        if ext in ('.xlsx','.xlsm','.csv'):
            parsed = parser.parse_spreadsheet(data,filename,kind,mapping)
            source_kind = 'spreadsheet'
        elif ext == '.json':
            try:
                payload = json.loads(data.decode('utf-8-sig'))
            except (ValueError,UnicodeDecodeError):
                raise errors.validation('The JSON file could not be read.',{'file':'Use valid UTF-8 JSON.'}) from None
            parsed = parser.map_json_payload(payload,mapping,kind)
            source_kind = 'json'
        elif ext in ('.docx','.pdf','.md','.txt'):
            import tempfile
            with tempfile.TemporaryDirectory() as temp:
                safe = secure_filename(filename)
                if not Path(safe).stem or Path(safe).suffix.lower()!=ext:
                    safe = f'document{ext}'
                path = Path(temp)/safe
                path.write_bytes(data)
                parsed = parser.parse_document(path,filename,mapping,kind=kind)
            source_kind = 'document'
        else:
            raise errors.validation('Choose a supported file.',{'file':'Use Excel, CSV, JSON, Word, PDF, Markdown or text.'})
        return create_preview(kind,parsed,filename=filename,source_kind=source_kind,data=data),201
    body = json_body()
    kind = _kind(body.get('type','intake'))
    mapping = _mapping(body.get('mapping'),kind)
    filename = str(body.get('filename') or ('Pasted document.txt' if 'text' in body else 'JSON intake.json'))[:200]
    if 'text' in body:
        parsed = parser.parse_document_text(body['text'],filename,mapping,kind=kind)
        return create_preview(kind,parsed,filename=filename,source_kind='document',data=body['text'].encode('utf-8')),201
    payload = body.get('payload',body.get('data',body))
    parsed = parser.map_json_payload(payload,mapping,kind)
    return create_preview(kind,parsed,filename=filename,source_kind='json',data=json.dumps(payload,ensure_ascii=False).encode('utf-8')),201


def _apply_edits(stored,payload,data):
    kind = stored['type']
    if 'mapping' in data:
        mapping = _mapping(data['mapping'],kind)
        payload['mapping'] = mapping
        if payload.get('document'):
            reparsed = parser.parse_document_text(payload['document']['text'],stored['filename'],mapping,kind=kind)
            old_components = payload['document'].get('components',[])
            payload.update(reparsed)
            payload['document']['components'] = old_components
        else:
            for row in payload['rows']:
                fields,evidence,warnings = parser.mapped_record(row.get('raw',{}),kind,mapping)
                row.update({'fields':fields,'evidence':evidence,'extraction_warnings':warnings})
    edits = data.get('rows',[])
    if not isinstance(edits,list) or not all(isinstance(e,dict) for e in edits):
        raise errors.validation('Check the review rows.',{'rows':'Send an array of row edits.'})
    indexed = {r['row_id']:r for r in payload['rows']}
    allowed = (parser.FUNDING_FIELDS if kind=='funding' else parser.INTAKE_FIELDS) | set(PERSON_MAP.values()) | {'requestor_id'}
    touched = set()
    for edit in edits:
        rid = edit.get('row_id')
        if rid not in indexed:
            raise errors.validation('That row does not belong to this preview.',{'row_id':str(rid)})
        if rid in touched:
            raise errors.validation('A review row was supplied more than once.',{'row_id':str(rid)})
        touched.add(rid)
        row = indexed[rid]
        if 'selected' in edit:
            if not isinstance(edit['selected'],bool):
                raise errors.validation('Choose whether to include the row.',{'selected':'Use true or false.'})
            row['selected'] = edit['selected']
        if 'fields' in edit:
            if not isinstance(edit['fields'],dict) or not all(k in allowed for k in edit['fields']):
                raise errors.validation('Check the edited fields.',{'fields':'One or more fields are not supported.'})
            for name,(target,*_) in intake_connections.PEOPLE.items():
                if target and name in edit['fields'] and target not in edit['fields'] and edit['fields'][name] != row['fields'].get(name):
                    row['fields'].pop(target,None)
            row['fields'] = {**row['fields'],**edit['fields']}
    if 'components' in data:
        choices = data['components']
        if not payload.get('document') or not isinstance(choices,list):
            raise errors.validation('Check the component selection.',{'components':'Select components mentioned in this document.'})
        indexed_components = {c['id']:c for c in payload['document'].get('components',[])}
        for choice in choices:
            if not isinstance(choice,dict) or choice.get('id') not in indexed_components or not isinstance(choice.get('selected'),bool):
                raise errors.validation('Check the component selection.',{'components':'Use component id and selected true or false.'})
            indexed_components[choice['id']]['selected'] = choice['selected']
    return _validate(payload,kind)


@bp.get('')
def list_imports():
    ensure_schema()
    rows = db.query('SELECT * FROM import_batches ORDER BY created_at DESC,id DESC LIMIT 100')
    items = []
    for stored in rows:
        item = _batch(stored)
        items.append({k:item.get(k) for k in ('id','type','status','filename','source_kind','created_at','committed_at','summary','result')})
    return {'items':items,'total':len(items)}


@bp.get('/<bid>')
def get_import(bid):
    row = _require(bid)
    if row['status']=='preview':
        payload = _validate(db.from_json(row['payload_json'],{}),row['type'])
        row['payload_json'] = db.to_json(payload)
    return _batch(row)


@bp.put('/<bid>')
def review_import(bid):
    with db.transaction():
        row = _require(bid)
        if row['status']!='preview':
            raise errors.conflict('This import has already been committed. Start another preview for new data.')
        payload = _apply_edits(row,db.from_json(row['payload_json'],{}),json_body())
        db.update('import_batches',bid,{'payload_json':db.to_json(payload)},key='id')
    return _batch(_require(bid))


def _source_file(stored):
    if not stored.get('source_path'):
        return None
    root = Path(current_app.config['UPLOAD_DIR']).resolve()
    path = (root/stored['source_path']).resolve()
    if root not in path.parents or not path.is_file():
        raise errors.not_found('Original source file',stored['id'])
    return path


@bp.get('/<bid>/source')
def source_download(bid):
    row = _require(bid)
    path = _source_file(row)
    if path is None:
        raise errors.not_found('Original source file',bid)
    return send_file(path,as_attachment=True,download_name=row['filename'],max_age=0)


def _commit_intake(stored,payload,row,uploaded_paths):
    from app.api.initiatives import create_initiative, store_upload
    fields = row['fields']
    values = dict(fields)
    linked = intake_connections.portal_mode()
    metadata_keys = ('external_key','sa_author','sa_version') if linked else ('external_key','sa_author','sa_version',*PERSON_MAP)
    metadata = {k:values.pop(k) for k in list(values) if k in metadata_keys}
    if linked:
        details = intake_connections.funding_from_import(values)
        if details:
            values['funding'] = details
    notes = []
    if metadata.get('external_key'):
        notes.append(f'Source ticket: {metadata["external_key"]}')
    for key,target in PERSON_MAP.items():
        if metadata.get(key) and not fields.get(target):
            notes.append(f'{key.replace("_"," ").title()} (source): {metadata[key]}')
    if notes:
        existing = values.get('comments') or ''
        values['comments'] = '\n'.join([existing,*notes]).strip()
        if len(values['comments'])>4000:
            raise errors.validation('Source notes exceed the comment limit. Shorten the comments before importing.',{'comments':'Keep comments and source notes to 4,000 characters.'})
    result = create_initiative(values)
    iid = result['initiative']['id']
    if metadata.get('sa_author') or metadata.get('sa_version'):
        db.update('initiatives',iid,{k:metadata[k] for k in ('sa_author','sa_version') if metadata.get(k)})
    document = payload.get('document')
    if document:
        source = _source_file(stored)
        filename = stored['filename']
        if Path(filename).suffix.lower() not in ('.docx','.pdf','.md','.txt'):
            filename = Path(filename).stem+'.txt'
        data = source.read_bytes() if source else document['text'].encode('utf-8')
        # This initiative was created inside the current transaction. Track its
        # new folder before attachment parsing/writes so any later failure also
        # removes files whose attachment insert did not finish.
        uploaded_paths.append(str(iid))
        attachment = store_upload(iid,filename,data,'sa_doc')
        uploaded_paths.append(attachment['attachment']['stored_path'])
        for component in document.get('components',[]):
            if not component.get('selected'):
                continue
            cat = db.query_one('SELECT * FROM dc_components WHERE id=?',(component['id'],))
            if not cat:
                raise errors.validation('A selected component is no longer available.',{'components':'Refresh and review the component list.'})
            db.insert('initiative_components',{'initiative_id':iid,'component_id':cat['id'],'approval':'Pending',
                        'change_summary':component.get('evidence'),'complexity':'Medium','est_hours':cat['base_hours_medium'],
                        'component_lead_id':cat['component_lead_id'],'source':'regex','sort':10*(component['id']+1)})
        repo.sync_derived(iid,reminders=True)
    item = {'row_id':row['row_id'],'initiative_id':iid,'rddc':result['initiative']['rddc'],'name':fields['name']}
    if 'connections' in result:
        item['connections'] = result['connections']
    return item


def _commit_funding(stored,row):
    fields = _resolve_people(row['fields'],[],commit=True)
    code = fields['prn_code']
    created_budget = False
    if not db.query_one('SELECT prn_code FROM prn_budget WHERE prn_code=?',(code,)):
        funding.create_budget({k:v for k,v in fields.items() if k in BUDGET_KEYS})
        created_budget = True
    result = {'row_id':row['row_id'],'prn_code':code,'created_budget':created_budget}
    if fields.get('month'):
        charge = funding.create_charge(code,{k:fields[k] for k in ('month','charged_hours','charged_amount') if k in fields},source=f'import:{stored["id"]}')
        result['charge_id'] = charge['id']
    if any(fields.get(k) for k in ('appcat','team','sto')):
        estimate = funding.create_estimate(code,{k:v for k,v in fields.items() if k in ESTIMATE_KEYS})
        result['estimate_id'] = estimate['id']
    return result


@bp.post('/<bid>/commit')
def commit_import(bid):
    # Re-check every row while holding BEGIN IMMEDIATE. A parallel import cannot race this check.
    ensure_schema()
    funding.ensure_schema()
    uploaded_paths = []
    try:
        with db.transaction():
            stored = _require(bid)
            if stored['status']=='committed':
                response = _batch(stored)
                response['idempotent'] = True
                return response
            payload = _apply_edits(stored,db.from_json(stored['payload_json'],{}),json_body())
            selected = [r for r in payload['rows'] if r.get('selected',True)]
            if not selected:
                raise errors.validation('Select at least one row to import.',{'rows':'No rows are selected.'})
            invalid = [r for r in selected if r['errors']]
            if invalid:
                raise errors.ApiError('validation','Review the selected rows before committing.',422,
                                      {'rows':[{k:r.get(k) for k in ('row_id','errors','duplicate')} for r in invalid],
                                       'fields':{'rows':f'{len(invalid)} selected row(s) need attention.'}})
            committed = []
            for row in selected:
                if stored['type']=='intake':
                    result = _commit_intake(stored,payload,row,uploaded_paths)
                else:
                    result = _commit_funding(stored,row)
                db.insert('import_records',{'batch_id':bid,'row_id':row['row_id'],'type':stored['type'],
                    'natural_key':row['natural_key'],'initiative_id':result.get('initiative_id'),
                    'prn_code':result.get('prn_code'),'source_json':db.to_json({'source':row['source'],'raw':row.get('raw'),
                    'fields':row['fields'],'evidence':row.get('evidence'),'warnings':row['warnings']}),'created_at':now_iso()})
                committed.append(result)
            result = {'created':len(committed),'skipped':len(payload['rows'])-len(committed),'items':committed}
            db.update('import_batches',bid,{'status':'committed','payload_json':db.to_json(payload),'result_json':db.to_json(result),
                                           'committed_at':now_iso()},key='id')
            log_activity('import',None,'create',{'label':f'{stored["filename"]}: {len(committed)} {stored["type"]} records'})
    except BaseException:
        root = Path(current_app.config['UPLOAD_DIR'])
        for relative in uploaded_paths:
            path = root/relative
            if path.is_dir():
                shutil.rmtree(path,ignore_errors=True)
            else:
                path.unlink(missing_ok=True)
            try:
                path.parent.rmdir()
            except OSError:
                pass
        raise
    return _batch(_require(bid))


@bp.get('/fields')
def import_fields():
    kind = _kind(request.args.get('type','intake'))
    fields = sorted(parser.FUNDING_FIELDS if kind=='funding' else parser.INTAKE_FIELDS)
    required = {'prn_code','name'} if kind=='funding' else {'name','lob','requestor'}
    return {'fields':[{'key':key,'label':key.replace('_',' ').title(),'required':key in required} for key in fields],
            'mapping_direction':'source_column_to_field','limits':{'rows':parser.MAX_ROWS,'columns':parser.MAX_COLUMNS},
            'supported_extensions':['.xlsx','.xlsm','.csv','.json','.docx','.pdf','.md','.txt']}


TEMPLATE_COLUMNS = {
    'intake':['Project name','Line of business','Priority','Requestor','Description','Requested go live','PRN code',
              'Platform','Region','Channel','APT number','DC External Team PR Code','Issue key','Status','Project key',
              'Business analyst','Solution Concurrence Date','PM','DC PM','Solution architect','Tech lead','Labels'],
    'funding':['PRN code','Project name','Line of business','Funded hours','Hourly rate','Budget amount','Currency',
               'Owner','Start month','End month','Decision','Charge type','Scope','Assumptions','AppCat','Team','STO',
               'Phase','Hours','Amount','Month','Charged hours','Charged amount']}


@bp.get('/templates/<kind>.<ext>')
def download_template(kind,ext):
    kind = _kind(kind)
    if ext not in ('csv','xlsx'):
        raise errors.not_found('Template format',ext)
    headers = TEMPLATE_COLUMNS[kind]
    if ext=='csv':
        output = io.StringIO(newline='')
        csv.writer(output).writerow(headers)
        stream = io.BytesIO(output.getvalue().encode('utf-8-sig'))
        mime = 'text/csv'
    else:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill
        book = Workbook()
        sheet = book.active
        sheet.title = 'Intakes' if kind=='intake' else 'Funding'
        sheet.append(headers)
        for cell in sheet[1]:
            cell.font = Font(bold=True,color='FFFFFF')
            cell.fill = PatternFill('solid',fgColor='0075BE')
            sheet.column_dimensions[cell.column_letter].width = min(max(len(str(cell.value))+3,16),36)
        sheet.freeze_panes = 'A2'
        sheet.auto_filter.ref = sheet.dimensions
        instructions = book.create_sheet('Instructions')
        lines = ['Blank import template. Enter your records below the header on the first sheet.',
                 'Remove optional columns you do not need. Do not change a header unless you map it in the import preview.',
                 'Dates: YYYY-MM-DD. Months: YYYY-MM. Numeric amounts and hours only.',
                 'Review the preview, correct required fields, and explicitly commit to save.',
                 'Existing initiatives and budgets are never overwritten by imports. Edit existing records in the portal.',
                 'Line of business options: '+', '.join(lookup_values('lob'))]
        if kind=='intake':
            lines += ['Required: Project name, Line of business, Requestor. Priority: 1 to 4 (proposed 3 when blank).',
                      'PRN and named people link only to existing portal records. Unmatched people stay as source evidence.']
        else:
            lines += ['New budget: PRN code, Project name and Funded hours or Budget amount; rate defaults to 110, currency to CAD.',
                      'Monthly charge: PRN code, Month and Charged hours or Charged amount. One actual per PRN per month.',
                      'Component estimate: PRN code and AppCat, Team or STO; Phase: Planning, Development or Support.',
                      'Decision: Pending, Approved, Rejected or Delayed. Charge type: Project or POD.']
        for line in lines:
            instructions.append([line])
        instructions.column_dimensions['A'].width = 130
        stream = io.BytesIO()
        book.save(stream)
        stream.seek(0)
        mime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    return send_file(stream,mimetype=mime,as_attachment=True,download_name=f'{kind}_template.{ext}',max_age=0)
