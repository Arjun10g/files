"""Governance (owner B1): change requests (CRQs) with live compliance, deterministic CRQ draft, risks, grooming
sessions and slots, and the Outbox. Contracts: docs/contracts.md §2 "governance".
"""
from __future__ import annotations

import re
from datetime import date, datetime, time, timedelta

from flask import Blueprint, request

from app import db, errors, repo
from app.activity import actor_name, log_activity
from app.api._shared import TIME_RE, Fields, arg_date, arg_int, json_body, listed
from app.today import get_today, now_iso, tz

bp = Blueprint("governance", __name__, url_prefix="/api")

CRQ_RE = re.compile(r"^(CRQ|RCSR)\d{6,12}$")
WEEK_RE = re.compile(r"^(\d{4})-W(\d{2})$")
CR_COLUMNS = ("crq_number", "raised_at", "crq_start", "crq_end", "release_type", "release_train", "target_release",
              "affected_cis", "impacted_components", "implementation_status", "crq_approval_status", "sto_approval",
              "cms_lead_id", "rel_lead_id", "resource_id", "tech_validation_status", "biz_validation_status",
              "tech_validation_attachment_id", "biz_validation_attachment_id", "backout_attachment_id", "implemented_at")


# ------------------------------------------------------------------ change requests
def _week_window(week: str) -> tuple[str, str]:
    m = WEEK_RE.match(week or "")
    if not m:
        raise errors.validation("Some filters need attention.", {"week": "Use an ISO week like 2026-W43."})
    try:
        monday = date.fromisocalendar(int(m.group(1)), int(m.group(2)), 1)
    except ValueError:
        raise errors.validation("Some filters need attention.", {"week": "Use an ISO week like 2026-W43."}) from None
    return monday.isoformat(), (monday + timedelta(days=13)).isoformat()


@bp.get("/change-requests")
def list_change_requests():
    where, params = [], []
    iid = arg_int("initiative_id", lo=1)
    if iid:
        where.append("cr.initiative_id = ?")
        params.append(iid)
    first, last = arg_date("from"), arg_date("to")
    if request.args.get("week"):
        first, last = _week_window(request.args["week"])
    if first:
        where.append("substr(cr.crq_start, 1, 10) >= ?")
        params.append(first)
    if last:
        where.append("substr(cr.crq_start, 1, 10) <= ?")
        params.append(last)
    return listed(repo.list_change_requests(("WHERE " + " AND ".join(where)) if where else "", params))


@bp.get("/change-requests/<int:cid>")
def get_change_request(cid: int):
    return repo.get_change_request(cid)


def _cr_fields(data: dict, iid: int) -> Fields:
    f = Fields(data)
    f.text("crq_number", max_len=20)
    if f.out.get("crq_number"):
        f.out["crq_number"] = f.out["crq_number"].upper()
        if not CRQ_RE.match(f.out["crq_number"]):
            f.error("crq_number", "Use a CRQ/RCSR number like CRQ000001052216.")
    f.date("raised_at")
    f.datetime("crq_start")
    f.datetime("crq_end")
    f.datetime("implemented_at")
    f.lookup("release_type", "release_type", label="release type")
    f.ref("release_train", "release_trains", label="release train", key="code")
    f.ref("target_release", "release_trains", label="release train", key="code")
    f.strings("affected_cis", max_items=30, max_len=60)
    codes = [r["code"] for r in db.query("SELECT code FROM dc_components")]
    f.strings("impacted_components", max_items=12, max_len=10, options=codes)
    f.lookup("implementation_status", "implementation_status", label="implementation status")
    f.lookup("crq_approval_status", "crq_approval_status", label="CRQ approval status")
    f.lookup("sto_approval", "sto_approval", label="STO approval")
    for col in ("cms_lead_id", "rel_lead_id", "resource_id"):
        f.ref(col, "resources", label="person")
    f.lookup("tech_validation_status", "validation_status", label="validation status")
    f.lookup("biz_validation_status", "validation_status", label="validation status")
    for col in ("tech_validation_attachment_id", "biz_validation_attachment_id", "backout_attachment_id"):
        f.integer(col, lo=1)
        if f.out.get(col):
            row = db.query_one("SELECT initiative_id FROM attachments WHERE id = ?", (f.out[col],))
            if row is None or row["initiative_id"] != iid:
                f.error(col, "That file is not attached to this initiative.")
    for required in ("implementation_status", "crq_approval_status", "tech_validation_status", "biz_validation_status"):
        if required in f.out and f.out[required] is None:
            f.error(required, "This field is required.")
    return f


def _check_window(f: Fields, merged: dict) -> None:
    start, end = merged.get("crq_start"), merged.get("crq_end")
    if start and end and datetime.fromisoformat(end) <= datetime.fromisoformat(start):
        f.error("crq_end", "The CRQ end must be after the start.")


def _store_compliance(cid: int) -> None:
    repo.cache_compliance(cid)


def _sto_decision(iid: int, cr: dict, sto: str) -> None:
    if sto not in ("Go", "No-Go"):
        return
    db.insert("decisions", {
        "initiative_id": iid, "title": f"STO {sto} for {cr.get('crq_number') or 'the change request'}",
        "context": f"Release {cr.get('release_train') or cr.get('target_release') or ''}".strip(),
        "decision": f"STO decision recorded as {sto}.", "decided_by": actor_name(iid),
        "decided_on": get_today().isoformat(), "status": "Approved", "source": "system", "created_at": now_iso()})


def _cr_values(values: dict) -> dict:
    out = {k: v for k, v in values.items() if k in CR_COLUMNS}
    for key in ("affected_cis", "impacted_components"):
        if key in out:
            out[key] = db.to_json(out[key] or [])
    return out


@bp.post("/initiatives/<int:iid>/change-requests")
def create_change_request(iid: int):
    ini = repo.get_initiative(iid)
    f = _cr_fields(json_body(), iid)
    values = f.check()
    _check_window(f, values)
    f.check()
    if values.get("crq_number") and db.query_one("SELECT 1 AS x FROM change_requests WHERE crq_number = ?",
                                                 (values["crq_number"],)):
        raise errors.conflict(f"{values['crq_number']} is already logged.")
    values.setdefault("raised_at", get_today().isoformat())
    values.setdefault("target_release", ini.get("target_release"))
    stamp = now_iso()
    with db.transaction():
        cid = db.insert("change_requests", {**_cr_values({k: v for k, v in values.items() if v is not None}),
                                            "initiative_id": iid, "source": "manual", "created_at": stamp,
                                            "updated_at": stamp})
        _store_compliance(cid)
        log_activity("change_request", cid, "create", {"label": values.get("crq_number") or "draft"}, iid)
        _sto_decision(iid, values, values.get("sto_approval"))
        repo.sync_derived(iid)
    return repo.get_change_request(cid), 201


def _draft_window(train_date: str) -> tuple[str, str]:
    engine = repo.optional_module("app.engines.compliance")
    if engine is not None:
        return engine.crq_window(train_date)
    day = date.fromisoformat(train_date)
    zone = tz()
    return (datetime.combine(day, time(2, 0), tzinfo=zone).isoformat(),
            datetime.combine(day, time(6, 0), tzinfo=zone).isoformat())


def _next_crq_number(*, consume: bool = True) -> str:
    """Next Remedy-style number (CRQ + 12 digits) from app_settings.crq_next; skips numbers already logged.
    consume=False only peeks (dry run) and leaves the sequence where it is."""
    raw = repo.setting("crq_next", "1052216")
    n = int(raw) if str(raw).isdigit() else 1052216
    while db.query_one("SELECT 1 AS x FROM change_requests WHERE crq_number = ?", (f"CRQ{n:012d}",)):
        n += 1
    if not consume:
        return f"CRQ{n:012d}"
    db.execute("INSERT INTO app_settings (key, value) VALUES ('crq_next', ?) "
               "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (str(n + 1),))
    return f"CRQ{n:012d}"


@bp.post("/initiatives/<int:iid>/change-requests/draft")
def draft_change_request(iid: int):
    """Deterministic CRQ draft from the plan: Saturday 02:00–06:00 on the WBS-700 date, Bundle, CIs from components.

    {"dry_run": true} returns the proposed CRQ (with the next number) without saving or consuming the number.
    """
    ini = repo.get_initiative(iid)
    if not ini.get("target_release"):
        raise errors.validation("Set the target release on Pg 1 before drafting the CRQ.",
                                {"target_release": "Choose the release train first."})
    train = db.query_one("SELECT code, train_date FROM release_trains WHERE code = ?", (ini["target_release"],))
    derive = repo.optional_module("app.services.derive")
    prod = derive.production_date(iid) if derive is not None and hasattr(derive, "production_date") else None
    window_date = prod or train["train_date"]
    on_train = db.query_one("SELECT code FROM release_trains WHERE train_date = ?", (window_date,))
    release_train = on_train["code"] if on_train else train["code"]
    existing = db.query_one("SELECT id FROM change_requests WHERE initiative_id = ? AND source = 'draft' "
                            "ORDER BY id LIMIT 1", (iid,))
    if existing:
        return {**repo.get_change_request(existing["id"]), "dry_run": False}
    comps = repo.list_components(iid)
    start, end = _draft_window(window_date)

    def person(role):
        row = db.query_one("SELECT id FROM resources WHERE role = ? AND active = 1 ORDER BY id LIMIT 1", (role,))
        return row["id"] if row else None

    values = {
        "raised_at": get_today().isoformat(), "crq_start": start, "crq_end": end,
        "release_type": "Bundle", "release_train": release_train, "target_release": train["code"],
        "affected_cis": [c["ci_name"] for c in comps if c.get("ci_name")], "impacted_components": [c["code"] for c in comps],
        "implementation_status": "Not Started", "crq_approval_status": "Draft", "cms_lead_id": person("CMS Lead"),
        "rel_lead_id": person("Rel Lead"), "resource_id": ini.get("tech_lead_id"),
        "tech_validation_status": "Not Started", "biz_validation_status": "Not Started"}
    values["sto_approval"] = None  # "Not requested" until the STO is asked (round-2 decision 2)
    if json_body().get("dry_run") is True:
        preview = {**values, "id": None, "initiative_id": iid, "rddc": ini["rddc"], "initiative_name": ini["name"],
                   "crq_number": _next_crq_number(consume=False), "source": "draft", "dry_run": True,
                   "cms_lead_name": repo.resource_name(values["cms_lead_id"]),
                   "rel_lead_name": repo.resource_name(values["rel_lead_id"]),
                   "resource_name": repo.resource_name(values["resource_id"])}
        preview["compliance"] = repo.compliance_for(preview)
        return preview
    stamp = now_iso()
    with db.transaction():
        values["crq_number"] = _next_crq_number()
        cid = db.insert("change_requests", {**_cr_values(values), "initiative_id": iid, "source": "draft",
                                            "created_at": stamp, "updated_at": stamp})
        _store_compliance(cid)
        log_activity("change_request", cid, "create", {"label": values["crq_number"], "draft": True}, iid)
        repo.sync_derived(iid)
    return repo.get_change_request(cid), 201


@bp.put("/change-requests/<int:cid>")
def update_change_request(cid: int):
    current = db.query_one("SELECT * FROM change_requests WHERE id = ?", (cid,))
    if current is None:
        raise errors.not_found("Change request", cid)
    iid = current["initiative_id"]
    f = _cr_fields(json_body(), iid)
    values = f.check()
    merged = {**current, **values}
    _check_window(f, merged)
    f.check()
    if values.get("crq_number") and db.query_one("SELECT 1 AS x FROM change_requests WHERE crq_number = ? AND id <> ?",
                                                 (values["crq_number"], cid)):
        raise errors.conflict(f"{values['crq_number']} is already logged.")
    stored = _cr_values(values)
    changes = {k: [current.get(k), v] for k, v in stored.items() if current.get(k) != v}
    if not changes:
        return repo.get_change_request(cid)
    with db.transaction():
        db.update("change_requests", cid, {**stored, "updated_at": now_iso()})
        _store_compliance(cid)
        action = "update"
        if "sto_approval" in changes and values.get("sto_approval") in ("Go", "No-Go"):
            action = "approve" if values["sto_approval"] == "Go" else "reject"
            _sto_decision(iid, merged, values["sto_approval"])
        log_activity("change_request", cid, action, {"label": merged.get("crq_number") or "draft", "changes": changes}, iid)
        repo.sync_derived(iid)
    return repo.get_change_request(cid)


@bp.delete("/change-requests/<int:cid>")
def delete_change_request(cid: int):
    current = repo.get_change_request(cid)
    with db.transaction():
        db.execute("DELETE FROM change_requests WHERE id = ?", (cid,))
        log_activity("change_request", cid, "delete", {"label": current.get("crq_number") or "draft"},
                     current["initiative_id"])
        repo.sync_derived(current["initiative_id"])
    return {"ok": True}


# ------------------------------------------------------------------ risks
def _risk(rid) -> dict:
    rows = repo.list_risks("WHERE rk.id = ?", (rid,))
    if not rows:
        raise errors.not_found("Risk", rid)
    return rows[0]


def _risk_fields(data: dict, iid: int, *, creating: bool) -> Fields:
    f = Fields(data)
    f.text("title", required=creating, max_len=200)
    f.text("description", max_len=4000)
    f.lookup("category", "risk_category", required=creating, label="category")
    f.integer("severity", required=creating, lo=1, hi=4)
    f.integer("likelihood", required=creating, lo=1, hi=4)
    f.text("trigger_signal", max_len=1000)
    f.text("mitigation", max_len=4000)
    f.ref("owner_id", "resources", label="person")
    f.lookup("status", "risk_status", label="status")
    f.date("due_date")
    f.integer("task_id", lo=1)
    if f.out.get("task_id"):
        row = db.query_one("SELECT initiative_id FROM wbs_tasks WHERE id = ?", (f.out["task_id"],))
        if row is None or row["initiative_id"] != iid:
            f.error("task_id", "That WBS step is not on this initiative.")
    if not creating:
        for required in ("title", "category", "severity", "likelihood", "status"):
            if required in f.out and f.out[required] is None:
                f.error(required, "This field is required.")
    return f


@bp.get("/risks")
def list_risks():
    where, params = [], []
    iid = arg_int("initiative_id", lo=1)
    if iid:
        where.append("rk.initiative_id = ?")
        params.append(iid)
    if request.args.get("status"):
        clause = repo._in_clause("rk.status", request.args["status"], params)
        if clause:
            where.append(clause)
    min_score = arg_int("min_score", lo=0, hi=16)
    if min_score:
        where.append("rk.score >= ?")
        params.append(min_score)
    return listed(repo.list_risks(("WHERE " + " AND ".join(where) + " ") if where else "", params))


@bp.post("/initiatives/<int:iid>/risks")
def create_risk(iid: int):
    repo.require("initiatives", iid, "Initiative")
    values = _risk_fields(json_body(), iid, creating=True).check()
    with db.transaction():
        last = db.scalar("SELECT MAX(CAST(substr(risk_code, 5) AS INTEGER)) FROM risks WHERE risk_code LIKE 'RSK-%'") or 0
        code = f"RSK-{last + 1:03d}"
        rid = db.insert("risks", {**{k: v for k, v in values.items() if v is not None}, "initiative_id": iid,
                                  "risk_code": code, "source": "manual", "created_at": now_iso()})
        log_activity("risk", rid, "create", {"label": f"{code} {values['title']}"}, iid)
        repo.sync_derived(iid)
    return _risk(rid), 201


@bp.put("/risks/<int:rid>")
def update_risk(rid: int):
    current = _risk(rid)
    values = _risk_fields(json_body(), current["initiative_id"], creating=False).check()
    changes = {k: [current.get(k), v] for k, v in values.items() if current.get(k) != v}
    if not changes:
        return current
    with db.transaction():
        db.update("risks", rid, values)
        log_activity("risk", rid, "update", {"label": current["risk_code"], "changes": changes}, current["initiative_id"])
        repo.sync_derived(current["initiative_id"])
    return _risk(rid)


@bp.delete("/risks/<int:rid>")
def delete_risk(rid: int):
    current = _risk(rid)
    with db.transaction():
        db.execute("DELETE FROM risks WHERE id = ?", (rid,))
        log_activity("risk", rid, "delete", {"label": current["risk_code"]}, current["initiative_id"])
        repo.sync_derived(current["initiative_id"])
    return {"ok": True}


# ------------------------------------------------------------------ grooming
def _sessions(where: str = "", params: tuple | list = ()) -> list[dict]:
    sessions = db.query("SELECT * FROM grooming_sessions " + where + " ORDER BY session_date, start_time", params)
    if not sessions:
        return []
    ids = [s["id"] for s in sessions]
    slots = db.query(
        f"SELECT s.session_id, s.initiative_id, i.rddc, i.name, i.priority, i.stage, s.slot_order, s.status, "
        f"s.recipients_json FROM grooming_slots s JOIN initiatives i ON i.id = s.initiative_id "
        f"WHERE s.session_id IN ({', '.join('?' for _ in ids)}) ORDER BY s.session_id, s.slot_order", ids)
    names = {r["id"]: r["name"] for r in db.query("SELECT id, name FROM resources")}
    by_session: dict[int, list] = {}
    for s in slots:
        people = db.from_json(s.pop("recipients_json"), []) or []
        s["recipients"] = [{"id": p, "name": names.get(p)} for p in people if p in names]
        by_session.setdefault(s["session_id"], []).append(s)
    for s in sessions:
        s["slots"] = by_session.get(s["id"], [])
    return sessions


@bp.get("/grooming/sessions")
def list_sessions():
    where, params = [], []
    first, last = arg_date("from"), arg_date("to")
    if first:
        where.append("session_date >= ?")
        params.append(first)
    if last:
        where.append("session_date <= ?")
        params.append(last)
    return listed(_sessions(("WHERE " + " AND ".join(where) + " ") if where else "", params))


@bp.post("/grooming/sessions")
def create_session():
    f = Fields(json_body())
    f.date("session_date", required=True)
    f.text("start_time", max_len=5)
    f.text("title", max_len=120)
    f.integer("capacity", lo=1, hi=12)
    f.enum("status", ("Scheduled", "Held", "Cancelled"), label="status")
    values = f.check()
    start = values.get("start_time") or "10:00"
    if not TIME_RE.match(start):
        raise errors.validation("Some fields need attention.", {"start_time": "Use a time like 10:00."})
    if date.fromisoformat(values["session_date"]).weekday() >= 5:
        raise errors.validation("Some fields need attention.", {"session_date": "Grooming runs on business days."})
    if db.query_one("SELECT 1 AS x FROM grooming_sessions WHERE session_date = ? AND start_time = ?",
                    (values["session_date"], start)):
        raise errors.conflict("A grooming session already exists at that date and time.")
    with db.transaction():
        sid = db.insert("grooming_sessions", {
            "session_date": values["session_date"], "start_time": start, "title": values.get("title") or "DC grooming",
            "capacity": values.get("capacity") or 6, "status": values.get("status") or "Scheduled"})
        log_activity("grooming_session", sid, "create", {"label": f"{values['session_date']} {start}"})
    return _sessions("WHERE id = ?", (sid,))[0], 201


@bp.put("/grooming/slots")
def update_slot():
    f = Fields(json_body())
    f.ref("session_id", "grooming_sessions", required=True, label="grooming session")
    f.ref("initiative_id", "initiatives", required=True, label="initiative")
    f.ref("new_session_id", "grooming_sessions", label="grooming session")
    f.lookup("status", "grooming_slot_status", label="status")
    values = f.check()
    sid, iid = values["session_id"], values["initiative_id"]
    slot = db.query_one("SELECT * FROM grooming_slots WHERE session_id = ? AND initiative_id = ?", (sid, iid))
    target = values.get("new_session_id") or sid
    moving = slot is None or target != sid
    if moving:
        session = db.query_one("SELECT * FROM grooming_sessions WHERE id = ?", (target,))
        if session["status"] != "Scheduled":
            raise errors.conflict("That grooming session is not open for new items.")
        if db.query_one("SELECT 1 AS x FROM grooming_slots WHERE session_id = ? AND initiative_id = ?", (target, iid)):
            raise errors.conflict("That initiative is already on this session.")
        used = db.scalar("SELECT COUNT(*) FROM grooming_slots WHERE session_id = ?", (target,))
        if used >= session["capacity"]:
            raise errors.conflict(f"That session is full ({session['capacity']} of {session['capacity']}).")
    ini = db.query_one("SELECT * FROM initiatives WHERE id = ?", (iid,))
    with db.transaction():
        if moving:
            order = (db.scalar("SELECT MAX(slot_order) FROM grooming_slots WHERE session_id = ?", (target,)) or 0) + 1
            if slot is not None:
                db.execute("DELETE FROM grooming_slots WHERE session_id = ? AND initiative_id = ?", (sid, iid))
                recipients = slot["recipients_json"]
            else:
                lead = db.query_one("SELECT id FROM resources WHERE role = 'Delivery Lead' ORDER BY id LIMIT 1")
                people = [p for p in ((lead or {}).get("id"), ini["dc_pm_id"], ini["dc_sa_id"], ini["requestor_id"]) if p]
                recipients = db.to_json(list(dict.fromkeys(people)))
            db.insert("grooming_slots", {"session_id": target, "initiative_id": iid, "slot_order": order,
                                         "recipients_json": recipients, "status": values.get("status") or "Proposed"})
            log_activity("grooming_slot", target, "move", {"label": ini["rddc"], "from_session": sid, "to_session": target}, iid)
        elif values.get("status"):
            db.execute("UPDATE grooming_slots SET status = ? WHERE session_id = ? AND initiative_id = ?",
                       (values["status"], sid, iid))
            log_activity("grooming_slot", sid, "update", {"label": ini["rddc"], "status": values["status"]}, iid)
        repo.sync_derived(iid)
    row = db.query_one("SELECT session_id, initiative_id, status, slot_order FROM grooming_slots "
                       "WHERE session_id = ? AND initiative_id = ?", (target, iid))
    return row


# ------------------------------------------------------------------ Outbox
def _notification(nid) -> dict:
    row = db.query_one("SELECT n.*, i.rddc FROM notifications n LEFT JOIN initiatives i ON i.id = n.initiative_id "
                       "WHERE n.id = ?", (nid,))
    if row is None:
        raise errors.not_found("Outbox message", nid)
    return repo.parse_row(row)


@bp.get("/outbox")
def list_outbox():
    where, params = [], []
    if request.args.get("status"):
        clause = repo._in_clause("n.status", request.args["status"], params)
        if clause:
            where.append(clause)
    if request.args.get("rule"):
        clause = repo._in_clause("n.rule", request.args["rule"], params)
        if clause:
            where.append(clause)
    iid = arg_int("initiative_id", lo=1)
    if iid:
        where.append("n.initiative_id = ?")
        params.append(iid)
    rows = db.query("SELECT n.*, i.rddc FROM notifications n LEFT JOIN initiatives i ON i.id = n.initiative_id "
                    + ("WHERE " + " AND ".join(where) + " " if where else "")
                    + "ORDER BY CASE n.status WHEN 'Queued' THEN 0 ELSE 1 END, COALESCE(n.due_at, n.created_at) DESC, "
                      "n.id DESC", params)
    counts = {s: 0 for s in ("Queued", "Sent", "Acknowledged", "Dismissed")}
    for r in db.query("SELECT status, COUNT(*) AS n FROM notifications GROUP BY status"):
        counts[r["status"]] = r["n"]
    items = repo.parse_rows(rows)
    return {"items": items, "total": len(items), "counts": counts}


def _set_status(nid: int, status: str, action: str):
    row = _notification(nid)
    updates = {"status": status}
    if status == "Sent" and not row.get("sent_at"):
        updates["sent_at"] = now_iso()
    with db.transaction():
        db.update("notifications", nid, updates)
        log_activity("notification", nid, action, {"label": row["subject"]}, row.get("initiative_id"))
    return _notification(nid)


@bp.post("/outbox/<int:nid>/send")
def send_outbox(nid: int):
    return _set_status(nid, "Sent", "send")


@bp.post("/outbox/<int:nid>/ack")
def ack_outbox(nid: int):
    return _set_status(nid, "Acknowledged", "ack")


@bp.post("/outbox/<int:nid>/dismiss")
def dismiss_outbox(nid: int):
    return _set_status(nid, "Dismissed", "dismiss")
