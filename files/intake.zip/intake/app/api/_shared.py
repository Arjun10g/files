"""Request parsing and field validation shared by the B1 blueprints (core, initiatives, plan, resources,
governance, artifacts). Not a blueprint: create_app() only imports the modules it lists.
"""
from __future__ import annotations

import math
import re
from datetime import date, datetime

from flask import request

from app import db, errors
from app.today import tz

DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
MONTH_RE = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")
TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


def json_body() -> dict:
    """The JSON object sent with the request ({} when the body is empty). Anything else is a 400."""
    if not request.get_data(cache=True):
        return {}
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise errors.ApiError("bad_request", "The request could not be read.", 400)
    return data


def listed(items: list) -> dict:
    return {"items": items, "total": len(items)}


def arg_int(name: str, *, default=None, lo: int | None = None, hi: int | None = None):
    raw = request.args.get(name)
    if raw in (None, ""):
        return default
    try:
        value = int(raw)
    except ValueError:
        raise errors.validation("Some filters need attention.", {name: "Enter a whole number."}) from None
    if lo is not None and value < lo:
        value = lo
    if hi is not None and value > hi:
        value = hi
    return value


def arg_date(name: str):
    raw = request.args.get(name)
    if raw in (None, ""):
        return None
    if not valid_date(raw):
        raise errors.validation("Some filters need attention.", {name: "Use a date like 2026-10-19."})
    return raw


def valid_date(value) -> bool:
    if not isinstance(value, str) or not DATE_RE.match(value):
        return False
    try:
        date.fromisoformat(value)
    except ValueError:
        return False
    return True


def lookup_values(category: str) -> list[str]:
    return [r["value"] for r in db.query("SELECT value FROM lookups WHERE category = ? ORDER BY sort", (category,))]


class Fields:
    """Validate a request body field by field. `out` holds the cleaned values for the fields that were sent."""

    def __init__(self, data: dict):
        self.data = data if isinstance(data, dict) else {}
        self.errors: dict[str, str] = {}
        self.out: dict = {}

    def has(self, name: str) -> bool:
        return name in self.data

    def _missing(self, name: str, required: bool) -> bool:
        value = self.data.get(name)
        empty = value is None or (isinstance(value, str) and not value.strip())
        if empty:
            if required:
                self.errors[name] = "This field is required."
            elif name in self.data:
                self.out[name] = None
            return True
        return False

    def text(self, name: str, *, required: bool = False, max_len: int = 4000):
        if self._missing(name, required):
            return
        value = self.data[name]
        if not isinstance(value, (str, int, float)) or isinstance(value, bool):
            self.errors[name] = "Enter text."
            return
        value = str(value).strip()
        if len(value) > max_len:
            self.errors[name] = f"Keep this to {max_len} characters or fewer."
            return
        self.out[name] = value

    def enum(self, name: str, options, *, required: bool = False, label: str = "value"):
        if self._missing(name, required):
            return
        value = self.data[name]
        allowed = list(options)
        if value not in allowed:
            self.errors[name] = f"Choose a {label} from the list."
            return
        self.out[name] = value

    def lookup(self, name: str, category: str, *, required: bool = False, label: str = "value"):
        self.enum(name, lookup_values(category), required=required, label=label)

    def integer(self, name: str, *, required: bool = False, lo: int | None = None, hi: int | None = None):
        if self._missing(name, required):
            return
        value = self.data[name]
        if isinstance(value, bool):
            value = int(value)
        if isinstance(value, str) and re.fullmatch(r"-?\d+", value.strip()):
            value = int(value.strip())
        if isinstance(value, float) and value.is_integer():
            value = int(value)
        if not isinstance(value, int):
            self.errors[name] = "Enter a whole number."
            return
        if (lo is not None and value < lo) or (hi is not None and value > hi):
            self.errors[name] = f"Enter a number from {lo} to {hi}." if lo is not None and hi is not None else \
                "That number is out of range."
            return
        self.out[name] = value

    def number(self, name: str, *, required: bool = False, lo: float | None = None, hi: float | None = None):
        if self._missing(name, required):
            return
        value = self.data[name]
        if isinstance(value, str):
            try:
                value = float(value.strip())
            except ValueError:
                value = None
        if isinstance(value, bool) or not isinstance(value, (int, float)) or math.isnan(value):
            self.errors[name] = "Enter a number."
            return
        if (lo is not None and value < lo) or (hi is not None and value > hi):
            self.errors[name] = "That number is out of range."
            return
        self.out[name] = float(value)

    def flag(self, name: str):
        if self._missing(name, False):
            return
        value = self.data[name]
        if value in (True, 1, "1", "true", "yes"):
            self.out[name] = 1
        elif value in (False, 0, "0", "false", "no"):
            self.out[name] = 0
        else:
            self.errors[name] = "Choose yes or no."

    def date(self, name: str, *, required: bool = False):
        if self._missing(name, required):
            return
        value = self.data[name]
        if isinstance(value, str) and len(value) > 10 and valid_date(value[:10]) and value[10] in "T ":
            value = value[:10]
        if not valid_date(value):
            self.errors[name] = "Use a date like 2026-10-19."
            return
        self.out[name] = value

    def month(self, name: str, *, required: bool = False):
        if self._missing(name, required):
            return
        value = self.data[name]
        if not isinstance(value, str) or not MONTH_RE.match(value):
            self.errors[name] = "Use a month like 2026-11."
            return
        self.out[name] = value

    def datetime(self, name: str, *, required: bool = False):
        """ISO date-time; a value without an offset is read as Toronto time."""
        if self._missing(name, required):
            return
        value = self.data[name]
        parsed = None
        if isinstance(value, str):
            try:
                parsed = datetime.fromisoformat(value.strip())
            except ValueError:
                parsed = None
        if parsed is None or len(value.strip()) < 16:
            self.errors[name] = "Use a date and time like 2027-02-20T02:00."
            return
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=tz())
        self.out[name] = parsed.replace(microsecond=0).isoformat()

    def ref(self, name: str, table: str, *, required: bool = False, label: str = "item", key: str = "id"):
        """Must point at an existing row. `table`/`key` are trusted identifiers."""
        if self._missing(name, required):
            return
        value = self.data[name]
        if key == "id":
            if isinstance(value, str) and value.strip().isdigit():
                value = int(value.strip())
            if isinstance(value, bool) or not isinstance(value, int):
                self.errors[name] = f"Choose a {label} from the list."
                return
        elif not isinstance(value, str):
            self.errors[name] = f"Choose a {label} from the list."
            return
        if db.query_one(f"SELECT 1 AS x FROM {table} WHERE {key} = ?", (value,)) is None:
            self.errors[name] = f"That {label} does not exist."
            return
        self.out[name] = value

    def strings(self, name: str, *, max_items: int = 50, max_len: int = 200, options=None):
        if name not in self.data:
            return
        value = self.data[name]
        if value is None:
            self.out[name] = []
            return
        if isinstance(value, str):
            value = [v.strip() for v in value.split(",") if v.strip()]
        if not isinstance(value, list) or len(value) > max_items:
            self.errors[name] = "Send a list of text values."
            return
        cleaned = []
        for item in value:
            if not isinstance(item, (str, int)) or isinstance(item, bool):
                self.errors[name] = "Send a list of text values."
                return
            text = str(item).strip()
            if not text:
                continue
            if len(text) > max_len:
                self.errors[name] = f"Keep each value to {max_len} characters or fewer."
                return
            if options is not None and text not in options:
                self.errors[name] = f"'{text}' is not in the list."
                return
            if text not in cleaned:
                cleaned.append(text)
        self.out[name] = cleaned

    def error(self, name: str, message: str):
        self.errors[name] = message

    def check(self, message: str = "Some fields need attention.") -> dict:
        if self.errors:
            raise errors.validation(message, self.errors)
        return self.out
