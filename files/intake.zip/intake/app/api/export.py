"""Excel and CSV downloads: the Demo View workbook for one initiative, the portfolio workbook and CSV."""
from __future__ import annotations

from flask import Blueprint, Response, request

from app import db, errors
from app.api import views
from app.engines import calendar as cal
from app.engines import capacity
from app.services import derive, xlsx_export
from app.today import get_today

bp = Blueprint("export", __name__, url_prefix="/api")

XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def _download(payload: bytes | str, filename: str, mime: str) -> Response:
    resp = Response(payload, mimetype=mime)
    resp.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    return resp


def _lookups() -> dict:
    out: dict[str, list] = {}
    for r in db.query("SELECT category, value, label FROM lookups ORDER BY category, sort, value"):
        out.setdefault(r["category"], []).append({"value": r["value"], "label": r["label"] or r["value"]})
    return out


def _risks(initiative_id=None) -> list[dict]:
    sql = ("SELECT k.*, i.rddc, r.name AS owner_name, t.wbs_code FROM risks k JOIN initiatives i ON "
           "i.id = k.initiative_id LEFT JOIN resources r ON r.id = k.owner_id LEFT JOIN wbs_tasks t ON "
           "t.id = k.task_id")
    if initiative_id is not None:
        return db.query(sql + " WHERE k.initiative_id = ? ORDER BY k.score DESC, k.id", (initiative_id,))
    return db.query(sql + " ORDER BY i.rddc, k.score DESC, k.id")


def _capacity(people: list[dict], months: list[str]) -> tuple[dict, dict]:
    quarter_months = cal.month_range(cal.fiscal_quarter(months[0])["months"][0],
                                     cal.fiscal_quarter(months[-1])["months"][-1])
    allocs = views._allocations(quarter_months)
    return (capacity.compute_capacity(people, allocs, quarter_months, "quarter"),
            capacity.compute_capacity(people, allocs, months, "resource"))


@bp.get("/export/demo-view.xlsx")
def demo_view_xlsx():
    raw = request.args.get("initiative_id")
    if not raw:
        raise errors.validation("Choose an initiative to export.", {"initiative_id": "Required."})
    try:
        initiative_id = int(raw)
    except ValueError as exc:
        raise errors.validation("Choose an initiative to export.", {"initiative_id": "Must be a number."}) from exc
    bundle = views._bundle(initiative_id)
    ini = views._initiative_row(initiative_id)
    grid = views.build_resource_grid(initiative_id)
    gantt = views.gantt_payload(bundle)
    health = views._health(initiative_id)
    on_plan = {r["resource_id"] for r in grid["rows"]}
    people = [p for p in views._capacity_people() if p["id"] in on_plan]
    months = [m for q in grid["quarters"] for m in q["months"]]
    cap_q, cap_m = _capacity(people, months)
    queue = {i["initiative_id"]: i for i in views.build_intake_queue()["items"]}
    crs = derive.change_requests_with_compliance("WHERE cr.initiative_id = ?", (initiative_id,))
    data = {
        "today": get_today().isoformat(),
        "initiative": ini,
        "components": bundle.get("components") or [],
        "tasks": bundle.get("tasks") or [],
        "attachments": bundle.get("attachments") or [],
        "grooming": bundle.get("grooming"),
        "action_required_by": _action_text(bundle.get("action_required"), queue.get(initiative_id)),
        "health": health,
        "gantt": gantt,
        "resource_grid": grid,
        "change_requests": crs,
        "risks": _risks(initiative_id),
        "capacity_quarter": cap_q,
        "capacity_month": cap_m,
        "portfolio": views.build_portfolio({}),
        "lookups": _lookups(),
    }
    payload = xlsx_export.build_demo_view(data)
    return _download(payload, f"{ini['rddc']}-demo-view.xlsx", XLSX_MIME)


def _action_text(action, queue_item=None) -> str:
    """The bundle's `action_required` ({owner_name, due, what}) as one line, the same text Pg 1 shows."""
    if action and action.get("due"):
        return (f"{action.get('owner_name') or 'Owner'} · {cal.fmt_day_long(action['due'])} · "
                f"{action.get('what') or 'Action required'}")
    if queue_item and queue_item.get("action_required_by"):
        return f"{queue_item.get('waiting_on') or 'Owner'} · {cal.fmt_day_long(queue_item['action_required_by'])}"
    return ""


@bp.get("/export/portfolio.xlsx")
def portfolio_xlsx():
    filters = views.portfolio_filters()
    months = views._window(11)
    cap_q, cap_m = _capacity(views._capacity_people(), months)
    data = {"today": get_today().isoformat(), "portfolio": views.build_portfolio(filters),
            "capacity_quarter": cap_q, "capacity_month": cap_m, "risks": _risks(), "lookups": _lookups()}
    payload = xlsx_export.build_portfolio_workbook(data)
    return _download(payload, f"dc-portfolio-{get_today().isoformat()}.xlsx", XLSX_MIME)


@bp.get("/export/portfolio.csv")
def portfolio_csv():
    projects = views.build_portfolio(views.portfolio_filters())["projects"]
    text = xlsx_export.build_portfolio_csv(projects)
    return _download("﻿" + text, f"dc-portfolio-{get_today().isoformat()}.csv", "text/csv")
