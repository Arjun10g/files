"""Project plan (owner B1): WBS steps, dependencies, grid bulk save and re-baseline.

Every write validates dates (end on or after start) and the dependency graph (no loops), lets
engines.schedule.propagate_slip move dependants, rolls summary rows up from their children, syncs the plan header
dates on the initiative, then rebuilds allocations and health through app.services.derive in the same transaction.
Contracts: docs/contracts.md §2 "plan" and §3 "Plan semantics".
"""
from __future__ import annotations

import re

from flask import Blueprint

from app import db, errors, repo
from app.activity import actor_name, log_activity
from app.api._shared import Fields, json_body, listed
from app.today import get_today, now_iso

bp = Blueprint("plan", __name__, url_prefix="/api")

WBS_RE = re.compile(r"^WBS-\d{3}$")
TASK_COLUMNS = ("wbs_code", "parent_id", "step", "phase", "description", "owner_id", "resource_id", "planned_start",
                "planned_end", "actual_start", "actual_end", "est_hours", "allocation_pct", "status", "pct", "at_risk",
                "comments", "is_milestone", "sort", "initiative_component_id")


# ------------------------------------------------------------------ validation
def _task_fields(data: dict, *, creating: bool) -> Fields:
    f = Fields(data)
    f.text("wbs_code", required=creating, max_len=7)
    if "wbs_code" in f.out and f.out["wbs_code"] is not None:
        f.out["wbs_code"] = f.out["wbs_code"].upper()
        if not WBS_RE.match(f.out["wbs_code"]):
            f.error("wbs_code", "Use a WBS code like WBS-210.")
    f.text("step", required=creating, max_len=200)
    f.lookup("phase", "phase", label="phase")
    f.text("description", max_len=4000)
    f.ref("owner_id", "resources", label="person")
    f.ref("resource_id", "resources", label="person")
    for col in ("planned_start", "planned_end", "actual_start", "actual_end"):
        f.date(col)
    f.number("est_hours", lo=0, hi=20000)
    f.integer("allocation_pct", lo=1, hi=100)
    f.lookup("status", "task_status", label="status")
    f.integer("pct", lo=0, hi=100)
    f.flag("at_risk")
    f.flag("is_milestone")
    f.text("comments", max_len=4000)
    f.integer("sort", lo=0, hi=1_000_000)
    f.integer("parent_id", lo=1)
    f.integer("initiative_component_id", lo=1)
    if "depends_on" in data:
        deps = data["depends_on"]
        if deps is None:
            deps = []
        if not isinstance(deps, list) or any(isinstance(d, bool) or not isinstance(d, int) for d in deps):
            f.error("depends_on", "Send a list of WBS step ids.")
        else:
            f.out["depends_on"] = list(dict.fromkeys(deps))
    for required in ("wbs_code", "step", "status"):
        if required in f.out and f.out[required] is None and not creating:
            f.error(required, "This field is required.")
    return f


def _effort_end(task_id, current: dict | None, values: dict) -> None:
    """Hours or Alloc % edited (and no explicit end in the same request): the end follows the effort.

    end = start + ceil(est_hours / (7 h × allocation_pct)) business days, the schedule engine's convention.
    Milestones and summary rows (children, no hours of their own) keep their dates.
    """
    if "planned_end" in values or not ({"est_hours", "allocation_pct"} & set(values)):
        return
    if current is not None and all(values.get(k, current.get(k)) == current.get(k) for k in ("est_hours", "allocation_pct")):
        return
    merged = _merged(current, values)
    start, hours = merged.get("planned_start"), float(merged.get("est_hours") or 0)
    if not start or hours <= 0 or merged.get("is_milestone"):
        return
    if task_id is not None and db.query_one("SELECT 1 AS x FROM wbs_tasks WHERE parent_id = ?", (task_id,)):
        return
    schedule = repo.optional_module("app.engines.schedule")
    cal = repo.optional_module("app.engines.calendar")
    if schedule is None or cal is None:
        return
    duration = schedule.duration_from_hours(hours, merged.get("allocation_pct"))
    values["planned_end"] = cal.end_after_business_days(start, duration).isoformat()


def _check_task(iid: int, task_id, merged: dict, errs: dict) -> None:
    """Cross-field and same-initiative checks on the merged (current + patch) task."""
    start, end = merged.get("planned_start"), merged.get("planned_end")
    if start and end and end < start:
        errs["planned_end"] = "End date must be on or after the start date."
    if merged.get("actual_start") and merged.get("actual_end") and merged["actual_end"] < merged["actual_start"]:
        errs["actual_end"] = "Actual end must be on or after the actual start."
    if merged.get("is_milestone") and start and end and start != end:
        errs["planned_end"] = "A milestone starts and ends on the same day."
    parent = merged.get("parent_id")
    if parent is not None:
        row = db.query_one("SELECT id, initiative_id, parent_id FROM wbs_tasks WHERE id = ?", (parent,))
        if row is None or row["initiative_id"] != iid:
            errs["parent_id"] = "The parent step must be on the same plan."
        elif task_id is not None:
            seen, cur = set(), row
            while cur is not None and cur["id"] not in seen:
                if cur["id"] == task_id:
                    errs["parent_id"] = "A step cannot sit under itself."
                    break
                seen.add(cur["id"])
                cur = db.query_one("SELECT id, parent_id FROM wbs_tasks WHERE id = ?", (cur["parent_id"],)) \
                    if cur["parent_id"] else None
    icid = merged.get("initiative_component_id")
    if icid is not None:
        row = db.query_one("SELECT initiative_id FROM initiative_components WHERE id = ?", (icid,))
        if row is None or row["initiative_id"] != iid:
            errs["initiative_component_id"] = "That DC component is not on this initiative."
    deps = merged.get("depends_on") or []
    if task_id is not None and task_id in deps:
        errs["depends_on"] = "A step cannot depend on itself."
    elif deps:
        rows = db.query(f"SELECT id FROM wbs_tasks WHERE initiative_id = ? AND id IN ({', '.join('?' for _ in deps)})",
                        [iid, *deps])
        if len(rows) != len(deps):
            errs["depends_on"] = "Every predecessor must be a step on the same plan."


def _find_cycle(iid: int) -> list[str]:
    """WBS codes on a dependency loop for this plan, or [] when the graph is acyclic."""
    tasks = {t["id"]: t["wbs_code"] for t in db.query("SELECT id, wbs_code FROM wbs_tasks WHERE initiative_id = ?", (iid,))}
    edges: dict[int, list[int]] = {i: [] for i in tasks}
    for d in db.query("SELECT d.task_id, d.depends_on_task_id FROM wbs_dependencies d JOIN wbs_tasks t "
                      "ON t.id = d.task_id WHERE t.initiative_id = ?", (iid,)):
        edges.setdefault(d["task_id"], []).append(d["depends_on_task_id"])
    state: dict[int, int] = {}
    stack_path: list[int] = []

    def visit(n: int) -> list[int] | None:
        state[n] = 1
        stack_path.append(n)
        for m in edges.get(n, []):
            if state.get(m) == 1:
                return stack_path[stack_path.index(m):] + [m]
            if state.get(m) is None:
                found = visit(m)
                if found:
                    return found
        stack_path.pop()
        state[n] = 2
        return None

    for node in tasks:
        if state.get(node) is None:
            loop = visit(node)
            if loop:
                return [tasks.get(i, str(i)) for i in loop]
    return []


# ------------------------------------------------------------------ plan maintenance
def _roll_up_summaries(iid: int) -> None:
    """A row with children and no hours of its own takes the earliest child start and latest child end."""
    for _ in range(4):
        changed = 0
        for row in db.query(
                "SELECT p.id, MIN(c.planned_start) AS s, MAX(c.planned_end) AS e, p.planned_start, p.planned_end "
                "FROM wbs_tasks p JOIN wbs_tasks c ON c.parent_id = p.id WHERE p.initiative_id = ? "
                "AND COALESCE(p.est_hours, 0) = 0 GROUP BY p.id", (iid,)):
            if row["s"] and (row["s"], row["e"]) != (row["planned_start"], row["planned_end"]):
                db.execute("UPDATE wbs_tasks SET planned_start = ?, planned_end = ? WHERE id = ?", (row["s"], row["e"], row["id"]))
                changed += 1
        if not changed:
            break


def _sync_header_dates(iid: int) -> None:
    tasks = db.query("SELECT * FROM wbs_tasks WHERE initiative_id = ?", (iid,))
    if not tasks:
        return
    schedule = repo.optional_module("app.engines.schedule")
    if schedule is not None:
        dates = schedule.key_dates(tasks)
    else:
        def max_end(phase):
            ends = [t["planned_end"] for t in tasks if t["phase"] == phase and t["planned_end"]]
            return max(ends) if ends else None
        prod = [t["planned_start"] for t in tasks if t["is_milestone"] and t["phase"] == "Production" and t["planned_start"]]
        starts = [t["planned_start"] for t in tasks if t["planned_start"]]
        ends = [t["planned_end"] for t in tasks if t["planned_end"]]
        dates = {"readiness_date": max_end("Readiness"), "qa_date": max_end("QA"), "prod_date": min(prod) if prod else None,
                 "start": min(starts) if starts else None, "end": max(ends) if ends else None}
    db.execute("UPDATE initiatives SET planned_start = ?, planned_end = ?, readiness_date = ?, qa_date = ?, prod_date = ? "
               "WHERE id = ?", (dates.get("start"), dates.get("end"), dates.get("readiness_date"), dates.get("qa_date"),
                                dates.get("prod_date"), iid))


def _propagate(iid: int, changed_ids: list[int]) -> list[dict]:
    schedule = repo.optional_module("app.engines.schedule")
    shifted: dict[int, tuple] = {}
    if schedule is not None:
        for changed in changed_ids:
            tasks = repo.list_tasks(iid)
            moves = schedule.propagate_slip(tasks, changed)
            for tid, (start, end) in moves.items():
                db.execute("UPDATE wbs_tasks SET planned_start = ?, planned_end = ?, updated_at = ? WHERE id = ?",
                           (start, end, now_iso(), tid))
                shifted[tid] = (start, end)
    _roll_up_summaries(iid)
    if not shifted:
        return []
    rows = db.query(f"SELECT id, wbs_code, planned_start, planned_end FROM wbs_tasks WHERE id IN "
                    f"({', '.join('?' for _ in shifted)}) ORDER BY sort, id", list(shifted))
    return rows


def _default_sort(iid: int, code: str) -> int:
    row = db.query_one("SELECT sort FROM wbs_tasks WHERE initiative_id = ? AND wbs_code <= ? ORDER BY wbs_code DESC LIMIT 1",
                       (iid, code))
    if row is None:
        return 0
    return (row["sort"] or 0) + 1


def _write_task(iid: int, task_id, values: dict) -> int:
    """Insert or update one task row and its dependencies. Caller holds the transaction."""
    deps = values.pop("depends_on", None)
    if values.get("status") == "Completed":
        values["pct"] = 100
    columns = {k: v for k, v in values.items() if k in TASK_COLUMNS}
    if columns.get("is_milestone") and columns.get("planned_start") and not columns.get("planned_end"):
        columns["planned_end"] = columns["planned_start"]
    columns["updated_at"] = now_iso()
    if task_id is None:
        if db.query_one("SELECT 1 AS x FROM wbs_tasks WHERE initiative_id = ? AND wbs_code = ?", (iid, columns["wbs_code"])):
            raise errors.conflict(f"{columns['wbs_code']} is already on this plan.")
        columns.setdefault("sort", _default_sort(iid, columns["wbs_code"]))
        columns.setdefault("status", "Backlog")
        columns.update({"initiative_id": iid, "source": "manual"})
        task_id = db.insert("wbs_tasks", columns)
    else:
        if "wbs_code" in columns and db.query_one(
                "SELECT 1 AS x FROM wbs_tasks WHERE initiative_id = ? AND wbs_code = ? AND id <> ?",
                (iid, columns["wbs_code"], task_id)):
            raise errors.conflict(f"{columns['wbs_code']} is already on this plan.")
        db.update("wbs_tasks", task_id, columns)
    if deps is not None:
        db.execute("DELETE FROM wbs_dependencies WHERE task_id = ?", (task_id,))
        db.executemany("INSERT INTO wbs_dependencies (task_id, depends_on_task_id, type, lag_days) VALUES (?, ?, 'FS', 0)",
                       [(task_id, d) for d in deps])
    return task_id


def _merged(current: dict | None, values: dict) -> dict:
    merged = dict(current or {})
    merged.update(values)
    return merged


def _finish(iid: int, changed_dates: list[int]) -> tuple[list[dict], dict | None]:
    loop = _find_cycle(iid)
    if loop:
        raise errors.validation("These steps depend on each other in a loop: " + " → ".join(loop) + ".",
                                {"depends_on": "Remove one of the dependencies to break the loop."})
    shifted = _propagate(iid, changed_dates)
    _sync_header_dates(iid)
    db.execute("UPDATE initiatives SET updated_at = ? WHERE id = ?", (now_iso(), iid))
    health = repo.sync_derived(iid, allocations=True)
    return shifted, health


# ------------------------------------------------------------------ endpoints
@bp.get("/initiatives/<int:iid>/tasks")
def list_tasks(iid: int):
    repo.require("initiatives", iid, "Initiative")
    return listed(repo.list_tasks(iid))


@bp.post("/initiatives/<int:iid>/tasks")
def create_task(iid: int):
    repo.require("initiatives", iid, "Initiative")
    f = _task_fields(json_body(), creating=True)
    values = f.check()
    _effort_end(None, None, values)
    _check_task(iid, None, values, f.errors)
    f.check()
    with db.transaction():
        tid = _write_task(iid, None, dict(values))
        log_activity("task", tid, "create", {"label": values["wbs_code"]}, iid)
        shifted, health = _finish(iid, [tid])
    return {"task": repo.get_task(tid), "shifted_tasks": shifted, "health": health}, 201


@bp.put("/tasks/<int:tid>")
def update_task(tid: int):
    current = repo.get_task(tid)
    iid = current["initiative_id"]
    f = _task_fields(json_body(), creating=False)
    values = f.check()
    _effort_end(tid, current, values)
    _check_task(iid, tid, _merged(current, values), f.errors)
    f.check()
    changes = {k: [current.get(k), v] for k, v in values.items() if current.get(k) != v}
    if not changes:
        cached = db.scalar("SELECT health_cached_json FROM initiatives WHERE id = ?", (iid,))
        return {"task": current, "shifted_tasks": [], "health": db.from_json(cached, None)}
    dates_changed = any(k in changes for k in ("planned_start", "planned_end"))
    with db.transaction():
        _write_task(iid, tid, dict(values))
        log_activity("task", tid, "update", {"label": current["wbs_code"], "changes": changes}, iid)
        shifted, health = _finish(iid, [tid] if dates_changed or "depends_on" in changes else [])
    return {"task": repo.get_task(tid), "shifted_tasks": shifted, "health": health}


@bp.delete("/tasks/<int:tid>")
def delete_task(tid: int):
    current = repo.get_task(tid)
    iid = current["initiative_id"]
    with db.transaction():
        db.execute("DELETE FROM wbs_tasks WHERE id = ?", (tid,))
        log_activity("task", tid, "delete", {"label": current["wbs_code"]}, iid)
        _, health = _finish(iid, [])
    return {"ok": True, "health": health}


@bp.put("/initiatives/<int:iid>/tasks/bulk")
def bulk_tasks(iid: int):
    repo.require("initiatives", iid, "Initiative")
    body = json_body()
    items = body.get("tasks")
    if not isinstance(items, list) or not items:
        raise errors.validation("Send at least one WBS step.", {"tasks": "Send at least one WBS step."})
    prepared, row_errors = [], {}
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            row_errors[f"tasks[{index}]"] = "Each row must be an object."
            continue
        tid = item.get("id")
        current = None
        if tid is not None:
            current = db.query_one("SELECT * FROM wbs_tasks WHERE id = ?", (tid,)) if isinstance(tid, int) else None
            if current is None or current["initiative_id"] != iid:
                row_errors[f"tasks[{index}].id"] = "That step is not on this plan."
                continue
            current = repo.get_task(tid)
        f = _task_fields({k: v for k, v in item.items() if k != "id"}, creating=current is None)
        values = dict(f.out)
        if not f.errors:
            _effort_end(tid, current, values)
            _check_task(iid, tid, _merged(current, values), f.errors)
        for field, message in f.errors.items():
            row_errors[f"tasks[{index}].{field}"] = message
        prepared.append((tid, current, values))
    if row_errors:
        raise errors.validation("Some rows need attention.", row_errors)
    with db.transaction():
        changed_dates = []
        for tid, current, values in prepared:
            changes = {k: v for k, v in values.items() if current is None or current.get(k) != v}
            if current is not None and not changes:
                continue
            new_id = _write_task(iid, tid, dict(values))
            if current is None or any(k in changes for k in ("planned_start", "planned_end", "depends_on")):
                changed_dates.append(new_id)
            log_activity("task", new_id, "create" if current is None else "update",
                         {"label": values.get("wbs_code") or current["wbs_code"]}, iid)
        _, health = _finish(iid, changed_dates)
    return {"items": repo.list_tasks(iid), "health": health}


@bp.post("/initiatives/<int:iid>/baseline")
def rebaseline(iid: int):
    ini = repo.get_initiative(iid)
    f = Fields(json_body())
    f.text("reason", required=True, max_len=1000)
    values = f.check("Give a reason for the re-baseline.")
    if not db.scalar("SELECT COUNT(*) FROM wbs_tasks WHERE initiative_id = ?", (iid,)):
        raise errors.validation("There is no plan to baseline yet.", {"tasks": "Generate or add the plan first."})
    stamp = now_iso()
    with db.transaction():
        db.execute("UPDATE wbs_tasks SET baseline_start = planned_start, baseline_end = planned_end WHERE initiative_id = ?",
                   (iid,))
        db.execute("UPDATE initiatives SET baseline_set_at = ?, updated_at = ? WHERE id = ?", (stamp, stamp, iid))
        readiness = db.scalar("SELECT readiness_date FROM initiatives WHERE id = ?", (iid,))
        db.insert("decisions", {
            "initiative_id": iid, "title": "Plan re-baselined",
            "context": values["reason"],
            "decision": "Baseline reset to the current plan" + (f"; Readiness Date {readiness}." if readiness else "."),
            "decided_by": actor_name(iid), "decided_on": get_today().isoformat(), "status": "Approved",
            "source": "system", "created_at": stamp})
        log_activity("plan", iid, "baseline", {"label": ini["rddc"], "reason": values["reason"]}, iid)
        repo.sync_derived(iid)
    return {"ok": True, "baseline_set_at": stamp}
