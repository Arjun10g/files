"""Artifacts (owner B1): Decision Log, Lessons Learned, Meeting Notes and the Document / Architecture repository.
`GET|POST /api/{decisions|lessons|meeting-notes|documents}` and `PUT|DELETE /api/{type}/{id}`; rows carry `rddc`.
"""
from __future__ import annotations

from flask import Blueprint, request

from app import db, errors, repo
from app.activity import actor_name, log_activity
from app.api._shared import Fields, arg_int, json_body, listed
from app.today import get_today, now_iso

bp = Blueprint("artifacts", __name__, url_prefix="/api")

TYPES = {
    "decisions": {"table": "decisions", "entity": "decision", "label": "Decision", "title": "title"},
    "lessons": {"table": "lessons_learned", "entity": "lesson", "label": "Lesson", "title": "lesson"},
    "meeting-notes": {"table": "meeting_notes", "entity": "meeting_note", "label": "Meeting notes", "title": "title"},
    "documents": {"table": "documents", "entity": "document", "label": "Document", "title": "title"},
}


def _spec(kind: str) -> dict:
    spec = TYPES.get(kind)
    if spec is None:
        raise errors.not_found("Artifact type", kind)
    return spec


def _fields(kind: str, data: dict, *, creating: bool) -> Fields:
    f = Fields(data)
    f.ref("initiative_id", "initiatives", label="initiative")
    if kind == "decisions":
        f.text("title", required=creating, max_len=200)
        f.text("context", max_len=4000)
        f.text("decision", required=creating, max_len=4000)
        f.text("decided_by", max_len=120)
        f.date("decided_on")
        f.enum("status", ("Proposed", "Approved", "Superseded"), label="status")
        required = ("title", "decision")
    elif kind == "lessons":
        f.text("category", max_len=60)
        f.text("what_happened", max_len=4000)
        f.text("lesson", required=creating, max_len=1000)
        f.text("recommendation", max_len=2000)
        f.strings("tags", max_items=20, max_len=40)
        required = ("lesson",)
    elif kind == "meeting-notes":
        f.ref("grooming_session_id", "grooming_sessions", label="grooming session")
        f.date("meeting_date")
        f.text("title", required=creating, max_len=200)
        f.strings("attendees", max_items=40, max_len=120)
        f.text("notes_md", max_len=50_000)
        if "action_items_json" in data:
            items = data["action_items_json"]
            if items is None:
                f.out["action_items_json"] = []
            elif not isinstance(items, list) or not all(isinstance(i, dict) for i in items) or len(items) > 100:
                f.error("action_items_json", "Send a list of actions with action, owner, due and status.")
            else:
                f.out["action_items_json"] = [{k: i.get(k) for k in ("action", "owner", "due", "status")} for i in items]
        required = ("title",)
    else:
        f.lookup("doc_type", "doc_type", required=creating, label="document type")
        f.text("title", required=creating, max_len=200)
        f.text("version", max_len=20)
        f.integer("attachment_id", lo=1)
        if f.out.get("attachment_id") and not db.query_one("SELECT 1 AS x FROM attachments WHERE id = ?",
                                                           (f.out["attachment_id"],)):
            f.error("attachment_id", "That file does not exist.")
        f.text("url", max_len=500)
        if f.out.get("url") and not f.out["url"].lower().startswith(("https://", "http://")):
            f.error("url", "Use a web link starting with https://.")
        f.ref("owner_id", "resources", label="person")
        f.enum("status", ("Draft", "In review", "Final"), label="status")
        codes = [r["code"] for r in db.query("SELECT code FROM dc_components")]
        f.strings("components", max_items=12, max_len=10, options=codes)
        required = ("doc_type", "title")
    if not creating:
        for name in required:
            if name in f.out and f.out[name] is None:
                f.error(name, "This field is required.")
    return f


def _store(kind: str, values: dict) -> dict:
    out = dict(values)
    for key in ("tags", "attendees", "components", "action_items_json"):
        if key in out:
            out[key] = db.to_json(out[key] if out[key] is not None else [])
    return out


def _select(kind: str) -> str:
    table = _spec(kind)["table"]
    extra = ""
    if kind == "documents":
        extra = (", o.name AS owner_name, a.filename AS attachment_filename FROM documents x "
                 "LEFT JOIN resources o ON o.id = x.owner_id LEFT JOIN attachments a ON a.id = x.attachment_id ")
        return "SELECT x.*, i.rddc, i.name AS initiative_name" + extra + "LEFT JOIN initiatives i ON i.id = x.initiative_id "
    return f"SELECT x.*, i.rddc, i.name AS initiative_name FROM {table} x LEFT JOIN initiatives i ON i.id = x.initiative_id "


def _row(kind: str, row_id) -> dict:
    row = db.query_one(_select(kind) + "WHERE x.id = ?", (row_id,))
    if row is None:
        raise errors.not_found(_spec(kind)["label"], row_id)
    return repo.parse_row(row)


ORDER = {"decisions": "x.decided_on DESC, x.id DESC", "lessons": "x.id", "meeting-notes": "x.meeting_date DESC, x.id DESC",
         "documents": "x.updated_at DESC, x.id DESC"}


@bp.get("/<any(decisions, lessons, 'meeting-notes', documents):kind>")
def list_artifacts(kind: str):
    where, params = [], []
    iid = arg_int("initiative_id", lo=1)
    if iid:
        where.append("x.initiative_id = ?")
        params.append(iid)
    q = (request.args.get("q") or "").strip()
    if q:
        column = "x.lesson" if kind == "lessons" else "x.title"
        where.append(f"({column} LIKE ? ESCAPE '\\' OR i.rddc LIKE ? ESCAPE '\\')")
        params += [repo._like(q)] * 2
    if kind == "documents":
        if request.args.get("doc_type"):
            clause = repo._in_clause("x.doc_type", request.args["doc_type"], params)
            if clause:
                where.append(clause)
        component = (request.args.get("component") or "").strip().upper()
        if component:
            where.append("x.components LIKE ? ESCAPE '\\'")
            params.append(repo._like(f'"{component}"'))
    rows = db.query(_select(kind) + ("WHERE " + " AND ".join(where) + " " if where else "") + f"ORDER BY {ORDER[kind]}",
                    params)
    return listed(repo.parse_rows(rows))


@bp.post("/<any(decisions, lessons, 'meeting-notes', documents):kind>")
def create_artifact(kind: str):
    spec = _spec(kind)
    values = {k: v for k, v in _fields(kind, json_body(), creating=True).check().items() if v is not None}
    iid = values.get("initiative_id")
    stamp = now_iso()
    if kind == "decisions":
        values.setdefault("decided_by", actor_name(iid))
        values.setdefault("decided_on", get_today().isoformat())
        values.update({"source": "manual", "created_at": stamp})
    elif kind == "lessons":
        values.update({"source": "manual", "created_at": stamp})
    elif kind == "meeting-notes":
        values.setdefault("meeting_date", get_today().isoformat())
        values["created_at"] = stamp
    else:
        values["updated_at"] = stamp
    with db.transaction():
        row_id = db.insert(spec["table"], _store(kind, values))
        log_activity(spec["entity"], row_id, "create", {"label": str(values.get(spec["title"]))[:80]}, iid)
    return _row(kind, row_id), 201


@bp.put("/<any(decisions, lessons, 'meeting-notes', documents):kind>/<int:row_id>")
def update_artifact(kind: str, row_id: int):
    spec = _spec(kind)
    current = _row(kind, row_id)
    values = _fields(kind, json_body(), creating=False).check()
    changes = {k: [current.get(k), v] for k, v in values.items() if current.get(k) != v}
    if not changes:
        return current
    stored = _store(kind, values)
    if kind == "documents":
        stored["updated_at"] = now_iso()
    with db.transaction():
        db.update(spec["table"], row_id, stored)
        log_activity(spec["entity"], row_id, "update", {"label": str(current.get(spec["title"]))[:80],
                                                        "fields": sorted(changes)}, current.get("initiative_id"))
    return _row(kind, row_id)


@bp.delete("/<any(decisions, lessons, 'meeting-notes', documents):kind>/<int:row_id>")
def delete_artifact(kind: str, row_id: int):
    spec = _spec(kind)
    current = _row(kind, row_id)
    with db.transaction():
        db.execute(f"DELETE FROM {spec['table']} WHERE id = ?", (row_id,))
        log_activity(spec["entity"], row_id, "delete", {"label": str(current.get(spec["title"]))[:80]},
                     current.get("initiative_id"))
    return {"ok": True}
