"""Funding budgets, monthly actuals and component/team estimates entered in the portal."""
from __future__ import annotations

import math
import re

from flask import Blueprint

from app import db, errors
from app.activity import log_activity
from app.api._shared import Fields, json_body, listed
from app.today import now_iso

bp = Blueprint('funding', __name__, url_prefix='/api/funding')
DECISIONS = ('Pending','Approved','Rejected','Delayed')
PHASES = ('Planning','Development','Support')
META_FIELDS = ('decision','charge_type','scope','assumptions','platform','region','channel','apt_number','external_pr_code')


def ensure_schema():
    db.execute('''CREATE TABLE IF NOT EXISTS funding_details (
        prn_code TEXT PRIMARY KEY REFERENCES prn_budget(prn_code) ON DELETE CASCADE,
        metadata_json TEXT NOT NULL DEFAULT '{}', updated_at TEXT)''')
    db.execute('''CREATE TABLE IF NOT EXISTS funding_estimates (
        id INTEGER PRIMARY KEY,
        prn_code TEXT NOT NULL REFERENCES prn_budget(prn_code) ON DELETE CASCADE,
        appcat TEXT, team TEXT, sto TEXT, phase TEXT NOT NULL DEFAULT 'Development',
        hours REAL NOT NULL DEFAULT 0, rate REAL NOT NULL DEFAULT 110, amount REAL NOT NULL DEFAULT 0,
        decision TEXT NOT NULL DEFAULT 'Pending', notes TEXT,
        created_at TEXT, updated_at TEXT)''')


def _finite(f: Fields):
    for key,value in f.out.items():
        if isinstance(value,float) and not math.isfinite(value):
            f.error(key,'Enter a finite number.')


def budget_fields(data: dict, *, creating: bool = True) -> tuple[dict,dict]:
    f = Fields(data)
    f.text('prn_code',required=creating,max_len=60)
    f.text('name',required=creating,max_len=200)
    f.lookup('lob','lob',label='line of business')
    f.number('funded_hours',lo=0)
    f.number('rate',lo=0)
    f.number('budget_amount',lo=0)
    f.text('currency',max_len=3)
    f.ref('owner_id','resources',label='budget owner')
    f.month('start_month')
    f.month('end_month')
    f.enum('decision',DECISIONS)
    f.enum('charge_type',('Project','POD'))
    for key in ('scope','assumptions'):
        f.text(key,max_len=16000)
    for key in ('platform','region','channel','apt_number','external_pr_code'):
        f.text(key,max_len=200)
    _finite(f)
    values = f.check()
    code = values.get('prn_code')
    if code:
        code = code.strip().upper()
        if not re.fullmatch(r'[A-Z0-9][A-Z0-9._-]{0,59}',code):
            raise errors.validation('Check the funding code.',{'prn_code':'Use letters, numbers, dots, underscores or hyphens.'})
        values['prn_code'] = code
    currency = values.get('currency')
    if currency:
        currency = currency.upper()
        if not re.fullmatch(r'[A-Z]{3}',currency):
            raise errors.validation('Check the currency.',{'currency':'Use a three-letter currency code.'})
        values['currency'] = currency
    if values.get('start_month') and values.get('end_month') and values['start_month'] > values['end_month']:
        raise errors.validation('Check the funding period.',{'end_month':'End month must be on or after start month.'})
    metadata = {k:values.pop(k) for k in META_FIELDS if k in values}
    if creating:
        values.setdefault('rate',110.0)
        values.setdefault('currency','CAD')
        if values.get('funded_hours') is None:
            if values.get('budget_amount') is not None and values['rate'] > 0:
                values['funded_hours'] = values['budget_amount'] / values['rate']
            else:
                raise errors.validation('Enter funded hours or an approved budget amount.',{'funded_hours':'Enter funded hours, or budget amount with a positive hourly rate.'})
        if values.get('budget_amount') is None:
            values['budget_amount'] = values['funded_hours'] * values['rate']
        metadata.setdefault('decision','Pending')
        metadata.setdefault('charge_type','Project')
    for required in ('name','funded_hours','rate','currency'):
        if required in values and values[required] is None:
            raise errors.validation('Check the funding details.',{required:'This field is required.'})
    return values,metadata


def _metadata(code):
    ensure_schema()
    row = db.query_one('SELECT metadata_json FROM funding_details WHERE prn_code = ?',(code,))
    return db.from_json(row['metadata_json'],{}) if row else {}


def _write_metadata(code,metadata):
    if metadata:
        ensure_schema()
        current = _metadata(code)
        current.update(metadata)
        db.execute('INSERT INTO funding_details (prn_code,metadata_json,updated_at) VALUES (?,?,?) '
                   'ON CONFLICT(prn_code) DO UPDATE SET metadata_json=excluded.metadata_json,updated_at=excluded.updated_at',
                   (code,db.to_json(current),now_iso()))


def get_budget(code: str) -> dict:
    ensure_schema()
    budget = db.query_one('SELECT p.*, r.name AS owner_name FROM prn_budget p LEFT JOIN resources r ON r.id=p.owner_id WHERE p.prn_code = ?',(code,))
    if budget is None:
        raise errors.not_found('Funding budget',code)
    budget.update(_metadata(code))
    budget['charges'] = db.query('SELECT * FROM prn_charges WHERE prn_code = ? ORDER BY month,id',(code,))
    budget['estimates'] = db.query('SELECT * FROM funding_estimates WHERE prn_code = ? ORDER BY appcat,team,id',(code,))
    budget['initiatives'] = db.query('SELECT id,rddc,name FROM initiatives WHERE prn_code = ? ORDER BY id',(code,))
    charged_hours = sum(row['charged_hours'] or 0 for row in budget['charges'])
    charged_amount = sum(row['charged_amount'] if row['charged_amount'] is not None else row['charged_hours']*budget['rate'] for row in budget['charges'])
    amount = budget['budget_amount'] if budget['budget_amount'] is not None else budget['funded_hours']*budget['rate']
    budget['totals'] = {'funded_hours':budget['funded_hours'],'charged_hours':round(charged_hours,2),
                        'remaining_hours':round(budget['funded_hours']-charged_hours,2),'budget_amount':amount,
                        'charged_amount':round(charged_amount,2),'remaining_amount':round(amount-charged_amount,2),
                        'utilization_pct':round(charged_amount/amount*100,1) if amount else 0,
                        'estimated_hours':round(sum(e['hours'] for e in budget['estimates']),2),
                        'estimated_amount':round(sum(e['amount'] for e in budget['estimates']),2)}
    return budget


def create_budget(data: dict) -> dict:
    ensure_schema()
    values,metadata = budget_fields(data)
    if db.query_one('SELECT 1 AS x FROM prn_budget WHERE prn_code=?',(values['prn_code'],)):
        raise errors.conflict('That funding code already exists.',{'prn_code':values['prn_code']})
    with db.transaction():
        db.insert('prn_budget',values)
        _write_metadata(values['prn_code'],metadata)
        log_activity('funding',None,'create',{'label':values['prn_code']})
    return get_budget(values['prn_code'])


def charge_fields(data: dict, *, creating=True) -> dict:
    f = Fields(data)
    f.month('month',required=creating)
    f.number('charged_hours',required=creating,lo=0)
    f.number('charged_amount',lo=0)
    _finite(f)
    values = f.check()
    for key in ('month','charged_hours'):
        if key in values and values[key] is None:
            raise errors.validation('Check the monthly charge.',{key:'This field is required.'})
    return values


def create_charge(code: str, data: dict, source: str = 'portal') -> dict:
    budget = get_budget(code)
    values = charge_fields(data)
    if db.query_one('SELECT id FROM prn_charges WHERE prn_code=? AND month=?',(code,values['month'])):
        raise errors.conflict('A charge already exists for this funding code and month. Edit that charge to change it.',{'prn_code':code,'month':values['month']})
    if values.get('charged_amount') is None:
        values['charged_amount'] = values['charged_hours'] * budget['rate']
    with db.transaction():
        cid = db.insert('prn_charges',{**values,'prn_code':code,'source':source})
        log_activity('funding_charge',cid,'create',{'label':f'{code} {values["month"]}'})
    return db.query_one('SELECT * FROM prn_charges WHERE id=?',(cid,))


def estimate_fields(data: dict, *, creating=True) -> dict:
    f = Fields(data)
    for key in ('appcat','team','sto'):
        f.text(key,max_len=200)
    f.enum('phase',PHASES)
    f.number('hours',lo=0)
    f.number('rate',lo=0)
    f.number('amount',lo=0)
    f.enum('decision',DECISIONS)
    f.text('notes',max_len=16000)
    _finite(f)
    values = f.check()
    if creating and not any(values.get(k) for k in ('appcat','team','sto')):
        raise errors.validation('Identify the component or team for this estimate.',{'appcat':'Enter an AppCat, team or STO.'})
    if creating:
        values.setdefault('phase','Development')
        values.setdefault('hours',0.0)
        values.setdefault('rate',110.0)
        values.setdefault('decision','Pending')
        if values.get('amount') is None:
            values['amount'] = values['hours']*values['rate']
    for key in ('phase','hours','rate','amount','decision'):
        if key in values and values[key] is None:
            raise errors.validation('Check the estimate.',{key:'This field is required.'})
    return values


def create_estimate(code: str, data: dict) -> dict:
    get_budget(code)
    values = estimate_fields(data)
    stamp = now_iso()
    with db.transaction():
        eid = db.insert('funding_estimates',{**values,'prn_code':code,'created_at':stamp,'updated_at':stamp})
        log_activity('funding_estimate',eid,'create',{'label':code})
    return db.query_one('SELECT * FROM funding_estimates WHERE id=?',(eid,))


def _summary(items):
    fields = ('funded_hours','charged_hours','remaining_hours','budget_amount','charged_amount','remaining_amount','estimated_hours','estimated_amount')
    currencies = {}
    by_month = {}
    by_lob = {}
    for item in items:
        currency = item['currency']
        bucket = currencies.setdefault(currency,{k:0 for k in fields})
        for key in fields:
            bucket[key] += item['totals'][key]
        lob = by_lob.setdefault((item.get('lob') or 'Unassigned',currency),{'lob':item.get('lob') or 'Unassigned','currency':currency,'budget_amount':0,'charged_amount':0,'funded_hours':0,'charged_hours':0})
        for key in ('budget_amount','charged_amount','funded_hours','charged_hours'):
            lob[key] += item['totals'][key]
        for charge in item['charges']:
            month = by_month.setdefault((charge['month'],currency),{'month':charge['month'],'currency':currency,'charged_hours':0,'charged_amount':0})
            month['charged_hours'] += charge['charged_hours']
            month['charged_amount'] += charge['charged_amount'] if charge['charged_amount'] is not None else charge['charged_hours']*item['rate']
    summary = {key:round(sum(i['totals'][key] for i in items),2) for key in fields}
    if len(currencies)>1:
        # Hours are additive; monetary totals are meaningful only inside one currency.
        for key in ('budget_amount','charged_amount','remaining_amount','estimated_amount'):
            summary[key] = None
    summary.update({'currency':next(iter(currencies)) if len(currencies)==1 else ('CAD' if not currencies else None),
                    'currencies':{c:{k:round(v,2) for k,v in vals.items()} for c,vals in currencies.items()},
                    'by_month':[by_month[k] for k in sorted(by_month)],'by_lob':list(by_lob.values()),
                    'budget_count':len(items)})
    return summary


@bp.get('')
def list_funding():
    ensure_schema()
    items = [get_budget(row['prn_code']) for row in db.query('SELECT prn_code FROM prn_budget ORDER BY prn_code')]
    return {**listed(items),'summary':_summary(items)}


@bp.get('/summary')
def funding_summary():
    return list_funding()['summary']


@bp.post('')
def post_funding():
    return create_budget(json_body()),201


@bp.get('/<code>')
def funding_detail(code):
    return get_budget(code)


@bp.put('/<code>')
def put_funding(code):
    before = get_budget(code)
    data = json_body()
    if data.get('prn_code') not in (None,code):
        raise errors.validation('The funding code cannot be renamed.',{'prn_code':'Create a separate budget for another funding code.'})
    values,metadata = budget_fields(data,creating=False)
    values.pop('prn_code',None)
    merged = {**before,**values}
    if merged.get('start_month') and merged.get('end_month') and merged['start_month']>merged['end_month']:
        raise errors.validation('Check the funding period.',{'end_month':'End month must be on or after start month.'})
    if 'budget_amount' not in values and ('funded_hours' in values or 'rate' in values):
        values['budget_amount'] = merged['funded_hours']*merged['rate']
    if values.get('budget_amount') is None and 'budget_amount' in values:
        values['budget_amount'] = merged['funded_hours']*merged['rate']
    if before.get('intake_draft') and any(data.get(key) is not None for key in ('funded_hours','budget_amount')):
        metadata['intake_draft'] = False
    with db.transaction():
        db.update('prn_budget',code,values,key='prn_code')
        _write_metadata(code,metadata)
        log_activity('funding',None,'update',{'label':code})
    return get_budget(code)


@bp.delete('/<code>')
def delete_funding(code):
    budget = get_budget(code)
    if budget['initiatives']:
        raise errors.conflict('This budget is linked to initiatives. Remove those funding links before deleting it.',{'initiatives':budget['initiatives']})
    with db.transaction():
        db.execute('DELETE FROM prn_budget WHERE prn_code=?',(code,))
        log_activity('funding',None,'delete',{'label':code})
    return {'ok':True}


@bp.get('/<code>/charges')
def list_charges(code):
    return listed(get_budget(code)['charges'])


@bp.post('/<code>/charges')
def post_charge(code):
    return create_charge(code,json_body()),201


@bp.put('/<code>/charges/<int:cid>')
def put_charge(code,cid):
    budget = get_budget(code)
    before = db.query_one('SELECT * FROM prn_charges WHERE id=? AND prn_code=?',(cid,code))
    if not before:
        raise errors.not_found('Monthly charge',cid)
    values = charge_fields(json_body(),creating=False)
    merged = {**before,**values}
    if db.query_one('SELECT id FROM prn_charges WHERE prn_code=? AND month=? AND id<>?',(code,merged['month'],cid)):
        raise errors.conflict('A charge already exists for this month.')
    if 'charged_hours' in values and 'charged_amount' not in values or values.get('charged_amount') is None and 'charged_amount' in values:
        values['charged_amount'] = merged['charged_hours']*budget['rate']
    with db.transaction():
        db.update('prn_charges',cid,values)
        log_activity('funding_charge',cid,'update',{'label':f'{code} {merged["month"]}'})
    return db.query_one('SELECT * FROM prn_charges WHERE id=?',(cid,))


@bp.delete('/<code>/charges/<int:cid>')
def delete_charge(code,cid):
    if not db.query_one('SELECT id FROM prn_charges WHERE id=? AND prn_code=?',(cid,code)):
        raise errors.not_found('Monthly charge',cid)
    with db.transaction():
        db.execute('DELETE FROM prn_charges WHERE id=?',(cid,))
        log_activity('funding_charge',cid,'delete',{'label':code})
    return {'ok':True}


@bp.get('/<code>/estimates')
def list_estimates(code):
    return listed(get_budget(code)['estimates'])


@bp.post('/<code>/estimates')
def post_estimate(code):
    return create_estimate(code,json_body()),201


@bp.put('/<code>/estimates/<int:eid>')
def put_estimate(code,eid):
    ensure_schema()
    before = db.query_one('SELECT * FROM funding_estimates WHERE id=? AND prn_code=?',(eid,code))
    if not before:
        raise errors.not_found('Funding estimate',eid)
    values = estimate_fields(json_body(),creating=False)
    merged = {**before,**values}
    if not any(merged.get(k) for k in ('appcat','team','sto')):
        raise errors.validation('Identify the component or team for this estimate.',{'appcat':'Enter an AppCat, team or STO.'})
    if 'amount' not in values and ('hours' in values or 'rate' in values):
        values['amount'] = merged['hours']*merged['rate']
    values['updated_at'] = now_iso()
    with db.transaction():
        db.update('funding_estimates',eid,values)
        log_activity('funding_estimate',eid,'update',{'label':code})
    return db.query_one('SELECT * FROM funding_estimates WHERE id=?',(eid,))


@bp.delete('/<code>/estimates/<int:eid>')
def delete_estimate(code,eid):
    ensure_schema()
    if not db.query_one('SELECT id FROM funding_estimates WHERE id=? AND prn_code=?',(eid,code)):
        raise errors.not_found('Funding estimate',eid)
    with db.transaction():
        db.execute('DELETE FROM funding_estimates WHERE id=?',(eid,))
        log_activity('funding_estimate',eid,'delete',{'label':code})
    return {'ok':True}


@bp.put('/<code>/initiatives')
def link_initiatives(code):
    get_budget(code)
    values = json_body().get('initiative_ids')
    if not isinstance(values,list) or any(isinstance(v,bool) or not isinstance(v,int) for v in values):
        raise errors.validation('Choose the initiatives to link.',{'initiative_ids':'Send a list of initiative IDs.'})
    selected = list(dict.fromkeys(values))
    with db.transaction():
        for iid in selected:
            if not db.query_one('SELECT id FROM initiatives WHERE id=?',(iid,)):
                raise errors.validation('An initiative no longer exists.',{'initiative_ids':str(iid)})
        before = [i['id'] for i in db.query('SELECT id FROM initiatives WHERE prn_code=?',(code,))]
        db.execute('UPDATE initiatives SET prn_code=NULL,updated_at=? WHERE prn_code=?',(now_iso(),code))
        for iid in selected:
            db.execute('UPDATE initiatives SET prn_code=?,updated_at=? WHERE id=?',(code,now_iso(),iid))
        for iid in set(before)|set(selected):
            from app import repo
            repo.sync_derived(iid)
        log_activity('funding',None,'update',{'label':code,'initiative_ids':selected})
    return get_budget(code)
