"""SQLite access helpers (FROZEN CONTRACT, owner B0).

Inside a Flask app/request context get_db() returns the per-context connection stored on flask.g.
Outside any context (CLI, seed, engines' callers in scripts, tests) it returns a thread-local
standalone connection to Config.DB_PATH, or the connection installed with use_connection().

Connections run in autocommit mode; group writes with `with transaction():` (nestable via SAVEPOINT).
Rows are plain dicts.
"""
from __future__ import annotations

import itertools
import json
import sqlite3
import threading
from collections.abc import Iterable, Iterator, Sequence
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from app.config import SCHEMA_PATH, load_config

_local = threading.local()


def _dict_factory(cursor: sqlite3.Cursor, row: tuple) -> dict:
    return {col[0]: row[idx] for idx, col in enumerate(cursor.description)}


def connect(path: str | None = None) -> sqlite3.Connection:
    """Open a configured connection (dict rows, FKs on, WAL, autocommit)."""
    db_path = path or load_config().DB_PATH
    if db_path != ":memory:":
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path, isolation_level=None, check_same_thread=False, timeout=10)
    conn.row_factory = _dict_factory
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 5000")
    if db_path != ":memory:":
        conn.execute("PRAGMA journal_mode = WAL")
    return conn


def _flask_g():
    try:
        from flask import g, has_app_context
    except ImportError:  # pragma: no cover
        return None
    return g if has_app_context() else None


def get_db() -> sqlite3.Connection:
    override = getattr(_local, "override", None)
    if override is not None:
        return override
    g = _flask_g()
    if g is not None:
        conn = g.get("_bmo_db")
        if conn is None:
            from flask import current_app
            conn = connect(current_app.config["DB_PATH"])
            g._bmo_db = conn
        return conn
    conn = getattr(_local, "standalone", None)
    if conn is None:
        conn = connect()
        _local.standalone = conn
    return conn


@contextmanager
def use_connection(conn: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    """Temporarily route get_db() (this thread) to `conn` (tests, CLI, seed)."""
    previous = getattr(_local, "override", None)
    _local.override = conn
    try:
        yield conn
    finally:
        _local.override = previous


def close_db(_exc: BaseException | None = None) -> None:
    g = _flask_g()
    if g is not None:
        conn = g.pop("_bmo_db", None)
        if conn is not None:
            conn.close()


def close_standalone() -> None:
    conn = getattr(_local, "standalone", None)
    if conn is not None:
        conn.close()
        _local.standalone = None


def init_app(app) -> None:
    app.teardown_appcontext(close_db)


# ------------------------------------------------------------------ queries
def query(sql: str, params: Sequence[Any] | dict = (), db: sqlite3.Connection | None = None) -> list[dict]:
    return (db or get_db()).execute(sql, params).fetchall()


def query_one(sql: str, params: Sequence[Any] | dict = (), db: sqlite3.Connection | None = None) -> dict | None:
    return (db or get_db()).execute(sql, params).fetchone()


def scalar(sql: str, params: Sequence[Any] | dict = (), db: sqlite3.Connection | None = None) -> Any:
    row = (db or get_db()).execute(sql, params).fetchone()
    return None if row is None else next(iter(row.values()))


def execute(sql: str, params: Sequence[Any] | dict = (), db: sqlite3.Connection | None = None) -> int:
    """Run one statement; returns lastrowid (inserts) or rowcount (updates/deletes when lastrowid is 0)."""
    cur = (db or get_db()).execute(sql, params)
    return cur.lastrowid if cur.lastrowid else cur.rowcount


def executemany(sql: str, rows: Iterable[Sequence[Any] | dict], db: sqlite3.Connection | None = None) -> int:
    return (db or get_db()).executemany(sql, rows).rowcount


def insert(table: str, values: dict, db: sqlite3.Connection | None = None) -> int:
    """INSERT a dict; table/column names must be trusted identifiers (never user input)."""
    cols = list(values)
    sql = f"INSERT INTO {table} ({', '.join(cols)}) VALUES ({', '.join('?' for _ in cols)})"
    return (db or get_db()).execute(sql, [values[c] for c in cols]).lastrowid


def update(table: str, row_id: Any, values: dict, key: str = "id", db: sqlite3.Connection | None = None) -> int:
    """UPDATE by key; table/column names must be trusted identifiers (whitelist them in the caller)."""
    if not values:
        return 0
    sets = ", ".join(f"{c} = ?" for c in values)
    sql = f"UPDATE {table} SET {sets} WHERE {key} = ?"
    return (db or get_db()).execute(sql, [*values.values(), row_id]).rowcount


@contextmanager
def transaction(db: sqlite3.Connection | None = None) -> Iterator[sqlite3.Connection]:
    """Atomic block. Outermost level uses BEGIN IMMEDIATE; nested levels use SAVEPOINTs."""
    conn = db or get_db()
    if not conn.in_transaction:
        conn.execute("BEGIN IMMEDIATE")
        try:
            yield conn
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        else:
            conn.execute("COMMIT")
        return
    name = f"sp_{next(_savepoints)}"
    conn.execute(f"SAVEPOINT {name}")
    try:
        yield conn
    except BaseException:
        conn.execute(f"ROLLBACK TO {name}")
        conn.execute(f"RELEASE {name}")
        raise
    else:
        conn.execute(f"RELEASE {name}")


_savepoints = itertools.count(1)


# ------------------------------------------------------------------ schema & JSON helpers
def init_schema(db: sqlite3.Connection | None = None) -> None:
    (db or get_db()).executescript(SCHEMA_PATH.read_text(encoding="utf-8"))


def table_exists(name: str, db: sqlite3.Connection | None = None) -> bool:
    return query_one("SELECT 1 AS x FROM sqlite_master WHERE type='table' AND name=?", (name,), db) is not None


def db_file_path() -> str:
    try:
        from flask import current_app, has_app_context
        if has_app_context():
            return current_app.config["DB_PATH"]
    except ImportError:  # pragma: no cover
        pass
    return load_config().DB_PATH


def db_ready(db: sqlite3.Connection | None = None) -> bool:
    """True when the schema exists and the database answers. Never creates the database file."""
    if db is None and getattr(_local, "override", None) is None:
        path = db_file_path()
        if path != ":memory:" and not Path(path).exists():
            return False
    try:
        return table_exists("initiatives", db)
    except sqlite3.Error:
        return False


def to_json(value: Any) -> str | None:
    return None if value is None else json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def from_json(text: str | None, default: Any = None) -> Any:
    if text in (None, ""):
        return default
    try:
        return json.loads(text)
    except (TypeError, ValueError):
        return default
