"""Demo clock (FROZEN CONTRACT). The only place that decides "today" and "now".

get_today()  -> date      app_settings.demo_today, else Config.TODAY (env BMO_TODAY, default 2026-10-19)
get_now()    -> datetime  demo_today at Config.DEMO_NOW_TIME (09:30) America/Toronto; engines use this
now_iso()    -> str       audit timestamp: demo date + real wall-clock time (Toronto), ISO 8601 with offset
"""
from __future__ import annotations

import sqlite3
from datetime import date, datetime, time, timedelta, timezone

from app.config import load_config

try:
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
except ImportError:  # pragma: no cover
    ZoneInfo = None
    ZoneInfoNotFoundError = Exception


def _config():
    try:
        from flask import current_app, has_app_context
        if has_app_context():
            return current_app.config
    except ImportError:  # pragma: no cover
        pass
    return load_config().as_flask()


def tz():
    name = _config().get("TIMEZONE", "America/Toronto")
    if ZoneInfo is not None:
        try:
            return ZoneInfo(name)
        except ZoneInfoNotFoundError:
            pass
    return timezone(timedelta(hours=-4), "ET")


def parse_date(value: str | date) -> date:
    return value if isinstance(value, date) else date.fromisoformat(str(value)[:10])


def _setting_today() -> str | None:
    try:
        from app.db import db_ready, query_one
        if not db_ready():
            return None
        row = query_one("SELECT value FROM app_settings WHERE key = 'demo_today'")
    except (sqlite3.Error, RuntimeError):
        return None
    return row["value"] if row and row.get("value") else None


def get_today() -> date:
    override = _setting_today()
    if override:
        try:
            return parse_date(override)
        except ValueError:
            pass
    return parse_date(_config().get("TODAY", "2026-10-19"))


def get_now() -> datetime:
    hh, mm = (int(x) for x in str(_config().get("DEMO_NOW_TIME", "09:30")).split(":")[:2])
    return datetime.combine(get_today(), time(hh, mm), tzinfo=tz())


def now_iso() -> str:
    wall = datetime.now(tz())
    stamp = datetime.combine(get_today(), wall.timetz().replace(microsecond=0))
    return stamp.isoformat()


def today_iso() -> str:
    return get_today().isoformat()
