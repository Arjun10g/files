"""JSON errors (FROZEN CONTRACT). Every error leaves the server as {"error": {code, message, details}} - never HTML.

Codes: bad_request 400 · validation 422 · not_found 404 · method_not_allowed 405 · conflict 409 ·
payload_too_large 413 · unreadable_file 422 · ai_error 502 · internal 500.
Messages are user-facing (sentence case, business language).
"""
from __future__ import annotations

import logging
import sqlite3

from flask import jsonify
from werkzeug.exceptions import HTTPException

log = logging.getLogger("bmo.errors")

_HTTP_CODES = {
    400: ("bad_request", "The request could not be read."),
    404: ("not_found", "That item could not be found."),
    405: ("method_not_allowed", "That action is not available here."),
    409: ("conflict", "That change conflicts with existing data."),
    413: ("payload_too_large", "The file is larger than 10 MB. Attach a smaller file."),
    415: ("bad_request", "Send the request as JSON."),
    422: ("validation", "Some fields need attention."),
    500: ("internal", "Something went wrong. Try again, or reset the demo from Settings."),
}


class ApiError(Exception):
    def __init__(self, code: str, message: str, status: int = 400, details: dict | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status
        self.details = details or {}

    def to_dict(self) -> dict:
        return {"error": {"code": self.code, "message": self.message, "details": self.details}}


def not_found(entity: str, ident=None) -> ApiError:
    label = f"{entity} {ident}" if ident is not None else entity
    return ApiError("not_found", f"{label} was not found.", 404, {"entity": entity, "id": ident})


def validation(message: str, fields: dict | None = None) -> ApiError:
    """fields: {field_name: 'what is wrong'}"""
    return ApiError("validation", message, 422, {"fields": fields or {}})


def conflict(message: str, details: dict | None = None) -> ApiError:
    return ApiError("conflict", message, 409, details)


def unreadable_file(message: str = "We could not read that file. Paste the text instead.") -> ApiError:
    return ApiError("unreadable_file", message, 422, {"fallback": "paste_text"})


def error_response(code: str, message: str, status: int, details: dict | None = None):
    return jsonify({"error": {"code": code, "message": message, "details": details or {}}}), status


def register_error_handlers(app) -> None:
    @app.errorhandler(ApiError)
    def _api_error(err: ApiError):
        return jsonify(err.to_dict()), err.status

    @app.errorhandler(HTTPException)
    def _http_error(err: HTTPException):
        status = err.code or 500
        code, default_message = _HTTP_CODES.get(status, ("bad_request" if status < 500 else "internal", err.name))
        message = default_message
        if status in (400, 422) and err.description and "browser (or proxy)" not in err.description:
            message = err.description
        return error_response(code, message, status)

    @app.errorhandler(sqlite3.IntegrityError)
    def _integrity_error(err: sqlite3.IntegrityError):
        text = str(err)
        if "UNIQUE" in text:
            return error_response("conflict", "That value already exists.", 409, {"db": text})
        if "CHECK" in text:
            return error_response("validation", "One of the values is not in the allowed list.", 422, {"db": text})
        if "FOREIGN KEY" in text:
            return error_response("validation", "A linked item does not exist.", 422, {"db": text})
        return error_response("validation", "That change could not be saved.", 422, {"db": text})

    @app.errorhandler(Exception)
    def _unhandled(err: Exception):
        log.exception("Unhandled error: %s", err)
        code, message = _HTTP_CODES[500]
        return error_response(code, message, 500)
