"""Command line: python -m app.cli init-if-missing | reset | seed | run

Extra commands are registered by app.ai.cli_ext (B3) when present: it exposes register(subparsers) and each command
it adds sets `func` through set_defaults(func=callable(args)).
"""
from __future__ import annotations

import argparse
import importlib
import socket
import sys
import time

from app import create_app, db


def _app():
    return create_app()


def _print_counts(counts: dict) -> None:
    keys = ("initiatives", "resources", "dc_components", "wbs_tasks", "allocations", "change_requests", "risks",
            "notifications")
    print("Seeded: " + ", ".join(f"{k} {counts[k]}" for k in keys if k in counts))


def cmd_reset(_args) -> int:
    from app.seed.seed import reset_database

    app = _app()
    started = time.perf_counter()
    with app.app_context():
        counts = reset_database(db.get_db(), upload_dir=app.config["UPLOAD_DIR"], today=app.config["TODAY"],
                                ai_mode=app.config["AI_MODE"])
    _print_counts(counts)
    print(f"Demo data reset in {time.perf_counter() - started:.2f} s ({app.config['DB_PATH']}).")
    return 0


def cmd_seed(args) -> int:
    return cmd_reset(args)


def cmd_init_if_missing(args) -> int:
    import os
    from datetime import datetime
    from zoneinfo import ZoneInfo

    from app.workspace import initialize_empty

    app = _app()
    with app.app_context():
        ready = db.db_ready()
        if not ready:
            today = os.environ.get("BMO_TODAY") or datetime.now(ZoneInfo("America/Toronto")).date().isoformat()
            initialize_empty(db.get_db(), today=today)
    print(f"Portal database ready ({app.config['DB_PATH']}).")
    return 0


def port_in_use(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.bind((host, port))
        except OSError:
            return True
    return False


def cmd_run(args) -> int:
    app = _app()
    host = app.config["HOST"]
    port = args.port or app.config["PORT"]
    if port_in_use(host, port):
        print(f"Port {port} is already in use. Stop the other server (or run with BMO_PORT=<free port>) and try again.",
              file=sys.stderr)
        return 1
    print(f"BMO DC Project Management Tool running at http://{host}:{port}/  (Ctrl+C to stop)", flush=True)
    app.run(host=host, port=port, debug=False, threaded=True, use_reloader=False)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m app.cli", description="BMO DC Project Management Tool")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("init-if-missing", help="create an empty portal with reference catalogues if missing").set_defaults(
        func=cmd_init_if_missing)
    sub.add_parser("reset", help="drop everything and reload the demo seed").set_defaults(func=cmd_reset)
    sub.add_parser("seed", help="reload the demo seed (same as reset)").set_defaults(func=cmd_seed)
    run = sub.add_parser("run", help="serve the app on 127.0.0.1:BMO_PORT (default 5055)")
    run.add_argument("--port", type=int, default=None)
    run.set_defaults(func=cmd_run)
    try:
        ext = importlib.import_module("app.ai.cli_ext")
    except ModuleNotFoundError as exc:
        if exc.name not in ("app.ai.cli_ext", "app.ai"):
            raise
        ext = None
    if ext is not None and callable(getattr(ext, "register", None)):
        ext.register(sub)
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.func(args) or 0)


if __name__ == "__main__":
    sys.exit(main())
