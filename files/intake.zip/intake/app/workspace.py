"""Create an empty operational workspace with reference catalogues only."""
from __future__ import annotations

import json
from pathlib import Path

from app import db
from app.config import SEED_DIR


def initialize_empty(conn, *, today: str, ai_mode: str = "simulated") -> None:
    if db.table_exists("initiatives", conn):
        return
    db.init_schema(conn)
    lookups = json.loads((SEED_DIR / "lookups.json").read_text())
    catalogue = json.loads((SEED_DIR / "components.json").read_text())["components"]
    governance = json.loads((SEED_DIR / "governance.json").read_text())
    with db.transaction(conn):
        for category, items in lookups["categories"].items():
            for index, item in enumerate(items):
                db.insert("lookups", {"category": category, "value": str(item["value"]), "label": item["label"], "sort": index}, conn)
        for holiday in lookups["holidays"]:
            db.insert("lookups", {"category": "holiday", "value": holiday["date"], "label": holiday["name"]}, conn)
        for bound, value in lookups["change_freeze"].items():
            db.insert("lookups", {"category": "change_freeze", "value": value, "label": bound}, conn)
        for key, value in {"ai_mode": ai_mode, "ai_speed": "Fast", "demo_today": today,
                           "persona": "DC PM", "rddc_next": "10001", "workspace_mode": "portal"}.items():
            db.insert("app_settings", {"key": key, "value": value}, conn)
        for component in catalogue:
            values = {k: component[k] for k in ("id", "code", "name", "team", "ci_name", "base_hours_low", "base_hours_medium", "base_hours_high", "description")}
            values["keywords"] = db.to_json(component["keywords"])
            db.insert("dc_components", values, conn)
        ids = {c["code"]: c["id"] for c in catalogue}
        for component in catalogue:
            for downstream in component["downstream"]:
                db.insert("component_dependencies", {"from_component_id": component["id"], "to_component_id": ids[downstream], "kind": "downstream"}, conn)
        for train in governance["release_trains"]:
            db.insert("release_trains", train, conn)
        skills = json.loads((SEED_DIR / "resources.json").read_text())["skills"]
        for skill in skills:
            db.insert("skills", skill, conn)


def session_secret(database_path: str) -> str:
    import os
    import secrets

    explicit = os.environ.get("BMO_SESSION_SECRET")
    if explicit:
        return explicit
    if database_path == ":memory:":
        return secrets.token_hex(32)
    path = Path(database_path).parent / ".portal-session-secret"
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with open(path, "x", opener=lambda p, flags: os.open(p, flags, 0o600)) as handle:
            handle.write(secrets.token_hex(32))
    except FileExistsError:
        pass
    return path.read_text().strip()
