"""Read models (owner B1): the initiative bundle, initiative lists, resource calendars, plus the guarded hooks
that CRUD writes use to trigger derived-data recalculation (app.services.derive, owned by B2).

JSON-ish TEXT columns come back parsed (docs/contracts.md §0).
"""
from __future__ import annotations

import importlib
from collections import defaultdict

from app import db, errors
from app.today import get_now, get_today

LIST_FIELDS = {"labels", "keywords", "affected_cis", "impacted_components", "cc_names", "attendees", "tags",
               "components", "action_items_json", "sa_missing_json", "recipients_json", "sources_json",
               "warnings_json"}
DICT_FIELDS = {"rag_overrides_json"}

# Hidden pseudo-initiatives (id < 0, e.g. BAU-FY27 "Run & maintain") carry capacity-only demand. Every list,
# KPI and search must exclude them: add VISIBLE_INITIATIVES.format(a="<alias>") to the WHERE clause.
VISIBLE_INITIATIVES = "{a}.id > 0"

PERSON_COLUMNS = (("requestor_id", "requestor_name"), ("assigned_to_id", "assigned_to_name"), ("pm_id", "pm_name"),
                  ("tech_lead_id", "tech_lead_name"), ("dc_pm_id", "dc_pm_name"), ("dc_sa_id", "dc_sa_name"))


# ------------------------------------------------------------------ optional modules (parallel builders)
def optional_module(name: str):
    """Import `name` if it exists; None when the module (or its package) is not there yet."""
    try:
        return importlib.import_module(name)
    except ModuleNotFoundError as exc:
        parts = name.split(".")
        if exc.name in {".".join(parts[:i]) for i in range(1, len(parts) + 1)}:
            return None
        raise


def sync_derived(initiative_id: int, *, allocations: bool = False, reminders: bool = False) -> dict | None:
    """Recalculate derived data after a CRUD write. Call inside the caller's db.transaction().

    allocations=True rebuilds the plan allocations (task writes); reminders=True queues any reminder that is now due
    (create, SA upload, component approval changes); health is always refreshed.
    Returns the Health payload, or None when the derive service is not installed.
    """
    derive = optional_module("app.services.derive")
    if derive is None:
        return None
    if allocations:
        derive.rebuild_allocations(initiative_id)
    if reminders and hasattr(derive, "run_reminders"):
        derive.run_reminders(None)
    return derive.refresh_health(initiative_id)


# ------------------------------------------------------------------ row helpers
def parse_row(row: dict | None) -> dict | None:
    """Parse JSON-ish TEXT columns in place (contracts §0)."""
    if row is None:
        return None
    for key, value in list(row.items()):
        if key in DICT_FIELDS:
            row[key] = db.from_json(value, {}) if isinstance(value, str) or value is None else value
        elif key in LIST_FIELDS:
            if value is None and key == "sa_missing_json":
                continue
            row[key] = db.from_json(value, []) if isinstance(value, str) or value is None else value
        elif key.endswith("_json") and (isinstance(value, str)):
            row[key] = db.from_json(value, None)
    return row


def parse_rows(rows: list[dict]) -> list[dict]:
    return [parse_row(r) for r in rows]


def require(table: str, row_id, entity: str) -> dict:
    """Fetch one row by id or raise 404. `table` is a trusted identifier."""
    row = db.query_one(f"SELECT * FROM {table} WHERE id = ?", (row_id,))
    if row is None:
        raise errors.not_found(entity, row_id)
    return row


def setting(key: str, default=None):
    row = db.query_one("SELECT value FROM app_settings WHERE key = ?", (key,))
    return row["value"] if row and row["value"] not in (None, "") else default


def resource_name(resource_id) -> str | None:
    if not resource_id:
        return None
    row = db.query_one("SELECT name FROM resources WHERE id = ?", (resource_id,))
    return row["name"] if row else None


# ------------------------------------------------------------------ initiatives
_INITIATIVE_SELECT = (
    "SELECT i.*, rq.name AS requestor_name, a.name AS assigned_to_name, pm.name AS pm_name, "
    "tl.name AS tech_lead_name, dpm.name AS dc_pm_name, dsa.name AS dc_sa_name "
    "FROM initiatives i "
    "LEFT JOIN resources rq ON rq.id = i.requestor_id LEFT JOIN resources a ON a.id = i.assigned_to_id "
    "LEFT JOIN resources pm ON pm.id = i.pm_id LEFT JOIN resources tl ON tl.id = i.tech_lead_id "
    "LEFT JOIN resources dpm ON dpm.id = i.dc_pm_id LEFT JOIN resources dsa ON dsa.id = i.dc_sa_id ")


def get_initiative(initiative_id) -> dict:
    """One initiative row with *_name joins and parsed JSON columns. Raises 404."""
    row = db.query_one(_INITIATIVE_SELECT + "WHERE i.id = ?", (initiative_id,))
    if row is None:
        raise errors.not_found("Initiative", initiative_id)
    if row.get("requestor_name") is None and row.get("requestor"):
        row["requestor_name"] = row["requestor"]
    lead = delivery_lead()
    row["dlr_shared_at"] = row.get("l2_submitted_at")
    row["dlr_id"] = lead["id"] if lead else None
    row["dlr_name"] = lead["name"] if lead else None
    return parse_row(row)


def delivery_lead() -> dict | None:
    """The Delivery Lead who runs the DLR (Delivery Lead Review) of L2 estimates."""
    return db.query_one("SELECT id, name FROM resources WHERE role = 'Delivery Lead' AND active = 1 ORDER BY id LIMIT 1")


def _join_names(items: list[str]) -> str:
    items = [i.lower() for i in items]
    return items[0] if len(items) == 1 else ", ".join(items[:-1]) + " and " + items[-1]


def action_required_for(initiative_id) -> dict | None:
    """action_required for one initiative id (used by the workbook export and other read paths)."""
    return action_required(get_initiative(initiative_id), list_components(initiative_id))


def action_required(ini: dict, components: list[dict]) -> dict | None:
    """Who the initiative is waiting on next, by when and for what: {owner_id, owner_name, due, what} or None.

    Same precedence as the reminder rules: L2 approval, then the SA document, then component approvals. `due` is the
    next reminder date from engines.reminders (every 3 / 2 / 2 business days).
    """
    rem = optional_module("app.engines.reminders")
    if rem is None or ini.get("stage") == "Closed":
        return None
    today = get_today()
    rules = rem.RULES
    if ini.get("l2_status") == "Pending approval" and ini.get("l2_submitted_at"):
        due = rem.next_reminder(ini["l2_submitted_at"], rules["l2_every_bd"], today)
        return {"owner_id": ini.get("requestor_id"), "owner_name": ini.get("requestor_name") or ini.get("requestor"),
                "due": due.isoformat(), "what": f"Approve the L2 estimate ({ini.get('l2_hours') or 0:,.0f} h)"}
    sa = ini.get("sa_completeness")
    # The SA action stays until a re-uploaded SA document has every section, whatever the stage (round 3, N3).
    sa_open = (sa is None or sa < 100) and (ini.get("sa_doc_attachment_id") or ini.get("stage") in rules["sa_waiting_stages"])
    if ini.get("dc_sa_id") and sa_open:
        since = ini.get("created_at")
        if ini.get("sa_doc_attachment_id"):
            since = db.scalar("SELECT uploaded_at FROM attachments WHERE id = ?", (ini["sa_doc_attachment_id"],)) or since
        due = rem.next_reminder(since or today, rules["sa_every_bd"], today)
        missing = ini.get("sa_missing_json") or []
        if not ini.get("sa_doc_attachment_id"):
            what = "Attach the SA document"
        elif missing:
            what = f"Add the {_join_names(missing)} section{'s' if len(missing) > 1 else ''} to the SA document"
        else:
            what = "Complete the SA document"
        return {"owner_id": ini.get("dc_sa_id"), "owner_name": ini.get("dc_sa_name"), "due": due.isoformat(), "what": what}
    pending = [c for c in components if c.get("approval") == "Pending" and c.get("component_lead_id")]
    if pending and ini.get("stage") in rules["pre_planning_stages"]:
        since = ini.get("l2_submitted_at") or ini.get("created_at") or today
        due = rem.next_reminder(since, rules["approval_every_bd"], today)
        c = pending[0]
        return {"owner_id": c["component_lead_id"], "owner_name": c.get("component_lead_name"), "due": due.isoformat(),
                "what": f"Approve the {c['name']} change summary"}
    return None


def _in_clause(column: str, raw, params: list) -> str:
    values = [v.strip() for v in str(raw).split(",") if v.strip()]
    if not values:
        return ""
    params.extend(values)
    return f"{column} IN ({', '.join('?' for _ in values)})"


def _like(text: str) -> str:
    escaped = text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


def list_initiatives(filters: dict | None = None) -> list[dict]:
    """Search Initiative rows. filters: q, stage, lob, status, rag, dc_pm_id, release (comma lists allowed)."""
    filters = filters or {}
    where, params = [VISIBLE_INITIATIVES.format(a="i")], []
    q = (filters.get("q") or "").strip()
    if q:
        like = _like(q)
        where.append("(i.rddc LIKE ? ESCAPE '\\' OR i.name LIKE ? ESCAPE '\\' OR i.description LIKE ? ESCAPE '\\' "
                     "OR i.requestor LIKE ? ESCAPE '\\' OR i.labels LIKE ? ESCAPE '\\' OR i.dc_intake LIKE ? ESCAPE '\\' "
                     "OR dpm.name LIKE ? ESCAPE '\\')")
        params.extend([like] * 7)
    for key, column in (("stage", "i.stage"), ("lob", "i.lob"), ("status", "i.status"),
                        ("release", "i.target_release"), ("dc_pm_id", "i.dc_pm_id"), ("priority", "i.priority")):
        if filters.get(key) not in (None, ""):
            clause = _in_clause(column, filters[key], params)
            if clause:
                where.append(clause)
    rag = filters.get("rag")
    if rag not in (None, ""):
        values = [v.strip() for v in str(rag).split(",") if v.strip()]
        parts = []
        scored = [v for v in values if v in ("Red", "Amber", "Green")]
        if scored:
            parts.append(f"i.rag_cached IN ({', '.join('?' for _ in scored)})")
            params.extend(scored)
        if any(v.lower() in ("none", "not scored", "unscored") for v in values):
            parts.append("i.rag_cached IS NULL")
        where.append("(" + (" OR ".join(parts) if parts else "0") + ")")
    sql = (
        "SELECT i.id, i.rddc, i.name, i.lob, i.stage, i.status, i.priority, i.dc_intake, i.requestor, i.labels, "
        "i.dc_pm_id, dpm.name AS dc_pm_name, i.dc_sa_id, dsa.name AS dc_sa_name, i.rag_cached AS rag, "
        "i.target_release, i.requested_go_live, i.readiness_date, i.prod_date, i.planned_start, i.planned_end, "
        "i.sa_completeness, i.l2_status, i.l2_hours, i.created_at, i.updated_at "
        "FROM initiatives i LEFT JOIN resources dpm ON dpm.id = i.dc_pm_id LEFT JOIN resources dsa ON dsa.id = i.dc_sa_id "
        + ("WHERE " + " AND ".join(where) + " " if where else "")
        + "ORDER BY i.rddc DESC")
    return parse_rows(db.query(sql, params))


# ------------------------------------------------------------------ components and tasks
def list_components(initiative_id) -> list[dict]:
    return db.query(
        "SELECT ic.*, c.code, c.name, c.team, c.ci_name, r.name AS component_lead_name "
        "FROM initiative_components ic JOIN dc_components c ON c.id = ic.component_id "
        "LEFT JOIN resources r ON r.id = ic.component_lead_id WHERE ic.initiative_id = ? ORDER BY ic.sort, ic.id",
        (initiative_id,))


def get_component(icid) -> dict:
    row = db.query_one(
        "SELECT ic.*, c.code, c.name, c.team, c.ci_name, r.name AS component_lead_name "
        "FROM initiative_components ic JOIN dc_components c ON c.id = ic.component_id "
        "LEFT JOIN resources r ON r.id = ic.component_lead_id WHERE ic.id = ?", (icid,))
    if row is None:
        raise errors.not_found("DC component row", icid)
    return row


_TASK_SELECT = (
    "SELECT t.*, o.name AS owner_name, r.name AS resource_name, c.code AS component_code "
    "FROM wbs_tasks t LEFT JOIN resources o ON o.id = t.owner_id LEFT JOIN resources r ON r.id = t.resource_id "
    "LEFT JOIN initiative_components ic ON ic.id = t.initiative_component_id "
    "LEFT JOIN dc_components c ON c.id = ic.component_id ")


def _attach_deps(tasks: list[dict]) -> list[dict]:
    if not tasks:
        return tasks
    ids = [t["id"] for t in tasks]
    deps = db.query(
        f"SELECT d.task_id, d.depends_on_task_id, t.wbs_code FROM wbs_dependencies d "
        f"JOIN wbs_tasks t ON t.id = d.depends_on_task_id WHERE d.task_id IN ({', '.join('?' for _ in ids)}) "
        f"ORDER BY t.sort, t.id", ids)
    by_task: dict[int, list] = defaultdict(list)
    for d in deps:
        by_task[d["task_id"]].append(d)
    for t in tasks:
        t["depends_on"] = [d["depends_on_task_id"] for d in by_task.get(t["id"], [])]
        t["depends_on_codes"] = [d["wbs_code"] for d in by_task.get(t["id"], [])]
    return tasks


def list_tasks(initiative_id) -> list[dict]:
    return _attach_deps(db.query(_TASK_SELECT + "WHERE t.initiative_id = ? ORDER BY t.sort, t.id", (initiative_id,)))


def get_task(task_id) -> dict:
    row = db.query_one(_TASK_SELECT + "WHERE t.id = ?", (task_id,))
    if row is None:
        raise errors.not_found("WBS step", task_id)
    return _attach_deps([row])[0]


# ------------------------------------------------------------------ change requests
_CR_SELECT = (
    "SELECT cr.*, i.rddc, i.name AS initiative_name, cms.name AS cms_lead_name, rel.name AS rel_lead_name, "
    "res.name AS resource_name FROM change_requests cr JOIN initiatives i ON i.id = cr.initiative_id "
    "LEFT JOIN resources cms ON cms.id = cr.cms_lead_id LEFT JOIN resources rel ON rel.id = cr.rel_lead_id "
    "LEFT JOIN resources res ON res.id = cr.resource_id ")


def compliance_for(cr: dict) -> dict:
    """Live compliance from derive.compliance_for / engines.compliance (B2), plus the saved AI review (compliance_json.ai, written by B3's
    apply) as `ai` when there is one. Falls back to the cached result when the engine is not installed."""
    cached = cr.get("compliance_json")
    cached = db.from_json(cached, None) if isinstance(cached, str) else cached
    derive = optional_module("app.services.derive")
    engine = optional_module("app.engines.compliance")
    if engine is None and (derive is None or not hasattr(derive, "compliance_for")):
        return dict(cached) if isinstance(cached, dict) else {"ok": True, "flags": []}
    row = dict(cr)
    for key in ("affected_cis", "impacted_components"):
        if isinstance(row.get(key), str):
            row[key] = db.from_json(row[key], [])
    if derive is not None and hasattr(derive, "compliance_for") and (engine is None or row.get("release_type") != "Independent"):
        # Release CRQs are checked against the plan too (CR-12 window = WBS-700 date, CR-13 production vs target).
        result = dict(derive.compliance_for(row))
    else:
        # Independent changes (pre-staging, config) are not the production release, so plan alignment does not apply.
        result = dict(engine.check_cr(row, get_today(), {"now": get_now().isoformat()}))
    if isinstance(cached, dict) and cached.get("ai"):
        result["ai"] = cached["ai"]
    return result


def cache_compliance(cid: int) -> None:
    """Store the live compliance result on the CRQ, keeping the AI review block (`ai`) written by B3's apply."""
    cr = db.query_one("SELECT * FROM change_requests WHERE id = ?", (cid,))
    if cr is None:
        return
    cached = db.from_json(cr.get("compliance_json"), None) or {}
    result = {k: v for k, v in compliance_for(cr).items() if k != "ai"}
    if isinstance(cached, dict) and cached.get("ai"):
        result["ai"] = cached["ai"]
    db.execute("UPDATE change_requests SET compliance_json = ? WHERE id = ?", (db.to_json(result), cid))


def list_change_requests(where: str = "", params: tuple | list = ()) -> list[dict]:
    """`where` is a trusted SQL fragment written in this codebase (values go through params).

    `compliance` is computed live; the saved AI review (compliance_json.ai) rides along as `compliance.ai`, and the
    cached `compliance_json` is returned parsed as well.
    """
    rows = db.query(_CR_SELECT + where + " ORDER BY cr.crq_start, cr.id", params)
    out = []
    for r in rows:
        r["compliance"] = compliance_for(r)
        r["compliance_json"] = db.from_json(r.get("compliance_json"), None) if isinstance(r.get("compliance_json"), str) \
            else r.get("compliance_json")
        out.append(parse_row(r))
    return out


def get_change_request(cid) -> dict:
    rows = list_change_requests("WHERE cr.id = ?", (cid,))
    if not rows:
        raise errors.not_found("Change request", cid)
    return rows[0]


# ------------------------------------------------------------------ resources and calendars
def resource_skills(resource_ids: list[int] | None = None) -> dict[int, list]:
    sql = ("SELECT rs.resource_id, s.name AS skill, rs.level, rs.source, rs.evidence FROM resource_skills rs "
           "JOIN skills s ON s.id = rs.skill_id ")
    params: list = []
    if resource_ids is not None:
        if not resource_ids:
            return {}
        sql += f"WHERE rs.resource_id IN ({', '.join('?' for _ in resource_ids)}) "
        params = list(resource_ids)
    out: dict[int, list] = defaultdict(list)
    for r in db.query(sql + "ORDER BY rs.rowid", params):
        out[r["resource_id"]].append(r)
    return out


def availability_map(resource_ids: list[int], months: list[str] | None = None) -> dict[int, dict]:
    if not resource_ids:
        return {}
    sql = (f"SELECT resource_id, month, available_hours FROM resource_availability "
           f"WHERE resource_id IN ({', '.join('?' for _ in resource_ids)}) ")
    params: list = list(resource_ids)
    if months:
        sql += f"AND month IN ({', '.join('?' for _ in months)}) "
        params += months
    out: dict[int, dict] = defaultdict(dict)
    for r in db.query(sql + "ORDER BY month", params):
        out[r["resource_id"]][r["month"]] = float(r["available_hours"])
    return out


def committed_map(resource_ids: list[int], months: list[str] | None = None) -> dict[int, dict]:
    """Allocated hours per resource and month across ALL initiatives (confirmed + tentative)."""
    if not resource_ids:
        return {}
    sql = (f"SELECT resource_id, month, SUM(hours) AS hours FROM allocations "
           f"WHERE resource_id IN ({', '.join('?' for _ in resource_ids)}) ")
    params: list = list(resource_ids)
    if months:
        sql += f"AND month IN ({', '.join('?' for _ in months)}) "
        params += months
    out: dict[int, dict] = defaultdict(dict)
    for r in db.query(sql + "GROUP BY resource_id, month ORDER BY month", params):
        out[r["resource_id"]][r["month"]] = round(float(r["hours"]), 2)
    return out


def month_span(first: str, last: str) -> list[str]:
    y, m = int(first[:4]), int(first[5:7])
    ly, lm = int(last[:4]), int(last[5:7])
    out = []
    while (y, m) <= (ly, lm):
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m > 12:
            y, m = y + 1, 1
    return out


def shift_month(month: str, n: int) -> str:
    y, m = int(month[:4]), int(month[5:7]) - 1 + n
    return f"{y + m // 12:04d}-{m % 12 + 1:02d}"


def resource_calendar(resource_id, from_month: str | None = None, to_month: str | None = None) -> dict:
    """One person's month-by-month view: availability, allocated hours and the initiatives behind them."""
    res = require("resources", resource_id, "Resource")
    today_month = get_today().isoformat()[:7]
    first = from_month or today_month
    last = to_month or shift_month(first, 11)
    months = month_span(first, last)
    avail = availability_map([res["id"]], months).get(res["id"], {})
    rows = db.query(
        "SELECT a.month, a.hours, a.firmness, i.id AS initiative_id, i.rddc, i.name FROM allocations a "
        "JOIN initiatives i ON i.id = a.initiative_id WHERE a.resource_id = ? AND a.month BETWEEN ? AND ? "
        "ORDER BY a.month, i.rddc", (res["id"], first, last))
    cells = []
    for m in months:
        items = [r for r in rows if r["month"] == m]
        by_init: dict[int, dict] = {}
        for r in items:
            entry = by_init.setdefault(r["initiative_id"], {"initiative_id": r["initiative_id"], "rddc": r["rddc"],
                                                            "name": r["name"], "confirmed": 0.0, "tentative": 0.0})
            entry[r["firmness"]] = round(entry[r["firmness"]] + float(r["hours"]), 2)
        allocated = round(sum(float(r["hours"]) for r in items), 2)
        available = avail.get(m)
        cells.append({"month": m, "available": available, "allocated": allocated,
                      "util": (allocated / available) if available else None,
                      "initiatives": list(by_init.values())})
    return {"resource_id": res["id"], "name": res["name"], "months": cells}


# ------------------------------------------------------------------ bundle
def _window_months(ini: dict, tasks: list[dict]) -> list[str]:
    starts = [t["planned_start"] for t in tasks if t.get("planned_start")]
    ends = [t["planned_end"] for t in tasks if t.get("planned_end")]
    if ini.get("planned_start"):
        starts.append(ini["planned_start"])
    if ini.get("planned_end"):
        ends.append(ini["planned_end"])
    today_month = get_today().isoformat()[:7]
    if starts and ends:
        first, last = min(starts)[:7], max(ends)[:7]
    else:
        first = today_month
        last = (ini.get("requested_go_live") or "")[:7] or shift_month(today_month, 5)
        if last < first:
            last = shift_month(first, 5)
    return month_span(shift_month(first, -1), shift_month(last, 1))


def _bundle_resources(ini: dict, tasks: list[dict], components: list[dict], allocations: list[dict],
                      months: list[str]) -> list[dict]:
    referenced = {ini.get(col) for col, _ in PERSON_COLUMNS}
    referenced |= {t.get("owner_id") for t in tasks} | {t.get("resource_id") for t in tasks}
    referenced |= {c.get("component_lead_id") for c in components} | {a["resource_id"] for a in allocations}
    referenced.discard(None)
    rows = db.query(
        "SELECT id, name, role, team, team_label, component_id, capacity_eligible, default_monthly_hours "
        "FROM resources WHERE active = 1 ORDER BY id")
    rows = [r for r in rows if r["capacity_eligible"] or r["id"] in referenced]
    tracked = [r["id"] for r in rows if r["capacity_eligible"]]
    avail = availability_map(tracked, months)
    committed = committed_map(tracked, months)
    skills = resource_skills([r["id"] for r in rows])
    out = []
    for r in rows:
        r["default_monthly_hours"] = float(r["default_monthly_hours"] or 0)
        r["availability"] = avail.get(r["id"], {}) if r["capacity_eligible"] else {}
        r["committed"] = committed.get(r["id"], {}) if r["capacity_eligible"] else {}
        r["skills"] = [{"skill": s["skill"], "level": s["level"]} for s in skills.get(r["id"], [])]
        out.append(r)
    return out


def list_attachments(initiative_id) -> list[dict]:
    return db.query(
        "SELECT id, initiative_id, entity_type, entity_id, kind, filename, stored_path, mime, size_bytes, version, "
        "uploaded_by, uploaded_at, LENGTH(extracted_text) AS extracted_chars FROM attachments "
        "WHERE initiative_id = ? ORDER BY uploaded_at, id", (initiative_id,))


def component_catalog() -> list[dict]:
    comps = db.query("SELECT * FROM dc_components ORDER BY id")
    deps = db.query(
        "SELECT d.from_component_id, c.code FROM component_dependencies d JOIN dc_components c "
        "ON c.id = d.to_component_id ORDER BY c.id")
    down: dict[int, list] = defaultdict(list)
    for d in deps:
        down[d["from_component_id"]].append(d["code"])
    for c in comps:
        c["keywords"] = db.from_json(c.get("keywords"), [])
        c["downstream"] = down.get(c["id"], [])
    return comps


def grooming_for(initiative_id) -> dict | None:
    today = get_today().isoformat()
    row = db.query_one(
        "SELECT g.id AS session_id, g.session_date, g.start_time, s.status FROM grooming_slots s "
        "JOIN grooming_sessions g ON g.id = s.session_id WHERE s.initiative_id = ? AND g.session_date >= ? "
        "ORDER BY g.session_date, g.start_time LIMIT 1", (initiative_id, today))
    if row is None:
        row = db.query_one(
            "SELECT g.id AS session_id, g.session_date, g.start_time, s.status FROM grooming_slots s "
            "JOIN grooming_sessions g ON g.id = s.session_id WHERE s.initiative_id = ? "
            "ORDER BY g.session_date DESC LIMIT 1", (initiative_id,))
    return row


def scope_changes(initiative_id) -> list[dict]:
    rows = db.query(
        "SELECT ts, detail_json FROM activity_log WHERE initiative_id = ? AND action = 'scope_change' ORDER BY id",
        (initiative_id,))
    out = []
    for r in rows:
        detail = db.from_json(r["detail_json"], {}) or {}
        out.append({"ts": r["ts"], "action": detail.get("change"), "component_code": detail.get("component_code"),
                    "detail": detail.get("text")})
    return out


def list_risks(where: str = "", params: tuple | list = ()) -> list[dict]:
    """`where` is a trusted SQL fragment written in this codebase."""
    return db.query(
        "SELECT rk.*, i.rddc, i.name AS initiative_name, o.name AS owner_name, t.wbs_code FROM risks rk "
        "JOIN initiatives i ON i.id = rk.initiative_id LEFT JOIN resources o ON o.id = rk.owner_id "
        "LEFT JOIN wbs_tasks t ON t.id = rk.task_id " + where + " ORDER BY rk.score DESC, rk.id", params)


def get_prn(prn_code) -> dict | None:
    if not prn_code:
        return None
    prn = db.query_one("SELECT * FROM prn_budget WHERE prn_code = ?", (prn_code,))
    if prn is None:
        return None
    prn["charges"] = db.query(
        "SELECT month, charged_hours, charged_amount FROM prn_charges WHERE prn_code = ? ORDER BY month",
        (prn_code,))
    return prn


def get_initiative_bundle(initiative_id) -> dict:
    """Everything engines and the AI layer need about one initiative (docs/contracts.md §3)."""
    ini = get_initiative(initiative_id)
    components = list_components(initiative_id)
    tasks = list_tasks(initiative_id)
    allocations = db.query(
        "SELECT a.resource_id, a.task_id, a.month, a.hours, a.firmness FROM allocations a "
        "LEFT JOIN wbs_tasks t ON t.id = a.task_id WHERE a.initiative_id = ? "
        "ORDER BY COALESCE(t.sort, 999999), a.task_id, a.month, a.resource_id", (initiative_id,))
    months = _window_months(ini, tasks)
    resources = _bundle_resources(ini, tasks, components, allocations, months)
    risks = list_risks("WHERE rk.initiative_id = ?", (initiative_id,))
    crs = list_change_requests("WHERE cr.initiative_id = ?", (initiative_id,))
    attachments = list_attachments(initiative_id)
    for a in attachments:
        a.pop("extracted_chars", None)
    sa_text = None
    if ini.get("sa_doc_attachment_id"):
        row = db.query_one("SELECT extracted_text FROM attachments WHERE id = ?", (ini["sa_doc_attachment_id"],))
        sa_text = row["extracted_text"] if row else None
    train = None
    if ini.get("target_release"):
        train = db.query_one("SELECT code, train_date FROM release_trains WHERE code = ?", (ini["target_release"],))
    return {
        "initiative": ini,
        "components": components,
        "tasks": tasks,
        "allocations": allocations,
        "resources": resources,
        "risks": risks,
        "change_requests": crs,
        "prn": get_prn(ini.get("prn_code")),
        "attachments": attachments,
        "grooming": grooming_for(initiative_id),
        "scope_changes": scope_changes(initiative_id),
        "target_train": train,
        "component_catalog": component_catalog(),
        "sa_doc_text": sa_text,
        "action_required": action_required(ini, components),
        "today": get_today().isoformat(),
        "now": get_now().isoformat(),
    }
