# Solution Architecture: Step-up MFA for Wire Transfers

Version 0.9 · Author: Mateo Brennan (DC SA) · LOB: Commercial Banking · RDDC-24601 · PRN-72391 · Target release: DC-2612

## 1. Document control

Author: Mateo Brennan (DC SA)
Version: 0.9
Status: Approved for build
Date: 2 Oct 2026
LOB: Commercial Banking
Requestor: Naomi Castell
RDDC: RDDC-24601
PRN: PRN-72391
Target release: DC-2612 (Sat 12 Dec 2026)
DC PM: Grace Ellingham

## 2. Business context

Commercial clients release wires in Online Banking for Business after a single sign-in. Fraud losses on business wires rose in 2026 and the fraud standard now requires step-up authentication for high-risk releases. This change adds step-up MFA when a wire is released above the client's threshold, with the threshold driven by fraud risk signals.

## 3. Scope

In scope: commercial wire release in Online Banking for Business; step-up by one-time passcode or push approval; risk-based thresholds from Fraud Signals Integration; API Gateway policy enforcement on wire release.
Out of scope: mobile wires, retail e-Transfers, changes to wire limits.

## 4. Impacted components

| DC component | Change | Complexity |
|---|---|---|
| CIAM / Security | Step-up challenge, approval and single-use step-up grant bound to the wire release | High |
| Fraud Signals Integration | Risk score per wire release sets the step-up threshold | Medium |
| Online Banking Web | Step-up prompts in the wire release flow | Low |
| API Gateway | Policy requires a valid step-up grant on wire release routes | Low |

## 5. Integration and sequence

1. The client releases a wire in Online Banking for Business.
2. Fraud Signals Integration scores the release (device, amount, payee age, session signals) and returns whether step-up is needed.
3. If it is, CIAM challenges the user by one-time passcode or push approval and issues a single-use step-up grant bound to that wire release.
4. API Gateway checks the grant on the wire release route; without it the release is refused and held for review.

## 6. Non-functional requirements

- Step-up completes in under 30 seconds for 95% of users.
- Risk score response p95 under 200 ms.
- 99.95% availability for the step-up service during business hours; peak 4,000 wire releases per hour at month end.

## 7. Security

- Step-up grants are single-use, bound to the wire release, and expire after 5 minutes.
- Passcodes lock after 3 failed attempts.
- Threat model updated for replay of step-up grants; penetration test before production.

## 8. Data

- Step-up audit records (who, when, method, risk score, outcome) retained 7 years.
- No new customer data; device signals are already captured by Fraud Signals Integration.

## 9. Backout plan

An API Gateway policy switch removes the step-up requirement and wire release returns to the current flow within 15 minutes. CIAM and Fraud Signals changes stay deployed but inactive. No data migration is involved.

## 10. Approvals

| DC component | Approver | Status |
|---|---|---|
| CIAM / Security | Mira Castellane | Approved |
| Fraud Signals Integration | Felix Hartwell | Approved |
| Online Banking Web | Nadia Fenwick | Approved |
| API Gateway | Devon Achterberg | Approved |

## 11. Open items

None. All approvals received 18 Jun 2026.
