# Solution Architecture: Wealth Dashboard Accessibility Fixes

Version 0.4 · Author: Mateo Brennan (DC SA) · LOB: Wealth · RDDC-24755 · Target release: DC-2703

## 1. Document control

Author: Mateo Brennan (DC SA)
Version: 0.4
Status: Draft
Date: 9 Oct 2026
LOB: Wealth
Requestor: Bea Lindqvist
RDDC: RDDC-24755
Target release: DC-2703 (Sat 20 Mar 2027)

## 2. Context

The latest accessibility audit of the Wealth dashboard found 34 WCAG 2.1 AA failures, 9 of them rated serious, across Online Banking Web and the iOS and Android apps. Wealth has committed to closing every Level A and AA finding by the end of Q2 FY27.

## 3. Scope

In scope: focus order and keyboard navigation on the holdings and performance widgets; colour contrast on the allocation chart and gain/loss figures; text alternatives and data tables for charts; screen reader labels on web, iOS and Android dashboard tiles.
Out of scope: dashboard redesign, new widgets, advisor-facing tools.

## 4. Impacted components

| DC component | Change | Complexity |
|---|---|---|
| Online Banking Web | Fix web findings on holdings, performance and allocation widgets, including chart alternatives | High |
| Mobile App – iOS | Screen reader labels, dynamic type and focus order on dashboard tiles | Medium |
| Mobile App – Android | Content descriptions, contrast and focus order on dashboard tiles | Medium |

## 5. Integration and sequence

All three channels read holdings from the existing Wealth dashboard services; no service changes. Web fixes ship on DC-2703 behind the existing Wealth dashboard feature flag. Mobile fixes ride the next app store release after DC-2703.

## 6. Data

No new data. Chart alternatives and data tables use the holdings already returned to the dashboard.

## 7. Open questions

1. Audit scope agreed with the accessibility office on 13 Oct; screen reader and browser test matrix still to be confirmed (owner: Hana Brightwater).
2. Sizing of chart alternatives with the design system team (owner: Nadia Fenwick, due 22 Oct 2026).
