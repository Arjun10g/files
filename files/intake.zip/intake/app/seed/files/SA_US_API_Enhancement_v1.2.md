# Solution Architecture: US API Enhancement

Version 1.2 · Author: Sana Whitfield (DC SA) · LOB: US P&C · RDDC-24817 · PRN-77310 · Target release: DC-2702

## 1. Document control

Author: Sana Whitfield (DC SA)
Version: 1.2
Status: For component approval
Date: 16 Oct 2026
LOB: US P&C
Requestor: Clara Pemberton
RDDC: RDDC-24817
DC Intake: DCI-3391
PRN: PRN-77310
Target release: DC-2702 (Sat 20 Feb 2027)
Requested go-live: 20 Feb 2027
DC PM: Grace Ellingham · Tech Lead: Devon Achterberg

Version history: 1.0 (2 Oct 2026) first draft for DC SA review. 1.1 (9 Oct 2026) CIAM scopes and the EDP change-data-capture feed added after the design review. 1.2 (16 Oct 2026) non-functional requirements, approvals and open items updated.

## 2. Context

US P&C digital channels and partner aggregators read account balances and transaction history today by screen-scraping Online Banking Web. Scraping breaks with every front-end release, cannot be rate limited per partner, and gives the bank no record of customer consent. Two aggregators have asked for supported access before their Q1 2027 launches.

This change exposes account and transaction data through versioned, consented APIs on the API Platform. US digital channels move to the same APIs, so one contract serves both internal and partner consumers. Success is measured by retiring scraping for the two launch partners within 30 days of go-live and holding the SLOs in section 6.

## 3. Scope

In scope:
- New read-only APIs /v2/accounts and /v2/transactions for US deposit and card accounts.
- OAuth2 consent for partner aggregators with two new scopes, and mutual TLS for partner connections.
- Change-data-capture of posted US transactions into the Enterprise Data Platform to back transaction history.
- SLO dashboards and alerting for the new APIs.

Out of scope:
- Payment initiation and money movement of any kind.
- Canadian channels and Canadian accounts.
- Partner onboarding workflow and the partner developer portal (separate intake).
- Changes to Mobile App or Online Banking Web screens. Both channels keep their current behaviour and are regression tested only.

## 4. Impacted components and solution overview

| DC component | Change | Complexity |
|---|---|---|
| API Platform | New /v2 accounts and transactions APIs | High |
| Enterprise Data Platform | New CDC feed and txn-history topic | Medium |
| CIAM / Security | New scopes, partner consent and mTLS | Medium |
| SRE / Observability | SLO dashboards and alerts | Low |

### 4.1 API Platform

Expose /v2/accounts and /v2/transactions to US digital channels and approved partner aggregators. Both APIs follow the bank's OpenAPI 3.1 standard and are published in the internal catalogue. /v2/transactions supports cursor pagination (100 records per page), date-range filters up to 13 months, and ETag caching so unchanged pages return 304. Each partner client is rate limited to 50 requests per second with a burst of 100. Requests carry an idempotency key so retried reads never double-count in partner reconciliation. The existing /v1 accounts API stays live for current channel consumers until they migrate; no /v1 contract changes.

### 4.2 Enterprise Data Platform

Publish posted US transactions from the core ledger as change-data-capture events to a new Kafka topic, txn-history, with 13-month retention. The API Platform reads transaction history from the EDP serving store fed by this topic, never from the ledger directly. The event schema is at draft v0.3 and needs to be frozen with the EDP team before development starts. Expected load is 1.6M events per day, with month-end peaks of 3x.

### 4.3 CIAM / Security

Add two OAuth2 scopes, accounts.read and transactions.read. Partners request them through the existing consent journey; customers grant consent for 90 days and can revoke it at any time in Online Banking Web settings. Consent grants are stored in CIAM and checked on every call. Partner clients authenticate with mutual TLS using certificates issued by the bank's partner PKI.

### 4.4 SRE / Observability

Add SLO dashboards for both APIs (availability, p95 latency, error rate by partner) and page the API Platform on-call when the 1-hour error budget burn rate exceeds 2x. No new tooling; this uses the existing observability stack.

## 5. Integration and sequence

1. The partner or channel client opens a mutual TLS connection and presents its client certificate.
2. The client obtains an access grant from CIAM carrying accounts.read or transactions.read, tied to the customer's consent.
3. The API Platform validates the grant and scope with CIAM, applies the per-client rate limit, and serves the request.
4. For /v2/transactions, the API Platform reads from the EDP serving store, which is fed from txn-history.
5. Every call is logged with partner id, scope and consent id for audit.

Build sequence: the CIAM scopes must be available in the integration environment before API Platform integration testing starts. The EDP topic and serving store must be loaded with 13 months of history before system integration testing.

## 6. Non-functional requirements (NFRs)

- Latency: p95 under 300 ms and p99 under 800 ms for both APIs at peak.
- Availability: 99.9% monthly per API, measured at the API Platform edge.
- Volume: 2M calls per day at launch, sized for 5M per day by end of 2027.
- Throughput: 50 requests per second per partner client; 600 requests per second aggregate peak.
- Freshness: posted transactions visible in /v2/transactions within 5 minutes.
- Recovery: RTO 1 hour, RPO 5 minutes for the EDP serving store.

## 7. Security

- Mutual TLS for all partner connections; TLS 1.2 or higher for channel traffic.
- Threat model updated for partner access, consent abuse and data scraping through the new APIs.
- Penetration test of both APIs completed and findings closed before production.
- Scopes are least-privilege and read-only; no scope grants money movement.
- Partner access is suspended automatically when a consent is revoked or a certificate expires.

## 8. Data

- Data classes: account identifiers, balances and transaction history (Confidential, customer data).
- Retention: txn-history keeps 13 months; API access logs keep 7 years per records policy.
- Account numbers are masked to the last four digits in partner responses.
- US data residency for the EDP serving store and logs is not yet confirmed (see open items).

## 9. Dependencies

- Downstream: Mobile App (iOS and Android) v8.4 and Online Banking Web read the /v1 accounts API today; both need regression testing against the new API Platform build.
- CIAM authorization server upgrade to the version that supports scoped consent, due in CIAM's November release.
- Two launch partners ready to test in UAT in February 2027.

## 10. Risks and assumptions

- Assumption: launch partners use the standard consent journey; no partner-specific consent screens.
- Assumption: the EDP Kafka cluster has headroom for 1.6M additional events per day.
- Risk: the EDP event schema is still draft; a late change would rework the transactions API mapping.
- Risk: DC SA capacity in November is tight while this document is finalized.
- Risk: the build runs through the 14 Dec to 8 Jan change freeze and the holiday period, leaving little float before DC-2702.

## 11. Approvals

| DC component | Approver | Status | Date |
|---|---|---|---|
| API Platform | Devon Achterberg | Approved | 14 Oct 2026 |
| Enterprise Data Platform | Lena Oduya | Approved | 15 Oct 2026 |
| CIAM / Security | Mira Castellane | Pending | — |
| SRE / Observability | Kai Moreau | Not required | — |

## 12. Open questions

1. TBD: partner onboarding SLA (owner: Clara Pemberton).
2. TBD: data residency confirmation for the EDP serving store and logs (owner: Sana Whitfield).
3. Freeze the txn-history event schema v0.3 with EDP before development starts (owner: Lena Oduya, target 13 Nov 2026).
4. CIAM / Security approval of the new scopes and partner mTLS at the November architecture review (owner: Mira Castellane).
