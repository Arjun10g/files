# Solution Architecture: Online Banking Real-time Alerts

Version 0.3 · Author: Mateo Brennan (DC SA) · LOB: Canadian P&C · Status: Draft

## 1. Document control

Author: Mateo Brennan (DC SA)
Version: 0.3
Status: Draft for discussion
Date: 13 Oct 2026
LOB: Canadian P&C
Requestor: Hugo Lafleur
DC Intake: DCI-3402
PRN: TBD
Target release: TBD

## 2. Background

Customers get real-time push alerts in the mobile app, but Online Banking Web shows alerts the next morning, after the overnight batch. The business would like the same real-time alerts in Online Banking ASAP, ideally before the spring campaign.

## 3. Proposed scope

- Real-time alerts for account activity in Online Banking Web, similar to existing alerts but delivered as events happen.
- Customers choose which alerts they want in alert preferences.
- Minor UI changes to the alerts inbox and the alerts settings page.

Alert types in the first release: TBD (large purchases, low balance and deposits have been mentioned).

## 4. Solution approach

Transaction events would be picked up from the Enterprise Data Platform and passed to the Notifications Service, which already sends the overnight alerts and the mobile push alerts. The Notifications Service would deliver the alert to Online Banking Web and keep it in the alerts inbox. The approach should be similar to existing alerts so the team can reuse what is there.

Online Banking Web needs minor UI changes to show new alerts without a page refresh and to add the new alert types to the settings page. Existing preferences should carry over.

Event volumes: TBD. The EDP team has said the existing topics may be enough, to be checked.

## 5. Components (initial view)

- Enterprise Data Platform: read transaction events.
- Notifications Service: new real-time alert rules for web.
- Online Banking Web: inbox and settings page changes.
- Mobile App: no change; it already receives real-time push alerts.

## 6. Data

Alerts contain the account nickname, the amount and the merchant name. Alert history is kept the same as today.

## 7. Open questions

- How quickly must an alert arrive after the transaction?
- Do customers need to opt in again, or do existing preferences apply?
- Is CIAM involved for preference changes?
- Who approves on the Notifications Service side?

## 8. Next steps

- Walk through the draft with the Notifications Service and EDP teams.
- Confirm alert types and the target release with the business.
- Add design details once the scope is agreed.
