"""Demo seed (owner B1): rebuilds the schema and loads app/seed/*.json (PO doc §4, master plan §6.2 pins).

reset_database() is idempotent and fast: it drops every table, recreates app/schema.sql, inserts the seed in one
transaction, clears data/uploads (and ai_runs with it), copies app/seed/files/* into the uploads folder and caches
health through app.services.derive when that module is installed.

Seeded plan allocations are stored as source='derived' rows with the exact pinned hours (Sana Nov 115.5 h, Mateo
Nov 50.5 h, Felix Dec 96 h of 80 h, Hana Dec 145.5 h, Tobias Dec 0 h of 147 h ...). They are what derive.py would
own for these plans, so a later plan edit on a seeded initiative re-derives them instead of double counting.
"""
from __future__ import annotations

import json
import shutil
import sqlite3
from pathlib import Path

from app import db
from app.config import SCHEMA_PATH, SEED_DIR, load_config

FILES_DIR = SEED_DIR / "files"
RATE = 110.0
MIME = {".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".pdf": "application/pdf", ".md": "text/markdown", ".txt": "text/plain"}


def _load(name: str) -> dict:
    return json.loads((SEED_DIR / name).read_text(encoding="utf-8"))


def _drop_all(conn) -> None:
    """Drop every table. Runs inside the reset transaction with foreign keys off."""
    names = [r["name"] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'").fetchall()]
    for name in names:
        conn.execute(f'DROP TABLE IF EXISTS "{name}"')


def _schema_statements() -> list[str]:
    """app/schema.sql split into statements (PRAGMAs skipped) so they can run inside one transaction."""
    statements, buf = [], ""
    for line in SCHEMA_PATH.read_text(encoding="utf-8").splitlines(keepends=True):
        buf += line
        if sqlite3.complete_statement(buf):
            stmt = buf.strip()
            buf = ""
            body = "\n".join(x for x in stmt.splitlines() if not x.strip().startswith("--")).strip()
            if body and not body.upper().startswith("PRAGMA"):
                statements.append(stmt)
    return statements


def _clear_uploads(upload_dir: Path) -> None:
    upload_dir.mkdir(parents=True, exist_ok=True)
    for child in upload_dir.iterdir():
        if child.is_dir() and not child.is_symlink():
            shutil.rmtree(child)
        else:
            child.unlink()


def _copy_sample_files(upload_dir: Path) -> int:
    if not FILES_DIR.is_dir():
        return 0
    copied = 0
    for src in sorted(FILES_DIR.iterdir()):
        if src.is_file() and not src.name.startswith("."):
            shutil.copy2(src, upload_dir / src.name)
            copied += 1
    return copied


def _sample_text(name: str | None) -> str | None:
    if not name:
        return None
    path = FILES_DIR / name
    if path.is_file() and path.suffix.lower() in (".md", ".txt"):
        return path.read_text(encoding="utf-8")
    return None


# ------------------------------------------------------------------ loaders
def _seed_reference(conn, today: str, ai_mode: str) -> None:
    lk = _load("lookups.json")
    rows = []
    for category, items in lk["categories"].items():
        default = lk["defaults"].get(category)
        for sort, item in enumerate(items):
            rows.append((category, str(item["value"]), item["label"], sort, 1 if item["value"] == default else 0))
    for sort, h in enumerate(lk["holidays"]):
        rows.append(("holiday", h["date"], h["name"], sort, 0))
    rows.append(("change_freeze", lk["change_freeze"]["start"], "start", 0, 0))
    rows.append(("change_freeze", lk["change_freeze"]["end"], "end", 1, 0))
    conn.executemany("INSERT INTO lookups (category, value, label, sort, is_default) VALUES (?, ?, ?, ?, ?)", rows)
    settings = dict(lk["settings"])
    settings.update({"ai_mode": ai_mode, "demo_today": today})
    conn.executemany("INSERT INTO app_settings (key, value) VALUES (?, ?)", list(settings.items()))

    gov = _load("governance.json")
    conn.executemany("INSERT INTO release_trains (code, train_date, status, notes) VALUES (?, ?, ?, ?)",
                     [(t["code"], t["train_date"], t["status"], t["notes"]) for t in gov["release_trains"]])
    conn.executemany(
        "INSERT INTO dc_intakes (code, name, lob, requestor, priority, requested_go_live, description, dc_pm_id, "
        "dc_sa_id, tech_lead_id, pm_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [(d["code"], d["name"], d["lob"], d["requestor"], d["priority"], d["requested_go_live"], d["description"],
          d.get("dc_pm_id"), d.get("dc_sa_id"), d.get("tech_lead_id"), d.get("pm_id")) for d in gov["dc_intakes"]])


def _seed_people_and_catalogue(conn) -> None:
    res = _load("resources.json")
    comps = _load("components.json")["components"]
    for r in res["resources"]:
        db.insert("resources", {
            "id": r["id"], "name": r["name"], "role": r["role"], "team": r["team"], "team_label": r["team_label"],
            "location": r["location"], "hourly_rate": r["hourly_rate"],
            "default_monthly_hours": r["default_monthly_hours"], "capacity_eligible": r["capacity_eligible"],
            "active": 1}, conn)
    for c in comps:
        db.insert("dc_components", {
            "id": c["id"], "code": c["code"], "name": c["name"], "team": c["team"], "ci_name": c["ci_name"],
            "component_lead_id": c["component_lead_id"], "keywords": db.to_json(c["keywords"]),
            "base_hours_low": c["base_hours_low"], "base_hours_medium": c["base_hours_medium"],
            "base_hours_high": c["base_hours_high"], "description": c["description"]}, conn)
    code_to_id = {c["code"]: c["id"] for c in comps}
    conn.executemany(
        "INSERT INTO component_dependencies (from_component_id, to_component_id, kind, note) VALUES (?, ?, 'downstream', ?)",
        [(c["id"], code_to_id[d], f"{c['name']} change needs regression on {d}") for c in comps for d in c["downstream"]])
    conn.executemany("UPDATE resources SET component_id = ? WHERE id = ?",
                     [(r["component_id"], r["id"]) for r in res["resources"] if r["component_id"]])

    skill_ids = {}
    for s in res["skills"]:
        skill_ids[s["name"]] = db.insert("skills", {"name": s["name"], "category": s["category"]}, conn)
    notes = res.get("availability_notes", {})
    for r in res["resources"]:
        for s in r["skills"]:
            conn.execute(
                "INSERT INTO resource_skills (resource_id, skill_id, level, source, evidence) VALUES (?, ?, ?, 'seed', ?)",
                (r["id"], skill_ids[s["skill"]], s["level"], s["evidence"]))
        for month, hours in (r.get("availability") or {}).items():
            conn.execute(
                "INSERT INTO resource_availability (resource_id, month, available_hours, note, updated_by) "
                "VALUES (?, ?, ?, ?, 'Elena Rusk')", (r["id"], month, hours, notes.get(f"{r['id']}:{month}")))


def _seed_budget(conn) -> None:
    for p in _load("governance.json")["prns"]:
        db.insert("prn_budget", {
            "prn_code": p["prn_code"], "name": p["name"], "lob": p["lob"], "funded_hours": p["funded_hours"],
            "rate": RATE, "budget_amount": round(p["funded_hours"] * RATE, 2), "currency": "CAD",
            "owner_id": p["owner_id"], "start_month": p["start_month"], "end_month": p["end_month"]}, conn)
        conn.executemany(
            "INSERT INTO prn_charges (prn_code, month, charged_hours, charged_amount, source) VALUES (?, ?, ?, ?, 'seed')",
            [(p["prn_code"], c["month"], c["charged_hours"], round(c["charged_hours"] * RATE, 2)) for c in p["charges"]])


INITIATIVE_COLUMNS = (
    "id", "rddc", "dc_intake", "name", "lob", "priority", "stage", "status", "requestor", "requestor_id",
    "assigned_to_id", "pm_id", "tech_lead_id", "dc_pm_id", "dc_sa_id", "sa_author", "sa_version", "sa_completeness",
    "description", "prn_code", "requested_go_live", "target_release", "planned_start", "planned_end",
    "readiness_date", "qa_date", "qa_signoff_date", "prod_date", "l2_hours", "l2_low_hours", "l2_high_hours",
    "l2_tshirt", "l2_status", "l2_baseline_hours", "l2_submitted_at", "l2_approved_at", "l2_approved_by",
    "l2_reminders_sent", "baseline_set_at", "rag_cached", "comments", "created_at")
TASK_COLUMNS = (
    "wbs_code", "step", "phase", "description", "owner_id", "resource_id", "planned_start", "planned_end",
    "baseline_start", "baseline_end", "actual_start", "actual_end", "est_hours", "allocation_pct", "status", "pct",
    "at_risk", "comments", "is_milestone")


def _seed_initiatives(conn) -> dict:
    """Returns {(initiative_id, wbs_code): task_id}."""
    comp_ids = {r["code"]: r["id"] for r in conn.execute("SELECT id, code FROM dc_components").fetchall()}
    task_ids: dict = {}
    for ini in _load("initiatives.json")["initiatives"]:
        values = {k: ini.get(k) for k in INITIATIVE_COLUMNS}
        values["labels"] = db.to_json(ini.get("labels") or [])
        values["sa_missing_json"] = db.to_json(ini["sa_missing_json"]) if ini.get("sa_missing_json") is not None else None
        values["rag_overrides_json"] = db.to_json({})
        values["updated_at"] = ini["created_at"]
        db.insert("initiatives", values, conn)
        ic_ids = {}
        for c in ini["components"]:
            ic_ids[c["code"]] = db.insert("initiative_components", {
                "initiative_id": ini["id"], "component_id": comp_ids[c["code"]], "approval": c["approval"],
                "change_summary": c["change_summary"], "complexity": c["complexity"], "est_hours": c["est_hours"],
                "component_lead_id": c["component_lead_id"], "sort": c["sort"], "source": "seed"}, conn)
        firmness = "confirmed" if ini.get("l2_status") == "Approved" else "tentative"
        local: dict = {}
        for sort, t in enumerate(ini["tasks"], start=1):
            values = {k: t.get(k) for k in TASK_COLUMNS}
            values.update({"initiative_id": ini["id"], "sort": sort * 10, "source": "seed",
                           "initiative_component_id": ic_ids.get(t.get("component_code")),
                           "updated_at": ini["created_at"]})
            local[t["wbs_code"]] = db.insert("wbs_tasks", values, conn)
        for t in ini["tasks"]:
            tid = local[t["wbs_code"]]
            if t.get("parent_code"):
                conn.execute("UPDATE wbs_tasks SET parent_id = ? WHERE id = ?", (local[t["parent_code"]], tid))
            conn.executemany("INSERT INTO wbs_dependencies (task_id, depends_on_task_id, type, lag_days) VALUES (?, ?, 'FS', 0)",
                             [(tid, local[d]) for d in t.get("depends_on", [])])
            conn.executemany(
                "INSERT INTO allocations (resource_id, initiative_id, task_id, month, hours, firmness, source) "
                "VALUES (?, ?, ?, ?, ?, ?, 'derived')",
                [(t["resource_id"], ini["id"], tid, m, h, firmness) for m, h in t.get("allocations", {}).items()])
        task_ids.update({(ini["id"], code): tid for code, tid in local.items()})
    return task_ids


def _seed_bau(conn) -> None:
    """Run & maintain (BAU) demand for Apr–Oct 2027 (20–40%, a fixed per-month table) on a hidden pseudo-initiative (id -1, rddc BAU-FY27).

    The negative id keeps the hero at id 9 and outside every /initiatives/<id> route. Rows are source='seed', so
    derive.rebuild_allocations never removes them. Oct 2026 – Mar 2027 numbers are untouched.
    """
    res = _load("resources.json")
    bau = res["bau"]
    ini = bau["initiative"]
    db.insert("initiatives", {
        "id": ini["id"], "rddc": ini["rddc"], "name": ini["name"], "lob": "Technology", "priority": 4, "stage": "Closed",
        "status": "Completed", "labels": db.to_json(["bau", "hidden"]), "description": ini["description"],
        "l2_status": "Approved", "rag_overrides_json": db.to_json({}), "comments": "Hidden capacity placeholder.",
        "created_at": "2026-10-01T09:00:00-04:00", "updated_at": "2026-10-01T09:00:00-04:00"}, conn)
    rows = []
    for r in res["resources"]:
        pct_by_month = r.get("bau_pct") or {}
        for month in bau["months"]:
            pct = pct_by_month.get(month)
            if not pct:
                continue
            hours = round((r["availability"].get(month) or 0) * pct / 100 * 2) / 2
            if hours > 0:
                rows.append((r["id"], ini["id"], month, hours))
    conn.executemany("INSERT INTO allocations (resource_id, initiative_id, task_id, month, hours, firmness, source) "
                     "VALUES (?, ?, NULL, ?, ?, 'confirmed', 'seed')", rows)


def _write_attachment(conn, upload_dir: Path, a: dict, entity_id) -> int:
    folder = upload_dir / str(a["initiative_id"])
    folder.mkdir(parents=True, exist_ok=True)
    text = _sample_text(a.get("seed_file")) or a["content"]
    target = folder / a["filename"]
    target.write_text(text, encoding="utf-8")
    return db.insert("attachments", {
        "initiative_id": a["initiative_id"], "entity_type": a["entity_type"], "entity_id": entity_id,
        "kind": a["kind"], "filename": a["filename"], "stored_path": f"{a['initiative_id']}/{a['filename']}",
        "mime": MIME.get(target.suffix.lower(), "text/plain"), "size_bytes": target.stat().st_size,
        "extracted_text": text, "version": a.get("version"), "uploaded_by": a.get("uploaded_by"),
        "uploaded_at": a.get("uploaded_at")}, conn)


def _seed_governance_and_artifacts(conn, upload_dir: Path, task_ids: dict) -> None:
    gov = _load("governance.json")
    art = _load("artifacts.json")
    crq_keys = {c["key"]: c for c in gov["change_requests"]}

    att_ids = {}
    for a in art["attachments"]:
        att_ids[a["key"]] = _write_attachment(conn, upload_dir, a, a["initiative_id"] if a["entity_type"] == "initiative" else None)
        if a["kind"] == "sa_doc":
            conn.execute("UPDATE initiatives SET sa_doc_attachment_id = ? WHERE id = ?", (att_ids[a["key"]], a["initiative_id"]))

    cr_ids = {}
    for c in gov["change_requests"]:
        cr_ids[c["key"]] = db.insert("change_requests", {
            "initiative_id": c["initiative_id"], "crq_number": c["crq_number"], "raised_at": c["raised_at"],
            "crq_start": c["crq_start"], "crq_end": c["crq_end"], "release_type": c["release_type"],
            "release_train": c["release_train"], "target_release": c["target_release"],
            "affected_cis": db.to_json(c["affected_cis"]), "impacted_components": db.to_json(c["impacted_components"]),
            "implementation_status": c["implementation_status"], "crq_approval_status": c["crq_approval_status"],
            "sto_approval": c["sto_approval"], "cms_lead_id": c["cms_lead_id"], "rel_lead_id": c["rel_lead_id"],
            "resource_id": c["resource_id"], "tech_validation_status": c["tech_validation_status"],
            "biz_validation_status": c["biz_validation_status"],
            "tech_validation_attachment_id": att_ids.get(c["tech_att"]),
            "biz_validation_attachment_id": att_ids.get(c["biz_att"]),
            "backout_attachment_id": att_ids.get(c["backout_att"]), "implemented_at": c.get("implemented_at"),
            "source": "seed", "created_at": c["created_at"], "updated_at": c["created_at"]}, conn)
    for a in art["attachments"]:
        if a.get("entity_key"):
            conn.execute("UPDATE attachments SET entity_id = ? WHERE id = ?", (cr_ids[a["entity_key"]], att_ids[a["key"]]))
    del crq_keys

    session_ids = {}
    for s in gov["grooming_sessions"]:
        session_ids[s["session_date"]] = db.insert("grooming_sessions", s, conn)
    conn.executemany(
        "INSERT INTO grooming_slots (session_id, initiative_id, slot_order, recipients_json, status) VALUES (?, ?, ?, ?, ?)",
        [(session_ids[s["session_date"]], s["initiative_id"], s["slot_order"], db.to_json(s["recipients"]), s["status"])
         for s in gov["grooming_slots"]])

    for n in gov["notifications"]:
        values = dict(n)
        values["cc_names"] = db.to_json(n.get("cc_names") or [])
        db.insert("notifications", values, conn)

    for i, r in enumerate(gov["risks"], start=1):
        db.insert("risks", {
            "risk_code": f"RSK-{i:03d}", "initiative_id": r["initiative_id"],
            "task_id": task_ids.get((r["initiative_id"], r["wbs"])) if r.get("wbs") else None,
            "title": r["title"], "description": r.get("description"), "category": r["category"],
            "severity": r["severity"], "likelihood": r["likelihood"], "trigger_signal": r["trigger_signal"],
            "mitigation": r["mitigation"], "owner_id": r["owner_id"], "status": r["status"], "due_date": r["due_date"],
            "source": r["source"], "created_at": "2026-10-12T10:00:00-04:00"}, conn)

    for d in art["documents"]:
        db.insert("documents", {
            "initiative_id": d["initiative_id"], "doc_type": d["doc_type"], "title": d["title"], "version": d["version"],
            "attachment_id": att_ids.get(d["attachment_key"]) if d.get("attachment_key") else None,
            "owner_id": d["owner_id"], "status": d["status"], "components": db.to_json(d["components"]),
            "updated_at": d["updated_at"]}, conn)
    for d in art["decisions"]:
        db.insert("decisions", {**d, "created_at": f"{d['decided_on']}T17:00:00-04:00"}, conn)
    for lesson in art["lessons"]:
        db.insert("lessons_learned", {**lesson, "tags": db.to_json(lesson["tags"]), "source": "manual",
                                      "created_at": "2026-10-16T15:00:00-04:00"}, conn)
    for m in art["meeting_notes"]:
        db.insert("meeting_notes", {
            "initiative_id": m["initiative_id"], "grooming_session_id": session_ids.get(m.get("session_date")),
            "meeting_date": m["meeting_date"], "title": m["title"], "attendees": db.to_json(m["attendees"]),
            "notes_md": _sample_text(m.get("notes_file")) or m["notes_md"],
            "action_items_json": db.to_json(m["action_items"]), "created_at": f"{m['meeting_date']}T16:00:00-04:00"}, conn)


def _cache_compliance(conn) -> None:
    from app import repo
    for cr in conn.execute("SELECT * FROM change_requests").fetchall():
        conn.execute("UPDATE change_requests SET compliance_json = ? WHERE id = ?",
                     (db.to_json(repo.compliance_for(cr)), cr["id"]))


def _refresh_derived() -> None:
    """Cache health and queue the reminders already due on the demo date, so the Outbox is settled at start."""
    from app import repo
    derive = repo.optional_module("app.services.derive")
    if derive is None:
        return
    if hasattr(derive, "run_reminders"):
        derive.run_reminders(None)
    if hasattr(derive, "refresh_all_health"):
        derive.refresh_all_health()
        return
    for row in db.query("SELECT id FROM initiatives ORDER BY id"):
        derive.refresh_health(row["id"])


COUNT_TABLES = ("initiatives", "initiative_components", "wbs_tasks", "wbs_dependencies", "allocations", "resources",
                "resource_availability", "dc_components", "component_dependencies", "skills", "resource_skills",
                "prn_budget", "prn_charges", "release_trains", "dc_intakes", "change_requests", "risks",
                "grooming_sessions", "grooming_slots", "notifications", "attachments", "documents", "decisions",
                "lessons_learned", "meeting_notes", "lookups", "ai_runs")


def table_counts(conn=None) -> dict:
    conn = conn or db.get_db()
    """Raw row counts (initiatives includes the hidden BAU pseudo-initiative, id -1)."""
    return {t: conn.execute(f"SELECT COUNT(*) AS n FROM {t}").fetchone()["n"] for t in COUNT_TABLES}


def reset_database(conn=None, *, upload_dir: str | Path | None = None, today: str | None = None,
                   ai_mode: str | None = None) -> dict:
    """Drop and rebuild everything from the seed. Returns row counts per table."""
    cfg = load_config()
    conn = conn or db.get_db()
    upload_dir = Path(upload_dir or cfg.UPLOAD_DIR)
    today = today or cfg.TODAY
    ai_mode = ai_mode or cfg.AI_MODE
    if conn.in_transaction:
        conn.execute("COMMIT")
    _clear_uploads(upload_dir)
    _copy_sample_files(upload_dir)
    # One write transaction for drop + recreate + seed: concurrent readers keep seeing the old data (WAL snapshot)
    # until the commit, so a reset never exposes missing tables to other requests.
    conn.execute("PRAGMA foreign_keys = OFF")
    try:
        with db.use_connection(conn), db.transaction(conn):
            _drop_all(conn)
            for stmt in _schema_statements():
                conn.execute(stmt)
            _seed_reference(conn, today, ai_mode)
            _seed_people_and_catalogue(conn)
            _seed_budget(conn)
            task_ids = _seed_initiatives(conn)
            _seed_bau(conn)
            _seed_governance_and_artifacts(conn, upload_dir, task_ids)
            _cache_compliance(conn)
            _refresh_derived()
            broken = conn.execute("PRAGMA foreign_key_check").fetchall()
            if broken:
                raise RuntimeError(f"Seed has {len(broken)} broken references, first: {broken[0]}")
    finally:
        conn.execute("PRAGMA foreign_keys = ON")
    with db.use_connection(conn):
        return table_counts(conn)
