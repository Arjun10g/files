"""Flask app factory (FROZEN CONTRACT, owner B0).

Blueprints are imported from app.api.<name> in BLUEPRINTS order; each module exposes `bp`.
A module that does not exist yet is skipped with a log line. Import errors inside an existing module are raised.
"""
from __future__ import annotations

import importlib
import logging
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

from app import db, errors
from app.config import STATIC_DIR, load_config

BLUEPRINTS = ["core", "initiatives", "plan", "resources", "governance", "artifacts", "views", "export", "ai"]

log = logging.getLogger("bmo")


def create_app(**overrides) -> Flask:
    cfg = load_config(**overrides)
    app = Flask(__name__, static_folder=str(STATIC_DIR), static_url_path="/static")
    app.config.from_mapping(cfg.as_flask())
    app.json.sort_keys = False
    app.registered_api_modules = []

    Path(app.config["UPLOAD_DIR"]).mkdir(parents=True, exist_ok=True)
    if app.config["DB_PATH"] != ":memory:":
        Path(app.config["DB_PATH"]).parent.mkdir(parents=True, exist_ok=True)

    db.init_app(app)
    errors.register_error_handlers(app)
    _register_blueprints(app)
    _register_shell_routes(app)

    @app.after_request
    def _no_store(response):
        if request.path == "/" or request.path.startswith("/api/") or request.path.endswith("index.html"):
            response.headers["Cache-Control"] = "no-store"
        return response

    return app


def _register_blueprints(app: Flask) -> None:
    for name in BLUEPRINTS:
        module_name = f"app.api.{name}"
        try:
            module = importlib.import_module(module_name)
        except ModuleNotFoundError as exc:
            if exc.name in (module_name, "app.api"):
                log.info("Blueprint %s not present yet; skipped", module_name)
                continue
            raise
        bp = getattr(module, "bp", None)
        if bp is None:
            log.warning("Module %s has no `bp`; skipped", module_name)
            continue
        app.register_blueprint(bp)
        app.registered_api_modules.append(name)


def _has_rule(app: Flask, path: str) -> bool:
    return any(rule.rule == path for rule in app.url_map.iter_rules())


def _register_shell_routes(app: Flask) -> None:
    @app.get("/")
    def index():
        index_file = Path(app.static_folder) / "index.html"
        if index_file.exists():
            return send_from_directory(app.static_folder, "index.html", max_age=0)
        placeholder = (
            "<!doctype html><meta charset='utf-8'><title>BMO DC Project Management Tool</title>"
            "<p style='font-family:sans-serif'>The interface is being prepared.</p>"
        )
        return (
            placeholder,
            200,
            {"Content-Type": "text/html; charset=utf-8"},
        )

    if not _has_rule(app, "/api/health"):
        @app.get("/api/health")
        def fallback_health():
            from app.today import get_today

            ready = db.db_ready()
            return jsonify({
                "status": "ok",
                "db": ready,
                "ai_mode": _effective_ai_mode(app),
                "model": app.config["AI_MODEL_HEAVY"],
                "today": get_today().isoformat() if ready else app.config["TODAY"],
                "version": app.config["APP_VERSION"],
                "modules": list(app.registered_api_modules),
            })


def _effective_ai_mode(app: Flask) -> str:
    mode = app.config["AI_MODE"]
    if mode == "simulated" or (mode == "auto" and not app.config["HAS_API_KEY"]):
        return "simulated"
    return "live" if app.config["HAS_API_KEY"] else "simulated"
