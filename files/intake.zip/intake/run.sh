#!/usr/bin/env bash
# Start the BMO DC Project Management Tool: create the demo database if it is missing, then serve on BMO_PORT (5055).
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f .venv/bin/activate ]; then
  echo "Python environment .venv not found. Create it with: python3 -m venv .venv && .venv/bin/pip install -r requirements.txt" >&2
  exit 1
fi
# shellcheck disable=SC1091
source .venv/bin/activate
python -m app.cli init-if-missing
exec python -m app.cli run
