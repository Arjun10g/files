#!/usr/bin/env bash
# Legacy demo reset uses a separate database and upload directory, never the operational portal.
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f .venv/bin/activate ]; then
  echo "Python environment .venv not found. Create it with: python3 -m venv .venv && .venv/bin/pip install -r requirements.txt" >&2
  exit 1
fi
# shellcheck disable=SC1091
source .venv/bin/activate
export BMO_DB_PATH="${BMO_DB_PATH:-data/bmo_intake.db}"
export BMO_UPLOAD_DIR="${BMO_UPLOAD_DIR:-data/demo_uploads}"
exec python -m app.cli reset
