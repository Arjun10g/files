#!/usr/bin/env bash
# Reset the demo: drop and re-seed the database, clear uploads and AI runs.
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f .venv/bin/activate ]; then
  echo "Python environment .venv not found. Create it with: python3 -m venv .venv && .venv/bin/pip install -r requirements.txt" >&2
  exit 1
fi
# shellcheck disable=SC1091
source .venv/bin/activate
exec python -m app.cli reset
