// grid.js: Excel-like editable table. Click a cell to edit; Tab/Enter move to the next cell;
// Esc cancels; arrow keys move the selection. Dirty cells show a blue left tick until saved.
// Inline validation shows a red border and a note under the table.
import { h, txt, mount } from './dom.js';
import { aiTag } from './components.js';

const editedRows = new Set();

function optionList(col, row) {
  const raw = typeof col.options === 'function' ? col.options(row) : (col.options || []);
  return raw.map((o) => (o && typeof o === 'object' ? o : { value: o, label: String(o) }));
}

function sameValue(a, b) {
  const na = a === undefined || a === '' ? null : a;
  const nb = b === undefined || b === '' ? null : b;
  return String(na) === String(nb);
}

/**
 * createGrid({columns, rows, rowKey, gridKey, onCommit, rowClass, indent, rowActions, footer,
 *             emptyText, isAi, flashRunId, caption, stickyCols})
 * column.extra: hidden until the wrapper gets class 'show-extra' ("More columns").
 * onCommit(row, key, newValue, oldValue): oldValue is the cell value before this edit.
 * column: {key, label, width, type, options, editable(row), format(row), validate(value,row), parse(raw),
 *          align, aiTag, cls, title, placeholder, min, max, step}
 */
export function createGrid(opts) {
  const {
    columns, rowKey = 'id', gridKey = 'grid', onCommit, rowClass, indent, rowActions, footer,
    emptyText = 'No rows yet.', isAi, caption, stickyCols = 0,
  } = opts;
  let rows = opts.rows || [];
  let flashRunId = opts.flashRunId || null;
  const dirty = new Map();
  const invalid = new Map();
  const saving = new Set();
  let sel = { r: -1, c: -1 };
  let editing = null;

  const table = h('table.grid', { attrs: { role: 'grid' } });
  const thead = h('thead');
  const tbody = h('tbody');
  const note = h('div.grid-note', { attrs: { role: 'alert' }, hidden: true });
  const scroller = h('div.grid-scroll', table);
  const frame = h('div.grid-frame', scroller, h('div.scroll-shade', { aria: { hidden: 'true' } }));
  const wrap = h('div.grid-wrap', frame, note);
  const updateShade = () => {
    frame.classList.toggle('scroll-r', scroller.scrollLeft + scroller.clientWidth < scroller.scrollWidth - 2);
    frame.classList.toggle('scroll-l', scroller.scrollLeft > 2);
  };
  scroller.addEventListener('scroll', updateShade, { passive: true });
  if (typeof ResizeObserver !== 'undefined') new ResizeObserver(updateShade).observe(scroller);
  if (caption) table.appendChild(h('caption.visually-hidden', caption));

  const editableCols = (row) => columns.map((c, i) => ({ c, i })).filter(({ c }) => isEditable(c, row));
  const cellKey = (row, col) => `${row[rowKey]}:${col.key}`;

  function isEditable(col, row) {
    if (!col.type || col.type === 'readonly' || col.type === 'custom') return false;
    return col.editable ? Boolean(col.editable(row)) : true;
  }

  function renderHead() {
    const tr = h('tr');
    columns.forEach((col, i) => {
      tr.appendChild(h(`th${i < stickyCols ? '.sticky-col' : ''}`, {
        attrs: { scope: 'col' }, title: col.title || null,
        style: { width: col.width ? `${col.width}px` : null, 'min-width': col.width ? `${col.width}px` : null, left: i < stickyCols ? `var(--sticky-${i})` : null },
        class: [col.align === 'right' ? 'num' : '', col.extra ? 'col-extra' : ''].filter(Boolean).join(' ') || null,
      }, col.label));
    });
    if (rowActions) tr.appendChild(h('th.row-actions-h', h('span.visually-hidden', 'Actions')));
    mount(thead, tr);
  }

  function displayFor(col, row) {
    const k = cellKey(row, col);
    if (invalid.has(k)) return txt(invalid.get(k).value, '');
    if (col.format) return col.format(row);
    const v = row[col.key];
    if (col.type === 'select') {
      const hit = optionList(col, row).find((o) => String(o.value) === String(v));
      return hit ? (hit.short || hit.label) : txt(v, '');
    }
    return txt(v, '');
  }

  function renderCell(row, col, ri, ci) {
    const k = cellKey(row, col);
    const editable = isEditable(col, row);
    const classes = ['cell'];
    if (editable) classes.push('editable');
    if (col.align === 'right') classes.push('num');
    if (col.cls) classes.push(typeof col.cls === 'function' ? col.cls(row) : col.cls);
    if (dirty.has(k)) classes.push('dirty');
    if (invalid.has(k)) classes.push('invalid');
    if (saving.has(k)) classes.push('saving');
    if (ci < stickyCols) classes.push('sticky-col');
    if (col.extra) classes.push('col-extra');
    if (sel.r === ri && sel.c === ci) classes.push('selected');
    if (flashRunId && row.ai_run_id && String(row.ai_run_id) === String(flashRunId)) classes.push('ai-flash');
    const content = displayFor(col, row);
    const td = h('td', {
      class: classes.filter(Boolean).join(' '),
      dataset: { r: ri, c: ci },
      title: invalid.has(k) ? invalid.get(k).msg : null,
      style: ci < stickyCols ? { left: `var(--sticky-${ci})` } : null,
      attrs: { role: 'gridcell', tabindex: sel.r === ri && sel.c === ci ? '0' : '-1', 'aria-invalid': invalid.has(k) ? 'true' : null },
    });
    const inner = h('div.cell-inner');
    if (ci === 0 && indent) {
      const lvl = indent(row) || 0;
      if (lvl) inner.style.paddingLeft = `${lvl * 16}px`;
    }
    if (col.indentPrefix && indent && indent(row)) inner.appendChild(h('span.indent-mark', { aria: { hidden: 'true' } }, '└ '));
    if (content instanceof Node) inner.appendChild(content);
    else inner.appendChild(h('span.cell-text', content === '' ? (col.placeholder && editable ? '' : '') : content));
    if (col.aiTag && isAi && isAi(row)) {
      inner.appendChild(aiTag(editedRows.has(`${gridKey}:${row[rowKey]}`) ? 'Edited' : 'AI'));
    }
    if (col.after) {
      const extra = col.after(row);
      if (extra) inner.appendChild(extra);
    }
    td.appendChild(inner);
    return td;
  }

  function renderRow(row, ri) {
    const tr = h('tr', { dataset: { id: row[rowKey] }, class: rowClass ? rowClass(row) : null });
    columns.forEach((col, ci) => tr.appendChild(renderCell(row, col, ri, ci)));
    if (rowActions) tr.appendChild(h('td.row-actions', rowActions(row) || ''));
    return tr;
  }

  function renderBody() {
    editing = null;
    mount(tbody);
    if (!rows.length) {
      tbody.appendChild(h('tr.grid-empty', h('td', { colSpan: columns.length + (rowActions ? 1 : 0) }, emptyText)));
    } else {
      rows.forEach((row, ri) => tbody.appendChild(renderRow(row, ri)));
    }
    renderNote();
  }

  function rerenderRow(ri) {
    const old = tbody.children[ri];
    if (!old || !rows[ri]) return;
    const fresh = renderRow(rows[ri], ri);
    tbody.replaceChild(fresh, old);
  }

  function renderNote() {
    const msgs = Array.from(new Set(Array.from(invalid.values()).map((v) => v.msg)));
    note.hidden = !msgs.length;
    mount(note, ...msgs.map((m) => h('div', '⚠ ', m)));
  }

  function cellEl(ri, ci) {
    const tr = tbody.children[ri];
    return tr ? tr.children[ci] : null;
  }

  function select(ri, ci, focus = true) {
    const prev = cellEl(sel.r, sel.c);
    if (prev) { prev.classList.remove('selected'); prev.setAttribute('tabindex', '-1'); }
    sel = { r: ri, c: ci };
    const td = cellEl(ri, ci);
    if (td) {
      td.classList.add('selected');
      td.setAttribute('tabindex', '0');
      if (focus) td.focus({ preventScroll: false });
    }
  }

  function startEdit(ri, ci, initialChar) {
    const row = rows[ri];
    const col = columns[ci];
    if (!row || !col || !isEditable(col, row)) return;
    const td = cellEl(ri, ci);
    if (!td) return;
    if (editing) commitEdit(false);
    const k = cellKey(row, col);
    const current = invalid.has(k) ? invalid.get(k).value : row[col.key];
    let input;
    if (col.type === 'select') {
      input = h('select.cell-editor', { aria: { label: col.label } });
      const opts2 = optionList(col, row);
      if (col.allowEmpty !== false) input.appendChild(h('option', { value: '' }, col.emptyLabel || '—'));
      let found = false;
      for (const o of opts2) {
        const selected = String(o.value) === String(current ?? '');
        if (selected) found = true;
        input.appendChild(h('option', { value: String(o.value), selected }, o.label));
      }
      if (!found && current !== null && current !== undefined && current !== '') {
        input.appendChild(h('option', { value: String(current), selected: true }, String(current)));
      }
    } else if (col.type === 'textarea') {
      input = h('textarea.cell-editor', { rows: 3, value: current ?? '', aria: { label: col.label } });
    } else {
      const type = col.type === 'number' ? 'number' : col.type === 'date' ? 'date' : 'text';
      input = h('input.cell-editor', {
        type, value: current ?? '', aria: { label: col.label },
        min: col.min ?? null, max: col.max ?? null, step: col.step ?? null, placeholder: col.placeholder || null,
      });
      if (initialChar && type === 'text') input.value = initialChar;
    }
    const inner = td.querySelector('.cell-inner');
    td.classList.add('is-editing');
    inner.hidden = true;
    td.appendChild(input);
    editing = { ri, ci, input, td, original: current };
    input.focus();
    if (input.select && col.type !== 'select' && !initialChar) input.select();

    input.addEventListener('keydown', (e) => {
      if (['Escape', 'Enter', 'Tab'].includes(e.key)) e.stopPropagation();
      if (e.key === 'Escape') { e.preventDefault(); cancelEdit(); }
      else if (e.key === 'Enter' && !(col.type === 'textarea' && e.shiftKey)) { e.preventDefault(); commitEdit(true, 'down'); }
      else if (e.key === 'Tab') { e.preventDefault(); commitEdit(true, e.shiftKey ? 'left' : 'right'); }
    });
    input.addEventListener('blur', () => { setTimeout(() => { if (editing && editing.input === input) commitEdit(false); }, 0); });
    if (col.type === 'select') input.addEventListener('change', () => commitEdit(true, null));
  }

  function cancelEdit() {
    if (!editing) return;
    const { ri, ci } = editing;
    editing = null;
    rerenderRow(ri);
    select(ri, ci);
  }

  function parseValue(col, raw) {
    if (col.parse) return col.parse(raw);
    if (col.type === 'number') {
      if (raw === '' || raw === null) return null;
      const n = Number(raw);
      return Number.isFinite(n) ? n : raw;
    }
    if (col.type === 'select') {
      if (raw === '') return null;
      const sample = optionList(col, rows[0] || {}).find((o) => String(o.value) === raw);
      return sample ? sample.value : raw;
    }
    return typeof raw === 'string' ? (col.type === 'date' && raw === '' ? null : raw) : raw;
  }

  function commitEdit(move, dir) {
    if (!editing) return;
    const { ri, ci, input } = editing;
    editing = null;
    const row = rows[ri];
    const col = columns[ci];
    const value = parseValue(col, input.value);
    const k = cellKey(row, col);
    const prospective = { ...row, [col.key]: value };
    const msg = col.validate ? col.validate(value, prospective) : '';
    if (msg) {
      invalid.set(k, { value: input.value, msg });
    } else {
      invalid.delete(k);
      if (!sameValue(value, row[col.key])) {
        const oldValue = row[col.key];
        row[col.key] = value;
        dirty.set(k, true);
        if (isAi && isAi(row)) editedRows.add(`${gridKey}:${row[rowKey]}`);
        if (onCommit) {
          saving.add(k);
          Promise.resolve(onCommit(row, col.key, value, oldValue)).catch(() => {}).finally(() => saving.delete(k));
        }
      }
    }
    rerenderRow(ri);
    renderNote();
    if (move) {
      const next = neighbour(ri, ci, dir);
      if (next) select(next.r, next.c);
      else select(ri, ci);
    } else {
      const td = cellEl(ri, ci);
      if (td) { td.classList.add('selected'); td.setAttribute('tabindex', '0'); }
    }
  }

  function neighbour(ri, ci, dir) {
    if (!dir) return { r: ri, c: ci };
    if (dir === 'down') return ri + 1 < rows.length ? { r: ri + 1, c: ci } : null;
    if (dir === 'up') return ri > 0 ? { r: ri - 1, c: ci } : null;
    const step = dir === 'left' ? -1 : 1;
    let r = ri;
    let c = ci + step;
    while (r >= 0 && r < rows.length) {
      const cols = editableCols(rows[r]).map((x) => x.i);
      const candidates = step > 0 ? cols.filter((i) => i >= c) : cols.filter((i) => i <= c).reverse();
      if (candidates.length) return { r, c: candidates[0] };
      r += step;
      c = step > 0 ? 0 : columns.length - 1;
    }
    return null;
  }

  table.addEventListener('click', (e) => {
    if (e.target.closest('.row-actions') || e.target.closest('button, a')) return;
    const td = e.target.closest('td[data-r]');
    if (!td || td.classList.contains('is-editing')) return;
    const ri = Number(td.dataset.r);
    const ci = Number(td.dataset.c);
    select(ri, ci);
    if (td.classList.contains('editable')) startEdit(ri, ci);
  });

  table.addEventListener('keydown', (e) => {
    if (editing || !e.target.isConnected) return;
    const td = e.target.closest && e.target.closest('td[data-r]');
    if (!td) return;
    const ri = Number(td.dataset.r);
    const ci = Number(td.dataset.c);
    const moves = { ArrowDown: [1, 0], ArrowUp: [-1, 0], ArrowRight: [0, 1], ArrowLeft: [0, -1] };
    if (moves[e.key]) {
      e.preventDefault();
      const [dr, dc] = moves[e.key];
      const r = Math.max(0, Math.min(rows.length - 1, ri + dr));
      const c = Math.max(0, Math.min(columns.length - 1, ci + dc));
      select(r, c);
    } else if (e.key === 'Enter' || e.key === 'F2') {
      e.preventDefault();
      startEdit(ri, ci);
    } else if (e.key === 'Tab') {
      const next = neighbour(ri, ci, e.shiftKey ? 'left' : 'right');
      if (next) { e.preventDefault(); select(next.r, next.c); }
    } else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
      const col = columns[ci];
      if (col && (col.type === 'text' || col.type === 'textarea' || col.type === 'number') && isEditable(col, rows[ri])) {
        e.preventDefault();
        startEdit(ri, ci, col.type === 'text' ? e.key : undefined);
      }
    }
  });

  renderHead();
  table.append(thead, tbody);
  renderBody();
  if (footer) wrap.appendChild(h('div.grid-footer', footer));

  return {
    el: wrap,
    table,
    getRows: () => rows,
    setRows(next, { flash } = {}) {
      rows = next || [];
      if (flash !== undefined) flashRunId = flash;
      dirty.clear();
      invalid.clear();
      sel = { r: -1, c: -1 };
      renderBody();
    },
    /** Replace a row by key (e.g. with the server copy) without touching dirty marks of other rows. */
    updateRow(row, { keepDirty = false } = {}) {
      const ri = rows.findIndex((r) => String(r[rowKey]) === String(row[rowKey]));
      if (ri < 0) return;
      rows[ri] = { ...rows[ri], ...row };
      if (!keepDirty) for (const col of columns) dirty.delete(cellKey(rows[ri], col));
      if (!editing || editing.ri !== ri) rerenderRow(ri);
    },
    markSaved(rowId) {
      for (const k of Array.from(dirty.keys())) if (k.startsWith(`${rowId}:`)) dirty.delete(k);
      const ri = rows.findIndex((r) => String(r[rowKey]) === String(rowId));
      if (ri >= 0 && (!editing || editing.ri !== ri)) rerenderRow(ri);
    },
    markAllSaved() {
      dirty.clear();
      rows.forEach((_, ri) => { if (!editing || editing.ri !== ri) rerenderRow(ri); });
    },
    markError(rowId, key, msg) {
      const row = rows.find((r) => String(r[rowKey]) === String(rowId));
      if (!row) return;
      invalid.set(`${rowId}:${key}`, { value: row[key], msg });
      const ri = rows.indexOf(row);
      rerenderRow(ri);
      renderNote();
    },
    hasInvalid: () => invalid.size > 0,
    isDirty: () => dirty.size > 0,
    /** Briefly highlight rows (e.g. dates shifted by a dependency). */
    pulseRows(ids, cls = 'row-pulse') {
      const set = new Set(ids.map(String));
      Array.from(tbody.children).forEach((tr) => {
        if (set.has(tr.dataset.id)) {
          tr.classList.remove(cls);
          void tr.offsetWidth;
          tr.classList.add(cls);
        }
      });
    },
    selectRowById(id) {
      const ri = rows.findIndex((r) => String(r[rowKey]) === String(id));
      if (ri >= 0) {
        select(ri, 0);
        tbody.children[ri].scrollIntoView({ block: 'center', behavior: 'smooth' });
        this.pulseRows([id]);
      }
    },
  };
}

/** Forget "Edited" markers (after a reset). */
export function clearEditedMarks() {
  editedRows.clear();
}
