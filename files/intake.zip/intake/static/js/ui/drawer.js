// drawer.js: right-hand drawer host (380px). The Assistant mounts into it; Esc closes it.
// At >=1600px the drawer pushes the content; below that it overlays with a scrim.
import { h, mount } from './dom.js';

let shell = null;
let current = null;

function ensure() {
  if (shell && document.body.contains(shell.root)) return shell;
  const title = h('h2.drawer-title');
  const sub = h('div.drawer-sub');
  const headExtra = h('div.drawer-head-extra');
  const body = h('div.drawer-body');
  const closeBtn = h('button.icon-btn.drawer-close', { type: 'button', aria: { label: 'Close panel' } }, '✕');
  const root = h('aside.drawer', { attrs: { 'aria-hidden': 'true', role: 'complementary' } },
    h('div.drawer-head', h('div.drawer-head-text', title, sub), headExtra, closeBtn),
    body);
  const scrim = h('div.drawer-scrim');
  closeBtn.addEventListener('click', () => close());
  scrim.addEventListener('click', () => close());
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && root.classList.contains('open') && !document.body.classList.contains('modal-open')) close();
  });
  document.body.append(scrim, root);
  shell = { root, scrim, title, sub, body, headExtra };
  return shell;
}

/**
 * openDrawer({key, title, subtitle, render(bodyEl), headExtra}) -> {body, close}
 * When the same key is already open the body is kept (so the assistant conversation survives).
 */
export function openDrawer({ key, title, subtitle, render, headExtra } = {}) {
  const s = ensure();
  s.title.textContent = title || '';
  s.sub.textContent = subtitle || '';
  if (headExtra !== undefined) mount(s.headExtra, headExtra);
  if (current !== key) {
    mount(s.body);
    current = key;
    if (render) render(s.body);
  }
  s.root.classList.add('open');
  s.root.setAttribute('aria-hidden', 'false');
  s.scrim.classList.add('open');
  document.body.classList.add('drawer-open');
  return { body: s.body, close };
}

export function setDrawerSubtitle(text) {
  if (shell) shell.sub.textContent = text || '';
}

export function close() {
  if (!shell) return;
  shell.root.classList.remove('open');
  shell.root.setAttribute('aria-hidden', 'true');
  shell.scrim.classList.remove('open');
  document.body.classList.remove('drawer-open');
}

export function isOpen(key) {
  return Boolean(shell && shell.root.classList.contains('open') && (key === undefined || key === current));
}

/** Body element for a drawer key (creating the shell if needed) without opening it. */
export function drawerBody() {
  return ensure().body;
}

export const closeDrawer = close;
