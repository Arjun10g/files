// ai_card.js: the shared AI Result Card (UX 2.7) and runAiFeature(), used by every yellow button.
// Flow: thinking steps -> proposal card (confidence, mode, sources, warnings) -> Accept / Edit before
// accepting / Regenerate / Discard. Nothing is written until Accept (POST /api/ai-runs/{id}/apply).
import * as api from '../api.js';
import { state } from '../state.js';
import { fmtSeconds } from '../dates.js';
import { h, reducedMotion, sleep, mount } from './dom.js';
import { btn, confidencePill, confidenceBand, modeChip, footerNoteForMode } from './components.js';
import { toast, toastError } from './toast.js';
import { featureMeta, stepDurations } from './thinking.js';

const running = new WeakMap();
/** Features whose verdicts come from rules, so no confidence is shown (decision 11). */
const DETERMINISTIC = new Set(['cr_compliance']);

const TABLE_WORDS = {
  initiative_components: ['component', 'components'], components: ['component', 'components'],
  wbs_tasks: ['plan step', 'plan steps'], tasks: ['plan step', 'plan steps'],
  risks: ['risk', 'risks'], allocations: ['allocation', 'allocations'],
  change_requests: ['change request', 'change requests'], decisions: ['decision', 'decisions'],
  resource_skills: ['skill rating', 'skill ratings'], notifications: ['reminder', 'reminders'],
  lessons_learned: ['lesson', 'lessons'], initiatives: ['initiative field', 'initiative fields'],
};

/** "Change Summary accepted · 4 components added." */
export function acceptMessage(title, result) {
  const applied = (result && result.applied) || {};
  const parts = [];
  for (const [table, n] of Object.entries(applied)) {
    if (typeof n !== 'number' || n <= 0) continue;
    const words = TABLE_WORDS[table];
    if (!words) continue;
    if (table === 'initiatives' || table === 'change_requests') parts.push(`${n === 1 ? words[0] : words[1]} updated`);
    else parts.push(`${n} ${n === 1 ? words[0] : words[1]} added`);
  }
  return parts.length ? `${title} accepted · ${parts.join(' · ')}.` : `${title} accepted.`;
}

/** Reveal text in 2–4 character chunks with a caret (skipped for reduced motion / Fast). */
export function streamText(el, text) {
  const value = String(text ?? '');
  if (!value) { el.textContent = ''; return Promise.resolve(); }
  if (reducedMotion() || state.aiSpeed() === 'Fast') { el.textContent = value; return Promise.resolve(); }
  el.textContent = '';
  const textNode = document.createTextNode('');
  const caret = h('span.caret', { aria: { hidden: 'true' } }, '▌');
  el.append(textNode, caret);
  let i = 0;
  return new Promise((resolve) => {
    const tick = () => {
      if (!el.isConnected) { el.textContent = value; resolve(); return; }
      i = Math.min(value.length, i + 2 + Math.floor(Math.random() * 3));
      textNode.data = value.slice(0, i);
      if (i >= value.length) { caret.remove(); resolve(); return; }
      setTimeout(tick, 18 + Math.random() * 12);
    };
    tick();
  });
}

/** Row stagger: 120 ms per row, fade-up 4px (CSS .ai-row). */
export function stagger(el, index) {
  if (reducedMotion()) return el;
  el.classList.add('ai-row');
  el.style.animationDelay = `${Math.min(index, 20) * 120}ms`;
  return el;
}

function thinkingPanel(meta, steps, onStop) {
  const list = h('ol.thinking-steps');
  const items = steps.map((s) => {
    const li = h('li.tstep', h('span.tstep-icon', { aria: { hidden: 'true' } }, '○'), h('span.tstep-text', s));
    list.appendChild(li);
    return li;
  });
  const el = h('div.ai-thinking', { attrs: { role: 'status', 'aria-live': 'polite' } },
    h('div.ai-thinking-head',
      h('span.auto-glyph', { aria: { hidden: 'true' } }, '✦'),
      h('span.ai-thinking-title', meta.title),
      btn('Stop', { variant: 'ghost', small: true, onClick: onStop, cls: 'ai-stop' })),
    list);
  const setStep = (i, st) => {
    const li = items[i];
    if (!li) return;
    li.className = `tstep tstep-${st}`;
    const icon = li.querySelector('.tstep-icon');
    mount(icon, st === 'run' ? h('span.spinner.spinner-sm') : document.createTextNode(st === 'done' ? '✓' : '○'));
  };
  return { el, setStep, count: items.length };
}

function sourceChips(sources) {
  const list = (sources || []).filter((s) => s && s.label);
  if (!list.length) return null;
  const seen = new Set();
  const chips = [];
  for (const s of list) {
    const key = `${s.type}:${s.id}:${s.label}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const title = s.excerpt ? `“${s.excerpt}”` : null;
    chips.push(s.route
      ? h('a.source-chip', { href: s.route, title }, s.label)
      : h('span.source-chip', { title }, s.label));
    if (chips.length >= 12) break;
  }
  return h('div.ai-sources', h('span.ai-sources-label', 'Sources:'), chips);
}

function warningsBlock(warnings) {
  const list = Array.from(new Set((warnings || []).filter((w) => typeof w === 'string' && w.trim())));
  if (!list.length) return null;
  return h('div.ai-warnings', h('div.ai-warn-title', 'Check before accepting'),
    h('ul', list.map((w) => h('li', w))));
}

function setTriggerRunning(trigger, on) {
  if (!trigger) return;
  if (on) {
    trigger.dataset.aiRunning = '1';
    trigger._prevChildren = Array.from(trigger.childNodes);
    trigger.classList.add('is-running');
    mount(trigger, h('span.spinner.spinner-sm', { aria: { hidden: 'true' } }), h('span.btn-label', 'Stop'));
  } else {
    delete trigger.dataset.aiRunning;
    trigger.classList.remove('is-running');
    if (trigger._prevChildren) mount(trigger, ...trigger._prevChildren);
    trigger._prevChildren = null;
  }
}

/**
 * Run an AI feature end to end inside `container`.
 * @param {object} o
 * @param {string} o.feature            snake_case feature key (FEATURES in app/ai/schemas.py)
 * @param {number|null} o.initiativeId  initiative scope; null/undefined uses the global endpoint
 * @param {HTMLElement} o.container     where the card goes (its contents are replaced)
 * @param {(output, ctx) => Node} o.renderPreview  ctx = {run, editing, draft, selection, toggle(i), isSelected(i), stream, stagger, setDirty}
 * @param {(result, run) => any} [o.onApplied]      called after a successful Accept
 * @param {object} [o.body]             extra request body, e.g. {options:{wbs_code}}
 * @param {string} [o.title]            card title (defaults to the feature title)
 * @param {boolean} [o.selectable]      preview offers row checkboxes; Accept sends `selected`
 * @param {(output) => number} [o.selectableCount] number of selectable rows (default: all selected)
 * @param {(output) => number[]} [o.initialSelection] indices selected at first (e.g. the recommended option)
 * @param {boolean} [o.editable=true]   show "Edit before accepting"
 * @param {boolean} [o.showConfidence]  false hides the confidence pill (deterministic outputs)
 * @param {boolean} [o.acceptable=true] false for read-only results (no Accept)
 * @param {string} [o.acceptLabel]
 * @param {(result, run, applyBody) => string} [o.acceptMessage]
 * @param {HTMLElement} [o.trigger]     the yellow button; it reads "Stop" while running
 * @param {() => void} [o.onDiscard]
 * @param {(run) => Node} [o.extraActions] extra footer buttons (e.g. Copy)
 * @returns {{cancel: () => void, el: HTMLElement, done: Promise<object|null>}}
 */
export function runAiFeature(o) {
  const {
    feature, initiativeId, container, renderPreview, onApplied, body = {}, selectable = false,
    editable = true, acceptable = true, trigger, onDiscard, extraActions,
  } = o;
  const meta = featureMeta(feature);
  const title = o.title || meta.title;

  if (trigger && trigger.dataset.aiRunning === '1') {
    const ctrl = running.get(trigger);
    if (ctrl) ctrl.cancel();
    return ctrl || { cancel() {}, el: null, done: Promise.resolve(null) };
  }

  const card = h('div.ai-card', { attrs: { 'aria-live': 'polite' }, dataset: { feature } });
  mount(container, card);
  container.hidden = false;

  let abort = null;
  let stopped = false;
  const stop = () => { stopped = true; if (abort) abort.abort(); };
  let finished = false;
  let resolveDone;
  const done = new Promise((r) => { resolveDone = r; });

  const controller = {
    el: card,
    done,
    cancel() {
      stop();
    },
  };
  if (trigger) running.set(trigger, controller);

  const path = initiativeId ? `/initiatives/${initiativeId}/ai/${meta.slug}` : `/ai/${meta.slug}`;

  async function call(extraBody, short) {
    abort = new AbortController();
    stopped = false;
    const steps = short ? [meta.steps[0], meta.steps[meta.steps.length - 1]].filter((v, i, a) => a.indexOf(v) === i) : meta.steps;
    const panel = thinkingPanel({ title }, steps, stop);
    card.className = 'ai-card ai-card-thinking';
    mount(card, panel.el);
    setTriggerRunning(trigger, true);
    const started = performance.now();
    const request = api.request('POST', path, { body: { ...body, ...extraBody }, timeout: api.AI_TIMEOUT_MS, signal: abort.signal });
    let result = null;
    let error = null;
    request.then((r) => { result = r; }, (e) => { error = e; });
    const durations = stepDurations(panel.count, state.aiSpeed());
    try {
      for (let i = 0; i < panel.count; i += 1) {
        panel.setStep(i, 'run');
        const until = performance.now() + durations[i];
        while (!stopped && performance.now() < until) await sleep(Math.min(50, until - performance.now()));
        if (i === panel.count - 1 && !stopped) {
          try { await request; } catch { /* handled below */ }
        }
        if (error || stopped) break;
        panel.setStep(i, 'done');
      }
    } finally {
      setTriggerRunning(trigger, false);
    }
    if (stopped) {
      request.then((r) => { if (r && r.ai_run_id) api.rejectAiRun(r.ai_run_id, { reason: 'Stopped' }).catch(() => {}); }, () => {});
      throw new api.ApiError('Request cancelled.', { code: 'cancelled' });
    }
    if (error) throw error;
    if (!result) throw new api.ApiError('This is taking longer than expected. Try again.', { code: 'timeout' });
    result._elapsed = performance.now() - started;
    return result;
  }

  function renderError(err, retryBody) {
    card.className = 'ai-card ai-card-error';
    const stopped = err && err.code === 'cancelled';
    mount(card, 
      h('div.ai-card-head',
        h('div.ai-card-title', h('span.auto-glyph', { aria: { hidden: 'true' } }, '✦'), ` ${title}`)),
      h('p.ai-error-msg', stopped ? 'Stopped. Nothing was changed.' : (err && err.message) || 'This is taking longer than expected. Try again.'),
      h('div.ai-card-actions',
        btn(stopped ? 'Run again' : 'Try again', { variant: 'primary', onClick: () => start(retryBody, false) }),
        btn('Close', { variant: 'ghost', onClick: () => { close(); } })),
    );
  }

  function close() {
    card.remove();
    if (!container.children.length) container.hidden = true;
    if (!finished) { finished = true; resolveDone(null); }
  }

  function renderRun(run) {
    const output = run.output || {};
    const selCount = selectable ? (o.selectableCount ? o.selectableCount(output) : 0) : 0;
    const initial = selectable && o.initialSelection ? o.initialSelection(output) : null;
    const selection = new Set(Array.isArray(initial) ? initial : Array.from({ length: selCount }, (_, i) => i));
    let editing = false;
    let draft = null;
    let pendingEdit = null;
    let firstRender = true;

    if (run.mode === 'live_fallback') {
      toast('The model provider is unavailable. This proposal was generated by local rules.', { variant: 'warning' });
    }

    const previewHost = h('div.ai-preview');
    const acceptBtn = acceptable ? btn(o.acceptLabel || 'Accept', { variant: 'primary', onClick: () => accept() }) : null;
    const editBtn = acceptable && editable ? btn('Edit before accepting', { variant: 'secondary', onClick: () => { editing = true; draft = structuredClone(output); paint(); editBtn.hidden = true; } }) : null;
    const regenBtn = btn('Regenerate', { variant: 'secondary', onClick: () => { regenRow.hidden = !regenRow.hidden; if (!regenRow.hidden) regenInput.focus(); } });
    const discardBtn = btn(acceptable ? 'Discard' : 'Close', { variant: 'ghost', onClick: () => discard() });
    const regenInput = h('input.input.regen-input', { type: 'text', maxLength: 300, placeholder: 'Optional: what should change? For example, more conservative', aria: { label: 'Regenerate instruction' } });
    const regenRow = h('div.regen-row', { hidden: true }, regenInput,
      btn('Regenerate', { variant: 'primary', small: true, onClick: () => regenerate() }),
      btn('Cancel', { variant: 'ghost', small: true, onClick: () => { regenRow.hidden = true; } }));
    regenInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); regenerate(); } });

    const rulesCheck = DETERMINISTIC.has(feature);
    const deterministic = o.showConfidence === false || rulesCheck || run.mode === 'simulated_generated';
    const conf = deterministic ? undefined : (typeof run.confidence === 'number' ? run.confidence : output.confidence);
    const band = confidenceBand(conf);
    const elapsed = typeof run.latency_ms === 'number' && run.latency_ms > 0 && (run.mode === 'live' || run.mode === 'live_fallback')
      ? run.latency_ms : run._elapsed;

    card.className = 'ai-card ai-card-result';
    mount(card, 
      h('div.ai-card-head',
        rulesCheck
          ? h('div.ai-card-title', `Rules check · ${title}`)
          : h('div.ai-card-title', h('span.auto-glyph', { aria: { hidden: 'true' } }, '✦'), ` AI suggestion · ${title}`),
        h('div.ai-card-meta',
          rulesCheck ? h('span.rules-badge', { title: 'Pass/Fail comes from the change rules, not from AI' }, 'Rules check') : h('span.ai-review-label', 'AI-generated — review before use'),
          conf !== undefined ? h('span.ai-conf', 'Confidence ', confidencePill(conf)) : null,
          band && band.band === 'Low' ? h('span.ai-low-note', 'Review carefully') : null,
          rulesCheck ? null : modeChip(run.mode, run.mode_label),
          elapsed ? h('span.ai-latency', fmtSeconds(elapsed)) : null)),
      previewHost,
      sourceChips(run.sources && run.sources.length ? run.sources : output.sources),
      warningsBlock([...(run.warnings || []), ...(output.warnings || [])]),
      h('div.ai-card-actions',
        acceptBtn, editBtn, regenBtn, extraActions ? extraActions(run) : null,
        h('span.spacer'), discardBtn),
      regenRow,
      h('div.ai-card-foot', rulesCheck ? 'Checked against the change rules; the reviewer note is drafted from the results.' : footerNoteForMode(run.mode)),
    );

    function paint() {
      const ctx = {
        run,
        editing,
        draft: editing ? draft : output,
        selection,
        isSelected: (i) => selection.has(i),
        toggle: (i, on) => {
          if (on === undefined ? !selection.has(i) : on) selection.add(i); else selection.delete(i);
          if (acceptBtn) acceptBtn.disabled = selectable && selection.size === 0;
        },
        selectOnly: (i) => {
          selection.clear();
          selection.add(i);
          if (acceptBtn) acceptBtn.disabled = selectable && selection.size === 0;
        },
        stream: firstRender ? streamText : (el, text) => { el.textContent = String(text ?? ''); return Promise.resolve(); },
        stagger: firstRender ? stagger : (el) => el,
        accept: (extra) => accept(extra),
        /** Record a user choice made in the preview (e.g. a chosen candidate); Accept sends it as edited_output. */
        setEditedOutput: (obj) => { pendingEdit = obj; },
      };
      let node;
      try {
        node = renderPreview ? renderPreview(editing ? draft : output, ctx) : null;
      } catch (err) {
        node = h('p.muted', 'This suggestion could not be displayed. Regenerate to try again.');
        window.dispatchEvent(new CustomEvent('bmo:error', { detail: err }));
      }
      mount(previewHost, node || h('span'));
      firstRender = false;
    }
    paint();

    async function accept(extra = {}) {
      if (!acceptBtn && !extra.force) return;
      const restore = [acceptBtn, editBtn, regenBtn, discardBtn].filter(Boolean).map((b) => { const d = b.disabled; b.disabled = true; return () => { b.disabled = d; }; });
      const bodyApply = {};
      if (selectable && !extra.selected) bodyApply.selected = Array.from(selection).sort((a, b) => a - b);
      if (extra.selected) bodyApply.selected = extra.selected;
      if (editing && draft) bodyApply.edited_output = draft;
      if (extra.edited_output) bodyApply.edited_output = extra.edited_output;
      if (!bodyApply.edited_output && pendingEdit) bodyApply.edited_output = pendingEdit;
      try {
        const result = await api.applyAiRun(run.ai_run_id, bodyApply);
        state.flashRunId = run.ai_run_id;
        const msg = o.acceptMessage ? o.acceptMessage(result, run, bodyApply) : acceptMessage(title, result);
        toast(msg);
        state.emit('ai:applied', { feature, run, result });
        card.className = 'ai-card ai-card-accepted';
        mount(card, h('div.ai-accepted-line',
          h('span.ok-mark', { aria: { hidden: 'true' } }, '✓'),
          h('span', msg),
          h('span.muted', ` · ${footerNoteForMode(run.mode)}`),
          h('button.link.ai-accepted-close', { type: 'button', on: { click: () => close() } }, 'Hide')));
        finished = true;
        resolveDone({ run, result });
        if (onApplied) await onApplied(result, run);
      } catch (err) {
        restore.forEach((fn) => fn());
        if (err && err.status === 409) toast('This suggestion was already used or replaced. Regenerate for a fresh one.', { variant: 'warning' });
        else toastError(err);
      }
    }

    function discard() {
      if (acceptable && run.ai_run_id) api.rejectAiRun(run.ai_run_id, { reason: 'Discarded' }).catch(() => {});
      close();
      onDiscard?.();
    }

    function regenerate() {
      const instruction = regenInput.value.trim();
      const extraBody = { regen_of: run.ai_run_id };
      if (instruction) extraBody.instruction = instruction;
      start(extraBody, true);
    }
  }

  async function start(extraBody = {}, short = false) {
    try {
      const run = await call(extraBody, short);
      renderRun(run);
    } catch (err) {
      renderError(err, extraBody);
    }
  }

  start({}, false);
  return controller;
}

/**
 * Deterministic automation (no AI): show a single short build step, then run fn().
 * Used for Generate Gantt view and Create CRQ draft so they do not look like AI.
 */
export async function runBuildStep(container, label, fn) {
  const panel = h('div.build-step', { attrs: { role: 'status' } }, h('span.spinner.spinner-sm', { aria: { hidden: 'true' } }), h('span', label));
  if (container) { container.hidden = false; mount(container, panel); }
  try {
    const [result] = await Promise.all([fn(), sleep(state.aiSpeed() === 'Fast' ? 100 : 300)]);
    return result;
  } finally {
    panel.remove();
  }
}
