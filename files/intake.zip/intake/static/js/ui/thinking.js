// thinking.js: client copy of the thinking steps in app/ai/schemas.py FEATURES (keep in sync).
// Shown for 1.5–3 s ("Realistic") or 0.3 s ("Fast") while the AI call runs.

export const FEATURE_META = {
  intake_analysis: {
    title: 'Intake Analysis', slug: 'intake-analysis',
    steps: ['Reading intake details…', 'Checking required information…', 'Looking for similar initiatives…', 'Drafting clarifying questions…'],
  },
  change_summary: {
    title: 'Change Summary', slug: 'change-summary',
    steps: ['Reading SA document…', 'Identifying impacted DC components…', 'Matching components to approvers…', 'Drafting change summary…', 'Scoring SA completeness…'],
  },
  l2_estimate: {
    title: 'L2 Estimate', slug: 'l2-estimate',
    steps: ['Reading change summary…', 'Applying L2 hours by complexity…', 'Comparing with past initiatives…', 'Writing estimate rationale…'],
  },
  wbs: {
    title: 'Project Plan', slug: 'wbs',
    steps: ['Reading change summary…', 'Applying DC WBS template…', 'Sequencing dependencies…', 'Mapping downstream impacts…', 'Estimating effort from L2…', 'Proposing owners…'],
  },
  resources: {
    title: 'Suggested Resources', slug: 'resources',
    steps: ['Checking skill matrix…', 'Checking availability…', 'Ranking candidates…'],
  },
  rebalance: {
    title: 'Resource Fix', slug: 'rebalance',
    steps: ['Finding over-allocated months…', 'Checking who has spare capacity…', 'Comparing before and after…'],
  },
  risks: {
    title: 'Risk Prediction', slug: 'risks',
    steps: ['Reviewing plan dates and allocations…', 'Comparing with past initiatives…', 'Rating severity and likelihood…'],
  },
  exec_summary: {
    title: 'Executive Summary', slug: 'exec-summary',
    steps: ['Collecting health and milestones…', "Checking this week's changes…", 'Writing the summary…'],
  },
  cr_compliance: {
    title: 'CR Compliance', slug: 'cr-compliance',
    steps: ['Reading change request…', 'Checking approvals and evidence…', 'Checking release window…', 'Writing reviewer note…'],
  },
  skill_matrix: {
    title: 'Skill Matrix', slug: 'skill-matrix',
    steps: ['Reading past WBS assignments…', 'Mapping work to skills…', 'Rating skill levels…'],
  },
  nudges: {
    title: 'Reminders', slug: 'nudges',
    steps: ['Finding pending actions and approvals…', 'Grouping by recipient…', 'Drafting reminders…'],
  },
  meeting_extract: {
    title: 'Meeting Actions', slug: 'meeting-extract',
    steps: ['Reading meeting notes…', 'Finding decisions…', 'Finding actions and owners…'],
  },
  lessons: {
    title: 'Lessons Learned', slug: 'lessons',
    steps: ['Comparing planned and actual effort…', 'Reviewing risks and decisions…', 'Drafting lessons…'],
  },
  intake_autofill: {
    title: 'Intake Autofill', slug: 'intake-autofill',
    steps: ['Reading SA document…', 'Finding intake details…', 'Filling the form…'],
  },
  assistant: {
    title: 'Assistant', slug: 'assistant',
    steps: ['Understanding the question…', 'Checking portfolio records…', 'Writing the answer…'],
  },
};

/** Deterministic step for non-AI automation (Generate Gantt view, CRQ draft). */
export const BUILD_STEPS = {
  gantt: ['Building timeline…'],
  crq: ['Building CRQ draft from the plan…'],
};

export function featureMeta(feature) {
  return FEATURE_META[feature] || { title: 'AI suggestion', slug: String(feature || '').replace(/_/g, '-'), steps: ['Working…'] };
}

/**
 * Per-step durations (ms) for a run. Realistic: 400–900 ms per step, total clamped to 1.5–3 s.
 * Fast: 0.3 s total. Short (regenerate): first and last step only.
 */
export function stepDurations(count, speed) {
  if (count <= 0) return [];
  if (speed === 'Fast') return Array(count).fill(Math.round(300 / count));
  const raw = Array.from({ length: count }, () => 400 + Math.random() * 500);
  const sum = raw.reduce((a, b) => a + b, 0);
  const target = Math.min(3000, Math.max(1500, sum));
  return raw.map((ms) => Math.round((ms / sum) * target));
}
