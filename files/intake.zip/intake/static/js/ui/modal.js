// modal.js: 560px dialog for destructive or blocking actions, plus small form prompts.
import { h } from './dom.js';

let openCount = 0;
const openClosers = new Set();

/**
 * openModal({title, body: Node|string, actions:[{label, variant:'primary'|'secondary'|'danger', onClick, closes}], onClose, width})
 * onClick may return a promise; returning false keeps the modal open.
 * @returns {{close: () => void, el: HTMLElement}}
 */
export function openModal({ title, body, actions = [], onClose, width } = {}) {
  const previous = document.activeElement;
  const scrim = h('div.modal-scrim');
  const titleId = `modal-title-${Date.now()}`;
  const dialog = h('div.modal', { attrs: { role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': titleId }, style: width ? { width: `${width}px` } : null });
  const footer = h('div.modal-footer');
  let closed = false;

  const close = () => {
    if (closed) return;
    closed = true;
    openClosers.delete(close);
    document.removeEventListener('keydown', onKey, true);
    scrim.remove();
    openCount = Math.max(0, openCount - 1);
    if (!openCount) document.body.classList.remove('modal-open');
    onClose?.();
    if (previous && typeof previous.focus === 'function') previous.focus();
  };

  function onKey(e) {
    if (e.key === 'Escape') {
      e.stopPropagation();
      close();
    } else if (e.key === 'Tab') {
      const focusables = dialog.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
      if (!focusables.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  }

  for (const action of actions) {
    const btn = h(`button.btn.btn-${action.variant || 'secondary'}`, { type: 'button' }, action.label);
    btn.addEventListener('click', async () => {
      if (!action.onClick) { close(); return; }
      btn.disabled = true;
      try {
        const result = await action.onClick({ close, dialog });
        if (result !== false && action.closes !== false) close();
      } finally {
        btn.disabled = false;
      }
    });
    footer.appendChild(btn);
  }

  dialog.append(
    h('div.modal-header', h('h2.modal-title', { id: titleId }, title || ''),
      h('button.icon-btn.modal-x', { type: 'button', aria: { label: 'Close' }, on: { click: close } }, '✕')),
    h('div.modal-body', typeof body === 'string' ? h('p', body) : body),
    footer,
  );
  scrim.appendChild(dialog);
  scrim.addEventListener('mousedown', (e) => { if (e.target === scrim) close(); });
  document.body.appendChild(scrim);
  document.body.classList.add('modal-open');
  openCount += 1;
  openClosers.add(close);
  document.addEventListener('keydown', onKey, true);
  const firstField = dialog.querySelector('input, select, textarea');
  (firstField || footer.querySelector('.btn-primary, .btn-danger') || dialog).focus?.();
  return { close, el: dialog };
}

/** Confirm dialog. Resolves true when confirmed. */
export function confirmModal({ title, message, confirmLabel = 'Confirm', danger = false, cancelLabel = 'Cancel' }) {
  return new Promise((resolve) => {
    let answered = false;
    openModal({
      title,
      body: message,
      onClose: () => { if (!answered) resolve(false); },
      actions: [
        { label: cancelLabel, variant: 'secondary' },
        { label: confirmLabel, variant: danger ? 'danger' : 'primary', onClick: () => { answered = true; resolve(true); } },
      ],
    });
  });
}

/**
 * Form prompt. fields: [{name, label, type:'text'|'textarea'|'select'|'date', options:[{value,label}], required, value, hint}]
 * Resolves with {name: value} or null when cancelled.
 */
export function promptModal({ title, intro, fields, submitLabel = 'Save', danger = false }) {
  return new Promise((resolve) => {
    let answered = false;
    const inputs = {};
    const errors = {};
    const form = h('form.modal-form', { on: { submit: (e) => e.preventDefault() } });
    if (intro) form.appendChild(h('p.modal-intro', intro));
    for (const f of fields) {
      let input;
      if (f.type === 'textarea') {
        input = h('textarea.input', { name: f.name, rows: f.rows || 4, value: f.value ?? '', placeholder: f.placeholder || '' });
      } else if (f.type === 'select') {
        input = h('select.input', { name: f.name },
          (f.options || []).map((o) => h('option', { value: o.value ?? '', selected: String(o.value ?? '') === String(f.value ?? '') }, o.label)));
      } else {
        input = h('input.input', { name: f.name, type: f.type || 'text', value: f.value ?? '', placeholder: f.placeholder || '' });
      }
      inputs[f.name] = input;
      errors[f.name] = h('div.field-error', { hidden: true });
      form.appendChild(h('label.form-field',
        h('span.form-label', f.label, f.required ? h('span.req', { aria: { hidden: 'true' } }, ' *') : null),
        input,
        f.hint ? h('span.form-hint', f.hint) : null,
        errors[f.name]));
    }
    openModal({
      title,
      body: form,
      onClose: () => { if (!answered) resolve(null); },
      actions: [
        { label: 'Cancel', variant: 'secondary' },
        {
          label: submitLabel,
          variant: danger ? 'danger' : 'primary',
          onClick: () => {
            const values = {};
            let ok = true;
            for (const f of fields) {
              const v = inputs[f.name].value;
              values[f.name] = typeof v === 'string' ? v.trim() : v;
              const missing = f.required && !values[f.name];
              errors[f.name].hidden = !missing;
              errors[f.name].textContent = missing ? `${f.label} is required.` : '';
              inputs[f.name].classList.toggle('invalid', Boolean(missing));
              if (missing) ok = false;
            }
            if (!ok) return false;
            answered = true;
            resolve(values);
            return true;
          },
        },
      ],
    });
  });
}

/** Close every open modal (main.js calls this on route change; the assistant drawer is not a modal). */
export function closeAllModals() {
  for (const close of Array.from(openClosers)) close();
}
