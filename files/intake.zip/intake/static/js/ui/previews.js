// previews.js: AI Result Card bodies for the workspace features. Each is (output, ctx) => Node.
// ctx comes from runAiFeature: {editing, draft, isSelected, toggle, selectOnly, stream, stagger, accept}.
import { state } from '../state.js';
import { fmtShort, fmtHours, fmtPct, fmtDate, fmtMonth } from '../dates.js';
import { h, txt } from './dom.js';
import { statusPill, meter, chip, ragPill, btn } from './components.js';

const SEV = { 1: 'Low', 2: 'Medium', 3: 'High', 4: 'Critical' };
const LIK = { 1: 'Rare', 2: 'Unlikely', 3: 'Possible', 4: 'Likely' };

export function componentName(code, fallbackName) {
  if (fallbackName) return fallbackName;
  const hit = state.components().find((c) => c.code === code);
  return hit ? hit.name : txt(code);
}

function sevLabel(v) { return state.label('risk_severity', v) || SEV[v] || txt(v); }
function likLabel(v) { return state.label('risk_likelihood', v) || LIK[v] || txt(v); }

function checkbox(ctx, i, label) {
  const cb = h('input', { type: 'checkbox', checked: ctx.isSelected(i), aria: { label: label || `Include row ${i + 1}` } });
  cb.addEventListener('change', () => ctx.toggle(i, cb.checked));
  return cb;
}

function textInput(obj, key, { type = 'text', min, max, step, width } = {}) {
  const input = h('input.input.input-sm', { type, value: obj[key] ?? '', min: min ?? null, max: max ?? null, step: step ?? null, style: width ? { width: `${width}px` } : null });
  input.addEventListener('input', () => {
    if (type === 'number') {
      const n = Number(input.value);
      obj[key] = input.value === '' ? null : (Number.isFinite(n) ? n : obj[key]);
    } else obj[key] = input.value;
  });
  return input;
}

function textArea(obj, key, rows = 2) {
  const ta = h('textarea.input.input-sm', { rows, value: obj[key] ?? '' });
  ta.addEventListener('input', () => { obj[key] = ta.value; });
  return ta;
}

function selectInput(obj, key, options, { numeric } = {}) {
  const sel = h('select.input.input-sm', options.map((o) => h('option', { value: String(o.value), selected: String(o.value) === String(obj[key]) }, o.label)));
  sel.addEventListener('change', () => { obj[key] = numeric ? Number(sel.value) : sel.value; });
  return sel;
}

function opts(category, fallback) {
  const list = state.options(category);
  return list.length ? list : fallback.map((v) => (typeof v === 'object' ? v : { value: v, label: String(v) }));
}

function listBlock(title, items, render = (x) => x) {
  const list = (items || []).filter(Boolean);
  if (!list.length) return null;
  return h('div.ai-block', h('div.ai-block-title', title), h('ul.ai-list', list.map((x) => h('li', render(x)))));
}

function streamed(ctx, text, tag = 'p.ai-text') {
  const el = h(tag);
  ctx.stream(el, text);
  return el;
}

// ------------------------------------------------------------------ F1 intake analysis
export function previewIntakeAnalysis(out, ctx) {
  const readinessTone = out.readiness === 'Ready for grooming' ? 'green' : out.readiness === 'Not ready' ? 'red' : 'amber';
  const dupes = out.possible_duplicates || [];
  const comps = out.likely_components || [];
  const questions = out.clarifying_questions || [];
  const counts = [
    comps.length ? `${comps.length} likely DC component${comps.length === 1 ? '' : 's'}` : null,
    questions.length ? `${questions.length} clarifying question${questions.length === 1 ? '' : 's'}` : null,
    dupes.length ? `${dupes.length} possible duplicate${dupes.length === 1 ? '' : 's'}` : 'no duplicates found',
  ].filter(Boolean).join(' · ');
  return h('div.preview',
    h('div.ai-summary-row',
      h(`span.pill.pill-status.pill-${readinessTone}`, txt(out.readiness)),
      h('span.ai-inline-label', 'Completeness'), meter(out.completeness_score),
      out.suggested_priority ? chip(`Suggested priority P${out.suggested_priority}`, { tone: 'grey' }) : null,
      h('span.muted.small', counts)),
    streamed(ctx, out.summary),
    h('details.ai-details', { open: ctx.editing || null },
      h('summary.link.small', 'Show details'),
      (out.suggested_labels || []).length
        ? h('div.ai-block', h('div.ai-block-title', 'Suggested labels'), h('div.chip-row', out.suggested_labels.map((l) => chip(l, { tone: 'blue' }))))
        : null,
      comps.length
        ? h('div.ai-block', h('div.ai-block-title', 'Likely DC components'),
          h('table.mini-table', h('tbody', comps.map((c) => h('tr',
            h('td.strong', componentName(c.component_code)), h('td', statusPill(c.complexity)), h('td', c.reason))))))
        : null,
      h('div.ai-block', h('div.ai-block-title', 'Possible duplicates'),
        dupes.length
          ? h('ul.ai-list', dupes.map((d) => h('li', h('a.link', { href: '#/search?q=' + encodeURIComponent(d.rddc) }, d.rddc), ` ${d.name} · ${fmtPct(d.similarity * 100)} similar · ${d.reason}`)))
          : h('p.muted', 'None found.')),
      questions.length
        ? h('div.ai-block', h('div.ai-block-title', 'Clarifying questions'),
          h('ol.ai-list', questions.map((q) => h('li', q.question, ' ', h('span.muted', `· for ${q.addressed_to}`)))))
        : null,
      listBlock('Missing information', out.missing_info, (m) => [m.item, ' ', statusPill(m.impact, { label: `${m.impact} impact` })]),
      listBlock('Ambiguous wording', out.ambiguities, (a) => [h('q', a.text), ' ', h('span.muted', a.why)])),
  );
}

// ------------------------------------------------------------------ F14 intake autofill
const AUTOFILL_LABELS = {
  name: 'Project Name', lob: 'LOB', requestor: 'Requestor', priority: 'Priority', description: 'Description of Change',
  labels: 'Labels', dc_intake: 'DC Intake', target_release: 'Target Release', requested_go_live: 'Requested Go-live',
  sa_author: 'SA author', dc_sa_name: 'DC SA', prn_code: 'PRN', sa_version: 'SA Version',
};

export function previewIntakeAutofill(out, ctx) {
  const fields = out.fields || {};
  const rows = Object.keys(AUTOFILL_LABELS).filter((k) => fields[k] && fields[k].value !== null && fields[k].value !== '');
  return h('div.preview',
    rows.length ? h('table.mini-table', h('thead', h('tr', h('th', 'Field'), h('th', 'Value'), h('th', 'Confidence'), h('th', 'Found in'))),
      h('tbody', rows.map((k, i) => {
        const f = fields[k];
        const value = ctx.editing ? textInput(f, 'value') : h('span', k === 'priority' ? `P${f.value}` : txt(f.value));
        return ctx.stagger(h('tr', h('td.strong', AUTOFILL_LABELS[k]), h('td', value),
          h('td', fmtPct((f.confidence || 0) * 100)), h('td.muted', txt(f.source))), i);
      })))
      : h('p.muted', 'No intake details were found in this document.'),
    (out.likely_components || []).length
      ? h('div.ai-block', h('div.ai-block-title', 'Likely DC components'), h('div.chip-row', out.likely_components.map((c) => chip(componentName(c), { tone: 'blue' }))))
      : null,
  );
}

// ------------------------------------------------------------------ F2 change summary
export function previewChangeSummary(out, ctx) {
  const comps = out.components || [];
  const approvals = opts('approval', ['Pending', 'Approved', 'Not required', 'Rejected']);
  const complexity = opts('complexity', ['Low', 'Medium', 'High']);
  const totalHours = comps.reduce((a, c) => a + (Number(c.est_hours) || 0), 0);
  return h('div.preview',
    h('p.ai-headline', `${comps.length} DC component${comps.length === 1 ? '' : 's'} identified · SA Completeness ${fmtPct(out.sa_completeness)}`,
      totalHours ? ` · ${fmtHours(totalHours)} development` : ''),
    comps.length ? h('table.mini-table.preview-table',
      h('thead', h('tr', h('th', h('span.visually-hidden', 'Include')), h('th', 'DC Component'), h('th', 'Approval'), h('th', 'Complexity'), h('th', 'Change Summary'), h('th.num', 'Est. hours'))),
      h('tbody', comps.map((c, i) => ctx.stagger(h('tr',
        h('td', checkbox(ctx, i, componentName(c.component_code, c.component_name))),
        h('td.strong', componentName(c.component_code, c.component_name)),
        h('td', ctx.editing ? selectInput(c, 'approval', approvals) : statusPill(c.approval)),
        h('td', ctx.editing ? selectInput(c, 'complexity', complexity) : txt(c.complexity)),
        h('td.wrap', ctx.editing ? textArea(c, 'change_summary', 3) : txt(c.change_summary),
          !ctx.editing && (c.evidence || []).length ? h('div.evidence', `SA ${c.evidence[0].section}`) : null),
        h('td.num', ctx.editing ? textInput(c, 'est_hours', { type: 'number', min: 0, step: 0.5, width: 80 }) : fmtHours(c.est_hours))), i))))
      : h('p.muted', 'No DC components were found in the SA document.'),
    listBlock('Gaps found', out.gaps),
    listBlock('Open items', out.open_items),
    listBlock('Out of scope', out.out_of_scope),
  );
}

// ------------------------------------------------------------------ F3 L2 estimate narrative
export function previewL2(out, ctx) {
  return h('div.preview',
    h('p.ai-headline', `${fmtHours(out.total_hours)} · T-shirt ${txt(out.tshirt)} · range ${fmtHours(out.low_hours).replace(' h', '')}–${fmtHours(out.high_hours)}`),
    streamed(ctx, out.narrative),
    (out.by_component || []).length ? h('div.ai-block', h('div.ai-block-title', 'By component'),
      h('table.mini-table', h('tbody', out.by_component.map((c, i) => ctx.stagger(h('tr',
        h('td.strong', componentName(c.component_code)), h('td', txt(c.complexity)), h('td.num', fmtHours(c.dev_hours)), h('td.wrap', c.rationale)), i))))) : null,
    (out.comparables || []).length ? h('div.ai-block', h('div.ai-block-title', 'Comparable initiatives'),
      h('ul.ai-list', out.comparables.map((c) => h('li', h('strong', c.rddc), ` ${c.name} · actual ${fmtHours(c.actual_hours)} · ${fmtPct(c.similarity * 100)} similar`, c.note ? ` · ${c.note}` : '')))) : null,
    listBlock('What drives the estimate', out.drivers, (d) => `${d.factor}: ${d.effect}`),
    listBlock('Assumptions', out.assumptions),
  );
}

// ------------------------------------------------------------------ F4 WBS
export function previewWbs(out, ctx) {
  const tasks = out.tasks || [];
  return h('div.preview',
    streamed(ctx, out.summary),
    h('p.ai-headline', `${tasks.length} plan steps · ${fmtHours(out.total_est_hours)} in total · dates are calculated when you accept`),
    h('div.preview-scroll', h('table.mini-table.preview-table',
      h('thead', h('tr', h('th', 'WBS'), h('th', 'Steps'), h('th', 'Phase'), h('th', 'SME/Owner'), h('th', 'Resource'), h('th.num', 'Hours'), h('th.num', 'Alloc %'), h('th.num', 'Days'), h('th', 'Depends on'))),
      h('tbody', tasks.map((t, i) => ctx.stagger(h(`tr${t.parent_code ? '.child-row' : ''}`,
        h('td.mono', t.wbs_code),
        h('td', t.parent_code ? h('span.indent-mark', '└ ') : null, ctx.editing ? textInput(t, 'step', { width: 220 }) : h('span', { class: t.parent_code ? null : 'strong' }, t.step),
          t.is_milestone ? h('span.milestone-mark', { title: 'Milestone' }, ' ◆') : null),
        h('td', txt(t.phase)),
        h('td', txt(t.owner_role)),
        h('td', txt(t.suggested_resource_name || state.personName(t.suggested_resource_id), '—')),
        h('td.num', ctx.editing ? textInput(t, 'est_hours', { type: 'number', min: 0, step: 0.5, width: 70 }) : fmtHours(t.est_hours)),
        h('td.num', ctx.editing ? textInput(t, 'allocation_pct', { type: 'number', min: 0, max: 100, width: 60 }) : (t.allocation_pct ? `${t.allocation_pct}%` : '—')),
        h('td.num', ctx.editing ? textInput(t, 'duration_days', { type: 'number', min: 0, width: 60 }) : txt(t.duration_days)),
        h('td.mono', (t.depends_on || []).join(', ') || '—')), i))))),
    (out.dependency_impacts || []).length ? h('div.ai-block', h('div.ai-block-title', 'Dependency mapping'),
      h('ul.ai-list', out.dependency_impacts.map((d) => h('li', h('strong', componentName(d.component_code)), ` (${d.direction}) · ${d.impact} `, h('span.muted', `→ ${d.action}${d.wbs_code ? ` (${d.wbs_code})` : ''}`))))) : null,
    listBlock('Assumptions', out.assumptions),
  );
}

// ------------------------------------------------------------------ F5 resources
function candidateCard(rec, cand, ri, ctx, recommended, chosen, onChoose) {
  const assignLabel = rec.wbs_code ? `Assign to ${rec.wbs_code}` : 'Assign';
  const assign = btn(assignLabel, {
    variant: recommended ? 'primary' : 'secondary', small: true,
    onClick: (e) => {
      e.stopPropagation();
      const edited = structuredClone(ctx.draft);
      edited.recommendations[ri].recommended_resource_id = cand.resource_id;
      ctx.accept({ selected: [ri], edited_output: edited });
    },
  });
  const card = h(`div.cand-card${recommended ? '.cand-recommended' : ''}${chosen ? '.cand-chosen' : ''}`, {
    tabIndex: 0, attrs: { role: 'radio', 'aria-checked': chosen ? 'true' : 'false' },
    title: 'Select to assign this person with Assign recommended',
  },
  h('div.cand-head',
    h('span.cand-rank', String(cand.rank)),
    h('div.cand-name-wrap', h('div.cand-name', cand.resource_name), h('div.cand-team', txt(cand.team, ''))),
    h('span.cand-score', `${fmtPct(cand.fit_score)} match`)),
  recommended ? h('div.cand-badge', /develop/i.test(rec.role_needed || '') ? 'Recommended Developer' : 'Recommended resource') : null,
  Number(cand.peak_util_after_pct) > 100 ? h('div.cand-badge.cand-over', 'Over capacity') : null,
  chosen && !recommended ? h('div.cand-badge', 'Selected') : null,
  h('ul.cand-reasons', (cand.reasons || []).map((r) => h('li', r))),
  (cand.concerns || []).length ? h('ul.cand-concerns', cand.concerns.map((c) => h('li', '⚠ ', c))) : null,
  (cand.matched_skills || []).length ? h('div.chip-row', cand.matched_skills.slice(0, 5).map((s) => chip(s, { tone: 'grey' }))) : null,
  h('div.cand-load', `Free ${fmtHours(cand.free_hours)} · peak ${fmtPct(cand.peak_util_after_pct)} after`,
    (cand.prior_work || []).length ? ` · worked on ${cand.prior_work.join(', ')}` : ''),
  h('div.cand-actions', assign));
  const choose = () => onChoose(cand.resource_id);
  card.addEventListener('click', choose);
  card.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); choose(); } });
  return card;
}

export function previewResources(out, ctx) {
  const recs = out.recommendations || [];
  if (!recs.length) return h('p.muted', 'No suggestions for these steps.');
  const choice = recs.map((r) => r.recommended_resource_id);
  const grids = [];
  const paintRec = (ri) => {
    const rec = recs[ri];
    grids[ri].replaceChildren(...rec.candidates.map((c) => candidateCard(rec, c, ri, ctx,
      c.resource_id === rec.recommended_resource_id, c.resource_id === choice[ri], (rid) => {
        choice[ri] = rid;
        const edited = structuredClone(ctx.draft);
        edited.recommendations.forEach((r, i) => { r.recommended_resource_id = choice[i]; });
        ctx.setEditedOutput(edited);
        ctx.toggle(ri, true);
        paintRec(ri);
      })));
  };
  const blocks = recs.map((rec, ri) => {
    grids[ri] = h('div.cand-grid');
    return ctx.stagger(h('div.rec-block',
      h('div.rec-head',
        h('label.rec-check', checkbox(ctx, ri, rec.wbs_code || rec.role_needed),
          h('strong', rec.wbs_code ? `${rec.wbs_code} · ` : ''), rec.role_needed),
        h('span.muted', ` ${fmtHours(rec.hours_needed)} · ${fmtShort(rec.window && rec.window.start)}–${fmtShort(rec.window && rec.window.end)}`),
        (rec.required_skills || []).length ? h('span.muted', ` · needs ${rec.required_skills.slice(0, 4).join(', ')}`) : null),
      (rec.candidates || []).length ? grids[ri] : h('p.muted', 'No one with the right skills has capacity in this window.')), ri);
  });
  recs.forEach((rec, ri) => { if ((rec.candidates || []).length) paintRec(ri); });
  return h('div.preview', h('p.small.muted', 'Click a person to choose them, then Assign recommended. Each step uses its highlighted choice.'), blocks);
}

// ------------------------------------------------------------------ F6 rebalance
function utilRow(name, from, to) {
  const tone = (v) => (v > 110 ? 'over' : v > 100 ? 'stretched' : v >= 70 ? 'ok' : 'spare');
  return h('div.util-row',
    h('span.util-name', name),
    h(`span.util-val.band-${tone(from)}`, fmtPct(from)),
    h('span.util-arrow', { aria: { hidden: 'true' } }, '→'),
    h(`span.util-val.band-${tone(to)}`, fmtPct(to)));
}

export function previewRebalance(out, ctx) {
  const p = out.problem || {};
  const options = out.options || [];
  const name = `rebalance-${Math.random().toString(36).slice(2, 8)}`;
  return h('div.preview',
    h('p.ai-headline', p.summary || `${txt(p.resource_name)} is at ${fmtPct(p.util_pct)} in ${fmtMonth(p.month)}`),
    options.length ? h('div.option-list', options.map((opt, i) => {
      const radio = h('input', { type: 'radio', name, checked: ctx.isSelected(i), aria: { label: opt.action } });
      radio.addEventListener('change', () => { if (radio.checked) ctx.selectOnly(i); });
      return ctx.stagger(h(`label.option-card${i === out.recommended_option_index ? '.option-recommended' : ''}`,
        radio,
        h('div.option-body',
          h('div.option-action', opt.action, i === out.recommended_option_index ? h('span.cand-badge.inline', 'Recommended') : null),
          h('div.option-utils',
            utilRow(opt.from_resource_name, opt.before && opt.before.from_pct, opt.after && opt.after.from_pct),
            utilRow(opt.to_resource_name, opt.before && opt.before.to_pct, opt.after && opt.after.to_pct)),
          h('div.option-effect', opt.effect),
          opt.health_after ? h('div.option-health', 'After: Resources ', ragPill(opt.health_after.resources, { size: 'sm' }), ' · Overall ', ragPill(opt.health_after.overall, { size: 'sm' })) : null,
          (opt.tradeoffs || []).length ? h('ul.ai-list.small', opt.tradeoffs.map((t) => h('li', t))) : null)), i);
    })) : h('p.muted', 'No one with spare capacity can take this work in that month.'),
  );
}

// ------------------------------------------------------------------ F7 risks
export function previewRisks(out, ctx) {
  const risks = out.risks || [];
  const sevOpts = opts('risk_severity', [{ value: 1, label: 'Low' }, { value: 2, label: 'Medium' }, { value: 3, label: 'High' }, { value: 4, label: 'Critical' }]);
  const likOpts = opts('risk_likelihood', [{ value: 1, label: 'Rare' }, { value: 2, label: 'Unlikely' }, { value: 3, label: 'Possible' }, { value: 4, label: 'Likely' }]);
  return h('div.preview',
    out.management_attention ? h('p.ai-headline', 'Management attention: ', out.management_attention) : null,
    risks.length ? h('div.preview-scroll', h('table.mini-table.preview-table',
      h('thead', h('tr', h('th', h('span.visually-hidden', 'Include')), h('th', 'Risk'), h('th', 'Category'), h('th', 'Severity × Likelihood'), h('th', 'Linked WBS'), h('th', 'Owner'), h('th', 'Mitigation'))),
      h('tbody', risks.map((r, i) => ctx.stagger(h('tr',
        h('td', checkbox(ctx, i, r.title)),
        h('td.wrap', ctx.editing ? textInput(r, 'title', { width: 220 }) : h('div.strong', r.title), h('div.muted.small', r.description),
          r.trigger_signal ? h('div.small', h('span.muted', 'Signal: '), r.trigger_signal) : null),
        h('td', txt(r.category)),
        h('td', ctx.editing
          ? h('div.inline-pair', selectInput(r, 'severity', sevOpts, { numeric: true }), selectInput(r, 'likelihood', likOpts, { numeric: true }))
          : h('span', statusPill(sevLabel(r.severity) === 'Critical' ? 'Critical' : sevLabel(r.severity), { label: sevLabel(r.severity) }), ' × ', likLabel(r.likelihood), h('span.muted', ` · score ${r.severity * r.likelihood}`))),
        h('td.mono', txt(r.wbs_code)),
        h('td', txt(r.owner_role)),
        h('td.wrap', h('ol.ai-list.small', (r.mitigation_steps || []).map((m) => h('li', m.step, m.due ? h('span.muted', ` · by ${fmtDate(m.due)}`) : null))))), i)))))
      : h('p.muted', 'No new risks found in the plan.'),
  );
}

// ------------------------------------------------------------------ F9 CR compliance
export function previewCompliance(out, ctx, opts = {}) {
  const findings = out.findings || [];
  const attention = findings.filter((f) => f.status === 'Fail' || f.status === 'Warn').length;
  const notDue = findings.filter((f) => f.status === 'Not due yet').length;
  return h('div.preview',
    h('div.ai-summary-row',
      h('strong', txt(out.crq_number, 'Change request')),
      attention ? statusPill('Fail', { label: `${attention} item${attention === 1 ? ' needs' : 's need'} attention` }) : statusPill('Pass', { label: 'No issues now' }),
      notDue ? statusPill('Not due yet', { label: `${notDue} not due yet` }) : null,
      h('span.ai-inline-label', 'Score'), h('span', fmtPct(out.score)),
      h('span.ai-inline-label', 'STO readiness'),
      opts.stoText && /^Not requested/.test(opts.stoText)
        ? h('span.small', opts.stoText)
        : statusPill(out.sto_readiness === 'Ready for Go' ? 'Go' : out.sto_readiness === 'Not ready' ? 'No-Go' : 'Tentative Go', { label: opts.stoText || out.sto_readiness })),
    h('table.mini-table.preview-table',
      h('thead', h('tr', h('th', 'Rule'), h('th', 'Check'), h('th', 'Result'), h('th', 'Detail'), h('th', 'Fix'))),
      h('tbody', findings.map((f, i) => ctx.stagger(h(`tr${f.status === 'Fail' ? '.row-fail' : ''}${f.status === 'Not due yet' ? '.row-notdue' : ''}`,
        h('td.mono', f.rule_id), h('td', f.rule),
        h('td', statusPill(f.status), f.status === 'Not due yet' && f.due_date ? h('div.small.muted', `Due by ${fmtDate(f.due_date)}`) : null),
        h('td.wrap', f.detail), h('td.wrap', txt(f.fix, '—'))), i)))),
    h('p.small.muted', 'Score counts passes against fails and warnings; checks not due yet are left out.'),
    h('div.ai-block', h('div.ai-block-title', 'Reviewer note'), streamed(ctx, out.reviewer_note)),
  );
}

export const PREVIEWS = {
  intake_analysis: previewIntakeAnalysis,
  intake_autofill: previewIntakeAutofill,
  change_summary: previewChangeSummary,
  l2_estimate: previewL2,
  wbs: previewWbs,
  resources: previewResources,
  rebalance: previewRebalance,
  risks: previewRisks,
  cr_compliance: previewCompliance,
};
