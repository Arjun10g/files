// dom.js: safe DOM building. Text always goes in through text nodes / textContent.

const ESC_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

/** Escape any value for use inside an HTML string. null/undefined become ''. */
export function esc(value) {
  if (value === null || value === undefined) return '';
  return String(value).replace(/[&<>"']/g, (c) => ESC_MAP[c]);
}

const PROPS = new Set(['value', 'checked', 'disabled', 'selected', 'hidden', 'readOnly', 'multiple', 'indeterminate',
  'tabIndex', 'htmlFor', 'type', 'placeholder', 'min', 'max', 'step', 'name', 'id', 'href', 'download', 'target',
  'rel', 'title', 'rows', 'colSpan', 'rowSpan', 'accept', 'maxLength', 'autocomplete', 'spellcheck', 'required']);

/** Turn any child value into nodes. Strings and numbers become text nodes; null/false/undefined are skipped. */
function appendChildren(el, children) {
  for (const child of children) {
    if (child === null || child === undefined || child === false || child === true) continue;
    if (Array.isArray(child)) {
      appendChildren(el, child);
    } else if (child instanceof Node) {
      el.appendChild(child);
    } else if (typeof child === 'number') {
      el.appendChild(document.createTextNode(Number.isFinite(child) ? String(child) : '—'));
    } else {
      el.appendChild(document.createTextNode(String(child)));
    }
  }
  return el;
}

/**
 * h('div.cls', {on:{click}, dataset:{}, style:{}, attrs:{}}, ...children)
 * Tag may carry classes after dots. Props in PROPS are set as properties; others as attributes.
 */
export function h(tag, props, ...children) {
  let tagName = tag;
  let classes = [];
  if (tag.includes('.')) {
    const parts = tag.split('.');
    tagName = parts.shift() || 'div';
    classes = parts.filter(Boolean);
  }
  const el = document.createElement(tagName);
  if (classes.length) el.className = classes.join(' ');
  if (props && (typeof props !== 'object' || props instanceof Node || Array.isArray(props))) {
    children.unshift(props);
    props = null;
  }
  if (props) {
    for (const [key, value] of Object.entries(props)) {
      if (value === undefined || value === null || value === false) {
        if (key === 'value' && value === null) el.value = '';
        continue;
      }
      if (key === 'class' || key === 'className') {
        const extra = Array.isArray(value) ? value.filter(Boolean).join(' ') : String(value);
        if (extra) el.className = el.className ? `${el.className} ${extra}` : extra;
      } else if (key === 'text') {
        el.textContent = String(value);
      } else if (key === 'on') {
        for (const [evt, fn] of Object.entries(value)) if (typeof fn === 'function') el.addEventListener(evt, fn);
      } else if (key === 'dataset') {
        for (const [k, v] of Object.entries(value)) if (v !== undefined && v !== null) el.dataset[k] = String(v);
      } else if (key === 'style') {
        if (typeof value === 'string') el.setAttribute('style', value);
        else for (const [k, v] of Object.entries(value)) if (v !== undefined && v !== null) el.style.setProperty(k, String(v));
      } else if (key === 'attrs') {
        for (const [k, v] of Object.entries(value)) if (v !== undefined && v !== null && v !== false) el.setAttribute(k, v === true ? '' : String(v));
      } else if (key === 'aria') {
        for (const [k, v] of Object.entries(value)) if (v !== undefined && v !== null) el.setAttribute(`aria-${k}`, String(v));
      } else if (PROPS.has(key)) {
        el[key] = value === true && key !== 'value' ? true : value;
      } else {
        el.setAttribute(key, value === true ? '' : String(value));
      }
    }
  }
  return appendChildren(el, children);
}

/** Remove every child of el. */
export function clear(el) {
  if (el) while (el.firstChild) el.removeChild(el.firstChild);
  return el;
}

/** Replace el's children. */
export function mount(el, ...children) {
  clear(el);
  return appendChildren(el, children);
}

/** Display text for any value: never 'undefined', 'null' or 'NaN'. */
export function txt(value, fallback = '—') {
  if (value === null || value === undefined || value === '') return fallback;
  if (typeof value === 'number' && !Number.isFinite(value)) return fallback;
  return String(value);
}

/** Debounce helper. */
export function debounce(fn, ms) {
  let timer = null;
  const wrapped = (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), ms);
  };
  wrapped.flush = (...args) => {
    clearTimeout(timer);
    fn(...args);
  };
  wrapped.cancel = () => clearTimeout(timer);
  return wrapped;
}

/** True when the user prefers reduced motion. */
export function reducedMotion() {
  return Boolean(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
}

export const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
