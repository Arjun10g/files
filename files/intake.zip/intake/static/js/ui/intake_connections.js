// Typed intake names and optional shared funding fields. No financial values are invented.
let pickerSequence = 0;
const normalize = (value) => String(value || '').trim().replace(/\s+/g, ' ').toLocaleLowerCase();

export function personNamePicker(ui, state, { value = '', id = null, label, required = false, onChange } = {}) {
  const { h } = ui;
  const listId = `intake-person-${++pickerSequence}`;
  const initialName = value || state.personName(id);
  const input = h('input.input', { type: 'text', value: initialName, required, maxLength: 120,
    autocomplete: 'off', attrs: { list: listId }, aria: { label }, placeholder: 'Enter or choose a name' });
  const list = h('datalist', { id: listId }, state.people().map((person) => h('option', { value: person.name }, [person.role, person.team].filter(Boolean).join(' · '))));
  function read() {
    const name = input.value.trim().replace(/\s+/g, ' ');
    const matches = state.people().filter((person) => normalize(person.name) === normalize(name));
    const selected = matches.find((person) => String(person.id) === String(id)) || (matches.length === 1 ? matches[0] : null);
    return { name: selected?.name || name || null, id: selected?.id ?? null };
  }
  input.addEventListener('input', () => onChange?.(read()));
  return { el: h('div.intake-person', input, list), input, read };
}

export function fundingIntakeFields(ui, state, budgets = [], { code = '', codeLabel = 'Funding / PRN', initiativeId, onCodeChange, onChange } = {}) {
  const { h } = ui;
  const listId = `intake-funding-${++pickerSequence}`;
  const codeInput = h('input.input', { value: code || '', maxLength: 60, autocomplete: 'off',
    attrs: { list: listId, pattern: '[A-Za-z0-9][A-Za-z0-9._\\-]*' }, aria: { label: codeLabel }, placeholder: 'Choose or enter a funding code' });
  const codeEl = h('div.intake-person', codeInput, h('datalist', { id: listId }, budgets.map((budget) => h('option', { value: budget.prn_code }, budget.name || ''))));
  const fields = {};
  const grid = h('div.form-grid');
  let current = null;
  let baseline = {};
  const note = h('p.intake-connection-note');
  const linked = h('div.intake-linked-record');
  const confirmationInput = h('input', { type: 'checkbox' });
  const confirmation = h('label.intake-shared-confirm', confirmationInput, h('span', 'Update this shared funding record'));
  confirmation.hidden = true;
  const numberKeys = new Set(['funded_hours', 'rate', 'budget_amount']);

  function addField(key, label, { type = 'text', items } = {}) {
    const input = items ? ui.selectEl(items.map((item) => ({ value: item, label: item })), '', { placeholder: 'Not specified', ariaLabel: label })
      : h(type === 'textarea' ? 'textarea.input' : 'input.input', { type: type === 'textarea' ? undefined : type,
        rows: type === 'textarea' ? 2 : undefined, min: type === 'number' ? 0 : undefined,
        step: type === 'number' ? .01 : undefined, maxLength: type === 'textarea' ? 16000 : 200, aria: { label } });
    fields[key] = input;
    input.addEventListener(items ? 'change' : 'input', changed);
    grid.append(h(`label.form-field${type === 'textarea' ? '.span-2' : ''}`, h('span.form-label', label), input));
  }

  addField('name', 'Budget name');
  const owner = personNamePicker(ui, state, { label: 'Budget owner', onChange: changed });
  fields.owner = owner.input;
  grid.append(h('label.form-field', h('span.form-label', 'Budget owner'), owner.el));
  addField('funded_hours', 'Funded hours', { type: 'number' });
  addField('rate', 'Blended hourly rate', { type: 'number' });
  addField('budget_amount', 'Budget amount', { type: 'number' });
  addField('currency', 'Currency', { items: ['CAD', 'USD', 'GBP', 'EUR'] });
  addField('decision', 'Funding decision', { items: ['Pending', 'Approved', 'Rejected', 'Delayed'] });
  addField('charge_type', 'PR charge allocation', { items: ['Project', 'POD'] });
  addField('scope', 'Scope', { type: 'textarea' });
  addField('assumptions', 'Assumptions', { type: 'textarea' });
  const el = h('details.intake-funding-details', h('summary', 'Funding details (optional)'),
    h('p.intake-connection-note', 'A new code starts as a pending draft. Enter hours and a rate to calculate the budget, or enter an explicit amount. Unknown rates stay at zero.'),
    linked, grid, note, confirmation);

  function payload() {
    const values = {};
    for (const [key, input] of Object.entries(fields)) {
      const raw = input.value.trim();
      if (raw === String(baseline[key] ?? '')) continue;
      // Clearing a field does not erase the shared budget. Use Funding for full budget maintenance.
      if (!raw) continue;
      values[key] = numberKeys.has(key) ? Number(raw) : raw;
    }
    if (!Object.keys(values).length) return null;
    if ('owner' in values) {
      const person = owner.read();
      values.owner = person.name;
      if (person.id) values.owner_id = person.id;
    }
    values.prn_code = codeInput.value.trim();
    if (current && confirmationInput.checked) values.update_existing = true;
    return values;
  }

  function changed() {
    const patch = payload();
    const sharedChange = Boolean(current && patch);
    confirmation.hidden = !sharedChange;
    confirmationInput.required = sharedChange;
    note.textContent = sharedChange
      ? 'These changes affect the shared funding record and every linked initiative. Confirm the update before saving.'
      : current ? 'This initiative reuses the shared budget. Edit these fields only when the shared funding needs to change.' : '';
    codeInput.setCustomValidity(patch && !codeInput.value.trim() ? 'Enter a funding code for these funding details.' : '');
    onChange?.(patch);
  }

  function syncCode() {
    current = budgets.find((budget) => normalize(budget.prn_code) === normalize(codeInput.value)) || null;
    baseline = {};
    for (const [key, input] of Object.entries(fields)) {
      let value = key === 'owner' ? current?.owner_name || state.personName(current?.owner_id) : current?.[key];
      if (key === 'currency' && value && ![...input.options].some((option) => option.value === value)) input.add(h('option', { value }, value));
      input.value = value ?? '';
      baseline[key] = input.value;
    }
    confirmationInput.checked = false;
    ui.mount(linked, current ? h('div', h('strong', `${current.prn_code} · ${current.name || 'Funding draft'}`),
      h('a.link', { href: `#/funding?prn=${encodeURIComponent(current.prn_code)}` }, 'Open funding'),
      initiativeId ? h('a.link', { href: `#/resources?initiative=${encodeURIComponent(initiativeId)}` }, 'Open resource allocation') : null) : null);
    changed();
  }

  codeInput.addEventListener('input', () => { syncCode(); onCodeChange?.(codeInput.value.trim() || null); });
  confirmationInput.addEventListener('change', changed);
  syncCode();
  return { el, codeInput, codeEl, read: payload, getCode: () => codeInput.value.trim() || null,
    validate() {
      if (!codeInput.checkValidity()) throw new Error(codeInput.validationMessage);
      for (const input of Object.values(fields)) if (!input.checkValidity()) throw new Error(input.validationMessage);
      if (confirmationInput.required && !confirmationInput.checked) throw new Error('Confirm the shared funding update before saving.');
    } };
}
