// toast.js: bottom-right navy toasts, 4 s, max 3 stacked, optional action (e.g. Undo / Open).
import { h } from './dom.js';

const MAX = 3;
let host = null;

function ensureHost() {
  if (!host || !document.body.contains(host)) {
    host = h('div.toast-host', { attrs: { role: 'status', 'aria-live': 'polite' } });
    document.body.appendChild(host);
  }
  return host;
}

/**
 * toast(message, {variant:'success'|'warning'|'info'|'error', action:{label, onClick}, duration})
 * @returns {{close: () => void}}
 */
export function toast(message, opts = {}) {
  const { variant = 'success', action = null, duration = 4000 } = opts;
  const root = ensureHost();
  const icon = variant === 'warning' || variant === 'error' ? '⚠' : variant === 'info' ? 'ℹ' : '✓';
  let timer = null;
  const el = h(`div.toast.toast-${variant}`,
    h('span.toast-icon', { aria: { hidden: 'true' } }, icon),
    h('span.toast-msg', String(message ?? '')),
  );
  const close = () => {
    clearTimeout(timer);
    el.classList.add('toast-out');
    setTimeout(() => el.remove(), 180);
  };
  if (action && action.label) {
    el.appendChild(h('button.toast-action', {
      type: 'button',
      on: { click: () => { close(); action.onClick?.(); } },
    }, action.label));
  }
  el.appendChild(h('button.toast-close', { type: 'button', aria: { label: 'Close' }, on: { click: close } }, '✕'));
  root.appendChild(el);
  while (root.children.length > MAX) root.firstElementChild.remove();
  timer = setTimeout(close, action ? Math.max(duration, 6000) : duration);
  el.addEventListener('mouseenter', () => clearTimeout(timer));
  el.addEventListener('mouseleave', () => { timer = setTimeout(close, 2000); });
  return { close };
}

/** Show an error (ApiError or anything) as a warning toast with its user-facing message. */
export function toastError(err, fallback = 'Something went wrong. Try again.') {
  if (err && err.code === 'cancelled') return null;
  const msg = err && err.name === 'ApiError' && err.message ? err.message : fallback;
  return toast(msg, { variant: 'warning', duration: 6000 });
}

/** Remove every toast (e.g. after a demo reset, so no action points at deleted data). */
export function clearToasts() {
  if (host) host.replaceChildren();
}
