// api.js: FROZEN CONTRACT (owner B0). One exported function per endpoint in docs/contracts.md.
// Views never call fetch() directly. Every function returns parsed JSON or throws ApiError.

const BASE = '/api';
export const AI_TIMEOUT_MS = 25000;
export const DEFAULT_TIMEOUT_MS = 15000;

export class ApiError extends Error {
  constructor(message, { code = 'error', status = 0, details = {} } = {}) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

const STATUS_MESSAGES = {
  400: 'The request could not be read.',
  404: 'That item could not be found.',
  409: 'That change conflicts with existing data.',
  413: 'The file is larger than 10 MB. Attach a smaller file.',
  422: 'Some fields need attention.',
  500: 'Something went wrong. Try again, or reset the demo from Settings.',
};

function buildQuery(params) {
  if (!params) return '';
  const qs = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === '') continue;
    qs.append(key, Array.isArray(value) ? value.join(',') : String(value));
  }
  const text = qs.toString();
  return text ? `?${text}` : '';
}

const enc = encodeURIComponent;

/**
 * Shared request helper.
 * @param {string} method  GET | POST | PUT | DELETE
 * @param {string} path    path below /api, e.g. '/initiatives/9'
 * @param {{body?: any, params?: object, form?: FormData, timeout?: number, signal?: AbortSignal}} [opts]
 * @returns {Promise<any>} parsed JSON body
 */
export async function request(method, path, opts = {}) {
  const { body, params, form, timeout = DEFAULT_TIMEOUT_MS, signal } = opts;
  const controller = new AbortController();
  let cancelled = false;
  const timer = setTimeout(() => controller.abort(), timeout);
  if (signal) {
    if (signal.aborted) cancelled = true;
    signal.addEventListener('abort', () => { cancelled = true; controller.abort(); }, { once: true });
  }
  const init = { method, headers: { Accept: 'application/json' }, signal: controller.signal, cache: 'no-store' };
  if (form) {
    init.body = form;
  } else if (body !== undefined) {
    init.headers['Content-Type'] = 'application/json';
    init.body = JSON.stringify(body);
  }
  let response;
  let text;
  try {
    response = await fetch(BASE + path + buildQuery(params), init);
    text = await response.text();
  } catch (err) {
    if (controller.signal.aborted) {
      if (cancelled) throw new ApiError('Request cancelled.', { code: 'cancelled' });
      throw new ApiError('This is taking longer than expected. Try again.', { code: 'timeout' });
    }
    throw new ApiError('Could not reach the server. Check that the app is running.', { code: 'network' });
  } finally {
    clearTimeout(timer);
  }
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = null;
    }
  }
  if (!response.ok) {
    const err = data && data.error ? data.error : {};
    throw new ApiError(err.message || STATUS_MESSAGES[response.status] || STATUS_MESSAGES[500], {
      code: err.code || `http_${response.status}`,
      status: response.status,
      details: err.details || {},
    });
  }
  if (data === null && text) {
    throw new ApiError(STATUS_MESSAGES[500], { code: 'bad_response', status: response.status });
  }
  return data;
}

const get = (path, params, opts = {}) => request('GET', path, { ...opts, params });
const post = (path, body = {}, opts = {}) => request('POST', path, { ...opts, body });
const put = (path, body = {}, opts = {}) => request('PUT', path, { ...opts, body });
const del = (path, opts = {}) => request('DELETE', path, opts);
const aiPost = (path, body = {}) => request('POST', path, { body, timeout: AI_TIMEOUT_MS });

// ------------------------------------------------------------------ core
/** @returns {Promise<{status:string, db:boolean, ai_mode:'simulated'|'live', model:string, today:string, version:string, modules:string[]}>} */
export const getAppHealth = () => get('/health');
/** @returns {Promise<Object<string, Array<{value:any,label:string}>> & {components:Array, resources:Array, release_trains:Array, fiscal_quarters:Array}>} */
export const getLookups = () => get('/lookups');
/** @returns {Promise<{ai_mode:string, ai_speed:string, demo_today:string, persona:string, live_available:boolean, model_heavy:string, model_fast:string}>} */
export const getSettings = () => get('/settings');
/** @param {{ai_mode?:string, ai_speed?:string, demo_today?:string, persona?:string}} patch @returns {Promise<Settings>} same shape as getSettings */
export const updateSettings = (patch) => put('/settings', patch);
/** @returns {Promise<{ok:true, counts:Object<string,number>}>} */
export const resetDemo = () => request('POST', '/admin/reset', { body: {}, timeout: AI_TIMEOUT_MS });
/** @returns {Promise<{initiative_id:number, rddc:string, steps:Array<{step:string, ok:boolean, ai_run_id?:number, message?:string}>}>} */
export const fastForwardHero = () => request('POST', '/admin/fast-forward-hero', { body: {}, timeout: AI_TIMEOUT_MS });
/** @returns {Promise<{items:Array<{id,ts,actor,persona,entity_type,entity_id,initiative_id,action,detail_json,summary}>, total:number}>} */
export const listActivity = (params = {}) => get('/activity', params);
/** @returns {Promise<{items:Array<{code,train_date,status,in_freeze:boolean,initiatives:Array<{id,rddc,name,rag}>}>, freeze:{start,end}, holidays:string[]}>} */
export const listReleaseTrains = () => get('/release-trains');
/** @returns {Promise<{items:Array<DcIntake>, total:number}>} */
export const listDcIntakes = (params = {}) => get('/dc-intakes', params);
/** @returns {Promise<{code,name,lob,requestor,priority,requested_go_live,description,initiative_id:number|null}>} */
export const getDcIntake = (code) => get(`/dc-intakes/${enc(code)}`);

// ------------------------------------------------------------------ initiatives
/** @param {{q?,stage?,lob?,status?,rag?,dc_pm_id?,release?}} params @returns {Promise<{items:Array<{id,rddc,name,lob,stage,status,priority,dc_pm_name,dc_sa_name,rag,target_release,readiness_date,planned_end}>, total:number}>} */
export const listInitiatives = (params = {}) => get('/initiatives', params);
/** @returns {Promise<{initiative:Initiative, grooming:{session_id,session_date,start_time,label}|null, queued_notifications:Array<{id,to_name,subject}>}>} */
export const createInitiative = (body) => post('/initiatives', body);
/** @returns {Promise<Bundle>} see docs/contracts.md "Bundle" */
export const getInitiative = (id) => get(`/initiatives/${id}`);
/** @returns {Promise<Initiative>} the updated initiative row (with *_name joins) */
export const updateInitiative = (id, patch) => put(`/initiatives/${id}`, patch);
/** @returns {Promise<{ok:true}>} */
export const deleteInitiative = (id) => del(`/initiatives/${id}`);
/** @returns {Promise<{items:Array<InitiativeComponent>, total:number}>} */
export const listComponents = (id) => get(`/initiatives/${id}/components`);
/** @param {{component_id,approval?,change_summary?,complexity?,est_hours?,component_lead_id?}} body @returns {Promise<InitiativeComponent>} */
export const addComponent = (id, body) => post(`/initiatives/${id}/components`, body);
/** @returns {Promise<InitiativeComponent>} */
export const updateComponent = (icid, patch) => put(`/initiative-components/${icid}`, patch);
/** @returns {Promise<{ok:true}>} */
export const deleteComponent = (icid) => del(`/initiative-components/${icid}`);
/** @returns {Promise<{items:Array<Attachment>, total:number}>} */
export const listAttachments = (id) => get(`/initiatives/${id}/attachments`);
/**
 * Multipart upload (.docx .pdf .md .txt, max 10 MB).
 * @param {{kind:'sa_doc'|'tech_validation'|'biz_validation'|'backout_plan'|'meeting_notes'|'other', entity_type?:string, entity_id?:number}} meta
 * @returns {Promise<{attachment:Attachment, extracted_chars:number, sa:{author,version,completeness,missing:string[]}|null}>}
 */
export function uploadAttachment(id, file, meta) {
  const form = new FormData();
  form.append('file', file);
  form.append('kind', meta.kind);
  if (meta.entity_type) form.append('entity_type', meta.entity_type);
  if (meta.entity_id !== undefined && meta.entity_id !== null) form.append('entity_id', String(meta.entity_id));
  return request('POST', `/initiatives/${id}/attachments`, { form, timeout: AI_TIMEOUT_MS });
}
/** Paste-text fallback when a file cannot be read. @returns {Promise<{attachment:Attachment, extracted_chars:number, sa:{author,version,completeness,missing:string[]}}>} */
export const submitSaText = (id, { text, filename }) => post(`/initiatives/${id}/sa-text`, { text, filename });
/** @returns {string} URL for an <a href download> */
export const attachmentDownloadUrl = (attachmentId) => `${BASE}/attachments/${attachmentId}/download`;

// ------------------------------------------------------------------ plan
/** @returns {Promise<{items:Array<Task>, total:number}>} */
export const listTasks = (id) => get(`/initiatives/${id}/tasks`);
/** @returns {Promise<{task:Task, shifted_tasks:Array<{id,wbs_code,planned_start,planned_end}>, health:Health}>} */
export const createTask = (id, task) => post(`/initiatives/${id}/tasks`, task);
/** Grid edit; dependants shift via schedule.propagate_slip. @returns {Promise<{task:Task, shifted_tasks:Array<{id,wbs_code,planned_start,planned_end}>, health:Health}>} */
export const updateTask = (taskId, patch) => put(`/tasks/${taskId}`, patch);
/** @returns {Promise<{ok:true, health:Health}>} */
export const deleteTask = (taskId) => del(`/tasks/${taskId}`);
/** @param {Array<Partial<Task>>} tasks @returns {Promise<{items:Array<Task>, health:Health}>} */
export const bulkUpdateTasks = (id, tasks) => put(`/initiatives/${id}/tasks/bulk`, { tasks });
/** @returns {Promise<{ok:true, baseline_set_at:string}>} */
export const rebaseline = (id, { reason }) => post(`/initiatives/${id}/baseline`, { reason });

// ------------------------------------------------------------------ resources
/** @param {{tracked?:0|1, team?:string}} params @returns {Promise<{items:Array<Resource>, total:number}>} */
export const listResources = (params = {}) => get('/resources', params);
/** @returns {Promise<Resource>} */
export const createResource = (body) => post('/resources', body);
/** @returns {Promise<Resource>} */
export const updateResource = (rid, patch) => put(`/resources/${rid}`, patch);
/** @returns {Promise<{resource_id:number, months:Object<string,number>}>} */
export const getAvailability = (rid, params = {}) => get(`/resources/${rid}/availability`, params);
/** @param {Object<string,number>} months e.g. {'2026-11': 120} @returns {Promise<{resource_id:number, months:Object<string,number>}>} */
export const setAvailability = (rid, months) => put(`/resources/${rid}/availability`, { months });
/** @returns {Promise<{items:Array<{id,resource_id,resource_name,initiative_id,rddc,task_id,wbs_code,month,hours,firmness,source}>, total:number}>} */
export const listAllocations = (params = {}) => get('/allocations', params);
/** Manual allocation. @returns {Promise<Allocation>} */
export const createAllocation = (body) => post('/allocations', body);
/** @returns {Promise<Allocation>} */
export const updateAllocation = (aid, patch) => put(`/allocations/${aid}`, patch);
/** @returns {Promise<{ok:true}>} */
export const deleteAllocation = (aid) => del(`/allocations/${aid}`);
/** @returns {Promise<{skills:Array<{id,name,category}>, rows:Array<{resource_id,name,team,levels:Object<string,number>, evidence:Object<string,string>}>}>} */
export const getSkillMatrix = () => get('/skills/matrix');
/** @param {Object<string,number>} skills {skill name: level 1-3} @returns {Promise<{resource_id:number, skills:Array<{skill,level,source}>}>} */
export const setResourceSkills = (rid, skills) => put(`/resources/${rid}/skills`, { skills });

// ------------------------------------------------------------------ governance
/** @param {{week?:string, initiative_id?:number, from?:string, to?:string}} params @returns {Promise<{items:Array<ChangeRequest & {compliance:{ok:boolean, flags:Array<{code,message}>}}>, total:number}>} */
export const listChangeRequests = (params = {}) => get('/change-requests', params);
/** @returns {Promise<ChangeRequest & {compliance:{ok:boolean, flags:Array<{code,message}>}}>} */
export const getChangeRequest = (cid) => get(`/change-requests/${cid}`);
/** @returns {Promise<ChangeRequest & {compliance}>} */
export const createChangeRequest = (id, body) => post(`/initiatives/${id}/change-requests`, body);
/** Deterministic CRQ draft from the plan. @returns {Promise<ChangeRequest & {compliance}>} */
export const createCrqDraft = (id) => post(`/initiatives/${id}/change-requests/draft`, {});
/** @returns {Promise<ChangeRequest & {compliance}>} */
export const updateChangeRequest = (cid, patch) => put(`/change-requests/${cid}`, patch);
/** @returns {Promise<{ok:true}>} */
export const deleteChangeRequest = (cid) => del(`/change-requests/${cid}`);
/** @param {{initiative_id?, status?, min_score?}} params @returns {Promise<{items:Array<Risk & {rddc,owner_name,wbs_code}>, total:number}>} */
export const listRisks = (params = {}) => get('/risks', params);
/** @returns {Promise<Risk>} */
export const createRisk = (id, body) => post(`/initiatives/${id}/risks`, body);
/** @returns {Promise<Risk>} */
export const updateRisk = (riskId, patch) => put(`/risks/${riskId}`, patch);
/** @returns {Promise<{ok:true}>} */
export const deleteRisk = (riskId) => del(`/risks/${riskId}`);
/** @returns {Promise<{items:Array<{id,session_date,start_time,title,capacity,status,slots:Array<{initiative_id,rddc,name,priority,slot_order,status,recipients:Array<{id,name}>}>}>, total:number}>} */
export const listGroomingSessions = (params = {}) => get('/grooming/sessions', params);
/** @returns {Promise<GroomingSession>} */
export const createGroomingSession = (body) => post('/grooming/sessions', body);
/** Re-slot or confirm. @param {{session_id, initiative_id, status?, new_session_id?}} body @returns {Promise<{session_id, initiative_id, status, slot_order}>} */
export const updateGroomingSlot = (body) => put('/grooming/slots', body);
/** Mark the initiative's grooming slot as discussed and move Grooming → Solution. @returns {Promise<{initiative:Initiative, grooming:object|null}>} */
export const markGroomed = (id, body = {}) => post(`/initiatives/${id}/groomed`, body);
/** @param {{status?, initiative_id?, rule?}} params @returns {Promise<{items:Array<Notification>, total:number, counts:{Queued:number, Sent:number}}>} */
export const listOutbox = (params = {}) => get('/outbox', params);
/** @returns {Promise<Notification>} status becomes Sent */
export const sendOutboxItem = (nid) => post(`/outbox/${nid}/send`, {});
/** @returns {Promise<Notification>} status becomes Acknowledged */
export const ackOutboxItem = (nid) => post(`/outbox/${nid}/ack`, {});
/** @returns {Promise<Notification>} status becomes Dismissed */
export const dismissOutboxItem = (nid) => post(`/outbox/${nid}/dismiss`, {});

// ------------------------------------------------------------------ artifacts  (type: 'decisions'|'lessons'|'meeting-notes'|'documents')
/** @returns {Promise<{items:Array<object>, total:number}>} rows of the matching table plus rddc */
export const listArtifacts = (type, params = {}) => get(`/${type}`, params);
/** @returns {Promise<object>} created row */
export const createArtifact = (type, body) => post(`/${type}`, body);
/** @returns {Promise<object>} updated row */
export const updateArtifact = (type, id, patch) => put(`/${type}/${id}`, patch);
/** @returns {Promise<{ok:true}>} */
export const deleteArtifact = (type, id) => del(`/${type}/${id}`);

// ------------------------------------------------------------------ computed views
/** @param {{lob?,dc_pm_id?,stage?,rag?,release?}} params @returns {Promise<{kpis:{active,red,amber,green,crqs_this_week,overallocated_people}, projects:Array<PortfolioRow>, change_mgmt:Array<ChangeMgmtRow>, health_tiles:{overall:Health|null}, capacity_teams:Array<{team,available,confirmed,tentative,util}>}>} */
export const getPortfolio = (params = {}) => get('/portfolio', params);
/** @returns {Promise<{start,end,today,freeze:{start,end},trains:Array<{code,train_date}>, rows:Array<{initiative_id,rddc,name,rag,stage,start,end,readiness_date,prod_date}>}>} */
export const getPortfolioGantt = (params = {}) => get('/portfolio/gantt', params);
/** @returns {Promise<{items:Array<{rddc,name,priority,stage,submitted_at,session:{id,session_date,start_time}|null,action_required_by:string|null,waiting_on:string|null}>, sessions:Array<GroomingSession>}>} */
export const getIntakeQueue = () => get('/intake-queue');
/** @returns {Promise<Health>} see docs/contracts.md "Health" */
export const getInitiativeHealth = (id) => get(`/initiatives/${id}/health`);
/** Per-dimension DC PM override; rag null clears it. @param {{dimension:'schedule'|'resources'|'scope'|'dependencies'|'budget', rag:'Red'|'Amber'|'Green'|null, reason:string}} body @returns {Promise<Health>} */
export const overrideHealth = (id, body) => put(`/initiatives/${id}/health/override`, body);
/** @returns {Promise<Gantt>} see docs/contracts.md "Gantt" */
export const getGantt = (id) => get(`/initiatives/${id}/gantt`);
/** @param {{from?:'YYYY-MM', to?:'YYYY-MM', group?:'resource'|'team'|'quarter', initiative_id?:number, team?:string}} params @returns {Promise<Capacity>} */
export const getCapacity = (params = {}) => get('/capacity', params);
/** Pg 3 quarter grid. @returns {Promise<{fy:string, quarters:Array<{fy,q,label,months}>, rows:Array<{resource_id,name,team,role,cells:Array<{quarter,availability,allocation,confirmed,tentative,util,band}>}>, assignments:Array<object>}>} */
export const getResourceGrid = (id) => get(`/initiatives/${id}/resource-grid`);
/** @returns {Promise<{items:Array<{prn_code,name,lob,funded_hours,charged_hours,forecast_hours,status}>, total:number}>} */
export const listPrns = () => get('/prns');
/** @returns {Promise<Burndown>} */
export const getPrnBurndown = (prnCode) => get(`/prn/${enc(prnCode)}/burndown`);
/** @returns {Promise<Burndown>} */
export const getInitiativeBurndown = (id) => get(`/initiatives/${id}/burndown`);
/** @returns {Promise<L2Estimate>} engine numbers, nothing saved */
export const calculateL2 = (id) => post(`/initiatives/${id}/l2/calculate`, {});
/** @returns {Promise<{initiative:Initiative, notifications:Array<Notification>}>} */
export const submitL2 = (id, body = {}) => post(`/initiatives/${id}/l2/submit`, body);
/** @returns {Promise<{initiative:Initiative, health:Health}>} */
export const approveL2 = (id, body = {}) => post(`/initiatives/${id}/l2/approve`, body);
/** @returns {Promise<{initiative:Initiative}>} */
export const rejectL2 = (id, { reason }) => post(`/initiatives/${id}/l2/reject`, { reason });
/** @param {{dry_run?:boolean}} body @returns {Promise<{assignments:Array<{session_id,session_date,start_time,initiative_id,rddc,recipients:Array<{id,name}>}>, unslotted:Array<{initiative_id,rddc,reason}>}>} */
export const autoSlotGrooming = (body = {}) => post('/grooming/auto-slot', body);
/** @returns {Promise<{created:Array<Notification>, skipped:number}>} */
export const runReminders = (body = {}) => post('/reminders/run', body);
/** @param {{week?:string}} params ISO week 'YYYY-Www' @returns {Promise<{week:string, from:string, to:string, items:Array<ChangeRequest & {compliance}>, noncompliant_count:number}>} */
export const getGovernanceWeekly = (params = {}) => get('/governance/weekly', params);
/** @returns {Promise<{items:Array<{kind:'l2'|'component'|'sto', initiative_id, rddc, name, entity_id, title, requested_at, waiting_days, approver}>, total:number}>} */
export const getApprovals = () => get('/governance/approvals');

// ------------------------------------------------------------------ export (return URLs for <a href download>)
/** @returns {string} */
export const exportDemoViewUrl = (id) => `${BASE}/export/demo-view.xlsx${buildQuery({ initiative_id: id })}`;
/** @returns {string} */
export const exportPortfolioXlsxUrl = () => `${BASE}/export/portfolio.xlsx`;
/** @returns {string} */
export const exportPortfolioCsvUrl = (params = {}) => `${BASE}/export/portfolio.csv${buildQuery(params)}`;

// ------------------------------------------------------------------ AI  (every call returns an AiRun envelope; nothing is saved until applyAiRun)
export const INITIATIVE_AI_FEATURES = ['intake-analysis', 'change-summary', 'l2-estimate', 'wbs', 'resources', 'rebalance', 'risks', 'exec-summary', 'cr-compliance'];
export const GLOBAL_AI_FEATURES = ['intake-analysis', 'intake-autofill', 'skill-matrix', 'exec-summary', 'nudges', 'meeting-extract', 'lessons'];

/**
 * @param {string} feature kebab-case, one of INITIATIVE_AI_FEATURES
 * @param {{instruction?:string, regen_of?:number, options?:object}} [body]
 * @returns {Promise<AiRun>} {ai_run_id, feature, initiative_id, scope, mode, mode_label, model, variant_index, confidence, sources, warnings, output, status, latency_ms, minutes_saved, regen_of, created_at}
 */
export const runInitiativeAi = (id, feature, body = {}) => aiPost(`/initiatives/${id}/ai/${feature}`, body);
/** @param {string} feature kebab-case, one of GLOBAL_AI_FEATURES @returns {Promise<AiRun>} */
export const runGlobalAi = (feature, body = {}) => aiPost(`/ai/${feature}`, body);

/** F1 @returns {Promise<AiRun>} */
export const aiIntakeAnalysis = (id, body = {}) => runInitiativeAi(id, 'intake-analysis', body);
/** F2 @returns {Promise<AiRun>} */
export const aiChangeSummary = (id, body = {}) => runInitiativeAi(id, 'change-summary', body);
/** F3 @returns {Promise<AiRun>} */
export const aiL2Estimate = (id, body = {}) => runInitiativeAi(id, 'l2-estimate', body);
/** F4 @returns {Promise<AiRun>} */
export const aiWbs = (id, body = {}) => runInitiativeAi(id, 'wbs', body);
/** F5 @param {{options?:{wbs_code?:string}}} body @returns {Promise<AiRun>} */
export const aiResources = (id, body = {}) => runInitiativeAi(id, 'resources', body);
/** F6 @param {{options?:{wbs_code?:string, resource_id?:number}}} body @returns {Promise<AiRun>} */
export const aiRebalance = (id, body = {}) => runInitiativeAi(id, 'rebalance', body);
/** F7 @returns {Promise<AiRun>} */
export const aiRisks = (id, body = {}) => runInitiativeAi(id, 'risks', body);
/** F8 initiative scope @returns {Promise<AiRun>} */
export const aiExecSummary = (id, body = {}) => runInitiativeAi(id, 'exec-summary', body);
/** F9 @param {{options:{change_request_id:number}}} body @returns {Promise<AiRun>} */
export const aiCrCompliance = (id, body = {}) => runInitiativeAi(id, 'cr-compliance', body);
/** F1 before the initiative exists. @param {{name, description, lob}} body @returns {Promise<AiRun>} */
export const aiIntakeAnalysisDraft = (body) => runGlobalAi('intake-analysis', body);
/** F14 @param {{attachment_id?:number, text?:string, filename?:string}} body @returns {Promise<AiRun>} */
export const aiIntakeAutofill = (body) => runGlobalAi('intake-autofill', body);
/** F10 @returns {Promise<AiRun>} */
export const aiSkillMatrix = (body = {}) => runGlobalAi('skill-matrix', body);
/** F8 portfolio scope @returns {Promise<AiRun>} */
export const aiPortfolioExecSummary = (body = {}) => runGlobalAi('exec-summary', body);
/** F11 @returns {Promise<AiRun>} */
export const aiNudges = (body = {}) => runGlobalAi('nudges', body);
/** F12 @param {{meeting_note_id?:number, text?:string}} body @returns {Promise<AiRun>} */
export const aiMeetingExtract = (body) => runGlobalAi('meeting-extract', body);
/** F13 @param {{initiative_id?:number}} body @returns {Promise<AiRun>} */
export const aiLessons = (body = {}) => runGlobalAi('lessons', body);

/** Accept (optionally a subset / an edited version). @param {{selected?:number[], edited_output?:object}} body @returns {Promise<{ai_run_id, status:'accepted', initiative_id, applied:Object<string,number>, minutes_saved:number, health?:Health}>} */
export const applyAiRun = (runId, body = {}) => request('POST', `/ai-runs/${runId}/apply`, { body, timeout: AI_TIMEOUT_MS });
/** @returns {Promise<{ai_run_id, status:'rejected'}>} */
export const rejectAiRun = (runId, { reason } = {}) => post(`/ai-runs/${runId}/reject`, { reason });
/** @param {{feature?, initiative_id?, status?, limit?}} params @returns {Promise<{items:Array<AiRunSummary>, total:number}>} */
export const listAiRuns = (params = {}) => get('/ai-runs', params);
/** @returns {Promise<AiRun & {input_json:object, edited_output_json:object|null, instruction, tokens_in, tokens_out, prompt_version}>} */
export const getAiRun = (runId) => get(`/ai-runs/${runId}`);
/** @returns {Promise<{runs:number, accepted:number, rejected:number, acceptance_rate:number, minutes_saved:number, by_feature:Array<{feature,runs,accepted,minutes_saved}>}>} */
export const getAiStats = () => get('/ai-runs/stats');

/** F15 @param {{message:string, conversation_id?:string, initiative_id?:number, page?:string}} body @returns {Promise<{conversation_id, answer_md, citations:Array<{type,id,label,route}>, suggested_actions:Array<{label,route?:string}>, follow_ups:string[], ai_run_id, mode, mode_label}>} */
export const chat = (body) => aiPost('/assistant/chat', body);
/** @returns {Promise<{conversation_id, messages:Array<{id,role,content,created_at,ai_run_id}>}>} */
export const getConversation = (conversationId) => get(`/assistant/conversations/${enc(conversationId)}`);
