// trains.js: release-train calendar strip. renderReleaseCalendar(el, releaseTrains, {today?, onTrainClick?(train)})
import { hideTip, h, clear, bindTip, dayNum, isoFromDay, fmtDate } from './kit.js';
import { s, stext, svgRoot, chartEmpty, widthOf, watchWidth, timeScale, drawTimeAxis, TODAY_FOOTER } from './svg.js';

export function renderReleaseCalendar(el, data, opts = {}) {
  let current = data;
  el.classList.add('ch-host', 'ch-trains');
  let unwatch = () => {};

  function draw() {
    const d = current || {};
    const trains = (Array.isArray(d.items) ? d.items : []).filter((t) => !Number.isNaN(dayNum(t.train_date)));
    if (!trains.length) {
      chartEmpty(el, 'No release trains are scheduled.');
      return;
    }
    clear(el);
    const dates = trains.map((t) => dayNum(t.train_date));
    let lo = Math.min(...dates) - 10;
    let hi = Math.max(...dates) + 10;
    const todayN = dayNum(opts.today);
    if (!Number.isNaN(todayN)) { lo = Math.min(lo, todayN); hi = Math.max(hi, todayN); }
    const width = widthOf(el);
    const ts = timeScale({ startIso: isoFromDay(lo), endIso: isoFromDay(hi), width: width - 16, scale: 'month' });
    const headerH = 40;
    const bodyH = 64;
    const root = svgRoot(ts.width + 16, headerH + bodyH + TODAY_FOOTER, 'Release train calendar');
    el.appendChild(h('div', { class: 'ch-scroll' }, root));
    const bg = s('g', {}, root);
    const header = s('g', {}, root);
    const marks = s('g', {}, root);
    const over = s('g', {}, root);
    drawTimeAxis(root, { bg, header, over }, ts, { x0: 8, bodyTop: headerH, bodyH, freeze: d.freeze, trains: [], today: opts.today, compact: true });
    if (d.freeze && d.freeze.start) {
      const fx = 8 + ts.x(d.freeze.start);
      const fw = ts.x(d.freeze.end) + ts.pxPerDay - ts.x(d.freeze.start);
      if (fw > 40) stext(over, fx + fw / 2, headerH + bodyH - 8, 'Change freeze', { class: 'ch-freeze-label', 'text-anchor': 'middle' });
    }
    trains.forEach((t, i) => {
      const x = 8 + ts.x(t.train_date) + ts.pxPerDay / 2;
      const done = t.status === 'Done';
      const g = s('g', { class: `ch-train-mark${done ? ' is-done' : ''}${t.in_freeze ? ' is-freeze' : ''}`, tabindex: 0 }, marks);
      s('line', { x1: x, x2: x, y1: headerH, y2: headerH + bodyH, class: 'ch-train-stem' }, g);
      const y = headerH + 10 + (i % 2) * 20;
      s('circle', { cx: x, cy: y, r: 6 }, g);
      stext(g, x + 9, y + 4, t.code, { class: 'ch-train-code' });
      const inits = Array.isArray(t.initiatives) ? t.initiatives : [];
      bindTip(g, () => [
        `${t.code} · ${fmtDate(t.train_date)}`,
        done ? 'Released' : t.in_freeze ? 'Inside the change freeze' : 'Planned',
        inits.length ? `${inits.length} initiative${inits.length === 1 ? '' : 's'}: ${inits.map((x2) => x2.rddc).join(', ')}` : 'No initiatives on this train',
      ]);
      if (opts.onTrainClick) {
        g.classList.add('is-clickable');
        g.addEventListener('click', () => opts.onTrainClick(t));
        g.addEventListener('keydown', (e) => { if (e.key === 'Enter') opts.onTrainClick(t); });
      }
    });
  }

  draw();
  unwatch = watchWidth(el, draw);
  return {
    update(json) { current = json; draw(); },
    destroy() { hideTip(); unwatch(); clear(el); },
  };
}
