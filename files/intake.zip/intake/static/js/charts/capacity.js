// capacity.js: team demand vs availability bars (UX §4.3).
// renderTeamBars(el, teams, {quarters?:[{value,label}], quarter?, onQuarterChange?(value), periodLabel?, order?})
import { hideTip, h, clear, bindTip, fmtNum, isNum, num, selectEl } from './kit.js';
import { s, stext, svgRoot, hatch, chartEmpty, widthOf, watchWidth, fit } from './svg.js';

export const DECK_TEAM_ORDER = ['EAPI (Dev1)', 'EAPI (Dev2)', 'EAPI Tech Lead', 'CIAM', 'SRE', 'Mobile', 'Web', 'QA', 'DC SA'];

export function teamUtil(t) {
  const avail = num(t.available);
  const demand = num(t.confirmed) + num(t.tentative);
  if (isNum(t.util)) return Number(t.util);
  return avail ? demand / avail : demand ? Infinity : 0;
}

export function renderTeamBars(el, teams, opts = {}) {
  let current = teams;
  el.classList.add('ch-host', 'ch-teambars');
  let unwatch = () => {};

  function draw() {
    clear(el);
    if (opts.quarters && opts.quarters.length) {
      el.appendChild(h('div', { class: 'ch-toolbar ch-toolbar-tight' },
        selectEl(opts.quarters, opts.quarter, (v) => { opts.quarter = v; if (opts.onQuarterChange) opts.onQuarterChange(v); }, { label: 'Period' })));
    }
    const order = opts.order || DECK_TEAM_ORDER;
    const list = (Array.isArray(current) ? current : []).filter((t) => t && t.team)
      .slice().sort((a, b) => {
        const ia = order.indexOf(a.team);
        const ib = order.indexOf(b.team);
        return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
      });
    if (!list.length) {
      const holder = h('div');
      el.appendChild(holder);
      chartEmpty(holder, 'No team capacity for this period yet.');
      return;
    }
    const width = widthOf(el);
    const labelW = Math.min(118, Math.max(84, width * 0.24));
    const valueW = width < 420 ? 112 : 150;
    const rowH = 34;
    const barH = 14;
    const maxUtil = Math.max(1, ...list.map((t) => (Number.isFinite(teamUtil(t)) ? teamUtil(t) : 1.5)));
    const scaleMax = Math.min(maxUtil, 1.5);
    const trackW = Math.max(60, (width - labelW - valueW - 12) / scaleMax);
    const height = list.length * rowH + 8;
    const root = svgRoot(width, height, 'Resource capacity by team');
    const hatchFill = hatch(root, '#0079C1');
    const hatchOver = hatch(root, '#D93025');
    el.appendChild(root);

    list.forEach((t, i) => {
      const cy = 4 + i * rowH + rowH / 2;
      const avail = num(t.available);
      const conf = num(t.confirmed);
      const tent = num(t.tentative);
      const util = teamUtil(t);
      const g = s('g', { class: 'ch-team', tabindex: 0 }, root);
      stext(g, 0, cy + 4, fit(t.team, labelW - 8), { class: 'ch-label' });
      const x0 = labelW;
      const unit = avail > 0 ? trackW / avail : 0;
      s('rect', { x: x0, y: cy - barH / 2, width: trackW, height: barH, rx: 2, class: 'ch-track' }, g);
      const maxPx = trackW * scaleMax;
      const confW = Math.min(conf * unit, maxPx);
      const tentW = Math.min(tent * unit, Math.max(0, maxPx - confW));
      const seg = (from, w, fill, cls) => { if (w > 0.5) s('rect', { x: x0 + from, y: cy - barH / 2, width: w, height: barH, fill, class: cls }, g); };
      // confirmed: blue up to the track end, red beyond
      seg(0, Math.min(confW, trackW), null, 'ch-conf');
      seg(trackW, Math.max(0, confW - trackW), null, 'ch-overflow');
      // tentative: hatched, red-hatched beyond the track end
      const tStart = confW;
      const tInside = Math.max(0, Math.min(tentW, trackW - tStart));
      seg(tStart, tInside, hatchFill, 'ch-tent');
      seg(tStart + tInside, tentW - tInside, hatchOver, 'ch-tent-over');
      if (!avail && (conf || tent)) seg(0, Math.min(trackW, 40), hatchOver, 'ch-tent-over');
      s('line', { x1: x0 + trackW, x2: x0 + trackW, y1: cy - barH / 2 - 3, y2: cy + barH / 2 + 3, class: 'ch-track-end' }, g);
      const pctText = avail ? `${Math.round(util * 100)}%` : 'No availability';
      const valueText = avail ? `${pctText} · ${fmtNum(conf + tent)} / ${fmtNum(avail)} h` : pctText;
      stext(g, width - 2, cy + 4, valueText, { class: `ch-value${util > 1.1 ? ' is-over' : util > 1 ? ' is-stretch' : ''}`, 'text-anchor': 'end' });
      bindTip(g, () => [
        `${t.team}${opts.periodLabel ? ` · ${opts.periodLabel}` : ''}`,
        `Confirmed ${fmtNum(conf, 1)} h · Tentative ${fmtNum(tent, 1)} h`,
        `Available ${fmtNum(avail, 1)} h${avail ? ` · ${Math.round(util * 100)}% used` : ''}`,
        util > 1 ? `Over capacity by ${fmtNum(conf + tent - avail, 1)} h` : null,
      ]);
    });

    el.appendChild(h('div', { class: 'ch-legend' },
      h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-conf-sw' }), 'Confirmed'),
      h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-tent-sw' }), 'Tentative'),
      h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-avail-sw' }), 'Available'),
      h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-over-sw' }), 'Over capacity')));
  }

  draw();
  unwatch = watchWidth(el, draw);
  return {
    update(json) { current = json; draw(); },
    destroy() { hideTip(); unwatch(); clear(el); },
  };
}
