// gantt.js: WBS Gantt (UX §4.1). renderGantt(el, gantt, {onTaskClick?, compact?, scale?, colorBy?, showCritical?})
import { hideTip, h, clear, dayNum, fmtDate, fmtShort, bindTip, isNum, num, segmented, isoFromDay } from './kit.js';
import { s, stext, svgRoot, arrowMarker, chartEmpty, widthOf, watchWidth, fit, timeScale, drawTimeAxis, TODAY_FOOTER } from './svg.js';

export const PHASE_GROUP = {
  Estimation: 'est', Development: 'dev', Integration: 'qa', QA: 'qa', UAT: 'qa', Readiness: 'prod', Production: 'prod', Hypercare: 'prod',
};
export const PHASE_GROUP_LABEL = { est: 'Estimation', dev: 'Development', qa: 'QA', prod: 'Production' };
const STATUS_LEGEND = [['backlog', 'Backlog'], ['prog', 'In progress'], ['done', 'Completed'], ['risk', 'At risk'], ['late', 'Late']];
const EMPTY_TEXT = 'The Gantt view appears once the plan has steps with start and end dates.';

function hasDates(t) {
  return t && !Number.isNaN(dayNum(t.planned_start)) && !Number.isNaN(dayNum(t.planned_end || t.planned_start));
}
function statusKey(t, today) {
  const pct = num(t.pct);
  if (t.status === 'Completed' || pct >= 100) return 'done';
  if (today && dayNum(today) > dayNum(t.planned_end) && pct < 100) return 'late';
  if (t.at_risk || t.status === 'Blocked') return 'risk';
  if (t.status === 'In progress') return 'prog';
  return 'backlog';
}

export function renderGantt(el, gantt, opts = {}) {
  const compact = Boolean(opts.compact);
  const state = { scale: opts.scale || 'month', colorBy: opts.colorBy || 'phase', critical: Boolean(opts.showCritical), data: gantt };
  el.classList.add('ch-host', 'ch-gantt');
  el.classList.toggle('is-compact', compact);
  let unwatch = () => {};

  function draw() {
    const data = state.data || {};
    const tasks = (Array.isArray(data.tasks) ? data.tasks : []).filter(hasDates);
    if (!tasks.length) {
      chartEmpty(el, EMPTY_TEXT);
      return;
    }
    clear(el);
    const today = data.today || null;
    const criticalIds = new Set((Array.isArray(data.critical_path) ? data.critical_path : []).map(String));
    const isCritical = (t) => Boolean(t.critical) || criticalIds.has(String(t.id));

    if (!compact) el.appendChild(toolbar());
    const scroll = h('div', { class: 'ch-scroll' });
    el.appendChild(scroll);

    const labelW = compact ? 128 : 240;
    const rightPad = compact ? 12 : 44;
    const total = widthOf(el);
    const starts = tasks.map((t) => dayNum(t.planned_start));
    const ends = tasks.map((t) => dayNum(t.planned_end || t.planned_start));
    let lo = Math.min(...starts);
    let hi = Math.max(...ends);
    const todayN = dayNum(today);
    if (!Number.isNaN(todayN) && todayN >= lo - 45 && todayN <= hi + 45) { lo = Math.min(lo, todayN); hi = Math.max(hi, todayN); }
    const ts = timeScale({ startIso: isoFromDay(lo), endIso: isoFromDay(hi), width: total - labelW - rightPad, scale: state.scale });
    if (!ts) {
      chartEmpty(el, EMPTY_TEXT);
      return;
    }
    const headerH = compact ? 50 : 74;
    const rowH = compact ? 26 : 32;
    const barH = compact ? 12 : 14;
    const bodyH = tasks.length * rowH;
    const svgW = labelW + ts.width + rightPad;
    const svgH = headerH + bodyH + TODAY_FOOTER;
    const root = svgRoot(svgW, svgH, compact ? 'Project Gantt by phase' : 'Project Gantt');
    if (state.critical) root.classList.add('is-critical-mode');
    scroll.appendChild(root);
    const bg = s('g', { class: 'ch-layer-bg' }, root);
    const rowsLayer = s('g', {}, root);
    const depLayer = s('g', { class: 'ch-deps' }, root);
    const barLayer = s('g', {}, root);
    const over = s('g', {}, root);
    const header = s('g', {}, root);
    const arrow = arrowMarker(root, '#7A8796');
    const arrowCrit = arrowMarker(root, '#0A2240');

    drawTimeAxis(root, { bg, header, over }, ts, {
      x0: labelW, bodyTop: headerH, bodyH, freeze: data.freeze, trains: data.trains || [], today, compact,
      highlightTrain: opts.targetTrain || null, trainRowY: 39, freezeRowY: compact ? null : 57,
    });

    const pos = new Map();
    tasks.forEach((t, i) => {
      const y = headerH + i * rowH;
      const cy = y + rowH / 2;
      if (i % 2) s('rect', { x: 0, y, width: svgW, height: rowH, class: 'ch-row-alt' }, rowsLayer);
      // label column
      const indent = t.parent_id ? 16 : 0;
      const labelG = s('g', { class: 'ch-row-label' }, rowsLayer);
      if (compact) {
        stext(labelG, 8 + indent, cy + 4, fit(t.step, labelW - 14 - indent), { class: 'ch-label' });
      } else {
        stext(labelG, 8 + indent, cy + 4, t.wbs_code || '', { class: 'ch-label-code' });
        stext(labelG, 70 + indent, cy + 4, fit(t.step, labelW - 78 - indent), { class: `ch-label${t.is_summary ? ' is-summary' : ''}` });
      }
      const tt = s('title', {}, labelG);
      tt.textContent = [t.wbs_code, t.step].filter(Boolean).join(' · ');

      const x = labelW + ts.x(t.planned_start);
      const xEnd = labelW + ts.x(t.planned_end || t.planned_start) + ts.pxPerDay;
      const w = Math.max(4, xEnd - x);
      const crit = isCritical(t);
      const group = PHASE_GROUP[t.phase] || 'other';
      const colourCls = state.colorBy === 'status' ? `ch-st-${statusKey(t, today)}` : `ch-ph-${group}`;
      const g = s('g', { class: `ch-bar ${colourCls}${crit ? ' is-critical' : ''}`, tabindex: 0, 'data-task': String(t.id) }, barLayer);
      if (t.is_milestone) {
        const mx = labelW + ts.x(t.planned_end || t.planned_start) + ts.pxPerDay / 2;
        const r = compact ? 6 : 7;
        s('path', { d: `M${mx},${cy - r} L${mx + r},${cy} L${mx},${cy + r} L${mx - r},${cy} Z`, class: 'ch-milestone' }, g);
        if (!compact) stext(g, mx + r + 12, cy + 4, fmtShort(t.planned_end || t.planned_start), { class: 'ch-bar-note' });
        pos.set(String(t.id), { x: mx - r, x2: mx + r, cy, crit });
      } else if (t.is_summary) {
        s('rect', { x, y: cy - 3, width: w, height: 6, class: 'ch-summary' }, g);
        s('path', { d: `M${x},${cy + 3} l0,5 l5,-5 Z M${x + w},${cy + 3} l0,5 l-5,-5 Z`, class: 'ch-summary' }, g);
        pos.set(String(t.id), { x, x2: x + w, cy, crit });
      } else {
        if (!compact && t.baseline_end && t.baseline_start && (t.baseline_end !== t.planned_end || t.baseline_start !== t.planned_start)) {
          const bx = labelW + ts.x(t.baseline_start);
          const bx2 = labelW + ts.x(t.baseline_end) + ts.pxPerDay;
          s('rect', { x: bx, y: cy + barH / 2 + 2, width: Math.max(3, bx2 - bx), height: 3, class: 'ch-baseline' }, g);
        }
        s('rect', { x, y: cy - barH / 2, width: w, height: barH, rx: 3, class: 'ch-bar-bg' }, g);
        const pct = Math.min(100, Math.max(0, num(t.pct)));
        if (pct > 0) s('rect', { x, y: cy - barH / 2, width: Math.max(2, (w * pct) / 100), height: barH, rx: 3, class: 'ch-bar-fill' }, g);
        s('rect', { x, y: cy - barH / 2, width: w, height: barH, rx: 3, class: 'ch-bar-outline' }, g);
        // % sits inside the bar (connectors leave from the bar end); the tooltip carries it for short bars
        if (!compact && w >= 36) stext(g, x + w - 4, cy + 4, `${pct}%`, { class: 'ch-bar-pct', 'text-anchor': 'end' });
        pos.set(String(t.id), { x, x2: x + w, cy, crit });
      }
      bindTip(g, () => tipLines(t, crit));
      if (opts.onTaskClick) {
        g.classList.add('is-clickable');
        g.addEventListener('click', () => opts.onTaskClick(t));
        g.addEventListener('keydown', (e) => { if (e.key === 'Enter') opts.onTaskClick(t); });
      }
      g.addEventListener('pointerenter', () => highlight(String(t.id), true));
      g.addEventListener('pointerleave', () => highlight(String(t.id), false));
    });

    // finish-to-start elbow connectors
    for (const t of tasks) {
      const to = pos.get(String(t.id));
      if (!to) continue;
      for (const depId of Array.isArray(t.depends_on) ? t.depends_on : []) {
        const from = pos.get(String(depId));
        if (!from) continue;
        const x1 = from.x2;
        const y1 = from.cy;
        const x2 = to.x;
        const y2 = to.cy;
        let d;
        if (x2 - x1 >= 16) d = `M${x1},${y1} H${x1 + 8} V${y2} H${x2 - 1}`;
        else {
          const midY = y2 > y1 ? y2 - rowH / 2 : y2 + rowH / 2;
          d = `M${x1},${y1} H${x1 + 8} V${midY} H${x2 - 8} V${y2} H${x2 - 1}`;
        }
        const crit = state.critical && from.crit && to.crit;
        s('path', { d, class: `ch-dep${crit ? ' is-critical' : ''}`, 'marker-end': crit ? arrowCrit : arrow, 'data-from': String(depId), 'data-to': String(t.id) }, depLayer);
      }
    }

    function highlight(id, on) {
      depLayer.querySelectorAll(`[data-from="${id}"], [data-to="${id}"]`).forEach((p) => p.classList.toggle('is-hl', on));
    }

    if (!compact) el.appendChild(legend(tasks, isCritical));
  }

  function tipLines(t, crit) {
    const lines = [[t.wbs_code, t.step].filter(Boolean).join(' · ')];
    if (t.is_milestone) lines.push(`Milestone ${fmtDate(t.planned_end || t.planned_start)}`);
    else lines.push(`${fmtDate(t.planned_start)} – ${fmtDate(t.planned_end)}`);
    if (t.phase) lines.push(`Phase: ${t.phase}`);
    if (t.resource_name) lines.push(`Resource: ${t.resource_name}`);
    if (!t.is_summary && !t.is_milestone) lines.push(`Status: ${t.status || 'Backlog'} · ${num(t.pct)}% complete`);
    if (isNum(t.float_bd)) lines.push(`Float: ${t.float_bd} business days`);
    if (t.baseline_end && t.baseline_end !== t.planned_end) lines.push(`Baseline end: ${fmtDate(t.baseline_end)}`);
    if (crit) lines.push('On the critical path');
    return lines;
  }

  function toolbar() {
    const crit = h('input', { type: 'checkbox', checked: state.critical });
    crit.addEventListener('change', () => { state.critical = crit.checked; draw(); });
    return h('div', { class: 'ch-toolbar' },
      h('span', { class: 'ch-toolbar-label', text: 'Scale' }),
      segmented([{ value: 'week', label: 'Week' }, { value: 'month', label: 'Month' }], state.scale, (v) => { state.scale = v; draw(); }, { label: 'Scale' }),
      h('span', { class: 'ch-toolbar-label', text: 'Colour by' }),
      segmented([{ value: 'phase', label: 'Phase' }, { value: 'status', label: 'Status' }], state.colorBy, (v) => { state.colorBy = v; draw(); }, { label: 'Colour by' }),
      h('label', { class: 'ch-check' }, crit, h('span', { text: 'Show critical path' })));
  }

  function legend(tasks, isCritical) {
    const items = state.colorBy === 'status'
      ? STATUS_LEGEND.map(([k, label]) => [`ch-st-${k}`, label])
      : Object.entries(PHASE_GROUP_LABEL).map(([k, label]) => [`ch-ph-${k}`, label]);
    const box = h('div', { class: 'ch-legend' },
      items.map(([cls, label]) => h('span', { class: 'ch-legend-item' }, h('span', { class: `ch-swatch ${cls}` }), label)),
      h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-swatch-diamond' }), 'Milestone'),
      h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-swatch-today' }), 'Today'),
      h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-swatch-freeze' }), 'Change freeze'),
      h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-swatch-train' }), 'Release train'),
      h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-swatch-baseline' }), 'Baseline'));
    if (state.critical) {
      const chain = tasks.filter((t) => isCritical(t) && !t.is_summary).sort((a, b) => dayNum(a.planned_start) - dayNum(b.planned_start));
      if (chain.length) {
        const first = Math.min(...chain.map((t) => dayNum(t.planned_start)));
        const last = Math.max(...chain.map((t) => dayNum(t.planned_end || t.planned_start)));
        const weeks = Math.max(1, Math.round((last - first + 1) / 7));
        box.appendChild(h('div', { class: 'ch-critical-line', text: `Critical path: ${criticalSteps(chain).join(' → ')} · ${weeks} weeks (${fmtDate(isoFromDay(first))} – ${fmtDate(isoFromDay(last))})` }));
      } else box.appendChild(h('div', { class: 'ch-critical-line', text: 'Critical path: no steps are on the critical path.' }));
    }
    return box;
  }

  draw();
  unwatch = watchWidth(el, draw);
  return {
    update(json) { state.data = json; draw(); },
    destroy() { hideTip(); unwatch(); clear(el); },
  };
}

/** Groups steps that run in parallel (overlapping dates) so the chain reads as sequence: WBS-210/220/230. */
export function criticalSteps(chain) {
  const groups = [];
  for (const t of chain) {
    const s0 = dayNum(t.planned_start);
    const e0 = dayNum(t.planned_end || t.planned_start);
    const g = groups[groups.length - 1];
    if (g && s0 <= g.end && s0 >= g.start) {
      g.items.push(t);
      g.end = Math.max(g.end, e0);
    } else groups.push({ start: s0, end: e0, items: [t] });
  }
  return groups.map((g) => {
    const codes = g.items.map((t) => t.wbs_code || t.step);
    if (codes.length === 1) return codes[0];
    const prefix = /^(WBS-)/.exec(codes[0]) ? 'WBS-' : '';
    return prefix ? `${prefix}${codes.map((c) => c.replace(/^WBS-/, '')).join('/')}` : codes.join(' / ');
  });
}

/** Rolls WBS tasks up into the four deck phases (Estimation / Development / QA / Production) for the Pg 5 tile. */
export function phaseGantt(gantt) {
  const tasks = (gantt && Array.isArray(gantt.tasks) ? gantt.tasks : []).filter((t) => hasDates(t) && !t.is_summary);
  const groups = ['est', 'dev', 'qa', 'prod'];
  const rows = [];
  for (const g of groups) {
    const list = tasks.filter((t) => (PHASE_GROUP[t.phase] || 'other') === g);
    if (!list.length) continue;
    const start = Math.min(...list.map((t) => dayNum(t.planned_start)));
    const end = Math.max(...list.map((t) => dayNum(t.planned_end || t.planned_start)));
    const hours = list.reduce((sum, t) => sum + Math.max(num(t.est_hours), 1), 0);
    const pct = Math.round(list.reduce((sum, t) => sum + num(t.pct) * Math.max(num(t.est_hours), 1), 0) / hours);
    rows.push({
      id: `phase-${g}`, wbs_code: '', step: PHASE_GROUP_LABEL[g], phase: list[0].phase,
      planned_start: isoFromDay(start), planned_end: isoFromDay(end), pct,
      status: pct >= 100 ? 'Completed' : pct > 0 ? 'In progress' : 'Backlog',
      critical: list.some((t) => t.critical), depends_on: rows.length ? [rows[rows.length - 1].id] : [], is_milestone: 0,
    });
  }
  return { ...(gantt || {}), tasks: rows, critical_path: [] };
}
