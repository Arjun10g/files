// burndown.js: PRN burndown (UX §4.4): hours remaining from the funded budget down to 0.
// renderBurndown(el, burndown, {today?}). Input is the contract Burndown (cumulative charged/forecast); this chart
// plots remaining = funded − cumulative, a straight even-burn plan line, and shades any forecast overrun below 0.
import { hideTip, h, clear, bindTip, fmtMonth, fmtMonthShort, fmtNum, isNum, num, dayNum, isoParts } from './kit.js';
import { s, stext, svgRoot, chartEmpty, widthOf, watchWidth } from './svg.js';

const STATUS = { on_track: ['On track', 'green'], at_risk: ['At risk', 'amber'], overrun: ['Overrun', 'red'] };

function series(arr, n) {
  const out = [];
  for (let i = 0; i < n; i += 1) out.push(Array.isArray(arr) && isNum(arr[i]) ? Number(arr[i]) : null);
  return out;
}
function niceStep(range) {
  const raw = range / 4;
  const mag = 10 ** Math.floor(Math.log10(Math.max(raw, 1)));
  const n = raw / mag;
  return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * mag;
}

export function renderBurndown(el, burndown, opts = {}) {
  let current = burndown;
  el.classList.add('ch-host', 'ch-burndown');
  let unwatch = () => {};

  function draw() {
    const b = current || {};
    const months = Array.isArray(b.months) ? b.months : [];
    if (!months.length || !isNum(b.funded_hours)) {
      chartEmpty(el, 'No PRN funding recorded for this initiative yet.');
      return;
    }
    clear(el);
    const n = months.length;
    const funded = num(b.funded_hours);
    const charged = series(b.charged_cum, n);
    const forecast = series(b.forecast_cum, n);
    const remaining = charged.map((v) => (v === null ? null : funded - v));
    const forecastRem = forecast.map((v) => (v === null ? null : funded - v));
    const plan = months.map((_, i) => (n > 1 ? funded * (1 - i / (n - 1)) : 0));
    const lastCharged = charged.reduce((acc, v) => (v === null ? acc : v), 0);
    const lastForecast = forecast.reduce((acc, v) => (v === null ? acc : v), lastCharged);
    const chargedIdx = charged.map((v, i) => (v === null ? -1 : i)).filter((i) => i >= 0);
    const recent = chargedIdx.slice(-4);
    // Burn rate and its window come from the API when present, so the widget and the Assistant quote the same number.
    const apiBurn = [b.burn_rate_h_per_month, b.burn_rate_hours, b.burn_rate].find((v) => isNum(v));
    const burnWindow = isNum(b.burn_window_months) ? Number(b.burn_window_months) : Math.max(1, recent.length - 1);
    const burn = apiBurn !== undefined ? Number(apiBurn) : recent.length >= 2 ? (charged[recent[recent.length - 1]] - charged[recent[0]]) / (recent.length - 1) : 0;
    const windowText = typeof b.burn_rate_window === 'string' && b.burn_rate_window ? b.burn_rate_window : `${burnWindow}-month average`;
    const burnText = b.burn_label || `Burn ${fmtNum(burn, 1)} h/month · ${windowText}`;
    const [statusLabel, statusCls] = STATUS[b.status] || STATUS.on_track;

    el.appendChild(h('div', { class: 'ch-statrow' },
      h('strong', { text: b.prn_code || 'PRN' }),
      h('span', { text: `Funded ${fmtNum(funded)} h` }),
      h('span', { text: `Charged ${fmtNum(lastCharged, 1)} h` }),
      h('span', { text: `Remaining ${fmtNum(funded - lastCharged, 1)} h` }),
      h('span', { text: `Forecast to finish ${fmtNum(lastForecast, 1)} h` }),
      h('span', { text: burnText }),
      h('span', { class: `dv-status dv-status-${statusCls}`, text: statusLabel }),
      b.exhaust_month ? h('span', { class: 'ch-stat-warn', text: `Funding exhausted by ${fmtMonth(b.exhaust_month)}` }) : null));

    const width = widthOf(el);
    const height = 220;
    const m = { l: 60, r: 14, t: 12, b: 28 };
    const plotW = width - m.l - m.r;
    const plotH = height - m.t - m.b;
    const minVal = Math.min(0, ...forecastRem.filter((v) => v !== null), ...remaining.filter((v) => v !== null));
    const step = niceStep(funded - minVal || 1);
    const yMax = Math.ceil(funded / step) * step || step;
    const yMin = minVal < 0 ? Math.floor(minVal / step) * step : 0;
    const xStep = n > 1 ? plotW / (n - 1) : plotW;
    const xi = (i) => m.l + (n > 1 ? i * xStep : plotW / 2);
    const y = (v) => m.t + plotH - ((v - yMin) / (yMax - yMin)) * plotH;
    const root = svgRoot(width, height, 'PRN burndown: hours remaining');
    el.appendChild(root);

    for (let v = yMin; v <= yMax + 0.001; v += step) {
      s('line', { x1: m.l, x2: width - m.r, y1: y(v), y2: y(v), class: v === 0 ? 'ch-axis-line' : 'ch-grid' }, root);
      stext(root, m.l - 6, y(v) + 4, `${fmtNum(v)} h`, { class: 'ch-axis', 'text-anchor': 'end' });
    }
    const labelEvery = Math.max(1, Math.ceil(n / Math.max(2, Math.floor(plotW / 48))));
    months.forEach((mo, i) => {
      if (i % labelEvery) return;
      const p = isoParts(mo);
      const label = p && (p.m === 1 || i === 0) ? `${fmtMonthShort(mo)} ${String(p.y).slice(2)}` : fmtMonthShort(mo);
      stext(root, xi(i), height - 8, label, { class: 'ch-axis', 'text-anchor': 'middle' });
    });

    // overrun: forecast remaining below zero
    const overIdx = forecastRem.map((v, i) => (v !== null && v < 0 ? i : -1)).filter((i) => i >= 0);
    if (overIdx.length) {
      const first = Math.max(0, overIdx[0] - 1);
      const last = overIdx[overIdx.length - 1];
      const top = [];
      const bottom = [];
      for (let i = first; i <= last; i += 1) {
        top.push(`${xi(i)},${y(0)}`);
        bottom.unshift(`${xi(i)},${y(Math.min(0, forecastRem[i] ?? 0))}`);
      }
      s('polygon', { points: [...top, ...bottom].join(' '), class: 'ch-overrun' }, root);
      const worst = Math.min(...overIdx.map((i) => forecastRem[i]));
      // label in the empty lower-left of the plot so the forecast line never crosses it
      stext(root, m.l + 8, m.t + plotH - 8, `Overrun risk: forecast exceeds funding by ${fmtNum(-worst)} h`, { class: 'ch-overrun-label', 'text-anchor': 'start' });
    }

    const path = (arr) => {
      let d = '';
      let pen = false;
      arr.forEach((v, i) => {
        if (v === null) { pen = false; return; }
        d += `${pen ? 'L' : 'M'}${xi(i)},${y(v)} `;
        pen = true;
      });
      return d.trim();
    };
    s('path', { d: path(plan), class: 'ch-line-plan' }, root);
    // forecast continues from the last actual point
    const fc = forecastRem.map((v, i) => (i >= (chargedIdx[chargedIdx.length - 1] ?? 0) ? v : null));
    const lastActual = chargedIdx[chargedIdx.length - 1];
    if (lastActual !== undefined && fc[lastActual] === null) fc[lastActual] = remaining[lastActual];
    const fcPath = path(fc);
    if (fcPath) s('path', { d: fcPath, class: 'ch-line-forecast' }, root);
    const remPath = path(remaining);
    if (remPath) s('path', { d: remPath, class: 'ch-line-actual' }, root);
    remaining.forEach((v, i) => {
      if (v === null) return;
      const dot = s('circle', { cx: xi(i), cy: y(v), r: 3, class: 'ch-dot', tabindex: 0 }, root);
      bindTip(dot, () => [fmtMonth(months[i]), `Remaining ${fmtNum(v, 1)} h of ${fmtNum(funded)} h`, `Charged to date ${fmtNum(charged[i], 1)} h`]);
    });
    fc.forEach((v, i) => {
      if (v === null || remaining[i] !== null) return;
      const hit = s('circle', { cx: xi(i), cy: y(v), r: 6, class: 'ch-hit', tabindex: 0 }, root);
      bindTip(hit, () => [fmtMonth(months[i]), `Forecast remaining ${fmtNum(v, 1)} h`, `Plan ${fmtNum(plan[i], 1)} h`]);
    });

    const today = opts.today || b.today;
    if (today) {
      const ym = today.slice(0, 7);
      const idx = months.indexOf(ym);
      if (idx >= 0) {
        const p = isoParts(today);
        const dim = dayNum(`${ym}-01`);
        const next = idx < n - 1 ? dayNum(`${months[idx + 1]}-01`) : dim + 30;
        const x = xi(idx) + (n > 1 ? ((p.d - 1) / Math.max(28, next - dim)) * xStep : 0);
        s('line', { x1: x, x2: x, y1: m.t, y2: m.t + plotH, class: 'ch-today' }, root);
        s('rect', { x: x - 21, y: m.t, width: 42, height: 15, rx: 7, class: 'ch-today-pill-rect' }, root);
        stext(root, x, m.t + 11, 'Today', { class: 'ch-today-pill-text', 'text-anchor': 'middle' });
      }
    }

    el.appendChild(h('div', { class: 'ch-legend' },
      h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-line-sw-plan' }), 'Plan (even burn to 0)'),
      h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-line-sw-actual' }), 'Remaining (actual)'),
      h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-line-sw-forecast' }), 'Forecast remaining'),
      overIdx.length ? h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-overrun-sw' }), 'Overrun risk') : null));
  }

  draw();
  unwatch = watchWidth(el, draw);
  return {
    update(json) { current = json; draw(); },
    destroy() { hideTip(); unwatch(); clear(el); },
  };
}
