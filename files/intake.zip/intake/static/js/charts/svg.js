// svg.js: low-level SVG helpers shared by every chart.
import { clear, h, dayNum, isoFromDay, isoParts, fiscalOf, fmtShort, fmtMonthShort } from './kit.js';

export const TODAY_FOOTER = 22;
export const NS = 'http://www.w3.org/2000/svg';
let uidCounter = 0;
export const uid = (prefix) => `${prefix}-${++uidCounter}`;

export function s(tag, attrs = {}, parent = null) {
  const el = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') el.setAttribute('class', v);
    else el.setAttribute(k, typeof v === 'number' ? String(Math.round(v * 100) / 100) : String(v));
  }
  if (parent) parent.appendChild(el);
  return el;
}
export function stext(parent, x, y, str, attrs = {}) {
  const t = s('text', { x, y, ...attrs }, parent);
  t.textContent = String(str ?? '');
  return t;
}
export function svgRoot(width, height, label) {
  const root = s('svg', { width, height, viewBox: `0 0 ${width} ${height}`, role: 'img', 'aria-label': label, class: 'ch-svg' });
  return root;
}
export function defs(root) {
  return root.querySelector('defs') || s('defs', {}, root);
}
export function hatch(root, color, id = uid('hatch')) {
  const p = s('pattern', { id, width: 6, height: 6, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(45)' }, defs(root));
  s('rect', { width: 6, height: 6, fill: color, 'fill-opacity': 0.4 }, p);
  s('line', { x1: 0, y1: 0, x2: 0, y2: 6, stroke: color, 'stroke-width': 2.4 }, p);
  return `url(#${id})`;
}
export function arrowMarker(root, color, id = uid('arrow')) {
  const m = s('marker', { id, viewBox: '0 0 6 6', refX: 5.5, refY: 3, markerWidth: 6, markerHeight: 6, orient: 'auto-start-reverse' }, defs(root));
  s('path', { d: 'M0,0 L6,3 L0,6 Z', fill: color }, m);
  return `url(#${id})`;
}
export function chartEmpty(el, message) {
  clear(el);
  el.appendChild(h('div', { class: 'ch-empty' }, h('span', { class: 'ch-empty-icon', 'aria-hidden': 'true' }), h('p', { text: message })));
}
export function widthOf(el, fallback = 800) {
  let w = el.clientWidth || (el.getBoundingClientRect ? el.getBoundingClientRect().width : 0);
  if (w && typeof getComputedStyle === 'function') {
    const cs = getComputedStyle(el);
    w -= (parseFloat(cs.paddingLeft) || 0) + (parseFloat(cs.paddingRight) || 0);
  }
  return Math.max(260, Math.floor(w || fallback) - 2);
}
/** Re-render on container width change. Returns a disconnect function. */
export function watchWidth(el, cb) {
  if (typeof ResizeObserver === 'undefined') return () => {};
  let last = el.clientWidth;
  let frame = 0;
  const ro = new ResizeObserver(() => {
    const w = el.clientWidth;
    if (!w || Math.abs(w - last) < 4) return;
    last = w;
    cancelAnimationFrame(frame);
    frame = requestAnimationFrame(cb);
  });
  ro.observe(el);
  return () => { cancelAnimationFrame(frame); ro.disconnect(); };
}
/** Truncate a label to fit `px` at roughly 6.4 px per character (12px UI font). */
export function fit(str, px, charPx = 6.4) {
  const text = String(str ?? '');
  const max = Math.max(3, Math.floor(px / charPx));
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

// ------------------------------------------------------------------ time axis
const firstOfMonth = (n) => { const iso = isoFromDay(n); return dayNum(`${iso.slice(0, 7)}-01`); };
const nextMonth = (n) => {
  const p = isoParts(isoFromDay(n));
  const y = p.m === 12 ? p.y + 1 : p.y;
  const m = p.m === 12 ? 1 : p.m + 1;
  return dayNum(`${y}-${String(m).padStart(2, '0')}-01`);
};
const mondayOf = (n) => n - ((((n + 4) % 7) + 6) % 7);

/**
 * Computes the day range and pixel scale.
 * scale 'month' fits the range into `width`; 'week' uses at least 44 px per week (the wrapper scrolls).
 */
export function timeScale({ startIso, endIso, width, scale = 'month' }) {
  let a = dayNum(startIso);
  let b = dayNum(endIso);
  if (Number.isNaN(a) || Number.isNaN(b)) return null;
  if (b < a) [a, b] = [b, a];
  if (scale === 'week') {
    a = mondayOf(a);
    b = mondayOf(b) + 7;
  } else {
    a = firstOfMonth(a);
    b = nextMonth(b);
  }
  const days = Math.max(1, b - a);
  const minPx = scale === 'week' ? 44 / 7 : 0;
  const pxPerDay = Math.max(minPx, width / days);
  return { a, b, days, pxPerDay, width: Math.round(days * pxPerDay), scale, x: (iso) => (dayNum(iso) - a) * pxPerDay, xd: (n) => (n - a) * pxPerDay };
}

/**
 * Draws quarter bands, month/week header, gridlines, freeze band, release trains and Today.
 * layers: {bg, header, over}; x0 = left offset of the plot; bodyTop/bodyH = plot body.
 * The Today pill sits in a 20 px footer below the body, so callers reserve TODAY_FOOTER px.
 */
export function drawTimeAxis(root, layers, ts, { x0, bodyTop, bodyH, freeze, trains = [], today, compact = false, highlightTrain, trainRowY, freezeRowY = null }) {
  const { bg, header, over } = layers;
  const qRowY = 0;
  const mRowY = 18;
  // fiscal quarter bands
  let n = ts.a;
  let qIdx = 0;
  while (n < ts.b) {
    const fq = fiscalOf(isoFromDay(n).slice(0, 7));
    let end = n;
    while (end < ts.b && fiscalOf(isoFromDay(end).slice(0, 7)).key === fq.key) end = nextMonth(end);
    end = Math.min(end, ts.b);
    const x = x0 + ts.xd(n);
    const w = ts.xd(end) - ts.xd(n);
    s('rect', { x, y: bodyTop, width: w, height: bodyH, class: qIdx % 2 ? 'ch-band-b' : 'ch-band-a' }, bg);
    s('rect', { x, y: qRowY, width: w, height: 17, class: qIdx % 2 ? 'ch-qhead-b' : 'ch-qhead-a' }, header);
    if (w > 46) stext(header, x + 6, qRowY + 12, `${fq.q} ${fq.fy}`, { class: 'ch-qlabel' });
    n = end;
    qIdx += 1;
  }
  // month or week header + gridlines
  if (ts.scale === 'week') {
    for (let d = ts.a; d < ts.b; d += 7) {
      const x = x0 + ts.xd(d);
      s('line', { x1: x, x2: x, y1: bodyTop, y2: bodyTop + bodyH, class: 'ch-grid' }, bg);
      stext(header, x + 3, mRowY + 13, fmtShort(isoFromDay(d)), { class: 'ch-axis' });
    }
  } else {
    for (let d = ts.a; d < ts.b; d = nextMonth(d)) {
      const x = x0 + ts.xd(d);
      const w = ts.xd(nextMonth(d)) - ts.xd(d);
      s('line', { x1: x, x2: x, y1: mRowY, y2: bodyTop + bodyH, class: 'ch-grid' }, bg);
      const iso = isoFromDay(d);
      const label = w > 54 ? `${fmtMonthShort(iso)} ${iso.slice(2, 4)}` : w > 22 ? fmtMonthShort(iso) : fmtMonthShort(iso).slice(0, 1);
      stext(header, x + w / 2, mRowY + 13, label, { class: 'ch-axis', 'text-anchor': 'middle' });
    }
  }
  s('line', { x1: x0, x2: x0 + ts.width, y1: bodyTop - 0.5, y2: bodyTop - 0.5, class: 'ch-axis-line' }, header);
  const inRange = (iso) => { const d = dayNum(iso); return !Number.isNaN(d) && d >= ts.a && d <= ts.b; };
  // freeze band
  if (freeze && freeze.start && freeze.end) {
    const fa = Math.max(dayNum(freeze.start), ts.a);
    const fb = Math.min(dayNum(freeze.end) + 1, ts.b);
    if (fb > fa) {
      const x = x0 + ts.xd(fa);
      const w = ts.xd(fb) - ts.xd(fa);
      const fill = hatch(root, '#9AA9B8');
      const band = s('rect', { x, y: bodyTop, width: w, height: bodyH, fill, class: 'ch-freeze' }, bg);
      const t = s('title', {}, band);
      t.textContent = `Change freeze ${fmtShort(freeze.start)} – ${fmtShort(freeze.end)}`;
      // own header row below the train markers, so train codes never overprint it
      if (!compact && w > 40 && freezeRowY !== null) stext(header, x + w / 2, freezeRowY + 10, w > 76 ? 'Change freeze' : 'Freeze', { class: 'ch-freeze-label', 'text-anchor': 'middle' });
    }
  }
  // release trains
  for (const tr of trains) {
    if (!tr || !inRange(tr.train_date)) continue;
    const x = x0 + ts.x(tr.train_date) + ts.pxPerDay / 2;
    const isTarget = highlightTrain && tr.code === highlightTrain;
    s('line', { x1: x, x2: x, y1: bodyTop, y2: bodyTop + bodyH, class: `ch-train-line${isTarget ? ' is-target' : ''}` }, bg);
    const y = trainRowY ?? (mRowY + 20);
    const g = s('g', { class: `ch-train${isTarget ? ' is-target' : ''}`, tabindex: 0 }, header);
    s('path', { d: `M${x - 5},${y + 2} L${x + 5},${y + 2} L${x},${y + 9} Z` }, g);
    if (!compact) stext(g, x + 7, y + 9, tr.code, { class: 'ch-train-label' });
    const t = s('title', {}, g);
    t.textContent = `Release train ${tr.code} · ${fmtShort(tr.train_date)}`;
  }
  // today
  if (today && inRange(today)) {
    const x = x0 + ts.x(today) + ts.pxPerDay / 2;
    s('line', { x1: x, x2: x, y1: bodyTop, y2: bodyTop + bodyH, class: 'ch-today' }, over);
    const label = `Today ${fmtShort(today)}`;
    const w = label.length * 6 + 12;
    const px = Math.min(Math.max(x - w / 2, x0), x0 + ts.width - w);
    const pill = s('g', { class: 'ch-today-pill' }, over);
    s('rect', { x: px, y: bodyTop + bodyH + 3, width: w, height: 16, rx: 8 }, pill);
    stext(pill, px + w / 2, bodyTop + bodyH + 15, label, { 'text-anchor': 'middle' });
  }
}
