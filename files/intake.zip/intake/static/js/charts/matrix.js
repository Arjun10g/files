// matrix.js: 4×4 risk matrix, severity × likelihood (master plan §6.1).
// renderRiskMatrix(el, risks, {onCellClick?(severity, likelihood), selected?:{severity, likelihood}, severityLabels?, likelihoodLabels?})
import { hideTip, h, clear, bindTip, num } from './kit.js';
import { s, stext, svgRoot } from './svg.js';

const SEV = { 1: 'Low', 2: 'Medium', 3: 'High', 4: 'Critical' };
const LIK = { 1: 'Rare', 2: 'Unlikely', 3: 'Possible', 4: 'Likely' };

export function scoreClass(score) {
  if (score >= 12) return 'm-red';
  if (score >= 8) return 'm-orange';
  if (score >= 4) return 'm-amber';
  return 'm-green';
}

export function renderRiskMatrix(el, risks, opts = {}) {
  let current = risks;
  el.classList.add('ch-host', 'ch-matrix');
  const sevL = { ...SEV, ...(opts.severityLabels || {}) };
  const likL = { ...LIK, ...(opts.likelihoodLabels || {}) };

  function draw() {
    clear(el);
    const list = (Array.isArray(current) ? current : []).filter((r) => r && r.status !== 'Closed');
    const cellW = 76;
    const cellH = 48;
    const left = 92;
    const top = 8;
    const width = left + 4 * cellW + 4;
    const height = top + 4 * cellH + 46;
    const root = svgRoot(width, height, 'Risk matrix, severity by likelihood');
    el.appendChild(h('div', { class: 'ch-scroll' }, root));
    for (let sev = 4; sev >= 1; sev -= 1) {
      const y = top + (4 - sev) * cellH;
      stext(root, left - 8, y + cellH / 2 + 4, sevL[sev], { class: 'ch-axis', 'text-anchor': 'end' });
      for (let lik = 1; lik <= 4; lik += 1) {
        const x = left + (lik - 1) * cellW;
        const inCell = list.filter((r) => num(r.severity) === sev && num(r.likelihood) === lik);
        const score = sev * lik;
        const sel = opts.selected && num(opts.selected.severity) === sev && num(opts.selected.likelihood) === lik;
        const g = s('g', { class: `ch-mcell ${scoreClass(score)}${sel ? ' is-selected' : ''}${inCell.length ? ' has-risks' : ''}`, tabindex: 0 }, root);
        s('rect', { x: x + 1, y: y + 1, width: cellW - 2, height: cellH - 2, rx: 3 }, g);
        stext(g, x + cellW / 2, y + cellH / 2 + 5, inCell.length ? String(inCell.length) : '', { class: 'ch-mcount', 'text-anchor': 'middle' });
        stext(g, x + cellW - 6, y + 13, String(score), { class: 'ch-mscore', 'text-anchor': 'end' });
        bindTip(g, () => [
          `${sevL[sev]} severity · ${likL[lik]} · score ${score}`,
          inCell.length ? `${inCell.length} open risk${inCell.length === 1 ? '' : 's'}` : 'No open risks',
          ...inCell.slice(0, 5).map((r) => `${r.risk_code || ''} ${r.title || ''}`.trim()),
        ]);
        if (opts.onCellClick) {
          g.classList.add('is-clickable');
          g.addEventListener('click', () => opts.onCellClick(sev, lik));
          g.addEventListener('keydown', (e) => { if (e.key === 'Enter') opts.onCellClick(sev, lik); });
        }
      }
    }
    for (let lik = 1; lik <= 4; lik += 1) stext(root, left + (lik - 0.5) * cellW, top + 4 * cellH + 16, likL[lik], { class: 'ch-axis', 'text-anchor': 'middle' });
    stext(root, left + 2 * cellW, top + 4 * cellH + 36, 'Likelihood', { class: 'ch-axis-title', 'text-anchor': 'middle' });
    const yTitle = stext(root, 12, top + 2 * cellH, 'Severity', { class: 'ch-axis-title', 'text-anchor': 'middle' });
    yTitle.setAttribute('transform', `rotate(-90 12 ${top + 2 * cellH})`);
    el.appendChild(h('div', { class: 'ch-legend' },
      [['m-green', 'Score 1–3'], ['m-amber', '4–6'], ['m-orange', '8–9'], ['m-red', '12–16']]
        .map(([cls, label]) => h('span', { class: 'ch-legend-item' }, h('span', { class: `ch-swatch ch-mswatch ${cls}` }), label)),
      h('span', { class: 'ch-legend-note', text: 'Closed risks are not counted' })));
  }

  draw();
  return {
    update(json, nextOpts) { current = json; if (nextOpts) Object.assign(opts, nextOpts); draw(); },
    destroy() { hideTip(); clear(el); },
  };
}
