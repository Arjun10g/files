// heatmap.js: resource × month utilisation (UX §4.2). renderHeatmap(el, capacity, {onCellClick?, breakdown?(row, cell)->[{label, hours, firmness?}], selected?})
import { hideTip, h, clear, bindTip, fmtMonth, fmtMonthShort, fmtHours, fiscalOf, isNum, num } from './kit.js';
import { s, stext, svgRoot, chartEmpty, fit, widthOf, watchWidth } from './svg.js';

const CELL_W_MAX = 56;
const CELL_W_MIN = 42;
const CELL_H = 28;

/** Cell colour class by utilisation; band from the server wins for the >100% cases. */
export function heatClass(cell) {
  const avail = num(cell && cell.available);
  const demand = num(cell && cell.confirmed) + num(cell && cell.tentative);
  if (!cell || (!avail && !demand)) return 'h-none';
  const util = isNum(cell.util) ? Number(cell.util) : avail ? demand / avail : 2;
  if (cell.band === 'over' || util > 1.1) return 'h-over';
  if (cell.band === 'stretched' || util > 1.0) return 'h-stretch';
  if (util <= 0.005) return 'h-0';
  if (util <= 0.5) return 'h-1';
  if (util <= 0.8) return 'h-2';
  return 'h-3';
}
export function cellPct(cell) {
  const avail = num(cell && cell.available);
  const demand = num(cell && cell.confirmed) + num(cell && cell.tentative);
  if (!cell || (!avail && !demand)) return null;
  if (isNum(cell.util)) return Math.round(Number(cell.util) * 100);
  return avail ? Math.round((demand / avail) * 100) : null;
}

export function renderHeatmap(el, capacity, opts = {}) {
  let current = capacity;
  el.classList.add('ch-host', 'ch-heatmap');

  function draw() {
    const cap = current || {};
    const rows = Array.isArray(cap.rows) ? cap.rows : [];
    const months = Array.isArray(cap.months) && cap.months.length ? cap.months : (rows[0] && Array.isArray(rows[0].cells) ? rows[0].cells.map((c) => c.month) : []);
    if (!rows.length || !months.length) {
      chartEmpty(el, 'No capacity data for this period. Add monthly available hours on the Resources page.');
      return;
    }
    clear(el);
    const avail = widthOf(el);
    const labelW = avail < 640 ? 150 : 196;
    // fit the months to the card; below 42 px a cell the chart scrolls inside its own box
    const CELL_W = Math.max(CELL_W_MIN, Math.min(CELL_W_MAX, Math.floor((avail - labelW - 2) / months.length)));
    const headerH = 40;
    const teamH = 22;
    // group rows by team, keeping server order of first appearance
    const teams = [];
    const byTeam = new Map();
    for (const r of rows) {
      const team = r.team || 'Other';
      if (!byTeam.has(team)) { byTeam.set(team, []); teams.push(team); }
      byTeam.get(team).push(r);
    }
    const height = headerH + teams.length * teamH + rows.length * CELL_H + 4;
    const width = labelW + months.length * CELL_W + 2;
    const scroll = h('div', { class: 'ch-scroll' });
    el.appendChild(scroll);
    const root = svgRoot(width, height, 'Capacity heatmap, resource by month');
    if (opts.highlightOver) root.classList.add('is-highlight-over');
    scroll.appendChild(root);

    // quarter + month header
    let i = 0;
    while (i < months.length) {
      const fq = fiscalOf(months[i]);
      let j = i;
      while (j < months.length && fiscalOf(months[j]).key === fq.key) j += 1;
      const x = labelW + i * CELL_W;
      s('rect', { x, y: 0, width: (j - i) * CELL_W, height: 17, class: (fq.q === 'Q1' || fq.q === 'Q3') ? 'ch-qhead-a' : 'ch-qhead-b' }, root);
      const span = (j - i) * CELL_W;
      const qText = span >= 150 ? `${fq.label} · ${fq.q} ${fq.fy}` : span >= 46 ? `${fq.q} ${fq.fy}` : fq.q;
      const qNode = stext(root, x + span / 2, 12, qText, { class: 'ch-qlabel', 'text-anchor': 'middle' });
      const qTitle = s('title', {}, qNode);
      qTitle.textContent = `${fq.label} · ${fq.q} ${fq.fy}`;
      i = j;
    }
    months.forEach((m, k) => stext(root, labelW + k * CELL_W + CELL_W / 2, 33, fmtMonthShort(m), { class: 'ch-axis', 'text-anchor': 'middle' }));

    let y = headerH;
    for (const team of teams) {
      s('rect', { x: 0, y, width, height: teamH, class: 'ch-team-row' }, root);
      stext(root, 8, y + 15, team, { class: 'ch-team-label' });
      y += teamH;
      for (const r of byTeam.get(team)) {
        const label = s('g', { class: 'ch-row-label' }, root);
        stext(label, 16, y + CELL_H / 2 + 4, fit(r.label || r.name || '', labelW - 22), { class: 'ch-label' });
        const cellsByMonth = new Map((Array.isArray(r.cells) ? r.cells : []).map((c) => [c.month, c]));
        months.forEach((m, k) => {
          const cell = cellsByMonth.get(m) || { month: m };
          const x = labelW + k * CELL_W;
          const cls = heatClass(cell);
          const pct = cellPct(cell);
          const selected = opts.selected && String(opts.selected.key) === String(r.key) && opts.selected.month === m;
          const g = s('g', { class: `ch-cell ${cls}${selected ? ' is-selected' : ''}`, tabindex: 0 }, root);
          s('rect', { x: x + 1, y: y + 1, width: CELL_W - 2, height: CELL_H - 2, rx: 2 }, g);
          const over = cls === 'h-over' || cls === 'h-stretch';
          stext(g, x + CELL_W / 2, y + CELL_H / 2 + 4, pct === null ? '—' : `${pct}%${over ? ' ▲' : ''}`, { 'text-anchor': 'middle', class: `ch-cell-text${CELL_W < 50 ? ' is-sm' : ''}` });
          bindTip(g, () => tip(r, cell, pct));
          if (opts.onCellClick) {
            g.classList.add('is-clickable');
            g.addEventListener('click', () => opts.onCellClick({ row: r, cell }));
            g.addEventListener('keydown', (e) => { if (e.key === 'Enter') opts.onCellClick({ row: r, cell }); });
          }
        });
        y += CELL_H;
      }
    }

    el.appendChild(h('div', { class: 'ch-legend' },
      [['h-0', '0%'], ['h-1', '1–50%'], ['h-2', '51–80%'], ['h-3', '81–100%'], ['h-stretch', '101–110% ▲'], ['h-over', 'Over 110% ▲']]
        .map(([cls, label]) => h('span', { class: 'ch-legend-item' }, h('span', { class: `ch-swatch ch-heat ${cls}` }), label)),
      h('span', { class: 'ch-legend-note', text: 'Utilisation = confirmed + tentative hours ÷ available hours' })));
  }

  function tip(r, cell, pct) {
    const demand = num(cell.confirmed) + num(cell.tentative);
    const lines = [`${r.label || ''} · ${fmtMonth(cell.month)}`];
    if (!num(cell.available) && !demand) lines.push('No availability or allocation this month');
    else lines.push(`${fmtHours(demand)} of ${fmtHours(num(cell.available))} available${pct === null ? '' : ` (${pct}%)`}`);
    if (num(cell.tentative)) lines.push(`Confirmed ${fmtHours(num(cell.confirmed))} · Tentative ${fmtHours(num(cell.tentative))}`);
    const parts = typeof opts.breakdown === 'function' ? opts.breakdown(r, cell) || [] : [];
    for (const p of parts) lines.push(`${p.label} ${fmtHours(p.hours)}${p.firmness === 'tentative' ? ' (tentative)' : ''}`);
    return lines;
  }

  draw();
  const unwatch = watchWidth(el, draw);
  return {
    update(json) { current = json; draw(); },
    destroy() { hideTip(); unwatch(); clear(el); },
  };
}
