// rag.js: Project Health tiles (UX §4.5, deck MVP 1 dashboard slide).
// renderHealth(el, health, {onSuggestFix?(dimension, dim), onOverride?(dimension, dim), title?})
// renderPortfolioHealth(el, {counts:{Red, Amber, Green, unscored}, attention:[{id, rddc, name, rag, text}]}, {onItemClick?})
import { hideTip, h, clear, bindTip, ragPill, fmtDate, fmtMonth, fmtNum, isNum, autoButton } from './kit.js';

export const DIMENSIONS = [
  ['schedule', 'Schedule'], ['resources', 'Resources'], ['scope', 'Scope'], ['dependencies', 'Dependencies'], ['budget', 'Budget'],
];
export const RULES = {
  schedule: 'Green: readiness float of 5+ business days and nothing overdue. Amber: float 0–4 days, or a step overdue up to 5 days. Red: misses the target release, a critical step overdue more than 5 days, or production inside the freeze.',
  resources: 'Green: everyone at or under 100% in the months they work on this initiative. Amber: anyone at 101–110%, or an unassigned step starting within 10 business days. Red: anyone over 110%, or an unassigned step starting within 5 business days.',
  scope: 'Green: no scope change after L2 approval and SA Completeness 80% or more. Amber: SA Completeness 60–79%, or 1 change / L2 delta up to 20%. Red: SA Completeness under 60%, 2+ changes, or L2 delta over 20%.',
  dependencies: 'Green unless a trigger fires. Amber: a component approval pending with need-by within 15 business days, or L2 pending over 10 business days. Red: an approval rejected or a dependency step overdue.',
  budget: 'Green: burn % minus completion % is 10 points or less. Amber: 11–20 points. Red: over 20 points, or forecast above the PRN funding.',
};
const OVERALL_RULE = 'Overall is Red when Schedule is Red or 2+ dimensions are Red; Amber when any dimension is Red or Amber; otherwise Green.';

const METRIC_LABELS = {
  float_bd: 'Readiness float (business days)', readiness_date: 'Readiness Date', target_train: 'Target release', train_date: 'Train date',
  max_util_pct: 'Highest utilisation', peak_util: 'Highest utilisation', person: 'Person', month: 'Month', unassigned: 'Unassigned steps',
  sa_completeness: 'SA Completeness', scope_changes: 'Scope changes', l2_delta_pct: 'L2 delta', pending_approvals: 'Pending approvals',
  burn_pct: 'Budget burn', completion_pct: 'Completion', gap_pts: 'Burn minus completion (points)', funded_hours: 'Funded hours',
  forecast_hours: 'Forecast hours', charged_hours: 'Charged hours', overdue: 'Overdue steps', peak_month: 'Peak month',
  min_need_by_bd: 'Earliest need-by (business days)', planned_hours: 'Planned hours', burn_minus_complete_pts: 'Burn minus completion (points)',
};
function metricLines(metrics) {
  if (!metrics || typeof metrics !== 'object') return [];
  const out = [];
  for (const [k, v] of Object.entries(metrics)) {
    if (v === null || v === undefined || typeof v === 'object' || /_id$/.test(k)) continue;
    const label = METRIC_LABELS[k] || k.replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase());
    let value = v;
    if (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v)) value = fmtDate(v);
    else if (typeof v === 'string' && /^\d{4}-\d{2}$/.test(v)) value = fmtMonth(v);
    else if (isNum(v) && /pct$/.test(k)) value = `${Math.round(Number(v))}%`;
    else if (isNum(v) && /util/.test(k)) value = `${Math.round(Number(v) <= 5 ? Number(v) * 100 : Number(v))}%`;
    else if (isNum(v)) value = fmtNum(v, 1);
    out.push(`${label}: ${value}`);
  }
  return out.slice(0, 6);
}

export function renderHealth(el, health, opts = {}) {
  let current = health;
  el.classList.add('ch-host', 'ch-health');

  function draw() {
    clear(el);
    const hl = current || {};
    const head = h('div', { class: 'ch-health-head' }, h('span', { class: 'ch-tile-title', text: opts.title || 'Project health' }));
    el.appendChild(head);
    if (!hl.scored || !hl.dimensions) {
      head.appendChild(ragPill(null, { large: true, unscoredText: 'Not scored yet' }));
      el.appendChild(h('p', { class: 'ch-muted', text: 'Health is calculated from the Planning stage onward, once the plan and resources are in.' }));
      return;
    }
    const overall = ragPill(hl.overall, { large: true });
    head.appendChild(overall);
    bindTip(overall, () => ['Overall', hl.rule || OVERALL_RULE]);

    const list = h('ul', { class: 'ch-dims' });
    for (const [key, label] of DIMENSIONS) {
      const dim = hl.dimensions[key];
      if (!dim) continue;
      const pill = opts.onOverride
        ? h('button', { type: 'button', class: 'ch-pill-btn', 'aria-label': `${label} is ${dim.rag || 'not scored'}. Override`, on: { click: () => opts.onOverride(key, dim) } }, ragPill(dim.rag))
        : ragPill(dim.rag);
      const row = h('li', { class: `ch-dim ch-dim-${(dim.rag || 'none').toLowerCase()}`, 'data-dimension': key },
        h('span', { class: 'ch-dim-name', text: label }),
        h('span', { class: 'ch-dim-right' },
          dim.overridden ? h('span', { class: 'ch-overridden', title: dim.override_reason || 'Manual override', text: 'Overridden' }) : null,
          dim.rag === 'Red' && key === 'resources' && opts.onSuggestFix
            ? autoButton('Suggest fix', (e) => opts.onSuggestFix(key, dim, e.currentTarget), { attrs: { 'data-action': 'suggest-fix' } })
            : null,
          pill));
      bindTip(row.querySelector('.ch-dim-name'), () => [
        `${label} = ${dim.rag || 'Not scored'}${dim.overridden ? ' (overridden)' : ''}`,
        ...(Array.isArray(dim.reasons) ? dim.reasons : []),
        ...(dim.explanation ? [dim.explanation] : metricLines(dim.metrics)),
        dim.overridden && dim.override_reason ? `Override reason: ${dim.override_reason}` : null,
        dim.overridden && dim.computed_rag ? `Calculated value: ${dim.computed_rag}` : null,
        dim.rule || RULES[key],
      ]);
      row.querySelector('.ch-dim-name').tabIndex = 0;
      list.appendChild(row);
    }
    el.appendChild(list);
    const attention = Array.isArray(hl.attention) ? hl.attention.filter(Boolean) : [];
    el.appendChild(h('div', { class: 'ch-attention' },
      h('div', { class: 'ch-attention-label', text: 'Management attention' }),
      attention.length ? h('ul', {}, attention.map((a) => h('li', { text: a }))) : h('p', { class: 'ch-muted', text: 'Nothing needs management attention.' })));
    if (hl.as_of) el.appendChild(h('div', { class: 'ch-asof', text: `Calculated ${fmtDate(String(hl.as_of).slice(0, 10))} · health is calculated, not typed` }));
    if (opts.onOverride) el.appendChild(h('div', { class: 'ch-asof', text: 'Click a status to override it with a reason.' }));
  }

  draw();
  return {
    update(json) { current = json; draw(); },
    destroy() { hideTip(); clear(el); },
  };
}

export function renderPortfolioHealth(el, data, opts = {}) {
  let current = data;
  el.classList.add('ch-host', 'ch-health');
  function draw() {
    clear(el);
    const d = current || {};
    const counts = d.counts || {};
    const worst = counts.Red ? 'Red' : counts.Amber ? 'Amber' : counts.Green ? 'Green' : null;
    // Portfolio scope has no single overall status (decision 7): show counts, and name the worst status in words.
    el.appendChild(h('div', { class: 'ch-health-head' },
      h('span', { class: 'ch-tile-title', text: 'Project health · all initiatives' }),
      worst ? bindTip(h('span', { class: `ch-worst ch-worst-${worst.toLowerCase()}`, tabindex: '0', text: `Worst: ${worst}` }), () => [
        `Worst: ${worst}`,
        d.rule || 'Each initiative: Red if Schedule is Red or 2 or more dimensions are Red; Amber if any dimension is Red or Amber; otherwise Green.',
        'Worst is the most severe status across active initiatives; there is no averaged portfolio status.',
      ]) : null));
    el.appendChild(h('div', { class: 'ch-counts' },
      [['Red', 'red'], ['Amber', 'amber'], ['Green', 'green']].map(([k, cls]) => h('div', { class: `ch-count ch-count-${cls}` }, h('strong', { text: String(counts[k] || 0) }), h('span', { text: k }))),
      h('div', { class: 'ch-count ch-count-none' }, h('strong', { text: String(counts.unscored || 0) }), h('span', { text: 'Not scored' }))));
    const items = Array.isArray(d.attention) ? d.attention : [];
    const list = h('ul', { class: 'ch-attn-list' });
    for (const item of items.slice(0, 5)) {
      const li = h('li', {}, ragPill(item.rag, { small: true }), h('span', { class: 'ch-attn-text' },
        h('strong', { text: item.rddc }), ` ${item.name || ''}`,
        Array.isArray(item.items) && item.items.length ? h('ul', { class: 'ch-attn-items' }, item.items.map((x) => h('li', { text: x }))) : (item.text ? ` — ${item.text}` : null)));
      if (opts.onItemClick) {
        li.classList.add('is-clickable');
        li.tabIndex = 0;
        li.addEventListener('click', () => opts.onItemClick(item));
        li.addEventListener('keydown', (e) => { if (e.key === 'Enter') opts.onItemClick(item); });
      }
      list.appendChild(li);
    }
    el.appendChild(h('div', { class: 'ch-attention' },
      h('div', { class: 'ch-attention-label', text: 'Management attention' }),
      items.length ? list : h('p', { class: 'ch-muted', text: 'Nothing needs management attention.' })));
  }
  draw();
  return {
    update(json) { current = json; draw(); },
    destroy() { hideTip(); clear(el); },
  };
}
