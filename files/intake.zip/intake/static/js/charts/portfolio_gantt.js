// portfolio_gantt.js: one bar per initiative. renderPortfolioGantt(el, portfolioGantt, {onRowClick?, compact?, highlightId?})
import { hideTip, h, clear, dayNum, fmtDate, bindTip, isoFromDay } from './kit.js';
import { s, stext, svgRoot, chartEmpty, widthOf, watchWidth, fit, timeScale, drawTimeAxis, TODAY_FOOTER } from './svg.js';

const RAG_CLS = { Red: 'red', Amber: 'amber', Green: 'green' };

export function renderPortfolioGantt(el, data, opts = {}) {
  const compact = Boolean(opts.compact);
  let current = data;
  el.classList.add('ch-host', 'ch-pgantt');
  let unwatch = () => {};

  function draw() {
    const d = current || {};
    const rows = (Array.isArray(d.rows) ? d.rows : []).filter((r) => !Number.isNaN(dayNum(r.start)) && !Number.isNaN(dayNum(r.end || r.start)));
    if (!rows.length) {
      chartEmpty(el, 'No initiatives have plan dates yet. Generate a project plan to see it here.');
      return;
    }
    clear(el);
    const scroll = h('div', { class: 'ch-scroll' });
    el.appendChild(scroll);
    const total = widthOf(el);
    const labelW = compact ? Math.round(Math.min(220, Math.max(140, total * 0.34))) : 260;
    let lo = Math.min(...rows.map((r) => dayNum(r.start)));
    let hi = Math.max(...rows.map((r) => Math.max(dayNum(r.end || r.start), dayNum(r.prod_date) || 0)));
    if (!Number.isNaN(dayNum(d.start))) lo = Math.max(lo, dayNum(d.start));
    if (!Number.isNaN(dayNum(d.end))) hi = Math.min(hi, dayNum(d.end));
    const todayN = dayNum(d.today);
    if (!Number.isNaN(todayN)) { lo = Math.min(lo, todayN); hi = Math.max(hi, todayN); }
    if (hi <= lo) hi = lo + 30;
    const ts = timeScale({ startIso: isoFromDay(lo), endIso: isoFromDay(hi), width: total - labelW - 12, scale: 'month' });
    const headerH = compact ? 50 : 74;
    const rowH = compact ? 24 : 30;
    const barH = compact ? 10 : 14;
    const bodyH = rows.length * rowH;
    const svgW = labelW + ts.width + 12;
    const root = svgRoot(svgW, headerH + bodyH + TODAY_FOOTER, 'Portfolio Gantt, one bar per initiative');
    scroll.appendChild(root);
    const bg = s('g', {}, root);
    const rowsLayer = s('g', {}, root);
    const bars = s('g', {}, root);
    const over = s('g', {}, root);
    const header = s('g', {}, root);
    drawTimeAxis(root, { bg, header, over }, ts, { x0: labelW, bodyTop: headerH, bodyH, freeze: d.freeze, trains: d.trains || [], today: d.today, compact, trainRowY: 39, freezeRowY: compact ? null : 57 });

    rows.forEach((r, i) => {
      const y = headerH + i * rowH;
      const cy = y + rowH / 2;
      const isHl = opts.highlightId && String(opts.highlightId) === String(r.initiative_id);
      if (isHl) s('rect', { x: 0, y, width: svgW, height: rowH, class: 'ch-row-hl' }, rowsLayer);
      else if (i % 2) s('rect', { x: 0, y, width: svgW, height: rowH, class: 'ch-row-alt' }, rowsLayer);
      const full = `${r.rddc} ${r.name || ''}`.trim();
      const labelG = s('g', { class: 'ch-row-label' }, rowsLayer);
      const lt = stext(labelG, 8, cy + 4, '', { class: 'ch-label' });
      const idSpan = s('tspan', { class: 'ch-label-id' }, lt);
      idSpan.textContent = r.rddc;
      const nameSpan = s('tspan', { class: 'ch-label-name', dx: 5 }, lt);
      nameSpan.textContent = fit(r.name || '', labelW - 14 - r.rddc.length * 6.6 - 5, compact ? 6 : 6.4);
      const tl = s('title', {}, labelG);
      tl.textContent = full;
      const x = labelW + ts.x(r.start);
      const x2 = labelW + ts.x(r.end || r.start) + ts.pxPerDay;
      const w = Math.max(4, x2 - x);
      const g = s('g', { class: `ch-bar ch-rag-${RAG_CLS[r.rag] || 'none'}`, tabindex: 0 }, bars);
      s('rect', { x, y: cy - barH / 2, width: w, height: barH, rx: 3, class: 'ch-bar-solid' }, g);
      if (!compact && w > 70) stext(g, x + 6, cy + 4, fit(r.stage || '', w - 10), { class: 'ch-bar-inlabel' });
      for (const [iso, cls] of [[r.readiness_date, 'ch-ms-ready'], [r.prod_date, 'ch-ms-prod']]) {
        if (Number.isNaN(dayNum(iso))) continue;
        const mx = labelW + ts.x(iso) + ts.pxPerDay / 2;
        const rr = compact ? 4.5 : 5.5;
        s('path', { d: `M${mx},${cy - rr} L${mx + rr},${cy} L${mx},${cy + rr} L${mx - rr},${cy} Z`, class: cls }, g);
      }
      bindTip(g, () => [
        `${r.rddc} · ${r.name || ''}`,
        `${fmtDate(r.start)} – ${fmtDate(r.end)}`,
        `Stage: ${r.stage || '—'} · RAG: ${r.rag || 'Not scored'}`,
        r.readiness_date ? `Readiness: ${fmtDate(r.readiness_date)}` : null,
        r.prod_date ? `Production: ${fmtDate(r.prod_date)}` : null,
      ]);
      if (opts.onRowClick) {
        g.classList.add('is-clickable');
        g.addEventListener('click', () => opts.onRowClick(r));
        g.addEventListener('keydown', (e) => { if (e.key === 'Enter') opts.onRowClick(r); });
      }
    });
    if (!compact) {
      el.appendChild(h('div', { class: 'ch-legend' },
        ['green', 'amber', 'red', 'none'].map((k) => h('span', { class: 'ch-legend-item' }, h('span', { class: `ch-swatch ch-rag-${k}` }), { green: 'Green', amber: 'Amber', red: 'Red', none: 'Not scored' }[k])),
        h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-swatch-ready' }), 'Readiness'),
        h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-swatch-diamond' }), 'Production'),
        h('span', { class: 'ch-legend-item' }, h('span', { class: 'ch-swatch ch-swatch-freeze' }), 'Change freeze')));
    }
  }

  draw();
  unwatch = watchWidth(el, draw);
  return {
    update(json) { current = json; draw(); },
    destroy() { hideTip(); unwatch(); clear(el); },
  };
}
