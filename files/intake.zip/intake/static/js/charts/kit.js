// kit.js: shared DOM, format, tooltip, modal, table and AI-card helpers for the B5 charts and views.
// User and AI text always enters the DOM through textContent (h() / text nodes), never innerHTML.

import * as api from '../api.js';
import * as D from '../dates.js';
import * as UI from '../ui/index.js';

export { api };

// ------------------------------------------------------------------ stylesheet
(function ensureChartsCss() {
  if (typeof document === 'undefined') return;
  if (document.querySelector('link[href*="charts.css"]')) return;
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = new URL('../../css/charts.css', import.meta.url).href;
  document.head.appendChild(link);
})();

// ------------------------------------------------------------------ DOM
const ESC_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ESC_MAP[c]);
}

/** h('div', {class, text, title, on:{click}, dataset, style, ...attrs}, ...children) */
export function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [key, value] of Object.entries(attrs)) {
      if (value === undefined || value === null || value === false) continue;
      if (key === 'class') el.className = value;
      else if (key === 'text') el.textContent = String(value);
      else if (key === 'on') for (const [ev, fn] of Object.entries(value)) el.addEventListener(ev, fn);
      else if (key === 'dataset') Object.assign(el.dataset, value);
      else if (key === 'style' && typeof value === 'object') Object.assign(el.style, value);
      else if (key === 'value') el.value = value;
      else if (key === 'checked' || key === 'disabled' || key === 'selected' || key === 'hidden') el[key] = Boolean(value);
      else el.setAttribute(key, value === true ? '' : String(value));
    }
  }
  append(el, children);
  return el;
}

export function append(el, children) {
  for (const child of children.flat(Infinity)) {
    if (child === undefined || child === null || child === false) continue;
    el.appendChild(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return el;
}

export function clear(el) {
  while (el && el.firstChild) el.removeChild(el.firstChild);
  return el;
}

// ------------------------------------------------------------------ numbers
const NUM0 = new Intl.NumberFormat('en-CA', { maximumFractionDigits: 0 });
const NUM1 = new Intl.NumberFormat('en-CA', { maximumFractionDigits: 1 });

export function isNum(v) {
  return v !== null && v !== undefined && v !== '' && Number.isFinite(Number(v));
}
export function num(v, fallback = 0) {
  return isNum(v) ? Number(v) : fallback;
}
export function fmtNum(v, dp = 0) {
  if (!isNum(v)) return '—';
  return (dp ? NUM1 : NUM0).format(Number(v));
}
export function fmtHours(v) {
  return isNum(v) ? `${fmtNum(v, 1)} h` : '—';
}
/** ratio (0..n) -> "112%" */
export function fmtPct(ratio) {
  return isNum(ratio) ? `${Math.round(Number(ratio) * 100)}%` : '—';
}

// ------------------------------------------------------------------ dates (ISO strings only; no Date parsing of strings)
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const pad2 = (n) => String(n).padStart(2, '0');

export function isoParts(value) {
  if (typeof value !== 'string') return null;
  const m = /^(\d{4})-(\d{2})(?:-(\d{2}))?/.exec(value);
  if (!m) return null;
  return { y: Number(m[1]), m: Number(m[2]), d: m[3] ? Number(m[3]) : 1, hasDay: Boolean(m[3]) };
}
/** Whole days since 1970-01-01 for an ISO date; timezone-independent. */
export function dayNum(iso) {
  const p = isoParts(iso);
  return p ? Math.round(Date.UTC(p.y, p.m - 1, p.d) / 864e5) : NaN;
}
export function isoFromDay(n) {
  const dt = new Date(n * 864e5);
  return `${dt.getUTCFullYear()}-${pad2(dt.getUTCMonth() + 1)}-${pad2(dt.getUTCDate())}`;
}
export function weekdayIdx(iso) {
  const n = dayNum(iso);
  return Number.isNaN(n) ? NaN : (((n + 4) % 7) + 7) % 7;
}
/** Local Date for an ISO date; delegates to dates.js when it is present. */
export function parseDate(iso) {
  if (typeof D.parseISODate === 'function') return D.parseISODate(iso);
  const p = isoParts(iso);
  return p ? new Date(p.y, p.m - 1, p.d) : null;
}
export function fmtDate(iso) {
  if (typeof D.fmtDate === 'function') return D.fmtDate(iso);
  const p = isoParts(iso);
  return p && p.hasDay ? `${p.d} ${MON[p.m - 1]} ${p.y}` : '—';
}
export function fmtShort(iso) {
  if (typeof D.fmtShort === 'function') return D.fmtShort(iso);
  const p = isoParts(iso);
  return p && p.hasDay ? `${p.d} ${MON[p.m - 1]}` : '—';
}
export function fmtDay(iso) {
  if (typeof D.fmtDay === 'function') return D.fmtDay(iso);
  const p = isoParts(iso);
  return p && p.hasDay ? `${DOW[weekdayIdx(iso)]} ${p.d} ${MON[p.m - 1]}` : '—';
}
export function fmtDayLong(iso) {
  if (typeof D.fmtDay === 'function') return D.fmtDay(iso, { withYear: true });
  const p = isoParts(iso);
  return p && p.hasDay ? `${DOW[weekdayIdx(iso)]} ${p.d} ${MON[p.m - 1]} ${p.y}` : '—';
}
export function fmtMonth(ym) {
  if (typeof D.fmtMonth === 'function') return D.fmtMonth(ym);
  const p = isoParts(ym);
  return p ? `${MON[p.m - 1]} ${p.y}` : '—';
}
export function fmtMonthShort(ym) {
  if (typeof D.fmtMonthShort === 'function') return D.fmtMonthShort(ym);
  const p = isoParts(ym);
  return p ? MON[p.m - 1] : '—';
}
/** '2027-02-20T02:00:00-05:00' -> 'Sat 20 Feb 2027 02:00' (wall-clock time as stored, Toronto) */
export function fmtDateTime(value) {
  if (typeof value !== 'string') return '—';
  const date = value.slice(0, 10);
  const time = /T(\d{2}:\d{2})/.exec(value);
  const day = fmtDayLong(date);
  if (day === '—') return '—';
  return time ? `${day} ${time[1]}` : day;
}
export function fmtTime(value) {
  const time = typeof value === 'string' ? /(\d{2}:\d{2})/.exec(value) : null;
  return time ? time[1] : '';
}
export function monthKey(iso) {
  return typeof iso === 'string' && iso.length >= 7 ? iso.slice(0, 7) : '';
}
export function addMonths(ym, delta) {
  const p = isoParts(ym);
  if (!p) return '';
  const idx = p.y * 12 + (p.m - 1) + delta;
  return `${Math.floor(idx / 12)}-${pad2((idx % 12) + 1)}`;
}
export function monthsBetween(fromYm, toYm) {
  const out = [];
  const a = isoParts(fromYm);
  const b = isoParts(toYm);
  if (!a || !b) return out;
  let idx = a.y * 12 + a.m - 1;
  const end = b.y * 12 + b.m - 1;
  while (idx <= end && out.length < 60) {
    out.push(`${Math.floor(idx / 12)}-${pad2((idx % 12) + 1)}`);
    idx += 1;
  }
  return out;
}
/** BMO fiscal year starts 1 Nov. '2026-11' -> {fy:'FY27', q:'Q1', label:'Nov–Jan'} */
export function fiscalOf(ym) {
  const p = isoParts(ym);
  if (!p) return null;
  const fy = p.m >= 11 ? p.y + 1 : p.y;
  const qi = Math.floor(((p.m + 1) % 12) / 3);
  const labels = ['Nov–Jan', 'Feb–Apr', 'May–Jul', 'Aug–Oct'];
  return { fy: `FY${String(fy).slice(-2)}`, q: `Q${qi + 1}`, label: labels[qi], key: `${fy}-Q${qi + 1}` };
}
/** ISO week string 'YYYY-Www' for an ISO date. */
export function isoWeek(iso) {
  const n = dayNum(iso);
  if (Number.isNaN(n)) return '';
  const dow = (weekdayIdx(iso) + 6) % 7; // Mon=0
  const thursday = n - dow + 3;
  const year = new Date(thursday * 864e5).getUTCFullYear();
  const jan1 = Math.round(Date.UTC(year, 0, 1) / 864e5);
  const week = Math.floor((thursday - jan1) / 7) + 1;
  return `${year}-W${pad2(week)}`;
}
export function shiftWeek(week, delta) {
  const m = /^(\d{4})-W(\d{2})$/.exec(week || '');
  if (!m) return '';
  const year = Number(m[1]);
  const jan4 = Math.round(Date.UTC(year, 0, 4) / 864e5);
  const jan4dow = (weekdayIdx(isoFromDay(jan4)) + 6) % 7;
  const monday = jan4 - jan4dow + (Number(m[2]) - 1) * 7 + delta * 7;
  return isoWeek(isoFromDay(monday));
}

// ------------------------------------------------------------------ app data helpers
let lookupsPromise = null;
export function getLookups(ctx) {
  const cached = ctx && ctx.state && ctx.state.lookups;
  if (cached && typeof cached === 'object' && cached.stage) return Promise.resolve(cached);
  if (ctx && ctx.state && typeof ctx.state.loadLookups === 'function') return ctx.state.loadLookups();
  if (!lookupsPromise) {
    lookupsPromise = api.getLookups().catch((err) => {
      lookupsPromise = null;
      throw err;
    });
  }
  return lookupsPromise;
}
export function lookupLabel(lookups, category, value) {
  const list = lookups && Array.isArray(lookups[category]) ? lookups[category] : [];
  const hit = list.find((o) => String(o.value) === String(value));
  return hit ? hit.label || String(hit.value) : value === null || value === undefined ? '—' : String(value);
}
export function lookupOptions(lookups, category) {
  const list = lookups && Array.isArray(lookups[category]) ? lookups[category] : [];
  return list.map((o) => ({ value: String(o.value), label: o.label || String(o.value) }));
}
export async function getSettingsSafe() {
  try {
    return await api.getSettings();
  } catch {
    return { ai_speed: 'Realistic', persona: 'DC PM', demo_today: null };
  }
}
export async function getToday(ctx) {
  const fromState = ctx && ctx.state && (ctx.state.today || (ctx.state.settings && ctx.state.settings.demo_today));
  if (typeof fromState === 'string' && fromState.length >= 10) return fromState.slice(0, 10);
  try {
    const health = await api.getAppHealth();
    if (health && typeof health.today === 'string') return health.today.slice(0, 10);
  } catch {
    /* fall through to settings */
  }
  const settings = await getSettingsSafe();
  return settings.demo_today || '';
}
export function go(ctx, hash) {
  if (ctx && typeof ctx.navigate === 'function') ctx.navigate(hash);
  else window.location.hash = hash;
}
export function itemsOf(res) {
  if (Array.isArray(res)) return res;
  return res && Array.isArray(res.items) ? res.items : [];
}

// ------------------------------------------------------------------ pills and small parts
const RAG_CLASS = { Red: 'red', Amber: 'amber', Green: 'green' };
export function ragPill(rag, { large = false, small = false, title, unscoredText = 'Not scored' } = {}) {
  const size = large ? 'lg' : small ? 'sm' : 'md';
  if (typeof UI.ragPill === 'function') return UI.ragPill(rag, { size, label: RAG_CLASS[rag] ? undefined : unscoredText, title });
  return h('span', { class: `pill pill-rag pill-${RAG_CLASS[rag] || 'none'} pill-${size}`, title }, h('span', { class: 'dot' }), RAG_CLASS[rag] ? rag : unscoredText);
}
export function chip(text, kind = '', attrs = {}) {
  return h('span', { ...attrs, class: `dv-chip${kind ? ` dv-chip-${kind}` : ''}${attrs.class ? ` ${attrs.class}` : ''}` }, text);
}
export function statusPill(status) {
  if (typeof UI.statusPill === 'function') return UI.statusPill(status);
  return h('span', { class: 'pill pill-status pill-grey' }, status || '—');
}
const VARIANT = { primary: 'primary', secondary: 'secondary', text: 'ghost', ghost: 'ghost', danger: 'danger-text', auto: 'auto' };
export function button(label, onClick, { kind = 'secondary', title, disabled, type = 'button', attrs = {}, small = false } = {}) {
  const extra = attrs.class ? ` ${attrs.class}` : '';
  const el = h('button', { ...attrs, type, class: `btn btn-${VARIANT[kind] || 'secondary'}${small ? ' btn-sm' : ''}${extra}`, title, disabled }, label);
  if (onClick) el.addEventListener('click', onClick);
  return el;
}
/** Yellow automation button (every AI / automation hook). */
export function autoButton(label, onClick, { title, disabled, attrs = {}, small = false } = {}) {
  const extra = attrs.class ? ` ${attrs.class}` : '';
  const el = h('button', { ...attrs, type: 'button', class: `btn btn-auto${small ? ' btn-sm' : ''}${extra}`, title, disabled },
    h('span', { class: 'auto-glyph', 'aria-hidden': 'true', text: '✦' }), h('span', { class: 'btn-label', text: label }));
  if (onClick) el.addEventListener('click', onClick);
  return el;
}
export function linkButton(label, hash, ctx, kind = 'secondary') {
  return h('a', { class: `btn btn-${VARIANT[kind] || 'secondary'}`, href: hash, on: { click: (e) => { e.preventDefault(); go(ctx, hash); } } }, label);
}
export function routeLink(ctx, hash, text) {
  return h('a', { class: 'dv-link', href: hash, on: { click: (e) => { e.preventDefault(); go(ctx, hash); } } }, text ?? '—');
}
export function emptyState(message, action) {
  if (typeof UI.emptyState === 'function') return UI.emptyState({ text: message, action: action || undefined, cls: 'compact' });
  return h('div', { class: 'empty-state compact' }, h('p', { class: 'empty-text', text: message }), action || null);
}
export function errorBox(err, retry, title) {
  if (typeof UI.errorPanel === 'function') return UI.errorPanel(err, { retry, title });
  const message = (err && err.message) || 'Something went wrong. Try again, or reset the demo from Settings.';
  return h('div', { class: 'error-panel', role: 'alert' }, h('p', { text: message }), retry ? button('Try again', retry) : null);
}
export function loading(label = 'Loading…') {
  if (typeof UI.loadingLine === 'function') return UI.loadingLine(label);
  return h('div', { class: 'loading-line', 'aria-busy': 'true' }, h('span', { text: label }));
}
/** Page frame matching the workspace pages: div.view-pad > section.page-box. Returns the box. */
export function framePage(root, view) {
  clear(root);
  const box = h('section', { class: 'page-box dv-page', 'data-view': view });
  root.appendChild(h('div', { class: 'view-pad' }, box));
  return box;
}
export function pageHeader({ eyebrow, title, hint, actions = [] }) {
  return h('header', { class: 'page-box-head dv-page-head' },
    h('div', { class: 'page-box-titles' },
      eyebrow ? h('div', { class: 'eyebrow', text: eyebrow }) : null,
      h('h2', { class: 'page-title', text: title }),
      hint ? h('span', { class: 'page-hint', text: hint }) : null),
    actions.length ? h('div', { class: 'page-box-actions' }, actions) : null);
}
export function card(title, { right, cls = '', body, noHead = false } = {}) {
  const bodyEl = body || h('div', { class: 'card-body' });
  const el = h('section', { class: `card dv-card ${cls}`.trim() },
    noHead ? null : h('div', { class: 'card-head' }, h('h3', { class: 'card-title', text: title }), right ? h('div', { class: 'card-actions' }, right) : null),
    bodyEl);
  return { el, body: bodyEl };
}
export function selectEl(options, value, onChange, { label, allLabel, cls = '', id } = {}) {
  const sel = h('select', { class: `dv-select ${cls}`, id, 'aria-label': label || allLabel || 'Filter' });
  if (allLabel) sel.appendChild(h('option', { value: '' }, allLabel));
  for (const opt of options) {
    const o = h('option', { value: String(opt.value) }, opt.label);
    if (String(opt.value) === String(value ?? '')) o.selected = true;
    sel.appendChild(o);
  }
  if (onChange) sel.addEventListener('change', () => onChange(sel.value));
  if (!label) return sel;
  return h('label', { class: 'dv-field' }, h('span', { class: 'dv-field-label', text: label }), sel);
}
export function segmented(options, value, onChange, { label } = {}) {
  const wrap = h('div', { class: 'dv-seg', role: 'group', 'aria-label': label || 'Options' });
  for (const opt of options) {
    const b = h('button', { type: 'button', class: `dv-seg-btn${opt.value === value ? ' is-on' : ''}`, 'aria-pressed': String(opt.value === value) }, opt.label);
    b.addEventListener('click', () => {
      wrap.querySelectorAll('.dv-seg-btn').forEach((x) => { x.classList.remove('is-on'); x.setAttribute('aria-pressed', 'false'); });
      b.classList.add('is-on');
      b.setAttribute('aria-pressed', 'true');
      onChange(opt.value);
    });
    wrap.appendChild(b);
  }
  return wrap;
}
export function tabs(items, active, onChange) {
  const bar = h('div', { class: 'dv-tabs', role: 'tablist' });
  for (const item of items) {
    const b = h('button', { type: 'button', role: 'tab', class: `dv-tab${item.value === active ? ' is-on' : ''}`, 'aria-selected': String(item.value === active) }, item.label);
    b.addEventListener('click', () => {
      bar.querySelectorAll('.dv-tab').forEach((x) => { x.classList.remove('is-on'); x.setAttribute('aria-selected', 'false'); });
      b.classList.add('is-on');
      b.setAttribute('aria-selected', 'true');
      onChange(item.value);
    });
    bar.appendChild(b);
  }
  return bar;
}

// ------------------------------------------------------------------ tooltip (one shared HTML div, follows the pointer)
let tipEl = null;
let tipAnchor = null;
if (typeof window !== 'undefined') {
  // A tooltip never outlives its page or its chart: hide on route change, scroll, click and when the anchor is gone.
  window.addEventListener('hashchange', () => hideTip());
  window.addEventListener('scroll', () => hideTip(), true);
  document.addEventListener('pointerdown', () => hideTip(), true);
  document.addEventListener('pointermove', (e) => {
    if (tipAnchor && (!tipAnchor.isConnected || !(e.target instanceof Node) || !tipAnchor.contains(e.target))) hideTip();
  }, true);
}
function tipNode() {
  if (!tipEl) {
    tipEl = h('div', { class: 'ch-tip', role: 'tooltip' });
    tipEl.style.display = 'none';
    document.body.appendChild(tipEl);
  }
  return tipEl;
}
export function showTip(evt, content) {
  const el = tipNode();
  clear(el);
  if (content instanceof Node) el.appendChild(content);
  else if (Array.isArray(content)) {
    content.filter((x) => x !== null && x !== undefined && x !== '').forEach((line, i) => {
      el.appendChild(line instanceof Node ? line : h('div', { class: i === 0 ? 'ch-tip-title' : 'ch-tip-line', text: line }));
    });
  } else el.appendChild(h('div', { class: 'ch-tip-line', text: String(content ?? '') }));
  el.style.display = 'block';
  moveTip(evt);
}
export function moveTip(evt) {
  if (!tipEl || tipEl.style.display === 'none') return;
  let x;
  let y;
  if (evt && Number.isFinite(evt.clientX) && (evt.clientX || evt.clientY)) {
    x = evt.clientX + 14;
    y = evt.clientY + 14;
  } else if (evt && evt.target && evt.target.getBoundingClientRect) {
    const r = evt.target.getBoundingClientRect();
    x = r.left;
    y = r.bottom + 6;
  } else return;
  const w = tipEl.offsetWidth;
  const hgt = tipEl.offsetHeight;
  if (x + w > window.innerWidth - 8) x = Math.max(8, x - w - 28);
  if (y + hgt > window.innerHeight - 8) y = Math.max(8, y - hgt - 28);
  tipEl.style.left = `${x}px`;
  tipEl.style.top = `${y}px`;
}
export function hideTip() {
  tipAnchor = null;
  if (tipEl) tipEl.style.display = 'none';
}
/** Attach a tooltip to a node; content is a function returning lines or a node. */
export function bindTip(node, contentFn) {
  node.addEventListener('pointerenter', (e) => { showTip(e, contentFn()); tipAnchor = node; });
  node.addEventListener('pointermove', moveTip);
  node.addEventListener('pointerleave', hideTip);
  node.addEventListener('focus', (e) => { showTip(e, contentFn()); tipAnchor = node; });
  node.addEventListener('blur', hideTip);
  return node;
}

// ------------------------------------------------------------------ toast
export function toast(message, kind = 'success') {
  if (typeof UI.toast === 'function') {
    UI.toast(message, { variant: kind === 'error' ? 'warning' : kind });
    return;
  }
  const el = h('div', { class: 'toast', role: 'status', text: String(message ?? '') });
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 4000);
}

// ------------------------------------------------------------------ modal
export function modal({ title, body, actions = [], onClose }) {
  const previous = document.activeElement;
  const scrim = h('div', { class: 'dv-scrim' });
  const box = h('div', { class: 'dv-modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title });
  const close = () => {
    document.removeEventListener('keydown', onKey);
    scrim.remove();
    if (onClose) onClose();
    if (previous && previous.focus) previous.focus();
  };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  const foot = h('div', { class: 'dv-modal-foot' });
  for (const action of actions) {
    foot.appendChild(button(action.label, async (e) => {
      const btn = e.currentTarget;
      btn.disabled = true;
      try {
        const keep = await action.onClick({ close, box });
        if (keep !== true) close();
      } finally {
        btn.disabled = false;
      }
    }, { kind: action.kind || 'secondary' }));
  }
  box.append(h('div', { class: 'dv-modal-head' }, h('h2', { text: title }), button('Close', close, { kind: 'text' })), h('div', { class: 'dv-modal-body' }, body), foot);
  scrim.appendChild(box);
  scrim.addEventListener('click', (e) => { if (e.target === scrim) close(); });
  document.addEventListener('keydown', onKey);
  document.body.appendChild(scrim);
  const first = box.querySelector('select, textarea, input, button.dv-btn-primary');
  if (first) first.focus();
  return { close, box };
}

// ------------------------------------------------------------------ sortable table
/**
 * columns: [{key, label, render?(row)->node|string, sort?(row)->value, align?, cls?, title?}]
 * returns {el, update(rows)}
 */
export function dataTable({ columns, rows = [], sortKey = null, sortDir = 'asc', onRowClick, empty = 'Nothing to show.', rowClass, caption, dense = false }) {
  let state = { key: sortKey, dir: sortDir };
  let data = rows.slice();
  const table = h('table', { class: `dv-table${dense ? ' dv-table-dense' : ''}` });
  if (caption) table.appendChild(h('caption', { class: 'dv-sr', text: caption }));
  const thead = h('thead');
  const tbody = h('tbody');
  table.append(thead, tbody);
  const wrap = h('div', { class: 'dv-table-wrap' }, table);

  const sortValue = (col, row) => {
    if (col.sort) return col.sort(row);
    const v = row[col.key];
    return v === null || v === undefined ? '' : v;
  };
  function drawHead() {
    clear(thead);
    const tr = h('tr');
    for (const col of columns) {
      const th = h('th', { scope: 'col', class: col.align === 'right' ? 'num' : '', title: col.title });
      if (col.sortable === false) th.textContent = col.label;
      else {
        const active = state.key === col.key;
        const b = h('button', { type: 'button', class: 'dv-th-btn', 'aria-sort': active ? (state.dir === 'asc' ? 'ascending' : 'descending') : 'none' },
          col.label, h('span', { class: 'dv-sort', 'aria-hidden': 'true', text: active ? (state.dir === 'asc' ? '▲' : '▼') : '' }));
        b.addEventListener('click', () => {
          state = { key: col.key, dir: state.key === col.key && state.dir === 'asc' ? 'desc' : 'asc' };
          drawHead();
          drawBody();
        });
        th.appendChild(b);
      }
      tr.appendChild(th);
    }
    thead.appendChild(tr);
  }
  function drawBody() {
    clear(tbody);
    let list = data;
    if (state.key) {
      const col = columns.find((c) => c.key === state.key);
      if (col) {
        list = data.slice().sort((a, b) => {
          const va = sortValue(col, a);
          const vb = sortValue(col, b);
          const cmp = typeof va === 'number' && typeof vb === 'number' ? va - vb : String(va).localeCompare(String(vb), 'en', { numeric: true });
          return state.dir === 'asc' ? cmp : -cmp;
        });
      }
    }
    if (!list.length) {
      tbody.appendChild(h('tr', { class: 'dv-empty-row' }, h('td', { colspan: String(columns.length), text: empty })));
      return;
    }
    for (const row of list) {
      const tr = h('tr', { class: rowClass ? rowClass(row) || '' : '' });
      if (onRowClick) {
        tr.classList.add('is-clickable');
        tr.tabIndex = 0;
        tr.addEventListener('click', (e) => {
          if (e.target.closest('button, a, input, select, textarea, label')) return;
          onRowClick(row);
        });
        tr.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target === tr) onRowClick(row); });
      }
      for (const col of columns) {
        const td = h('td', { class: `${col.align === 'right' ? 'num' : ''} ${col.cls || ''}`.trim() || null });
        const content = col.render ? col.render(row) : row[col.key];
        append(td, [content === null || content === undefined || content === '' ? '—' : content]);
        tr.appendChild(td);
      }
      tbody.appendChild(tr);
    }
  }
  drawHead();
  drawBody();
  return {
    el: wrap,
    update(next) {
      data = (next || []).slice();
      drawBody();
    },
  };
}

// ------------------------------------------------------------------ AI result card (UX §2.7)
export function confidencePill(conf) {
  if (typeof UI.confidencePill === 'function') return UI.confidencePill(isNum(conf) ? Number(conf) : undefined);
  if (!isNum(conf)) return null;
  const c = Number(conf);
  const level = c >= 0.8 ? 'High' : c >= 0.6 ? 'Medium' : 'Low';
  return h('span', { class: `pill pill-conf pill-${level === 'High' ? 'green' : level === 'Medium' ? 'amber' : 'red'}` }, `${level} ${Math.round(c * 100)}%`);
}
export const MODE_COPY = {
  simulated_fixture: 'Simulated AI · prepared response',
  simulated_generated: 'Simulated AI · rules engine',
  live: 'Live Claude',
  live_fallback: 'Live → Simulated',
};
export function modeText(mode, fallback) {
  return fallback || MODE_COPY[mode] || 'Rules engine';
}
export function modeChip(modeLabel, mode) {
  const text = modeText(mode, modeLabel);
  if (typeof UI.modeChip === 'function') return UI.modeChip(mode, text);
  return h('span', { class: `mode-chip${mode === 'live' ? ' mode-live' : ''}` }, text);
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const slugOf = (feature) => String(feature || '').replace(/_/g, '-');

/**
 * Runs an AI feature inside `host` using the shared AI Result Card (ui/ai_card.js runAiFeature).
 * opts: {feature, initiativeId?, body?, title?, trigger?, preview(run)->Node, acceptMessage?(result, run)->string,
 *        onApplied?(result, run), selectable?, selectableCount?(output), initialSelection?(output), acceptLabel?, acceptable?}
 * Accept calls POST /api/ai-runs/{id}/apply; onApplied runs after it.
 */
export function runAi(host, opts) {
  const renderPreview = (output, c) => opts.preview({ ...((c && c.run) || {}), output }, c || {});
  if (typeof UI.runAiFeature === 'function') {
    return UI.runAiFeature({
      feature: opts.feature,
      initiativeId: opts.initiativeId || null,
      container: host,
      renderPreview,
      body: opts.body || {},
      title: opts.title,
      trigger: opts.trigger,
      editable: false,
      acceptable: opts.acceptable !== false,
      acceptLabel: opts.acceptLabel,
      selectable: Boolean(opts.selectable),
      selectableCount: opts.selectableCount,
      initialSelection: opts.initialSelection,
      acceptMessage: opts.acceptMessage,
      onApplied: opts.onApplied,
    });
  }
  return runAiLocal(host, opts);
}

/** Minimal stand-in used only when ui/ai_card.js is unavailable. */
async function runAiLocal(host, opts) {
  const title = opts.title || 'AI suggestion';
  const settings = await getSettingsSafe();
  const call = (extra) => (opts.initiativeId
    ? api.runInitiativeAi(opts.initiativeId, slugOf(opts.feature), { ...(opts.body || {}), ...extra })
    : api.runGlobalAi(slugOf(opts.feature), { ...(opts.body || {}), ...extra }));
  async function generate(extra) {
    clear(host);
    host.hidden = false;
    host.appendChild(h('div', { class: 'ai-thinking' }, h('span', { text: `✦ ${title} · working…` })));
    if (opts.trigger) opts.trigger.disabled = true;
    let run;
    try {
      [run] = await Promise.all([call(extra), sleep(settings.ai_speed === 'Fast' ? 300 : 1500)]);
    } catch (err) {
      clear(host);
      host.appendChild(errorBox(err, () => generate(extra)));
      return;
    } finally {
      if (opts.trigger) opts.trigger.disabled = false;
    }
    clear(host);
    const output = run.output || {};
    const actions = h('div', { class: 'ai-card-actions' });
    if (opts.acceptable !== false) {
      actions.appendChild(button(opts.acceptLabel || 'Accept', async (e) => {
        const btn = e.currentTarget;
        btn.disabled = true;
        try {
          const selected = opts.selectable && opts.initialSelection ? opts.initialSelection(output) : undefined;
          const result = await api.applyAiRun(run.ai_run_id, selected ? { selected } : {});
          const msg = opts.acceptMessage ? opts.acceptMessage(result, run) : `${title} accepted.`;
          toast(msg);
          clear(host);
          host.appendChild(h('p', { class: 'ai-accepted-line', text: msg }));
          if (opts.onApplied) await opts.onApplied(result, run);
        } catch (err) {
          btn.disabled = false;
          toast(err.message, 'warning');
        }
      }, { kind: 'primary' }));
    }
    actions.append(button('Regenerate', () => generate({ regen_of: run.ai_run_id })), button('Discard', () => {
      api.rejectAiRun(run.ai_run_id, { reason: 'Discarded' }).catch(() => {});
      clear(host);
      host.hidden = true;
    }, { kind: 'text' }));
    host.appendChild(h('div', { class: 'ai-card ai-card-result' },
      h('div', { class: 'ai-card-head' }, h('span', { class: 'ai-card-title', text: `✦ AI suggestion · ${title}` }),
        h('span', { class: 'ai-card-meta' }, h('span', { text: 'AI-generated — review before use' }), confidencePill(run.confidence), modeChip(run.mode_label, run.mode))),
      h('div', { class: 'ai-preview' }, renderPreview(output, { run })),
      actions));
  }
  await generate({});
  return null;
}

/** Plain list preview helper for AI cards. */
export function bulletList(items) {
  const list = (items || []).filter(Boolean);
  if (!list.length) return null;
  return h('ul', { class: 'dv-bullets' }, list.map((x) => h('li', { text: String(x) })));
}

export function copyText(text) {
  if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
  const ta = h('textarea', { class: 'dv-offscreen', readonly: true });
  ta.value = text;
  document.body.appendChild(ta);
  ta.select();
  let ok = false;
  try {
    ok = document.execCommand('copy');
  } finally {
    ta.remove();
  }
  return ok ? Promise.resolve() : Promise.reject(new Error('Copy is not available in this browser.'));
}

export function rddcRoute(id, tab = 'pg1') {
  return `#/initiative/${id}/${tab}`;
}

// ------------------------------------------------------------------ safe markdown (bold, italic, code, lists, tables, hash-route links)
const INLINE_RE = /\*\*([^*]+)\*\*|`([^`]+)`|\[([^\]]+)\]\(([^)\s]+)\)|\*([^*\s][^*]*)\*|_([^_\s][^_]*)_/g;
function inline(text, ctx) {
  const frag = document.createDocumentFragment();
  let last = 0;
  let m;
  INLINE_RE.lastIndex = 0;
  while ((m = INLINE_RE.exec(text))) {
    if (m.index > last) frag.appendChild(document.createTextNode(text.slice(last, m.index)));
    if (m[1] !== undefined) frag.appendChild(h('strong', { text: m[1] }));
    else if (m[2] !== undefined) frag.appendChild(h('code', { text: m[2] }));
    else if (m[3] !== undefined) {
      const href = m[4];
      if (/^#\/[\w\-/]*$/.test(href)) {
        frag.appendChild(h('a', { href, on: { click: (e) => { e.preventDefault(); go(ctx, href); } } }, m[3]));
      } else frag.appendChild(document.createTextNode(m[3]));
    } else if (m[5] !== undefined) frag.appendChild(h('em', { text: m[5] }));
    else if (m[6] !== undefined) frag.appendChild(h('em', { text: m[6] }));
    last = INLINE_RE.lastIndex;
  }
  if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
  return frag;
}
const splitRow = (line) => line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((c) => c.trim());

/** Renders a small, safe subset of markdown into DOM nodes (no HTML is ever interpreted). */
export function renderMarkdown(md, ctx) {
  const root = h('div', { class: 'dv-md' });
  const lines = String(md ?? '').replace(/\r\n?/g, '\n').split('\n');
  let para = [];
  let list = null;
  const flushPara = () => {
    if (!para.length) return;
    const p = h('p');
    para.forEach((line, i) => { if (i) p.appendChild(h('br')); p.appendChild(inline(line, ctx)); });
    root.appendChild(p);
    para = [];
  };
  const flushList = () => { list = null; };
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    if (!line.trim()) { flushPara(); flushList(); continue; }
    const heading = /^\s{0,3}#{1,6}\s+(.*)$/.exec(line);
    if (heading) { flushPara(); flushList(); root.appendChild(h('h4', {}, inline(heading[1], ctx))); continue; }
    if (/^\s*\|/.test(line) && i + 1 < lines.length && /^\s*\|?\s*:?-{2,}/.test(lines[i + 1])) {
      flushPara(); flushList();
      const table = h('table');
      const head = h('tr', {}, splitRow(line).map((c) => h('th', {}, inline(c, ctx))));
      table.appendChild(h('thead', {}, head));
      const body = h('tbody');
      i += 2;
      while (i < lines.length && /^\s*\|/.test(lines[i])) {
        body.appendChild(h('tr', {}, splitRow(lines[i]).map((c) => h('td', {}, inline(c, ctx)))));
        i += 1;
      }
      i -= 1;
      table.appendChild(body);
      root.appendChild(table);
      continue;
    }
    const bullet = /^\s*[-*•]\s+(.*)$/.exec(line);
    const ordered = /^\s*\d+[.)]\s+(.*)$/.exec(line);
    if (bullet || ordered) {
      flushPara();
      const tag = bullet ? 'ul' : 'ol';
      if (!list || list.tagName.toLowerCase() !== tag) { list = h(tag); root.appendChild(list); }
      list.appendChild(h('li', {}, inline((bullet || ordered)[1], ctx)));
      continue;
    }
    flushList();
    para.push(line.trim());
  }
  flushPara();
  return root;
}
/** Plain-text version of markdown for "Copy to email". */
export function markdownToText(md) {
  return String(md ?? '')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/(^|\s)\*([^*\s][^*]*)\*/g, '$1$2')
    .replace(/^\s{0,3}#{1,6}\s+/gm, '')
    .replace(/^\s*[*•]\s+/gm, '- ')
    .trim();
}
/** Notifies the shell that initiative data changed (header RAG/stage can refresh). */
export function announceChange(initiativeId, what = 'data', ctx = null) {
  window.dispatchEvent(new CustomEvent('bmo:data-changed', { detail: { initiative_id: initiativeId ?? null, what } }));
  const st = ctx && ctx.state;
  if (st && typeof st.emit === 'function') st.emit('ai:applied', { feature: what, initiative_id: initiativeId ?? null });
}
