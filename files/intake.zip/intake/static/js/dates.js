// dates.js: the only place that parses or formats dates in the browser.
// ISO date strings ('YYYY-MM-DD') are parsed as LOCAL dates; datetimes are shown as the wall time
// written in the string (the server writes Toronto time), so every timezone sees the same text.

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MONTHS_LONG = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September',
  'October', 'November', 'December'];
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const DATE_RE = /^(\d{4})-(\d{2})-(\d{2})/;
const TIME_RE = /T(\d{2}):(\d{2})/;
const MONTH_RE = /^(\d{4})-(\d{2})$/;

const pad = (n) => String(n).padStart(2, '0');

/** 'YYYY-MM-DD' (or the date part of a datetime) -> local Date at midnight, or null. */
export function parseISODate(value) {
  if (!value || typeof value !== 'string') return null;
  const m = DATE_RE.exec(value);
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  return Number.isNaN(d.getTime()) ? null : d;
}

/** Local Date -> 'YYYY-MM-DD'. */
export function toISODate(date) {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) return '';
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

/** True when the value is a valid 'YYYY-MM-DD'. */
export function isISODate(value) {
  return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && parseISODate(value) !== null;
}

/** Compare two ISO dates: negative, 0 or positive. Missing values sort last. */
export function compareISO(a, b) {
  if (!a && !b) return 0;
  if (!a) return 1;
  if (!b) return -1;
  return a < b ? -1 : a > b ? 1 : 0;
}

/** "19 Oct 2026" */
export function fmtDate(value, fallback = '—') {
  const d = parseISODate(value);
  if (!d) return fallback;
  return `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

/** "19 Oct" */
export function fmtShort(value, fallback = '—') {
  const d = parseISODate(value);
  if (!d) return fallback;
  return `${d.getDate()} ${MONTHS[d.getMonth()]}`;
}

/** "Tue 20 Oct" (add year with withYear) */
export function fmtDay(value, { withYear = false, fallback = '—' } = {}) {
  const d = parseISODate(value);
  if (!d) return fallback;
  const base = `${DAYS[d.getDay()]} ${d.getDate()} ${MONTHS[d.getMonth()]}`;
  return withYear ? `${base} ${d.getFullYear()}` : base;
}

/** Day-of-week name for an ISO date ("Sat"). */
export function weekday(value) {
  const d = parseISODate(value);
  return d ? DAYS[d.getDay()] : '';
}

/** "10:00" from a datetime string or an 'HH:MM' value. */
export function fmtTime(value, fallback = '') {
  if (!value || typeof value !== 'string') return fallback;
  const m = TIME_RE.exec(value) || /^(\d{2}):(\d{2})/.exec(value);
  return m ? `${m[1]}:${m[2]}` : fallback;
}

/** "19 Oct 2026, 09:44" from an ISO datetime (wall time as written). */
export function fmtDateTime(value, fallback = '—') {
  if (!value || typeof value !== 'string') return fallback;
  const date = fmtDate(value, '');
  if (!date) return fallback;
  const time = fmtTime(value);
  return time ? `${date}, ${time}` : date;
}

/** "Nov 2026" from 'YYYY-MM'. */
export function fmtMonth(value, fallback = '—') {
  const m = MONTH_RE.exec(value || '') || DATE_RE.exec(value || '');
  if (!m) return fallback;
  return `${MONTHS[Number(m[2]) - 1]} ${m[1]}`;
}

/** "Nov" from 'YYYY-MM'. */
export function fmtMonthShort(value, fallback = '—') {
  const m = MONTH_RE.exec(value || '') || DATE_RE.exec(value || '');
  return m ? MONTHS[Number(m[2]) - 1] : fallback;
}

/** "November" from 'YYYY-MM'. */
export function fmtMonthLong(value, fallback = '—') {
  const m = MONTH_RE.exec(value || '') || DATE_RE.exec(value || '');
  return m ? MONTHS_LONG[Number(m[2]) - 1] : fallback;
}

const numberFmt = new Intl.NumberFormat('en-CA', { maximumFractionDigits: 1 });
const intFmt = new Intl.NumberFormat('en-CA', { maximumFractionDigits: 0 });

/** Number with thousands separators and up to one decimal; '—' when not a finite number. */
export function fmtNumber(value, fallback = '—') {
  const n = typeof value === 'string' && value.trim() !== '' ? Number(value) : value;
  if (typeof n !== 'number' || !Number.isFinite(n)) return fallback;
  return numberFmt.format(n);
}

/** "120 h", "137.5 h", "1,000 h" */
export function fmtHours(value, fallback = '—') {
  const s = fmtNumber(value, '');
  return s === '' ? fallback : `${s} h`;
}

/** Utilisation ratio (1.2833) -> "128%". */
export function fmtUtil(ratio, fallback = '—') {
  if (typeof ratio !== 'number' || !Number.isFinite(ratio)) return fallback;
  return `${intFmt.format(Math.round(ratio * 100))}%`;
}

/** Percentage value (88) -> "88%". */
export function fmtPct(value, fallback = '—') {
  const n = typeof value === 'string' && value.trim() !== '' ? Number(value) : value;
  if (typeof n !== 'number' || !Number.isFinite(n)) return fallback;
  return `${intFmt.format(Math.round(n))}%`;
}

/** Fiscal label from the API quarter object {fy, q, label}: "FY27 Q1 · Nov–Jan". */
export function fiscalLabel(quarter, fallback = '') {
  if (!quarter || typeof quarter !== 'object') return fallback;
  const parts = [quarter.fy, quarter.q].filter(Boolean).join(' ');
  if (parts && quarter.label) return `${parts} · ${quarter.label}`;
  return parts || quarter.label || fallback;
}

/** Calendar-day difference b - a (both ISO dates). Business days are computed on the server only. */
export function daysBetween(a, b) {
  const da = parseISODate(a);
  const db = parseISODate(b);
  if (!da || !db) return null;
  return Math.round((Date.UTC(db.getFullYear(), db.getMonth(), db.getDate())
    - Date.UTC(da.getFullYear(), da.getMonth(), da.getDate())) / 86400000);
}

/** UTC offset of America/Toronto on the given ISO date, e.g. "-05:00". */
export function torontoOffset(isoDate) {
  const m = DATE_RE.exec(isoDate || '');
  if (!m) return '-05:00';
  try {
    const probe = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]), 12));
    const parts = new Intl.DateTimeFormat('en-US', { timeZone: 'America/Toronto', timeZoneName: 'shortOffset' })
      .formatToParts(probe);
    const name = (parts.find((p) => p.type === 'timeZoneName') || {}).value || '';
    const om = /GMT([+-])(\d{1,2})(?::(\d{2}))?/.exec(name);
    if (!om) return '+00:00';
    return `${om[1]}${pad(om[2])}:${om[3] || '00'}`;
  } catch {
    return '-05:00';
  }
}

/** ISO datetime with offset -> value for <input type="datetime-local"> ("2027-02-20T02:00"). */
export function toLocalInput(value) {
  if (!value || typeof value !== 'string') return '';
  const d = DATE_RE.exec(value);
  const t = TIME_RE.exec(value);
  if (!d) return '';
  return `${d[1]}-${d[2]}-${d[3]}T${t ? `${t[1]}:${t[2]}` : '00:00'}`;
}

/** <input type="datetime-local"> value -> ISO datetime with the Toronto offset for that date. */
export function fromLocalInput(value) {
  if (!value || typeof value !== 'string') return null;
  const m = /^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})/.exec(value);
  if (!m) return null;
  return `${m[1]}T${m[2]}:00${torontoOffset(m[1])}`;
}

/** "2 min ago" style text from two ISO datetimes (now defaults to the browser clock). */
export function fmtAgo(value, nowValue) {
  if (!value) return '';
  const then = Date.parse(value);
  const now = nowValue ? Date.parse(nowValue) : Date.now();
  if (Number.isNaN(then) || Number.isNaN(now)) return fmtDateTime(value, '');
  const mins = Math.round((now - then) / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours} h ago`;
  return fmtDateTime(value, '');
}

/** Seconds from milliseconds: 2400 -> "2.4 s". */
export function fmtSeconds(ms, fallback = '') {
  if (typeof ms !== 'number' || !Number.isFinite(ms)) return fallback;
  return `${(ms / 1000).toFixed(1)} s`;
}

export const MONTH_NAMES = MONTHS;
