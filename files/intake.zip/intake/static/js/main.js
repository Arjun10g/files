// main.js: bootstrap, hash router, top bar, left rail, global error boundary.
// View modules: export async function render(root, params, ctx) -> cleanup | void.
import * as api from './api.js';
import * as dates from './dates.js';
import { state } from './state.js';
import * as ui from './ui/index.js';

const { h, mount } = ui;
const VERSION = state.version;

// ------------------------------------------------------------------ routes (contracts.md §6)
const ROUTES = [
  { re: /^\/?$/, redirect: '#/portfolio' },
  { re: /^\/portfolio$/, module: 'portfolio', rail: 'portfolio', title: 'Portfolio View' },
  { re: /^\/search$/, module: 'search', rail: 'search', title: 'Search Initiative' },
  { re: /^\/initiative\/new$/, module: 'initiative_new', rail: 'new', title: 'Add New Initiative' },
  {
    re: /^\/initiative\/(\d+)(?:\/(pg[1-5]|risks|artifacts|print))?$/, module: 'initiative', rail: 'edit', title: 'Edit Initiative',
    params: (m) => ({ id: Number(m[1]), tab: m[2] || 'pg1' }),
  },
  { re: /^\/intake$/, module: 'intake', rail: 'intake', title: 'Intake & Grooming' },
  { re: /^\/resources$/, module: 'resources', rail: 'resources', title: 'Resources' },
  { re: /^\/risks$/, module: 'risks', rail: 'risks', title: 'Risk Register' },
  { re: /^\/changes$/, module: 'changes', rail: 'changes', title: 'Change Management' },
  { re: /^\/artifacts$/, module: 'artifacts', rail: 'artifacts', title: 'Artifacts' },
  { re: /^\/outbox$/, module: 'outbox', rail: 'outbox', title: 'Outbox' },
  { re: /^\/ai-activity$/, module: 'ai_activity', rail: 'ai-activity', title: 'AI Activity' },
  { re: /^\/settings$/, module: 'settings', rail: 'settings', title: 'Settings' },
];

const viewHost = document.getElementById('view-host');
const banner = document.getElementById('global-banner');
let currentCleanup = null;
let navToken = 0;

/** Import a module under static/js with the cache-busting version. Resolves null when it is missing. */
export async function loadModule(relPath) {
  try {
    return await import(`./${relPath}?v=${VERSION}`);
  } catch (err) {
    if (err instanceof SyntaxError) window.dispatchEvent(new CustomEvent('bmo:error', { detail: err }));
    return null;
  }
}

function parseHash() {
  const raw = (window.location.hash || '#/').replace(/^#/, '');
  const [path, query = ''] = raw.split('?');
  return { path: path || '/', query: Object.fromEntries(new URLSearchParams(query)) };
}

export function navigate(hash) {
  const target = hash.startsWith('#') ? hash : `#${hash}`;
  if (window.location.hash === target) route();
  else window.location.hash = target;
}

function preparingPanel(title) {
  return h('div.view-pad', ui.pageBox({ title: title || 'This page' },
    ui.emptyState({
      icon: '◷',
      text: 'This page is being prepared. Use the Portfolio View or an initiative workspace in the meantime.',
      action: { label: 'Open Portfolio View', onClick: () => navigate('#/portfolio') },
    })));
}

function notFoundPanel() {
  return h('div.view-pad', ui.pageBox({ title: 'Page not found' },
    ui.emptyState({ text: 'That page does not exist in this tool.', action: { label: 'Open Portfolio View', onClick: () => navigate('#/portfolio') } })));
}

function setRail(key) {
  document.querySelectorAll('.rail-link').forEach((a) => {
    const on = a.dataset.rail === key;
    a.classList.toggle('active', on);
    if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  });
}

function updateEditLink() {
  const link = document.getElementById('rail-edit');
  if (!link) return;
  link.href = state.lastInitiativeId ? `#/initiative/${state.lastInitiativeId}/pg1` : '#/search?edit=1';
}

/** Render a view module into the host; errors become a friendly panel with Try again. */
async function renderView(moduleName, params, title, token) {
  const root = h('div.view', { dataset: { view: moduleName } });
  const mod = await loadModule(`views/${moduleName}.js`);
  if (token !== navToken) return;
  if (!mod || typeof mod.render !== 'function') {
    mount(viewHost, preparingPanel(title));
    return;
  }
  mount(viewHost, root);
  try {
    const cleanup = await mod.render(root, params, ctx);
    if (token !== navToken) { if (typeof cleanup === 'function') cleanup(); return; }
    currentCleanup = typeof cleanup === 'function' ? cleanup : null;
  } catch (err) {
    if (token !== navToken) return;
    mount(root, h('div.view-pad', ui.errorPanel(err, { title: `${title} could not be loaded`, retry: () => route() })));
  }
}

async function route() {
  const token = ++navToken;
  ui.closeAllModals();
  if (currentCleanup) {
    try { currentCleanup(); } catch { /* a view's cleanup must never block navigation */ }
    currentCleanup = null;
  }
  const { path, query } = parseHash();
  const match = ROUTES.map((r) => ({ r, m: r.re.exec(path) })).find((x) => x.m);
  hideBanner(true);
  if (!match) {
    setRail(null);
    mount(viewHost, notFoundPanel());
    return;
  }
  const { r, m } = match;
  if (r.redirect) {
    window.location.replace(r.redirect);
    return;
  }
  setRail(r.rail);
  document.title = `${r.title} · Digital Channels · Project Management Tool`;
  if (r.module !== 'initiative') state.setCurrent({ initiativeId: null, rddc: null, name: null, tab: null, page: r.title });
  const params = { ...(r.params ? r.params(m) : {}), query };
  mount(viewHost, h('div.view-pad', ui.skeleton({ lines: 8 })));
  viewHost.parentElement.scrollTop = 0;
  window.scrollTo(0, 0);
  await renderView(r.module, params, r.title, token);
  refreshBadges();
}

// ------------------------------------------------------------------ global banner / error boundary
let bannerTimer = null;
function showBanner(message) {
  clearTimeout(bannerTimer);
  mount(banner,
    h('span.banner-icon', { aria: { hidden: 'true' } }, '⚠'),
    h('span.banner-msg', message),
    h('button.link.banner-retry', { type: 'button', on: { click: () => { hideBanner(); route(); } } }, 'Reload this page'),
    h('button.icon-btn.banner-close', { type: 'button', aria: { label: 'Dismiss' }, on: { click: () => hideBanner() } }, '✕'));
  banner.hidden = false;
  bannerTimer = setTimeout(() => hideBanner(), 12000);
}
function hideBanner(onlyTransient) {
  if (onlyTransient && banner.dataset.sticky === '1') return;
  banner.hidden = true;
  banner.dataset.sticky = '';
}

function friendly(err) {
  if (err && err.name === 'ApiError' && err.message) return err.message;
  return 'Something went wrong. Try again, or reset the demo from Settings.';
}

window.addEventListener('unhandledrejection', (e) => {
  e.preventDefault();
  const err = e.reason;
  if (err && err.code === 'cancelled') return;
  showBanner(friendly(err));
});
window.addEventListener('error', (e) => {
  if (e && e.target && e.target !== window) return;
  showBanner(friendly(e.error));
});
window.addEventListener('bmo:error', (e) => showBanner(friendly(e.detail)));

// ------------------------------------------------------------------ top bar
function updateModeBadge() {
  const badge = document.getElementById('ai-mode-badge');
  const live = state.isLive();
  badge.textContent = live ? '● Live Claude' : '● Simulated AI';
  badge.classList.toggle('live', live);
  badge.title = live ? 'AI mode: Live Claude · change it in Settings' : 'AI mode: Simulated AI · change it in Settings';
}

const PERSONA_INITIALS = { 'DC PM': 'PM', 'Dev Lead': 'DL', Requestor: 'RQ', STO: 'ST', 'Account Manager': 'AM' };

function fillPersona() {
  const sel = document.getElementById('persona-select');
  const opts = state.options('persona');
  const list = opts.length ? opts : ['DC PM', 'Dev Lead', 'Requestor', 'STO', 'Account Manager'].map((v) => ({ value: v, label: v }));
  const current = state.persona();
  mount(sel, ...list.map((o) => h('option', { value: String(o.value), selected: String(o.value) === current }, o.label)));
  document.getElementById('persona-avatar').textContent = PERSONA_INITIALS[current] || current.slice(0, 2).toUpperCase();
}

function wirePersona() {
  const sel = document.getElementById('persona-select');
  sel.addEventListener('change', async () => {
    const value = sel.value;
    try {
      const s = await api.updateSettings({ persona: value });
      state.setSettings(s);
      ui.toast(`Acting as ${value}.`, { variant: 'info' });
    } catch (err) {
      ui.toastError(err);
      fillPersona();
    }
  });
  state.on('settings', () => { fillPersona(); updateModeBadge(); });
}

function wireSearch() {
  const input = document.getElementById('global-search');
  const results = document.getElementById('gs-results');
  let items = [];
  let active = -1;
  let reqId = 0;
  const close = () => { results.hidden = true; input.setAttribute('aria-expanded', 'false'); active = -1; };
  const open = (id) => { close(); input.value = ''; navigate(`#/initiative/${id}/pg1`); };
  const paint = () => {
    mount(results);
    if (!items.length) {
      results.appendChild(h('div.gs-empty', `No initiatives match "${input.value.trim()}".`));
    } else {
      items.forEach((it, i) => {
        results.appendChild(h(`div.gs-item${i === active ? '.active' : ''}`, {
          attrs: { role: 'option', 'aria-selected': i === active ? 'true' : 'false' },
          on: { mousedown: (e) => { e.preventDefault(); open(it.id); } },
        }, h('span.gs-rddc', it.rddc), h('span.gs-name', it.name), ui.ragPill(it.rag, { size: 'sm' })));
      });
    }
    results.appendChild(h('div.gs-all', { on: { mousedown: (e) => { e.preventDefault(); const q = input.value.trim(); close(); navigate(`#/search?q=${encodeURIComponent(q)}`); } } }, 'See all results in Search Initiative'));
    results.hidden = false;
    input.setAttribute('aria-expanded', 'true');
  };
  const lookup = ui.debounce(async () => {
    const q = input.value.trim();
    if (q.length < 2) { close(); return; }
    const mine = ++reqId;
    try {
      const res = await api.listInitiatives({ q });
      if (mine !== reqId) return;
      items = (res.items || []).slice(0, 8);
      active = items.length ? 0 : -1;
      paint();
    } catch {
      close();
    }
  }, 200);
  input.addEventListener('input', lookup);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown' && !results.hidden) { e.preventDefault(); active = Math.min(items.length - 1, active + 1); paint(); }
    else if (e.key === 'ArrowUp' && !results.hidden) { e.preventDefault(); active = Math.max(0, active - 1); paint(); }
    else if (e.key === 'Enter') {
      e.preventDefault();
      lookup.cancel();
      if (!results.hidden && items[active]) open(items[active].id);
      else { const q = input.value.trim(); close(); navigate(`#/search${q ? `?q=${encodeURIComponent(q)}` : ''}`); }
    } else if (e.key === 'Escape') { close(); }
  });
  input.addEventListener('blur', () => setTimeout(close, 120));
}

// ------------------------------------------------------------------ assistant drawer
// B5's views/assistant.js owns the drawer content and toggles `hidden`/`is-open` on the host element;
// main.js positions the host, adds the scrim (below 1600px) and pushes the content (1600px and up).
let assistantMod = null;
let assistantMounted = false;
const assistantEl = h('aside.assistant-drawer', { hidden: true, attrs: { 'aria-hidden': 'true', 'aria-label': 'Assistant' } });
const assistantScrim = h('div.drawer-scrim');
document.body.append(assistantScrim, assistantEl);
assistantScrim.addEventListener('click', () => { if (assistantMod && assistantMod.close) assistantMod.close(); });
window.addEventListener('bmo:assistant-toggle', (e) => {
  const open = Boolean(e.detail && e.detail.open);
  assistantScrim.classList.toggle('open', open);
  document.body.classList.toggle('drawer-open', open);
});

async function openAssistant(opts = {}) {
  const cur = state.current;
  if (!assistantMod) assistantMod = await loadModule('views/assistant.js');
  if (!assistantMod || typeof assistantMod.mount !== 'function') {
    const { body } = ui.openDrawer({ key: 'assistant-missing', title: 'Assistant', subtitle: cur.rddc || cur.page || '' });
    mount(body, ui.emptyState({ icon: '✦', text: 'The assistant is being prepared. Ask again in a moment.' }));
    return;
  }
  try {
    if (!assistantMounted) {
      assistantMounted = true;
      await assistantMod.mount(assistantEl, ctx);
    }
    const context = {};
    const iid = opts.initiativeId ?? cur.initiativeId;
    if (iid) context.initiative_id = iid;
    if (cur.page) context.page = cur.page;
    if (cur.rddc) context.label = `${cur.rddc}${cur.page ? ` · ${cur.page}` : ''}`;
    if (opts.question) context.question = opts.question;
    if (typeof assistantMod.open === 'function') await assistantMod.open(context);
    else { assistantEl.hidden = false; assistantEl.classList.add('is-open'); }
  } catch (err) {
    assistantMounted = false;
    ui.toastError(err, 'The assistant could not start. Try again.');
  }
}

state.on('current', () => {
  updateEditLink();
  const cur = state.current;
  ui.setDrawerSubtitle(cur.rddc ? `Context: ${cur.rddc}${cur.page ? ` · ${cur.page}` : ''}` : (cur.page ? `Context: ${cur.page}` : ''));
});

// ------------------------------------------------------------------ rail badges
let badgeTimer = 0;
async function refreshBadges() {
  const now = Date.now();
  if (now - badgeTimer < 3000) return;
  badgeTimer = now;
  const setBadge = (id, n, title) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.hidden = !(n > 0);
    el.textContent = n > 0 ? String(n) : '';
    el.title = title || '';
  };
  try {
    const q = await api.getIntakeQueue();
    const waiting = (q.items || []).filter((i) => ['Intake', 'Grooming'].includes(i.stage)).length;
    setBadge('badge-intake', waiting, `${waiting} waiting for grooming`);
  } catch { setBadge('badge-intake', 0); }
  try {
    const o = await api.listOutbox({ status: 'Queued' });
    const n = (o.counts && o.counts.Queued) ?? o.total ?? 0;
    setBadge('badge-outbox', n, `${n} queued`);
  } catch { setBadge('badge-outbox', 0); }
}
state.on('ai:applied', () => { badgeTimer = 0; refreshBadges(); });

// ------------------------------------------------------------------ ctx handed to views
export const ctx = {
  api,
  state,
  ui,
  dates,
  navigate,
  refresh: () => route(),
  openAssistant,
  loadModule,
};

// ------------------------------------------------------------------ bootstrap
async function boot() {
  wirePersona();
  wireSearch();
  updateEditLink();
  document.getElementById('ask-assistant').addEventListener('click', () => openAssistant());
  window.addEventListener('hashchange', route);
  const [settings, health, lookups] = await Promise.allSettled([api.getSettings(), api.getAppHealth(), state.loadLookups()]);
  if (settings.status === 'fulfilled') state.setSettings(settings.value);
  if (health.status === 'fulfilled') {
    state.setAppHealth(health.value);
    if (health.value && health.value.version) state.version = health.value.version;
    const foot = document.getElementById('rail-foot');
    if (health.value && health.value.today) foot.textContent = `Demo date ${dates.fmtDate(health.value.today)}`;
  }
  if (settings.status === 'rejected' && health.status === 'rejected') {
    banner.dataset.sticky = '1';
    showBanner(friendly(settings.reason));
  } else if (lookups.status === 'rejected') {
    showBanner('Some lists could not be loaded. Reload the page to try again.');
  }
  fillPersona();
  updateModeBadge();
  await route();
}

boot();
