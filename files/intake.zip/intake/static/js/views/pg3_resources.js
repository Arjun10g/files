// views/pg3_resources.js: Pg 3 Resource Management. Project Health (Suggest fix -> rebalance),
// PRN burndown, quarter grid (Availability | Allocation), monthly heatmap, Suggest Resources, assignments.
import { runAiFeature } from '../ui/ai_card.js';
import { previewResources, previewRebalance } from '../ui/previews.js';

const DIMENSIONS = [
  ['schedule', 'Schedule'], ['resources', 'Resources'], ['scope', 'Scope'], ['dependencies', 'Dependencies'], ['budget', 'Budget'],
];

export async function render(root, params, ctx) {
  const { api, state, ui, dates, ws, navigate } = ctx;
  const { h } = ui;
  const id = params.id;
  const bundle = params.bundle;
  const print = Boolean(params.print);
  const charts = [];
  let disposed = false;

  /** Render with a B5 chart when present; otherwise use the local fallback. */
  async function chartOr(path, fn, el, data, opts, fallback) {
    const mod = await ctx.loadModule(path);
    if (disposed) return null;
    if (mod && typeof mod[fn] === 'function') {
      try {
        ui.mount(el);
        const c = mod[fn](el, data, opts);
        if (c) charts.push(c);
        return c;
      } catch (err) {
        window.dispatchEvent(new CustomEvent('bmo:error', { detail: err }));
      }
    }
    ui.mount(el, fallback());
    return null;
  }

  // ---------------------------------------------------------------- Project Health
  const healthHost = h('div.chart-host.health-host');
  const fixSlot = h('div.ai-slot', { hidden: true });

  async function loadHealth() {
    ui.mount(healthHost, ui.loadingLine('Calculating health…'));
    let health;
    try {
      health = await api.getInitiativeHealth(id);
    } catch (err) {
      ui.mount(healthHost, ui.errorPanel(err, { retry: loadHealth }));
      return;
    }
    if (disposed) return;
    ws.setHealth(health);
    if (!health || health.scored === false) {
      ui.mount(healthHost, h('div', ui.ragPill(null, { size: 'lg' }),
        h('p.muted', { style: { 'margin-top': '8px' } }, 'Health is scored from the Planning stage onward. Approve the L2 estimate on Pg 1 to start scoring.')));
      return;
    }
    await chartOr('charts/rag.js', 'renderHealth', healthHost, health, {
      onSuggestFix: (dim) => suggestFix(health, dim),
      onOverride: (dim) => pillClicked(health, dim),
    }, () => fallbackHealth(health));
  }

  function fallbackHealth(health) {
    const dims = health.dimensions || {};
    return h('div.health-fallback',
      h('div.hf-row', h('strong.eyebrow', 'Project Health'), ui.ragPill(health.overall, { size: 'lg' })),
      DIMENSIONS.map(([key, label]) => {
        const d = dims[key] || {};
        const fixable = key === 'resources' && (d.rag === 'Red' || d.rag === 'Amber') && !print;
        return h('div.hf-row',
          h('div', h('div', label, d.overridden ? h('span.ai-tag.ai-tag-edited', 'Overridden') : null),
            (d.reasons || []).length ? h('div.hf-reason', d.reasons[0]) : null),
          h('div.btn-row',
            fixable ? ui.btn('Suggest fix', { variant: 'ghost', small: true, onClick: () => suggestFix(health, key) }) : null,
            print ? null : h('button.link.small', { type: 'button', on: { click: () => pillClicked(health, key) } }, 'Override'),
            ui.ragPill(d.rag || null, { size: 'sm' })));
      }),
      (health.attention || []).length ? h('div.attention', h('b', 'Management attention'), health.attention.join(' · ')) : null);
  }

  function suggestFix(health, dim) {
    const res = (health.dimensions || {}).resources || {};
    const m = res.metrics || {};
    const options = {};
    if (m.wbs_codes && m.wbs_codes[0]) options.wbs_code = m.wbs_codes[0];
    if (m.peak_resource_id) options.resource_id = m.peak_resource_id;
    if (dim && dim !== 'resources') {
      ui.toast('Suggest fix works on the Resources dimension. Other dimensions follow the plan dates and approvals.', { variant: 'info' });
      return;
    }
    fixSlot.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    runAiFeature({
      feature: 'rebalance', initiativeId: id, container: fixSlot,
      body: { options },
      renderPreview: previewRebalance,
      selectable: true, selectableCount: (o) => (o.options || []).length,
      initialSelection: (o) => (o.recommended_option_index !== null && o.recommended_option_index !== undefined ? [o.recommended_option_index] : (o.options || []).length ? [0] : []),
      editable: false,
      acceptLabel: 'Accept',
      acceptMessage: (r, run, applyBody) => {
        const opts = run.output.options || [];
        const idx = applyBody && applyBody.selected && applyBody.selected.length ? applyBody.selected[0] : (run.output.recommended_option_index ?? 0);
        const opt = opts[idx] || opts[0];
        const rag = r && r.health && r.health.dimensions && r.health.dimensions.resources ? r.health.dimensions.resources.rag : null;
        const moved = opt ? `${opt.task_wbs_code} moved to ${opt.to_resource_name}` : 'Work moved';
        return rag ? `Resources is now ${rag} — ${moved}.` : `${moved}.`;
      },
      onApplied: async (r) => {
        if (r && r.health) ws.setHealth(r.health);
        await ws.reload();
      },
    });
  }

  /** Red/Amber pill: offer Suggest fix (primary) and Override; Green/unscored: straight to Override. */
  function pillClicked(health, dim) {
    const d = ((health.dimensions || {})[dim]) || {};
    if (!['Red', 'Amber'].includes(d.rag) || print) { overrideDim(health, dim); return; }
    const label = (DIMENSIONS.find(([k]) => k === dim) || [dim, dim])[1];
    const fixable = dim === 'resources';
    ui.openModal({
      title: `${label} is ${d.rag}`,
      body: h('div',
        (d.reasons || []).length ? h('ul.ai-list', d.reasons.map((r) => h('li', r))) : null,
        h('p.small.muted', { style: { 'margin-top': '8px' } }, fixable
          ? 'Suggest fix proposes moving work to someone with spare capacity. Nothing changes until you accept.'
          : `${label} follows the plan dates and approvals; fix it on Pg 2 or Pg 1, or override it with a reason.`)),
      actions: [
        { label: 'Cancel', variant: 'ghost' },
        { label: 'Override', variant: 'secondary', onClick: () => { setTimeout(() => overrideDim(health, dim), 0); } },
        fixable
          ? { label: 'Suggest fix', variant: 'primary', onClick: () => { setTimeout(() => suggestFix(health, dim), 0); } }
          : { label: dim === 'schedule' ? 'Open Pg 2 Project Plan' : 'Open Pg 1', variant: 'primary', onClick: () => navigate(`#/initiative/${id}/${dim === 'schedule' ? 'pg2' : 'pg1'}`) },
      ],
    });
  }

  async function overrideDim(health, dim) {
    const d = ((health.dimensions || {})[dim]) || {};
    const label = (DIMENSIONS.find(([k]) => k === dim) || [dim, dim])[1];
    const values = await ui.promptModal({
      title: `Override ${label}`,
      intro: `Calculated as ${d.rag || 'not scored'}. A DC PM override needs a reason and is shown as "Overridden".`,
      fields: [
        { name: 'rag', label: 'RAG', type: 'select', value: d.overridden ? d.rag : '', options: [{ value: '', label: 'Use the calculated value' }, ...state.options('rag')] },
        { name: 'reason', label: 'Reason', type: 'textarea', rows: 3 },
      ],
      submitLabel: 'Save override',
    });
    if (!values) return;
    if (values.rag && !values.reason) { ui.toast('Add a reason for the override.', { variant: 'warning' }); return; }
    try {
      const next = await api.overrideHealth(id, { dimension: dim, rag: values.rag || null, reason: values.reason || '' });
      ws.setHealth(next);
      ui.toast(values.rag ? `${label} overridden to ${values.rag}.` : `${label} uses the calculated value again.`);
      loadHealth();
    } catch (err) {
      ui.toastError(err);
    }
  }

  // ---------------------------------------------------------------- PRN burndown
  const burnHost = h('div.chart-host.burn-host');
  async function loadBurndown() {
    if (!bundle.initiative.prn_code && !bundle.prn) {
      ui.mount(burnHost, ui.emptyState({ icon: '◔', text: 'No PRN linked. Add the PRN on Pg 1 to track charged against funded hours.', cls: 'compact' }));
      return;
    }
    ui.mount(burnHost, ui.loadingLine());
    try {
      const b = await api.getInitiativeBurndown(id);
      if (disposed) return;
      await chartOr('charts/burndown.js', 'renderBurndown', burnHost, b, {}, () => fallbackBurndown(b));
    } catch (err) {
      ui.mount(burnHost, ui.errorPanel(err, { retry: loadBurndown }));
    }
  }
  function fallbackBurndown(b) {
    const charged = (b.charged_cum || []).filter((v) => typeof v === 'number').slice(-1)[0] || 0;
    const statusText = { on_track: 'On track', at_risk: 'At risk', overrun: 'Overrun' }[b.status] || '';
    return ui.keyStrip([
      { label: 'PRN', value: ui.txt(b.prn_code) },
      { label: 'Funded', value: dates.fmtHours(b.funded_hours) },
      { label: 'Charged', value: dates.fmtHours(charged) },
      { label: 'Remaining', value: dates.fmtHours((b.funded_hours || 0) - charged) },
      { label: 'Status', value: statusText || '—', sub: b.exhaust_month ? `Exhausted by ${dates.fmtMonth(b.exhaust_month)}` : null },
    ]);
  }

  // ---------------------------------------------------------------- quarter grid + assignments
  const qHost = h('div.q-host');
  const assignHost = h('div.assign-host');
  let gridData = null;

  async function loadGrid() {
    ui.mount(qHost, ui.skeleton({ lines: 4 }));
    try {
      gridData = await api.getResourceGrid(id);
    } catch (err) {
      ui.mount(qHost, ui.errorPanel(err, { retry: loadGrid }));
      return;
    }
    if (disposed) return;
    paintQuarters();
    paintAssignments();
    fyHint.textContent = gridData.fy ? `Fiscal year ${gridData.fy} (Nov–Oct)` : 'Fiscal year starts in November';
  }

  function paintQuarters() {
    const quarters = gridData.quarters || [];
    const rows = gridData.rows || [];
    if (!rows.length) {
      ui.mount(qHost, ui.emptyState({ icon: '◔', text: 'No one is assigned yet. Assign resources on Pg 2, or click Suggest Resources.' }));
      return;
    }
    const head1 = h('tr', h('th.name', { rowSpan: 2 }, 'Resource Name'),
      quarters.map((q) => h('th.q-head', { colSpan: 2, title: dates.fiscalLabel(q) }, q.label)));
    const head2 = h('tr', quarters.map(() => [h('th', 'Availability'), h('th', 'Allocation')]));
    const body = rows.map((r) => h('tr',
      h('td.name', r.name, h('small', [r.role, r.team].filter(Boolean).filter((v, i, a) => a.indexOf(v) === i && !(i > 0 && String(a[0]).startsWith(String(v)))).join(' · '))),
      quarters.map((q) => {
        const c = (r.cells || []).find((x) => x.quarter === q.q || x.quarter === q.label) || {};
        const alloc = Number(c.allocation) || 0;
        const title = alloc ? `${r.name} · ${q.label}: ${dates.fmtHours(alloc)} of ${dates.fmtHours(c.availability)} (${dates.fmtUtil(c.util)}) · Confirmed ${dates.fmtHours(c.confirmed || 0)} · Tentative ${dates.fmtHours(c.tentative || 0)}` : null;
        return [
          h('td', dates.fmtHours(c.availability)),
          h(`td.alloc.${alloc ? ui.bandClass(c.band, c.util) : 'band-none'}`, { title }, alloc ? dates.fmtHours(alloc) : '0 h',
            alloc && typeof c.util === 'number' ? h('span.small', ` · ${dates.fmtUtil(c.util)}`) : null),
        ];
      })));
    ui.mount(qHost, 
      h('div.table-scroll', h('table.qgrid', h('thead', head1, head2), h('tbody', body))),
      h('div.legend',
        h('span', h('span.legend-sw.band-spare'), 'Under 70% (spare)'),
        h('span', h('span.legend-sw.band-ok'), '70–100%'),
        h('span', h('span.legend-sw.band-stretched'), '101–110%'),
        h('span', h('span.legend-sw.band-over'), 'Over 110%'),
        h('span.muted', 'Availability is maintained by the Account Manager on the Resources page. Allocation is calculated from Pg 2 assignments.')));
  }

  let highlightResource = null;
  function paintAssignments() {
    const list = (gridData && gridData.assignments) || [];
    if (!list.length) {
      ui.mount(assignHost, ui.emptyState({ icon: '◔', text: 'No one is assigned yet. Assign resources on Pg 2, or click Suggest Resources.', cls: 'compact' }));
      return;
    }
    ui.mount(assignHost, h('div.table-scroll', h('table.table',
      h('thead', h('tr', h('th', 'Resource'), h('th', 'WBS Step'), h('th.num', 'Hours'), h('th.num', 'Allocation %'), h('th', 'From'), h('th', 'To'), h('th', 'Demand'))),
      h('tbody', list.map((a) => h(`tr${highlightResource && String(highlightResource) === String(a.resource_id) ? '.row-highlight' : ''}`,
        { style: highlightResource && String(highlightResource) === String(a.resource_id) ? { background: 'var(--ai-fill)' } : null },
        h('td', ui.txt(a.resource_name)), h('td.mono', ui.txt(a.wbs_code)), h('td.num', dates.fmtHours(a.hours)),
        h('td.num', a.allocation_pct ? `${a.allocation_pct}%` : '—'), h('td', dates.fmtDate(a.from)), h('td', dates.fmtDate(a.to)),
        h('td', ui.demandPill(a.firmness))))))));
  }

  // ---------------------------------------------------------------- heatmap
  const heatHost = h('div.chart-host.heat-host');
  async function loadHeatmap() {
    ui.mount(heatHost, ui.loadingLine());
    let cap;
    try {
      cap = await api.getCapacity({ group: 'resource', initiative_id: id });
    } catch (err) {
      ui.mount(heatHost, ui.errorPanel(err, { retry: loadHeatmap }));
      return;
    }
    if (disposed) return;
    if (!(cap.rows || []).length) {
      ui.mount(heatHost, ui.emptyState({ icon: '◔', text: 'Monthly allocation appears once people are assigned on Pg 2.', cls: 'compact' }));
      return;
    }
    await chartOr('charts/heatmap.js', 'renderHeatmap', heatHost, cap, {
      onCellClick: (cell) => {
        const key = cell && (cell.resource_id ?? cell.key ?? cell.row?.key);
        highlightResource = key ?? null;
        paintAssignments();
        assignHost.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      },
    }, () => fallbackHeat(cap));
  }
  function fallbackHeat(cap) {
    const months = cap.months || [];
    return h('div.table-scroll', h('table.qgrid.fallback-heat',
      h('thead', h('tr', h('th.name', 'Resource'), months.map((m) => h('th', dates.fmtMonthShort(m))))),
      h('tbody', (cap.rows || []).map((r) => h('tr', h('td.name', ui.txt(r.label)),
        months.map((m) => {
          const c = (r.cells || []).find((x) => x.month === m) || {};
          const has = typeof c.util === 'number' && (c.confirmed || c.tentative);
          return h(`td.${has ? ui.bandClass(c.band, c.util) : 'band-none'}`, { title: has ? `${r.label} · ${dates.fmtMonth(m)} · ${dates.fmtHours((c.confirmed || 0) + (c.tentative || 0))} of ${dates.fmtHours(c.available)}` : null },
            has ? dates.fmtUtil(c.util) : '');
        }))))));
  }

  // ---------------------------------------------------------------- suggest resources
  const suggestSlot = h('div.ai-slot', { hidden: true });
  const stepSel = h('select.input.input-sm', { aria: { label: 'Suggest resources for' } },
    h('option', { value: '' }, 'All steps'),
    (bundle.tasks || []).filter((t) => !(t.est_hours === 0 && (bundle.tasks || []).some((x) => x.parent_id === t.id)) && !t.is_milestone)
      .map((t) => h('option', { value: t.wbs_code }, `${t.wbs_code} ${t.step}`)));
  function suggestTitle() {
    if (!stepSel.value) return 'Suggested Resources';
    const t = (bundle.tasks || []).find((x) => x.wbs_code === stepSel.value);
    return `${t && t.phase === 'Development' ? 'Recommended Developer' : 'Recommended resource'} · ${stepSel.value}`;
  }
  const suggestBtn = ui.autoBtn('Suggest Resources', {
    onClick: () => runAiFeature({
      feature: 'resources', initiativeId: id, container: suggestSlot, trigger: suggestBtn,
      title: suggestTitle(),
      body: stepSel.value ? { options: { wbs_code: stepSel.value } } : {},
      renderPreview: previewResources,
      selectable: true, selectableCount: (o) => (o.recommendations || []).length,
      acceptLabel: 'Assign recommended',
      acceptMessage: () => 'Resources assigned · capacity and health recalculated.',
      onApplied: async (r) => {
        if (r && r.health) ws.setHealth(r.health);
        await ws.reload();
      },
    }),
    disabled: !(bundle.tasks || []).length,
    reason: 'Generate the project plan on Pg 2 first.',
  });

  // ---------------------------------------------------------------- assemble
  const fyHint = h('span.page-hint', 'Fiscal year starts in November');
  const box = ui.pageBox({ pg: 'PG 3', title: 'Resource Management' },
    h('div.two-col.collapse-narrow',
      ui.card({}, healthHost),
      ui.card({ title: 'PRN burndown', actions: bundle.prn ? h('span.muted.small', bundle.prn.prn_code) : null }, burnHost)),
    fixSlot,
    h('div.section-title', 'Hours per quarter', fyHint),
    qHost,
    h('div.section-title', 'Monthly allocation', h('span.section-sub', '% of available hours')),
    heatHost,
    print ? null : h('div.auto-row', suggestBtn, h('span.muted.small', 'for'), stepSel),
    suggestSlot,
    h('div.section-title', 'Assignments', h('span.section-sub', 'from Pg 2 · Tentative until L2 is approved, Confirmed after')),
    assignHost,
    (bundle.tasks || []).length ? null : h('div.btn-row', ui.btn('Open Pg 2 Project Plan', { variant: 'secondary', onClick: () => navigate(`#/initiative/${id}/pg2`) })));
  root.append(box);
  state.flashRunId = null;

  await Promise.allSettled([loadHealth(), loadGrid(), loadHeatmap(), loadBurndown()]);

  return () => {
    disposed = true;
    for (const c of charts) { try { c.destroy?.(); } catch { /* ignore */ } }
  };
}
