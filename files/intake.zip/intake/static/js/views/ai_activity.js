// AI Activity (#/ai-activity): every AI run with feature, initiative, mode, confidence, status, latency; KPIs.
import {
  api, h, clear, card, dataTable, pageHeader, errorBox, loading, selectEl, chip, statusPill, confidencePill, modeChip,
  fmtNum, fmtDateTime, go, itemsOf, isNum, button, bulletList, framePage,
} from '../charts/kit.js';

export const FEATURE_LABEL = {
  intake_analysis: 'Intake Analysis', change_summary: 'Change Summary', l2_estimate: 'L2 estimate', wbs: 'Project Plan',
  resources: 'Suggest Resources', rebalance: 'Suggest fix', risks: 'Predict risks', exec_summary: 'Executive Summary',
  cr_compliance: 'CR Compliance', skill_matrix: 'Skill Matrix', nudges: 'Draft reminders', meeting_extract: 'Meeting actions',
  lessons: 'Lessons learned', intake_autofill: 'Intake autofill', assistant: 'Assistant',
};
const STATUS_LABEL = { generated: 'Not reviewed', not_reviewed: 'Not reviewed', accepted: 'Accepted', rejected: 'Discarded', superseded: 'Regenerated' };

/** Deterministic outputs (rules engine, CR compliance checks) carry no confidence score (decision 11). */
export function isDeterministic(r) {
  return Boolean(r && (r.deterministic || r.mode === 'simulated_generated' || r.feature === 'cr_compliance'));
}
function statusOf(r) {
  if (r.status === 'rejected' && /not reviewed/i.test(r.reject_reason || '')) return 'Not reviewed';
  return STATUS_LABEL[r.status] || r.status;
}

function stat(label, value, note) {
  return h('div', { class: 'dv-kpi' }, h('div', { class: 'dv-kpi-label', text: label }), h('div', { class: 'dv-kpi-value', text: value }), note ? h('div', { class: 'dv-kpi-note', text: note }) : null);
}

export async function render(root, params, ctx) {
  const page = framePage(root, 'ai-activity');
  page.appendChild(pageHeader({ title: 'AI Activity', hint: 'Every AI suggestion, how it was produced, and what the team did with it' }));
  const statsHost = h('div');
  const runsCard = card('Runs');
  const featCard = card('By feature');
  const detail = h('div', { class: 'dv-detail', hidden: true, 'aria-live': 'polite' });
  const legend = h('p', { class: 'dv-muted dv-mode-legend' },
    h('strong', { text: 'Simulated AI · prepared response' }), ' = drafted in advance by an AI test agent from the same prompt and data. ',
    h('strong', { text: 'Simulated AI · rules engine' }), ' = built by the tool\'s own rules from live data. ',
    h('strong', { text: 'Live Claude' }), ' = answered by Claude just now; ',
    h('strong', { text: 'Live → Simulated' }), ' = Claude was unavailable, so a simulated response was used.');
  page.append(legend, statsHost, h('div', { class: 'dv-grid-21' }, runsCard.el, featCard.el), detail);
  statsHost.appendChild(loading());

  let stats;
  let runs;
  let inits;
  try {
    [stats, runs, inits] = await Promise.all([api.getAiStats(), api.listAiRuns({ limit: 200 }), api.listInitiatives({}).catch(() => ({ items: [] }))]);
  } catch (err) {
    clear(statsHost);
    statsHost.appendChild(errorBox(err, () => render(root, params, ctx)));
    return undefined;
  }
  const rddcById = new Map(itemsOf(inits).map((i) => [String(i.id), i.rddc]));
  const items = itemsOf(runs);
  // Time is credited only on accepted runs (decision 11), so it is summed from the accepted rows themselves.
  const acceptedRows = items.filter((r) => r.status === 'accepted');
  const minutes = acceptedRows.length ? acceptedRows.reduce((s, r) => s + (Number(r.minutes_saved) || 0), 0) : 0;
  const totalRuns = Number(stats.runs ?? items.length) || 0;
  const rate = totalRuns ? (Number(stats.accepted) || 0) / totalRuns : 0;
  const avgLatency = items.length ? items.reduce((s, r) => s + (Number(r.latency_ms) || 0), 0) / items.length : 0;
  clear(statsHost);
  statsHost.appendChild(h('div', { class: 'dv-stats', 'data-testid': 'ai-stats' },
    stat('Runs', fmtNum(stats.runs ?? items.length), `${fmtNum(stats.rejected ?? 0)} discarded · ${fmtNum(items.filter((r) => statusOf(r) === 'Not reviewed').length)} not reviewed`),
    stat('Accepted', `${fmtNum(stats.accepted ?? 0)} of ${fmtNum(stats.runs ?? items.length)}`, `Accepted ÷ all runs (${Math.round((rate <= 1 ? rate * 100 : rate))}%)`),
    stat('Time saved', minutes >= 90 ? `${fmtNum(minutes / 60, 1)} h` : `${fmtNum(minutes)} min`, 'Credited on Accept, against the manual baseline per feature'),
    stat('Average response', `${fmtNum(avgLatency / 1000, 1)} s`, 'Simulated responses include thinking time')));

  const featureOptions = Object.entries(FEATURE_LABEL).map(([value, label]) => ({ value, label }));
  const filters = { feature: '', status: '' };
  const table = dataTable({
    caption: 'AI runs', sortKey: 'created_at', sortDir: 'desc', dense: true,
    empty: 'No AI runs yet. Use any yellow ✦ button to create one.',
    onRowClick: (r) => showDetail(r),
    columns: [
      { key: 'created_at', label: 'When', render: (r) => fmtDateTime(r.created_at) },
      { key: 'feature', label: 'Feature', render: (r) => FEATURE_LABEL[r.feature] || r.feature },
      { key: 'initiative_id', label: 'Initiative', render: (r) => {
        const rddc = r.rddc || rddcById.get(String(r.initiative_id));
        if (!r.initiative_id) return r.scope === 'portfolio' ? 'Portfolio' : 'Draft intake';
        return h('a', { class: 'dv-link', href: `#/initiative/${r.initiative_id}/pg1`, on: { click: (e) => { e.preventDefault(); go(ctx, `#/initiative/${r.initiative_id}/pg1`); } } }, rddc || `Initiative ${r.initiative_id}`);
      } },
      { key: 'mode', label: 'Mode', render: (r) => (isDeterministic(r) ? h('span', { class: 'mode-chip', title: 'A deterministic check by the tool\'s own rules', text: 'Rules check' }) : modeChip(r.mode_label, r.mode)) },
      { key: 'confidence', label: 'Confidence', render: (r) => (isDeterministic(r) ? h('span', { class: 'dv-muted', title: 'Calculated by rules, so no confidence score', text: 'Rules' }) : confidencePill(r.confidence) || '—'), sort: (r) => (isDeterministic(r) ? -1 : Number(r.confidence) || 0) },
      { key: 'status', label: 'Status', render: (r) => statusPill(statusOf(r)), sort: (r) => statusOf(r) },
      { key: 'latency_ms', label: 'Latency', align: 'right', render: (r) => (isNum(r.latency_ms) ? (Number(r.latency_ms) < 100 ? 'Instant' : `${(Number(r.latency_ms) / 1000).toFixed(1)} s`) : '—'), sort: (r) => Number(r.latency_ms) || 0 },
      { key: 'minutes_saved', label: 'Saved', align: 'right', title: 'Credited only when a suggestion is accepted', render: (r) => (r.status === 'accepted' && Number(r.minutes_saved) ? `${fmtNum(r.minutes_saved)} min` : '—'), sort: (r) => (r.status === 'accepted' ? Number(r.minutes_saved) || 0 : 0) },
    ],
    rows: items,
  });
  const apply = () => table.update(items.filter((r) => (!filters.feature || r.feature === filters.feature) && (!filters.status || statusOf(r) === filters.status)));
  runsCard.body.append(h('div', { class: 'dv-filters' },
    selectEl(featureOptions, '', (v) => { filters.feature = v; apply(); }, { label: 'Feature', allLabel: 'All features' }),
    selectEl([...new Set(Object.values(STATUS_LABEL))].map((label) => ({ value: label, label })), '', (v) => { filters.status = v; apply(); }, { label: 'Status', allLabel: 'All' })), table.el);

  const featMap = new Map();
  for (const r of items) {
    const f = featMap.get(r.feature) || { feature: r.feature, runs: 0, accepted: 0, minutes_saved: 0 };
    f.runs += 1;
    if (r.status === 'accepted') { f.accepted += 1; f.minutes_saved += Number(r.minutes_saved) || 0; }
    featMap.set(r.feature, f);
  }
  const byFeature = items.length ? [...featMap.values()] : (Array.isArray(stats.by_feature) ? stats.by_feature : []);
  featCard.body.appendChild(dataTable({
    caption: 'By feature', sortKey: 'runs', sortDir: 'desc', dense: true, empty: 'No runs yet.',
    columns: [
      { key: 'feature', label: 'Feature', render: (r) => FEATURE_LABEL[r.feature] || r.feature },
      { key: 'runs', label: 'Runs', align: 'right' },
      { key: 'accepted', label: 'Accepted', align: 'right' },
      { key: 'minutes_saved', label: 'Saved', align: 'right', render: (r) => `${fmtNum(r.minutes_saved)} min`, sort: (r) => Number(r.minutes_saved) || 0 },
    ],
    rows: byFeature,
  }).el);

  async function showDetail(r) {
    clear(detail);
    detail.hidden = false;
    detail.appendChild(loading());
    try {
      const run = await api.getAiRun(r.ai_run_id ?? r.id);
      clear(detail);
      const warnings = Array.isArray(run.warnings) ? run.warnings : [];
      const sources = Array.isArray(run.sources) ? run.sources : [];
      detail.append(
        h('div', { class: 'dv-section-title' }, h('span', { text: `${FEATURE_LABEL[run.feature] || run.feature} · ${fmtDateTime(run.created_at)}` }), button('Close', () => { detail.hidden = true; }, { kind: 'text' })),
        h('dl', { class: 'dv-kv' },
          h('dt', { text: 'Mode' }), h('dd', {}, isDeterministic(run) ? h('span', { class: 'mode-chip', text: 'Rules check' }) : modeChip(run.mode_label, run.mode)),
          run.mode === 'live' && run.model ? [h('dt', { text: 'Generated by' }), h('dd', { text: `Claude · ${run.model}` })] : null,
          h('dt', { text: 'Status' }), h('dd', { text: statusOf(run) }),
          isNum(run.confidence) && !isDeterministic(run) ? [h('dt', { text: 'Confidence' }), h('dd', {}, confidencePill(run.confidence))] : null,
          run.instruction ? [h('dt', { text: 'Instruction' }), h('dd', { text: run.instruction })] : null,
          isNum(run.variant_index) ? [h('dt', { text: 'Variant' }), h('dd', { text: String(Number(run.variant_index) + 1) })] : null),
        sources.length ? h('div', { class: 'ai-sources' }, h('span', { class: 'dv-muted', text: 'Sources: ' }), sources.map((s) => chip(s.label || String(s.id ?? '')))) : null,
        warnings.length ? h('div', {}, h('strong', { text: 'Warnings' }), bulletList(warnings)) : null);
    } catch (err) {
      clear(detail);
      detail.appendChild(errorBox(err, () => showDetail(r)));
    }
  }
  return undefined;
}
