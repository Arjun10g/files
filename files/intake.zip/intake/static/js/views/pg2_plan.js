// views/pg2_plan.js: Pg 2 Project Plan. Key dates, Generate Project Plan (AI), Excel-like WBS grid saved
// through the bulk endpoint (debounced), Recommended Developer per row, Generate Gantt view (B5 chart
// with a built-in fallback). Grid edits recalculate the Gantt, key dates and header RAG live.
import { createGrid } from '../ui/grid.js';
import { runAiFeature, runBuildStep } from '../ui/ai_card.js';
import { previewWbs, previewResources } from '../ui/previews.js';

const WBS_RE = /^WBS-\d{3}$/;

export async function render(root, params, ctx) {
  const { api, state, ui, dates, ws } = ctx;
  const { h } = ui;
  const id = params.id;
  const bundle = params.bundle;
  const ini = bundle.initiative;
  const print = Boolean(params.print);
  let disposed = false;

  const tasks = (bundle.tasks || []).map((t) => ({ ...t, depends_on_codes: t.depends_on_codes || [] }));
  const childCount = (t) => tasks.filter((x) => x.parent_id === t.id).length;
  const isSummary = (t) => childCount(t) > 0 && !(Number(t.est_hours) > 0);

  let gantt = null;
  let grid = null;
  const rowsNow = () => (grid ? grid.getRows() : tasks);
  let chart = null;
  let scale = 'month';
  let showCritical = false;
  let ganttVisible = false;

  // ---------------------------------------------------------------- key dates
  const keyHost = h('div.key-host');
  /** Caption under Production Date: the train that date belongs to, flagged when it misses the target. */
  function prodCaption(prod, target) {
    if (!prod) return { sub: target ? `Target ${target.code}` : null };
    const trains = (state.lookups && state.lookups.release_trains) || [];
    const own = trains.find((t) => t.train_date === prod);
    const ownText = own ? `${own.code} release train` : 'Not a release train date';
    if (target && target.train_date && prod > target.train_date) {
      return { sub: h('span', `${ownText} · `, h('strong.text-red', `Misses ${target.code}`)), cls: 'key-bad' };
    }
    return { sub: ownText };
  }

  // ---------------------------------------------------------------- plan vs L2 reconciliation (#11)
  const reconHost = h('div.recon-line.small');
  let l2 = null;
  const PHASE_TO_L2 = {
    Development: 'dev', Estimation: 'arch', Architecture: 'arch', Integration: 'qa', QA: 'qa', UAT: 'qa',
    Readiness: 'pm', Production: 'pm', Hypercare: 'pm',
  };
  function paintRecon() {
    const rows = grid ? grid.getRows() : tasks;
    if (!l2 || !rows.length) { ui.mount(reconHost); return; }
    const plan = { dev: 0, arch: 0, qa: 0, pm: 0 };
    let total = 0;
    for (const t of rows) {
      if (isSummary(t)) continue;
      const hrs = Number(t.est_hours) || 0;
      total += hrs;
      const k = PHASE_TO_L2[t.phase];
      if (k) plan[k] += hrs;
    }
    const est = { dev: l2.dev_hours, arch: l2.architecture_hours, qa: l2.qa_hours, pm: l2.pm_release_hours };
    const labels = { dev: 'Development', arch: 'Architecture / SA', qa: 'QA and testing', pm: 'PM / Release' };
    const diff = (k) => Math.round(((plan[k] || 0) - (Number(est[k]) || 0)) * 10) / 10;
    const signed = (n) => (n > 0 ? `+${dates.fmtHours(n)}` : n < 0 ? `−${dates.fmtHours(-n)}` : '0 h');
    const rounding = Math.round(((Number(l2.total_hours) || 0) - (Number(l2.subtotal) || 0) - (Number(l2.contingency_hours) || 0)) * 10) / 10;
    ui.mount(reconHost,
      h('strong', `Plan ${dates.fmtHours(total)} vs L2 ${dates.fmtHours(l2.total_hours)}`),
      ` — contingency ${dates.fmtHours(l2.contingency_hours)} held${rounding ? ` (+${dates.fmtHours(rounding)} rounding)` : ''}; difference by phase: `,
      Object.keys(labels).map((k) => `${labels[k]} ${signed(diff(k))}`).join(' · '),
      '.');
  }
  if (tasks.length && (bundle.components || []).length) {
    api.calculateL2(id).then((e) => { l2 = e; paintRecon(); }).catch(() => {});
  }

  function paintKeys() {
    const devHours = grid.getRows().filter((t) => t.phase === 'Development' && !isSummary(t)).reduce((a, t) => a + (Number(t.est_hours) || 0), 0);
    const g = gantt || {};
    const readiness = g.readiness_date || ini.readiness_date;
    const qa = g.qa_date || ini.qa_date;
    const prod = g.prod_date || ini.prod_date;
    const floatBd = typeof g.float_bd === 'number' ? g.float_bd : null;
    const sched = ws.health && ws.health.dimensions && ws.health.dimensions.schedule;
    const train = bundle.target_train;
    const scored = Boolean(ws.health && ws.health.scored !== false && ws.health.overall);
    paintRecon();
    ui.mount(keyHost, ui.keyStrip([
      { label: 'Readiness Date', value: readiness ? dates.fmtDay(readiness, { withYear: true }) : '—' },
      { label: 'QA Date', value: qa ? dates.fmtDay(qa, { withYear: true }) : '—' },
      { label: 'Production Date', value: prod ? dates.fmtDay(prod, { withYear: true }) : '—', ...prodCaption(prod, train) },
      { label: 'Developer hours', value: grid.getRows().length ? dates.fmtHours(devHours) : '—' },
      {
        label: 'Float to release',
        value: floatBd === null ? '—' : `${floatBd} business day${Math.abs(floatBd) === 1 ? '' : 's'}`,
        sub: grid.getRows().length ? h('span', 'Schedule ', ui.ragPill(scored && sched ? sched.rag : null, { size: 'sm' })) : null,
        cls: scored && sched && sched.rag === 'Red' ? 'key-bad' : scored && sched && sched.rag === 'Amber' ? 'key-warn' : null,
      },
      { label: 'Plan baseline', value: ini.baseline_set_at ? dates.fmtDate(ini.baseline_set_at) : 'Not set' },
    ]));
  }

  // ---------------------------------------------------------------- grid
  const people = state.people().map((p) => ({ value: p.id, label: p.name }));
  const tracked = state.people({ tracked: true }).map((p) => ({ value: p.id, label: `${p.name} · ${p.team_label || p.team || ''}`.replace(/ · $/, ''), short: p.name }));
  const statusOpts = state.options('task_status');

  const depCodesValid = (codes, row) => {
    const known = new Set(rowsNow().map((t) => t.wbs_code));
    for (const c of codes) {
      if (!WBS_RE.test(c)) return `"${c}" is not a WBS step. Use codes like WBS-210.`;
      if (c === row.wbs_code) return 'A step cannot depend on itself.';
      if (!known.has(c)) return `Unknown WBS step: ${c}.`;
    }
    return '';
  };

  const editableIfLeaf = (r) => !isSummary(r);
  const pending = new Map();
  let lastChange = null;
  const saveSoon = ui.debounce(() => flush(), 600);

  grid = createGrid({
    gridKey: `wbs-${id}`,
    caption: 'Project plan (WBS)',
    rows: tasks,
    stickyCols: 2,
    flashRunId: state.flashRunId,
    isAi: (r) => r.source === 'ai',
    indent: (r) => (r.parent_id ? 1 : 0),
    rowClass: (r) => [isSummary(r) ? 'summary-row' : '', r.parent_id ? 'child-row' : '', r.at_risk ? 'at-risk-row' : ''].filter(Boolean).join(' '),
    emptyText: 'No project plan yet. Generate one from the Change Summary, or add steps manually.',
    columns: [
      { key: 'wbs_code', label: 'WBS', width: 76, type: 'readonly', cls: 'mono' },
      {
        key: 'step', label: 'Steps', width: 220, type: 'text', aiTag: true, indentPrefix: true,
        format: (r) => h('span', { title: r.description || null }, r.step),
        validate: (v) => (!String(v || '').trim() ? 'Step name is required.' : ''),
        after: (r) => (r.is_milestone ? h('span.milestone-mark', { title: 'Milestone' }, '◆') : null),
      },
      {
        key: 'resource_id', label: 'Resource', width: 146, type: 'select', options: tracked, editable: editableIfLeaf,
        format: (r) => {
          if (isSummary(r)) return '';
          const name = r.resource_name || state.personName(r.resource_id);
          return name ? name : h('span.warn-mark', { title: 'No resource assigned · this feeds the Resources RAG' }, '⚠ Unassigned');
        },
        after: (r) => (print || isSummary(r) || r.is_milestone ? null : h('button.cell-suggest', {
          type: 'button', title: `Recommended Developer for ${r.wbs_code}`, aria: { label: `Recommended Developer for ${r.wbs_code}` },
          on: { click: (e) => { e.stopPropagation(); suggestFor(r); } },
        }, '✦')),
      },
      {
        key: 'planned_start', label: 'Start', width: 102, type: 'date', editable: editableIfLeaf,
        format: (r) => dates.fmtDate(r.planned_start, ''),
        validate: (v, r) => (!v ? 'Start date is required.' : (r.planned_end && v > r.planned_end ? 'End date is before start date.' : '')),
      },
      {
        key: 'planned_end', label: 'End', width: 102, type: 'date', editable: editableIfLeaf,
        format: (r) => dates.fmtDate(r.planned_end, ''),
        validate: (v, r) => (!v ? 'End date is required.' : (r.planned_start && v < r.planned_start ? 'End date is before start date.' : '')),
      },
      { key: 'status', label: 'Status', width: 108, type: 'select', options: statusOpts, allowEmpty: false, format: (r) => ui.statusPill(r.status) },
      {
        key: 'pct', label: '%', width: 84, type: 'number', align: 'right', min: 0, max: 100,
        format: (r) => h('span', `${Number(r.pct) || 0}`, ui.pctBar(r.pct)),
        validate: (v) => (v === null || typeof v !== 'number' || v < 0 || v > 100 ? '% Completion must be from 0 to 100.' : ''),
      },
      {
        key: 'est_hours', label: 'Hours', width: 80, type: 'number', align: 'right', min: 0, step: 0.5, editable: editableIfLeaf,
        format: (r) => (isSummary(r) ? dates.fmtHours(sumChildren(r)) : dates.fmtHours(r.est_hours)),
        validate: (v) => (v === null || typeof v !== 'number' || v < 0 ? 'Hours must be zero or more.' : ''),
      },
      {
        key: 'allocation_pct', extra: true, label: 'Alloc %', width: 72, type: 'number', align: 'right', min: 1, max: 100, editable: editableIfLeaf,
        format: (r) => (r.allocation_pct ? `${r.allocation_pct}%` : ''),
        validate: (v) => (v !== null && (typeof v !== 'number' || v < 1 || v > 100 || !Number.isInteger(v)) ? 'Allocation must be a whole number from 1 to 100.' : ''),
      },
      {
        key: 'depends_on_codes', extra: true, label: 'Depends on', width: 130, type: 'text', cls: 'mono',
        format: (r) => (r.depends_on_codes || []).join(', '),
        parse: (raw) => String(raw || '').split(/[\s,;]+/).map((s) => s.trim().toUpperCase()).filter(Boolean).map((s) => (/^\d{3}$/.test(s) ? `WBS-${s}` : s)),
        validate: (v, r) => depCodesValid(v || [], r),
      },
      { key: 'owner_id', extra: true, label: 'SME/Owner', width: 150, type: 'select', options: people, format: (r) => ui.txt(r.owner_name || state.personName(r.owner_id), '') },
      { key: 'description', extra: true, label: 'Description', width: 220, type: 'textarea', format: (r) => (r.description ? h('span.ellipsis', { title: r.description }, r.description) : '') },
      { key: 'comments', label: 'Comments', width: 150, type: 'text', format: (r) => (r.comments ? h('span.ellipsis', { title: r.comments }, r.comments) : '') },
    ],
    rowActions: print ? null : (r) => h('button.icon-btn', { type: 'button', title: `Delete ${r.wbs_code}`, aria: { label: `Delete ${r.wbs_code}` }, on: { click: () => deleteStep(r) } }, '✕'),
    onCommit: (r, key, value, oldValue) => queue(r, key, value, oldValue),
  });
  state.flashRunId = null;

  function sumChildren(r) {
    return rowsNow().filter((x) => x.parent_id === r.id).reduce((a, x) => a + (Number(x.est_hours) || 0), 0);
  }

  function queue(r, key, value, oldValue) {
    const patch = pending.get(r.id) || { id: r.id };
    if (key === 'depends_on_codes') {
      const byCode = new Map(grid.getRows().map((t) => [t.wbs_code, t.id]));
      patch.depends_on = (value || []).map((c) => byCode.get(c)).filter(Boolean);
    } else {
      patch[key] = value;
    }
    if (key === 'status' && value === 'Completed' && Number(r.pct) !== 100) {
      patch.pct = 100;
      r.pct = 100;
      grid.updateRow({ id: r.id, pct: 100 }, { keepDirty: true });
    }
    if (key === 'resource_id') r.resource_name = state.personName(value);
    if (key === 'owner_id') r.owner_name = state.personName(value);
    pending.set(r.id, patch);
    if (key === 'planned_start' || key === 'planned_end') {
      const prev = lastChange && lastChange.id === r.id ? lastChange : {
        id: r.id, code: r.wbs_code,
        start: key === 'planned_start' ? oldValue : r.planned_start,
        end: key === 'planned_end' ? oldValue : r.planned_end,
      };
      lastChange = prev;
    }
    saveSoon();
  }

  let saving = false;
  let undoPending = false;
  let lastUndo = null;
  async function flush() {
    if (!pending.size || disposed) return;
    if (saving) { saveSoon(); return; }
    saving = true;
    const batch = Array.from(pending.values());
    pending.clear();
    const before = new Map(grid.getRows().map((t) => [t.id, `${t.planned_start}|${t.planned_end}`]));
    const change = lastChange;
    lastChange = null;
    const wasUndo = undoPending;
    undoPending = false;
    try {
      const res = await api.bulkUpdateTasks(id, batch);
      if (disposed) return;
      const items = res.items || [];
      const editedIds = new Set(batch.map((b) => b.id));
      const shifted = [];
      for (const it of items) {
        const prev = before.get(it.id);
        if (prev !== undefined && prev !== `${it.planned_start}|${it.planned_end}` && !editedIds.has(it.id)) shifted.push(it);
        grid.updateRow({ ...it, depends_on_codes: it.depends_on_codes || [] });
      }
      grid.markAllSaved();
      if (shifted.length) grid.pulseRows(shifted.map((t) => t.id));
      if (res.health) ws.setHealth(res.health);
      await refreshGantt();
      paintKeys();
      if (!wasUndo && change && !shifted.length && change.start && change.end) {
        lastUndo = { id: change.id, code: change.code, start: change.start, end: change.end };
        paintUndo();
      }
      if (wasUndo) {
        const readiness = gantt && gantt.readiness_date;
        ui.toast(`Change undone${readiness ? ` · Readiness Date back to ${dates.fmtDate(readiness)}` : ''}.`, { variant: 'info' });
      } else if (change && shifted.length) {
        const readiness = gantt && gantt.readiness_date;
        const oldStart = change.start;
        const oldEnd = change.end;
        if (oldStart && oldEnd) { lastUndo = { id: change.id, code: change.code, start: oldStart, end: oldEnd }; paintUndo(); }
        ui.toast(`${shifted[0].wbs_code}${shifted.length > 1 ? ` and ${shifted.length - 1} more step${shifted.length > 2 ? 's' : ''}` : ''} moved${readiness ? ` · Readiness Date now ${dates.fmtDate(readiness)}` : ''}.`, {
          variant: 'info',
          action: oldStart && oldEnd ? { label: 'Undo', onClick: () => undoDates(change.id, oldStart, oldEnd) } : null,
        });
      }
    } catch (err) {
      for (const b of batch) {
        const key = Object.keys(b).find((k) => k !== 'id');
        grid.markError(b.id, key === 'depends_on' ? 'depends_on_codes' : key, err.message || 'Could not save this change.');
      }
      ui.toastError(err);
    } finally {
      saving = false;
    }
  }

  function undoDates(taskId, start, end) {
    if (disposed) return;
    grid.updateRow({ id: taskId, planned_start: start, planned_end: end });
    pending.set(taskId, { ...(pending.get(taskId) || { id: taskId }), planned_start: start, planned_end: end });
    undoPending = true;
    lastUndo = null;
    paintUndo();
    saveSoon.flush();
  }

  async function deleteStep(r) {
    const kids = grid.getRows().filter((x) => x.parent_id === r.id);
    const ok = await ui.confirmModal({
      title: `Delete ${r.wbs_code}?`,
      message: kids.length ? `${r.wbs_code} ${r.step} and its ${kids.length} child step${kids.length === 1 ? '' : 's'} will be removed from the plan.` : `${r.wbs_code} ${r.step} will be removed from the plan.`,
      confirmLabel: 'Delete step', danger: true,
    });
    if (!ok) return;
    try {
      const res = await api.deleteTask(r.id);
      if (res && res.health) ws.setHealth(res.health);
      ui.toast(`${r.wbs_code} deleted.`);
      await ws.reload();
    } catch (err) {
      ui.toastError(err);
    }
  }

  async function addStep() {
    const rows = grid.getRows();
    const codes = rows.map((t) => Number(String(t.wbs_code).slice(4))).filter(Number.isFinite);
    const next = `WBS-${String(Math.min(999, (Math.floor(Math.max(0, ...codes) / 100) + 1) * 100)).padStart(3, '0')}`;
    const phases = state.options('phase');
    const values = await ui.promptModal({
      title: 'Add step',
      fields: [
        { name: 'wbs_code', label: 'WBS', value: next, required: true, hint: 'Child steps use the parent hundred, for example WBS-250 under WBS-200.' },
        { name: 'step', label: 'Step', required: true },
        { name: 'phase', label: 'Phase', type: 'select', options: phases, value: 'Development' },
        { name: 'parent_id', label: 'Parent step', type: 'select', options: [{ value: '', label: 'None (top level)' }, ...rows.filter((t) => !t.parent_id).map((t) => ({ value: t.id, label: `${t.wbs_code} ${t.step}` }))] },
        { name: 'planned_start', label: 'Start', type: 'date', required: true, value: ini.planned_start || bundle.today },
        { name: 'planned_end', label: 'End', type: 'date', required: true, value: ini.planned_start || bundle.today },
        { name: 'est_hours', label: 'Hours', type: 'number', value: '0' },
      ],
      submitLabel: 'Add step',
    });
    if (!values) return;
    if (!WBS_RE.test(values.wbs_code.toUpperCase())) { ui.toast('Use a WBS code like WBS-250.', { variant: 'warning' }); return; }
    if (values.planned_end < values.planned_start) { ui.toast('End date is before start date.', { variant: 'warning' }); return; }
    try {
      const res = await api.createTask(id, {
        wbs_code: values.wbs_code.toUpperCase(), step: values.step, phase: values.phase || null,
        parent_id: values.parent_id ? Number(values.parent_id) : null,
        planned_start: values.planned_start, planned_end: values.planned_end,
        est_hours: Number(values.est_hours) || 0, status: 'Backlog', pct: 0,
      });
      if (res && res.health) ws.setHealth(res.health);
      ui.toast(`${values.wbs_code.toUpperCase()} added to the plan.`);
      await ws.reload();
    } catch (err) {
      ui.toastError(err);
    }
  }

  async function rebaseline() {
    const values = await ui.promptModal({
      title: 'Re-baseline the plan',
      intro: 'The current dates become the new baseline. A decision is logged with your reason.',
      fields: [{ name: 'reason', label: 'Reason', type: 'textarea', rows: 3, required: true }],
      submitLabel: 'Re-baseline',
    });
    if (!values) return;
    try {
      const res = await api.rebaseline(id, { reason: values.reason });
      ws.updateInitiative({ baseline_set_at: res.baseline_set_at });
      paintKeys();
      ui.toast('Baseline reset · decision logged.');
    } catch (err) {
      ui.toastError(err);
    }
  }

  // ---------------------------------------------------------------- AI: plan + recommended developer
  const planSlot = h('div.ai-slot', { hidden: true });
  const hasComponents = (bundle.components || []).length > 0;
  const genBtn = ui.autoBtn('Generate Project Plan', {
    onClick: () => generatePlan(),
    disabled: !hasComponents,
    reason: 'Generate the Change Summary on Pg 1 first.',
  });

  async function generatePlan() {
    if (grid.getRows().length) {
      const ok = await ui.confirmModal({
        title: 'Replace the current plan?',
        message: 'A new plan suggestion will be prepared. Accepting it replaces the current steps; nothing changes until you accept.',
        confirmLabel: 'Prepare new plan',
      });
      if (!ok) return;
    }
    runAiFeature({
      feature: 'wbs', initiativeId: id, container: planSlot, trigger: genBtn,
      renderPreview: previewWbs,
      acceptMessage: () => 'Plan updated · Gantt, capacity and health recalculated.',
      onApplied: async (res) => {
        if (res && res.health) ws.setHealth(res.health);
        await ws.reload();
      },
    });
  }

  function suggestFor(r) {
    planSlot.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    runAiFeature({
      feature: 'resources', initiativeId: id, container: planSlot,
      title: `${r.phase === 'Development' ? 'Recommended Developer' : 'Recommended resource'} · ${r.wbs_code}`,
      body: { options: { wbs_code: r.wbs_code } },
      renderPreview: previewResources,
      selectable: true, selectableCount: (o) => (o.recommendations || []).length,
      acceptLabel: 'Assign recommended',
      acceptMessage: () => `${r.wbs_code} resource updated · capacity and health recalculated.`,
      onApplied: async (res) => {
        if (res && res.health) ws.setHealth(res.health);
        await ws.reload();
      },
    });
  }

  // ---------------------------------------------------------------- Gantt
  const ganttSlot = h('div.ai-slot', { hidden: true });
  const ganttHost = h('div.chart-host.gantt-host');
  const critLegend = h('div.small.muted.crit-legend');
  const ganttBtn = ui.autoBtn('Generate Gantt view', { onClick: () => showGantt(true), disabled: !tasks.length, reason: 'Generate the project plan first.' });
  const scaleSeg = h('div.seg', { attrs: { role: 'group', 'aria-label': 'Scale' } },
    ...['week', 'month'].map((s) => h(`button${s === scale ? '.on' : ''}`, { type: 'button', dataset: { scale: s }, on: { click: () => { scale = s; paintSeg(); redrawChart(true); } } }, s === 'week' ? 'Week' : 'Month')));
  function paintSeg() { scaleSeg.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.scale === scale)); }
  const critBox = h('input', { type: 'checkbox' });
  critBox.addEventListener('change', () => { showCritical = critBox.checked; redrawChart(true); });
  const toolbar = h('div.chart-toolbar.no-print', { hidden: true },
    h('span.muted', 'Scale'), scaleSeg,
    h('label.check', critBox, 'Show critical path'),
    critLegend);

  async function showGantt(fromButton) {
    if (!grid.getRows().length) {
      ui.mount(ganttHost, ui.emptyState({ icon: '▤', text: 'The Gantt view appears once the plan has steps with start and end dates.', cls: 'compact' }));
      return;
    }
    try {
      gantt = await runBuildStep(ganttSlot, 'Building timeline…', () => api.getGantt(id));
      ganttSlot.hidden = true;
      if (disposed) return;
      state.markGanttShown(id);
      ganttVisible = true;
      await redrawChart(true);
      paintKeys();
      if (fromButton) ganttHost.scrollIntoView({ block: 'start', behavior: 'smooth' });
    } catch (err) {
      ui.mount(ganttHost, ui.errorPanel(err, { retry: () => showGantt(false) }));
    }
  }

  async function refreshGantt() {
    try {
      gantt = await api.getGantt(id);
    } catch {
      return;
    }
    if (ganttVisible) await redrawChart(false);
  }

  function paintCritLegend() {
    if (!showCritical || !gantt) { critLegend.textContent = ''; return; }
    const byId = new Map((gantt.tasks || []).map((t) => [t.id, t.wbs_code]));
    const chain = (gantt.critical_path || []).map((tid) => byId.get(tid)).filter(Boolean);
    critLegend.textContent = chain.length ? `Critical path: ${chain.join(' → ')}` : 'No critical path found.';
  }

  async function redrawChart(rebuild) {
    if (!gantt) return;
    paintCritLegend();
    const mod = await ctx.loadModule('charts/gantt.js');
    if (disposed) return;
    const opts = {
      onTaskClick: (t) => grid.selectRowById(t && typeof t === 'object' ? t.id : t),
      compact: false, scale, showCritical,
      targetTrain: bundle.target_train ? bundle.target_train.code : null,
    };
    if (mod && typeof mod.renderGantt === 'function') {
      toolbar.hidden = true;
      try {
        if (chart && !rebuild && typeof chart.update === 'function') { chart.update(gantt); return; }
        if (chart && typeof chart.destroy === 'function') chart.destroy();
        ui.mount(ganttHost);
        ganttHost.classList.toggle('show-critical', showCritical);
        chart = mod.renderGantt(ganttHost, gantt, opts);
        return;
      } catch (err) {
        chart = null;
        window.dispatchEvent(new CustomEvent('bmo:error', { detail: err }));
      }
    }
    toolbar.hidden = false;
    ui.mount(ganttHost, fallbackGantt(gantt));
  }

  function fallbackGantt(g) {
    const rows = (g.tasks || []).filter((t) => t.planned_start && t.planned_end);
    if (!rows.length) return ui.emptyState({ icon: '▤', text: 'The Gantt view appears once the plan has steps with start and end dates.', cls: 'compact' });
    const start = dates.parseISODate(g.start || rows[0].planned_start);
    const end = dates.parseISODate(g.end || rows[rows.length - 1].planned_end);
    const span = Math.max(1, dates.daysBetween(dates.toISODate(start), dates.toISODate(end)) + 1);
    const pos = (iso) => `${(Math.max(0, dates.daysBetween(dates.toISODate(start), iso)) / span) * 100}%`;
    const width = (a, b) => `${Math.max(0.6, ((dates.daysBetween(a, b) + 1) / span) * 100)}%`;
    const months = [];
    const cur = new Date(start.getFullYear(), start.getMonth(), 1);
    while (cur <= end) {
      const iso = dates.toISODate(cur);
      if (iso >= dates.toISODate(start)) months.push(h('span.fg-month', { style: { left: pos(iso) } }, dates.fmtMonthShort(iso.slice(0, 7))));
      cur.setMonth(cur.getMonth() + 1);
    }
    const crit = new Set(g.critical_path || []);
    const todayIn = g.today && g.today >= dates.toISODate(start) && g.today <= dates.toISODate(end);
    return h('div.fg', { attrs: { role: 'img', 'aria-label': 'Project Gantt' } },
      h('div.fg-head', h('div.fg-label.strong', 'WBS step'), h('div.fg-months', months)),
      rows.map((t) => h('div.fg-row',
        h('div.fg-label', { title: `${t.wbs_code} ${t.step}`, style: t.parent_id ? { 'padding-left': '24px' } : null }, `${t.wbs_code} ${t.step}`),
        h('div.fg-track',
          t.is_milestone
            ? h('span.fg-ms', { style: { left: pos(t.planned_start) }, title: `${t.step} · ${dates.fmtDate(t.planned_start)}` })
            : h(`span.fg-bar.ph-${t.phase || 'Development'}${showCritical && crit.has(t.id) ? '.crit' : ''}`, {
              style: { left: pos(t.planned_start), width: width(t.planned_start, t.planned_end), opacity: showCritical && !crit.has(t.id) ? '0.4' : null },
              title: `${t.wbs_code} ${t.step} · ${dates.fmtDate(t.planned_start)} to ${dates.fmtDate(t.planned_end)}`,
            }),
          todayIn ? h('span.fg-today', { style: { left: pos(g.today) }, title: `Today ${dates.fmtShort(g.today)}` }) : null))));
  }

  // ---------------------------------------------------------------- assemble
  const undoBtn = ui.btn('Undo last change', { variant: 'secondary', icon: '↶', onClick: () => { if (lastUndo) undoDates(lastUndo.id, lastUndo.start, lastUndo.end); } });
  function paintUndo() {
    ui.setDisabled(undoBtn, !lastUndo, 'No date change to undo.');
    if (lastUndo) undoBtn.title = `Put ${lastUndo.code} back to ${dates.fmtDate(lastUndo.start)} – ${dates.fmtDate(lastUndo.end)}`;
  }
  paintUndo();
  const SHOW_KEY = 'bmo.pg2.allColumns';
  let showAll = false;
  try { showAll = window.localStorage.getItem(SHOW_KEY) === '1'; } catch { /* storage unavailable */ }
  const colsBtn = ui.btn(showAll ? 'Fewer columns' : 'More columns', { variant: 'ghost', onClick: () => {
    showAll = !showAll;
    grid.el.classList.toggle('show-extra', showAll);
    colsBtn.lastChild.textContent = showAll ? 'Fewer columns' : 'More columns';
    try { window.localStorage.setItem(SHOW_KEY, showAll ? '1' : '0'); } catch { /* storage unavailable */ }
  }, title: 'Show or hide Alloc %, Depends on, SME/Owner and Description' });
  grid.el.classList.toggle('show-extra', showAll || print);
  const toolbarTop = print ? null : h('div.btn-row',
    undoBtn, colsBtn,
    ui.btn('+ Add step', { variant: 'secondary', onClick: () => addStep() }),
    ui.btn('Re-baseline', { variant: 'ghost', onClick: () => rebaseline(), title: 'Lock the current dates as the new baseline' }));

  root.append(ui.pageBox({ pg: 'PG 2', title: 'Project Plan', hint: '(WBS to be auto-populated from Change Summary)' },
    keyHost,
    reconHost,
    h('div.auto-row', genBtn, h('span.spacer'), toolbarTop),
    planSlot,
    grid.el,
    h('div.auto-row', ganttBtn, h('span.auto-hint', '(auto-populated from Project Plan)')),
    toolbar,
    ganttSlot,
    ganttHost));

  paintKeys();
  if (tasks.length) {
    api.getGantt(id).then((g) => {
      if (disposed) return;
      gantt = g;
      paintKeys();
      if (state.ganttShown(id) || print) showGantt(false);
    }).catch(() => {});
  } else {
    ui.mount(ganttHost, ui.emptyState({ icon: '▤', text: 'The Gantt view appears once the plan has steps with start and end dates.', cls: 'compact' }));
  }

  return () => {
    saveSoon.cancel();
    if (pending.size) api.bulkUpdateTasks(id, Array.from(pending.values())).catch(() => {});
    pending.clear();
    disposed = true;
    if (chart && typeof chart.destroy === 'function') { try { chart.destroy(); } catch { /* ignore */ } }
  };
}
