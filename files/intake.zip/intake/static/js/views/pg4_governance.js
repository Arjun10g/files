// views/pg4_governance.js: Pg 4 Change Governance (Excel two-block layout), validation attachments in
// yellow cells, Create CRQ draft (deterministic), Check CR Compliance (AI card), compliance list.
import { runAiFeature, runBuildStep } from '../ui/ai_card.js';
import { previewCompliance, componentName } from '../ui/previews.js';

const ATTACH_FIELDS = {
  tech_validation_attachment_id: { kind: 'tech_validation', label: 'technical validation evidence' },
  biz_validation_attachment_id: { kind: 'biz_validation', label: 'business validation evidence' },
  backout_attachment_id: { kind: 'backout_plan', label: 'backout plan' },
};

/** STO readiness text: B2's structured value when present; never "Tentative" next to an empty STO. */
export function stoReadinessText(cr, dates) {
  const c = (cr && cr.compliance) || {};
  const r = c.sto_readiness;
  if (c.sto_readiness_detail && c.sto_readiness_detail.label) return c.sto_readiness_detail.label;
  if (r && typeof r === 'object') return r.label || r.text || [r.status, r.note].filter(Boolean).join(' · ');
  if (c.sto_readiness_text) return c.sto_readiness_text;
  if (!cr || !cr.sto_approval) {
    const from = c.sto_auto_from || c.sto_suggest_from;
    return `Not requested${from ? ` · auto-suggest from ${dates.fmtDay(from, { withYear: true })}` : ''}`;
  }
  return typeof r === 'string' && r ? r : cr.sto_approval;
}

export async function render(root, params, ctx) {
  const { api, state, ui, dates, ws } = ctx;
  const { h } = ui;
  const id = params.id;
  const bundle = params.bundle;
  const ini = bundle.initiative;
  const print = Boolean(params.print);

  let crs = [];
  let attachments = bundle.attachments || [];
  let selectedId = params.query && params.query.crq ? Number(params.query.crq) : null;

  const body = h('div.pg4-body');
  const aiSlot = h('div.ai-slot', { hidden: true });
  const buildSlot = h('div.ai-slot', { hidden: true });
  const draftBtn = ui.autoBtn('Create CRQ draft', { onClick: () => createDraft() });
  const checkBtn = ui.autoBtn('Check CR Compliance', { onClick: () => checkCompliance() });
  const addBtn = ui.btn('+ Add change request', { variant: 'secondary', onClick: () => addManual() });

  root.append(ui.pageBox({ pg: 'PG 4', title: 'Change Governance', actions: print ? null : [draftBtn, checkBtn] }, buildSlot, aiSlot, body));

  async function load(selectId) {
    ui.mount(body, ui.skeleton({ lines: 6 }));
    try {
      const [res, att] = await Promise.all([api.listChangeRequests({ initiative_id: id }), api.listAttachments(id).catch(() => null)]);
      crs = res.items || [];
      if (att && att.items) attachments = att.items;
    } catch (err) {
      ui.mount(body, ui.errorPanel(err, { retry: () => load(selectId) }));
      return;
    }
    if (selectId) selectedId = selectId;
    if (!crs.find((c) => c.id === selectedId)) selectedId = crs.length ? crs[0].id : null;
    paint();
  }

  function current() { return crs.find((c) => c.id === selectedId) || null; }

  function paint() {
    ui.setDisabled(checkBtn, !current(), 'Create or add a change request first.');
    if (!crs.length) {
      ui.mount(body, ui.emptyState({
        icon: '⇄',
        text: 'No change request logged. Add the CRQ/RCSR # when the change is raised.',
        action: print ? null : h('div.btn-row', ui.autoBtn('Create CRQ draft', { onClick: () => createDraft() }), addBtn),
      }));
      return;
    }
    const picker = crs.length > 1 ? h('div.crq-tabs', crs.map((c) => ui.btn(c.crq_number || 'Draft change request', {
      variant: c.id === selectedId ? 'primary' : 'secondary', small: true, onClick: () => { selectedId = c.id; paint(); },
    }))) : null;
    ui.mount(body, picker || h('span'), crForm(current()));
  }

  function attachmentName(aid) {
    const a = attachments.find((x) => x.id === aid);
    return a ? a.filename : null;
  }

  function crForm(cr) {
    const form = {};
    const original = {};
    const dirty = new Set();
    const rows = {};
    const saveBtn = ui.btn('Save Pg 4', { variant: 'primary', onClick: () => save() });
    const discardBtn = ui.btn('Discard changes', { variant: 'secondary', onClick: () => paint() });
    const dirtyNote = h('span.dirty-note');
    ui.setDisabled(saveBtn, true, 'No changes to save.');
    ui.setDisabled(discardBtn, true);

    const setVal = (key, value) => {
      form[key] = value;
      const changed = JSON.stringify(value ?? null) !== JSON.stringify(original[key] ?? null);
      if (changed) dirty.add(key); else dirty.delete(key);
      (rows[key] || []).forEach((tr) => tr.classList.toggle('dirty', changed));
      dirtyNote.textContent = dirty.size ? `${dirty.size} unsaved change${dirty.size === 1 ? '' : 's'}` : '';
      ui.setDisabled(saveBtn, !dirty.size, 'No changes to save.');
      ui.setDisabled(discardBtn, !dirty.size);
    };
    const track = (key) => { form[key] = cr[key] ?? null; original[key] = cr[key] ?? null; };

    const sel = (key, category, extraOpts, placeholder = '—') => {
      track(key);
      const s = ui.selectEl(extraOpts || state.options(category), cr[key], { placeholder, ariaLabel: key });
      s.addEventListener('change', () => {
        setVal(key, s.value || null);
        document.querySelectorAll(`select[data-mirror="${key}"]`).forEach((m) => { if (m !== s) m.value = s.value; });
      });
      s.dataset.mirror = key;
      return s;
    };
    const text = (key, placeholder) => {
      track(key);
      const i = h('input.input', { type: 'text', value: cr[key] ?? '', placeholder: placeholder || null, aria: { label: key } });
      i.addEventListener('input', () => setVal(key, i.value.trim() || null));
      return i;
    };
    const dt = (key) => {
      track(key);
      const i = h('input.input', { type: 'datetime-local', value: dates.toLocalInput(cr[key]), aria: { label: key } });
      i.addEventListener('change', () => setVal(key, dates.fromLocalInput(i.value)));
      return ui.dateField(i, { placeholder: '—' });
    };
    const person = (key, team) => {
      track(key);
      const ro = state.lookups && state.lookups.role_options;
      const ids = ro && Array.isArray(ro[key]) ? ro[key].map(String) : null;
      const list = ids ? state.people().filter((p) => ids.includes(String(p.id))) : state.people(team ? { team } : {});
      const opts = (list.length ? list : state.people()).map((p) => ({ value: p.id, label: p.name }));
      if (cr[key] && !opts.some((o) => String(o.value) === String(cr[key])) && state.personName(cr[key])) opts.push({ value: cr[key], label: state.personName(cr[key]) });
      const s = ui.selectEl(opts, cr[key], { placeholder: '—', ariaLabel: key });
      s.addEventListener('change', () => setVal(key, s.value ? Number(s.value) : null));
      return s;
    };
    const list = (key) => {
      track(key);
      const arr = Array.isArray(cr[key]) ? cr[key] : [];
      const i = h('textarea.input.cis-input', { rows: Math.min(4, Math.max(2, Math.ceil(arr.join(', ').length / 34))), value: arr.join(', '), placeholder: 'Comma separated', aria: { label: key } });
      i.addEventListener('input', () => setVal(key, i.value.split(',').map((s) => s.trim()).filter(Boolean)));
      return i;
    };
    const compPicker = () => {
      track('impacted_components');
      const selected = new Set(Array.isArray(cr.impacted_components) ? cr.impacted_components : []);
      const codes = (bundle.components || []).map((c) => c.code);
      for (const c of selected) if (!codes.includes(c)) codes.push(c);
      if (!codes.length) return h('span.lv-text.muted', 'Add DC components on Pg 1');
      const wrap = h('div.chip-row', { style: { padding: '4px 0' } });
      for (const code of codes) {
        const cb = h('input', { type: 'checkbox', checked: selected.has(code) });
        cb.addEventListener('change', () => {
          if (cb.checked) selected.add(code); else selected.delete(code);
          setVal('impacted_components', codes.filter((c) => selected.has(c)));
        });
        wrap.appendChild(h('label.check.small', cb, componentName(code)));
      }
      return wrap;
    };
    const attachCell = (key) => {
      const meta = ATTACH_FIELDS[key];
      const input = h('input.visually-hidden', { type: 'file', accept: '.docx,.pdf,.md,.txt', tabIndex: -1 });
      const name = attachmentName(cr[key]);
      const btn = h('button.attach-btn', { type: 'button' }, name ? '⤓ Replace' : '⤓ Attach');
      btn.addEventListener('click', () => input.click());
      input.addEventListener('change', async () => {
        const file = input.files && input.files[0];
        input.value = '';
        if (!file) return;
        const problem = ui.checkFile(file);
        if (problem) { ui.toast(problem, { variant: 'warning' }); return; }
        const restore = ui.busy(btn, 'Attaching…');
        try {
          const res = await api.uploadAttachment(id, file, { kind: meta.kind, entity_type: 'change_request', entity_id: cr.id });
          const att = res.attachment || {};
          await api.updateChangeRequest(cr.id, { [key]: att.id });
          ui.toast(`${file.name} attached as ${meta.label}.`);
          await load(cr.id);
        } catch (err) {
          restore();
          ui.toastError(err);
        }
      });
      return h('div.attach-cell', input,
        name ? h('a.link', { href: api.attachmentDownloadUrl(cr[key]), download: '' }, name) : h('span.muted.small', 'Not attached'),
        print ? null : btn);
    };

    const trains = ((state.lookups && state.lookups.release_trains) || []).map((t) => ({ value: t.code, label: `${t.code} · ${dates.fmtDay(t.train_date, { withYear: true })}` }));
    const r = (key, label, value, extra = {}) => ({ key, label, value, ...extra });

    const left = ui.lvGrid([
      [
        r('crq_number', 'CRQ/RCSR #', text('crq_number', 'CRQ##########')),
        r('crq_start', 'CRQ Start Date and Time', dt('crq_start')),
        r('crq_end', 'CRQ End Date and Time', dt('crq_end')),
        r('release_type', 'Release Type', sel('release_type', 'release_type')),
        r('release_train', 'Release Train/Sprint', sel('release_train', null, trains)),
      ],
      [
        r('affected_cis', 'Affected CIs', list('affected_cis')),
        r('target_release', 'Target Release', sel('target_release', null, trains)),
        r('impacted_components', 'Impacted Component', compPicker()),
        r('implementation_status', 'Implementation Status', sel('implementation_status', 'implementation_status')),
        r('crq_approval_status', 'CRQ Approval Status', sel('crq_approval_status', 'crq_approval_status')),
      ],
      [
        r('sto_approval', 'STO Approval', sel('sto_approval', 'sto_approval', null, 'Not requested')),
      ],
    ]);
    const right = ui.lvGrid([
      [
        r('cms_lead_id', 'CMS Lead', person('cms_lead_id', 'Change')),
        r('rel_lead_id', 'Rel Lead', person('rel_lead_id', 'Release')),
        r('resource_id', 'Resource', person('resource_id')),
      ],
      [
        r('tech_validation_status', 'Technical Validation Status', sel('tech_validation_status', 'validation_status')),
        r('tech_validation_attachment_id', 'Technical validation evidence', attachCell('tech_validation_attachment_id'), { cls: 'lv-auto' }),
        r('biz_validation_status', 'Business Validation Status', sel('biz_validation_status', 'validation_status')),
        r('biz_validation_attachment_id', 'Business validation evidence', attachCell('biz_validation_attachment_id'), { cls: 'lv-auto' }),
      ],
      [
        r('backout_attachment_id', 'Backout plan', attachCell('backout_attachment_id'), { cls: 'lv-auto' }),
      ],
    ]);
    for (const tr of [...left.querySelectorAll('tr[data-key]'), ...right.querySelectorAll('tr[data-key]')]) {
      (rows[tr.dataset.key] = rows[tr.dataset.key] || []).push(tr);
    }

    async function save() {
      if (!dirty.size) return;
      if (form.crq_start && form.crq_end && form.crq_end <= form.crq_start) {
        (rows.crq_end || []).forEach((tr) => tr.classList.add('invalid'));
        ui.toast('CRQ end must be after the start.', { variant: 'warning' });
        return;
      }
      const patch = {};
      for (const k of dirty) patch[k] = form[k];
      const restore = ui.busy(saveBtn, 'Saving…');
      try {
        await api.updateChangeRequest(cr.id, patch);
        ui.toast('Pg 4 saved.');
        await load(cr.id);
      } catch (err) {
        restore();
        if (err && err.details && err.details.fields) {
          for (const k of Object.keys(err.details.fields)) (rows[k] || []).forEach((tr) => { tr.classList.add('invalid'); tr.title = err.details.fields[k]; });
        }
        ui.toastError(err);
      }
    }

    async function remove() {
      const ok = await ui.confirmModal({
        title: `Delete ${cr.crq_number || 'this change request'}?`,
        message: 'The change request and its compliance check will be removed from this initiative.',
        confirmLabel: 'Delete change request', danger: true,
      });
      if (!ok) return;
      try {
        await api.deleteChangeRequest(cr.id);
        ui.toast(`${cr.crq_number || 'Change request'} deleted.`);
        selectedId = null;
        await load();
      } catch (err) {
        ui.toastError(err);
      }
    }

    const comp = cr.compliance || { ok: null, flags: [] };
    const allFlags = comp.flags || [];
    const notDue = [
      ...(Array.isArray(comp.findings) ? comp.findings : []).filter((f) => f.status === 'Not due yet'),
      ...allFlags.filter((f) => f.status === 'Not due yet'),
    ].map((f) => ({ ...f, message: f.message || f.rule || f.code, due_date: f.due_date }));
    const flags = allFlags.filter((f) => f.status !== 'Not due yet');
    const complianceBox = h(`div.compliance.${flags.length ? 'bad' : 'ok'}`,
      h('div.compliance-title', flags.length ? `⚠ ${flags.length} item${flags.length === 1 ? '' : 's'} need${flags.length === 1 ? 's' : ''} attention` : '✓ Meets the change standards'),
      flags.length ? h('ul.ai-list', flags.map((f) => h('li', f.message || f.code))) : h('div.small.muted', notDue.length ? 'Nothing is failing today.' : 'Window, approvals and validation evidence are in place.'),
      h('div.small', { style: { 'margin-top': '6px' } }, h('strong', 'STO readiness: '), stoReadinessText(cr, dates)),
      notDue.length ? h('div.notdue-list', h('div.strong', `Not due yet (${notDue.length})`),
        h('ul.ai-list', notDue.map((f) => h('li', f.message || f.code, f.due_date ? ` · due by ${dates.fmtDay(f.due_date, { withYear: true })}` : '')))) : null);

    const review = comp.ai || null;
    const reviewBox = review ? h('div.compliance.review',
      h('div.compliance-title', '✦ Saved compliance review ', ui.aiTag('AI')),
      h('div.small', [
        typeof review.score === 'number' ? `Score ${dates.fmtPct(review.score)}` : null,
        review.sto_readiness ? `STO readiness: ${review.sto_readiness}` : null,
      ].filter(Boolean).join(' · ')),
      review.reviewer_note ? h('p.small', { style: { margin: '6px 0 0' } }, review.reviewer_note) : null,
      (review.reviewed_by || review.reviewed_at)
        ? h('div.small.muted', `Reviewed${review.reviewed_by ? ` by ${review.reviewed_by}` : ''}${review.reviewed_at ? ` on ${dates.fmtDateTime(review.reviewed_at)}` : ''}`)
        : null) : null;

    return h('div.cr-form',
      h('div.excel-cols', h('div.col-left', left), h('div.col-right', right, complianceBox, reviewBox)),
      cr.source === 'ai' || cr.source === 'derived' ? h('p.small.muted', { style: { 'margin-top': '8px' } }, 'Drafted from the plan · review the window and CIs before submitting.') : null,
      print ? null : h('div.page-footer',
        ui.btn('Delete change request', { variant: 'danger-text', onClick: () => remove() }),
        addBtn, dirtyNote, discardBtn, saveBtn));
  }

  async function createDraft() {
    let draft;
    try {
      draft = await runBuildStep(buildSlot, 'Building CRQ draft from the plan…',
        () => api.request('POST', `/initiatives/${id}/change-requests/draft`, { body: { dry_run: true } }));
      buildSlot.hidden = true;
    } catch (err) {
      buildSlot.hidden = true;
      ui.toastError(err);
      return;
    }
    if (draft && draft.dry_run === false && draft.id) {
      ui.toast(`${draft.crq_number || 'The CRQ draft'} already exists for this initiative.`, { variant: 'info' });
      await load(draft.id);
      return;
    }
    const when = draft.crq_start ? `${dates.fmtDay(draft.crq_start, { withYear: true })} ${dates.fmtTime(draft.crq_start)}–${dates.fmtTime(draft.crq_end)}` : '—';
    const flagsNow = ((draft.compliance && draft.compliance.flags) || []).filter((f) => f.status !== 'Not due yet');
    const body = h('div',
      h('p.small.muted', 'Built from the plan: window on the target train, CIs from the DC components. Review before adding it to Pg 4.'),
      ui.lvGrid([[
        { label: 'CRQ/RCSR #', value: draft.crq_number || 'Assigned when raised in Remedy' },
        { label: 'Change window', value: when },
        { label: 'Release Type', value: ui.txt(draft.release_type) },
        { label: 'Release Train/Sprint', value: ui.txt(draft.release_train) },
        { label: 'Affected CIs', value: h('span.lv-text.wrap', (draft.affected_cis || []).join(', ') || '—') },
        { label: 'Impacted Component', value: h('span.lv-text.wrap', (draft.impacted_components || []).map((c) => componentName(c)).join(', ') || '—') },
        { label: 'STO Approval', value: draft.sto_approval || 'Not requested' },
      ]]),
      flagsNow.length ? h('div.notice.notice-amber', { style: { 'margin-top': '12px' } }, `${flagsNow.length} item${flagsNow.length === 1 ? ' needs' : 's need'} attention: `, flagsNow.map((f) => f.message || f.code).join(' · ')) : null);
    ui.openModal({
      title: 'Review CRQ draft',
      body,
      width: 620,
      actions: [
        { label: 'Discard', variant: 'ghost', onClick: () => { ui.toast('CRQ draft discarded.', { variant: 'info' }); } },
        {
          label: 'Accept', variant: 'primary',
          onClick: async () => {
            try {
              const cr = await api.createCrqDraft(id);
              ui.toast(`${cr.crq_number || 'CRQ'} drafted · window ${when}${cr.sto_approval ? ` · STO ${cr.sto_approval}` : ' · STO not requested yet'}.`);
              state.emit('ai:applied', { feature: 'crq_draft' });
              await load(cr.id);
            } catch (err) {
              ui.toastError(err);
              return false;
            }
            return true;
          },
        },
      ],
    });
  }

  async function addManual() {
    try {
      const cr = await api.createChangeRequest(id, { release_type: 'Bundle', target_release: ini.target_release || null, release_train: ini.target_release || null });
      ui.toast('Change request added. Fill in the CRQ/RCSR # when it is raised.', { variant: 'info' });
      await load(cr.id);
    } catch (err) {
      const fields = err && err.details && err.details.fields;
      if (fields && Object.keys(fields).length) {
        const LABELS = { target_release: 'Target Release', release_train: 'Release Train/Sprint', release_type: 'Release Type', crq_number: 'CRQ/RCSR #' };
        const lines = Object.entries(fields).map(([k, msg]) => `${LABELS[k] || k.replace(/_/g, ' ')}: ${msg}`);
        ui.mount(buildSlot, h('div.notice.notice-amber', { attrs: { role: 'alert' } },
          h('strong', 'The change request could not be added. '), lines.join(' · '),
          ini.target_release ? null : h('span', ' Set the Target Release on Pg 1 first.')));
        buildSlot.hidden = false;
        ui.toast(lines[0], { variant: 'warning' });
      } else {
        ui.toastError(err);
      }
    }
  }

  function checkCompliance() {
    const cr = current();
    if (!cr) { ui.toast('Create or add a change request first.', { variant: 'info' }); return; }
    runAiFeature({
      feature: 'cr_compliance', initiativeId: id, container: aiSlot, trigger: checkBtn,
      title: `CR Compliance · ${cr.crq_number || 'draft'}`,
      body: { options: { change_request_id: cr.id } },
      renderPreview: (out, pctx) => previewCompliance(out, pctx, { stoText: stoReadinessText(cr, dates) }), editable: false,
      acceptLabel: 'Save review',
      acceptMessage: () => 'Compliance review saved to the change request · shown on Pg 4.',
      onApplied: async () => { await load(cr.id); ws.reloadBundle().catch(() => {}); },
    });
  }

  await load(selectedId);
}
