// views/artifacts_tab.js: this initiative's documents (incl. SA document download), decision log and
// meeting notes. The portfolio-wide repository is the Artifacts page.

export async function render(root, params, ctx) {
  const { api, state, ui, dates, navigate } = ctx;
  const { h } = ui;
  const id = params.id;
  const ini = params.bundle.initiative;
  const print = Boolean(params.print);

  const docsHost = h('div');
  const decHost = h('div');
  const notesHost = h('div');

  const KIND_LABEL = {
    sa_doc: 'SA document', tech_validation: 'Technical validation', biz_validation: 'Business validation',
    backout_plan: 'Backout plan', meeting_notes: 'Meeting notes', other: 'Other',
  };

  async function loadDocs() {
    ui.mount(docsHost, ui.loadingLine());
    try {
      const [att, docs] = await Promise.all([api.listAttachments(id), api.listArtifacts('documents', { initiative_id: id })]);
      const files = att.items || [];
      const docRows = docs.items || [];
      const linked = new Set(docRows.map((d) => d.attachment_id).filter(Boolean));
      const rows = [
        ...docRows.map((d) => ({
          title: d.title, type: d.doc_type, version: d.version, status: d.status,
          when: d.updated_at, href: d.attachment_id ? api.attachmentDownloadUrl(d.attachment_id) : null, by: d.owner_name,
          sa: d.doc_type === 'SA',
        })),
        ...files.filter((f) => !linked.has(f.id)).map((f) => ({
          title: f.filename, type: KIND_LABEL[f.kind] || 'Other', version: f.version, status: null,
          when: f.uploaded_at, href: api.attachmentDownloadUrl(f.id), by: f.uploaded_by, size: f.size_bytes,
          sa: f.id === ini.sa_doc_attachment_id,
        })),
      ];
      const table = rows.length ? h('table.table',
        h('thead', h('tr', h('th', 'Document'), h('th', 'Type'), h('th', 'Version'), h('th', 'Status'), h('th', 'Added by'), h('th', 'Updated'), h('th', ''))),
        h('tbody', rows.map((r) => h('tr',
          h('td', h('span.strong', r.title), r.sa ? h('span.chip.chip-blue', { style: { 'margin-left': '6px' } }, 'SA document') : null,
            r.size ? h('span.muted.small', ` · ${ui.fmtFileSize(r.size)}`) : null),
          h('td', ui.txt(r.type)), h('td', ui.txt(r.version)), h('td', r.status ? ui.statusPill(r.status) : '—'),
          h('td', ui.txt(r.by)), h('td', dates.fmtDateTime(r.when)),
          h('td', r.href ? h('a.link', { href: r.href, download: '' }, 'Download') : h('span.muted', '—'))))))
        : null;
      const dz = print ? null : ui.dropzone({
        label: 'Drop files here or Browse', hint: 'Adds the file to this initiative · PDF · DOCX · MD · TXT', compact: true,
        onFile: async (file) => {
          await api.uploadAttachment(id, file, { kind: 'other' });
          ui.toast(`${file.name} added to ${ini.rddc}.`);
          setTimeout(loadDocs, 50);
          return null;
        },
      });
      ui.mount(docsHost, 
        table || ui.emptyState({ icon: '▤', text: 'No documents yet. Drop files here to add them to this initiative.', cls: 'compact' }),
        dz ? h('div', { style: { 'margin-top': '12px' } }, dz.el) : null);
    } catch (err) {
      ui.mount(docsHost, ui.errorPanel(err, { retry: loadDocs }));
    }
  }

  async function loadDecisions() {
    ui.mount(decHost, ui.loadingLine());
    try {
      const res = await api.listArtifacts('decisions', { initiative_id: id });
      const items = (res.items || []).slice().sort((a, b) => dates.compareISO(b.decided_on || b.created_at, a.decided_on || a.created_at));
      ui.mount(decHost, items.length ? h('table.table',
        h('thead', h('tr', h('th', 'Date'), h('th', 'Decision'), h('th', 'By'), h('th', 'Status'), h('th', 'Source'))),
        h('tbody', items.map((d) => h('tr',
          h('td', dates.fmtDate(d.decided_on || d.created_at)),
          h('td', h('div.strong', d.title), h('div.small', d.decision), d.context ? h('div.small.muted', d.context) : null),
          h('td', ui.txt(d.decided_by)), h('td', ui.statusPill(d.status)),
          h('td', d.source === 'ai' ? ui.aiTag('AI') : d.source === 'system' ? h('span.muted.small', 'Automatic') : h('span.muted.small', 'Manual'))))))
        : ui.emptyState({ icon: '✓', text: 'No decisions logged yet. L2 approvals, re-baselines and STO calls are logged here automatically.', cls: 'compact' }));
    } catch (err) {
      ui.mount(decHost, ui.errorPanel(err, { retry: loadDecisions }));
    }
  }

  async function addDecision() {
    const values = await ui.promptModal({
      title: 'Log a decision',
      fields: [
        { name: 'title', label: 'Title', required: true },
        { name: 'decision', label: 'Decision', type: 'textarea', rows: 3, required: true },
        { name: 'context', label: 'Context', type: 'textarea', rows: 2 },
        { name: 'decided_by', label: 'Decided by', value: state.persona() === 'DC PM' ? (ini.dc_pm_name || '') : '' },
      ],
      submitLabel: 'Log decision',
    });
    if (!values) return;
    try {
      await api.createArtifact('decisions', {
        initiative_id: id, title: values.title, decision: values.decision, context: values.context || null,
        decided_by: values.decided_by || null, decided_on: params.bundle.today, status: 'Approved', source: 'manual',
      });
      ui.toast('Decision logged.');
      loadDecisions();
    } catch (err) {
      ui.toastError(err);
    }
  }

  async function loadNotes() {
    ui.mount(notesHost, ui.loadingLine());
    try {
      const res = await api.listArtifacts('meeting-notes', { initiative_id: id });
      const items = res.items || [];
      ui.mount(notesHost, items.length ? h('div.stack', items.map((n) => {
        const actions = Array.isArray(n.action_items_json) ? n.action_items_json : [];
        return h('details.card', h('summary.card-head', { style: { cursor: 'pointer' } },
          h('span.strong', n.title), h('span.muted.small', `${dates.fmtDate(n.meeting_date)}${(n.attendees || []).length ? ` · ${n.attendees.length} attendees` : ''}`)),
        h('div.card-body',
          (n.attendees || []).length ? h('p.small.muted', `Attendees: ${n.attendees.join(', ')}`) : null,
          h('div.ai-text.small', ui.txt(n.notes_md, 'No notes recorded.')),
          actions.length ? h('div.ai-block', h('div.ai-block-title', 'Actions'), h('ul.ai-list', actions.map((a) => h('li', ui.txt(a.action, ''), a.owner ? h('span.muted', ` · ${a.owner}`) : null, a.due ? h('span.muted', ` · by ${dates.fmtDate(a.due)}`) : null)))) : null));
      })) : ui.emptyState({ icon: '✎', text: 'No meeting notes for this initiative yet. Add notes on the Artifacts page and extract actions from them.', cls: 'compact' }));
    } catch (err) {
      ui.mount(notesHost, ui.errorPanel(err, { retry: loadNotes }));
    }
  }

  root.append(ui.pageBox({
    title: 'Artifacts', hint: `Documents, decisions and meeting notes for ${ini.rddc}`,
    actions: print ? null : [ui.btn('Open Artifacts page', { variant: 'secondary', onClick: () => navigate('#/artifacts') })],
  },
  h('div.section-title', 'Document Repository'), docsHost,
  h('div.section-title', 'Decision Log', print ? null : ui.btn('+ Log decision', { variant: 'ghost', small: true, onClick: () => addDecision() })), decHost,
  h('div.section-title', 'Meeting Notes'), notesHost));

  await Promise.allSettled([loadDocs(), loadDecisions(), loadNotes()]);
}
