// views/initiative.js: initiative workspace = header (RDDC, name, RAG, stage) + 5-step stepper (navigation)
// + tabs Pg 1–Pg 5 · Risks · Artifacts, Print view (all pages stacked) and an activity footer.

const TABS = [
  { key: 'pg1', label: 'Pg 1 General Details', module: 'pg1_general', title: 'Pg 1 General Details' },
  { key: 'pg2', label: 'Pg 2 Project Plan', module: 'pg2_plan', title: 'Pg 2 Project Plan' },
  { key: 'pg3', label: 'Pg 3 Resource Management', module: 'pg3_resources', title: 'Pg 3 Resource Management' },
  { key: 'pg4', label: 'Pg 4 Change Governance', module: 'pg4_governance', title: 'Pg 4 Change Governance' },
  { key: 'pg5', label: 'Pg 5 Portfolio View', module: 'pg5_portfolio', title: 'Pg 5 Portfolio View' },
  { key: 'risks', label: 'Risks', module: 'risks_tab', title: 'Risks' },
  { key: 'artifacts', label: 'Artifacts', module: 'artifacts_tab', title: 'Artifacts' },
];

const SCORED_STAGES = ['Planning', 'Build', 'QA', 'Release', 'Closed'];

export function overallRag(initiative, health) {
  if (health && health.scored === false) return null;
  if (health && health.overall) return health.overall;
  if (!initiative || !SCORED_STAGES.includes(initiative.stage)) return null;
  return initiative.rag_cached || null;
}

export async function render(root, params, ctx) {
  const { api, state, ui, dates, navigate } = ctx;
  const { h } = ui;
  const id = params.id;
  const tabKey = params.tab || 'pg1';
  const isPrint = tabKey === 'print';
  const tabDef = TABS.find((t) => t.key === tabKey) || TABS[0];
  let cleanups = [];
  let disposed = false;

  await state.loadLookups().catch(() => null);

  let bundle;
  try {
    bundle = await api.getInitiative(id);
  } catch (err) {
    if (err && err.status === 404) {
      state.forgetInitiative(id);
      root.append(h('div.view-pad', ui.pageBox({ title: 'Edit Initiative' }, ui.emptyState({
        icon: '⌕', text: 'This initiative no longer exists. It may have been removed by a demo reset.',
        action: { label: 'Search Initiative', variant: 'primary', onClick: () => navigate('#/search') },
      }))));
      return undefined;
    }
    throw err;
  }

  const ini = bundle.initiative;
  let health = ini.health_cached_json || null;
  state.setCurrent({ initiativeId: id, rddc: ini.rddc, name: ini.name, tab: tabKey, page: isPrint ? 'Print view' : tabDef.title });
  document.title = `${ini.rddc} · ${isPrint ? 'Print view' : tabDef.title} · Digital Channels · Project Management Tool`;

  // ---------------------------------------------------------------- header
  const ragHost = h('span.ws-rag');
  const stageHost = h('span.ws-stage');
  const metaHost = h('div.ws-meta');
  const stepHost = h('div.ws-stepper');

  function paintHeader(prevRag) {
    const rag = overallRag(ini, health);
    const pill = ui.ragPill(rag, { size: 'lg', title: rag ? 'Overall health · see Pg 3 for the five dimensions' : undefined });
    if (prevRag !== undefined && prevRag !== rag) pill.classList.add('pill-pulse');
    ui.mount(ragHost, pill);
    ui.mount(stageHost, h('span.muted', 'Stage: '), h('b', ui.txt(ini.stage)));
    ui.mount(metaHost, 
      h('span', 'LOB ', h('b', ui.txt(ini.lob))),
      h('span', 'DC PM ', h('b', ui.txt(ini.dc_pm_name))),
      h('span', 'Target Release ', h('b', ui.txt(ini.target_release))),
      h('span', 'Priority ', h('b', ini.priority ? state.label('priority', ini.priority) || `P${ini.priority}` : '—')),
      ini.updated_at ? h('span.muted', `Last saved ${dates.fmtDateTime(ini.updated_at)}`) : null,
    );
    paintStepper();
  }

  function paintStepper() {
    const tasks = bundle.tasks || [];
    const parents = new Set(tasks.map((t) => t.parent_id).filter(Boolean));
    const leaves = tasks.filter((t) => !(parents.has(t.id) && !(Number(t.est_hours) > 0)) && !t.is_milestone);
    const allAssigned = leaves.length > 0 && leaves.every((t) => t.resource_id);
    const done = [
      true,
      (bundle.components || []).length > 0,
      tasks.length > 0,
      tasks.length > 0 && allAssigned && state.ganttShown(id),
      tasks.length > 0 && state.visited(id, 'pg5'),
    ];
    ui.mount(stepHost, ui.stepper(done, {
      hrefs: {
        intake: `#/initiative/${id}/pg1`,
        dc: `#/initiative/${id}/pg1?focus=change-summary`,
        wbs: `#/initiative/${id}/pg2`,
        resource: `#/initiative/${id}/pg3`,
        views: `#/initiative/${id}/pg5`,
      },
    }));
  }

  const ws = {
    id,
    get bundle() { return bundle; },
    get initiative() { return ini; },
    get health() { return health; },
    /** Merge an updated initiative row into the header. */
    updateInitiative(next) {
      if (!next) return;
      const prev = overallRag(ini, health);
      Object.assign(ini, next);
      state.setCurrent({ rddc: ini.rddc, name: ini.name });
      paintHeader(prev);
    },
    /** New health (from a grid save, L2 approval or AI apply): repaint the RAG pill (pulses if changed). */
    setHealth(next) {
      if (!next) return;
      const prev = overallRag(ini, health);
      health = next;
      ini.health_cached_json = next;
      if (next.overall) ini.rag_cached = next.overall;
      paintHeader(prev);
    },
    /** Re-fetch the bundle; returns it. Header repaints. */
    async reloadBundle() {
      const prev = overallRag(ini, health);
      const fresh = await api.getInitiative(id);
      Object.assign(ini, fresh.initiative);
      fresh.initiative = ini;
      bundle = fresh;
      health = ini.health_cached_json || health;
      paintHeader(prev);
      return bundle;
    },
    /** Re-render the current tab with a fresh bundle (keeps the scroll position). */
    async reload() {
      const y = window.scrollY;
      await ws.reloadBundle();
      await renderTab();
      window.scrollTo(0, y);
    },
    goTab(key) { navigate(`#/initiative/${id}/${key}`); },
  };

  const header = h('div.ws-header',
    h('div.ws-title-row',
      h('span.ws-rddc', ini.rddc), h('span.ws-sep', '·'), h('h1.ws-name', ini.name),
      ragHost, stageHost,
      h('div.ws-actions.no-print',
        ui.btn('Ask about this initiative', { variant: 'secondary', icon: '✦', onClick: () => ctx.openAssistant({ initiativeId: id }) }),
        h('a.btn.btn-secondary', { href: api.exportDemoViewUrl(id), download: '', title: 'Download the Demo View workbook for this initiative' }, 'Initiative Demo View workbook'),
        isPrint
          ? ui.btn('Back to tabs', { variant: 'secondary', onClick: () => navigate(`#/initiative/${id}/pg1`) })
          : ui.btn('Print view', { variant: 'secondary', onClick: () => navigate(`#/initiative/${id}/print`) }))),
    metaHost,
    stepHost,
    isPrint ? null : ui.tabsBar(TABS.map((t) => ({ key: t.key, label: t.label, href: `#/initiative/${id}/${t.key}` })), tabKey));

  const body = h('div.ws-body');
  const persistent = [];
  persistent.push(state.on('visited', (v) => { if (v && String(v.initiativeId) === String(id)) paintStepper(); }));
  if (tabKey === 'pg5') state.markVisited(id, 'pg5');
  const activity = activityFooter();
  root.append(header, body, activity);
  paintHeader();

  const wsCtx = { ...ctx, ws, bundle };

  async function renderTab() {
    for (const fn of cleanups) { try { fn(); } catch { /* ignore */ } }
    cleanups = [];
    wsCtx.bundle = bundle;
    if (isPrint) {
      const stack = h('div.print-stack');
      ui.mount(body, stack);
      for (const t of TABS.slice(0, 5)) {
        const slot = h('div.print-slot', { dataset: { tab: t.key } });
        stack.appendChild(slot);
        await mountTab(t, slot, true);
      }
      return;
    }
    const slot = h('div.tab-slot');
    ui.mount(body, slot);
    await mountTab(tabDef, slot, false);
  }

  async function mountTab(t, slot, print) {
    const mod = await ctx.loadModule(`views/${t.module}.js`);
    if (disposed) return;
    if (!mod || typeof mod.render !== 'function') {
      ui.mount(slot, ui.pageBox({ pg: t.key.startsWith('pg') ? `PG ${t.key.slice(2)}` : null, title: t.title },
        ui.emptyState({ icon: '◷', text: 'This page is being prepared.' })));
      return;
    }
    try {
      const cleanup = await mod.render(slot, {
        id, initiativeId: id, tab: t.key, scope: 'initiative', print, bundle, query: params.query || {},
      }, wsCtx);
      if (typeof cleanup === 'function') cleanups.push(cleanup);
    } catch (err) {
      ui.mount(slot, ui.errorPanel(err, { title: `${t.title} could not be loaded`, retry: () => ws.reload() }));
    }
  }

  function activityFooter() {
    const list = h('div.activity-body');
    const det = h('details.activity-foot.no-print', h('summary', 'Activity on this initiative'), list);
    let loaded = false;
    det.addEventListener('toggle', async () => {
      if (!det.open || loaded) return;
      loaded = true;
      ui.mount(list, ui.loadingLine());
      try {
        const res = await api.listActivity({ initiative_id: id, limit: 20 });
        const items = res.items || [];
        if (!items.length) { ui.mount(list, h('p.muted', 'No activity recorded yet.')); return; }
        ui.mount(list, h('ul.activity-list', items.map((a) => h('li',
          h('span.activity-time', dates.fmtDateTime(a.ts)),
          h('span', ui.txt(a.summary || a.action)),
          h('span.muted', ` · ${ui.txt(a.actor, '')}${a.persona ? ` (${a.persona})` : ''}`)))));
      } catch (err) {
        loaded = false;
        ui.mount(list, ui.errorPanel(err));
      }
    });
    persistent.push(state.on('ai:applied', () => { loaded = false; if (det.open) { det.open = false; } }));
    return det;
  }

  await renderTab();

  return () => {
    disposed = true;
    for (const fn of [...cleanups, ...persistent]) { try { fn(); } catch { /* ignore */ } }
  };
}
