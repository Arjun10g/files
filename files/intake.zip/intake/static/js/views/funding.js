import { api, h, clear, card, dataTable, button, pageHeader, errorBox, loading, emptyState, fmtMonth, fmtHours, fmtNum, getLookups, getToday, itemsOf, toast, num, framePage, chip, announceChange } from '../charts/kit.js';
import { renderBurndown } from '../charts/burndown.js';
import { field, editor, removeItem, metric, meter, rowActions, money } from './operation_helpers.js';

const decisions = ['Pending', 'Approved', 'Rejected', 'Delayed'];
const phases = ['Planning', 'Development', 'Support'];
const options = (items) => items.map((value) => ({ value, label: value }));
const path = (code, suffix = '') => `/funding/${encodeURIComponent(code)}${suffix}`;

export async function render(root, params, ctx) {
  const page = framePage(root, 'funding'), body = h('div', { class: 'op-content' });
  let budgets = [], people = [], initiatives = [], lookups = {}, today = '', selected = params.query?.prn || '', currency = '', lob = '', decision = '', query = '', disposed = false, chart = null, detailToken = 0;
  page.append(pageHeader({ title: 'Funding', hint: 'Budgets, component estimates and monthly actuals in one place.', actions: [h('a', { class: 'btn btn-secondary', href: '#/imports?type=funding', text: 'Import funding' }), button('Add budget', () => editBudget(), { kind: 'primary' })] }), body);
  await reload();

  async function reload() {
    body.replaceChildren(loading('Loading funding…'));
    try {
      const results = await Promise.all([api.request('GET', '/funding'), api.listResources(), api.listInitiatives(), getLookups(ctx), getToday(ctx)]);
      if (disposed) return;
      budgets = itemsOf(results[0]); people = itemsOf(results[1]); initiatives = itemsOf(results[2]); lookups = results[3]; today = results[4]; draw();
    } catch (err) { if (!disposed) body.replaceChildren(errorBox(err, reload)); }
  }
  async function changed(message) { toast(message); announceChange(null, 'funding', ctx); await reload(); }
  function teardownChart() { detailToken += 1; if (chart) { chart.destroy(); chart = null; } }
  function draw() {
    if (disposed) return; teardownChart(); clear(body);
    const budget = budgets.find((b) => b.prn_code === selected);
    if (budget) drawDetail(budget); else { selected = ''; drawOverview(); }
  }
  function drawOverview() {
    const toolbar = h('div', { class: 'op-toolbar' });
    const filters = [
      { name: 'currency', label: 'Currency', value: currency, options: [{ value: '', label: 'All currencies' }, ...options([...new Set(budgets.map((b) => b.currency))].sort())], set: (v) => { currency = v; } },
      { name: 'lob', label: 'Line of business', value: lob, options: [{ value: '', label: 'All lines of business' }, ...options([...new Set(budgets.map((b) => b.lob).filter(Boolean))].sort())], set: (v) => { lob = v; } },
      { name: 'decision', label: 'Decision', value: decision, options: [{ value: '', label: 'All decisions' }, ...options(decisions)], set: (v) => { decision = v; } },
    ];
    filters.forEach((f) => { const c = field({ ...f, type: 'select' }); c.input.addEventListener('change', () => { f.set(c.input.value); draw(); }); toolbar.appendChild(c.el); });
    const search = field({ name: 'search', label: 'Find funding', value: query, placeholder: 'PRN, budget or owner', type: 'search' }); search.el.classList.add('op-search'); search.input.addEventListener('change', () => { query = search.input.value; draw(); }); toolbar.appendChild(search.el);
    const rows = budgets.filter((b) => (!currency || b.currency === currency) && (!lob || b.lob === lob) && (!decision || (b.decision || 'Pending') === decision) && (!query || `${b.prn_code} ${b.name} ${b.owner_name || ''}`.toLowerCase().includes(query.toLowerCase())));
    const currencies = [...new Set(rows.map((r) => r.currency))], single = currencies.length <= 1, cur = currencies[0] || 'CAD';
    const total = (key) => rows.reduce((sum, b) => sum + num(b.totals?.[key]), 0);
    body.append(h('div', { class: 'op-metrics' }, metric('Funding budgets', fmtNum(rows.length), `${rows.filter((b) => b.decision === 'Approved').length} approved`), metric('Budget amount', single ? money(total('budget_amount'), cur) : 'By currency', `${fmtHours(total('funded_hours'))} funded`), metric('Actual spend', single ? money(total('charged_amount'), cur) : 'By currency', `${fmtHours(total('charged_hours'))} charged`), metric('Budget remaining', single ? money(total('remaining_amount'), cur) : 'By currency', `${fmtHours(total('remaining_hours'))} remaining`, total('remaining_hours') < 0 ? 'over' : '')), toolbar);
    if (!single) body.appendChild(h('div', { class: 'op-currency-note', text: 'Select one currency to see combined monetary totals. Each budget below is shown in its own currency.' }));
    if (!budgets.length) { body.appendChild(emptyState('No funding has been loaded. Import the funding workbook or enter your first budget.', button('Add first budget', () => editBudget(), { kind: 'primary' }))); return; }
    const table = card('Funding register');
    table.body.appendChild(dataTable({ columns: [
      { key: 'prn_code', label: 'Funding', render: (b) => h('div', {}, button(b.prn_code, () => { selected = b.prn_code; draw(); }, { kind: 'text', small: true }), h('span', { class: 'op-secondary', text: b.name }), b.intake_draft ? chip('Intake draft', 'amber') : null) },
      { key: 'lob', label: 'Line of business', render: (b) => h('div', {}, b.lob || '—', h('span', { class: 'op-secondary', text: `${b.charge_type || 'Project'}${b.owner_name ? ` · ${b.owner_name}` : ''}` })) },
      { key: 'decision', label: 'Decision', render: (b) => decisionChip(b.decision) },
      { key: 'budget', label: 'Budget', align: 'right', sort: (b) => num(b.totals?.budget_amount), render: (b) => h('div', {}, h('span', { class: 'op-funding-amount', text: money(b.totals.budget_amount, b.currency) }), h('span', { class: 'op-secondary', text: fmtHours(b.funded_hours) })) },
      { key: 'actuals', label: 'Actuals', align: 'right', sort: (b) => num(b.totals?.charged_amount), render: (b) => h('div', {}, money(b.totals.charged_amount, b.currency), h('span', { class: 'op-secondary', text: fmtHours(b.totals.charged_hours) })) },
      { key: 'spent', label: 'Budget used', render: (b) => meter(b.totals.charged_amount, b.totals.budget_amount, { label: `${Math.round(num(b.totals.utilization_pct))}% · ${b.initiatives?.length || 0} initiative${b.initiatives?.length === 1 ? '' : 's'}` }) },
      { key: 'actions', label: '', sortable: false, render: (b) => rowActions(button('Open', () => { selected = b.prn_code; draw(); }, { kind: 'text', small: true }), button('Edit', () => editBudget(b), { kind: 'text', small: true })) },
    ], rows, caption: 'Funding budgets', empty: 'No funding matches these filters.', dense: true }).el); body.appendChild(table.el);
    if (rows.length) {
      const visuals = h('div', { class: 'op-two-col' }), monthly = card('Monthly actual effort'), split = card('Funding by line of business');
      const months = new Map(); rows.forEach((b) => (b.charges || []).forEach((c) => months.set(c.month, (months.get(c.month) || 0) + num(c.charged_hours)))); monthly.body.appendChild(monthBars([...months].sort(([a], [b]) => a.localeCompare(b)).slice(-12).map(([month, hours]) => ({ month, hours }))));
      const groups = new Map(); rows.forEach((b) => { const key = `${b.lob || 'Unassigned'}|${b.currency}`; if (!groups.has(key)) groups.set(key, { lob: b.lob || 'Unassigned', currency: b.currency, amount: 0, spent: 0 }); const g = groups.get(key); g.amount += num(b.totals.budget_amount); g.spent += num(b.totals.charged_amount); });
      split.body.appendChild(dataTable({ columns: [{ key: 'lob', label: 'Business' }, { key: 'amount', label: 'Budget', align: 'right', render: (g) => money(g.amount, g.currency) }, { key: 'spent', label: 'Actuals', align: 'right', render: (g) => money(g.spent, g.currency) }], rows: [...groups.values()], caption: 'Funding by business', dense: true }).el); visuals.append(monthly.el, split.el); body.appendChild(visuals);
    }
  }

  function decisionChip(value) { return chip(value || 'Pending', value === 'Approved' ? 'green' : value === 'Rejected' ? 'red' : value === 'Delayed' ? 'amber' : ''); }
  function monthBars(rows) {
    if (!rows.length) return emptyState('Monthly charges will appear here after actuals are entered.');
    const max = Math.max(1, ...rows.map((r) => r.hours));
    return h('div', { class: 'op-bars', role: 'img', 'aria-label': `Monthly actual effort: ${rows.map((r) => `${fmtMonth(r.month)} ${fmtHours(r.hours)}`).join(', ')}` }, rows.map((r) => h('div', { class: 'op-bar-column' }, h('span', { text: fmtHours(r.hours) }), h('div', { class: 'op-bar-track' }, h('span', { class: 'op-bar-fill', style: { height: `${r.hours / max * 100}%` } })), h('span', { text: fmtMonth(r.month) }))));
  }

  function drawDetail(b) {
    const totals = b.totals || {}, currency = b.currency || 'CAD';
    const detailActions = rowActions(decisionChip(b.decision), button('Edit budget', () => editBudget(b)), button('Delete', () => removeItem({ title: 'Delete funding budget?', message: `Delete ${b.prn_code}, its estimates and all monthly actuals? Linked initiatives must be unlinked first.`, remove: () => api.request('DELETE', path(b.prn_code)), after: async () => { selected = ''; await changed('Funding budget deleted.'); } }), { kind: 'danger' }));
    body.appendChild(h('div', { class: 'op-detail-head' }, h('div', {}, button('← All funding', () => { selected = ''; draw(); }, { kind: 'text' }), h('h3', { text: `${b.prn_code} · ${b.name}` }), h('p', { text: `${b.lob || 'No business assigned'} · ${b.charge_type || 'Project'}${b.owner_name ? ` · ${b.owner_name}` : ''}` })), detailActions));
    if (b.intake_draft) body.appendChild(h('div', { class: 'notice notice-amber' }, h('strong', { text: 'Funding details started from an intake. ' }),
      'The code and context are linked. Enter the funding figures and confirm the decision to complete this draft. ', button('Complete funding details', () => editBudget(b), { small: true })));
    body.appendChild(h('div', { class: 'op-metrics' }, metric('Budget', money(totals.budget_amount, currency), `${fmtHours(b.funded_hours)} funded`), metric('Actual spend', money(totals.charged_amount, currency), `${fmtHours(totals.charged_hours)} charged`), metric('Remaining budget', money(totals.remaining_amount, currency), `${fmtHours(totals.remaining_hours)} unspent`, totals.remaining_amount < 0 ? 'over' : ''), metric('Component estimates', money(totals.estimated_amount, currency), `${fmtHours(totals.estimated_hours)} across ${(b.estimates || []).length} lines`)));
    const overview = h('div', { class: 'op-two-col' }), forecast = card('Funding forecast'), info = card('Scope & funding context');
    const chartHost = h('div'); forecast.body.appendChild(chartHost); chartHost.appendChild(loading('Loading forecast…')); forecast.body.appendChild(h('p', { class: 'op-note', text: 'Forecast combines recorded actuals and future resource allocations on linked initiatives. Add allocations in the Resource allocation tab to build the forecast.' }));
    const token = detailToken;
    api.getPrnBurndown(b.prn_code).then((data) => {
      if (disposed || token !== detailToken) return;
      if ((data.months || []).length > 1) chart = renderBurndown(chartHost, data, { today });
      else {
        const funded = num(data.funded_hours), actual = num(data.charged_hours), forecast = num(data.forecast_hours);
        chartHost.replaceChildren(h('div', { class: 'op-forecast-snapshot' },
          h('div', {}, h('span', { text: 'Actual effort charged' }), h('strong', { text: fmtHours(actual) }), meter(actual, funded, { label: `${funded ? Math.round(actual / funded * 100) : 0}% of funded hours` })),
          h('div', {}, h('span', { text: 'Forecast to finish' }), h('strong', { text: fmtHours(forecast) }), meter(forecast, funded, { label: `${fmtHours(funded - forecast)} available after forecast` })),
          h('p', { class: 'op-note', text: `${fmtHours(funded)} funded · ${data.status === 'overrun' ? 'Forecast exceeds funding' : data.status === 'at_risk' ? 'Funding is close to its limit' : 'Within funded capacity'}. A monthly trend appears as more months are recorded.` })));
      }
    }).catch((err) => { if (!disposed && token === detailToken) chartHost.replaceChildren(errorBox(err)); });
    const context = [['Funding period', [b.start_month && fmtMonth(b.start_month), b.end_month && fmtMonth(b.end_month)].filter(Boolean).join(' – ') || 'Not set'], ['Platform / region', [b.platform, b.region].filter(Boolean).join(' · ') || '—'], ['Channel', b.channel || '—'], ['APT / PR', [b.apt_number, b.external_pr_code].filter(Boolean).join(' · ') || '—']];
    info.body.appendChild(h('dl', { class: 'op-context' }, context.map(([label, value]) => h('div', {}, h('dt', { text: label }), h('dd', { text: value })))));
    info.body.append(h('h4', { text: 'Scope' }), h('p', { class: 'op-context-text', text: b.scope || 'Add the scope covered by this budget.' }), h('h4', { text: 'Assumptions' }), h('p', { class: 'op-context-text', text: b.assumptions || 'No assumptions entered.' })); overview.append(forecast.el, info.el); body.appendChild(overview);

    const estimates = card('Component & team estimates', { right: button('Add estimate', () => editEstimate(b), { kind: 'primary', small: true }) });
    if ((b.estimates || []).length) {
      const phaseSummary = h('div', { class: 'op-detail-metrics' }); phases.forEach((phase) => { const lines = b.estimates.filter((e) => e.phase === phase); phaseSummary.appendChild(metric(phase, money(lines.reduce((sum, e) => sum + num(e.amount), 0), currency), fmtHours(lines.reduce((sum, e) => sum + num(e.hours), 0)))); }); estimates.body.appendChild(phaseSummary);
    }
    estimates.body.appendChild(h('p', { class: 'op-note', text: 'Estimates include all decisions. The approved funding budget is entered separately.' }));
    estimates.body.appendChild(dataTable({ columns: [
      { key: 'appcat', label: 'AppCat / team', render: (e) => h('div', {}, e.appcat || '—', h('span', { class: 'op-secondary', text: [e.team, e.sto && `STO: ${e.sto}`].filter(Boolean).join(' · ') })) }, { key: 'phase', label: 'Phase' }, { key: 'hours', label: 'Hours', align: 'right', render: (e) => fmtHours(e.hours) }, { key: 'rate', label: 'Rate', align: 'right', render: (e) => money(e.rate, currency) }, { key: 'amount', label: 'Estimate', align: 'right', render: (e) => money(e.amount, currency) }, { key: 'decision', label: 'Decision', render: (e) => decisionChip(e.decision) },
      { key: 'notes', label: 'Scope / assumptions', render: (e) => h('span', { class: 'op-line-notes', title: e.notes || '', text: e.notes || '—' }) },
      { key: 'actions', label: '', sortable: false, render: (e) => rowActions(button('Edit', () => editEstimate(b, e), { kind: 'text', small: true }), button('Delete', () => removeItem({ title: 'Delete estimate?', message: `Remove this ${e.phase.toLowerCase()} estimate for ${e.appcat || e.team || e.sto}?`, remove: () => api.request('DELETE', path(b.prn_code, `/estimates/${e.id}`)), after: () => changed('Estimate deleted.') }), { kind: 'danger', small: true })) },
    ], rows: b.estimates || [], caption: 'Component funding estimates', empty: 'Add estimates for each AppCat, team or STO. Separate planning, development and support to show the full cost.', dense: true }).el); body.appendChild(estimates.el);
    const actuals = card('Monthly actuals', { right: button('Record actuals', () => editCharge(b), { kind: 'primary', small: true }) });
    actuals.body.appendChild(dataTable({ columns: [{ key: 'month', label: 'Month', render: (c) => fmtMonth(c.month) }, { key: 'charged_hours', label: 'Charged hours', align: 'right', render: (c) => fmtHours(c.charged_hours) }, { key: 'charged_amount', label: 'Actual amount', align: 'right', render: (c) => money(c.charged_amount ?? c.charged_hours * b.rate, currency) }, { key: 'source', label: 'Source', render: (c) => c.source === 'portal' ? 'Portal' : c.source === 'import' ? 'Workbook' : c.source }, { key: 'actions', label: '', sortable: false, render: (c) => rowActions(button('Edit', () => editCharge(b, c), { kind: 'text', small: true }), button('Delete', () => removeItem({ title: 'Delete monthly actuals?', message: `Remove ${fmtMonth(c.month)} actuals from ${b.prn_code}?`, remove: () => api.request('DELETE', path(b.prn_code, `/charges/${c.id}`)), after: () => changed('Monthly actuals deleted.') }), { kind: 'danger', small: true })) }], rows: b.charges || [], caption: 'Monthly actual funding charges', empty: 'No actuals entered. Record one total per funding code and month.', dense: true }).el); body.appendChild(actuals.el);
    const links = card('Linked initiatives', { right: button('Manage links', () => editLinks(b), { small: true }) });
    links.body.appendChild((b.initiatives || []).length ? h('div', { class: 'op-link-list' }, b.initiatives.map((i) => h('a', { href: `#/initiative/${i.id}/pg1`, text: `${i.rddc} · ${i.name}` }))) : emptyState('Link initiatives so their resource allocations contribute to the funding forecast.')); body.appendChild(links.el);
  }

  function editBudget(b = null) {
    const lobOptions = (lookups.lob || []).map((o) => ({ value: o.value, label: o.label || o.value }));
    editor({ title: b ? `Edit ${b.prn_code}` : 'Add funding budget', width: 860, intro: 'Enter approved funding separately from component estimates. Leave the budget amount blank to calculate hours × rate.', fields: [
      ...(!b ? [{ name: 'prn_code', label: 'Funding / PRN code', required: true, maxlength: 60, placeholder: 'PRN-12345', pattern: '[A-Za-z0-9][A-Za-z0-9._\\-]*' }] : []),
      { name: 'name', label: 'Budget name', value: b?.name, required: true, maxlength: 200 }, { name: 'lob', label: 'Line of business', type: 'select', value: b?.lob || '', options: [{ value: '', label: 'Select business' }, ...lobOptions] },
      { name: 'funded_hours', label: 'Funded hours', type: 'number', value: b?.funded_hours ?? '', min: 0, step: .5, hint: 'Enter hours or a budget amount.' }, { name: 'rate', label: 'Blended hourly rate', type: 'number', value: b?.rate ?? 110, min: 0, step: .01, required: true },
      { name: 'budget_amount', label: 'Budget amount', type: 'number', value: b?.budget_amount ?? '', min: 0, step: .01 }, { name: 'currency', label: 'Currency', type: 'select', value: b?.currency || 'CAD', options: options([...new Set(['CAD', 'USD', 'GBP', 'EUR', b?.currency].filter(Boolean))]) },
      { name: 'decision', label: 'Funding decision', type: 'select', value: b?.decision || 'Pending', options: options(decisions) }, { name: 'charge_type', label: 'PR charge allocation', type: 'select', value: b?.charge_type || 'Project', options: options(['Project', 'POD']) },
      { name: 'owner_id', label: 'Budget owner', type: 'select', value: b?.owner_id || '', options: [{ value: '', label: 'Unassigned' }, ...people.map((p) => ({ value: p.id, label: p.name }))] }, { name: 'start_month', label: 'Start month', type: 'month', value: b?.start_month || '' }, { name: 'end_month', label: 'End month', type: 'month', value: b?.end_month || '' },
      ...[['platform', 'Platform'], ['region', 'Region'], ['channel', 'Channel'], ['apt_number', 'APT number'], ['external_pr_code', 'External PR code']].map(([name, label]) => ({ name, label, value: b?.[name] || '', maxlength: 200 })),
      { name: 'scope', label: 'Scope', type: 'textarea', value: b?.scope || '', maxlength: 16000, 'data-wide': true }, { name: 'assumptions', label: 'Assumptions', type: 'textarea', value: b?.assumptions || '', maxlength: 16000, 'data-wide': true },
    ], validate: (v) => { if (v.funded_hours === null && (v.budget_amount === null || !(v.rate > 0))) throw new Error('Enter funded hours, or a budget amount with a positive hourly rate.'); if (v.start_month && v.end_month && v.end_month < v.start_month) throw new Error('End month must be on or after the start month.'); }, onSave: async (v) => {
      v.owner_id = v.owner_id ? Number(v.owner_id) : null;
      if (b && v.funded_hours === null) v.funded_hours = v.budget_amount / v.rate;
      if (!b && v.funded_hours === null) delete v.funded_hours;
      const saved = await api.request(b ? 'PUT' : 'POST', b ? path(b.prn_code) : '/funding', { body: v }); selected = saved.prn_code; await changed(b ? 'Funding budget updated.' : 'Funding budget added.');
    } });
  }
  function editCharge(b, charge = null) {
    editor({ title: charge ? `Edit actuals · ${b.prn_code}` : `Record actuals · ${b.prn_code}`, intro: 'Enter one actual total per month. Leave amount blank to calculate charged hours × budget rate.', fields: [
      { name: 'month', label: 'Month', type: 'month', value: charge?.month || today.slice(0, 7), required: true }, { name: 'charged_hours', label: 'Charged hours', type: 'number', value: charge?.charged_hours ?? '', required: true, min: 0, step: .5 }, { name: 'charged_amount', label: `Actual amount (${b.currency})`, type: 'number', value: charge?.charged_amount ?? '', min: 0, step: .01 },
    ], onSave: async (v) => { await api.request(charge ? 'PUT' : 'POST', path(b.prn_code, charge ? `/charges/${charge.id}` : '/charges'), { body: v }); await changed('Monthly actuals saved.'); } });
  }
  function editEstimate(b, line = null) {
    editor({ title: line ? 'Edit component estimate' : 'Add component estimate', width: 800, intro: 'Identify an AppCat, team or STO. Separate the phases into individual lines. Amount defaults to hours × rate.', fields: [
      { name: 'appcat', label: 'AppCat / component', value: line?.appcat || '', maxlength: 200 }, { name: 'team', label: 'Team', value: line?.team || '', maxlength: 200 }, { name: 'sto', label: 'STO', value: line?.sto || '', maxlength: 200 }, { name: 'phase', label: 'Phase', type: 'select', value: line?.phase || 'Development', options: options(phases) },
      { name: 'hours', label: 'Estimated hours', type: 'number', value: line?.hours ?? '', min: 0, step: .5, required: true }, { name: 'rate', label: `Rate (${b.currency})`, type: 'number', value: line?.rate ?? b.rate, min: 0, step: .01, required: true }, { name: 'amount', label: `Estimated amount (${b.currency})`, type: 'number', value: line?.amount ?? '', min: 0, step: .01 }, { name: 'decision', label: 'Decision', type: 'select', value: line?.decision || 'Pending', options: options(decisions) },
      { name: 'notes', label: 'Scope, assumptions & notes', type: 'textarea', value: line?.notes || '', maxlength: 16000, 'data-wide': true },
    ], validate: (v) => { if (!v.appcat && !v.team && !v.sto) throw new Error('Enter an AppCat, team or STO to identify this estimate.'); }, onSave: async (v) => { if (v.amount === null) v.amount = v.hours * v.rate; await api.request(line ? 'PUT' : 'POST', path(b.prn_code, line ? `/estimates/${line.id}` : '/estimates'), { body: v }); await changed('Component estimate saved.'); } });
  }
  function editLinks(b) {
    const checks = [], linked = new Set((b.initiatives || []).map((i) => i.id)), list = h('div', { class: 'op-link-picker' });
    initiatives.forEach((i) => { const input = h('input', { type: 'checkbox', checked: linked.has(i.id), value: i.id }); checks.push(input); list.appendChild(h('label', {}, input, h('span', { text: `${i.rddc} · ${i.name}` }))); });
    if (!initiatives.length) list.appendChild(emptyState('Create or import an initiative to link it to funding.'));
    editor({ title: `Linked initiatives · ${b.prn_code}`, intro: 'Selected initiatives use this funding code. Selecting an initiative funded elsewhere moves it to this budget.', extra: list, saveLabel: 'Save links', onSave: async () => { await api.request('PUT', path(b.prn_code, '/initiatives'), { body: { initiative_ids: checks.filter((c) => c.checked).map((c) => Number(c.value)) } }); await changed('Funding links saved.'); } });
  }
  return () => { disposed = true; teardownChart(); };
}
