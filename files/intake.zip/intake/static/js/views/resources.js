// Resources (#/resources): team bars, FY heatmap with per-initiative breakdown, inventory (editable monthly
// available hours), Skill Matrix (AI), PRN burndown.
import {
  api, h, clear, card, dataTable, autoButton, button, pageHeader, errorBox, loading, emptyState, selectEl, chip,
  fmtMonth, fmtMonthShort, fmtHours, fmtNum, getLookups, getToday, getSettingsSafe, itemsOf, runAi, toast, bindTip,
  monthKey, monthsBetween, addMonths, fiscalOf, isNum, num, framePage,
} from '../charts/kit.js';
import { renderHeatmap } from '../charts/heatmap.js';
import { mountCapacityTile, mountBurndownPicker } from './portfolio.js';

function fiscalYears(lookups, today) {
  const quarters = Array.isArray(lookups && lookups.fiscal_quarters) ? lookups.fiscal_quarters : [];
  const byFy = new Map();
  for (const q of quarters) {
    if (!Array.isArray(q.months) || !q.months.length) continue;
    if (!byFy.has(q.fy)) byFy.set(q.fy, []);
    byFy.get(q.fy).push(...q.months);
  }
  if (!byFy.size) {
    const f = fiscalOf(addMonths(monthKey(today) || '2026-10', 1));
    const startYear = Number(`20${f.fy.slice(2)}`) - 1;
    byFy.set(f.fy, monthsBetween(`${startYear}-11`, `${startYear + 1}-10`));
  }
  return [...byFy.entries()].map(([fy, months]) => ({ value: fy, label: `${fy} (Nov–Oct)`, months: [...new Set(months)].sort() }));
}

function levelDots(level) {
  const n = Math.max(0, Math.min(3, Number(level) || 0));
  return h('span', { class: 'dv-level', 'aria-label': `Level ${n} of 3` }, [1, 2, 3].map((i) => h('i', { class: i <= n ? 'on' : '' })));
}

export async function render(root, params, ctx) {
  const page = framePage(root, 'resources');
  const aiHost = h('div', { class: 'dv-ai-host', hidden: true });
  const body = h('div');
  const skillBtn = autoButton('Generate Skill Matrix', () => generateSkills());
  page.append(pageHeader({ title: 'Resources', hint: 'Capacity, utilisation, inventory and skills for capacity-tracked people', actions: [skillBtn] }), aiHost, body);
  body.appendChild(loading('Loading resources…'));

  let lookups;
  let today;
  let settings;
  try {
    [lookups, today, settings] = await Promise.all([getLookups(ctx), getToday(ctx), getSettingsSafe()]);
  } catch (err) {
    clear(body);
    body.appendChild(errorBox(err, () => render(root, params, ctx)));
    return undefined;
  }
  clear(body);
  const cleanups = [];
  const years = fiscalYears(lookups, today);
  let fy = years.find((y) => y.months.some((m) => m >= monthKey(today))) || years[0];
  let focus = null;
  try {
    const raw = sessionStorage.getItem('bmo.resources.focus');
    if (raw) { focus = JSON.parse(raw); sessionStorage.removeItem('bmo.resources.focus'); }
  } catch { focus = null; }

  // row 1: team bars + PRN burndown
  const teamCard = card('Resource capacity by team');
  const burnCard = card('PRN burndown');
  body.appendChild(h('div', { class: 'dv-grid-2' }, teamCard.el, burnCard.el));
  const teamTile = mountCapacityTile(teamCard.body, { lookups, today });
  mountBurndownPicker(burnCard.body, { today, preferred: 'PRN-77310' }).then((c) => cleanups.push(c));

  // row 2: heatmap
  const heatCard = card('Utilisation by person and month', {
    right: selectEl(years.map((y) => ({ value: y.value, label: y.label })), fy.value, (v) => { fy = years.find((y) => y.value === v) || fy; loadCapacity(); }, { label: 'Fiscal year' }),
  });
  const heatHost = h('div');
  const detail = h('div', { class: 'dv-detail', hidden: true, 'aria-live': 'polite' });
  heatCard.body.append(heatHost, detail);
  body.appendChild(h('div', { class: 'dv-section' }, heatCard.el));

  // row 3: inventory
  const invCard = card('Resource inventory · monthly available hours', {
    right: h('span', { class: 'dv-muted', text: settings.persona === 'Account Manager' ? 'Editing as Account Manager' : `Account Manager edits availability · acting as ${settings.persona || 'DC PM'}` }),
  });
  body.appendChild(h('div', { class: 'dv-section', 'data-testid': 'resource-inventory' }, invCard.el));

  // row 4: skill matrix
  const skillCard = card('Skill matrix', { right: h('span', { class: 'dv-muted', text: 'Level 1 working · 2 strong · 3 expert' }) });
  body.appendChild(h('div', { class: 'dv-section', 'data-testid': 'skill-matrix' }, skillCard.el));

  let capacity = null;
  let resources = [];
  let breakdown = new Map();
  let heat = null;
  let invFilter = null;

  const ridOf = (row) => {
    if (isNum(row.key)) return Number(row.key);
    if (isNum(row.resource_id)) return Number(row.resource_id);
    const hit = resources.find((r) => r.name === row.label);
    return hit ? hit.id : null;
  };

  async function loadCapacity() {
    clear(heatHost);
    heatHost.appendChild(loading('Loading utilisation…'));
    try {
      const months = fy.months;
      const [cap, res, allocs] = await Promise.all([
        api.getCapacity({ group: 'resource', from: months[0], to: months[months.length - 1] }),
        api.listResources({ tracked: 1 }),
        api.listAllocations({}).catch(() => ({ items: [] })),
      ]);
      capacity = cap;
      resources = itemsOf(res).filter((r) => r.capacity_eligible !== 0);
      breakdown = new Map();
      for (const a of itemsOf(allocs)) {
        const key = `${a.resource_id}|${a.month}`;
        if (!breakdown.has(key)) breakdown.set(key, new Map());
        const m = breakdown.get(key);
        const label = a.rddc || `Initiative ${a.initiative_id}`;
        const prev = m.get(label) || { label, hours: 0, firmness: a.firmness };
        prev.hours += num(a.hours);
        if (a.firmness === 'tentative') prev.firmness = 'tentative';
        m.set(label, prev);
      }
      clear(heatHost);
      const opts = {
        breakdown: (row, cell) => {
          const m = breakdown.get(`${ridOf(row)}|${cell.month}`);
          return m ? [...m.values()].sort((a, b) => b.hours - a.hours) : [];
        },
        onCellClick: ({ row, cell }) => showDetail(row, cell),
        selected: focus && focus.key !== undefined ? { key: focus.key, month: focus.month } : null,
        highlightOver: Boolean(focus && focus.highlight === 'over'),
      };
      if (heat) heat.destroy();
      heat = renderHeatmap(heatHost, capacity, opts);
      drawInventory();
      if (focus && focus.highlight === 'over') {
        heatCard.el.scrollIntoView({ block: 'start' });
        detail.hidden = false;
        clear(detail);
        const overRows = (capacity.rows || []).map((r) => ({ r, cells: (r.cells || []).filter((c) => c.band === 'over' || c.band === 'stretched' || Number(c.util) > 1) })).filter((x) => x.cells.length);
        detail.append(h('div', { class: 'dv-section-title' }, h('span', { text: `Over-allocated people · ${overRows.length}` }),
          button('Show all months', () => { detail.hidden = true; loadCapacity(); }, { kind: 'text' })),
        overRows.length ? h('ul', { class: 'dv-bullets' }, overRows.map(({ r, cells }) => h('li', { text: `${r.label}: ${cells.map((c) => `${fmtMonth(c.month)} ${Math.round(Number(c.util) * 100)}%`).join(', ')}` }))) : h('p', { class: 'dv-muted', text: 'Nobody is over 100% in this fiscal year.' }));
        focus = null;
      } else if (focus) {
        const row = (capacity.rows || []).find((r) => String(r.key) === String(focus.key) || r.label === focus.label);
        const cell = row && (row.cells || []).find((c) => c.month === focus.month);
        if (row && cell) showDetail(row, cell);
        focus = null;
      }
    } catch (err) {
      clear(heatHost);
      heatHost.appendChild(errorBox(err, loadCapacity));
    }
  }

  function showDetail(row, cell) {
    const rid = ridOf(row);
    const m = breakdown.get(`${rid}|${cell.month}`);
    const parts = m ? [...m.values()].sort((a, b) => b.hours - a.hours) : [];
    const demand = num(cell.confirmed) + num(cell.tentative);
    clear(detail);
    detail.hidden = false;
    detail.append(
      h('div', { class: 'dv-section-title' }, h('span', { text: `${row.label} · ${fmtMonth(cell.month)}` }), button('Close', () => { detail.hidden = true; invFilter = null; drawInventory(); }, { kind: 'text' })),
      h('p', { text: `${fmtHours(demand)} allocated of ${fmtHours(num(cell.available))} available.` }),
      parts.length ? h('ul', { class: 'dv-bullets' }, parts.map((p) => h('li', { text: `${p.label} · ${fmtHours(p.hours)}${p.firmness === 'tentative' ? ' (tentative)' : ''}` }))) : h('p', { class: 'dv-muted', text: 'No initiative work booked this month.' }));
    invFilter = rid;
    drawInventory();
  }

  function drawInventory() {
    clear(invCard.body);
    if (!capacity) return;
    const months = fy.months;
    const capRows = new Map((capacity.rows || []).map((r) => [String(ridOf(r)), r]));
    const people = resources.length ? resources : (capacity.rows || []).map((r) => ({ id: ridOf(r), name: r.label, team: r.team, role: '' }));
    const rows = people.filter((p) => invFilter === null || String(p.id) === String(invFilter)).map((p) => ({ ...p, cap: capRows.get(String(p.id)) || null }));
    const columns = [
      { key: 'name', label: 'Name', cls: 'dv-nowrap' },
      { key: 'team', label: 'Team', cls: 'dv-nowrap', render: (r) => r.team_label || r.team || '—' },
      { key: 'role', label: 'Role', render: (r) => {
        // Team uses the capacity label (e.g. "EAPI Tech Lead"); when the role repeats it, show only the part after the team.
        let role = r.role || '—';
        if (r.team_label && role === r.team_label && r.team && role.startsWith(`${r.team} `)) role = role.slice(r.team.length + 1);
        return h('span', { class: 'dv-cell-clip dv-clip-120', title: r.role || '', text: role });
      } },
      ...months.map((mo) => ({
        key: `m_${mo}`, label: fmtMonthShort(mo), align: 'right', sortable: false, title: fmtMonth(mo), cls: 'dv-month-cell',
        render: (r) => {
          const cell = r.cap && Array.isArray(r.cap.cells) ? r.cap.cells.find((c) => c.month === mo) : null;
          const value = cell && isNum(cell.available) ? Number(cell.available) : null;
          const input = h('input', { class: 'dv-input dv-input-num', type: 'number', min: '0', max: '250', step: '0.5', inputmode: 'decimal', 'aria-label': `${r.name} available hours ${fmtMonth(mo)}` });
          input.value = value === null ? '' : String(value);
          input.addEventListener('change', () => saveAvailability(r, mo, input, value));
          return input;
        },
      })),
    ];
    if (invFilter !== null) invCard.body.appendChild(h('p', { class: 'dv-muted' }, 'Showing one person. ', button('Show everyone', () => { invFilter = null; detail.hidden = true; drawInventory(); }, { kind: 'text' })));
    invCard.body.appendChild(dataTable({ columns, rows, sortKey: 'team', caption: 'Resource inventory', empty: 'No capacity-tracked people yet.', dense: true }).el);
  }

  async function saveAvailability(r, month, input, previous) {
    const v = Number(input.value);
    if (input.value === '' || !Number.isFinite(v) || v < 0 || v > 250) {
      input.classList.add('is-invalid');
      input.title = 'Enter hours between 0 and 250';
      toast('Available hours must be between 0 and 250.', 'warning');
      return;
    }
    input.classList.remove('is-invalid');
    input.disabled = true;
    try {
      await api.setAvailability(r.id, { [month]: v });
      input.classList.add('is-saved');
      toast(`${r.name} · ${fmtMonth(month)} set to ${fmtNum(v, 1)} h. Utilisation recalculated.`);
      teamTile.reload();
      const months = fy.months;
      capacity = await api.getCapacity({ group: 'resource', from: months[0], to: months[months.length - 1] });
      if (heat) heat.update(capacity);
    } catch (err) {
      input.value = previous === null ? '' : String(previous);
      toast(err.message, 'warning');
    } finally {
      input.disabled = false;
    }
  }

  let skillCategory = null;
  async function loadSkills() {
    clear(skillCard.body);
    skillCard.body.appendChild(loading('Loading skills…'));
    try {
      const matrix = await api.getSkillMatrix();
      clear(skillCard.body);
      const skills = Array.isArray(matrix.skills) ? matrix.skills : [];
      const rows = Array.isArray(matrix.rows) ? matrix.rows : [];
      if (!skills.length || !rows.length) {
        skillCard.body.appendChild(emptyState('No skills recorded yet. Click Generate Skill Matrix to build one from past WBS work.'));
        return;
      }
      const usedAll = skills.filter((s) => rows.some((r) => r.levels && r.levels[s.name]));
      const categories = [...new Set(usedAll.map((s) => s.category).filter(Boolean))];
      if (skillCategory === null) skillCategory = categories[0] || '';
      const used = skillCategory ? usedAll.filter((s) => s.category === skillCategory) : usedAll;
      if (categories.length > 1) {
        skillCard.body.appendChild(h('div', { class: 'dv-filters' },
          selectEl(categories.map((c) => ({ value: c, label: c })), skillCategory, (v) => { skillCategory = v; loadSkills(); }, { label: 'Skill area', allLabel: 'All areas' }),
          h('span', { class: 'dv-muted', text: `${used.length} of ${usedAll.length} skills shown` })));
      }
      const columns = [
        { key: 'name', label: 'Name', cls: 'dv-nowrap' },
        { key: 'team', label: 'Team', cls: 'dv-nowrap' },
        ...used.map((s) => ({
          key: `s_${s.name}`, label: s.name, sortable: true, cls: 'dv-skill-cell', title: s.category || s.name,
          sort: (r) => -(num(r.levels && r.levels[s.name])),
          render: (r) => {
            const lvl = r.levels ? r.levels[s.name] : null;
            if (!lvl) return h('span', { class: 'dv-muted', text: '·' });
            const dots = levelDots(lvl);
            const ev = r.evidence && r.evidence[s.name];
            dots.tabIndex = 0;
            bindTip(dots, () => [`${r.name} · ${s.name}`, `Level ${lvl} of 3`, ev ? `Evidence: ${ev}` : null]);
            return dots;
          },
        })),
      ];
      skillCard.body.appendChild(dataTable({ columns, rows, sortKey: 'team', caption: 'Skill matrix', dense: true }).el);
    } catch (err) {
      clear(skillCard.body);
      skillCard.body.appendChild(errorBox(err, loadSkills));
    }
  }

  function generateSkills() {
    return runAi(aiHost, {
      feature: 'skill_matrix', title: 'Skill Matrix', trigger: skillBtn,
      preview: (run) => {
        const o = run.output || {};
        const rows = Array.isArray(o.rows) ? o.rows : [];
        const gaps = Array.isArray(o.team_gaps) ? o.team_gaps : [];
        return h('div', {},
          h('p', { text: `${rows.length} people rated across ${Array.isArray(o.skills) ? o.skills.length : 0} skills from their WBS history.` }),
          rows.length ? dataTable({ dense: true, caption: 'Proposed skills', columns: [
            { key: 'resource_name', label: 'Name' },
            { key: 'team', label: 'Team' },
            { key: 'top_skills', label: 'Top skills', sortable: false, render: (r) => (Array.isArray(r.top_skills) ? r.top_skills.join(', ') : '—') },
            { key: 'skills', label: 'Skills rated', align: 'right', sort: (r) => (Array.isArray(r.skills) ? r.skills.length : 0), render: (r) => String(Array.isArray(r.skills) ? r.skills.length : 0) },
          ], rows }).el : null,
          gaps.length ? [h('h3', { text: 'Team gaps' }), h('ul', { class: 'dv-bullets' }, gaps.map((g) => h('li', { text: `${g.skill}: ${g.holders} holder${g.holders === 1 ? '' : 's'}${Array.isArray(g.holder_names) && g.holder_names.length ? ` (${g.holder_names.join(', ')})` : ''}${g.note ? ` — ${g.note}` : ''}` })))] : null);
      },
      acceptMessage: (res) => {
        const n = res && res.applied ? Object.values(res.applied).reduce((a, b) => a + num(b), 0) : 0;
        return n ? `Skill matrix accepted · ${fmtNum(n)} ratings saved.` : 'Skill matrix accepted.';
      },
      onApplied: () => loadSkills(),
    });
  }

  await Promise.all([loadCapacity(), loadSkills()]);
  return () => { if (heat) heat.destroy(); cleanups.forEach((fn) => fn()); };
}
