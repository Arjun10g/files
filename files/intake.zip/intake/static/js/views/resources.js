import { api, h, clear, card, dataTable, button, pageHeader, errorBox, loading, emptyState, fmtMonth, fmtHours, fmtNum, getToday, itemsOf, toast, monthKey, monthsBetween, addMonths, num, framePage, tabs, chip, announceChange } from '../charts/kit.js';
import { renderHeatmap } from '../charts/heatmap.js';
import { openModal } from '../ui/modal.js';
import { field, editor, removeItem, metric, meter, rowActions } from './operation_helpers.js';

export async function render(root, params, ctx) {
  const page = framePage(root, 'resources');
  const content = h('div', { class: 'op-content' }), metrics = h('div', { class: 'op-metrics' }), toolbar = h('div', { class: 'op-toolbar' });
  let initiativeFilter = String(params.query?.initiative_id || params.query?.initiative || '');
  let activeTab = initiativeFilter ? 'allocations' : 'capacity', people = [], initiatives = [], allocations = [], intakeContext = null;
  let currentMonth = monthKey(await getToday(ctx)) || new Date().toISOString().slice(0, 7);
  let team = '', query = '', showInactive = false, period = '12', allocationMonth = '', heat = null, disposed = false;
  page.append(pageHeader({ title: 'Resource allocation', hint: 'Manage people, monthly capacity and initiative assignments.', actions: [button('Add person', () => editPerson(), { kind: 'primary' }), button('Allocate hours', () => editAllocation())] }), metrics, toolbar, tabs([{ value: 'capacity', label: 'Capacity overview' }, { value: 'people', label: 'People & skills' }, { value: 'allocations', label: 'Allocations' }], activeTab, (v) => { activeTab = v; draw(); }), content);
  await reload();

  async function reload() {
    content.replaceChildren(loading('Loading resource allocation…'));
    try {
      const result = await Promise.all([api.listResources({ active: 'all' }), api.listInitiatives(), api.listAllocations(),
        initiativeFilter ? api.getInitiative(initiativeFilter).catch(() => null) : Promise.resolve(null)]);
      if (disposed) return;
      people = itemsOf(result[0]); initiatives = itemsOf(result[1]); allocations = itemsOf(result[2]); intakeContext = result[3]?.initiative || null; draw();
    } catch (err) { if (!disposed) content.replaceChildren(errorBox(err, reload)); }
  }
  function filteredPeople() { return people.filter((p) => (showInactive || p.active !== 0) && (!team || p.team === team) && (!query || `${p.name} ${p.email || ''} ${p.role} ${(p.skills || []).map((s) => s.skill).join(' ')}`.toLowerCase().includes(query.toLowerCase()))); }
  function availableFor(p, month) { return num(p.availability?.[month], num(p.default_monthly_hours)); }
  function loadFor(id, month) { return allocations.filter((a) => a.resource_id === id && a.month === month).reduce((n, a) => n + num(a.hours), 0); }
  function changed(what) { announceChange(null, what, ctx); return reload(); }

  function draw() {
    if (disposed) return;
    if (heat) { heat.destroy(); heat = null; }
    clear(content); clear(metrics); clear(toolbar);
    const tracked = filteredPeople().filter((p) => p.capacity_eligible !== 0 && p.active !== 0);
    const available = tracked.reduce((n, p) => n + availableFor(p, currentMonth), 0), booked = tracked.reduce((n, p) => n + loadFor(p.id, currentMonth), 0);
    const over = tracked.filter((p) => loadFor(p.id, currentMonth) > availableFor(p, currentMonth)).length;
    metrics.append(metric('Active people', fmtNum(people.filter((p) => p.active !== 0).length), `${tracked.length} in selected capacity view`), metric('Available capacity', fmtHours(available), fmtMonth(currentMonth)), metric('Allocated hours', fmtHours(booked), available ? `${Math.round(booked / available * 100)}% of selected capacity` : 'Add available hours to calculate utilisation'), metric('Over capacity', fmtNum(over), 'People above available hours', over ? 'over' : ''));
    const monthControl = field({ name: 'month', label: 'Focus month', type: 'month', value: currentMonth, required: true });
    monthControl.input.addEventListener('change', () => { if (monthControl.input.value) { currentMonth = monthControl.input.value; draw(); } });
    const teamControl = field({ name: 'team', label: 'Team', type: 'select', value: team, options: [{ value: '', label: 'All teams' }, ...[...new Set(people.map((p) => p.team).filter(Boolean))].sort().map((t) => ({ value: t, label: t }))] });
    teamControl.input.addEventListener('change', () => { team = teamControl.input.value; draw(); });
    const search = field({ name: 'search', label: 'Find people', value: query, placeholder: 'Name, role or skill', type: 'search' }); search.el.classList.add('op-search');
    search.input.addEventListener('change', () => { query = search.input.value; draw(); }); toolbar.append(monthControl.el, teamControl.el, search.el);
    if (activeTab === 'capacity') drawCapacity(tracked); else if (activeTab === 'people') drawPeople(); else drawAllocations();
  }
  function drawCapacity(tracked) {
    const periods = field({ name: 'period', label: 'Months shown', type: 'select', value: period, options: [{ value: '6', label: '6 months' }, { value: '12', label: '12 months' }] });
    periods.input.addEventListener('change', () => { period = periods.input.value; draw(); }); toolbar.appendChild(periods.el);
    if (!people.length) { content.appendChild(emptyState('Start by adding your team. Set each person’s availability, then allocate hours to initiatives.', button('Add first person', () => editPerson(), { kind: 'primary' }))); return; }
    if (!tracked.length) { content.appendChild(emptyState('No active people match these filters with capacity tracking enabled.')); return; }
    const months = monthsBetween(currentMonth, addMonths(currentMonth, Number(period) - 1));
    const capacity = { months, rows: tracked.map((p) => ({ key: p.id, label: p.name, team: p.team || 'Unassigned team', cells: months.map((month) => {
      const a = allocations.filter((item) => item.resource_id === p.id && item.month === month);
      const confirmed = a.filter((item) => item.firmness === 'confirmed').reduce((n, item) => n + num(item.hours), 0), tentative = a.filter((item) => item.firmness !== 'confirmed').reduce((n, item) => n + num(item.hours), 0), available = availableFor(p, month);
      return { month, confirmed, tentative, available, util: available ? (confirmed + tentative) / available : null };
    }) })) };
    const overview = card('Monthly utilisation', { right: h('span', { class: 'op-tag', text: 'Select a cell to view or change assignments' }) }); content.appendChild(overview.el);
    heat = renderHeatmap(overview.body, capacity, { breakdown: (row, cell) => allocations.filter((a) => a.resource_id === Number(row.key) && a.month === cell.month).map((a) => ({ label: a.rddc || a.initiative_name, hours: a.hours, firmness: a.firmness })), onCellClick: ({ row, cell }) => showMonth(people.find((p) => p.id === Number(row.key)), cell.month) });
    const teams = [...new Set(tracked.map((p) => p.team || 'Unassigned team'))].map((label) => { const members = tracked.filter((p) => (p.team || 'Unassigned team') === label); return { label, people: members.length, available: members.reduce((n, p) => n + availableFor(p, currentMonth), 0), allocated: members.reduce((n, p) => n + loadFor(p.id, currentMonth), 0) }; });
    const byTeam = card(`Team capacity · ${fmtMonth(currentMonth)}`);
    byTeam.body.appendChild(dataTable({ columns: [{ key: 'label', label: 'Team' }, { key: 'people', label: 'People', align: 'right' }, { key: 'available', label: 'Available', align: 'right', render: (r) => fmtHours(r.available) }, { key: 'allocated', label: 'Allocated', align: 'right', render: (r) => fmtHours(r.allocated) }, { key: 'util', label: 'Utilisation', render: (r) => meter(r.allocated, r.available, { label: r.available ? `${Math.round(r.allocated / r.available * 100)}%` : 'No capacity' }) }], rows: teams, caption: 'Team capacity', dense: true }).el); content.appendChild(byTeam.el);
  }
  function drawPeople() {
    const incomplete = filteredPeople().filter(p => p.capacity_eligible && !num(p.default_monthly_hours) && !Object.values(p.availability || {}).some(h => num(h) > 0));
    if (incomplete.length) content.appendChild(h('p', { class: 'notice notice-amber', text: `${incomplete.length} ${incomplete.length === 1 ? 'person has' : 'people have'} no working capacity entered. Names from intakes are already available; use Capacity to enter their hours.` }));
    const archived = field({ name: 'inactive', label: 'Include inactive people', type: 'checkbox', value: showInactive }); archived.input.addEventListener('change', () => { showInactive = archived.input.checked; draw(); }); toolbar.appendChild(archived.el);
    const host = card('People & skills', { right: h('span', { class: 'op-tag', text: 'All resource information is maintained in this portal' }) });
    host.body.appendChild(dataTable({ columns: [
      { key: 'name', label: 'Person', render: (p) => h('div', {}, h('span', { class: 'op-person-name', text: p.name }), h('span', { class: 'op-secondary', text: p.email || p.location || '' })) },
      { key: 'team', label: 'Team / role', render: (p) => h('div', {}, p.team || '—', h('span', { class: 'op-secondary', text: p.role })) },
      { key: 'skills', label: 'Skills', sortable: false, render: (p) => h('div', { class: 'op-skill-chips' }, (p.skills || []).length ? p.skills.map((s) => chip(`${s.skill} · ${s.level}/3`)) : h('span', { class: 'op-secondary', text: 'No skills entered' })) },
      { key: 'capacity', label: 'Monthly capacity', align: 'right', render: (p) => p.capacity_eligible ? fmtHours(availableFor(p, currentMonth)) : 'Not tracked' },
      { key: 'active', label: 'Status', render: (p) => chip(p.active === 0 ? 'Inactive' : 'Active', p.active === 0 ? '' : 'green') },
      { key: 'actions', label: '', sortable: false, render: (p) => rowActions(button('Edit', () => editPerson(p), { kind: 'text', small: true }), button('Capacity', () => editAvailability(p), { kind: 'text', small: true }), button('Skills', () => editSkills(p), { kind: 'text', small: true })) },
    ], rows: filteredPeople(), caption: 'People and skills', empty: 'No people found. Add a person to begin.', dense: true }).el); content.appendChild(host.el);
  }
  function drawAllocations() {
    const control = field({ name: 'allocation_month', label: 'Allocation period', type: 'select', value: allocationMonth, options: [{ value: '', label: 'All months' }, ...[...new Set(allocations.map((a) => a.month))].sort().map((m) => ({ value: m, label: fmtMonth(m) }))] }); control.input.addEventListener('change', () => { allocationMonth = control.input.value; draw(); }); toolbar.appendChild(control.el);
    const initiativeControl = field({ name: 'allocation_initiative', label: 'Initiative', type: 'select', value: initiativeFilter, options: [{ value: '', label: 'All initiatives' }, ...initiatives.map(i => ({ value: i.id, label: `${i.rddc} · ${i.name}` }))] });
    initiativeControl.input.addEventListener('change', async () => { initiativeFilter = initiativeControl.input.value; await reload(); }); toolbar.appendChild(initiativeControl.el);
    if (intakeContext) {
      const ids = new Set(['requestor_id','dc_pm_id','dc_sa_id','tech_lead_id','pm_id','assigned_to_id'].map(k => intakeContext[k]).filter(Boolean));
      const teamPeople = people.filter(p => ids.has(p.id) || intakeContext.business_analyst && p.name.trim().toLowerCase() === intakeContext.business_analyst.trim().toLowerCase());
      const context = card(`People from ${intakeContext.rddc}`);
      context.body.append(h('p', { class: 'op-note', text: 'These people are linked to the intake. Complete their capacity and rates, then allocate effort to this initiative.' }),
        h('div', { class: 'btn-row' }, teamPeople.map(p => button(`${p.name} · ${p.role}`, () => editPerson(p), { small: true }))));
      content.appendChild(context.el);
    }
    const ids = new Set(filteredPeople().map((p) => p.id)), rows = allocations.filter((a) => ids.has(a.resource_id) && (!allocationMonth || a.month === allocationMonth) && (!initiativeFilter || String(a.initiative_id) === initiativeFilter));
    const host = card('Initiative allocations', { right: button('Allocate hours', () => editAllocation(), { kind: 'primary', small: true }) }); host.body.appendChild(allocationTable(rows)); host.body.appendChild(h('p', { class: 'op-note', text: 'Manual allocations are editable here. Assignments created from a project plan are maintained on that initiative’s Plan tab.' })); content.appendChild(host.el);
  }
  function allocationTable(rows, close) {
    return dataTable({ columns: [
      { key: 'resource_name', label: 'Person' }, { key: 'rddc', label: 'Initiative', render: (a) => h('a', { href: `#/initiative/${a.initiative_id}/pg2`, text: `${a.rddc || ''} · ${a.initiative_name || ''}` }) },
      { key: 'month', label: 'Month', render: (a) => fmtMonth(a.month) }, { key: 'hours', label: 'Hours', align: 'right', render: (a) => fmtHours(a.hours) },
      { key: 'firmness', label: 'Commitment', render: (a) => chip(a.firmness === 'confirmed' ? 'Confirmed' : 'Tentative', a.firmness === 'confirmed' ? 'blue' : 'amber') },
      { key: 'source', label: 'Source', render: (a) => a.source === 'manual' ? 'Portal' : 'Project plan' },
      { key: 'actions', label: '', sortable: false, render: (a) => a.source === 'manual' ? rowActions(button('Edit', () => { if (close) close(); editAllocation(a); }, { kind: 'text', small: true }), button('Delete', () => removeItem({ title: 'Delete allocation?', message: `Remove ${fmtHours(a.hours)} for ${a.resource_name} in ${fmtMonth(a.month)}?`, remove: () => api.deleteAllocation(a.id), after: async () => { if (close) close(); toast('Allocation deleted.'); await changed('allocations'); } }), { kind: 'danger', small: true })) : h('a', { href: `#/initiative/${a.initiative_id}/pg2`, text: 'Open plan' }) },
    ], rows, sortKey: 'month', caption: 'Monthly initiative allocations', empty: 'No allocations yet. Allocate hours once an initiative and a person have been added.', dense: true }).el;
  }
  function editPerson(person = null) {
    editor({ title: person ? `Edit ${person.name}` : 'Add person', intro: 'Enter the team member’s role and capacity. Availability can be adjusted separately for each month.', fields: [
      { name: 'name', label: 'Full name', value: person?.name, required: true, maxlength: 120 }, { name: 'role', label: 'Role', value: person?.role, required: true, maxlength: 80 },
      { name: 'email', label: 'Email', type: 'email', value: person?.email, maxlength: 200 }, { name: 'team', label: 'Team', value: person?.team, maxlength: 40, placeholder: 'e.g. Integration' },
      { name: 'location', label: 'Location', value: person?.location, maxlength: 80 }, { name: 'hourly_rate', label: 'Hourly rate (CAD)', type: 'number', value: person?.hourly_rate ?? '', min: 0, max: 1000, step: .01 },
      { name: 'default_monthly_hours', label: 'Default available hours / month', type: 'number', value: person?.default_monthly_hours ?? 140, min: 0, max: 744, step: .5, required: true, hint: person ? 'Used where a month has no saved override. Use Capacity to change existing months.' : 'Initialises monthly availability for this person.' },
      { name: 'capacity_eligible', label: 'Track capacity', type: 'checkbox', value: person?.capacity_eligible ?? 1 }, ...(person ? [{ name: 'active', label: 'Active team member', type: 'checkbox', value: person.active }] : []),
    ], onSave: async (values) => { if (person) await api.updateResource(person.id, values); else await api.createResource(values); toast(person ? 'Person updated.' : 'Person added.'); await changed('resources'); } });
  }
  function editAvailability(person, fromMonth = currentMonth) {
    let months = monthsBetween(fromMonth, addMonths(fromMonth, 11)); const inputs = {};
    const start = field({ name: 'start', label: 'From month', type: 'month', value: months[0], required: true }), end = field({ name: 'end', label: 'Through month', type: 'month', value: months.at(-1), required: true }), bulk = field({ name: 'bulk', label: 'Hours per month', type: 'number', value: person.default_monthly_hours ?? 140, min: 0, max: 744, step: .5 }), monthsHost = h('div', { class: 'op-month-grid' });
    function drawMonths() { clear(monthsHost); months = monthsBetween(start.input.value, end.input.value); if (months.length > 24) { monthsHost.appendChild(h('p', { text: 'Choose a period of up to 24 months.' })); return; } months.forEach((month) => { const c = field({ name: month, label: fmtMonth(month), type: 'number', value: inputs[month]?.value ?? availableFor(person, month), required: true, min: 0, max: 744, step: .5 }); inputs[month] = c.input; monthsHost.appendChild(c.el); }); }
    start.input.addEventListener('change', drawMonths); end.input.addEventListener('change', drawMonths);
    const apply = button('Apply to period', () => { if (bulk.input.value !== '' && bulk.input.reportValidity()) months.forEach((m) => { if (inputs[m]) inputs[m].value = bulk.input.value; }); });
    const extra = h('div', {}, h('div', { class: 'op-form-grid' }, start.el, end.el), h('div', { class: 'op-toolbar op-form-section' }, bulk.el, apply), monthsHost); drawMonths();
    editor({ title: `Monthly availability · ${person.name}`, intro: 'Set working capacity after leave and other commitments. Enter 0 for a month with no availability.', extra, validate: () => { if (!months.length || months.length > 24) throw new Error('Choose a valid period of up to 24 months.'); }, onSave: async () => { await api.setAvailability(person.id, Object.fromEntries(months.map((m) => [m, Number(inputs[m].value)]))); toast('Monthly availability saved.'); await changed('availability'); } });
  }
  function editSkills(person) {
    const rows = [], host = h('div', { class: 'op-form-section' });
    function addRow(skill = '', level = 1) {
      const name = h('input', { class: 'input', type: 'text', value: skill, maxlength: 60, placeholder: 'Skill name', 'aria-label': 'Skill name' }), select = h('select', { class: 'input', 'aria-label': 'Skill level' }, [1, 2, 3].map((value) => h('option', { value }, `${value} · ${['Working', 'Strong', 'Expert'][value - 1]}`))); select.value = level;
      const row = { name, select, removed: false }, el = h('div', { class: 'op-skill-row' }, name, select, button('×', () => { row.removed = true; el.remove(); }, { kind: 'text', attrs: { 'aria-label': 'Remove skill' } })); rows.push(row); host.appendChild(el);
    }
    (person.skills || []).forEach((s) => addRow(s.skill, s.level)); if (!rows.length) addRow();
    editor({ title: `Skills · ${person.name}`, intro: 'Rate skills from 1 (working) to 3 (expert). These ratings are entered and maintained by your team.', extra: h('div', {}, host, button('Add skill', () => addRow())), onSave: async () => {
      const skills = Object.fromEntries((person.skills || []).map((s) => [s.skill, 0])), names = new Set();
      for (const row of rows.filter((r) => !r.removed)) { const name = row.name.value.trim(); if (!name) continue; if (names.has(name.toLowerCase())) throw new Error(`Enter ${name} once.`); names.add(name.toLowerCase()); skills[name] = Number(row.select.value); }
      if (Object.keys(skills).length) await api.setResourceSkills(person.id, skills); toast('Skills saved.'); await changed('skills');
    } });
  }
  function editAllocation(allocation = null, person = null, month = currentMonth) {
    const availablePeople = people.filter((p) => p.active !== 0 || p.id === allocation?.resource_id);
    if (!availablePeople.length || !initiatives.length) { openModal({ title: 'Set up an allocation', body: h('div', {}, h('p', { text: !availablePeople.length ? 'Add a person before allocating hours.' : 'Create or import an initiative before allocating hours.' }), !initiatives.length ? h('a', { class: 'btn btn-primary', href: '#/initiative/new', text: 'Add initiative' }) : null), actions: [{ label: 'Close' }] }); return; }
    editor({ title: allocation ? 'Edit allocation' : 'Allocate hours', intro: 'Assign monthly effort to an initiative. Utilisation updates immediately after saving.', fields: [
      { name: 'resource_id', label: 'Person', type: 'select', required: true, value: allocation?.resource_id ?? person?.id ?? '', options: [{ value: '', label: 'Select person' }, ...availablePeople.map((p) => ({ value: p.id, label: `${p.name}${p.team ? ` · ${p.team}` : ''}` }))] },
      { name: 'initiative_id', label: 'Initiative', type: 'select', required: true, value: allocation?.initiative_id ?? initiativeFilter, options: [{ value: '', label: 'Select initiative' }, ...initiatives.map((i) => ({ value: i.id, label: `${i.rddc} · ${i.name}` }))] },
      { name: 'month', label: 'Month', type: 'month', value: allocation?.month || month, required: true }, { name: 'hours', label: 'Allocated hours', type: 'number', value: allocation?.hours ?? '', required: true, min: 0, max: 744, step: .5 },
      { name: 'firmness', label: 'Commitment', type: 'select', value: allocation?.firmness || 'tentative', options: [{ value: 'tentative', label: 'Tentative' }, { value: 'confirmed', label: 'Confirmed' }] },
    ], onSave: async (values) => { values.resource_id = Number(values.resource_id); values.initiative_id = Number(values.initiative_id); if (allocation) await api.updateAllocation(allocation.id, values); else await api.createAllocation(values); toast('Allocation saved.'); await changed('allocations'); } });
  }
  function showMonth(person, month) {
    const rows = allocations.filter((a) => a.resource_id === person.id && a.month === month), available = availableFor(person, month), booked = loadFor(person.id, month); let dialog;
    dialog = openModal({ title: `${person.name} · ${fmtMonth(month)}`, width: 900, body: h('div', {}, h('div', { class: 'op-detail-metrics' }, metric('Available', fmtHours(available)), metric('Allocated', fmtHours(booked)), metric('Remaining capacity', fmtHours(available - booked), null, booked > available ? 'over' : '')), allocationTable(rows, () => dialog.close())), actions: [{ label: 'Edit capacity', onClick: () => editAvailability(person, month) }, { label: 'Allocate hours', variant: 'primary', onClick: () => editAllocation(null, person, month) }] });
  }
  return () => { disposed = true; if (heat) heat.destroy(); };
}
