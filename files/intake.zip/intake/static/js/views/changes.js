// Change Management (#/changes): weekly CRQ review (next 14 days, compliance flags), Governance Reviews approval
// queue (L2, component approvals, STO decisions), release-train calendar with the change freeze.
import {
  api, h, clear, card, dataTable, button, pageHeader, errorBox, loading, chip, statusPill, ragPill,
  fmtDate, fmtDateTime, fmtDayLong, getToday, getSettingsSafe, go, itemsOf, toast, isoWeek, shiftWeek, announceChange, framePage,
} from '../charts/kit.js';
import { renderReleaseCalendar } from '../charts/trains.js';

const KIND_LABEL = { l2: 'L2 approval', component: 'Component approval', sto: 'STO decision' };

function initiativeLink(ctx, id, text, tab = 'pg4') {
  return h('a', { class: 'dv-link', href: `#/initiative/${id}/${tab}`, on: { click: (e) => { e.preventDefault(); go(ctx, `#/initiative/${id}/${tab}`); } } }, text || '—');
}
const FINDING = {
  Pass: ['✓', 'green', 'Pass'],
  Fail: ['✗', 'red', 'Fails'],
  Warn: ['!', 'amber', 'Check'],
  'Not due': ['○', 'grey', 'Not due yet'],
  'Not due yet': ['○', 'grey', 'Not due yet'],
  'N/A': ['–', 'grey', 'Does not apply'],
};
function savedReview(r) {
  const c = r.compliance || {};
  const cached = r.compliance_json && typeof r.compliance_json === 'object' ? r.compliance_json : {};
  return c.ai || cached.ai || null;
}
/** One finding: icon + rule + what to do. A Pass never carries a "fix"; a not-yet-due rule is neutral, not Pass. */
export function findingRow(f) {
  const [icon, tone, word] = FINDING[f.status] || ['○', 'grey', f.status || 'Check'];
  return h('li', { class: `dv-finding dv-finding-${tone}` },
    h('span', { class: 'dv-finding-icon', 'aria-hidden': 'true', text: icon }),
    h('span', { class: 'dv-finding-text' },
      h('strong', { text: `${f.rule_id ? `${f.rule_id} ` : ''}${f.rule || ''}` }),
      h('span', { class: 'dv-sr', text: ` ${word}.` }),
      f.status === 'Not due yet' && f.due_date ? h('span', { class: 'dv-finding-due', text: ` Due by ${fmtDayLong(f.due_date)}` }) : null,
      f.status !== 'Pass' && f.detail ? h('span', { class: 'dv-muted', text: ` ${f.detail}` }) : null,
      f.status !== 'Pass' && f.fix ? h('span', { class: 'dv-finding-fix', text: `Fix: ${f.fix}` }) : null));
}
function reviewCell(r) {
  const review = savedReview(r);
  if (!review) return h('span', { class: 'dv-muted', text: 'Not reviewed yet' });
  const findings = Array.isArray(review.findings) ? review.findings : [];
  const failing = findings.filter((f) => f.status === 'Fail');
  const details = h('details', { class: 'dv-review' },
    h('summary', {}, `Score ${Number.isFinite(Number(review.score)) ? `${review.score}%` : '—'} · ${review.sto_readiness || 'STO readiness not set'}`),
    review.reviewer_note ? h('p', { text: review.reviewer_note }) : null,
    findings.length ? h('ul', { class: 'dv-findings' }, [...failing, ...findings.filter((f) => f.status !== 'Fail')].map(findingRow)) : null,
    review.reviewed_at ? h('div', { class: 'dv-muted', text: `Saved ${fmtDate(String(review.reviewed_at).slice(0, 10))}${review.reviewed_by ? ` by ${review.reviewed_by}` : ''}` }) : null);
  return details;
}

function flagChips(compliance) {
  const flags = compliance && Array.isArray(compliance.flags) ? compliance.flags : [];
  const findings = compliance && Array.isArray(compliance.findings) ? compliance.findings : [];
  const notDue = findings.filter((f) => f.status === 'Not due yet');
  const out = h('div', { class: 'dv-flags dv-flags-wrap' },
    flags.length ? flags.map((f) => chip(f.message || f.code, f.severity === 'warn' || f.status === 'Warn' ? 'amber' : 'red', { title: f.code || null })) : chip(notDue.length ? 'No issues so far' : 'Compliant', 'green'),
    notDue.length ? chip(`${notDue.length} not due yet`, '', { title: notDue.map((f) => `${f.rule_id || ''} ${f.rule || ''}${f.due_date ? ` · due by ${fmtDayLong(f.due_date)}` : ''}`.trim()).join('\n') }) : null);
  if (!findings.length) return out;
  const order = { Fail: 0, Warn: 1, 'Not due yet': 2, Pass: 3 };
  return h('div', {}, out, h('details', { class: 'dv-review' },
    h('summary', {}, `All ${findings.length} checks`),
    h('ul', { class: 'dv-findings' }, findings.slice().sort((a, b) => (order[a.status] ?? 4) - (order[b.status] ?? 4)).map(findingRow))));
}

export async function render(root, params, ctx) {
  const page = framePage(root, 'changes');
  page.appendChild(pageHeader({ title: 'Change Management', hint: 'Weekly CRQ review every Monday · governance approvals · release trains and the change freeze' }));
  const weeklyCard = card('Weekly CRQ review');
  const approvalsCard = card('Governance Reviews');
  const trainsCard = card('Release train calendar');
  page.append(
    h('div', { class: 'dv-section', 'data-testid': 'weekly-crq' }, weeklyCard.el),
    h('div', { class: 'dv-section', 'data-testid': 'approvals' }, approvalsCard.el),
    h('div', { class: 'dv-section', 'data-testid': 'release-trains' }, trainsCard.el));

  const [today, settings] = await Promise.all([getToday(ctx), getSettingsSafe()]);
  let week = isoWeek(today);
  const cleanups = [];

  async function loadWeekly() {
    clear(weeklyCard.body);
    weeklyCard.body.appendChild(loading("Loading this week's CRQs…"));
    try {
      const data = await api.getGovernanceWeekly(week ? { week } : {});
      if (data.week) week = data.week;
      clear(weeklyCard.body);
      const items = itemsOf(data);
      const nc = Number(data.noncompliant_count) || items.filter((i) => i.compliance && i.compliance.flags && i.compliance.flags.length).length;
      weeklyCard.body.append(
        h('div', { class: 'dv-filters' },
          button('Previous week', () => { week = shiftWeek(week, -1); loadWeekly(); }, { kind: 'secondary' }),
          h('strong', { text: data.from ? `Week of ${fmtDayLong(data.from)} · CRQs starting ${fmtDate(data.from)} – ${fmtDate(data.to)} (this week and next)` : 'CRQs starting this week and next' }),
          button('Next week', () => { week = shiftWeek(week, 1); loadWeekly(); }, { kind: 'secondary' }),
          nc ? chip(`${nc} need${nc === 1 ? 's' : ''} attention`, 'red') : chip('All compliant', 'green')),
        dataTable({
          caption: 'Weekly CRQ review', sortKey: 'crq_start',
          empty: 'No CRQs start in this window.',
          onRowClick: (r) => go(ctx, `#/initiative/${r.initiative_id}/pg4`),
          columns: [
            { key: 'crq_number', label: 'CRQ/RCSR #', render: (r) => r.crq_number || 'Draft' },
            { key: 'rddc', label: 'RDDC #', render: (r) => initiativeLink(ctx, r.initiative_id, r.rddc) },
            { key: 'crq_start', label: 'Window', render: (r) => (r.crq_start ? `${fmtDateTime(r.crq_start)} – ${(r.crq_end || '').slice(11, 16) || '—'}` : '—') },
            { key: 'release_train', label: 'Release Train' },
            { key: 'release_type', label: 'Release Type' },
            { key: 'implementation_status', label: 'Implementation', render: (r) => statusPill(r.implementation_status) },
            { key: 'sto_approval', label: 'STO Approval', render: (r) => (r.sto_approval ? statusPill(r.sto_approval) : h('span', { class: 'dv-muted', title: 'STO approval is requested from T-5 business days', text: 'Not requested' })) },
            { key: 'compliance', label: 'Compliance flags', sortable: false, render: (r) => flagChips(r.compliance) },
            { key: 'ai_review', label: 'Saved AI review', sortable: false, render: (r) => reviewCell(r) },
          ],
          rows: items,
        }).el);
    } catch (err) {
      clear(weeklyCard.body);
      weeklyCard.body.appendChild(errorBox(err, loadWeekly));
    }
  }

  async function loadApprovals() {
    clear(approvalsCard.body);
    approvalsCard.body.appendChild(loading('Loading approvals…'));
    try {
      const items = itemsOf(await api.getApprovals());
      clear(approvalsCard.body);
      approvalsCard.body.append(
        h('p', { class: 'dv-muted', text: `Decisions are recorded as ${settings.persona || 'DC PM'}. Switch persona in the top bar to act as the approver.` }),
        dataTable({
          caption: 'Governance Reviews', sortKey: 'waiting_days', sortDir: 'desc',
          empty: 'Nothing is waiting for approval.',
          columns: [
            { key: 'kind', label: 'Type', render: (r) => KIND_LABEL[r.kind] || r.kind },
            { key: 'rddc', label: 'RDDC #', render: (r) => initiativeLink(ctx, r.initiative_id, r.rddc, r.kind === 'sto' ? 'pg4' : 'pg1') },
            { key: 'title', label: 'Item', cls: 'dv-cell-wrap', render: (r) => r.title || r.name },
            { key: 'requested_at', label: 'Requested', render: (r) => fmtDate(String(r.requested_at || '').slice(0, 10)) },
            { key: 'waiting_days', label: 'Waiting', align: 'right', render: (r) => (Number.isFinite(Number(r.waiting_days)) ? (Number(r.waiting_days) === 0 ? 'Since today' : `${r.waiting_days} business day${Number(r.waiting_days) === 1 ? '' : 's'}`) : '—'), sort: (r) => Number(r.waiting_days) || 0 },
            { key: 'approver', label: 'Approver' },
            { key: 'actions', label: 'Decision', sortable: false, render: (r) => decisionCell(r) },
          ],
          rows: items,
        }).el);
    } catch (err) {
      clear(approvalsCard.body);
      approvalsCard.body.appendChild(errorBox(err, loadApprovals));
    }
  }

  function decisionCell(item) {
    const comment = h('input', { class: 'dv-input', type: 'text', placeholder: item.kind === 'l2' ? 'Comment (required to reject)' : 'Comment', 'aria-label': `Comment for ${item.rddc} ${KIND_LABEL[item.kind] || ''}` });
    const wrap = h('div', { class: 'dv-approval-actions' }, comment);
    const act = async (approve, btn) => {
      const text = comment.value.trim();
      if (!approve && item.kind === 'l2' && !text) {
        comment.classList.add('is-invalid');
        comment.focus();
        toast('Enter a reason to reject the L2 estimate.', 'warning');
        return;
      }
      wrap.querySelectorAll('button').forEach((b) => { b.disabled = true; });
      try {
        if (item.kind === 'l2') {
          if (approve) await api.approveL2(item.initiative_id, text ? { comment: text } : {});
          else await api.rejectL2(item.initiative_id, { reason: text });
        } else if (item.kind === 'component') {
          await api.updateComponent(item.entity_id, { approval: approve ? 'Approved' : 'Rejected' });
        } else if (item.kind === 'sto') {
          await api.updateChangeRequest(item.entity_id, { sto_approval: approve ? 'Go' : 'No-Go' });
        }
        toast(`${KIND_LABEL[item.kind] || 'Item'} for ${item.rddc} ${approve ? 'approved' : 'rejected'}.`);
        announceChange(item.initiative_id, 'governance');
        await Promise.all([loadApprovals(), loadWeekly()]);
      } catch (err) {
        toast(err.message, 'warning');
        wrap.querySelectorAll('button').forEach((b) => { b.disabled = false; });
        if (btn) btn.focus();
      }
    };
    wrap.append(
      button(item.kind === 'sto' ? 'Go' : 'Approve', (e) => act(true, e.currentTarget), { kind: 'primary', small: true }),
      button(item.kind === 'sto' ? 'No-Go' : 'Reject', (e) => act(false, e.currentTarget), { kind: 'secondary', small: true, attrs: { class: 'btn-danger-text' } }));
    return wrap;
  }

  async function loadTrains() {
    clear(trainsCard.body);
    trainsCard.body.appendChild(loading('Loading release trains…'));
    try {
      const data = await api.listReleaseTrains();
      clear(trainsCard.body);
      const chartHost = h('div');
      trainsCard.body.appendChild(chartHost);
      const chart = renderReleaseCalendar(chartHost, data, { today });
      cleanups.push(() => chart.destroy());
      const freeze = data.freeze || {};
      if (freeze.start) trainsCard.body.appendChild(h('p', { class: 'dv-muted', text: `Change freeze ${fmtDayLong(freeze.start)} – ${fmtDayLong(freeze.end)}. Production implementations cannot be scheduled inside it.` }));
      const grid = h('div', { class: 'dv-train-cards' });
      for (const t of itemsOf(data)) {
        const inits = Array.isArray(t.initiatives) ? t.initiatives : [];
        grid.appendChild(h('article', { class: `dv-train-card${t.status === 'Done' ? ' is-done' : ''}${t.in_freeze ? ' is-freeze' : ''}` },
          h('h3', { text: t.code }),
          h('div', { class: 'dv-muted', text: `${fmtDayLong(t.train_date)} · ${t.status === 'Done' ? 'Released' : t.in_freeze ? 'Inside the freeze' : 'Planned'}` }),
          inits.length
            ? h('ul', {}, inits.map((i) => h('li', {}, ragPill(i.rag), initiativeLink(ctx, i.id, i.rddc, 'pg5'), h('span', { class: 'dv-cell-clip', title: i.name, text: i.name }))))
            : h('p', { class: 'dv-muted', text: 'No initiatives on this train.' })));
      }
      trainsCard.body.appendChild(grid);
    } catch (err) {
      clear(trainsCard.body);
      trainsCard.body.appendChild(errorBox(err, loadTrains));
    }
  }

  await Promise.all([loadWeekly(), loadApprovals(), loadTrains()]);
  return () => cleanups.forEach((fn) => fn());
}
