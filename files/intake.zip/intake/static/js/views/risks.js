// Risk Register (#/risks): all risks across initiatives, filters, 4×4 matrix, links to initiatives.
import {
  api, h, clear, card, dataTable, pageHeader, errorBox, loading, selectEl, chip, getLookups, lookupLabel, lookupOptions,
  go, itemsOf, toast, num, fmtDate, announceChange, framePage,
} from '../charts/kit.js';
import { renderRiskMatrix, scoreClass } from '../charts/matrix.js';

const SCORE_CHIP = { 'm-red': 'red', 'm-orange': 'red', 'm-amber': 'amber', 'm-green': 'green' };

export async function render(root, params, ctx) {
  const page = framePage(root, 'risks');
  page.appendChild(pageHeader({ title: 'Risk Register', hint: 'All risks across initiatives · score = severity × likelihood' }));
  const body = h('div');
  page.appendChild(body);
  body.appendChild(loading('Loading risks…'));

  let lookups;
  let risks;
  try {
    [lookups, risks] = await Promise.all([getLookups(ctx), api.listRisks({})]);
  } catch (err) {
    clear(body);
    body.appendChild(errorBox(err, () => render(root, params, ctx)));
    return undefined;
  }
  clear(body);
  let all = itemsOf(risks);
  const filters = { rddc: '', category: '', status: 'open', min: '', cell: null };
  const sevLabels = Object.fromEntries((lookups.risk_severity || []).map((o) => [Number(o.value), o.label]));
  const likLabels = Object.fromEntries((lookups.risk_likelihood || []).map((o) => [Number(o.value), o.label]));
  const statusOptions = lookupOptions(lookups, 'risk_status');

  const matrixCard = card('Risk matrix', { right: h('span', { class: 'dv-muted', text: 'Click a cell to filter' }) });
  const tableCard = card('Risks');
  body.appendChild(h('div', { class: 'dv-grid-21' }, tableCard.el, matrixCard.el));
  const matrix = renderRiskMatrix(matrixCard.body, all, {
    severityLabels: sevLabels, likelihoodLabels: likLabels,
    onCellClick: (sev, lik) => {
      filters.cell = filters.cell && filters.cell.severity === sev && filters.cell.likelihood === lik ? null : { severity: sev, likelihood: lik };
      apply();
    },
  });

  const rddcs = [...new Map(all.map((r) => [r.rddc, r])).values()].filter((r) => r.rddc).sort((a, b) => a.rddc.localeCompare(b.rddc)).map((r) => ({ value: r.rddc, label: r.rddc }));
  const cellNote = h('span', { class: 'dv-muted' });
  tableCard.body.appendChild(h('div', { class: 'dv-filters' },
    selectEl(rddcs, '', (v) => { filters.rddc = v; apply(); }, { label: 'Initiative', allLabel: 'All initiatives' }),
    selectEl(lookupOptions(lookups, 'risk_category'), '', (v) => { filters.category = v; apply(); }, { label: 'Category', allLabel: 'All categories' }),
    selectEl([{ value: 'open', label: 'Open and mitigating' }, ...statusOptions], 'open', (v) => { filters.status = v; apply(); }, { label: 'Status', allLabel: 'All statuses' }),
    selectEl([{ value: '12', label: '12+ (critical)' }, { value: '8', label: '8+ (high)' }, { value: '4', label: '4+' }], '', (v) => { filters.min = v; apply(); }, { label: 'Score', allLabel: 'Any score' }),
    cellNote));

  const table = dataTable({
    caption: 'Risk Register',
    sortKey: 'score', sortDir: 'desc',
    empty: "No risks recorded. Use Predict risks on an initiative's Risks tab, or add one there.",
    columns: [
      { key: 'risk_code', label: 'Risk ID', cls: 'dv-nowrap', render: (r) => h('span', {}, r.risk_code || '—', r.source === 'ai' ? h('span', { class: 'dv-tag-ai', title: 'Predicted by AI and accepted by a person', text: ' AI' }) : null) },
      { key: 'rddc', label: 'RDDC #', render: (r) => h('a', { class: 'dv-link', href: `#/initiative/${r.initiative_id}/risks`, on: { click: (e) => { e.preventDefault(); go(ctx, `#/initiative/${r.initiative_id}/risks`); } } }, r.rddc || '—') },
      { key: 'title', label: 'Title · linked WBS', cls: 'dv-col-title', render: (r) => h('div', {}, r.title || '—', r.wbs_code ? h('div', { class: 'dv-muted', text: r.wbs_code }) : null) },
      { key: 'category', label: 'Category' },
      { key: 'severity', label: 'Severity × Likelihood', sort: (r) => num(r.severity) * 10 + num(r.likelihood), render: (r) => h('div', {}, lookupLabel(lookups, 'risk_severity', r.severity), h('div', { class: 'dv-muted', text: lookupLabel(lookups, 'risk_likelihood', r.likelihood) })) },
      { key: 'score', label: 'Score', align: 'right', sort: (r) => num(r.score ?? num(r.severity) * num(r.likelihood)), render: (r) => {
        const score = num(r.score ?? num(r.severity) * num(r.likelihood));
        return chip(String(score), SCORE_CHIP[scoreClass(score)]);
      } },
      { key: 'status', label: 'Status', render: (r) => statusSelect(r) },
      { key: 'owner_name', label: 'Owner' },
      { key: 'mitigation', label: 'Mitigation', render: (r) => (r.mitigation ? h('span', { class: 'dv-cell-clip dv-clip-120', title: r.mitigation, text: r.mitigation, tabindex: '0' }) : '—') },
    ],
    rows: [],
  });
  tableCard.body.appendChild(table.el);

  function statusSelect(r) {
    const sel = selectEl(statusOptions.length ? statusOptions : ['Open', 'Mitigating', 'Closed'].map((v) => ({ value: v, label: v })), r.status, async (v) => {
      sel.disabled = true;
      try {
        const updated = await api.updateRisk(r.id, { status: v });
        Object.assign(r, updated && typeof updated === 'object' ? updated : { status: v });
        toast(`${r.risk_code || 'Risk'} marked ${v}.`);
        announceChange(r.initiative_id, 'risks');
        apply();
      } catch (err) {
        sel.value = r.status;
        toast(err.message, 'warning');
      } finally {
        sel.disabled = false;
      }
    });
    sel.setAttribute('aria-label', `Status of ${r.risk_code || r.title}`);
    sel.classList.add('dv-status-select');
    return sel;
  }

  function apply() {
    const min = Number(filters.min) || 0;
    const rows = all.filter((r) => {
      const score = num(r.score ?? num(r.severity) * num(r.likelihood));
      if (filters.rddc && r.rddc !== filters.rddc) return false;
      if (filters.category && r.category !== filters.category) return false;
      if (filters.status === 'open' && r.status === 'Closed') return false;
      if (filters.status && filters.status !== 'open' && r.status !== filters.status) return false;
      if (min && score < min) return false;
      if (filters.cell && (num(r.severity) !== filters.cell.severity || num(r.likelihood) !== filters.cell.likelihood)) return false;
      return true;
    });
    table.update(rows);
    cellNote.textContent = filters.cell ? `Matrix filter: ${sevLabels[filters.cell.severity] || filters.cell.severity} × ${likLabels[filters.cell.likelihood] || filters.cell.likelihood}` : `${rows.length} of ${all.length} risks`;
    matrix.update(all.filter((r) => (!filters.rddc || r.rddc === filters.rddc) && (!filters.category || r.category === filters.category)), { selected: filters.cell });
  }
  apply();
  const due = all.filter((r) => r.due_date && r.status !== 'Closed').sort((a, b) => a.due_date.localeCompare(b.due_date))[0];
  if (due) matrixCard.body.appendChild(h('p', { class: 'dv-muted', text: `Next mitigation due: ${due.risk_code || ''} ${fmtDate(due.due_date)}` }));
  return () => { all = []; matrix.destroy(); };
}
