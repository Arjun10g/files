const INTAKE_FIELDS = ['name','lob','priority','requestor','description','requested_go_live','target_release','prn_code','dc_pm','dc_sa','tech_lead','pm','assigned_to','business_analyst','owner','funding_name','funded_hours','rate','budget_amount','currency','decision','charge_type','start_month','end_month','funding_scope','funding_assumptions','jira_key','jira_status','project_key','platform','region','channel','apt_number','external_pr_code','solution_concurrence_date','labels'];
const FUNDING_FIELDS = ['prn_code','name','lob','funded_hours','rate','budget_amount','currency','start_month','end_month','month','charged_hours','charged_amount','decision','charge_type','phase','appcat','team','sto','hours','amount','scope','assumptions','notes'];
const LABELS = { name: 'Project name', lob: 'Line of business', prn_code: 'PRN / funding code', jira_key: 'Jira key', external_key: 'Source ticket key', requested_go_live: 'Requested go-live', external_pr_code: 'External team PR code', apt_number: 'APT number', dc_pm: 'DC project manager', dc_sa: 'Solution architect', tech_lead: 'Technical lead', pm: 'Project manager', assigned_to: 'Assigned to', owner: 'Funding owner', rate: 'Funding hourly rate', decision: 'Funding decision', charge_type: 'Project / POD charging' };
const label = k => LABELS[k] || k.replaceAll('_', ' ').replace(/^./, c => c.toUpperCase());

export async function render(root, params, ctx) {
  const { api, ui, state, navigate } = ctx;
  const { h } = ui;
  await state.loadLookups();
  let type = params.query?.type === 'funding' ? 'funding' : 'intake';
  let batch = null;
  let activeRow = 0;
  const stage = h('div.stack');
  const errorSlot = h('div', { attrs: { role: 'alert' } });
  const page = h('div.view-pad');
  root.append(page);
  const heading = h('div');
  page.append(heading, errorSlot, stage);
  function header(step) {
    ui.mount(heading, ui.pageBox({ title: type === 'funding' ? 'Import funding' : 'Import initiatives', hint: 'Rules extract the information. You review it before it enters the portfolio.' },
      h('ol.import-steps', ...['Choose source', 'Review fields', 'Save records'].map((t, i) => h(`li${i <= step ? '.active' : ''}`, h('span', String(i + 1)), t)))));
  }
  function fail(err) {
    ui.mount(errorSlot, ui.errorPanel(err), ...Object.entries(err.details?.fields || {}).map(([key, value]) => h('p.field-error', `${label(key)}: ${value}`)));
    errorSlot.scrollIntoView({ block: 'nearest' });
  }
  async function preview(body, form) {
    ui.mount(errorSlot);
    batch = await api.request('POST', '/imports/preview', form ? { form, timeout: 60000 } : { body, timeout: 60000 });
    activeRow = 0; review();
  }
  async function loadBatch(id) {
    batch = await api.request('GET', `/imports/${encodeURIComponent(id)}`);
    type = batch.type || type;
    if (batch.status === 'committed') completed(batch.result || batch); else review();
  }
  function source() {
    header(0);
    const kind = ui.selectEl([{ value: 'intake', label: 'Initiatives / Jira workbook' }, { value: 'funding', label: 'Funding / estimates' }], type, { ariaLabel: 'Import type' });
    kind.addEventListener('change', () => { type = kind.value; source(); });
    const file = h('input.input', { type: 'file', accept: '.xlsx,.xlsm,.csv,.docx,.pdf,.md,.txt,.json', aria: { label: 'Choose workbook or document' } });
    const upload = ui.btn('Read file', { variant: 'primary', onClick: async () => {
      if (!file.files[0]) { ui.toast('Choose a file first.', { variant: 'warning' }); return; }
      const restore = ui.busy(upload, 'Reading…');
      const form = new FormData(); form.append('file', file.files[0]); form.append('type', type);
      try { await preview(null, form); } catch (err) { fail(err); } finally { restore(); }
    } });
    const text = h('textarea.input', { rows: 10, placeholder: 'Paste the full SA document or intake text here…', aria: { label: 'Document text' } });
    const readText = ui.btn('Read pasted text', { variant: 'secondary', onClick: async () => {
      const restore = ui.busy(readText, 'Reading…');
      try { await preview({ type, text: text.value }); } catch (err) { fail(err); } finally { restore(); }
    } });
    const history = h('div.stack');
    api.request('GET', '/imports').then(result => {
      const items = result.items || [];
      if (items.length) ui.mount(history, h('h3', 'Recent imports'), ...items.slice(0, 8).map(b => h('button.import-history', { type: 'button', on: { click: () => loadBatch(b.id).catch(fail) } }, h('strong', b.filename || 'Pasted text / JSON'), h('span', `${b.type} · ${b.status} · ${b.created_at || ''}`))));
    }).catch(() => {});
    ui.mount(stage, ui.card({ title: 'Upload a source' }, h('label.form-field', h('span.form-label', 'What are you importing?'), kind),
      h('p.muted', 'Excel .xlsx / .xlsm, CSV, Word .docx, text-based PDF, Markdown, text, or JSON · maximum 10 MB. Multiple sheets and repeated Jira columns are retained.'),
      file, h('div.btn-row', upload, h('a.btn.btn-secondary', { href: `/api/imports/templates/${type}.xlsx`, download: '' }, 'Download blank Excel template'))),
      ui.card({ title: type === 'funding' ? 'Or paste funding confirmation text' : 'Or paste document text' }, text, readText), history);
  }
  function review() {
    header(1);
    const rows = batch.rows || [];
    const fields = type === 'funding' ? FUNDING_FIELDS : INTAKE_FIELDS;
    const list = h('div.import-row-list');
    const editor = h('div.import-editor');
    const summary = h('p.muted', `${batch.filename || 'Pasted source'} · ${rows.length} records · ${(batch.sheets || []).map(s => typeof s === 'string' ? s : s.name || s.sheet || '').filter(Boolean).join(', ')}`);
    function paintList() {
      ui.mount(list, ...rows.map((row, index) => {
        const check = h('input', { type: 'checkbox', checked: row.selected !== false, aria: { label: `Include row ${index + 1}` }, on: { change: e => { row.selected = e.target.checked; } } });
        return h(`div.import-row${index === activeRow ? '.active' : ''}`, check,
          h('button', { type: 'button', on: { click: () => { activeRow = index; paintList(); paintEditor(); } } },
            h('strong', row.fields?.name || row.fields?.prn_code || `Row ${index + 1}`),
            h('span', [row.fields?.jira_key, `Row ${index + 1}`, row.duplicate ? 'Duplicate — check before saving' : '', Object.keys(row.errors || {}).length ? 'Needs review' : 'Ready to review'].filter(Boolean).join(' · '))));
      }));
    }
    function paintEditor() {
      const row = rows[activeRow];
      if (!row) { ui.mount(editor, h('p', 'No importable records found. Check the source or map its columns.')); return; }
      row.fields ||= {};
      const grid = h('div.form-grid');
      const extraGrid = h('div.form-grid');
      const connectionsGrid = h('div.form-grid');
      const connectionFields = new Set(['dc_pm','dc_sa','tech_lead','pm','assigned_to','business_analyst','owner','funding_name','funded_hours','rate','budget_amount','currency','decision','charge_type','start_month','end_month','funding_scope','funding_assumptions']);
      const primaryFields = new Set(type === 'intake' ? ['name','lob','priority','requestor','description','requested_go_live','prn_code']
        : ['prn_code','name','funded_hours','rate','budget_amount','currency','month','charged_hours','charged_amount','appcat','team','sto','phase','hours','amount','decision']);
      for (const key of fields) {
        const value = row.fields[key];
        const multiline = ['description','scope','assumptions','funding_scope','funding_assumptions'].includes(key);
        const control = key === 'lob' ? ui.selectEl(state.options('lob'), value || '', { placeholder: 'Choose line of business', ariaLabel: label(key) })
          : key === 'priority' ? ui.selectEl(state.options('priority'), value || '', { placeholder: 'Choose priority', ariaLabel: label(key) })
          : h(multiline ? 'textarea.input' : 'input.input', {
            type: multiline ? undefined : /date$|go_live$/.test(key) ? 'date' : key.endsWith('month') || key === 'month' ? 'month' : 'text',
            rows: key === 'description' ? 6 : 3, value: Array.isArray(value) ? value.join(', ') : value ?? '', aria: { label: label(key) } });
        const change = () => { row.fields[key] = key === 'priority' ? Number(control.value) || null : control.value; };
        control.addEventListener('input', change); control.addEventListener('change', change);
        (type === 'intake' && connectionFields.has(key) ? connectionsGrid : primaryFields.has(key) ? grid : extraGrid).append(h(`label.form-field${multiline ? '.span-2' : ''}`, h('span.form-label', label(key)), control,
          row.errors?.[key] ? h('span.field-error', String(row.errors[key])) : null));
      }
      const warnings = Array.isArray(row.warnings) ? row.warnings : Object.values(row.warnings || {});
      ui.mount(editor, h('h3', `Review record ${activeRow + 1} of ${rows.length}`),
        Object.keys(row.errors || {}).length ? h('div.notice.notice-amber',
          h('strong', 'Resolve these fields before saving:'),
          h('ul', ...Object.entries(row.errors).map(([key, message]) => h('li', `${label(key.replace(/^funding\./, ''))}: ${message}`))),
          type === 'intake' && row.fields.prn_code ? h('p', h('a', { href: `#/funding?prn=${encodeURIComponent(row.fields.prn_code)}` }, 'Review the shared funding entry'), ' to update confirmed figures, or clear the imported financial values to reuse its existing budget.') : null) : null,
        row.duplicate ? h('div.notice.notice-amber', `Possible duplicate: ${typeof row.duplicate === 'string' ? row.duplicate : JSON.stringify(row.duplicate)}. Deselect it or resolve its key before saving.`) : null,
        warnings.length ? h('ul.import-warnings', ...warnings.map(w => h('li', typeof w === 'string' ? w : JSON.stringify(w)))) : null,
        grid,
        type === 'intake' ? h('details.source-evidence', { open: [...connectionFields].some(key => row.errors?.[key] || row.fields[key] !== undefined && row.fields[key] !== '') }, h('summary', 'People and funding from this intake'),
          h('p.muted', 'Saved intake names become reusable people. New funding codes become linked entries. Enter capacity, rates, and approvals when confirmed.'), connectionsGrid) : null,
        h('details.source-evidence', { open: fields.some(key => !primaryFields.has(key) && !connectionFields.has(key) && row.errors?.[key]) }, h('summary', 'Source, delivery, and additional fields'), extraGrid),
        h('details.source-evidence', h('summary', 'Original source and extraction evidence'), h('pre', JSON.stringify({ source: row.source, raw: row.raw, evidence: row.evidence }, null, 2))));
    }
    const validate = ui.btn('Validate changes', { variant: 'secondary', onClick: async () => {
      const restore = ui.busy(validate, 'Validating…');
      try { batch = await api.request('PUT', `/imports/${batch.id}`, { body: reviewBody(rows) }); ui.mount(errorSlot); review(); ui.toast('Validation refreshed. Review warnings before saving.'); } catch (err) { fail(err); } finally { restore(); }
    } });
    const save = ui.btn('Save selected records', { variant: 'primary', onClick: async () => {
      if (!rows.some(r => r.selected !== false)) { ui.toast('Select at least one record.', { variant: 'warning' }); return; }
      const restore = ui.busy(save, 'Saving…');
      try {
        batch = await api.request('PUT', `/imports/${batch.id}`, { body: reviewBody(rows) });
        if ((batch.rows || []).filter(r => r.selected !== false).some(r => Object.keys(r.errors || {}).length)) { review(); ui.toast('Resolve the highlighted errors or deselect those records.', { variant: 'warning' }); return; }
        const result = await api.request('POST', `/imports/${batch.id}/commit`, { body: {}, timeout: 60000 });
        await state.loadLookups(true); state.emit('ai:applied', { feature: 'import' }); completed(result);
      } catch (err) { fail(err); } finally { restore(); }
    } });
    const mapping = h('details.source-evidence', h('summary', 'Column mapping'));
    const mappingGrid = h('div.form-grid');
    const mapped = { ...(batch.mapping || {}) };
    const columns = (batch.columns || []).map(c => typeof c === 'string' ? c : c.name || c.header || c.key).filter(Boolean);
    for (const column of columns) {
      const mappingFields = [...new Set([...fields, ...Object.values(batch.mapping || {}).filter(Boolean)])];
      const select = ui.selectEl(mappingFields.map(key => ({ value: key, label: label(key) })), mapped[column] || '', { placeholder: 'Keep as source only', ariaLabel: `Map column ${column}` });
      select.addEventListener('change', () => { mapped[column] = select.value; });
      mappingGrid.append(h('label.form-field', h('span.form-label', column), select));
    }
    mapping.append(mappingGrid, ui.btn('Apply mapping', { onClick: async () => {
      try { batch = await api.request('PUT', `/imports/${batch.id}`, { body: { mapping: mapped } }); review(); } catch (err) { fail(err); }
    } }));
    const document = batch.document;
    const evidence = document ? ui.card({ title: type === 'funding' ? 'Funding source document' : 'Document coverage and component review' },
      h('p.muted', type === 'funding' ? `${document.characters || document.text?.length || 0} characters read. Explicit budget values and estimate lines are extracted for review.` : `${document.characters || document.text?.length || 0} characters read · ${document.coverage || 0}% of section types found. Coverage checks headings and text; it does not validate the architecture.`),
      type === 'intake' ? ui.meter(document.coverage || 0) : null,
      h('div.btn-row', ...(document.sections || []).map(section => h('span.pill.pill-green', section.name))),
      document.metrics?.length ? h('div.btn-row', ...document.metrics.map(metric => h('span.pill.pill-blue', { title: `Source line ${metric.line}: ${metric.evidence}` }, `${metric.label}: ${metric.value}`))) : null,
      type === 'intake' && document.missing_sections?.length ? h('p.muted', `Sections to check: ${document.missing_sections.join(', ')}`) : null,
      type === 'intake' ? h('p', 'Select the evidenced component impacts to add to the Change Summary. Approvals remain pending until confirmed.') : null,
      ...(type === 'intake' ? document.components || [] : []).map(component => h('label.import-component',
        h('input', { type: 'checkbox', checked: !!component.selected, on: { change: e => { component.selected = e.target.checked; } } }),
        h('span', h('strong', `${component.code || component.component_code || ''} · ${component.name || component.component_name || ''}`),
          h('span.muted', ` ${component.evidence || component.excerpt || ''}`)))),
      h('details.source-evidence', h('summary', 'Read the full extracted document'), h('pre', document.text || '')),
      batch.source_url ? h('a', { href: batch.source_url, download: '' }, 'Download original source') : null) : null;
    ui.mount(stage, ui.card({ title: 'Review before saving' }, summary,
      h('div.btn-row', ui.btn('Select all', { onClick: () => { rows.forEach(r => r.selected = true); paintList(); } }),
        ui.btn('Deselect all', { onClick: () => { rows.forEach(r => r.selected = false); paintList(); } })),
      h('div.import-workbench', list, editor)), columns.length ? mapping : null, evidence,
      h('div.page-footer', ui.btn('Start another import', { onClick: () => { batch = null; source(); } }), validate, save));
    paintList(); paintEditor();
  }
  function completed(result) {
    header(2); ui.mount(errorSlot);
    result = result.result || result;
    const created = result.items || result.initiatives || (Array.isArray(result.created) ? result.created : []);
    ui.mount(stage, ui.card({ title: 'Import saved' }, h('p', type === 'intake' ? 'The selected intakes are saved. Their people and funding details are available in Resources and Funding, ready to complete.' : 'The selected funding records are saved. Continue planning and resource allocation in the portal.'),
      h('div.btn-row', ui.btn(type === 'funding' ? 'Open funding' : 'Open portfolio', { variant: 'primary', onClick: () => navigate(type === 'funding' ? '#/funding' : '#/portfolio') }),
        ui.btn('Import another file', { onClick: () => { batch = null; source(); } })),
      ...((Array.isArray(created) ? created : []).map(record => { const i = record.initiative || record; const id = i.id || i.initiative_id; return id && i.rddc ? h('p', h('a', { href: `#/initiative/${id}/pg1` }, `${i.rddc} · ${i.name || ''}`)) : null; }))));
  }
  function reviewBody(rows) {
    const body = { rows };
    if (batch.document && type === 'intake') body.components = (batch.document.components || []).map(c => ({ id: c.id, selected: !!c.selected }));
    return body;
  }
  if (params.query?.batch) await loadBatch(params.query.batch); else source();
}
