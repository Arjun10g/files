// Outbox (#/outbox): every reminder, invite and notice the tool "sends". Nothing is really emailed.
import {
  api, h, clear, card, dataTable, autoButton, button, pageHeader, errorBox, loading, selectEl, chip, statusPill,
  fmtDate, fmtDay, fmtDateTime, getLookups, go, itemsOf, runAi, toast, announceChange, framePage,
} from '../charts/kit.js';

export const RULE_LABEL = {
  grooming_invite: 'Grooming invite', sa_action_required: 'SA action required', component_approval: 'Component approval',
  l2_approval: 'L2 approval reminder', l2_escalation: 'L2 escalation', cr_noncompliance: 'CRQ compliance', validation_missing: 'Validation evidence missing',
  backout_missing: 'Backout plan missing', ai_nudge: 'Consolidated reminder', manual: 'Manual',
};

export async function render(root, params, ctx) {
  const page = framePage(root, 'outbox');
  const aiHost = h('div', { class: 'dv-ai-host', hidden: true });
  const draftBtn = autoButton('Draft reminders', () => draft());
  const runBtn = button('Run reminders now', () => runNow(), { kind: 'secondary' });
  page.appendChild(pageHeader({ title: 'Outbox', hint: 'Reminders, invites and notices queued by the tool · nothing is emailed from this demo', actions: [draftBtn, runBtn] }));
  page.appendChild(aiHost);
  const listCard = card('Messages');
  const detail = h('div', { class: 'dv-detail', hidden: true, 'aria-live': 'polite' });
  page.append(h('div', { class: 'dv-section', 'data-testid': 'outbox-list' }, listCard.el), detail);

  const lookups = await getLookups(ctx).catch(() => ({}));
  const statusOptions = Array.isArray(lookups.notification_status) && lookups.notification_status.length
    ? lookups.notification_status.map((o) => ({ value: String(o.value), label: o.label || String(o.value) }))
    : ['Queued', 'Sent', 'Acknowledged', 'Dismissed'].map((v) => ({ value: v, label: v }));
  const filters = { status: '', rule: '' };
  const countsHost = h('div', { class: 'dv-counts' });
  const tableHost = h('div');
  listCard.body.append(h('div', { class: 'dv-filters' },
    selectEl(statusOptions, '', (v) => { filters.status = v; load(); }, { label: 'Status', allLabel: 'All statuses' }),
    selectEl(Object.entries(RULE_LABEL).map(([value, label]) => ({ value, label })), '', (v) => { filters.rule = v; load(); }, { label: 'Trigger type', allLabel: 'All types' }),
    countsHost), tableHost);

  async function load() {
    clear(tableHost);
    tableHost.appendChild(loading('Loading the Outbox…'));
    try {
      const res = await api.listOutbox({ status: filters.status, rule: filters.rule });
      const items = itemsOf(res);
      clear(tableHost);
      clear(countsHost);
      const counts = res.counts || {};
      countsHost.append(chip(`${counts.Queued ?? items.filter((i) => i.status === 'Queued').length} queued`, 'amber'), chip(`${counts.Sent ?? items.filter((i) => i.status === 'Sent').length} sent`, 'blue'));
      tableHost.appendChild(dataTable({
        caption: 'Outbox', sortKey: 'due_at', empty: 'The Outbox is empty. Reminders appear here when someone needs to act.',
        onRowClick: (r) => showDetail(r),
        columns: [
          { key: 'to_name', label: 'To', render: (r) => h('div', {}, r.to_name, Array.isArray(r.cc_names) && r.cc_names.length ? h('div', { class: 'dv-muted', text: `cc ${r.cc_names.join(', ')}` }) : null) },
          { key: 'subject', label: 'Subject', cls: 'dv-cell-wrap', render: (r) => h('div', {}, r.subject, r.escalation_level ? h('span', { class: 'dv-chip dv-chip-red', text: `Escalation ${r.escalation_level}` }) : null) },
          { key: 'due_at', label: 'Due', render: (r) => (r.due_at ? fmtDateTime(r.due_at) : '—') },
          { key: 'action_required_by', label: 'Action required by', render: (r) => (r.action_required_by ? fmtDay(r.action_required_by) : '—') },
          { key: 'trigger_event', label: 'Trigger', cls: 'dv-cell-wrap', render: (r) => h('div', {}, RULE_LABEL[r.rule] || r.rule, r.trigger_event ? h('div', { class: 'dv-muted', text: r.trigger_event }) : null) },
          { key: 'status', label: 'Status', render: (r) => statusPill(r.status) },
          { key: 'actions', label: '', sortable: false, render: (r) => actions(r) },
        ],
        rows: items,
      }).el);
    } catch (err) {
      clear(tableHost);
      tableHost.appendChild(errorBox(err, load));
    }
  }

  function actions(r) {
    const wrap = h('div', { class: 'dv-approval-actions' });
    const act = async (fn, msg, btn) => {
      btn.disabled = true;
      try {
        await fn(r.id);
        toast(msg);
        announceChange(r.initiative_id, 'outbox');
        await load();
      } catch (err) {
        btn.disabled = false;
        toast(err.message, 'warning');
      }
    };
    if (r.status === 'Queued') {
      wrap.append(
        button('Send', (e) => act(api.sendOutboxItem, `Marked as sent to ${r.to_name}.`, e.currentTarget), { kind: 'secondary', small: true, attrs: { 'data-action': 'send' } }),
        button('Dismiss', (e) => act(api.dismissOutboxItem, 'Message dismissed.', e.currentTarget), { kind: 'text', small: true, attrs: { 'data-action': 'dismiss' } }));
    } else if (r.status === 'Sent') {
      wrap.append(button('Acknowledge', (e) => act(api.ackOutboxItem, `${r.to_name} acknowledged.`, e.currentTarget), { kind: 'secondary', small: true, attrs: { 'data-action': 'ack' } }));
    }
    return wrap.childNodes.length ? wrap : '';
  }

  function showDetail(r) {
    clear(detail);
    detail.hidden = false;
    detail.append(
      h('div', { class: 'dv-section-title' }, h('span', { text: r.subject }), button('Close', () => { detail.hidden = true; }, { kind: 'text' })),
      h('dl', { class: 'dv-kv' },
        h('dt', { text: 'To' }), h('dd', { text: r.to_name }),
        Array.isArray(r.cc_names) && r.cc_names.length ? [h('dt', { text: 'Cc' }), h('dd', { text: r.cc_names.join(', ') })] : null,
        h('dt', { text: 'Trigger' }), h('dd', { text: `${RULE_LABEL[r.rule] || r.rule}${r.trigger_event ? ` · ${r.trigger_event}` : ''}` }),
        r.action_required_by ? [h('dt', { text: 'Action required by' }), h('dd', { text: fmtDate(r.action_required_by) })] : null,
        r.sent_at ? [h('dt', { text: 'Sent' }), h('dd', { text: fmtDateTime(r.sent_at) })] : null),
      h('div', { class: 'dv-note-body is-open', text: r.body || '' }),
      r.initiative_id ? h('a', { class: 'dv-link', href: `#/initiative/${r.initiative_id}/pg1`, on: { click: (e) => { e.preventDefault(); go(ctx, `#/initiative/${r.initiative_id}/pg1`); } } }, r.rddc ? `Open ${r.rddc}` : 'Open the initiative') : null);
    detail.scrollIntoView({ block: 'nearest' });
  }

  async function runNow() {
    runBtn.disabled = true;
    try {
      const res = await api.runReminders({});
      const created = Array.isArray(res.created) ? res.created.length : 0;
      const skipped = Number(res.skipped) || 0;
      toast(created ? `${created} reminder${created === 1 ? '' : 's'} queued${skipped ? ` · ${skipped} already queued` : ''}.` : `No new reminders are due${skipped ? ` · ${skipped} already queued` : ''}.`);
      await load();
    } catch (err) {
      toast(err.message, 'warning');
    } finally {
      runBtn.disabled = false;
    }
  }

  function draft() {
    return runAi(aiHost, {
      feature: 'nudges', title: 'Reminders', trigger: draftBtn,
      preview: (run) => {
        const msgs = Array.isArray(run.output && run.output.messages) ? run.output.messages : [];
        if (!msgs.length) return h('p', { text: 'Nobody has open actions that need a reminder.' });
        return h('div', {},
          h('p', { text: `${msgs.length} consolidated message${msgs.length === 1 ? '' : 's'}, one per person.` }),
          ...msgs.map((m) => h('div', { class: 'dv-note' },
            h('div', { class: 'dv-note-head' }, h('span', { class: 'dv-note-title', text: `To ${m.recipient_name}${m.recipient_role ? ` (${m.recipient_role})` : ''}` }),
              h('span', {}, m.urgency && m.urgency !== 'Normal' ? chip(m.urgency, 'red') : null, m.action_required_by ? chip(`Action required by ${fmtDay(m.action_required_by)}`, 'amber') : null)),
            h('div', { class: 'dv-muted', text: m.subject }),
            h('div', { class: 'dv-note-body', text: m.body }))));
      },
      acceptMessage: (res) => {
        const n = res && res.applied ? Object.values(res.applied).reduce((a, b) => a + (Number(b) || 0), 0) : 0;
        return n ? `${n} reminder${n === 1 ? '' : 's'} queued in the Outbox.` : 'Reminders queued in the Outbox.';
      },
      onApplied: () => load(),
    });
  }

  await load();
  return undefined;
}
