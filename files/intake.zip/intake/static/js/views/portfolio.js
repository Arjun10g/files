// Portfolio View (#/portfolio, also home): Excel Pg 5 at portfolio scope (UX §2.5, PO §3 Pg 5).
import {
  api, h, clear, card, dataTable, ragPill, statusPill, chip, autoButton, pageHeader, errorBox, loading, emptyState,
  selectEl, fmtDate, fmtNum, getLookups, lookupOptions, getToday, go, itemsOf, runAi, bulletList, renderMarkdown,
  markdownToText, copyText, toast, bindTip, button, fiscalOf, monthKey, addMonths, monthsBetween, framePage, num, modal,
} from '../charts/kit.js';
import { renderPortfolioHealth } from '../charts/rag.js';
import { renderTeamBars } from '../charts/capacity.js';
import { renderPortfolioGantt } from '../charts/portfolio_gantt.js';
import { renderHeatmap } from '../charts/heatmap.js';
import { renderBurndown } from '../charts/burndown.js';

const RAG_RANK = { Red: 0, Amber: 1, Green: 2 };
const DIM_LABEL = { schedule: 'Schedule', resources: 'Resources', scope: 'Scope', dependencies: 'Dependencies', budget: 'Budget' };

// ------------------------------------------------------------------ shared pieces (also used by pg5_portfolio.js)

/** "17 Feb 27" style for dense dashboard columns; full date in the tooltip of the row via the sortable value. */
function fmtShortYear(iso) {
  const full = fmtDate(iso);
  return full === '—' ? full : full.replace(/ (\d{2})(\d{2})$/, ' $2');
}

/** KPI strip; each tile is a button when a handler is given (filters the dashboard or opens the matching page). */
export function kpiStrip(kpis = {}, on = {}) {
  const over = kpis.overallocated_people;
  const overCount = Array.isArray(over) ? over.length : fmtNum(over ?? 0);
  const overNote = Array.isArray(over) ? over.map((p) => (typeof p === 'string' ? p : p && p.name)).filter(Boolean).join(', ') : '';
  const tile = (key, label, value, cls = '', note = '', hint = '') => {
    const body = [h('div', { class: 'dv-kpi-label', text: label }), h('div', { class: 'dv-kpi-value', text: String(value) }), note ? h('div', { class: 'dv-kpi-note', text: note }) : null];
    if (typeof on[key] !== 'function') return h('div', { class: `dv-kpi ${cls}` }, body);
    return h('button', { type: 'button', class: `dv-kpi dv-kpi-link ${cls}`, title: hint, 'data-kpi': key, on: { click: on[key] } }, body);
  };
  return h('div', { class: 'dv-kpis', 'data-testid': 'kpi-strip' },
    tile('active', 'Active', fmtNum(kpis.active ?? 0), '', '', 'Show all initiatives on the Project Dashboard'),
    tile('red', 'Red', fmtNum(kpis.red ?? 0), 'dv-kpi-red', '', 'Show Red initiatives on the Project Dashboard'),
    tile('amber', 'Amber', fmtNum(kpis.amber ?? 0), 'dv-kpi-amber', '', 'Show Amber initiatives on the Project Dashboard'),
    tile('crqs', 'CRQs this week', fmtNum(kpis.crqs_this_week ?? 0), '', '', 'Open the weekly CRQ review'),
    tile('over', 'Over-allocated people', overCount, Number(Array.isArray(over) ? over.length : over) ? 'dv-kpi-red' : '', overNote, 'Open the Resources heatmap with over-allocated months highlighted'));
}

export function ragWithDims(row) {
  const pill = ragPill(row.rag);
  const dims = row.dimensions && typeof row.dimensions === 'object' ? row.dimensions : null;
  if (dims) {
    pill.tabIndex = 0;
    bindTip(pill, () => [`${row.rddc} health`, ...Object.entries(DIM_LABEL).map(([k, label]) => `${label}: ${dims[k] || 'Not scored'}`)]);
  } else if (!row.rag) pill.title = 'Health is calculated from the Planning stage onward';
  return pill;
}

export function projectColumns(ctx) {
  return [
    { key: 'rddc', label: 'Intake/RDDC #', render: (r) => h('a', { class: 'dv-link', href: `#/initiative/${r.id}/pg1`, on: { click: (e) => { e.preventDefault(); go(ctx, `#/initiative/${r.id}/pg1`); } } }, r.rddc) },
    { key: 'name', label: 'Project Name', cls: 'dv-col-name' },
    { key: 'lob', label: 'LOB' },
    { key: 'dc_pm_name', label: 'DC PM' },
    { key: 'stage', label: 'Stage' },
    { key: 'rag', label: 'RAG', render: ragWithDims, sort: (r) => (r.rag in RAG_RANK ? RAG_RANK[r.rag] : 3) },
    { key: 'target_release', label: 'Target Release', cls: 'dv-nowrap' },
    { key: 'readiness_date', label: 'Readiness Date', cls: 'dv-nowrap', render: (r) => (r.readiness_date ? fmtShortYear(r.readiness_date) : '—') },
    { key: 'qa_signoff_date', label: 'QA Sign-off', cls: 'dv-nowrap', render: (r) => (r.qa_signoff_date ? `✓ ${fmtShortYear(r.qa_signoff_date)}` : '—') },
    { key: 'prod_date', label: 'Prod/Final', cls: 'dv-nowrap', render: (r) => (r.prod_date ? fmtShortYear(r.prod_date) : '—') },
    { key: 'comments', label: 'Comments', render: (r) => (r.comments ? h('span', { class: 'dv-cell-clip', title: r.comments, text: r.comments, tabindex: '0' }) : '—') },
  ];
}

export function changeColumns(ctx) {
  return [
    { key: 'rddc', label: 'Intake/Release', render: (r) => h('div', {},
      h('a', { class: 'dv-link', href: `#/initiative/${r.initiative_id}/pg4`, on: { click: (e) => { e.preventDefault(); go(ctx, `#/initiative/${r.initiative_id}/pg4`); } } }, r.rddc),
      h('div', { class: 'dv-muted', text: [r.crq_number, r.release_train].filter(Boolean).join(' · ') || 'No CRQ yet' })) },
    { key: 'cms_lead_name', label: 'CMS Lead / Rel Lead', render: (r) => h('div', { class: 'dv-nowrap' }, r.cms_lead_name || '—', h('div', { class: 'dv-muted', text: r.rel_lead_name || '—' })) },
    { key: 'resource_name', label: 'Resource' },
    { key: 'implementation_status', label: 'Implementation Status', render: (r) => statusPill(r.implementation_status) },
    { key: 'tech_validation_status', label: 'Technical Validation Status', render: (r) => statusPill(r.tech_validation_status) },
    { key: 'biz_validation_status', label: 'Business Validation Status', render: (r) => statusPill(r.biz_validation_status) },
    { key: 'sto_approval', label: 'STO Approval', render: (r) => (r.sto_approval ? statusPill(r.sto_approval) : h('span', { class: 'dv-muted', title: 'STO approval is requested from T-5 business days', text: 'Not requested' })) },
    { key: 'compliance_flags', label: 'Compliance', sortable: false, render: (r) => {
      const flags = Array.isArray(r.compliance_flags) ? r.compliance_flags : [];
      if (!flags.length) return chip('Compliant', 'green');
      return h('div', { class: 'dv-flags dv-flags-wrap' }, flags.map((f) => {
        const text = typeof f === 'string' ? f : f.message || f.code;
        return chip(text, 'red', { title: text });
      }));
    } },
  ];
}

/** Portfolio-scope health tile data from the dashboard rows. */
/** Portfolio-scope health tile data. Attention items come from the API's shared rule (every Red dimension and
 * Schedule Amber with float of 2 business days or less), never re-derived here. */
export function portfolioHealthData(projects) {
  const counts = { Red: 0, Amber: 0, Green: 0, unscored: 0 };
  const attention = [];
  for (const p of projects) {
    if (p.rag in counts) counts[p.rag] += 1; else counts.unscored += 1;
    const items = Array.isArray(p.attention) ? p.attention.filter(Boolean) : [];
    if (items.length) attention.push({ id: p.id, rddc: p.rddc, name: p.name, rag: p.rag, items });
  }
  attention.sort((a, b) => (a.rag in RAG_RANK ? RAG_RANK[a.rag] : 3) - (b.rag in RAG_RANK ? RAG_RANK[b.rag] : 3) || b.items.length - a.items.length);
  return { counts, attention };
}

/** Quarter options from lookups.fiscal_quarters (or computed), default = first quarter that is not over. */
export function quarterOptions(lookups, today) {
  let quarters = Array.isArray(lookups && lookups.fiscal_quarters) ? lookups.fiscal_quarters.filter((q) => Array.isArray(q.months) && q.months.length) : [];
  if (!quarters.length) {
    const start = monthKey(today) || '2026-11';
    const fq = fiscalOf(addMonths(start, 1));
    const fyStart = `${Number(`20${fq.fy.slice(2)}`) - 1}-11`;
    quarters = [0, 1, 2, 3].map((i) => {
      const months = monthsBetween(addMonths(fyStart, i * 3), addMonths(fyStart, i * 3 + 2));
      const f = fiscalOf(months[0]);
      return { fy: f.fy, q: f.q, label: f.label, months };
    });
  }
  const options = quarters.map((q) => ({ value: `${q.fy}-${q.q}`, label: `${q.label} · ${q.q} ${q.fy}`, months: q.months, short: q.label }));
  const nowYm = monthKey(today);
  const current = options.find((o) => o.months[o.months.length - 1] >= nowYm) || options[0];
  return { options, current };
}

/** Resource Capacity tile with a quarter selector; fetches /api/capacity per quarter. */
export function mountCapacityTile(el, { lookups, today, initiativeId = null, fallbackTeams = null }) {
  const { options, current } = quarterOptions(lookups, today);
  let chart = null;
  async function load(value) {
    const q = options.find((o) => o.value === value) || current;
    if (!q) return;
    try {
      const cap = await api.getCapacity({ group: 'team', from: q.months[0], to: q.months[q.months.length - 1], initiative_id: initiativeId || undefined });
      const teams = cap && Array.isArray(cap.teams) ? cap.teams : [];
      if (!chart) chart = renderTeamBars(el, teams, { quarters: options, quarter: q.value, periodLabel: q.short, onQuarterChange: load });
      else chart.update(teams);
    } catch (err) {
      if (fallbackTeams && !chart) chart = renderTeamBars(el, fallbackTeams, { quarters: options, quarter: q.value, periodLabel: q.short, onQuarterChange: load });
      else { clear(el); el.appendChild(errorBox(err, () => load(value))); chart = null; }
    }
  }
  load(current ? current.value : null);
  return { reload: () => load(current ? current.value : null) };
}

export function execSummaryPreview(run, ctx) {
  const o = run.output || {};
  const textForEmail = [
    o.headline, '', markdownToText(o.summary_md),
    o.highlights && o.highlights.length ? `\nHighlights:\n${o.highlights.map((x) => `- ${x}`).join('\n')}` : '',
    o.concerns && o.concerns.length ? `\nConcerns:\n${o.concerns.map((x) => `- ${x}`).join('\n')}` : '',
    o.asks && o.asks.length ? `\nAsks:\n${o.asks.map((x) => `- ${x}`).join('\n')}` : '',
  ].filter((x) => x !== undefined && x !== null).join('\n').trim();
  return h('div', {},
    h('div', { class: 'dv-section-title' }, h('span', { text: o.headline || 'Executive summary' }), o.rag ? ragPill(o.rag) : null),
    o.period && o.period.from ? h('div', { class: 'dv-muted', text: `Period ${fmtDate(o.period.from)} – ${fmtDate(o.period.to)}` }) : null,
    o.summary_md ? renderMarkdown(o.summary_md, ctx) : null,
    o.highlights && o.highlights.length ? [h('h3', { text: 'Highlights' }), bulletList(o.highlights)] : null,
    o.concerns && o.concerns.length ? [h('h3', { text: 'Concerns' }), bulletList(o.concerns)] : null,
    o.asks && o.asks.length ? [h('h3', { text: 'Asks' }), bulletList(o.asks)] : null,
    button('Copy to email', () => copyText(textForEmail).then(() => toast('Copied. Paste it into your email.'), (e) => toast(e.message, 'warning'))));
}

export function exportLinks() {
  let rows = [];
  const portfolioLink = h('a', { class: 'btn btn-secondary', href: api.exportPortfolioXlsxUrl(), download: 'portfolio.xlsx', 'data-testid': 'export-portfolio' }, 'Portfolio workbook');
  const demoBtn = button('Initiative workbook…', () => chooseDemoView(), { attrs: { 'data-testid': 'export-demo-view', title: 'Download the delivery workbook for one initiative' } });
  function chooseDemoView() {
    const sorted = rows.slice().sort((a, b) => String(a.rddc).localeCompare(String(b.rddc)));
    const pick = rows.find((r) => r.rddc === 'RDDC-24817') || rows.slice().sort((a, b) => Number(b.id) - Number(a.id))[0];
    const sel = h('select', { class: 'dv-select', 'aria-label': 'Initiative' },
      sorted.map((r) => h('option', { value: String(r.id), selected: Boolean(pick && r.id === pick.id) }, `${r.rddc} · ${r.name}`)));
    const link = h('a', { class: 'btn btn-primary', href: api.exportDemoViewUrl(sel.value), download: '', 'data-testid': 'export-demo-view-download' }, 'Download workbook');
    sel.addEventListener('change', () => { link.href = api.exportDemoViewUrl(sel.value); });
    const dlg = modal({
      title: 'Initiative delivery workbook',
      body: [
        h('p', { class: 'dv-muted', text: 'Choose an initiative to export its intake, delivery plan, resource management, governance, and portfolio context.' }),
        h('label', { class: 'dv-form-row' }, h('span', { text: 'Initiative' }), sel),
        h('div', {}, link),
      ],
      actions: [],
    });
    link.addEventListener('click', () => setTimeout(dlg.close, 0));
  }
  return {
    links: [portfolioLink, demoBtn],
    setRows(next) { rows = Array.isArray(next) ? next : []; demoBtn.disabled = !rows.length; },
  };
}

/** Portfolio body (KPIs, three deck tiles, capacity/budget, tables). Used by #/portfolio and by Pg 5 "All initiatives". */
export async function renderPortfolioBody(host, ctx, { highlightId = null, onLoaded = null } = {}) {
  clear(host);
  host.appendChild(loading('Loading portfolio…'));
  let lookups;
  let today;
  let portfolio;
  try {
    [lookups, today, portfolio] = await Promise.all([getLookups(ctx), getToday(ctx), api.getPortfolio()]);
  } catch (err) {
    clear(host);
    host.appendChild(errorBox(err, () => renderPortfolioBody(host, ctx, { highlightId })));
    return () => {};
  }
  clear(host);
  const projects = Array.isArray(portfolio.projects) ? portfolio.projects : [];
  if (onLoaded) onLoaded(portfolio);
  if (!projects.length) {
    host.appendChild(h('section', { class: 'portal-welcome' },
      h('h2', {}, 'Your delivery workspace is ready'),
      h('p', {}, 'Start with an intake, import a Jira workbook, or read a solution architecture document. The overview fills in as you add funding, people, and delivery plans.'),
      h('div', { class: 'intake-paths' },
        h('a', { class: 'intake-path', href: '#/initiative/new' }, h('strong', {}, '01 · Add an initiative'), h('span', {}, 'Enter the request directly in the portal')),
        h('a', { class: 'intake-path', href: '#/imports' }, h('strong', {}, '02 · Import your source'), h('span', {}, 'Excel, CSV, SA Word documents, or text')),
        h('a', { class: 'intake-path', href: '#/resources' }, h('strong', {}, '03 · Build your delivery team'), h('span', {}, 'Add people, availability, and allocations')))));
    return () => {};
  }
  const cleanups = [];
  const filterByRag = (rag) => {
    filters.rag = rag;
    const sel = ragFilter.querySelector('select');
    if (sel) sel.value = rag;
    apply();
    dash.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };
  host.appendChild(kpiStrip(portfolio.kpis || {}, {
    active: () => filterByRag(''),
    red: () => filterByRag('Red'),
    amber: () => filterByRag('Amber'),
    crqs: () => go(ctx, '#/changes'),
    over: () => {
      try { sessionStorage.setItem('bmo.resources.focus', JSON.stringify({ highlight: 'over' })); } catch { /* optional */ }
      go(ctx, '#/resources');
    },
  }));

  // three deck tiles
  const healthCard = card('Project health', { noHead: true });
  const capCard = card('Resource capacity');
  const ganttCard = card('Project Gantt', { right: h('span', { class: 'dv-muted', text: 'One bar per initiative' }) });
  host.appendChild(h('div', { class: 'dv-grid-3 dv-section', 'data-testid': 'deck-tiles' }, healthCard.el, capCard.el, ganttCard.el));
  const tileData = portfolioHealthData(projects);
  tileData.rule = portfolio.rule_text || (portfolio.health_tiles && portfolio.health_tiles.rule_text) || null;
  const healthChart = renderPortfolioHealth(healthCard.body, tileData, { onItemClick: (item) => go(ctx, `#/initiative/${item.id}/pg5`) });
  cleanups.push(() => healthChart.destroy());
  mountCapacityTile(capCard.body, { lookups, today, fallbackTeams: portfolio.capacity_teams });
  api.getPortfolioGantt().then((pg) => {
    const chart = renderPortfolioGantt(ganttCard.body, pg, { compact: true, highlightId, onRowClick: (r) => go(ctx, `#/initiative/${r.initiative_id}/pg5`) });
    cleanups.push(() => chart.destroy());
  }, (err) => { clear(ganttCard.body); ganttCard.body.appendChild(errorBox(err)); });

  // Project Dashboard
  const dash = h('section', { class: 'dv-section', 'data-testid': 'project-dashboard' });
  host.appendChild(dash);
  dash.appendChild(h('h2', { class: 'dv-section-title', text: 'Project Dashboard' }));
  const filters = { lob: '', dc_pm: '', stage: '', rag: '', release: '', q: '' };
  const pms = [...new Set(projects.map((p) => p.dc_pm_name).filter(Boolean))].sort().map((n) => ({ value: n, label: n }));
  const trains = Array.isArray(lookups.release_trains) ? lookups.release_trains.map((t) => ({ value: t.code, label: t.code })) : [];
  const search = h('input', { class: 'dv-input', type: 'search', placeholder: 'Search RDDC # or name', 'aria-label': 'Search RDDC # or name' });
  const ragFilter = selectEl([{ value: 'Red', label: 'Red' }, { value: 'Amber', label: 'Amber' }, { value: 'Green', label: 'Green' }, { value: 'none', label: 'Not scored' }], '', (v) => { filters.rag = v; apply(); }, { label: 'RAG', allLabel: 'All' });
  const csvLink = h('a', { class: 'btn btn-ghost', href: api.exportPortfolioCsvUrl({}), download: 'portfolio.csv' }, 'Export CSV');
  const table = dataTable({
    columns: projectColumns(ctx), rows: projects, sortKey: 'rag', dense: true, onRowClick: (r) => go(ctx, `#/initiative/${r.id}/pg5`),
    rowClass: (r) => (highlightId && String(r.id) === String(highlightId) ? 'is-hero' : ''), caption: 'Project Dashboard',
    empty: 'No initiatives match these filters. Clear a filter to see more.',
  });
  const apply = () => {
    const q = filters.q.trim().toLowerCase();
    const rows = projects.filter((p) => (!filters.lob || p.lob === filters.lob)
      && (!filters.dc_pm || p.dc_pm_name === filters.dc_pm)
      && (!filters.stage || p.stage === filters.stage)
      && (!filters.rag || (filters.rag === 'none' ? !(p.rag in RAG_RANK) : p.rag === filters.rag))
      && (!filters.release || p.target_release === filters.release)
      && (!q || `${p.rddc} ${p.name}`.toLowerCase().includes(q)));
    table.update(rows);
    csvLink.href = api.exportPortfolioCsvUrl({ lob: filters.lob, stage: filters.stage, rag: filters.rag === 'none' ? '' : filters.rag, release: filters.release });
  };
  search.addEventListener('input', () => { filters.q = search.value; apply(); });
  dash.appendChild(h('div', { class: 'dv-filters' },
    selectEl(lookupOptions(lookups, 'lob'), '', (v) => { filters.lob = v; apply(); }, { label: 'LOB', allLabel: 'All LOBs' }),
    selectEl(pms, '', (v) => { filters.dc_pm = v; apply(); }, { label: 'DC PM', allLabel: 'All DC PMs' }),
    selectEl(lookupOptions(lookups, 'stage'), '', (v) => { filters.stage = v; apply(); }, { label: 'Stage', allLabel: 'All stages' }),
    ragFilter,
    selectEl(trains, '', (v) => { filters.release = v; apply(); }, { label: 'Release', allLabel: 'All releases' }),
    h('label', { class: 'dv-field' }, h('span', { class: 'dv-field-label', text: 'Search' }), search),
    csvLink));
  dash.appendChild(table.el);

  // Change Management
  const cm = Array.isArray(portfolio.change_mgmt) ? portfolio.change_mgmt : [];
  host.appendChild(h('section', { class: 'dv-section', 'data-testid': 'change-management' },
    h('h2', { class: 'dv-section-title' }, h('span', { text: 'Change Management' }), h('a', { class: 'dv-link', href: '#/changes', on: { click: (e) => { e.preventDefault(); go(ctx, '#/changes'); } } }, 'Open weekly CRQ review')),
    dataTable({ columns: changeColumns(ctx), rows: cm, sortKey: 'rddc', dense: true, caption: 'Change Management', empty: 'No change requests logged yet.', onRowClick: (r) => go(ctx, `#/initiative/${r.initiative_id}/pg4`) }).el));

  // Capacity and budget (demo step 13: heatmap shows the new demand; PRN burndown)
  const heatCard = card('Resource heatmap · next two quarters', { right: h('a', { class: 'dv-link', href: '#/resources', on: { click: (e) => { e.preventDefault(); go(ctx, '#/resources'); } } }, 'Open Resources') });
  const burnCard = card('PRN burndown');
  host.appendChild(h('div', { class: 'dv-section' }, heatCard.el));
  host.appendChild(h('div', { class: 'dv-section' }, burnCard.el));
  const { current } = quarterOptions(lookups, today);
  const from = current ? current.months[0] : monthKey(today);
  api.getCapacity({ group: 'resource', from, to: addMonths(from, 5) }).then((cap) => {
    const chart = renderHeatmap(heatCard.body, cap, {
      onCellClick: ({ row, cell }) => {
        try { sessionStorage.setItem('bmo.resources.focus', JSON.stringify({ key: row.key, label: row.label, month: cell.month })); } catch { /* focus is optional */ }
        go(ctx, '#/resources');
      },
    });
    cleanups.push(() => chart.destroy());
  }, (err) => { clear(heatCard.body); heatCard.body.appendChild(errorBox(err)); });
  mountBurndownPicker(burnCard.body, { today, preferred: 'PRN-77310' }).then((c) => cleanups.push(c));

  return () => cleanups.forEach((fn) => fn());
}

/** "PRN-71840 · RDDC-24412 e-Transfer…"; a PRN funded before its intake exists says so. */
export function prnLabel(p) {
  const inits = Array.isArray(p.initiatives) ? p.initiatives : null;
  if (inits && inits.length) return `${p.prn_code} · ${inits.map((i) => `${i.rddc} ${i.name || ''}`.trim()).join(', ')}`;
  if (inits) return `${p.prn_code} · ${p.name || p.lob || 'Funded'} (not yet linked)`;
  return `${p.prn_code} · ${p.name || p.lob || ''}`.replace(/ · $/, '');
}

/** PRN selector + burndown chart; resolves to a cleanup function. */
export async function mountBurndownPicker(el, { today, preferred }) {
  clear(el);
  let prns = [];
  try {
    prns = itemsOf(await api.listPrns());
  } catch (err) {
    el.appendChild(errorBox(err, () => mountBurndownPicker(el, { today, preferred })));
    return () => {};
  }
  if (!prns.length) {
    el.appendChild(emptyState('No PRNs are funded yet.'));
    return () => {};
  }
  const chartHost = h('div');
  let chart = null;
  // Default to the preferred PRN when it has charges; otherwise the PRN with the most charged hours,
  // so the opening chart shows a real burndown rather than a flat line.
  const pref = prns.find((p) => p.prn_code === preferred);
  const charged = prns.slice().sort((a, b) => num(b.charged_hours) - num(a.charged_hours))[0];
  const initial = (pref && num(pref.charged_hours) > 0 ? pref : (charged && num(charged.charged_hours) > 0 ? charged : pref || prns[0])).prn_code;
  const load = async (code) => {
    try {
      const b = await api.getPrnBurndown(code);
      if (!chart) chart = renderBurndown(chartHost, b, { today });
      else chart.update(b);
    } catch (err) {
      clear(chartHost);
      chartHost.appendChild(errorBox(err, () => load(code)));
      chart = null;
    }
  };
  el.append(h('div', { class: 'ch-toolbar' }, selectEl(prns.map((p) => ({ value: p.prn_code, label: prnLabel(p) })), initial, load, { label: 'PRN' })), chartHost);
  await load(initial);
  return () => { if (chart) chart.destroy(); };
}

// ------------------------------------------------------------------ view

export async function render(root, params, ctx) {
  const page = framePage(root, 'portfolio');
  const aiHost = h('div', { class: 'dv-ai-host', hidden: true });
  const body = h('div');
  const exports = exportLinks();
  const summaryBtn = autoButton('Write Executive Summary', () => runAi(aiHost, {
    feature: 'exec_summary', title: 'Executive Summary · all initiatives', trigger: summaryBtn,
    preview: (run) => execSummaryPreview(run, ctx),
    acceptMessage: () => 'Executive summary saved to Artifacts → Meeting Notes.',
  }));
  page.append(
    pageHeader({ eyebrow: 'DELIVERY PORTAL', title: 'Portfolio overview', hint: 'Initiatives, funding, capacity, and delivery health in one workspace', actions: [summaryBtn, ...exports.links] }),
    aiHost, body);
  return renderPortfolioBody(body, ctx, {
    highlightId: params && params.highlight,
    onLoaded: (pf) => { exports.setRows(pf.projects || []); summaryBtn.hidden = !(pf.projects || []).length; exports.links.forEach(link => { link.hidden = !(pf.projects || []).length; }); },
  });
}
