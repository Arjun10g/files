// Manual intake shares validation and delivery engines with reviewed imports.
import { fundingIntakeFields, personNamePicker } from '../ui/intake_connections.js';

export async function render(root, params, ctx) {
  const { api, state, ui, navigate } = ctx;
  const { h } = ui;
  await state.loadLookups();
  const funding = await api.request('GET', '/funding').catch(() => ({ items: [] }));
  const controls = {};
  const people = {};
  const grid = h('div.form-grid');
  function field(key, label, kind = 'text', options = {}) {
    const input = kind === 'select' ? ui.selectEl(options.items || [], options.value || '', { placeholder: 'Choose…', ariaLabel: label })
      : h(kind === 'textarea' ? 'textarea.input' : 'input.input', { type: kind === 'textarea' ? undefined : kind, rows: kind === 'textarea' ? 5 : undefined,
        required: options.required, maxLength: key === 'name' ? 80 : undefined, aria: { label } });
    controls[key] = input;
    grid.append(h(`label.form-field${kind === 'textarea' ? '.span-2' : ''}`, h('span.form-label', label + (options.required ? ' *' : '')), input));
  }
  field('name', 'Project name', 'text', { required: true });
  field('lob', 'Line of business', 'select', { items: state.options('lob'), required: true });
  field('priority', 'Priority', 'select', { items: state.options('priority'), value: 3, required: true });
  const requestor = personNamePicker(ui, state, { label: 'Requestor name', required: true });
  people.requestor = requestor;
  grid.append(h('label.form-field', h('span.form-label', 'Requestor name *'), requestor.el));
  field('requested_go_live', 'Requested go-live', 'date');
  field('target_release', 'Target release', 'select', { items: (state.lookups.release_trains || []).filter(t => t.status !== 'Done').map(t => ({ value: t.code, label: `${t.code} · ${t.train_date}` })) });
  field('platform', 'Platform', 'select', { items: ['BDB', 'BBX'].map(value => ({ value, label: value })) });
  field('region', 'Region', 'select', { items: ['CA', 'US'].map(value => ({ value, label: value })) });
  field('channel', 'Channel', 'select', { items: ['SS', 'Assisted'].map(value => ({ value, label: value })) });
  field('apt_number', 'APT number');
  field('external_pr_code', 'External team PR code');
  field('solution_concurrence_date', 'Solution concurrence date', 'date');
  field('jira_key', 'Jira issue key');
  field('labels', 'Labels (comma separated)');
  field('description', 'Business context, scope, and requested change', 'textarea');
  const connectionGrid = h('div.form-grid');
  for (const [key, label] of [['dc_pm', 'DC project manager'], ['dc_sa', 'Solution architect'], ['tech_lead', 'Technical lead'],
    ['pm', 'Project manager'], ['assigned_to', 'Assigned to'], ['business_analyst', 'Business analyst']]) {
    const picker = personNamePicker(ui, state, { label });
    people[key] = picker;
    connectionGrid.append(h('label.form-field', h('span.form-label', label), picker.el));
  }
  const fundingFields = fundingIntakeFields(ui, state, funding.items || []);
  connectionGrid.append(h('label.form-field', h('span.form-label', 'Funding / PRN'), fundingFields.codeEl));
  const connections = h('details.intake-connections', h('summary', 'People and funding'),
    h('p.intake-connection-note', 'Choose existing people or enter new names. Saving adds them to Resources so you can complete capacity, rates and allocations there.'),
    connectionGrid, fundingFields.el);
  const errorSlot = h('div', { attrs: { role: 'alert' } });
  const form = h('form', { on: { submit: e => { e.preventDefault(); save(); } } }, grid, connections, errorSlot);
  const saveButton = ui.btn('Create initiative', { variant: 'primary', onClick: () => form.requestSubmit() });
  async function save() {
    const restore = ui.busy(saveButton, 'Creating…');
    ui.mount(errorSlot);
    const body = {};
    for (const [key, control] of Object.entries(controls)) {
      if (!control.value.trim()) continue;
      body[key] = key.endsWith('_id') || key === 'priority' ? Number(control.value) : control.value.trim();
    }
    body.labels = String(body.labels || '').split(',').map(x => x.trim()).filter(Boolean);
    try {
      fundingFields.validate();
      for (const [key, picker] of Object.entries(people)) {
        const person = picker.read();
        if (!person.name) continue;
        body[key] = person.name;
        if (key !== 'business_analyst') body[`${key}_id`] = person.id;
      }
      if (fundingFields.getCode()) body.prn_code = fundingFields.getCode();
      const fundingPatch = fundingFields.read();
      if (fundingPatch) body.funding = fundingPatch;
      const result = await api.createInitiative(body);
      await state.loadLookups(true);
      state.emit('ai:applied', { feature: 'create' });
      ui.toast(`${result.initiative.rddc} created. Review scope and ownership in the workspace.`);
      navigate(`#/initiative/${result.initiative.id}/pg1`);
    } catch (err) {
      ui.mount(errorSlot, ui.errorPanel(err), ...Object.entries(err.details?.fields || {}).map(([k, message]) => h('p.field-error', `${k.replaceAll('_', ' ')}: ${message}`)));
    } finally { restore(); }
  }
  root.append(h('div.view-pad', ui.pageBox({ title: 'Add initiative', hint: 'Start with the request. Add estimates, people, and delivery details as they become available.' },
    h('div.intake-paths',
      h('a.intake-path', { href: '#/imports' }, h('strong', 'Import Excel or CSV'), h('span', 'Load a Jira export or intake workbook')),
      h('a.intake-path', { href: '#/imports?source=document' }, h('strong', 'Read an SA document'), h('span', 'Extract Word, PDF, or pasted text with rules')),
      h('a.intake-path', { href: '#/experimental' }, h('strong', 'Experimental · Jira'), h('span', 'Authenticated JSON and live issue capture'))),
    form, h('div.page-footer', ui.btn('Cancel', { onClick: () => navigate('#/portfolio') }), saveButton))));
  controls.name.focus();
}
