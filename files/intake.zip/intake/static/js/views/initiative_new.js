// views/initiative_new.js: Add New Initiative. DC Intake lookup pre-fill, SA document drop for AI autofill,
// inline validation, Save -> grooming toast (text from the API) -> workspace Pg 1 with Intake Analysis.
import { runAiFeature } from '../ui/ai_card.js';
import { previewIntakeAutofill } from '../ui/previews.js';

const REQUIRED = {
  name: 'Project Name', lob: 'LOB', priority: 'Priority', requestor: 'Requestor',
  requested_go_live: 'Requested Go-live', description: 'Description of Change',
};

/** Read the text of word/document.xml from a .docx in the browser (for the autofill preview only). */
async function docxText(file) {
  if (typeof DecompressionStream === 'undefined') return '';
  const buf = new Uint8Array(await file.arrayBuffer());
  const view = new DataView(buf.buffer);
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 66000); i -= 1) {
    if (view.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) return '';
  const count = view.getUint16(eocd + 10, true);
  let p = view.getUint32(eocd + 16, true);
  const decoder = new TextDecoder();
  for (let n = 0; n < count && p + 46 <= buf.length; n += 1) {
    if (view.getUint32(p, true) !== 0x02014b50) break;
    const method = view.getUint16(p + 10, true);
    const csize = view.getUint32(p + 20, true);
    const nameLen = view.getUint16(p + 28, true);
    const extraLen = view.getUint16(p + 30, true);
    const commentLen = view.getUint16(p + 32, true);
    const local = view.getUint32(p + 42, true);
    const name = decoder.decode(buf.subarray(p + 46, p + 46 + nameLen));
    p += 46 + nameLen + extraLen + commentLen;
    if (name !== 'word/document.xml') continue;
    const start = local + 30 + view.getUint16(local + 26, true) + view.getUint16(local + 28, true);
    const data = buf.subarray(start, start + csize);
    let xml;
    if (method === 0) xml = decoder.decode(data);
    else if (method === 8) {
      const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
      xml = await new Response(stream).text();
    } else return '';
    return xml.replace(/<\/w:p>/g, '\n').replace(/<w:tab\/>/g, '\t').replace(/<[^>]+>/g, '')
      .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&')
      .replace(/\n{3,}/g, '\n\n').trim();
  }
  return '';
}

/** Best-effort text from a text-based PDF (literal strings in Tj/TJ, plain or Flate streams). */
async function pdfText(file) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  const toStr = (arr) => { let r = ''; for (let i = 0; i < arr.length; i += 0x8000) r += String.fromCharCode.apply(null, arr.subarray(i, i + 0x8000)); return r; };
  const bin = toStr(bytes);
  const toBytes = (str) => Uint8Array.from(str, (c) => c.charCodeAt(0) & 0xff);
  const win = new TextDecoder('windows-1252');
  const unescape = (lit) => lit.replace(/\\([nrtbf()\\]|[0-7]{1,3})/g, (m, c) => {
    if (/^[0-7]+$/.test(c)) return String.fromCharCode(parseInt(c, 8));
    return { n: '\n', r: '\r', t: '\t', b: '', f: '', '(': '(', ')': ')', '\\': '\\' }[c];
  });
  const out = [];
  const streamRe = /<<([\s\S]*?)>>\s*stream\r?\n([\s\S]*?)\r?\nendstream/g;
  let m;
  while ((m = streamRe.exec(bin))) {
    let content = m[2];
    const dict = m[1].slice(m[1].lastIndexOf("<<") + 2);
    if (/FlateDecode/.test(dict)) {
      if (typeof DecompressionStream === 'undefined') continue;
      try {
        const stream = new Blob([toBytes(content)]).stream().pipeThrough(new DecompressionStream('deflate'));
        content = toStr(new Uint8Array(await new Response(stream).arrayBuffer()));
      } catch { continue; }
    } else if (/Filter/.test(dict)) continue;
    if (!/\bBT\b/.test(content)) continue;
    const tokRe = /\((?:\\[\s\S]|[^\\)])*\)\s*(?:Tj|')|\[((?:\((?:\\[\s\S]|[^\\)])*\)|[^\]])*)\]\s*TJ|\bT\*|\bT[dD]\b|\bET\b/g;
    let t;
    let line = '';
    while ((t = tokRe.exec(content))) {
      const tok = t[0];
      if (tok.startsWith('(')) line += unescape(tok.slice(1, tok.lastIndexOf(')')));
      else if (tok.startsWith('[')) line += (t[1].match(/\((?:\\[\s\S]|[^\\)])*\)/g) || []).map((x) => unescape(x.slice(1, -1))).join('');
      else if (line) { out.push(line); line = ''; }
    }
    if (line) out.push(line);
  }
  return win.decode(toBytes(out.join('\n'))).replace(/\n{3,}/g, '\n\n').trim();
}

async function readFileText(file) {
  const name = (file.name || '').toLowerCase();
  if (name.endsWith('.md') || name.endsWith('.txt')) return file.text();
  if (name.endsWith('.docx')) {
    try { return await docxText(file); } catch { return ''; }
  }
  if (name.endsWith('.pdf')) {
    try { return await pdfText(file); } catch { return ''; }
  }
  return '';
}

export async function render(root, params, ctx) {
  const { api, state, ui, dates, navigate } = ctx;
  const { h } = ui;
  await state.loadLookups().catch(() => null);

  const values = {
    dc_intake: '', name: '', lob: '', priority: '', requestor: '', requestor_id: null, requested_go_live: '',
    target_release: '', dc_pm_id: '', dc_sa_id: '', tech_lead_id: '', pm_id: null, labels: '', prn_code: '', description: '',
  };
  const inputs = {};
  const errors = {};
  const labelsEl = {};
  let saFile = null;

  const people = (filter) => {
    const list = state.people(filter);
    return (list.length ? list : state.people()).map((p) => ({ value: p.id, label: p.name }));
  };
  const trains = ((state.lookups && state.lookups.release_trains) || []).filter((t) => t.status !== 'Done')
    .map((t) => ({ value: t.code, label: `${t.code} · ${dates.fmtDay(t.train_date, { withYear: true })}` }));

  function field(key, label, control, { span2, hint } = {}) {
    inputs[key] = control;
    errors[key] = h('div.field-error', { hidden: true });
    labelsEl[key] = h('span.form-label', label, REQUIRED[key] ? h('span.req', { aria: { hidden: 'true' } }, ' *') : null);
    const evt = control.tagName === 'SELECT' ? 'change' : 'input';
    control.addEventListener(evt, () => {
      values[key] = control.value;
      if (key === 'requestor') values.requestor_id = control.value ? Number(control.value) : null;
      clearError(key);
    });
    const shown = control.type === 'date' ? ui.dateField(control) : control;
    if (shown !== control) control._wrap = shown;
    return h(`label.form-field${span2 ? '.span-2' : ''}`, labelsEl[key], shown, hint ? h('span.form-hint', hint) : null, errors[key]);
  }

  function setError(key, msg) {
    if (!errors[key]) return;
    errors[key].textContent = msg;
    errors[key].hidden = false;
    inputs[key].classList.add('invalid');
    inputs[key].setAttribute('aria-invalid', 'true');
  }
  function clearError(key) {
    if (!errors[key]) return;
    errors[key].hidden = true;
    inputs[key].classList.remove('invalid');
    inputs[key].removeAttribute('aria-invalid');
  }

  function setValue(key, value, { ai } = {}) {
    const el = inputs[key];
    if (!el || value === null || value === undefined || value === '') return false;
    el.value = String(value);
    if (el.tagName === 'SELECT' && el.value !== String(value)) return false;
    if (el._wrap) el._wrap.refresh();
    values[key] = el.value;
    if (key === 'requestor') values.requestor_id = Number(el.value) || null;
    clearError(key);
    if (ai) {
      el.classList.remove('ai-filled');
      void el.offsetWidth;
      el.classList.add('ai-filled');
      if (!labelsEl[key].querySelector('.ai-tag')) labelsEl[key].appendChild(ui.aiTag('AI'));
    }
    return true;
  }

  const findPerson = (name, filter) => {
    if (!name) return null;
    const n = String(name).trim().toLowerCase();
    return state.people(filter).find((p) => p.name.toLowerCase() === n) || state.people().find((p) => p.name.toLowerCase() === n) || null;
  };

  // ---------------------------------------------------------------- DC Intake lookup
  const intakeInput = h('input.input', { type: 'text', placeholder: 'DCI-####', autocomplete: 'off', attrs: { list: 'dci-list' }, aria: { label: 'DC Intake' } });
  const intakeList = h('datalist', { id: 'dci-list' });
  const intakeNote = h('div.form-hint');
  const lookupBtn = ui.btn('Look up', { variant: 'secondary', onClick: () => lookupIntake() });
  intakeInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); lookupIntake(); } });
  intakeInput.addEventListener('change', () => { if (/^DCI-\d{4}$/i.test(intakeInput.value.trim())) lookupIntake(); });
  api.listDcIntakes().then((res) => {
    ui.mount(intakeList, ...(res.items || []).filter((d) => !d.initiative_id)
      .map((d) => h('option', { value: d.code }, `${d.code} · ${d.name}`)));
  }).catch(() => {});

  async function lookupIntake() {
    const code = intakeInput.value.trim().toUpperCase();
    if (!code) { intakeNote.textContent = 'Enter a DC Intake number, for example DCI-3391.'; return; }
    const restore = ui.busy(lookupBtn, 'Looking up…');
    try {
      const d = await api.getDcIntake(code);
      values.dc_intake = d.code;
      intakeInput.value = d.code;
      if (d.initiative_id) {
        ui.mount(intakeNote, h('span', `${d.code} is already registered. `),
          h('a.link', { href: `#/initiative/${d.initiative_id}/pg1` }, 'Open the initiative'));
        return;
      }
      setValue('name', d.name);
      setValue('lob', d.lob);
      setValue('priority', d.priority);
      const p = d.requestor_id ? { id: d.requestor_id } : findPerson(d.requestor, { team: 'Business' });
      if (p) setValue('requestor', p.id);
      if (d.prn_code) setValue('prn_code', d.prn_code);
      setValue('requested_go_live', d.requested_go_live);
      setValue('description', d.description);
      setValue('dc_pm_id', d.dc_pm_id);
      setValue('dc_sa_id', d.dc_sa_id);
      setValue('tech_lead_id', d.tech_lead_id);
      if (d.pm_id) values.pm_id = d.pm_id;
      if (d.target_release) setValue('target_release', d.target_release);
      intakeNote.textContent = `Pre-filled from ${d.code}. Check the details before saving.`;
    } catch (err) {
      intakeNote.textContent = err && err.status === 404 ? `No DC Intake ${code} was found.` : (err.message || 'The DC Intake could not be read.');
    } finally {
      restore();
    }
  }

  // ---------------------------------------------------------------- SA document autofill
  const autofillSlot = h('div.ai-slot', { hidden: true });
  const dz = ui.dropzone({
    label: 'Drop SA document here or Browse',
    hint: 'Fills this form from the document · attached to Pg 1 when you save',
    yellow: true,
    onFile: async (file) => {
      saFile = file;
      const text = await readFileText(file);
      if (text && text.length >= 200) startAutofill(file, text);
      else {
        autofillSlot.hidden = false;
        ui.mount(autofillSlot, h('div.notice.notice-amber', { attrs: { role: 'status' } },
          `The text of ${file.name} could not be read here, so the form was not filled. Fill the fields yourself; the document is still attached to Pg 1 when you save.`));
      }
      return { filename: file.name, size: file.size };
    },
    onRemove: () => { saFile = null; dz.setEmpty(); autofillSlot.hidden = true; ui.mount(autofillSlot); },
  });

  function startAutofill(file, text) {
    const options = { filename: file.name };
    if (text) options.text = text.slice(0, 60000);
    runAiFeature({
      feature: 'intake_autofill', initiativeId: null, container: autofillSlot,
      body: { options },
      renderPreview: previewIntakeAutofill, editable: false,
      acceptLabel: 'Fill the form',
      acceptMessage: () => 'Form filled from the SA document · review each field before saving.',
      onApplied: (res, run) => fillFromAutofill(run.output || {}),
    });
  }

  function fillFromAutofill(out) {
    const f = out.fields || {};
    const v = (k) => (f[k] && f[k].value !== null && f[k].value !== undefined ? f[k].value : null);
    let n = 0;
    if (setValue('name', v('name'), { ai: true })) n += 1;
    if (setValue('lob', v('lob'), { ai: true })) n += 1;
    if (setValue('priority', v('priority'), { ai: true })) n += 1;
    const req = findPerson(v('requestor'), { team: 'Business' });
    if (req && setValue('requestor', req.id, { ai: true })) n += 1;
    if (setValue('requested_go_live', v('requested_go_live'), { ai: true })) n += 1;
    if (setValue('target_release', v('target_release'), { ai: true })) n += 1;
    if (setValue('description', v('description'), { ai: true })) n += 1;
    const labels = v('labels');
    if (labels && setValue('labels', Array.isArray(labels) ? labels.join(', ') : labels, { ai: true })) n += 1;
    if (setValue('prn_code', v('prn_code'), { ai: true })) n += 1;
    const sa = findPerson(v('dc_sa_name'), { team: 'DC SA' });
    if (sa && setValue('dc_sa_id', sa.id, { ai: true })) n += 1;
    if (v('dc_intake') && !intakeInput.value) { intakeInput.value = v('dc_intake'); values.dc_intake = v('dc_intake'); }
    return n;
  }

  // ---------------------------------------------------------------- form
  const lobSel = ui.selectEl(state.options('lob'), '', { placeholder: 'Choose LOB', ariaLabel: 'LOB' });
  const prioSel = ui.selectEl(state.options('priority'), '', { placeholder: 'Choose priority', ariaLabel: 'Priority' });
  const reqSel = ui.selectEl(people({ team: 'Business' }), '', { placeholder: 'Choose requestor', ariaLabel: 'Requestor' });
  const defaultPm = state.persona() === 'DC PM' ? (state.people({ team: 'DC PM' })[0] || null) : null;
  const pmSel = ui.selectEl(people({ team: 'DC PM' }), defaultPm ? defaultPm.id : '', { placeholder: '—', ariaLabel: 'DC PM' });
  if (defaultPm) values.dc_pm_id = String(defaultPm.id);
  const saSel = ui.selectEl(people({ team: 'DC SA' }), '', { placeholder: '—', ariaLabel: 'DC SA' });
  const leadSel = ui.selectEl(people({ tracked: true }), '', { placeholder: '—', ariaLabel: 'Tech/Dev Lead' });
  const trainSel = ui.selectEl(trains, '', { placeholder: '—', ariaLabel: 'Target Release' });
  const nameIn = h('input.input', { type: 'text', maxLength: 80, placeholder: 'Business name of the change' });
  const goLiveIn = h('input.input', { type: 'date' });
  const labelsIn = h('input.input', { type: 'text', placeholder: 'For example: payments, api' });
  const prnIn = h('input.input', { type: 'text', placeholder: 'PRN-#####' });
  const descIn = h('textarea.input.desc-box', { rows: 5, placeholder: 'What is changing, for whom, and why' });

  const saveBtn = ui.btn('Save', { variant: 'primary', onClick: () => save() });
  const formGrid = h('div.form-grid',
    h('div.form-field', h('span.form-label', 'RDDC #'), h('div.input.readonly-field', { style: { display: 'flex', 'align-items': 'center', background: 'var(--cell-label)', color: 'var(--ink-3)' } }, 'Assigned when you save')),
    h('div.form-field', h('span.form-label', 'DC Intake'), h('div.btn-row', { style: { 'flex-wrap': 'nowrap' } }, intakeInput, lookupBtn), intakeList, intakeNote),
    field('name', 'Project Name', nameIn),
    field('lob', 'LOB', lobSel),
    field('priority', 'Priority', prioSel),
    field('requestor', 'Requestor', reqSel),
    field('requested_go_live', 'Requested Go-live', goLiveIn),
    field('target_release', 'Target Release', trainSel),
    field('dc_pm_id', 'DC PM', pmSel),
    field('dc_sa_id', 'DC SA', saSel),
    field('tech_lead_id', 'Tech/Dev Lead', leadSel),
    field('prn_code', 'PRN', prnIn),
    field('labels', 'Labels', labelsIn, { span2: true, hint: 'Separate labels with commas.' }),
    field('description', 'Description of Change', descIn, { span2: true }),
  );

  function validate() {
    let ok = true;
    for (const [key, label] of Object.entries(REQUIRED)) {
      const v = String(values[key] ?? '').trim();
      if (!v) { setError(key, `${label} is required.`); ok = false; }
    }
    if (values.prn_code && !/^PRN-\d{5}$/i.test(values.prn_code.trim())) { setError('prn_code', 'Use the format PRN-#####.'); ok = false; }
    if (values.requested_go_live && !dates.isISODate(values.requested_go_live)) { setError('requested_go_live', 'Enter a valid date.'); ok = false; }
    return ok;
  }

  async function save() {
    if (!validate()) {
      const first = Object.keys(errors).find((k) => !errors[k].hidden);
      if (first) inputs[first].focus();
      ui.toast('Some fields need attention.', { variant: 'warning' });
      return;
    }
    const body = {
      name: values.name.trim(),
      lob: values.lob,
      priority: Number(values.priority),
      requestor: state.personName(values.requestor_id) || null,
      requestor_id: values.requestor_id || null,
      requested_go_live: values.requested_go_live,
      description: values.description.trim(),
      dc_intake: values.dc_intake || intakeInput.value.trim().toUpperCase() || null,
      dc_pm_id: values.dc_pm_id ? Number(values.dc_pm_id) : null,
      dc_sa_id: values.dc_sa_id ? Number(values.dc_sa_id) : null,
      tech_lead_id: values.tech_lead_id ? Number(values.tech_lead_id) : null,
      labels: String(values.labels || '').split(',').map((s) => s.trim()).filter(Boolean),
    };
    if (values.target_release) body.target_release = values.target_release;
    if (values.pm_id) body.pm_id = Number(values.pm_id);
    if (values.prn_code) body.prn_code = values.prn_code.trim().toUpperCase();
    const restore = ui.busy(saveBtn, 'Saving…');
    try {
      const res = await api.createInitiative(body);
      const ini = res.initiative;
      ui.toast(`${ini.rddc} created.`);
      const g = res.grooming;
      const names = Array.from(new Set((res.queued_notifications || []).map((n) => n.to_name).filter(Boolean)));
      if (g) {
        const when = g.label || `${dates.fmtDay(g.session_date)}, ${dates.fmtTime(g.start_time, '10:00')}`;
        ui.toast(`Slotted for grooming ${when}.${names.length ? ` Invite queued to ${names.join(', ')}.` : ''}`, { duration: 8000 });
      }
      if (saFile) {
        try {
          const up = await api.uploadAttachment(ini.id, saFile, { kind: 'sa_doc' });
          if (up && up.sa) ui.toast(`SA document attached · SA Completeness ${dates.fmtPct(up.sa.completeness)}.`);
        } catch (err) {
          ui.toast(`The SA document could not be attached (${err.message || 'file not readable'}). Attach it on Pg 1.`, { variant: 'warning' });
        }
      }
      state.pendingAutoRun = { initiativeId: ini.id, feature: 'intake_analysis' };
      state.emit('ai:applied', { feature: 'create' });
      navigate(`#/initiative/${ini.id}/pg1`);
    } catch (err) {
      restore();
      const fields = err && err.details && err.details.fields;
      if (fields) for (const [k, msg] of Object.entries(fields)) setError(k, msg);
      ui.toastError(err);
    }
  }

  root.append(h('div.view-pad', ui.pageBox({
    pg: 'PG 1', title: 'Add New Initiative', hint: 'RDDC # is assigned when you save',
  },
  h('div.two-col', { style: { 'grid-template-columns': 'minmax(0,3fr) minmax(0,2fr)', 'align-items': 'start' } },
    formGrid,
    h('div.stack',
      ui.card({ title: 'SA document' }, h('p.small.muted', 'Drop the SA document to fill the form for you. Every filled field is marked AI so you can check it.'), dz.el),
      autofillSlot,
      ui.card({ title: 'What happens when you save' }, h('ol.ai-list',
        h('li', 'The next RDDC # is assigned.'),
        h('li', 'The intake is slotted into the next grooming session (Tue/Thu 10:00 ET) and invites are queued in the Outbox.'),
        h('li', 'Intake Analysis checks completeness, likely DC components and possible duplicates.'))))),
  h('div.page-footer',
    ui.btn('Cancel', { variant: 'secondary', onClick: () => navigate('#/search') }),
    saveBtn))));
  nameIn.focus();
}
