// Assistant drawer (UX §2.6). mount(drawerEl, ctx) builds the panel; open(context?) shows it with page context.
// Answers are rendered with the safe markdown renderer (no HTML), revealed in small chunks, with citation chips.
import {
  api, h, clear, button, chip, modeChip, renderMarkdown, markdownToText, copyText, toast, go, getSettingsSafe, itemsOf, errorBox,
} from '../charts/kit.js';

const PAGE_LABEL = {
  portfolio: 'Portfolio View', search: 'Search Initiative', intake: 'Intake & Grooming', resources: 'Resources', risks: 'Risk Register',
  changes: 'Change Management', artifacts: 'Artifacts', outbox: 'Outbox', 'ai-activity': 'AI Activity', settings: 'Settings',
};
const TAB_LABEL = {
  pg1: 'Pg 1 General Details', pg2: 'Pg 2 Project Plan', pg3: 'Pg 3 Resource Management', pg4: 'Pg 4 Change Governance',
  pg5: 'Pg 5 Portfolio View', risks: 'Risks', artifacts: 'Artifacts', print: 'Print view',
};
const CHECK_PHRASE = {
  initiative: 'Checked initiative health and key dates', resource: 'Checked people and availability', allocation: 'Checked allocations by month',
  wbs_task: 'Checked WBS steps', crq: 'Checked change requests', change_request: 'Checked change requests', risk: 'Checked the risk register',
  prn: 'Checked PRN burndown', component: 'Checked DC components', grooming: 'Checked grooming sessions', notification: 'Checked the Outbox',
  decision: 'Checked the Decision Log', skill: 'Checked the skill matrix', release_train: 'Checked release trains',
};
const PROMPTS = {
  initiative: ["What's driving the health status?", 'Who is over-allocated on this initiative?', 'Summarise this initiative for the steering call', 'What are the top risks?'],
  resources: ['Who has CIAM capacity in January?', 'Who is over 100% next month?', 'Who knows Kafka?'],
  changes: ['Which CRQs are non-compliant this week?', 'What approvals are pending?', 'Which initiatives are on DC-2702?'],
  default: ['Which initiatives are at risk for the Feb release and why?', "Draft this week's exec summary", 'Who has CIAM capacity in January?', 'Which CRQs are non-compliant this week?'],
};

const S = { drawer: null, ctx: null, log: null, input: null, sendBtn: null, ctxLine: null, modeEl: null, conversationId: null, context: null, busy: false, initiatives: null, listening: false, hosted: false };

const reduceMotion = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function contextFromHash() {
  const hash = window.location.hash || '#/portfolio';
  const m = /^#\/initiative\/(\d+)(?:\/([\w-]+))?/.exec(hash);
  if (m) return { initiative_id: Number(m[1]), page: m[2] || 'pg1' };
  const page = (/^#\/([\w-]+)/.exec(hash) || [null, 'portfolio'])[1];
  return { initiative_id: null, page };
}

async function contextLabel(context) {
  if (!context) return 'Portfolio View';
  if (context.label) return context.label;
  if (context.initiative_id) {
    if (!S.initiatives) {
      try { S.initiatives = itemsOf(await api.listInitiatives({})); } catch { S.initiatives = []; }
    }
    let hit = S.initiatives.find((i) => String(i.id) === String(context.initiative_id));
    if (!hit) {
      try { S.initiatives = itemsOf(await api.listInitiatives({})); } catch { S.initiatives = S.initiatives || []; }
      hit = S.initiatives.find((i) => String(i.id) === String(context.initiative_id));
    }
    const name = hit ? `${hit.rddc} · ${hit.name}` : 'This initiative';
    return `${name} · ${TAB_LABEL[context.page] || 'Workspace'}`;
  }
  return PAGE_LABEL[context.page] || 'Portfolio View';
}

async function refreshContext(context) {
  S.context = context || contextFromHash();
  const label = await contextLabel(S.context);
  if (S.ctxLine) S.ctxLine.textContent = `Context: ${label}`;
  if (S.input) S.input.placeholder = S.context.initiative_id ? 'Ask about this initiative…' : 'Ask about initiatives, people or risks…';
}

function suggestions() {
  const c = S.context || {};
  const list = c.initiative_id ? PROMPTS.initiative : PROMPTS[c.page] || PROMPTS.default;
  return h('div', { class: 'dv-drawer-try' },
    h('div', { class: 'dv-muted', text: c.initiative_id ? "Ask about this initiative's plan, people or risks. Try:" : 'Ask about initiatives, people, capacity or risks. Try:' }),
    h('div', { class: 'dv-chips' }, list.map((q) => h('button', { type: 'button', class: 'dv-chip dv-chip-link', on: { click: () => send(q) } }, q))));
}

function checksFor(res) {
  const seen = new Set();
  const out = [];
  for (const c of Array.isArray(res.citations) ? res.citations : []) {
    const phrase = CHECK_PHRASE[c.type];
    if (phrase && !seen.has(phrase)) { seen.add(phrase); out.push(phrase); }
  }
  if (!out.length) out.push('Checked portfolio data');
  return out.slice(0, 4);
}

async function reveal(mdRoot, fast) {
  if (fast || reduceMotion()) return;
  const walker = document.createTreeWalker(mdRoot, NodeFilter.SHOW_TEXT);
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  const full = nodes.map((n) => n.nodeValue);
  const total = full.reduce((s, t) => s + t.length, 0);
  nodes.forEach((n) => { n.nodeValue = ''; });
  mdRoot.classList.add('dv-caret');
  const chunk = Math.max(3, Math.ceil(total / 110));
  for (let i = 0; i < nodes.length; i += 1) {
    let pos = 0;
    while (pos < full[i].length) {
      pos = Math.min(full[i].length, pos + chunk);
      nodes[i].nodeValue = full[i].slice(0, pos);
      await sleep(18 + Math.floor(Math.random() * 12));
    }
  }
  mdRoot.classList.remove('dv-caret');
}

const FALLBACK_INTENTS = new Set(['help', 'fallback', 'unknown', 'unsupported', 'cant_answer']);
/** An honest "can't answer that yet" reply: no fake "Checked …" steps. */
function isFallback(res) {
  return Boolean(res && (res.fallback || FALLBACK_INTENTS.has(res.intent)));
}
/** Compact table for structured answers (PRN burn, CRQ readiness, what-if) when the text has no table of its own. */
function answerTable(table) {
  const cell = (v) => (v === null || v === undefined || v === '' ? '—' : typeof v === 'object' ? (v.label ?? JSON.stringify(v)) : String(v));
  return h('div', { class: 'dv-md' }, h('table', {},
    h('thead', {}, h('tr', {}, table.columns.map((c) => h('th', { text: cell(c) })))),
    h('tbody', {}, table.rows.slice(0, 20).map((row) => h('tr', {}, (Array.isArray(row) ? row : table.columns.map((c) => row[c])).map((v) => h('td', { text: cell(v) })))))));
}

function routeChip(label, route, title) {
  if (typeof route === 'string' && route.startsWith('#/')) {
    return h('a', { class: 'dv-chip dv-chip-link', href: route, title, on: { click: (e) => { e.preventDefault(); go(S.ctx, route); } } }, label);
  }
  return chip(label, '', { title });
}

async function send(text) {
  const message = String(text || '').trim();
  if (!message || S.busy) return;
  S.busy = true;
  S.sendBtn.disabled = true;
  S.input.value = '';
  const tryBox = S.log.querySelector('.dv-drawer-try');
  if (tryBox) tryBox.remove();
  S.log.appendChild(h('div', { class: 'dv-msg-user', text: message }));
  const who = h('div', { class: 'dv-msg-who' }, h('span', { text: 'Assistant' }));
  const checks = h('ul', { class: 'dv-checks' });
  const bodyEl = h('div', { class: 'dv-muted', text: 'Checking the latest data…' });
  const bot = h('div', { class: 'dv-msg-bot', 'data-testid': 'assistant-answer' }, who, checks, bodyEl);
  S.log.appendChild(bot);
  S.log.scrollTop = S.log.scrollHeight;
  const settings = await getSettingsSafe();
  const fast = settings.ai_speed === 'Fast';
  try {
    const ctxNow = S.context || contextFromHash();
    const res = await api.chat({ message, conversation_id: S.conversationId || undefined, initiative_id: ctxNow.initiative_id || undefined, page: ctxNow.page || undefined });
    S.conversationId = res.conversation_id || S.conversationId;
    who.appendChild(modeChip(res.mode_label, res.mode));
    const fallback = isFallback(res);
    for (const c of fallback ? [] : checksFor(res)) {
      checks.appendChild(h('li', { text: c }));
      S.log.scrollTop = S.log.scrollHeight;
      if (!fast && !reduceMotion()) await sleep(280);
    }
    const md = renderMarkdown(res.answer_md || 'I could not find an answer in the current data.', S.ctx);
    bodyEl.replaceWith(md);
    await reveal(md, fast);
    if (!fallback && res.table && Array.isArray(res.table.columns) && Array.isArray(res.table.rows) && res.table.rows.length && !/^\s*(\||[-*•]\s|\d+[.)]\s)/m.test(res.answer_md || '')) {
      bot.appendChild(answerTable(res.table));
    }
    const citations = Array.isArray(res.citations) ? res.citations : [];
    if (citations.length) bot.appendChild(h('div', { class: 'dv-chips', 'data-testid': 'assistant-sources' }, h('span', { class: 'dv-muted', text: 'Sources:' }), citations.map((c) => routeChip(c.label || String(c.id ?? ''), c.route, c.type))));
    const actions = (Array.isArray(res.suggested_actions) ? res.suggested_actions : []).filter((a) => typeof a.route === 'string' && a.route.startsWith('#/'));
    if (actions.length) bot.appendChild(h('div', { class: 'dv-chips' }, actions.map((a) => h('a', { class: 'btn btn-secondary btn-sm', href: a.route, on: { click: (e) => { e.preventDefault(); go(S.ctx, a.route); } } }, a.label))));
    const emailText = `${markdownToText(res.answer_md)}${citations.length ? `\n\nSources: ${citations.map((c) => c.label).filter(Boolean).join(', ')}` : ''}`;
    bot.appendChild(h('div', { class: 'dv-chips' },
      button('Copy to email', () => copyText(emailText).then(() => toast('Copied. Paste it into your email.'), (e) => toast(e.message, 'warning')), { kind: 'secondary', small: true })));
    const follow = Array.isArray(res.follow_ups) ? res.follow_ups.filter(Boolean) : [];
    if (follow.length) {
      bot.appendChild(h('div', { class: 'dv-chips' },
        fallback ? h('span', { class: 'dv-muted', text: 'Questions I can answer from the live records:' }) : null,
        follow.slice(0, fallback ? 5 : 3).map((q) => h('button', { type: 'button', class: 'dv-chip dv-chip-link', on: { click: () => send(q) } }, q))));
    }
  } catch (err) {
    bodyEl.replaceWith(errorBox(err, () => { bot.remove(); send(message); }));
  } finally {
    S.busy = false;
    S.sendBtn.disabled = false;
    S.log.scrollTop = S.log.scrollHeight;
    S.input.focus();
  }
}

function newConversation() {
  S.conversationId = null;
  clear(S.log);
  S.log.appendChild(suggestions());
}

export function mount(drawerEl, ctx) {
  S.drawer = drawerEl;
  S.ctx = ctx;
  S.hosted = drawerEl.classList.contains('drawer-body');
  clear(drawerEl);
  drawerEl.classList.add('dv-drawer');
  S.ctxLine = h('div', { class: 'dv-drawer-ctx', text: 'Context: Portfolio View' });
  S.modeEl = h('span', { class: 'dv-mode', text: 'Simulated AI' });
  S.log = h('div', { class: 'dv-drawer-log', role: 'log', 'aria-live': 'polite' });
  S.input = h('textarea', { class: 'dv-textarea', rows: 1, 'aria-label': 'Ask the assistant', placeholder: 'Ask about initiatives, people or risks…' });
  S.sendBtn = button('Ask', () => send(S.input.value), { kind: 'primary' });
  S.input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(S.input.value); }
  });
  // Inside the shell drawer the title, context line, mode badge and close button live in the drawer head.
  drawerEl.append(
    S.hosted
      ? h('div', { class: 'dv-drawer-tools' }, button('New conversation', newConversation, { kind: 'text', small: true }))
      : h('div', { class: 'dv-drawer-head' },
        h('span', { class: 'dv-drawer-title', text: 'Assistant' }),
        S.modeEl,
        h('span', { class: 'dv-drawer-head-actions' },
          button('New', newConversation, { kind: 'text', small: true, attrs: { title: 'Start a new conversation', 'aria-label': 'New conversation' } }),
          button('✕', close, { kind: 'text', small: true, attrs: { 'aria-label': 'Close assistant', title: 'Close (Esc)' } }))),
    S.hosted ? null : S.ctxLine, S.log,
    h('div', { class: 'dv-drawer-foot' }, S.input, S.sendBtn));
  if (!S.hosted) drawerEl.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
  if (!S.listening) {
    S.listening = true;
    window.addEventListener('hashchange', () => { if (isOpen()) refreshContext(); });
    window.addEventListener('bmo:assistant-open', (e) => open(e.detail || undefined));
  }
  api.getAppHealth().then((hl) => {
    const live = hl && hl.ai_mode === 'live';
    S.modeEl.textContent = live ? '● Live Claude' : '● Simulated AI';
    S.modeEl.title = live ? 'Answers come from Claude using this tool\'s data' : 'Answers come from prepared responses and rules over this tool\'s data';
    S.modeEl.className = `dv-mode ${live ? 'dv-mode-live' : 'dv-mode-sim'}`;
  }, () => {});
  newConversation();
  refreshContext();
  return { open, close };
}

function isOpen() {
  if (!S.drawer || S.drawer.hidden) return false;
  const shell = S.drawer.closest('.drawer');
  return shell ? shell.classList.contains('open') : S.drawer.classList.contains('is-open');
}

/** Opens the drawer. context: {initiative_id?, page?, label?, question?}; defaults to the current route. */
export function open(context) {
  if (!S.drawer) return;
  if (!S.hosted) {
    S.drawer.hidden = false;
    S.drawer.setAttribute('aria-hidden', 'false');
    document.body.classList.add('assistant-open');
  }
  S.drawer.classList.add('is-open');
  window.dispatchEvent(new CustomEvent('bmo:assistant-toggle', { detail: { open: true } }));
  const base = contextFromHash();
  const given = context && typeof context === 'object' ? context : {};
  const ctx = {
    ...base,
    initiative_id: given.initiative_id ?? given.initiativeId ?? base.initiative_id,
    label: given.label || null,
    question: given.question || null,
  };
  refreshContext(ctx).then(() => {
    if (!S.log.querySelector('.dv-msg-user')) newConversation();
    if (ctx.question) send(ctx.question);
    else S.input.focus();
  });
}

export function close() {
  if (!S.drawer) return;
  S.drawer.classList.remove('is-open');
  const ui = S.ctx && S.ctx.ui;
  if (S.hosted && ui && typeof ui.closeDrawer === 'function') ui.closeDrawer();
  else {
    S.drawer.hidden = true;
    S.drawer.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('assistant-open');
  }
  window.dispatchEvent(new CustomEvent('bmo:assistant-toggle', { detail: { open: false } }));
}
