export async function render(root, params, ctx) {
  const { api, ui, navigate } = ctx;
  const { h } = ui;
  let status = await api.request('GET', '/experimental/status');
  const content = h('div.stack');
  const errorSlot = h('div', { attrs: { role: 'alert' } });
  root.append(h('div.view-pad', ui.pageBox({ title: 'Experimental · Jira', hint: 'Capture ticket information as JSON, review the extracted fields, then choose what enters the portfolio.' },
    h('div.notice.notice-amber', 'Integration lab · local password sign-in protects this tab. Enterprise Jira access uses the account configured on the server.'), errorSlot, content)));
  const call = (path, body) => api.request('POST', `/experimental/${path}`, { body, headers: { 'X-Portal-CSRF': status.csrf }, timeout: 30000 });
  const fail = err => { ui.mount(errorSlot, ui.errorPanel(err)); };
  function paint() {
    ui.mount(errorSlot);
    if (!status.authenticated) {
      const password = h('input.input', { type: 'password', minLength: 12, maxLength: 256, required: true, autocomplete: status.configured ? 'current-password' : 'new-password', aria: { label: 'Integration lab password' } });
      const submit = ui.btn(status.configured ? 'Sign in' : 'Create lab password', { variant: 'primary', onClick: () => form.requestSubmit() });
      const form = h('form', { on: { submit: async e => {
        e.preventDefault(); const restore = ui.busy(submit, 'Signing in…');
        try { status = await call(status.configured ? 'login' : 'setup', { password: password.value }); password.value = ''; paint(); }
        catch (err) { fail(err); } finally { restore(); }
      } } }, h('label.form-field', h('span.form-label', 'Integration lab password'), password), submit);
      ui.mount(content, ui.card({ title: status.configured ? 'Sign in to the integration lab' : 'Set up the integration lab' },
        h('p.muted', status.configured ? 'Your session lasts up to eight hours. This password is separate from Jira.' : 'Create a password of at least 12 characters from this computer. The portal stores a password hash.'), form));
      return;
    }
    const json = h('textarea.input.json-input', { rows: 14, placeholder: 'Paste a Jira issue JSON object, a Jira export array, or { "issues": [...] }', aria: { label: 'Jira JSON' }, spellcheck: false });
    const file = h('input.input', { type: 'file', accept: '.json,application/json', aria: { label: 'Jira JSON file' }, on: { change: async () => {
      if (file.files[0]?.size > 10 * 1024 * 1024) { ui.toast('Choose a JSON file smaller than 10 MB.', { variant: 'warning' }); return; }
      if (file.files[0]) json.value = await file.files[0].text();
    } } });
    const preview = ui.btn('Preview JSON intake', { variant: 'primary', onClick: async () => {
      const restore = ui.busy(preview, 'Reading JSON…');
      try { const payload = JSON.parse(json.value); const result = await call('json-preview', { type: 'intake', payload }); navigate(`#/imports?batch=${encodeURIComponent(result.id)}`); }
      catch (err) { fail(err instanceof SyntaxError ? new Error('The JSON is invalid. Paste the original JSON response or choose a valid .json file.') : err); }
      finally { restore(); }
    } });
    const issue = h('input.input', { placeholder: 'BIDC-123', maxLength: 45, aria: { label: 'Jira issue key' } });
    const fetch = ui.btn('Fetch issue and preview', { variant: 'primary', disabled: !status.jira_configured, onClick: async () => {
      const restore = ui.busy(fetch, 'Reading Jira…');
      try { const response = await call('jira-fetch', { issue_key: issue.value }); const result = await call('json-preview', { type: 'intake', payload: response.payload }); navigate(`#/imports?batch=${encodeURIComponent(result.id)}`); }
      catch (err) { fail(err); } finally { restore(); }
    } });
    ui.mount(content,
      h('div.btn-row', h('span.status-pill', 'Signed in'), ui.btn('Sign out', { onClick: async () => { try { await call('logout', {}); status = await api.request('GET', '/experimental/status'); paint(); } catch (err) { fail(err); } } })),
      ui.card({ title: 'Capture from JSON' }, h('p.muted', 'Choose a saved Jira JSON response or paste it below. Issue keys, rich text descriptions, labels, people, and custom fields are retained for review.'), file, json, preview),
      ui.card({ title: 'Read an authenticated Jira issue' }, h('p.muted', status.jira_configured ? `Connected host: ${status.jira_base_url}` : 'Jira is not configured yet. Set the server variables below to enable a read-only issue request.'),
        h('div.btn-row', issue, fetch),
        h('details.source-evidence', h('summary', 'Jira connection setup'), h('pre', 'BMO_JIRA_BASE_URL=https://your-jira-host\nBMO_JIRA_TOKEN=<API token or bearer token>\nBMO_JIRA_EMAIL=<email for Basic auth; omit for Bearer>\nBMO_JIRA_API_VERSION=3'),
          h('p.muted', 'Restart the server after configuration. Credentials stay on the server. SSO browser cookies cannot be reused by this connector; a supported API token or service identity is needed.'))),
      ui.card({ title: 'Future document intelligence · Amazon Bedrock' }, h('p', status.bedrock?.enabled ? 'Bedrock is explicitly enabled. Review Settings for provider readiness.' : 'Rules are active. Bedrock is disabled until it is explicitly configured.'),
        h('a', { href: '#/settings' }, 'View parsing and provider settings')));
  }
  paint();
}
