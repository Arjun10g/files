// Artifacts (#/artifacts): Documents · Decision Log · Architecture · Lessons Learned (AI draft) · Meeting Notes (AI extract).
import {
  api, h, clear, dataTable, autoButton, button, pageHeader, errorBox, loading, emptyState, selectEl, chip, tabs, statusPill,
  fmtDate, getLookups, getToday, getSettingsSafe, go, itemsOf, runAi, bulletList, toast, announceChange, num, framePage,
} from '../charts/kit.js';

const TABS = [
  { value: 'documents', label: 'Documents' }, { value: 'decisions', label: 'Decision Log' }, { value: 'architecture', label: 'Architecture' },
  { value: 'lessons', label: 'Lessons Learned' }, { value: 'notes', label: 'Meeting Notes' },
];
const SOURCE_LABEL = { manual: 'Manual', ai: 'AI', system: 'Automatic', seed: 'Imported' };
let lastTab = 'documents';

function rddcLink(ctx, row, tab = 'artifacts') {
  if (!row.initiative_id) return row.rddc || 'Portfolio';
  return h('a', { class: 'dv-link', href: `#/initiative/${row.initiative_id}/${tab}`, on: { click: (e) => { e.preventDefault(); go(ctx, `#/initiative/${row.initiative_id}/${tab}`); } } }, row.rddc || `Initiative ${row.initiative_id}`);
}
function sourceCell(src) {
  return src === 'ai' ? h('span', { class: 'dv-tag-ai', text: 'AI' }) : (SOURCE_LABEL[src] || 'Manual');
}

export async function render(root, params, ctx) {
  const page = framePage(root, 'artifacts');
  page.appendChild(pageHeader({ title: 'Artifacts', hint: 'Documents, decisions, architecture, lessons and meeting notes across initiatives' }));
  const initial = TABS.some((t) => t.value === (params && params.tab)) ? params.tab : lastTab;
  const body = h('div');
  page.append(tabs(TABS, initial, (v) => { lastTab = v; show(v); }), body);

  const [lookups, today, settings] = await Promise.all([getLookups(ctx).catch(() => ({})), getToday(ctx), getSettingsSafe()]);
  const resourceName = (id) => {
    const r = (lookups.resources || []).find((x) => String(x.id) === String(id));
    return r ? r.name : null;
  };
  let initiatives = null;
  const getInitiatives = async () => {
    if (!initiatives) initiatives = itemsOf(await api.listInitiatives({}));
    return initiatives;
  };

  async function show(tab) {
    clear(body);
    body.appendChild(loading());
    try {
      if (tab === 'documents') await showDocuments(false);
      else if (tab === 'architecture') await showDocuments(true);
      else if (tab === 'decisions') await showDecisions();
      else if (tab === 'lessons') await showLessons();
      else await showNotes();
    } catch (err) {
      clear(body);
      body.appendChild(errorBox(err, () => show(tab)));
    }
  }

  async function showDocuments(architecture) {
    const docs = itemsOf(await api.listArtifacts('documents'));
    clear(body);
    let rows = architecture ? docs.filter((d) => d.doc_type === 'SA' || d.doc_type === 'Architecture') : docs;
    const columns = [
      { key: 'title', label: 'Title', cls: 'dv-cell-wrap' },
      { key: 'rddc', label: 'RDDC #', render: (r) => rddcLink(ctx, r) },
      { key: 'doc_type', label: 'Type' },
      { key: 'version', label: 'Version' },
      architecture
        ? { key: 'components', label: 'Components', sortable: false, render: (r) => (Array.isArray(r.components) && r.components.length ? h('div', { class: 'dv-flags' }, r.components.map((c) => chip(componentName(c)))) : '—') }
        : { key: 'owner_id', label: 'Owner', render: (r) => r.owner_name || resourceName(r.owner_id) || '—' },
      { key: 'status', label: 'Status', render: (r) => (r.status ? statusPill(r.status) : '—') },
      { key: 'updated_at', label: 'Updated', render: (r) => fmtDate(String(r.updated_at || '').slice(0, 10)) },
      { key: 'file', label: 'File', sortable: false, render: (r) => (r.attachment_id ? h('a', { class: 'dv-link', href: api.attachmentDownloadUrl(r.attachment_id), download: '' }, 'Download') : '—') },
    ];
    const table = dataTable({ columns, rows, sortKey: 'updated_at', sortDir: 'desc', caption: architecture ? 'Architecture repository' : 'Documents', empty: architecture ? 'No SA or architecture documents yet.' : "No documents yet. Drop files on an initiative's Artifacts tab to add them." });
    if (architecture) {
      const comps = (lookups.components || []).map((c) => ({ value: c.code, label: c.name }));
      const search = h('input', { class: 'dv-input', type: 'search', placeholder: 'Search title or RDDC #', 'aria-label': 'Search architecture documents' });
      let comp = '';
      const apply = () => {
        const q = search.value.trim().toLowerCase();
        rows = docs.filter((d) => (d.doc_type === 'SA' || d.doc_type === 'Architecture')
          && (!comp || (Array.isArray(d.components) && d.components.includes(comp)))
          && (!q || `${d.title} ${d.rddc || ''}`.toLowerCase().includes(q)));
        table.update(rows);
      };
      search.addEventListener('input', apply);
      body.appendChild(h('div', { class: 'dv-filters' },
        selectEl(comps, '', (v) => { comp = v; apply(); }, { label: 'DC Component', allLabel: 'All components' }),
        h('label', { class: 'dv-field' }, h('span', { class: 'dv-field-label', text: 'Search' }), search)));
    }
    body.appendChild(table.el);
  }

  function componentName(code) {
    const c = (lookups.components || []).find((x) => x.code === code);
    return c ? c.name : code;
  }

  async function showDecisions() {
    const items = itemsOf(await api.listArtifacts('decisions'));
    clear(body);
    const formHost = h('div', { hidden: true, class: 'dv-detail' });
    body.append(h('div', { class: 'dv-filters' }, button('+ Add decision', () => openForm(), { kind: 'secondary' })), formHost);
    body.appendChild(dataTable({
      caption: 'Decision Log', sortKey: 'decided_on', sortDir: 'desc', empty: 'No decisions logged yet.',
      columns: [
        { key: 'decided_on', label: 'Date', render: (r) => fmtDate(r.decided_on || String(r.created_at || '').slice(0, 10)) },
        { key: 'rddc', label: 'RDDC #', render: (r) => rddcLink(ctx, r) },
        { key: 'title', label: 'Decision', cls: 'dv-cell-wrap', render: (r) => h('div', {}, h('strong', { text: r.title }), r.decision && r.decision !== r.title ? h('div', { class: 'dv-muted', text: r.decision }) : null) },
        { key: 'decided_by', label: 'By' },
        { key: 'status', label: 'Status', render: (r) => statusPill(r.status) },
        { key: 'source', label: 'Source', render: (r) => sourceCell(r.source) },
      ],
      rows: items,
    }).el);

    async function openForm() {
      formHost.hidden = false;
      clear(formHost);
      const inits = await getInitiatives();
      const initSel = selectEl(inits.map((i) => ({ value: i.id, label: `${i.rddc} · ${i.name}` })), '', null, { label: 'Initiative', allLabel: 'Portfolio-wide' });
      const title = h('input', { class: 'dv-input', type: 'text', maxlength: '120', 'aria-label': 'Decision title' });
      const text = h('textarea', { class: 'dv-textarea', rows: 3, 'aria-label': 'Decision detail' });
      const by = h('input', { class: 'dv-input', type: 'text', 'aria-label': 'Decided by' });
      by.value = settings.persona || '';
      const error = h('div', { class: 'dv-form-error', role: 'alert' });
      formHost.append(
        h('div', { class: 'dv-filters' }, initSel, h('label', { class: 'dv-field' }, h('span', { class: 'dv-field-label', text: 'Decided by' }), by)),
        h('label', { class: 'dv-form-row' }, h('span', { text: 'Decision' }), title),
        h('label', { class: 'dv-form-row' }, h('span', { text: 'Context and detail' }), text),
        error,
        h('div', { class: 'dv-filters' },
          button('Save decision', async (e) => {
            const btn = e.currentTarget;
            if (!title.value.trim()) { error.textContent = 'Enter the decision.'; title.focus(); return; }
            btn.disabled = true;
            try {
              const sel = initSel.querySelector('select');
              await api.createArtifact('decisions', {
                initiative_id: sel.value ? Number(sel.value) : null, title: title.value.trim(), decision: text.value.trim() || title.value.trim(),
                decided_by: by.value.trim() || null, decided_on: today, status: 'Approved', source: 'manual',
              });
              toast('Decision logged.');
              await showDecisions();
            } catch (err) {
              error.textContent = err.message;
              btn.disabled = false;
            }
          }, { kind: 'primary' }),
          button('Cancel', () => { formHost.hidden = true; }, { kind: 'text' })));
      title.focus();
    }
  }

  async function showLessons() {
    const [items, inits] = await Promise.all([api.listArtifacts('lessons'), getInitiatives()]);
    clear(body);
    const closed = inits.filter((i) => i.stage === 'Closed');
    const aiHost = h('div', { class: 'dv-ai-host', hidden: true });
    let target = closed[0] ? String(closed[0].id) : '';
    const draftBtn = autoButton('Draft lessons learned', () => runAi(aiHost, {
      feature: 'lessons', title: 'Lessons learned', trigger: draftBtn,
      body: { initiative_id: Number(target), options: { initiative_id: Number(target) } },
      preview: (run) => {
        const o = run.output || {};
        const lessons = Array.isArray(o.lessons) ? o.lessons : [];
        const acc = o.estimate_accuracy;
        return h('div', {},
          acc && Number.isFinite(Number(acc.planned_hours)) ? h('p', { text: `Planned ${num(acc.planned_hours)} h · actual ${num(acc.actual_hours)} h · variance ${num(acc.variance_pct)}%${Array.isArray(acc.worst_phases) && acc.worst_phases.length ? ` · worst: ${acc.worst_phases.join(', ')}` : ''}` }) : null,
          lessons.length ? h('ol', { class: 'dv-bullets' }, lessons.map((l) => h('li', {},
            h('strong', { text: `${l.category || 'Lesson'}${l.kind === 'keep' ? ' · keep doing' : l.kind === 'improve' ? ' · improve' : ''}: ` }), l.lesson || '',
            l.what_happened ? h('div', { class: 'dv-muted', text: l.what_happened }) : null,
            l.recommendation ? h('div', { text: `Recommendation: ${l.recommendation}` }) : null))) : h('p', { class: 'dv-muted', text: 'No lessons proposed.' }));
      },
      acceptMessage: (res) => {
        const n = res && res.applied ? Object.values(res.applied).reduce((a, b) => a + num(b), 0) : 0;
        return n ? `${n} lessons saved.` : 'Lessons learned accepted.';
      },
      onApplied: () => showLessons(),
    }));
    if (!closed.length) draftBtn.disabled = true;
    body.append(
      h('div', { class: 'dv-filters' },
        selectEl(closed.map((i) => ({ value: i.id, label: `${i.rddc} · ${i.name}` })), target, (v) => { target = v; }, { label: 'Closed initiative' }),
        draftBtn,
        closed.length ? null : h('span', { class: 'dv-muted', text: 'Lessons can be drafted once an initiative is closed.' })),
      aiHost,
      dataTable({
        caption: 'Lessons learned', sortKey: 'rddc', empty: 'No lessons recorded yet.',
        columns: [
          { key: 'rddc', label: 'RDDC #', render: (r) => rddcLink(ctx, r) },
          { key: 'category', label: 'Category' },
          { key: 'what_happened', label: 'What happened', cls: 'dv-cell-wrap' },
          { key: 'lesson', label: 'Lesson', cls: 'dv-cell-wrap' },
          { key: 'recommendation', label: 'Recommendation', cls: 'dv-cell-wrap' },
          { key: 'source', label: 'Source', render: (r) => sourceCell(r.source) },
        ],
        rows: itemsOf(items),
      }).el);
  }

  async function showNotes() {
    const [notesRes, inits] = await Promise.all([api.listArtifacts('meeting-notes'), getInitiatives()]);
    const notes = itemsOf(notesRes).sort((a, b) => String(b.meeting_date || '').localeCompare(String(a.meeting_date || '')));
    clear(body);
    const aiHost = h('div', { class: 'dv-ai-host', hidden: true });
    const paste = h('textarea', { class: 'dv-textarea', rows: 6, placeholder: 'Paste meeting notes here. Decisions and actions with owners and dates are extracted for review.', 'aria-label': 'Meeting notes' });
    let initiativeId = '';
    const extractBtn = autoButton('Extract actions', () => {
      if (!paste.value.trim()) { toast('Paste the meeting notes first.', 'warning'); paste.focus(); return; }
      extract({ text: paste.value.trim(), initiative_id: initiativeId ? Number(initiativeId) : undefined }, extractBtn);
    });
    body.append(
      h('section', { class: 'dv-note' },
        h('div', { class: 'dv-note-head' }, h('span', { class: 'dv-note-title', text: 'Paste notes' }),
          selectEl(inits.map((i) => ({ value: i.id, label: `${i.rddc} · ${i.name}` })), '', (v) => { initiativeId = v; }, { label: 'Initiative', allLabel: 'Not linked' })),
        paste, h('div', { class: 'dv-filters' }, extractBtn)),
      aiHost);
    if (!notes.length) body.appendChild(emptyState('No meeting notes yet. Paste notes above to extract decisions and actions.'));
    for (const n of notes) {
      const attendees = Array.isArray(n.attendees) ? n.attendees : [];
      const actions = Array.isArray(n.action_items_json) ? n.action_items_json : [];
      const noteBody = h('div', { class: 'dv-note-body', text: n.notes_md || '' });
      const btn = autoButton('Extract actions', () => extract({ meeting_note_id: n.id }, btn));
      body.appendChild(h('article', { class: 'dv-note' },
        h('div', { class: 'dv-note-head' },
          h('span', { class: 'dv-note-title', text: n.title }),
          h('span', { class: 'dv-muted' }, fmtDate(n.meeting_date), ' · ', rddcLink(ctx, n))),
        attendees.length ? h('div', { class: 'dv-attendees', text: `Attendees: ${attendees.join(', ')}` }) : null,
        noteBody,
        actions.length ? h('ul', { class: 'dv-bullets' }, actions.map((a) => h('li', { text: `${a.action || ''}${a.owner ? ` · ${a.owner}` : ''}${a.due ? ` · due ${fmtDate(a.due)}` : ''}${a.status ? ` · ${a.status}` : ''}` }))) : null,
        h('div', { class: 'dv-filters' },
          button('Show full notes', (e) => { noteBody.classList.toggle('is-open'); e.currentTarget.textContent = noteBody.classList.contains('is-open') ? 'Show less' : 'Show full notes'; }, { kind: 'text' }),
          btn)));
    }

    function extract(input, trigger) {
      aiHost.scrollIntoView({ block: 'nearest' });
      return runAi(aiHost, {
        feature: 'meeting_extract', title: 'Meeting actions', trigger,
        body: { ...input, options: { ...input } },
        preview: (run) => {
          const o = run.output || {};
          const decisions = Array.isArray(o.decisions) ? o.decisions : [];
          const actions = Array.isArray(o.actions) ? o.actions : [];
          return h('div', {},
            o.summary ? h('p', { text: o.summary }) : null,
            decisions.length ? [h('h3', { text: `Decisions (${decisions.length}) · go to the Decision Log` }), bulletList(decisions.map((d) => `${d.decision}${d.made_by ? ` · ${d.made_by}` : ''}${d.rddc ? ` · ${d.rddc}` : ''}`))] : null,
            actions.length ? [h('h3', { text: `Actions (${actions.length})` }), dataTable({ dense: true, caption: 'Actions', columns: [
              { key: 'action', label: 'Action', cls: 'dv-cell-wrap' },
              { key: 'owner_name', label: 'Owner', render: (a) => a.owner_name || 'Unassigned' },
              { key: 'due', label: 'Due', render: (a) => (a.due ? fmtDate(a.due) : '—') },
              { key: 'rddc', label: 'RDDC #' },
            ], rows: actions }).el] : null,
            Array.isArray(o.risks_raised) && o.risks_raised.length ? [h('h3', { text: 'Risks raised' }), bulletList(o.risks_raised.map((r) => (typeof r === 'string' ? r : r.title || r.risk || '')))] : null,
            Array.isArray(o.open_questions) && o.open_questions.length ? [h('h3', { text: 'Open questions' }), bulletList(o.open_questions)] : null);
        },
        acceptMessage: (res) => {
          const applied = res && res.applied ? Object.entries(res.applied).map(([k, v]) => `${v} ${k.replace(/_/g, ' ')}`).join(', ') : '';
          return applied ? `Saved: ${applied}.` : 'Decisions and actions saved.';
        },
        onApplied: () => {
          announceChange(input.initiative_id || null, 'artifacts');
          if (!input.meeting_note_id) paste.value = '';
        },
      });
    }
  }

  await show(initial);
  return undefined;
}
