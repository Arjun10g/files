export async function render(root, params, ctx) {
  const { api, state, ui, dates } = ctx;
  const { h } = ui;
  const settings = await api.getSettings();
  state.setSettings(settings);
  const bedrock = settings.bedrock || {};
  const enabled = bedrock.enabled && bedrock.configured && bedrock.sdk_available;
  const date = h('input.input', { type: 'date', value: settings.demo_today, aria: { label: 'Planning date' } });
  const mode = ui.selectEl([{ value: 'simulated', label: 'Rules engine · offline' }, { value: 'auto', label: 'Use configured provider with rules fallback' }], settings.ai_mode, { ariaLabel: 'Processing mode' });
  const saveMode = ui.btn('Save processing mode', { onClick: async () => {
    try { state.setSettings(await api.updateSettings({ ai_mode: mode.value })); ui.toast('Processing mode saved.'); } catch (err) { ui.toastError(err); }
  } });
  root.append(h('div.view-pad', ui.pageBox({ title: 'Settings', hint: 'Local workspace, parsing rules, and optional integrations.' },
    h('div.settings-grid',
      ui.card({ title: 'Document and workbook parsing' }, h('p', 'The portal uses deterministic rules and regular expressions. It retains source text, maps known labels and column names, and flags missing or ambiguous fields for review.'),
        h('p.muted', 'Word paragraphs, tables, nested tables, headers, footers, comments, and footnotes are extracted. PDFs must contain selectable text. Scans, diagrams, and images require a text copy or OCR outside this parser.'),
        h('a', { href: '#/imports' }, 'Open import review')),
      ui.card({ title: 'Processing provider' }, h('p', enabled ? 'Amazon Bedrock is configured and enabled. AWS permissions are checked when a request runs.' : 'Rules engine is available. No AI connection is required.'), mode, saveMode,
        h('details.source-evidence', h('summary', 'Amazon Bedrock setup'), h('pre', 'pip install -r requirements-bedrock.txt\nBMO_AI_PROVIDER=bedrock\nBMO_BEDROCK_ENABLED=true\nBMO_BEDROCK_REGION=<AWS region>\nBMO_BEDROCK_MODEL_ID=<model or inference profile ID>'),
          h('p.muted', 'Use your AWS credential chain or workload IAM role. Restart the server and select the configured provider mode. A failed provider call returns a labelled rules proposal. Nothing is accepted automatically.'))),
      ui.card({ title: 'Planning date' }, h('p.muted', 'Grooming, deadlines, and capacity views use this date. Change it when rehearsing a different delivery period.'), date,
        ui.btn('Apply planning date', { onClick: async () => {
          try { const next = await api.updateSettings({ demo_today: date.value }); state.setSettings(next); document.getElementById('rail-foot').textContent = `Planning date ${dates.fmtDate(next.demo_today)}`; ui.toast('Planning date updated.'); } catch (err) { ui.toastError(err); }
        } })),
      ui.card({ title: 'Workspace' }, h('p', 'SQLite and original uploads are saved on this machine. New workspaces start without initiatives, people, allocations, or funding records.'),
        h('p.muted', 'Reference catalogues contain component codes, skills, lookup choices, holidays, and release trains. Persona selection records who is acting on an approval; it is not enterprise authentication.'),
        h('a', { href: '#/experimental' }, 'Open authenticated integration lab'))))));
}
