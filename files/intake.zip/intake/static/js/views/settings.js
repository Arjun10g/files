// views/settings.js: AI mode, AI response speed, demo date, persona, demo data (reset, sample load,
// Fast-forward hero).
import { clearEditedMarks } from '../ui/grid.js';

export async function render(root, params, ctx) {
  const { api, state, ui, dates, navigate } = ctx;
  const { h } = ui;
  await state.loadLookups().catch(() => null);

  let settings;
  try {
    settings = await api.getSettings();
    state.setSettings(settings);
  } catch (err) {
    root.append(h('div.view-pad', ui.errorPanel(err, { title: 'Settings could not be loaded', retry: () => ctx.refresh() })));
    return;
  }

  async function update(patch, message) {
    try {
      const next = await api.updateSettings(patch);
      settings = next;
      state.setSettings(next);
      if (message) ui.toast(message);
      return true;
    } catch (err) {
      ui.toastError(err);
      return false;
    }
  }

  // ---------------------------------------------------------------- AI mode
  const live = Boolean(settings.live_available);
  const modeName = `ai-mode-${Date.now()}`;
  const modeOption = (value, title, note, disabled) => {
    const input = h('input', { type: 'radio', name: modeName, value, checked: settings.ai_mode === value, disabled: disabled || null });
    input.addEventListener('change', async () => {
      if (!input.checked) return;
      const label = value === 'live' ? 'Live Claude' : value === 'auto' ? 'Automatic' : 'Simulated AI';
      const ok = await update({ ai_mode: value }, `AI mode set to ${label}.`);
      if (!ok) paintMode();
    });
    return h('label.radio', input, h('span.radio-text', h('strong', title), h('span.radio-note', note)));
  };
  const modeHost = h('div.radio-list');
  function paintMode() {
    ui.mount(modeHost, 
      modeOption('simulated', '● Simulated AI', 'Prepared responses and rules. Same answer every run; best for the demo.'),
      modeOption('live', '● Live Claude', live ? 'Connected' : 'Not configured on this machine', !live),
      modeOption('auto', 'Automatic', live ? 'Use Live Claude, and fall back to Simulated AI if it is slow or unavailable.' : 'Uses Simulated AI until Live Claude is configured.'),
    );
  }
  paintMode();

  // ---------------------------------------------------------------- speed
  const speedName = `ai-speed-${Date.now()}`;
  const speedOption = (value, title, note) => {
    const input = h('input', { type: 'radio', name: speedName, value, checked: (settings.ai_speed || 'Realistic') === value });
    input.addEventListener('change', () => { if (input.checked) update({ ai_speed: value }, `AI response speed set to ${title}.`); });
    return h('label.radio', input, h('span.radio-text', h('strong', title), h('span.radio-note', note)));
  };
  const speedHost = h('div.radio-list',
    speedOption('Realistic', 'Realistic', 'Thinking steps take 1.5–3 seconds, like a real assistant.'),
    speedOption('Fast', 'Fast (for rehearsal)', 'Thinking steps take 0.3 seconds and text appears at once.'));

  // ---------------------------------------------------------------- demo date + persona
  const dateIn = h('input.input', { type: 'date', value: settings.demo_today || '' });
  const dateBtn = ui.btn('Apply date', { variant: 'secondary', onClick: async () => {
    if (!dates.isISODate(dateIn.value)) { ui.toast('Enter a valid date.', { variant: 'warning' }); return; }
    if (await update({ demo_today: dateIn.value }, `Demo date set to ${dates.fmtDate(dateIn.value)}.`)) {
      const foot = document.getElementById('rail-foot');
      if (foot) foot.textContent = `Demo date ${dates.fmtDate(dateIn.value)}`;
    }
  } });
  const personaOpts = state.options('persona').length ? state.options('persona') : ['DC PM', 'Dev Lead', 'Requestor', 'STO', 'Account Manager'].map((v) => ({ value: v, label: v }));
  const personaSel = ui.selectEl(personaOpts, settings.persona, { ariaLabel: 'Persona' });
  personaSel.addEventListener('change', () => update({ persona: personaSel.value }, `Acting as ${personaSel.value}.`));
  const offSettings = state.on('settings', (s) => { if (s && s.persona && personaSel.value !== s.persona) personaSel.value = s.persona; });

  // ---------------------------------------------------------------- demo data
  const ffList = h('ul.ff-steps');
  const ffBtn = ui.autoBtn('Fast-forward RDDC-24817', { onClick: () => fastForward() });
  ffBtn.classList.add('btn-hero');

  const STEP_TEXT = {
    create: 'Create RDDC-24817 from DCI-3391', attach_sa: 'Attach the sample SA document', change_summary: 'Generate and accept the Change Summary',
    l2_submit: 'Send L2 for approval', l2_approve: 'Approve L2', wbs: 'Generate and accept the project plan', resources: 'Suggest and assign resources',
  };

  async function fastForward() {
    const ok = await ui.confirmModal({
      title: 'Fast-forward RDDC-24817?',
      message: 'Runs the whole hero flow in Simulated AI: create the intake, attach the SA document, accept the Change Summary, approve L2, accept the plan and assign resources. Steps already done are skipped.',
      confirmLabel: 'Fast-forward',
    });
    if (!ok) return;
    const restore = ui.busy(ffBtn, 'Running the hero flow…');
    ui.mount(ffList, ui.loadingLine('Working through the steps…'));
    try {
      const res = await api.fastForwardHero();
      ui.mount(ffList, ...(res.steps || []).map((s) => h('li',
        h(s.ok ? 'span.ff-ok' : 'span.ff-bad', { aria: { hidden: 'true' } }, s.ok ? '✓' : '⚠'),
        h('span', STEP_TEXT[s.step] || String(s.step).replace(/_/g, ' ')),
        s.message ? h('span.muted', ` · ${s.message}`) : null)));
      state.lastInitiativeId = res.initiative_id;
      state.emit('ai:applied', { feature: 'fast_forward' });
      ui.toast(`${res.rddc || 'RDDC-24817'} is ready.`, { action: { label: 'Open', onClick: () => navigate(`#/initiative/${res.initiative_id}/pg3`) } });
      restore();
      ffBtn.after(h('a.btn.btn-primary', { href: `#/initiative/${res.initiative_id}/pg3`, style: { 'margin-left': '8px' } }, `Open ${res.rddc || 'RDDC-24817'}`));
    } catch (err) {
      restore();
      ui.mount(ffList, ui.errorPanel(err, { title: 'Fast-forward stopped' }));
    }
  }

  async function resetDemo(kind) {
    const ok = await ui.confirmModal({
      title: kind === 'load' ? 'Load sample initiatives?' : 'Reset demo data?',
      message: kind === 'load'
        ? 'The eight sample initiatives, people and release trains are loaded fresh. Anything added since the last reset is removed. This can\'t be undone.'
        : 'Reset demo data? All initiatives return to the starting sample. This can\'t be undone.',
      confirmLabel: kind === 'load' ? 'Load sample initiatives' : 'Reset demo data',
      danger: true,
    });
    if (!ok) return;
    const wait = ui.toast('Resetting demo data…', { variant: 'info', duration: 20000 });
    try {
      await api.resetDemo();
      wait.close();
      ui.clearToasts();
      state.clearLocal();
      clearEditedMarks();
      await state.loadLookups(true).catch(() => null);
      const [s, hl] = await Promise.all([api.getSettings().catch(() => null), api.getAppHealth().catch(() => null)]);
      if (s) state.setSettings(s);
      if (hl) state.setAppHealth(hl);
      state.emit('ai:applied', { feature: 'reset' });
      window.dispatchEvent(new CustomEvent('bmo:reset'));
      ui.toast(kind === 'load' ? 'Sample initiatives loaded.' : 'Demo data reset to the starting sample.');
      navigate('#/portfolio');
    } catch (err) {
      wait.close();
      ui.toastError(err);
    }
  }

  const health = state.appHealth || {};
  root.append(h('div.view-pad',
    ui.pageBox({ title: 'Settings' },
      h('div.settings-grid',
        ui.card({ title: 'AI mode' }, modeHost,
          h('p.small.muted', { style: { 'margin-top': '8px' } }, 'The top bar always shows the current mode. If Live Claude is slow or unavailable, answers switch to Simulated AI and are labelled.')),
        ui.card({ title: 'AI response speed' }, speedHost),
        ui.card({ title: 'Demo clock and persona' },
          h('div.form-grid',
            h('label.form-field', h('span.form-label', 'Demo date'), h('div.btn-row', { style: { 'flex-wrap': 'nowrap' } }, h('div', { style: { 'min-width': '160px' } }, ui.dateField(dateIn)), dateBtn),
              h('span.form-hint', 'Dates, reminders and grooming slots are calculated from this day.')),
            h('label.form-field', h('span.form-label', 'Acting as'), personaSel, h('span.form-hint', 'Shown on approvals and in the activity log.')),
            h('div.form-field', h('span.form-label', 'Fiscal year starts'), h('div', 'November (Q1 Nov–Jan · Q2 Feb–Apr · Q3 May–Jul · Q4 Aug–Oct)')))),
        ui.card({ title: 'Demo data' },
          h('div.hero-card',
            h('div.strong', 'Fast-forward the hero intake'),
            h('p.small', 'One click runs the US API Enhancement flow end to end, so the presenter can recover at any point.'),
            h('div.btn-row', ffBtn), ffList),
          h('div.btn-row', { style: { 'margin-top': '16px' } },
            ui.btn('Load sample initiatives', { variant: 'secondary', onClick: () => resetDemo('load') }),
            ui.btn('Reset demo data', { variant: 'danger-text', onClick: () => resetDemo('reset') })),
          h('p.small.muted', { style: { 'margin-top': '8px' } },
            `Version ${ui.txt(health.version, state.version)}${health.today ? ` · demo date ${dates.fmtDate(health.today)}` : ''}`))))));
  return () => offSettings();
}
