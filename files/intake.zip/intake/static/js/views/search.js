// views/search.js: Search Initiative. Filters RDDC/name, LOB, DC PM, Stage, RAG; row opens the workspace.

export async function render(root, params, ctx) {
  const { api, state, ui, dates, navigate } = ctx;
  const { h } = ui;
  await state.loadLookups().catch(() => null);
  const query = params.query || {};
  const editMode = query.edit === '1';

  const filters = {
    q: query.q || '',
    lob: query.lob || '',
    dc_pm_id: query.dc_pm_id || '',
    stage: query.stage || '',
    rag: query.rag || '',
  };

  const qInput = h('input.input', { type: 'search', value: filters.q, placeholder: 'RDDC # or project name', aria: { label: 'RDDC # or project name' } });
  const lobSel = ui.selectEl(state.options('lob'), filters.lob, { placeholder: 'All LOBs', ariaLabel: 'LOB' });
  const pmSel = ui.selectEl(state.people({ team: 'DC PM' }).map((p) => ({ value: p.id, label: p.name })), filters.dc_pm_id, { placeholder: 'All DC PMs', ariaLabel: 'DC PM' });
  const stageSel = ui.selectEl(state.options('stage'), filters.stage, { placeholder: 'All stages', ariaLabel: 'Stage' });
  const ragSel = ui.selectEl([...state.options('rag'), { value: 'none', label: 'Not scored yet' }], filters.rag, { placeholder: 'All RAG', ariaLabel: 'RAG' });
  const clearBtn = ui.btn('Clear filters', { variant: 'ghost', onClick: () => {
    qInput.value = ''; lobSel.value = ''; pmSel.value = ''; stageSel.value = ''; ragSel.value = '';
    load();
  } });
  const results = h('div.search-results');
  const countLine = h('div.muted.small', { style: { margin: '0 0 8px' } });

  const field = (label, control, cls) => h(`label.form-field${cls ? `.${cls}` : ''}`, h('span.form-label', label), control);

  root.append(h('div.view-pad', ui.pageBox({
    title: editMode ? 'Edit Initiative' : 'Search Initiative',
    hint: editMode ? 'Pick the initiative you want to edit.' : null,
    actions: [ui.btn('Add New Initiative', { variant: 'primary', icon: '+', onClick: () => navigate('#/initiative/new') })],
  },
  h('div.filters',
    field('RDDC # or Project Name', qInput, 'grow'),
    field('LOB', lobSel), field('DC PM', pmSel), field('Stage', stageSel), field('RAG', ragSel),
    clearBtn),
  countLine,
  results)));

  let reqId = 0;
  async function load() {
    const mine = ++reqId;
    const p = {
      q: qInput.value.trim(), lob: lobSel.value, dc_pm_id: pmSel.value, stage: stageSel.value,
      rag: ragSel.value === 'none' ? '' : ragSel.value,
    };
    ui.mount(results, ui.loadingLine('Finding initiatives…'));
    try {
      const res = await api.listInitiatives(p);
      if (mine !== reqId) return;
      let items = res.items || [];
      if (ragSel.value === 'none') items = items.filter((i) => !i.rag);
      paint(items, p.q);
    } catch (err) {
      if (mine !== reqId) return;
      ui.mount(results, ui.errorPanel(err, { retry: load }));
    }
  }

  function paint(items, q) {
    countLine.textContent = `${items.length} initiative${items.length === 1 ? '' : 's'}`;
    if (!items.length) {
      const anyFilter = q || lobSel.value || pmSel.value || stageSel.value || ragSel.value;
      ui.mount(results, ui.emptyState({
        icon: '⌕',
        text: q ? `No initiatives match '${q}'. Check the RDDC # or clear filters.` : (anyFilter ? 'No initiatives match these filters. Clear filters to see all.' : 'No initiatives yet. Add the first one.'),
        action: anyFilter ? { label: 'Clear filters', onClick: () => clearBtn.click() } : { label: 'Add New Initiative', variant: 'primary', onClick: () => navigate('#/initiative/new') },
      }));
      return;
    }
    const table = h('table.table',
      h('thead', h('tr',
        h('th', 'RDDC #'), h('th', 'Project Name'), h('th', 'LOB'), h('th', 'DC PM'), h('th', 'Stage'),
        h('th', 'Progress'), h('th', 'RAG'), h('th', 'Target Release'), h('th', 'Readiness Date'))),
      h('tbody', items.map((it) => {
        const tr = h('tr.clickable', { tabIndex: 0, attrs: { role: 'link', 'aria-label': `Open ${it.rddc} ${it.name}` } },
          h('td.strong.nowrap', it.rddc),
          h('td', it.name),
          h('td', ui.txt(it.lob)),
          h('td', ui.txt(it.dc_pm_name)),
          h('td', ui.txt(it.stage)),
          h('td', ui.miniStepper(ui.stepsDoneForStage(it.stage))),
          h('td', ui.ragPill(it.rag, { size: 'sm' })),
          h('td', ui.txt(it.target_release)),
          h('td', dates.fmtDate(it.readiness_date)));
        const open = () => navigate(`#/initiative/${it.id}/pg1`);
        tr.addEventListener('click', open);
        tr.addEventListener('keydown', (e) => { if (e.key === 'Enter') open(); });
        return tr;
      })));
    ui.mount(results, h('div.table-scroll', table));
  }

  const debounced = ui.debounce(load, 250);
  qInput.addEventListener('input', debounced);
  qInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') debounced.flush(); });
  [lobSel, pmSel, stageSel, ragSel].forEach((s) => s.addEventListener('change', load));
  await load();
  qInput.focus();
  return () => debounced.cancel();
}
