// Pg 5 Portfolio View at initiative scope (#/initiative/:id/pg5). Scope toggle: This initiative / All initiatives.
import {
  api, h, clear, card, dataTable, autoButton, pageHeader, errorBox, loading, segmented, getLookups, getToday, go, runAi,
  fmtDate, fmtNum, isNum, modal, toast, announceChange,
} from '../charts/kit.js';
import * as UI from '../ui/index.js';
import { renderHealth, DIMENSIONS, RULES } from '../charts/rag.js';
import { renderGantt, phaseGantt } from '../charts/gantt.js';
import { renderBurndown } from '../charts/burndown.js';
import { projectColumns, changeColumns, execSummaryPreview, mountCapacityTile, renderPortfolioBody } from './portfolio.js';

function initiativeIdFrom(params) {
  const raw = params && (params.id ?? params.initiative_id);
  if (raw !== undefined && raw !== null && raw !== '') return Number(raw);
  const m = /#\/initiative\/(\d+)/.exec(window.location.hash);
  return m ? Number(m[1]) : null;
}

export function rebalancePreview(run) {
  const o = run.output || {};
  const options = Array.isArray(o.options) ? o.options : [];
  const rec = isNum(o.recommended_option_index) ? Number(o.recommended_option_index) : 0;
  return h('div', {},
    o.problem && o.problem.summary ? h('p', { text: o.problem.summary }) : null,
    options.length ? h('ol', { class: 'dv-bullets' }, options.map((opt, i) => h('li', {},
      h('strong', { text: opt.action || 'Option' }), i === rec ? h('span', { class: 'dv-chip dv-chip-green', text: 'Recommended' }) : null,
      opt.before && opt.after ? h('div', { class: 'dv-muted', text: `${opt.from_resource_name || 'Current'} ${fmtNum(opt.before.from_pct)}% → ${fmtNum(opt.after.from_pct)}% · ${opt.to_resource_name || 'New'} ${fmtNum(opt.before.to_pct)}% → ${fmtNum(opt.after.to_pct)}%` }) : null,
      opt.effect ? h('div', { text: opt.effect }) : null))) : h('p', { class: 'dv-muted', text: 'No alternative assignment keeps everyone within capacity.' }));
}

export function openOverrideModal({ initiativeId, dimension, dim, onDone, ctx }) {
  const label = (DIMENSIONS.find(([k]) => k === dimension) || [dimension, dimension])[1];
  const select = h('select', { class: 'dv-select', 'aria-label': 'Status' },
    ['Red', 'Amber', 'Green'].map((v) => h('option', { value: v, selected: v === dim.rag }, v)),
    h('option', { value: '' }, 'Use calculated value'));
  const reason = h('textarea', { class: 'dv-textarea', rows: 3, placeholder: 'Why the calculated status does not reflect reality', 'aria-label': 'Reason' });
  if (dim.override_reason) reason.value = dim.override_reason;
  const error = h('div', { class: 'dv-form-error', role: 'alert' });
  modal({
    title: `Override ${label}`,
    body: [
      h('p', { class: 'dv-muted', text: `Calculated: ${dim.rag || 'Not scored'}. ${RULES[dimension] || ''}` }),
      h('label', { class: 'dv-form-row' }, h('span', { text: 'Status' }), select),
      h('label', { class: 'dv-form-row' }, h('span', { text: 'Reason (required)' }), reason),
      error,
    ],
    actions: [
      { label: 'Cancel', onClick: () => undefined },
      {
        label: 'Save override', kind: 'primary', onClick: async () => {
          const rag = select.value || null;
          const text = reason.value.trim();
          if (rag && !text) { error.textContent = 'Enter a reason for the override.'; return true; }
          try {
            const health = await api.overrideHealth(initiativeId, { dimension, rag, reason: text || 'Returned to calculated value' });
            toast(rag ? `${label} overridden to ${rag}.` : `${label} uses the calculated value again.`);
            announceChange(initiativeId, 'health', ctx);
            onDone(health);
            return false;
          } catch (err) {
            error.textContent = err.message;
            return true;
          }
        },
      },
    ],
  });
}

async function renderInitiativeScope(host, id, ctx, aiHost) {
  clear(host);
  host.appendChild(loading('Loading Pg 5…'));
  let lookups;
  let today;
  let health;
  let gantt;
  let portfolio;
  try {
    [lookups, today, health, gantt, portfolio] = await Promise.all([
      getLookups(ctx), getToday(ctx), api.getInitiativeHealth(id), api.getGantt(id).catch(() => null), api.getPortfolio(),
    ]);
  } catch (err) {
    clear(host);
    host.appendChild(errorBox(err, () => renderInitiativeScope(host, id, ctx, aiHost)));
    return () => {};
  }
  clear(host);
  const cleanups = [];
  const row = (portfolio.projects || []).find((p) => String(p.id) === String(id));

  const healthCard = card('Project health', { noHead: true });
  const capCard = card('Resource capacity', { right: h('span', { class: 'dv-muted', text: "This initiative's teams" }) });
  const ganttCard = card('Project Gantt');
  host.appendChild(h('div', { class: 'dv-grid-3', 'data-testid': 'deck-tiles' }, healthCard.el, capCard.el, ganttCard.el));

  const capTile = mountCapacityTile(capCard.body, { lookups, today, initiativeId: id });
  const healthChart = renderHealth(healthCard.body, health, {
    onOverride: (dimension, dim) => openOverrideModal({
      initiativeId: id, dimension, dim, ctx,
      onDone: (next) => { healthChart.update(next); if (ctx.ws && typeof ctx.ws.setHealth === 'function') ctx.ws.setHealth(next); },
    }),
    onSuggestFix: (dimension, dim, trigger) => runAi(aiHost, {
      feature: 'rebalance', initiativeId: id, title: 'Suggest fix · Resources', trigger,
      preview: (run, c) => (typeof UI.previewRebalance === 'function' && c && c.isSelected ? UI.previewRebalance(run.output || {}, c) : rebalancePreview(run)),
      selectable: true,
      selectableCount: (o) => (Array.isArray(o.options) ? o.options.length : 0),
      initialSelection: (o) => [isNum(o.recommended_option_index) ? Number(o.recommended_option_index) : 0],
      acceptMessage: (res, run, applyBody) => {
        const o = run.output || {};
        const idx = applyBody && Array.isArray(applyBody.selected) && applyBody.selected.length ? applyBody.selected[0] : 0;
        const opt = Array.isArray(o.options) ? o.options[idx] : null;
        const next = res && res.health;
        const resRag = next && next.dimensions && next.dimensions.resources ? next.dimensions.resources.rag : null;
        return resRag
          ? `${opt && opt.action ? opt.action : 'Change applied'}. Resources is now ${resRag}; overall ${next.overall || 'recalculated'}.`
          : `${opt && opt.action ? opt.action : 'Change applied'}. Health recalculated.`;
      },
      onApplied: async (res) => {
        const next = (res && res.health) || (await api.getInitiativeHealth(id));
        healthChart.update(next);
        capTile.reload();
        if (ctx.ws && typeof ctx.ws.setHealth === 'function') ctx.ws.setHealth(next);
        announceChange(id, 'health', ctx);
      },
    }),
  });
  cleanups.push(() => healthChart.destroy());

  const phases = phaseGantt(gantt);
  const ganttChart = renderGantt(ganttCard.body, phases, { compact: true, onTaskClick: () => go(ctx, `#/initiative/${id}/pg2`) });
  cleanups.push(() => ganttChart.destroy());
  if (gantt && gantt.readiness_date) {
    ganttCard.body.appendChild(h('dl', { class: 'dv-kv' },
      h('dt', { text: 'Readiness Date' }), h('dd', { text: fmtDate(gantt.readiness_date) }),
      h('dt', { text: 'QA Date' }), h('dd', { text: fmtDate(gantt.qa_date) }),
      h('dt', { text: 'Production' }), h('dd', { text: fmtDate(gantt.prod_date) }),
      isNum(gantt.float_bd) ? [h('dt', { text: 'Float to release' }), h('dd', { text: `${gantt.float_bd} business days` })] : null));
  }

  const burnCard = card('PRN burndown');
  host.appendChild(h('div', { class: 'dv-section' }, burnCard.el));
  const bundle = (ctx && ctx.bundle) || null;
  const hasPrn = bundle && bundle.initiative ? Boolean(bundle.initiative.prn_code) : true;
  (hasPrn ? api.getInitiativeBurndown(id) : Promise.reject(new Error('no PRN'))).then((b) => {
    const chart = renderBurndown(burnCard.body, b, { today });
    cleanups.push(() => chart.destroy());
  }, () => {
    clear(burnCard.body);
    burnCard.body.appendChild(h('p', { class: 'dv-muted', text: 'No PRN funding is linked to this initiative yet. Add the PRN on Pg 1.' }));
  });

  host.appendChild(h('section', { class: 'dv-section', 'data-testid': 'project-dashboard' },
    h('h2', { class: 'dv-section-title', text: 'Project Dashboard' }),
    dataTable({ columns: projectColumns(ctx), rows: row ? [row] : [], caption: 'Project Dashboard', empty: 'This initiative is not on the dashboard yet.', rowClass: () => 'is-hero' }).el));
  const cm = (portfolio.change_mgmt || []).filter((c) => String(c.initiative_id) === String(id));
  host.appendChild(h('section', { class: 'dv-section', 'data-testid': 'change-management' },
    h('h2', { class: 'dv-section-title', text: 'Change Management' }),
    dataTable({ columns: changeColumns(ctx), rows: cm, caption: 'Change Management', empty: 'No change request logged. Create the CRQ draft on Pg 4.' }).el));
  return () => cleanups.forEach((fn) => fn());
}

export async function render(root, params, ctx) {
  const id = initiativeIdFrom(params);
  clear(root);
  const page = h('section', { class: 'page-box dv-page', 'data-view': 'pg5' });
  root.appendChild(page);
  if (!id) {
    page.appendChild(errorBox(new Error('Open an initiative first to see its Pg 5.'), () => go(ctx, '#/search')));
    return undefined;
  }
  const aiHost = h('div', { class: 'dv-ai-host', hidden: true });
  const body = h('div');
  let cleanup = () => {};
  let scope = 'initiative';
  const show = async (next) => {
    scope = next;
    cleanup();
    cleanup = scope === 'all' ? await renderPortfolioBody(body, ctx, { highlightId: id }) : await renderInitiativeScope(body, id, ctx, aiHost);
  };
  const summaryBtn = autoButton('Write Executive Summary', () => runAi(aiHost, {
    feature: 'exec_summary', title: scope === 'all' ? 'Executive Summary · all initiatives' : 'Executive Summary', trigger: summaryBtn,
    initiativeId: scope === 'all' ? null : id,
    preview: (run) => execSummaryPreview(run, ctx),
    acceptMessage: () => 'Executive summary saved to Artifacts → Meeting Notes.',
  }));
  const risksBtn = h('a', { class: 'btn btn-secondary', href: `#/initiative/${id}/risks`, on: { click: (e) => { e.preventDefault(); go(ctx, `#/initiative/${id}/risks`); } } }, 'Open risks');
  page.append(
    pageHeader({ eyebrow: 'PG 5', title: 'Portfolio View', hint: '(auto-populated from Pg 1–Pg 4)', actions: [
      segmented([{ value: 'initiative', label: 'This initiative' }, { value: 'all', label: 'All initiatives' }], scope, show, { label: 'Scope' }),
      summaryBtn, risksBtn] }),
    aiHost, body);
  await show('initiative');
  return () => cleanup();
}

