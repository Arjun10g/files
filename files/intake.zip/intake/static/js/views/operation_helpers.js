import { h, clear, button, errorBox, num } from '../charts/kit.js';
import { openModal, confirmModal } from '../ui/modal.js';

if (!document.querySelector('link[href*="operations.css"]')) document.head.appendChild(h('link', { rel: 'stylesheet', href: new URL('../../css/operations.css', import.meta.url).href }));

export function field({ name, label, type = 'text', value = '', options = [], hint, required = false, ...attrs }) {
  const input = type === 'select'
    ? h('select', { class: 'input', name, required, 'aria-label': label, ...attrs }, options.map((o) => h('option', { value: o.value }, o.label)))
    : type === 'textarea' ? h('textarea', { class: 'input', name, rows: 3, required, 'aria-label': label, ...attrs })
      : h('input', { class: 'input', name, type, required, 'aria-label': label, ...attrs });
  if (type === 'checkbox') input.checked = Boolean(value); else input.value = value ?? '';
  const el = h('label', { class: `form-field${attrs['data-wide'] ? ' op-wide' : ''}` }, h('span', { class: 'form-label', text: `${label}${required ? ' *' : ''}` }), input, hint ? h('span', { class: 'form-hint', text: hint }) : null);
  return { el, input };
}

export function editor({ title, intro, fields = [], extra, saveLabel = 'Save', onSave, width = 720, validate }) {
  const controls = {}, grid = h('div', { class: 'op-form-grid' }), error = h('div', { 'aria-live': 'polite' });
  fields.forEach((f) => { const control = field(f); controls[f.name] = control.input; grid.appendChild(control.el); });
  const form = h('form', { class: 'op-form' }, intro ? h('p', { class: 'op-intro', text: intro }) : null, error, grid, extra || null);
  let submitting = false;
  async function save({ close }) {
    if (submitting || !form.reportValidity()) return false;
    const values = {};
    for (const [name, input] of Object.entries(controls)) values[name] = input.type === 'checkbox' ? (input.checked ? 1 : 0) : input.type === 'number' ? (input.value === '' ? null : Number(input.value)) : input.value.trim();
    clear(error);
    try { if (validate) validate(values); submitting = true; await onSave(values, controls); close(); return true; }
    catch (err) {
      error.appendChild(err.name === 'ApiError' ? errorBox(err, undefined, 'Check the form') : h('div', { class: 'error-panel', role: 'alert' }, h('p', { text: err.message || 'Check the form and try again.' })));
      for (const [key, message] of Object.entries(err.details?.fields || err.details || {})) {
        if (!controls[key] || typeof message !== 'string') continue;
        controls[key].setCustomValidity(message);
        controls[key].addEventListener('input', () => controls[key].setCustomValidity(''), { once: true });
      }
      error.scrollIntoView({ block: 'nearest' }); return false;
    } finally { submitting = false; }
  }
  const dialog = openModal({ title, body: form, width, actions: [{ label: 'Cancel' }, { label: saveLabel, variant: 'primary', onClick: save }] });
  form.addEventListener('submit', (e) => { e.preventDefault(); dialog.el.querySelector('.modal-footer .btn-primary').click(); });
  return { ...dialog, controls, form };
}

export async function removeItem({ title, message, remove, after }) {
  if (!await confirmModal({ title, message, confirmLabel: 'Delete', danger: true })) return;
  try { await remove(); if (after) await after(); }
  catch (err) { openModal({ title: 'Could not delete', body: errorBox(err), actions: [{ label: 'Close' }] }); }
}
export function metric(label, value, detail, kind = '') { return h('div', { class: `op-metric${kind ? ` op-${kind}` : ''}` }, h('span', { class: 'op-metric-label', text: label }), h('strong', { text: value }), detail ? h('span', { class: 'op-metric-detail', text: detail }) : null); }
export function meter(value, total, { label, kind = '' } = {}) {
  const ratio = total > 0 ? num(value) / total : 0;
  return h('div', { class: 'op-meter-wrap' }, h('div', { class: `op-meter ${kind || (ratio > 1 ? 'op-over' : ratio > .9 ? 'op-warning' : '')}`, role: 'img', 'aria-label': label || `${Math.round(ratio * 100)}%` }, h('span', { style: { width: `${Math.max(0, Math.min(100, ratio * 100))}%` } })), label ? h('span', { class: 'op-meter-label', text: label }) : null);
}
export function rowActions(...actions) { return h('div', { class: 'op-row-actions' }, actions); }
export function money(value, currency = 'CAD') {
  if (value === null || value === undefined) return '—';
  try { return new Intl.NumberFormat('en-CA', { style: 'currency', currency, maximumFractionDigits: 0 }).format(num(value)); } catch { return `${currency} ${num(value).toLocaleString('en-CA')}`; }
}
