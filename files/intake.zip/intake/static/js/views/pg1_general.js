// views/pg1_general.js: Pg 1 General Details (Excel layout). Left/right label-value blocks, SA document,
// Description of Change, Generate Change Summary + editable Change Summary table, L2 Estimate panel,
// grooming session line.
import { createGrid } from '../ui/grid.js';
import { runAiFeature } from '../ui/ai_card.js';
import { previewIntakeAnalysis, previewChangeSummary, previewL2, componentName } from '../ui/previews.js';
import { fundingIntakeFields, personNamePicker } from '../ui/intake_connections.js';

const SA_ATTACH_FIRST = 'Attach the SA document first.';

export async function render(root, params, ctx) {
  const { api, state, ui, dates, ws, navigate } = ctx;
  const { h } = ui;
  const id = params.id;
  const bundle = params.bundle;
  const ini = bundle.initiative;
  const catalog = bundle.component_catalog || [];
  const print = Boolean(params.print);
  const portal = state.settings?.workspace_mode === 'portal';
  const fundingBudgets = portal ? (await api.request('GET', '/funding').catch(() => ({ items: [] }))).items || [] : [];

  // ---------------------------------------------------------------- form model (header fields)
  const form = {};
  const original = {};
  const rowsByKey = {};
  const dirty = new Set();
  const saveBtn = ui.btn('Save Pg 1', { variant: 'primary', onClick: () => save() });
  const discardBtn = ui.btn('Discard changes', { variant: 'secondary', onClick: () => discard() });
  const dirtyNote = h('span.dirty-note');
  ui.setDisabled(saveBtn, true, 'No changes to save.');
  ui.setDisabled(discardBtn, true);

  function setVal(key, value) {
    form[key] = value;
    const changed = JSON.stringify(value ?? null) !== JSON.stringify(original[key] ?? null);
    if (changed) dirty.add(key); else dirty.delete(key);
    const tr = rowsByKey[key];
    if (tr) { tr.classList.toggle('dirty', changed); tr.classList.remove('invalid'); }
    const n = dirty.size;
    dirtyNote.textContent = n ? `${n} unsaved change${n === 1 ? '' : 's'}` : '';
    ui.setDisabled(saveBtn, n === 0, 'No changes to save.');
    ui.setDisabled(discardBtn, n === 0);
  }

  function track(key, value) {
    form[key] = value;
    original[key] = value;
  }

  const ROLE_FILTERS = {
    pmLead: (p) => ['DC PM', 'Delivery'].includes(p.team) || (/lead/i.test(p.role || '') && !['QA', 'Release', 'Change', 'Business'].includes(p.team)),
    devLead: (p) => /lead|develop|engineer/i.test(p.role || '') && !['QA', 'Release', 'Change', 'Business', 'DC PM', 'Delivery'].includes(p.team),
    dcSa: (p) => p.team === 'DC SA',
  };
  const roleIds = (key) => {
    const ro = state.lookups && state.lookups.role_options;
    return ro && Array.isArray(ro[key]) ? ro[key].map(String) : null;
  };
  const peopleOpts = (filter, current, key) => {
    const ids = key ? roleIds(key) : null;
    let list = ids ? state.people().filter((p) => ids.includes(String(p.id)))
      : (typeof filter === 'function' ? state.people().filter(filter) : state.people(filter));
    if (!list.length) list = state.people();
    const opts = list.map((p) => ({ value: p.id, label: p.name }));
    if (current && !opts.some((o) => String(o.value) === String(current))) {
      const name = state.personName(current);
      if (name) opts.push({ value: current, label: name });
    }
    return opts;
  };

  const personPickers = {};
  function personField(key, filter, label = key) {
    track(key, ini[key] ?? null);
    if (portal) {
      const nameKey = key.replace(/_id$/, '');
      const name = ini[nameKey] || state.personName(ini[key]);
      track(nameKey, name || null);
      const picker = personNamePicker(ui, state, { value: name, id: ini[key], label,
        onChange: (person) => { setVal(key, person.id); setVal(nameKey, person.name); } });
      personPickers[key] = picker;
      return picker.el;
    }
    return ui.selectEl(peopleOpts(filter, ini[key], key), ini[key], {
      placeholder: '—', ariaLabel: key,
      onChange: (v) => setVal(key, v === '' ? null : Number(v)),
    });
  }

  function selectField(key, category, { numeric } = {}) {
    track(key, ini[key] ?? null);
    return ui.selectEl(state.options(category), ini[key], {
      placeholder: '—', ariaLabel: key,
      onChange: (v) => setVal(key, v === '' ? null : (numeric ? Number(v) : v)),
    });
  }

  function textField(key, { type = 'text', maxLength, placeholder } = {}) {
    track(key, ini[key] ?? null);
    const input = h('input.input', { type, value: ini[key] ?? '', maxLength: maxLength || null, placeholder: placeholder || null, aria: { label: key } });
    input.addEventListener('input', () => setVal(key, input.value.trim() === '' ? null : input.value));
    return type === 'date' ? ui.dateField(input, { placeholder: '—' }) : input;
  }

  // Requestor: person select (Business team) that also writes the requestor text
  track('requestor_id', ini.requestor_id ?? null);
  track('requestor', ini.requestor ?? null);
  const requestorSel = portal ? personField('requestor_id', { team: 'Business' }, 'Requestor') : ui.selectEl(peopleOpts({ team: 'Business' }, ini.requestor_id, 'requestor_id'), ini.requestor_id, { placeholder: ini.requestor || '—', ariaLabel: 'Requestor' });
  if (!portal) requestorSel.addEventListener('change', () => {
    const rid = requestorSel.value ? Number(requestorSel.value) : null;
    setVal('requestor_id', rid);
    setVal('requestor', rid ? state.personName(rid) : original.requestor);
  });

  // Labels: comma separated
  const labelsArr = Array.isArray(ini.labels) ? ini.labels : [];
  track('labels', labelsArr);
  const labelsInput = h('input.input', { type: 'text', value: labelsArr.join(', '), placeholder: 'For example: payments, api', aria: { label: 'Labels' } });
  labelsInput.addEventListener('input', () => setVal('labels', labelsInput.value.split(',').map((s) => s.trim()).filter(Boolean)));

  const trainOpts = ((state.lookups && state.lookups.release_trains) || []).map((t) => ({ value: t.code, label: `${t.code} · ${dates.fmtDay(t.train_date, { withYear: true })}` }));
  track('target_release', ini.target_release ?? null);
  const trainSel = ui.selectEl(trainOpts, ini.target_release, { placeholder: '—', ariaLabel: 'Target Release', onChange: (v) => setVal('target_release', v || null) });

  const nameInput = textField('name', { maxLength: 80 });
  const descInput = h('textarea.input.desc-box', { rows: 4, value: ini.description ?? '', aria: { label: 'Description of Change' }, placeholder: 'What is changing, for whom, and why' });
  track('description', ini.description ?? null);
  descInput.addEventListener('input', () => setVal('description', descInput.value.trim() === '' ? null : descInput.value));

  // ---------------------------------------------------------------- SA document block
  const saAuthor = h('span.lv-text');
  const saVersion = h('span.lv-text');
  const saCompl = h('div.sa-compl');
  const genBtn = ui.autoBtn('Generate Change Summary', { onClick: () => generateChangeSummary() });

  function paintSa() {
    saAuthor.textContent = ui.txt(ini.sa_author);
    saVersion.textContent = ui.txt(ini.sa_version);
    const missing = Array.isArray(ini.sa_missing_json) ? ini.sa_missing_json : [];
    ui.mount(saCompl, 
      h('div.sa-compl-row', ui.meter(typeof ini.sa_completeness === 'number' ? ini.sa_completeness : null),
        typeof ini.sa_completeness === 'number' ? ui.aiTag('Rules', 'Scored against the 9-section SA checklist') : null),
      missing.length ? h('div.lv-hint', `Missing: ${missing.join(', ')}`) : null,
      actionChipHost);
    const hasSa = Boolean(ini.sa_doc_attachment_id);
    ui.setDisabled(genBtn, !hasSa, SA_ATTACH_FIRST);
    if (!hasSa) genBtn.title = SA_ATTACH_FIRST;
  }

  const actionChipHost = h('div.action-chip-host');
  async function loadActionChip() {
    const ar = (ws.bundle && ws.bundle.action_required) || bundle.action_required;
    if (ar && (ar.owner_name || ar.what)) {
      const text = `Action required by ${ui.txt(ar.owner_name, 'the owner')}${ar.due ? ` · ${dates.fmtDay(ar.due, { withYear: true })}` : ''}${ar.what ? `: ${ar.what}` : ''}`;
      ui.mount(actionChipHost, ui.chip(text, { tone: 'amber', icon: '⏰', title: 'Reminders go out every 2 business days until this is done' }));
      return;
    }
    if (typeof ini.sa_completeness === 'number' && ini.sa_completeness >= 100) { ui.mount(actionChipHost); return; }
    try {
      const res = await api.listOutbox({ initiative_id: id, rule: 'sa_action_required' });
      const queued = (res.items || []).filter((n) => n.status === 'Queued' && n.action_required_by)
        .sort((a, b) => dates.compareISO(a.action_required_by, b.action_required_by));
      if (!queued.length) { ui.mount(actionChipHost); return; }
      const n = queued[0];
      ui.mount(actionChipHost, ui.chip(`Action required by DC SA · ${ui.txt(n.to_name, '')} · next reminder ${dates.fmtDay(n.action_required_by)}`,
        { tone: 'amber', icon: '⏰', title: 'Reminders go out every 2 business days until the SA document is complete' }));
    } catch {
      ui.mount(actionChipHost);
    }
  }

  const saAttachment = (bundle.attachments || []).find((a) => a.id === ini.sa_doc_attachment_id);
  const dz = ui.dropzone({
    compact: true,
    yellow: true,
    label: 'Drop SA document here or Browse',
    hint: 'PDF · DOCX · MD · TXT',
    replaceLabel: 'Replace',
    attached: saAttachment ? { filename: saAttachment.filename, size: saAttachment.size_bytes, href: api.attachmentDownloadUrl(saAttachment.id) } : null,
    onFile: (file) => uploadSa(file),
  });

  async function uploadSa(file) {
    try {
      const res = await api.uploadAttachment(id, file, { kind: 'sa_doc' });
      return afterSa(res);
    } catch (err) {
      if (err && err.code === 'unreadable_file') {
        const values = await ui.promptModal({
          title: "Couldn't read this file",
          intro: `${err.message || 'The text could not be read from this file.'} Paste the SA document text instead.`,
          fields: [{ name: 'text', label: 'SA document text', type: 'textarea', rows: 10, required: true }],
          submitLabel: 'Use this text',
        });
        if (!values) throw err;
        const res = await api.submitSaText(id, { text: values.text, filename: file.name });
        return afterSa(res);
      }
      throw err;
    }
  }

  function afterSa(res) {
    const att = res.attachment || {};
    if (res.sa) {
      ini.sa_author = res.sa.author ?? ini.sa_author;
      ini.sa_version = res.sa.version ?? ini.sa_version;
      ini.sa_completeness = res.sa.completeness ?? ini.sa_completeness;
      ini.sa_missing_json = res.sa.missing || [];
    }
    ini.sa_doc_attachment_id = att.id || ini.sa_doc_attachment_id;
    paintSa();
    ws.reloadBundle().then(() => loadActionChip()).catch(() => loadActionChip());
    if (intakeSlot.querySelector('.ai-card-result, .ai-card-thinking')) {
      ui.mount(intakeSlot, h('div.ai-stale-line',
        h('span.muted', 'Intake Analysis ran before the SA document was attached.'),
        h('button.link', { type: 'button', on: { click: () => runIntakeAnalysis() } }, 'Analyse again'),
        h('button.link', { type: 'button', on: { click: () => { ui.mount(intakeSlot); intakeSlot.hidden = true; } } }, 'Hide')));
    }
    const missing = res.sa && res.sa.missing && res.sa.missing.length ? ` · Missing: ${res.sa.missing.join(', ')}` : '';
    ui.toast(`SA document attached · SA Completeness ${dates.fmtPct(ini.sa_completeness)}${missing}.`);
    return { filename: att.filename || 'SA document', size: att.size_bytes, href: att.id ? api.attachmentDownloadUrl(att.id) : null };
  }

  // ---------------------------------------------------------------- PM / DC PM (one row when the same person)
  let mergedPm = Boolean(ini.pm_id && ini.dc_pm_id && String(ini.pm_id) === String(ini.dc_pm_id));
  const pmSel = personField('pm_id', ROLE_FILTERS.pmLead);
  const dcPmSel = personField('dc_pm_id', ROLE_FILTERS.pmLead);
  dcPmSel.addEventListener(portal ? 'input' : 'change', () => {
    if (!mergedPm) return;
    if (portal) {
      const person = personPickers.dc_pm_id.read();
      personPickers.pm_id.input.value = person.name || '';
      setVal('pm_id', person.id);
      setVal('pm', person.name);
    } else {
      pmSel.value = dcPmSel.value;
      setVal('pm_id', dcPmSel.value === '' ? null : Number(dcPmSel.value));
    }
  });
  const splitPmLink = h('button.link.small', { type: 'button', title: 'Use a different person as PM' }, 'Different PM');
  splitPmLink.addEventListener('click', () => {
    mergedPm = false;
    splitPmLink.remove();
    const pmRow = rowsByKey.pm_id;
    const dcRow = rowsByKey.dc_pm_id;
    if (pmRow) pmRow.classList.remove('row-hidden');
    const th = dcRow && dcRow.querySelector('th');
    if (th && th.firstChild) th.firstChild.textContent = 'DC PM';
    (personPickers.pm_id?.input || pmSel).focus();
  });

  let fundingFields = null;
  if (portal) {
    track('prn_code', ini.prn_code ?? null);
    track('funding', null);
    fundingFields = fundingIntakeFields(ui, state, fundingBudgets, { code: ini.prn_code, codeLabel: 'prn_code', initiativeId: id,
      onCodeChange: (value) => setVal('prn_code', value), onChange: (value) => setVal('funding', value) });
  }

  // ---------------------------------------------------------------- layout: Excel blocks
  const row = (key, label, value, extra = {}) => ({ key, label, value, ...extra });
  const left = ui.lvGrid([
    [
      row('rddc', 'RDDC #', h('span.lv-text.strong', ini.rddc)),
      row('name', 'Project Name', nameInput, { required: true }),
      row('status', 'Current Status', selectField('status', 'status')),
      row('assigned_to_id', 'Assigned To', personField('assigned_to_id', ROLE_FILTERS.pmLead)),
    ],
    mergedPm
      ? [
        row('dc_pm_id', 'PM / DC PM', h('div.merged-pm', dcPmSel, splitPmLink)),
        row('pm_id', 'PM', pmSel, { cls: 'row-hidden' }),
        row('tech_lead_id', 'Tech/Dev Lead', personField('tech_lead_id', ROLE_FILTERS.devLead)),
      ]
      : [
        row('pm_id', 'PM', pmSel),
        row('tech_lead_id', 'Tech/Dev Lead', personField('tech_lead_id', ROLE_FILTERS.devLead)),
      ],
    mergedPm
      ? [row('stage', 'Stage', selectField('stage', 'stage'))]
      : [
        row('dc_pm_id', 'DC PM', dcPmSel),
        row('stage', 'Stage', selectField('stage', 'stage')),
      ],
    [
      row('lob', 'LOB', selectField('lob', 'lob'), { required: true }),
      row('priority', 'Priority', selectField('priority', 'priority', { numeric: true })),
      row('requested_go_live', 'Requested Go-live', textField('requested_go_live', { type: 'date' })),
      row('target_release', 'Target Release', trainSel),
      row('prn_code', 'PRN', fundingFields?.codeEl || textField('prn_code', { placeholder: 'PRN-#####' })),
    ],
  ]);
  const right = ui.lvGrid([
    [
      row('dc_intake', 'DC Intake', h('span.lv-text', ui.txt(ini.dc_intake))),
      row('labels', 'Labels', labelsInput),
      row('requestor_id', 'Requestor', requestorSel),
    ],
    [
      row('sa_doc', 'SA document', dz.el, { cls: 'lv-auto' }),
      row('sa_author', 'Author', saAuthor),
      row('sa_version', 'SA Version', saVersion),
    ],
    [
      row('dc_sa_id', 'DC SA', personField('dc_sa_id', ROLE_FILTERS.dcSa)),
      row('sa_completeness', 'SA Completeness', saCompl),
    ],
  ]);
  for (const tr of [...left.querySelectorAll('tr[data-key]'), ...right.querySelectorAll('tr[data-key]')]) rowsByKey[tr.dataset.key] = tr;
  rowsByKey.description = null;
  paintSa();

  // ---------------------------------------------------------------- intake analysis (F1)
  const intakeSlot = h('div.ai-slot', { hidden: true });
  const analyseBtn = ui.autoBtn('Analyse intake', { small: true, onClick: () => runIntakeAnalysis() });
  function runIntakeAnalysis() {
    runAiFeature({
      feature: 'intake_analysis', initiativeId: id, container: intakeSlot, trigger: analyseBtn,
      renderPreview: previewIntakeAnalysis, editable: false,
      acceptLabel: 'Apply suggested labels',
      onApplied: () => ws.reload(),
    });
  }

  // ---------------------------------------------------------------- Change Summary table
  const csSlot = h('div.ai-slot', { hidden: true });
  const comps = (bundle.components || []).map((c) => ({ ...c }));
  const approvalOpts = state.options('approval');
  const complexityOpts = state.options('complexity');
  const leadOpts = peopleOpts({});

  const catalogFor = (row) => catalog.find((c) => c.id === row.component_id || c.code === row.code);
  const baseHours = (row, complexity) => {
    const cat = catalogFor(row);
    if (!cat) return null;
    return { Low: cat.base_hours_low, Medium: cat.base_hours_medium, High: cat.base_hours_high }[complexity] ?? null;
  };

  const grid = createGrid({
    gridKey: `cs-${id}`,
    caption: 'Change Summary',
    rows: comps,
    flashRunId: state.flashRunId,
    isAi: (r) => r.source === 'ai',
    emptyText: 'No DC components yet. Attach the SA document and click Generate Change Summary, or add a component yourself.',
    columns: [
      { key: 'name', label: 'DC Component', width: 180, type: 'readonly', aiTag: true, format: (r) => h('span.strong', componentName(r.code, r.name)) },
      { key: 'approval', label: 'Approval', width: 130, type: 'select', options: approvalOpts, allowEmpty: false, format: (r) => ui.statusPill(r.approval) },
      { key: 'complexity', label: 'Complexity', width: 110, type: 'select', options: complexityOpts, allowEmpty: false },
      { key: 'change_summary', label: 'Change Summary', type: 'textarea', cls: 'wrap', placeholder: 'What changes in this component' },
      {
        key: 'est_hours', label: 'Est. hours', width: 100, type: 'number', align: 'right', min: 0, step: 0.5,
        format: (r) => dates.fmtHours(r.est_hours),
        validate: (v) => (v !== null && (typeof v !== 'number' || v < 0) ? 'Hours must be zero or more.' : ''),
      },
      { key: 'component_lead_id', label: 'Component Lead', width: 170, type: 'select', options: leadOpts, format: (r) => ui.txt(r.component_lead_name || state.personName(r.component_lead_id)) },
    ],
    rowActions: print ? null : (r) => h('button.icon-btn', { type: 'button', title: `Remove ${componentName(r.code, r.name)}`, aria: { label: `Remove ${componentName(r.code, r.name)}` }, on: { click: () => removeComponent(r) } }, '✕'),
    onCommit: async (r, key, value) => {
      const patch = { [key]: value };
      if (key === 'complexity') {
        const prevComplexity = original.complexity?.[r.id];
        const oldBase = baseHours(r, prevComplexity);
        if (oldBase !== null && Number(r.est_hours) === Number(oldBase)) patch.est_hours = baseHours(r, value);
      }
      try {
        const updated = await api.updateComponent(r.id, patch);
        rememberComplexity(updated);
        grid.updateRow({ ...updated });
        grid.markSaved(r.id);
        afterComponentChange();
      } catch (err) {
        grid.markError(r.id, key, err.message || 'Could not save this change.');
        ui.toastError(err);
      }
    },
  });
  original.complexity = {};
  const rememberComplexity = (c) => { if (c && c.id) original.complexity[c.id] = c.complexity; };
  comps.forEach(rememberComplexity);
  state.flashRunId = null;

  const addSel = h('select.input.input-sm', { aria: { label: 'Component to add' } });
  const addBtn = ui.btn('+ Add component', { variant: 'secondary', small: true, onClick: () => addComponent() });
  function paintAddOptions() {
    const used = new Set(grid.getRows().map((r) => r.component_id));
    const free = state.components().filter((c) => !used.has(c.id));
    ui.mount(addSel, h('option', { value: '' }, free.length ? 'Choose a DC component…' : 'All components added'),
      ...free.map((c) => h('option', { value: String(c.id) }, c.name)));
    ui.setDisabled(addBtn, !free.length, 'All DC components are already on this initiative.');
  }
  paintAddOptions();

  async function addComponent() {
    if (!addSel.value) { addSel.focus(); ui.toast('Choose a DC component to add.', { variant: 'info' }); return; }
    const restore = ui.busy(addBtn, 'Adding…');
    try {
      const created = await api.addComponent(id, { component_id: Number(addSel.value) });
      rememberComplexity(created);
      grid.setRows([...grid.getRows(), created]);
      paintAddOptions();
      ui.toast(`${componentName(created.code, created.name)} added to the Change Summary.`);
      afterComponentChange();
    } catch (err) {
      ui.toastError(err);
    } finally {
      restore();
    }
  }

  async function removeComponent(r) {
    const name = componentName(r.code, r.name);
    const approved = ini.l2_status === 'Approved';
    const ok = await ui.confirmModal({
      title: `Remove ${name}?`,
      message: approved
        ? `${name} will be removed from the Change Summary. The L2 estimate is already approved, so this counts as a scope change.`
        : `${name} will be removed from the Change Summary and the L2 estimate.`,
      confirmLabel: 'Remove component',
      danger: true,
    });
    if (!ok) return;
    try {
      await api.deleteComponent(r.id);
      grid.setRows(grid.getRows().filter((x) => x.id !== r.id));
      paintAddOptions();
      ui.toast(`${name} removed.`);
      afterComponentChange();
    } catch (err) {
      ui.toastError(err);
    }
  }

  function afterComponentChange() {
    paintL2();
    api.getInitiativeHealth(id).then((hl) => ws.setHealth(hl)).catch(() => {});
  }

  function generateChangeSummary() {
    if (!ini.sa_doc_attachment_id) { ui.toast(SA_ATTACH_FIRST, { variant: 'info' }); return; }
    runAiFeature({
      feature: 'change_summary', initiativeId: id, container: csSlot, trigger: genBtn,
      renderPreview: previewChangeSummary,
      selectable: true, selectableCount: (o) => (o.components || []).length,
      acceptMessage: (res) => {
        const n = (res.applied && (res.applied.initiative_components ?? res.applied.components)) || 0;
        return n ? `Change Summary accepted · ${n} component${n === 1 ? '' : 's'} added.` : 'Change Summary accepted.';
      },
      onApplied: async (res) => {
        if (res && res.health) ws.setHealth(res.health);
        const prevStage = ini.stage;
        await ws.reload();
        const nowStage = ws.initiative.stage;
        if (nowStage && nowStage !== prevStage) ui.toast(`Stage moved ${prevStage} → ${nowStage}.`, { variant: 'info' });
        const anchor = document.getElementById('change-summary');
        if (anchor) anchor.scrollIntoView({ block: 'start', behavior: 'smooth' });
      },
    });
  }

  // ---------------------------------------------------------------- L2 Estimate panel
  const l2Host = h('div.l2-panel', { id: 'l2-estimate' });
  let paintActions = () => {};
  const l2Slot = h('div.ai-slot', { hidden: true });

  async function paintL2() {
    const hasComponents = grid.getRows().length > 0;
    const status = ini.l2_status || 'Draft';
    const head = h('div.l2-head',
      h('div', h('div.eyebrow', 'L2 Estimate'), h('span.muted.small', 'Calculated from the Change Summary · numbers come from the L2 rules')),
      ui.statusPill(status));
    if (!hasComponents) {
      ui.mount(l2Host, head, h('div.l2-body', h('p.muted', 'The L2 estimate is calculated once the Change Summary has at least one DC component.')));
      return;
    }
    ui.mount(l2Host, head, h('div.l2-body', ui.loadingLine('Calculating L2…')));
    let est;
    try {
      est = await api.calculateL2(id);
    } catch (err) {
      ui.mount(l2Host, head, h('div.l2-body', ui.errorPanel(err, { retry: paintL2 })));
      return;
    }
    const figures = h('div.l2-figures',
      h('div.l2-fig', h('div.key-label', 'Total'), h('div.key-value', dates.fmtHours(est.total_hours))),
      h('div.l2-fig', h('div.key-label', 'T-shirt'), h('div.key-value', ui.txt(est.tshirt))),
      h('div.l2-fig', h('div.key-label', 'Range'), h('div.key-value', `${dates.fmtNumber(est.low_hours)}–${dates.fmtHours(est.high_hours)}`)),
      h('div.l2-fig', h('div.key-label', 'L2 Status'), h('div.key-value', status)));
    const breakdown = h('table.mini-table',
      h('thead', h('tr', h('th', 'Line'), h('th', 'Rule'), h('th.num', 'Hours'))),
      h('tbody',
        h('tr', h('td', 'Development'), h('td', 'Sum of component hours by complexity'), h('td.num', dates.fmtHours(est.dev_hours))),
        h('tr', h('td', 'Architecture'), h('td', '10% of development'), h('td.num', dates.fmtHours(est.architecture_hours))),
        h('tr', h('td', 'QA'), h('td', '35% of development'), h('td.num', dates.fmtHours(est.qa_hours))),
        h('tr', h('td', 'PM / Release'), h('td', '10% of development'), h('td.num', dates.fmtHours(est.pm_release_hours))),
        h('tr', h('td', 'Subtotal'), h('td', ''), h('td.num', dates.fmtHours(est.subtotal))),
        h('tr', h('td', 'Contingency'), h('td', '15% of subtotal'), h('td.num', dates.fmtHours(est.contingency_hours))),
        h('tr.strong', h('td.strong', 'Total'), h('td', 'Rounded to the nearest 50 h · range ±25%'), h('td.num.strong', dates.fmtHours(est.total_hours)))));
    const baselineNote = status === 'Approved' && typeof ini.l2_baseline_hours === 'number' && Number(ini.l2_baseline_hours) !== Number(est.total_hours)
      ? h('div.notice.notice-amber', `Current scope calculates to ${dates.fmtHours(est.total_hours)}; the approved baseline is ${dates.fmtHours(ini.l2_baseline_hours)}.`)
      : null;
    const howBtn = ui.autoBtn('How we got this', { small: true, onClick: () => {
      runAiFeature({
        feature: 'l2_estimate', initiativeId: id, container: l2Slot, trigger: howBtn,
        renderPreview: previewL2, editable: false, acceptLabel: 'Save explanation',
        acceptMessage: () => 'Explanation saved to the Decision Log.',
      });
    } });
    const actions = h('div.l2-actions');
    paintActions = () => {
      const persona = state.persona();
      ui.mount(actions);
      if (status === 'Draft' || status === 'Rejected') {
        actions.append(ui.btn('Send L2 to DLR', { variant: 'primary', onClick: (e) => submitL2(e.currentTarget) }),
          h('span.persona-note', `Shares the L2 for DLR and asks the Requestor to approve · usually sent by the Dev Lead · you are acting as ${persona}`));
      } else if (status === 'Pending approval') {
        actions.append(ui.btn('Approve L2', { variant: 'primary', onClick: (e) => approveL2(e.currentTarget) }),
          ui.btn('Reject', { variant: 'secondary', onClick: () => rejectL2() }),
          h('span.persona-note', `Usually approved by the Requestor · you are acting as ${persona}`));
      }
    };
    paintActions();
    const dlrAt = ini.dlr_shared_at || ini.l2_submitted_at;
    const dlrLine = dlrAt
      ? h('div.small', h('strong', 'DLR: '), `shared ${dates.fmtDate(dlrAt)} · ${ini.dlr_name || deliveryLead()} (Delivery Lead)`)
      : null;
    const approvedLine = status === 'Approved' && ini.l2_approved_at
      ? h('div.small.muted', `Approved by ${ui.txt(ini.l2_approved_by, 'the Requestor')} on ${dates.fmtDateTime(ini.l2_approved_at)} · reminders sent ${ini.l2_reminders_sent ?? 0}`)
      : (status === 'Pending approval' && ini.l2_submitted_at
        ? h('div.small.muted', `Waiting for Requestor approval · reminders sent ${ini.l2_reminders_sent ?? 0}`)
        : null);
    ui.mount(l2Host, head, figures,
      h('div.l2-body', baselineNote, h('div.btn-row', howBtn, h('span.muted.small', ui.txt(est.rule, ''))), l2Slot,
        h('details.l2-breakdown', { open: true }, h('summary.small.muted', 'Breakdown'), breakdown), dlrLine, approvedLine),
      print ? null : actions);
  }

  function deliveryLead() {
    const dl = state.people({ team: 'Delivery' })[0];
    return dl ? dl.name : 'Delivery Lead';
  }

  async function submitL2(button) {
    const restore = ui.busy(button, 'Sending…');
    try {
      const res = await api.submitL2(id, {});
      ws.updateInitiative(res.initiative);
      const to = (res.notifications || []).map((n) => n.to_name).filter(Boolean);
      ui.toast(`L2 shared with DLR (${deliveryLead()})${to.length ? ` · approval request queued to ${to.join(', ')}` : ''}.`);
      state.emit('ai:applied', { feature: 'l2_submit' });
      paintL2();
    } catch (err) {
      restore();
      ui.toastError(err);
    }
  }

  async function approveL2(button) {
    const restore = ui.busy(button, 'Approving…');
    try {
      const res = await api.approveL2(id, {});
      const prevStage = ini.stage;
      ws.updateInitiative(res.initiative);
      if (res.health) ws.setHealth(res.health);
      ui.toast(`L2 approved${prevStage !== ini.stage ? ` · stage moved ${prevStage} → ${ini.stage}` : ''} · demand is now Confirmed.`);
      paintL2();
      stageSel.value = ini.stage;
      original.stage = ini.stage;
      form.stage = ini.stage;
    } catch (err) {
      restore();
      ui.toastError(err);
    }
  }

  async function rejectL2() {
    const values = await ui.promptModal({
      title: 'Reject L2 estimate',
      fields: [{ name: 'reason', label: 'Reason', type: 'textarea', required: true, rows: 3 }],
      submitLabel: 'Reject L2', danger: true,
    });
    if (!values) return;
    try {
      const res = await api.rejectL2(id, { reason: values.reason });
      ws.updateInitiative(res.initiative);
      ui.toast('L2 rejected · the Dev Lead can revise and resend it.', { variant: 'info' });
      paintL2();
    } catch (err) {
      ui.toastError(err);
    }
  }

  // ---------------------------------------------------------------- grooming line
  const g = bundle.grooming;
  const groomed = g && ['Discussed', 'Groomed'].includes(g.status);
  const markBtn = !print && g && !groomed && ['Intake', 'Grooming'].includes(ini.stage)
    ? ui.btn('Mark as groomed', { variant: 'secondary', small: true, onClick: (e) => markGroomed(e.currentTarget) })
    : null;
  const groomingLine = h('div.grooming-line',
    h('span.strong', 'Grooming session:'),
    g ? h('span', `${dates.fmtDay(g.session_date, { withYear: true })}, ${dates.fmtTime(g.start_time, '10:00')} ET`)
      : (['Intake', 'Grooming'].includes(ini.stage) ? h('span.muted', 'Not slotted yet') : h('span', ui.statusPill('Discussed', { label: 'Groomed' }), ' walk-through recorded in the activity log')),
    g && g.status ? ui.statusPill(groomed ? 'Discussed' : g.status, { label: groomed ? 'Groomed' : g.status }) : null,
    markBtn,
    h('a.link', { href: '#/intake' }, 'Open Intake & Grooming'));

  async function markGroomed(button) {
    const restore = ui.busy(button, 'Saving…');
    const prevStage = ini.stage;
    try {
      const res = await api.markGroomed(id, {});
      await ws.reload();
      const nowStage = ws.initiative.stage;
      ui.toast(res && res.message ? res.message : `Groomed${nowStage !== prevStage ? ` · stage moved ${prevStage} → ${nowStage}` : ''}.`);
      state.emit('ai:applied', { feature: 'groomed' });
    } catch (err) {
      restore();
      ui.toastError(err);
    }
  }

  // ---------------------------------------------------------------- save / discard / delete
  const stageSel = rowsByKey.stage ? rowsByKey.stage.querySelector('select') : null;

  async function save() {
    if (!dirty.size) return;
    const patch = {};
    for (const k of dirty) patch[k] = form[k];
    if ('name' in patch && !String(patch.name || '').trim()) {
      markInvalid({ name: 'Project Name is required.' });
      return;
    }
    const restore = ui.busy(saveBtn, 'Saving…');
    try {
      fundingFields?.validate();
      const updated = await api.updateInitiative(id, patch);
      for (const k of Object.keys(patch)) original[k] = patch[k];
      dirty.clear();
      Object.values(rowsByKey).forEach((tr) => tr && tr.classList.remove('dirty', 'invalid'));
      descWrap.classList.remove('dirty');
      dirtyNote.textContent = '';
      ws.updateInitiative(updated);
      if (portal) {
        await state.loadLookups(true);
        await ws.reload();
      }
      ui.toast('Pg 1 saved.');
      restore();
      ui.setDisabled(saveBtn, true, 'No changes to save.');
      ui.setDisabled(discardBtn, true);
    } catch (err) {
      restore();
      if (err && err.details && err.details.fields) markInvalid(err.details.fields);
      ui.toastError(err);
    }
  }

  function markInvalid(fields) {
    for (const [k, msg] of Object.entries(fields)) {
      const tr = rowsByKey[k];
      if (tr) { tr.classList.add('invalid'); tr.title = msg; }
      if (k === 'description') descWrap.classList.add('invalid');
    }
  }

  function discard() {
    ws.reload();
  }

  async function deleteInitiative() {
    const ok = await ui.confirmModal({
      title: `Delete ${ini.rddc}?`,
      message: `${ini.rddc} ${ini.name} and its plan, risks and change requests will be removed. This can't be undone.`,
      confirmLabel: 'Delete initiative', danger: true,
    });
    if (!ok) return;
    try {
      await api.deleteInitiative(id);
      state.forgetInitiative(id);
      ui.toast(`${ini.rddc} deleted.`);
      navigate('#/search');
    } catch (err) {
      ui.toastError(err);
    }
  }

  // ---------------------------------------------------------------- assemble
  const sourceFields = [['platform','Platform'],['region','Region'],['channel','Channel'],['apt_number','APT number'],
    ['external_pr_code','External team PR code'],['business_analyst','Business analyst'],['solution_concurrence_date','Solution concurrence date'],
    ['jira_key','Jira issue key'],['jira_status','Jira source status'],['project_key','Jira project key']];
  const contextGrid = h('div.form-grid');
  for (const [key, label] of sourceFields) {
    let input;
    if (portal && key === 'business_analyst') {
      track(key, ini[key] ?? null);
      input = personNamePicker(ui, state, { value: ini[key], label, onChange: (person) => setVal(key, person.name) }).el;
    } else input = textField(key, { type: key.endsWith('_date') ? 'date' : 'text', maxLength: 200 });
    contextGrid.append(h('label.form-field', h('span.form-label', label), input));
  }
  const sourceContext = h('details.source-evidence', h('summary', ['Source and business context', ini.jira_key, ini.platform, ini.region, ini.channel].filter(Boolean).join(' · ')), contextGrid);
  const descWrap = h('div.desc-wrap', descInput);
  descInput.addEventListener('input', () => descWrap.classList.toggle('dirty', dirty.has('description')));

  const box = ui.pageBox({ pg: 'PG 1', title: 'General Details', actions: print ? null : [analyseBtn] },
    intakeSlot,
    h('div.excel-cols', h('div.col-left', left), h('div.col-right', right)),
    portal ? h('div.intake-linked-summary',
      h('span', 'People entered here are available in Resources.'),
      h('a.link', { href: `#/resources?initiative=${encodeURIComponent(id)}` }, 'Complete resource allocation'),
      ini.prn_code ? h('a.link', { href: `#/funding?prn=${encodeURIComponent(ini.prn_code)}` }, `View funding · ${ini.prn_code}`) : null) : null,
    fundingFields?.el,
    sourceContext,
    bundle.sa_doc_text ? h('details.source-evidence', h('summary', 'Read the full extracted SA document'), h('pre', bundle.sa_doc_text)) : null,
    h('div.section-title', 'Description of Change'),
    descWrap,
    h('div.auto-row', { id: 'change-summary' }, genBtn, h('span.auto-hint', '(populated from SA document attachment)')),
    csSlot,
    grid.el,
    print ? null : h('div.grid-footer', addSel, addBtn),
    l2Host,
    groomingLine,
    print ? null : h('div.page-footer',
      ui.btn('Delete initiative', { variant: 'danger-text', onClick: () => deleteInitiative() }),
      dirtyNote, discardBtn, saveBtn));
  root.append(box);

  paintL2();
  loadActionChip();

  if (params.query && params.query.focus === 'change-summary') {
    requestAnimationFrame(() => document.getElementById('change-summary')?.scrollIntoView({ block: 'start' }));
  }
  const pending = state.pendingAutoRun;
  if (pending && String(pending.initiativeId) === String(id) && pending.feature === 'intake_analysis' && !print) {
    state.pendingAutoRun = null;
    runIntakeAnalysis();
  }

  const onBeforeUnload = (e) => { if (dirty.size) { e.preventDefault(); e.returnValue = ''; } };
  window.addEventListener('beforeunload', onBeforeUnload);
  let lastPersona = state.persona();
  const offPersona = state.on('settings', () => {
    if (state.persona() !== lastPersona) { lastPersona = state.persona(); paintActions(); }
  });
  return () => { window.removeEventListener('beforeunload', onBeforeUnload); offPersona(); };
}
