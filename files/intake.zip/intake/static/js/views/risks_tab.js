// views/risks_tab.js: initiative risk register (editable), Identify Risks (AI card), add risk, 4×4 matrix.
import { createGrid } from '../ui/grid.js';
import { runAiFeature } from '../ui/ai_card.js';
import { previewRisks } from '../ui/previews.js';

export async function render(root, params, ctx) {
  const { api, state, ui } = ctx;
  const { h } = ui;
  const id = params.id;
  const bundle = params.bundle;
  const print = Boolean(params.print);

  const tasks = bundle.tasks || [];
  const sevOpts = state.options('risk_severity');
  const likOpts = state.options('risk_likelihood');
  const catOpts = state.options('risk_category');
  const statusOpts = state.options('risk_status');
  const ownerOpts = state.people().map((p) => ({ value: p.id, label: p.name }));
  const wbsOpts = tasks.map((t) => ({ value: t.id, label: `${t.wbs_code} ${t.step}`, short: t.wbs_code }));

  const aiSlot = h('div.ai-slot', { hidden: true });
  const matrixHost = h('div.matrix-host');
  const gridHost = h('div.grid-host');
  const predictBtn = ui.autoBtn('Predict risks', {
    onClick: () => runAiFeature({
      feature: 'risks', initiativeId: id, container: aiSlot, trigger: predictBtn,
      renderPreview: previewRisks,
      selectable: true, selectableCount: (o) => (o.risks || []).length,
      acceptLabel: 'Add selected to Risk Register',
      acceptMessage: (res, run, body) => {
        const n = (res.applied && res.applied.risks) || (body.selected ? body.selected.length : 0);
        return `${n} risk${n === 1 ? '' : 's'} added to the Risk Register.`;
      },
      onApplied: () => load(),
    }),
  });

  let grid = null;

  function scoreTone(score) {
    if (score >= 12) return 'red';
    if (score >= 6) return 'amber';
    return 'green';
  }

  async function load() {
    ui.mount(gridHost, ui.skeleton({ lines: 4 }));
    let items;
    try {
      const res = await api.listRisks({ initiative_id: id });
      items = res.items || [];
    } catch (err) {
      ui.mount(gridHost, ui.errorPanel(err, { retry: load }));
      return;
    }
    items.sort((a, b) => (b.score || b.severity * b.likelihood) - (a.score || a.severity * a.likelihood));
    grid = createGrid({
      gridKey: `risks-${id}`,
      caption: 'Risk register',
      rows: items,
      flashRunId: state.flashRunId,
      isAi: (r) => r.source === 'ai',
      emptyText: 'No risks recorded. Click Predict risks to review the plan, or add one.',
      columns: [
        { key: 'risk_code', label: 'Risk ID', width: 70, type: 'readonly', cls: 'mono' },
        { key: 'title', label: 'Risk', width: 168, type: 'text', aiTag: true, format: (r) => h('span.clamp-2', { title: r.description || r.title }, r.title), validate: (v) => (!String(v || '').trim() ? 'Risk title is required.' : '') },
        { key: 'category', label: 'Category', width: 92, type: 'select', options: catOpts, allowEmpty: false },
        { key: 'severity', label: 'Severity', width: 82, type: 'select', options: sevOpts, allowEmpty: false },
        { key: 'likelihood', label: 'Likelihood', width: 86, type: 'select', options: likOpts, allowEmpty: false },
        {
          key: 'score', label: 'Score', width: 54, type: 'readonly', align: 'right',
          format: (r) => { const s = (Number(r.severity) || 0) * (Number(r.likelihood) || 0); return h(`span.pill.pill-sm.pill-${scoreTone(s)}`, String(s)); },
        },
        { key: 'owner_id', label: 'Owner', width: 116, type: 'select', options: ownerOpts, format: (r) => ui.txt(r.owner_name || state.personName(r.owner_id), '') },
        { key: 'mitigation', label: 'Mitigation', width: 164, type: 'textarea', format: (r) => (r.mitigation ? h('span.clamp-2', { title: r.mitigation }, r.mitigation) : '') },
        { key: 'task_id', label: 'Linked WBS', width: 80, cls: 'mono', type: 'select', options: wbsOpts, format: (r) => ui.txt(r.wbs_code || (tasks.find((t) => t.id === r.task_id) || {}).wbs_code, '') },
        { key: 'status', label: 'Status', width: 96, type: 'select', options: statusOpts, allowEmpty: false, format: (r) => ui.statusPill(r.status) },
      ],
      rowActions: print ? null : (r) => h('button.icon-btn', { type: 'button', title: `Delete ${r.risk_code || 'risk'}`, aria: { label: `Delete ${r.risk_code || 'risk'}` }, on: { click: () => remove(r) } }, '✕'),
      onCommit: async (r, key, value) => {
        try {
          const updated = await api.updateRisk(r.id, { [key]: value });
          grid.updateRow(updated);
          grid.markSaved(r.id);
          paintMatrix();
        } catch (err) {
          grid.markError(r.id, key, err.message || 'Could not save this change.');
          ui.toastError(err);
        }
      },
    });
    state.flashRunId = null;
    ui.mount(gridHost, grid.el);
    paintMatrix();
  }

  function paintMatrix() {
    const rows = grid ? grid.getRows().filter((r) => r.status !== 'Closed') : [];
    const count = (s, l) => rows.filter((r) => Number(r.severity) === s && Number(r.likelihood) === l).length;
    const label = (opts, v, fb) => (opts.find((o) => Number(o.value) === v) || {}).label || fb;
    ui.mount(matrixHost, h('div',
      h('div.eyebrow', 'Open risks by severity × likelihood'),
      h('table.risk-matrix',
        h('thead', h('tr', h('th', ''), [1, 2, 3, 4].map((l) => h('th', label(likOpts, l, String(l)))))),
        h('tbody', [4, 3, 2, 1].map((s) => h('tr', h('th', label(sevOpts, s, String(s))),
          [1, 2, 3, 4].map((l) => {
            const n = count(s, l);
            const tone = s * l >= 12 ? 4 : s * l >= 6 ? 3 : s * l >= 3 ? 2 : 1;
            return h(`td.rm-${tone}`, { title: `${n} open risk${n === 1 ? '' : 's'}` }, n ? String(n) : '');
          })))))));
  }

  async function remove(r) {
    const ok = await ui.confirmModal({ title: `Delete ${r.risk_code || 'this risk'}?`, message: `${r.title} will be removed from the register.`, confirmLabel: 'Delete risk', danger: true });
    if (!ok) return;
    try {
      await api.deleteRisk(r.id);
      ui.toast(`${r.risk_code || 'Risk'} deleted.`);
      await load();
    } catch (err) {
      ui.toastError(err);
    }
  }

  async function addRisk() {
    const values = await ui.promptModal({
      title: 'Add risk',
      fields: [
        { name: 'title', label: 'Risk', required: true },
        { name: 'category', label: 'Category', type: 'select', options: catOpts, value: 'Schedule' },
        { name: 'severity', label: 'Severity', type: 'select', options: sevOpts, value: 2 },
        { name: 'likelihood', label: 'Likelihood', type: 'select', options: likOpts, value: 2 },
        { name: 'owner_id', label: 'Owner', type: 'select', options: [{ value: '', label: '—' }, ...ownerOpts], value: bundle.initiative.dc_pm_id || '' },
        { name: 'task_id', label: 'Linked WBS', type: 'select', options: [{ value: '', label: '—' }, ...wbsOpts] },
        { name: 'mitigation', label: 'Mitigation', type: 'textarea', rows: 3 },
      ],
      submitLabel: 'Add risk',
    });
    if (!values) return;
    try {
      const created = await api.createRisk(id, {
        title: values.title, category: values.category, severity: Number(values.severity), likelihood: Number(values.likelihood),
        owner_id: values.owner_id ? Number(values.owner_id) : null, task_id: values.task_id ? Number(values.task_id) : null,
        mitigation: values.mitigation || null, status: 'Open',
      });
      ui.toast(`${created.risk_code || 'Risk'} added.`);
      await load();
    } catch (err) {
      ui.toastError(err);
    }
  }

  root.append(ui.pageBox({
    title: 'Risks', hint: `Risk register for ${bundle.initiative.rddc}`,
    actions: print ? null : [predictBtn, ui.btn('+ Add risk', { variant: 'secondary', onClick: () => addRisk() })],
  },
  aiSlot,
  h('details.matrix-details', h('summary.small.muted', 'Severity × likelihood matrix'), matrixHost),
  gridHost,
  h('p.small.muted', { style: { 'margin-top': '8px' } }, 'Score = severity × likelihood (1–16). All risks across initiatives are on the Risk Register page.')));
  await load();
}
