// Intake & Grooming (#/intake): RDDC queue, grooming session cards (agenda max 6), auto-slot, Action required by chips.
import {
  api, h, clear, dataTable, autoButton, button, pageHeader, errorBox, loading, emptyState, statusPill, segmented,
  fmtDate, fmtDay, fmtTime, getToday, go, itemsOf, toast, dayNum, announceChange, framePage,
} from '../charts/kit.js';

const PRE_GROOMED = new Set(['Intake', 'Grooming']);

function queueState(item) {
  if (!PRE_GROOMED.has(item.stage)) return 'groomed';
  return item.session ? 'slotted' : 'todo';
}
function prio(p) {
  const n = Number(p);
  return h('span', { class: `dv-prio dv-prio-${n}`, text: Number.isFinite(n) && n ? `P${n}` : '—' });
}
export function actionChip(item) {
  if (!item.action_required_by && !item.waiting_on) return null;
  const who = item.waiting_on ? `Action required by ${item.waiting_on}` : 'Action required';
  return h('span', { class: 'dv-action-chip', title: 'A reminder is queued in the Outbox every 2 business days until this is resolved' },
    item.action_required_by ? `${who} · ${fmtDay(item.action_required_by)}` : who);
}
function sessionLabel(sess) {
  if (!sess) return '—';
  return `${fmtDay(sess.session_date)} · ${fmtTime(sess.start_time) || '10:00'}`;
}

export async function render(root, params, ctx) {
  const page = framePage(root, 'intake');
  const slotHost = h('div', { class: 'dv-ai-host', hidden: true });
  const body = h('div');
  const autoBtn = autoButton('Auto-slot backlog', () => autoSlot());
  page.append(pageHeader({
    title: 'Intake & Grooming',
    hint: 'Grooming runs Tue and Thu at 10:00 ET · up to 6 initiatives per session · P1 moves to the front',
    actions: [autoBtn],
  }), slotHost, body);

  let filter = 'all';
  let table = null;
  let items = [];

  async function load() {
    clear(body);
    body.appendChild(loading('Loading the intake queue…'));
    let queue;
    let today;
    try {
      [queue, today] = await Promise.all([api.getIntakeQueue(), getToday(ctx)]);
    } catch (err) {
      clear(body);
      body.appendChild(errorBox(err, load));
      return;
    }
    clear(body);
    items = itemsOf(queue);
    const sessions = (Array.isArray(queue.sessions) ? queue.sessions : [])
      .filter((s) => !today || dayNum(s.session_date) >= dayNum(today))
      .sort((a, b) => (a.session_date + a.start_time).localeCompare(b.session_date + b.start_time));

    // queue
    const counts = { all: items.length, todo: 0, slotted: 0, groomed: 0 };
    items.forEach((i) => { counts[queueState(i)] += 1; });
    const queueSection = h('section', { class: 'dv-section', 'data-testid': 'intake-queue' },
      h('h2', { class: 'dv-section-title' }, h('span', { text: 'RDDC queue' }),
        segmented([
          { value: 'all', label: `All ${counts.all}` }, { value: 'todo', label: `To do ${counts.todo}` },
          { value: 'slotted', label: `Slotted ${counts.slotted}` }, { value: 'groomed', label: `Groomed ${counts.groomed}` },
        ], filter, (v) => { filter = v; table.update(filtered()); }, { label: 'Queue filter' })));
    table = dataTable({
      caption: 'RDDC queue',
      columns: [
        { key: 'rddc', label: 'RDDC #', render: (r) => h('a', { class: 'dv-link', href: `#/initiative/${r.initiative_id}/pg1`, on: { click: (e) => { e.preventDefault(); go(ctx, `#/initiative/${r.initiative_id}/pg1`); } } }, r.rddc) },
        { key: 'name', label: 'Name', cls: 'dv-cell-wrap' },
        { key: 'lob', label: 'LOB' },
        { key: 'priority', label: 'Priority', render: (r) => prio(r.priority), sort: (r) => Number(r.priority) || 9 },
        { key: 'stage', label: 'Stage' },
        { key: 'submitted_at', label: 'Submitted', render: (r) => fmtDate(String(r.submitted_at || '').slice(0, 10)) },
        { key: 'session', label: 'Session (Tue/Thu)', render: (r) => sessionLabel(r.session), sort: (r) => (r.session ? r.session.session_date : '9999') },
        { key: 'action_required_by', label: 'Action required by', render: (r) => actionChip(r) || '—', sort: (r) => r.action_required_by || '9999' },
        { key: 'waiting_on', label: 'Waiting on' },
      ],
      rows: filtered(),
      sortKey: 'priority',
      onRowClick: (r) => go(ctx, `#/initiative/${r.initiative_id}/pg1`),
      empty: 'Nothing waiting for grooming. New RDDC tickets will appear here.',
    });
    queueSection.appendChild(table.el);

    // sessions
    const sessSection = h('section', { class: 'dv-section', 'data-testid': 'grooming-sessions' }, h('h2', { class: 'dv-section-title', text: 'Upcoming grooming sessions' }));
    if (!sessions.length) sessSection.appendChild(emptyState('No grooming sessions are scheduled. Sessions run every Tuesday and Thursday at 10:00.'));
    else {
      const grid = h('div', { class: 'dv-sessions' });
      sessions.slice(0, 6).forEach((sess, idx) => grid.appendChild(sessionCard(sess, sessions[idx + 1] || null)));
      sessSection.appendChild(grid);
    }
    body.append(sessSection, queueSection);
  }

  function filtered() {
    return filter === 'all' ? items : items.filter((i) => queueState(i) === filter);
  }

  function sessionCard(sess, nextSess) {
    const slots = (Array.isArray(sess.slots) ? sess.slots : []).slice().sort((a, b) => Number(a.slot_order) - Number(b.slot_order));
    const capacity = Number(sess.capacity) || 6;
    const attendees = new Map();
    slots.forEach((sl) => (Array.isArray(sl.recipients) ? sl.recipients : []).forEach((r) => { if (r && r.name) attendees.set(r.id ?? r.name, r.name); }));
    const nextRoom = nextSess && (Array.isArray(nextSess.slots) ? nextSess.slots.length : 0) < (Number(nextSess.capacity) || 6);
    const agenda = h('ol', { class: 'dv-agenda' });
    for (const sl of slots.slice(0, capacity)) {
      agenda.appendChild(h('li', {},
        prio(sl.priority),
        h('a', { class: 'dv-link', href: `#/initiative/${sl.initiative_id}/pg1`, on: { click: (e) => { e.preventDefault(); go(ctx, `#/initiative/${sl.initiative_id}/pg1`); } } }, sl.rddc),
        h('span', { class: 'dv-grow', title: sl.name, text: sl.name }),
        statusPill(sl.status),
        h('span', { class: 'dv-agenda-actions' },
        sl.status === 'Proposed' ? button('Confirm', (e) => slotAction(e.currentTarget, { session_id: sess.id, initiative_id: sl.initiative_id, status: 'Confirmed' }, `${sl.rddc} confirmed for ${fmtDay(sess.session_date)}.`), { kind: 'text', small: true }) : null,
        nextRoom ? button('Move to next', (e) => slotAction(e.currentTarget, { session_id: sess.id, initiative_id: sl.initiative_id, new_session_id: nextSess.id }, `${sl.rddc} moved to ${fmtDay(nextSess.session_date)}.`), { kind: 'text', small: true, attrs: { title: `Move to ${sessionLabel(nextSess)}` } }) : null)));
    }
    return h('article', { class: 'dv-session', 'data-session': String(sess.id) },
      h('div', { class: 'dv-session-head' },
        h('span', { class: 'dv-session-date', text: sessionLabel(sess) }),
        h('span', { class: 'dv-session-cap', text: `${slots.length} of ${capacity} slots` })),
      h('div', { class: `dv-capbar${slots.length >= capacity ? ' is-full' : ''}` }, h('span', { style: { width: `${Math.min(100, (slots.length / capacity) * 100)}%` } })),
      slots.length ? agenda : h('p', { class: 'dv-muted', text: 'No initiatives slotted yet.' }),
      h('div', { class: 'dv-attendees', text: attendees.size ? `Attendees: Arlo Kingsley (Delivery Lead), ${[...attendees.values()].filter((n) => n !== 'Arlo Kingsley').join(', ')}` : 'Attendees: Arlo Kingsley (Delivery Lead)' }));
  }

  async function slotAction(btn, body2, message) {
    btn.disabled = true;
    try {
      await api.updateGroomingSlot(body2);
      toast(message);
      announceChange(body2.initiative_id, 'grooming');
      await load();
    } catch (err) {
      btn.disabled = false;
      toast(err.message, 'warning');
    }
  }

  async function autoSlot() {
    autoBtn.disabled = true;
    clear(slotHost);
    slotHost.hidden = false;
    slotHost.appendChild(loading('Finding the next open sessions…'));
    try {
      const plan = await api.autoSlotGrooming({ dry_run: true });
      clear(slotHost);
      const assignments = Array.isArray(plan.assignments) ? plan.assignments : [];
      const unslotted = Array.isArray(plan.unslotted) ? plan.unslotted : [];
      const panel = h('section', { class: 'ai-card ai-card-result' },
        h('div', { class: 'ai-card-head' }, h('div', { class: 'ai-card-title', text: '✦ Auto-slot backlog · proposed slots' }), h('div', { class: 'ai-card-meta' }, h('span', { class: 'mode-chip', text: 'Grooming rules · Tue/Thu 10:00' }))),
        h('div', { class: 'ai-preview' },
          assignments.length
            ? dataTable({ dense: true, caption: 'Proposed slots', columns: [
              { key: 'rddc', label: 'RDDC #' },
              { key: 'session_date', label: 'Session', render: (a) => `${fmtDay(a.session_date)} · ${fmtTime(a.start_time) || '10:00'}` },
              { key: 'recipients', label: 'Invite goes to', sortable: false, render: (a) => (Array.isArray(a.recipients) ? a.recipients.map((r) => r.name).join(', ') : '—') },
            ], rows: assignments }).el
            : h('p', { text: 'Everything waiting is already slotted.' }),
          unslotted.length ? h('ul', { class: 'dv-ai-warn' }, unslotted.map((u) => h('li', { text: `${u.rddc}: ${u.reason}` }))) : null),
        h('div', { class: 'ai-card-actions' },
          assignments.length ? button('Confirm slots', async (e) => {
            const btn = e.currentTarget;
            btn.disabled = true;
            try {
              const res = await api.autoSlotGrooming({ dry_run: false });
              const n = Array.isArray(res.assignments) ? res.assignments.length : assignments.length;
              clear(slotHost);
              slotHost.appendChild(h('p', { class: 'ai-accepted-line', text: `${n} initiative${n === 1 ? '' : 's'} slotted. Invites queued in the Outbox.` }));
              announceChange(null, 'grooming');
              await load();
            } catch (err) {
              btn.disabled = false;
              toast(err.message, 'warning');
            }
          }, { kind: 'primary' }) : null,
          button(assignments.length ? 'Cancel' : 'Close', () => { clear(slotHost); slotHost.hidden = true; }, { kind: 'text' })));
      slotHost.appendChild(panel);
    } catch (err) {
      clear(slotHost);
      slotHost.appendChild(errorBox(err, autoSlot));
    } finally {
      autoBtn.disabled = false;
    }
  }

  await load();
  return undefined;
}
