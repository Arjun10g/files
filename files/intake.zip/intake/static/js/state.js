// state.js: tiny shared store (lookups cache, settings, current initiative, AI flash markers).
// Views receive it as ctx.state; modules that import it directly share the same instance.
import * as api from './api.js';

const LAST_KEY = 'bmo.lastInitiativeId';
const VISIT_KEY = 'bmo.visited';

const listeners = new Map();

function readStorage(key, fallback) {
  try {
    const raw = window.localStorage.getItem(key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function writeStorage(key, value) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable (private window); the value lives in memory only */
  }
}

function readSession(key, fallback) {
  try {
    const raw = window.sessionStorage.getItem(key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function writeSession(key, value) {
  try {
    window.sessionStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable; marks last for this page load only */
  }
}

let lookupsPromise = null;

export const state = {
  version: '2.0.0',
  lookups: null,
  settings: null,
  appHealth: null,
  /** {initiativeId, rddc, name, tab, page} for the page on screen; used by the assistant drawer. */
  current: { initiativeId: null, rddc: null, name: null, tab: null, page: null },
  /** ai_run_id whose rows should flash once after an Accept. */
  flashRunId: null,
  /** One-shot request for a view to auto-run an AI feature after navigation. */
  pendingAutoRun: null,

  on(event, fn) {
    if (!listeners.has(event)) listeners.set(event, new Set());
    listeners.get(event).add(fn);
    return () => listeners.get(event)?.delete(fn);
  },

  emit(event, data) {
    for (const fn of listeners.get(event) || []) {
      try {
        fn(data);
      } catch (err) {
        window.dispatchEvent(new CustomEvent('bmo:error', { detail: err }));
      }
    }
  },

  async loadLookups(force = false) {
    if (force || !lookupsPromise) {
      lookupsPromise = api.getLookups().then((data) => {
        state.lookups = data || {};
        state.emit('lookups', state.lookups);
        return state.lookups;
      }).catch((err) => {
        lookupsPromise = null;
        throw err;
      });
    }
    return lookupsPromise;
  },

  /** Enum options for a lookup category: [{value, label}]. */
  options(category) {
    const list = state.lookups && Array.isArray(state.lookups[category]) ? state.lookups[category] : [];
    return list.map((o) => (o && typeof o === 'object' && 'value' in o
      ? { value: o.value, label: o.label ?? String(o.value) }
      : { value: o, label: String(o) }));
  },

  /** Display label of an enum value (falls back to the value itself, never 'undefined'). */
  label(category, value) {
    if (value === null || value === undefined || value === '') return '';
    const hit = state.options(category).find((o) => String(o.value) === String(value));
    return hit ? hit.label : String(value);
  },

  /** People from lookups, optionally filtered: {team, tracked, teams:[...]} */
  people(filter = {}) {
    const all = (state.lookups && state.lookups.resources) || [];
    return all.filter((r) => {
      if (filter.team && r.team !== filter.team) return false;
      if (filter.teams && !filter.teams.includes(r.team)) return false;
      if (filter.tracked !== undefined && Boolean(r.capacity_eligible) !== Boolean(filter.tracked)) return false;
      return true;
    });
  },

  personName(id) {
    if (id === null || id === undefined || id === '') return '';
    const p = ((state.lookups && state.lookups.resources) || []).find((r) => String(r.id) === String(id));
    return p ? p.name : '';
  },

  components() {
    return (state.lookups && state.lookups.components) || [];
  },

  setSettings(settings) {
    if (!settings) return;
    state.settings = { ...(state.settings || {}), ...settings };
    state.emit('settings', state.settings);
  },

  setAppHealth(health) {
    state.appHealth = health;
    state.emit('apphealth', health);
  },

  /** 'Realistic' | 'Fast' */
  aiSpeed() {
    return (state.settings && state.settings.ai_speed) === 'Fast' ? 'Fast' : 'Realistic';
  },

  persona() {
    return (state.settings && state.settings.persona) || 'DC PM';
  },

  /** True when AI calls will go to Live Claude. */
  isLive() {
    const s = state.settings || {};
    if (s.ai_mode === 'live') return Boolean(s.live_available);
    if (s.ai_mode === 'auto') return Boolean(s.live_available);
    return false;
  },

  setCurrent(patch) {
    state.current = { ...state.current, ...patch };
    if (patch.initiativeId) {
      state.lastInitiativeId = patch.initiativeId;
      writeStorage(LAST_KEY, patch.initiativeId);
    }
    state.emit('current', state.current);
  },

  lastInitiativeId: readStorage(LAST_KEY, null),

  forgetInitiative(id) {
    if (String(state.lastInitiativeId) === String(id)) {
      state.lastInitiativeId = null;
      writeStorage(LAST_KEY, null);
    }
  },

  /** Session-scoped "this initiative's page/chart was opened" marks (stepper ticks). */
  visited(initiativeId, what) {
    return readSession(VISIT_KEY, []).includes(`${initiativeId}:${what}`);
  },

  markVisited(initiativeId, what) {
    const list = readSession(VISIT_KEY, []);
    const key = `${initiativeId}:${what}`;
    if (!list.includes(key)) {
      list.push(key);
      writeSession(VISIT_KEY, list.slice(-200));
      state.emit('visited', { initiativeId, what });
    }
  },

  ganttShown(initiativeId) {
    return state.visited(initiativeId, 'gantt');
  },

  markGanttShown(initiativeId) {
    state.markVisited(initiativeId, 'gantt');
  },

  /** Called after a demo reset so cached ids do not point at deleted rows. */
  clearLocal() {
    state.lastInitiativeId = null;
    writeStorage(LAST_KEY, null);
    writeSession(VISIT_KEY, []);
    state.flashRunId = null;
    state.pendingAutoRun = null;
  },
};

export default state;
