# Agentic AI in VS Code — training pack

Open `START_HERE.html` for the package index. `Presentation.html` is the offline 25-slide presenter view; arrow keys and Page Up/Down navigate. Guided clips are instructor-authored still walkthroughs. The PowerPoint is editable and carries full notes; the PDF matches its 25 slides.

## Contents

- `BMO_Agentic_AI_VS_Code.pptx` and `.pdf` — exact authorized slide order.
- `preview/slide-01.png` … `slide-25.png`, `contact-sheet.png` — rendered views.
- `slide_content.json`, `slide_specs/`, `handoff/` — authored content, references, source, and rebuild steps.
- `teaching/presenter-guide.html` and `.pdf`, `copyable-prompts.html` and `.md`.
- `demo/student_starter.zip` — student files, fixed tests, and optional VS Code agent profiles; no answer.
- `demo/instructor_reference.zip` — authored snapshots and actual local test records.
- `media/` — original screenshots, crops, posters, transcripts, and MP4s with `manifest.json` provenance.

## Evidence boundaries

Starter 3/6, partial patch 4/6, and reference 6/6 are instructor-authored snapshots, not AI performance. No authenticated Windows Copilot run, live delegated model switch, measured billing, or benchmark winner is claimed. Local screenshots were captured on macOS in the Local harness; official VS Code reference assets are labelled separately. Actual supported models, tools, permissions, and billing vary by account and integration.

## Rebuild

See `handoff/REBUILD.md`. The deck is generated from all 25 `slide_specs/slide_NN.json` files, preserving exact titles/order from `handoff/outline.json`.
