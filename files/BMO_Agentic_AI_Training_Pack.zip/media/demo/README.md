# V4 demonstration captures

These are actual 2880×1724 macOS VS Code 1.143.1 window captures and unretouched crops of those captures. `manifest.json` records the source file hashes, crop boxes, dimensions, captions, and terminal commands.

## Suggested large images

| Teaching moment | Image |
| --- | --- |
| Workspace file tree | `workspace-map-workspace.png` |
| Project instructions | `project-instructions-editor.png` |
| Read-only scout | `read-only-code-scout-editor.png` |
| Bounded writer | `bounded-writer-editor.png` |
| Planner handoff | `planner-handoff-editor.png` |
| Reusable task prompt | `fix-prompt-file-editor.png` |
| Parallel inspection prompt | `parallel-scouts-prompt-editor.png` |
| Six fixed tests | `six-fixed-tests-editor.png` |
| Starter failures | `baseline-tests-terminal.png` |
| Partial patch failures | `partial-patch-tests-terminal.png` |
| Reference pass | `verified-tests-terminal.png` |
| Patch comparison | `reference-diff-diff.png` |
| Hypothetical token arithmetic | `token-cost-example-editor.png`, `token-cost-example-terminal.png` |
| Cost and effort worksheet | `cost-effort-preview-preview.png` |
| Compact handoff | `compact-handoff-preview-preview.png` |
| Decision scorecard | `decision-scorecard-preview-preview.png` |

Every instructor-authored code state and worksheet is labelled in its asset caption. Terminal test statuses and the color diff are actual local commands. Copilot Chat chrome is visible in some full captures; no Copilot prompt, response, model run, or Windows session was captured. The hypothetical token arithmetic uses arbitrary units and does not claim observed Copilot pricing or savings.
