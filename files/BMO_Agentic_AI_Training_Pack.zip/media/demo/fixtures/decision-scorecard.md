# DECISION SCORECARD — teaching template

Compare approaches only after the same fixed six-test gate and review.

| Candidate | Six tests | Diff reviewed? | Remaining risk | Usage | Elapsed | Accept? |
| --- | --- | --- | --- | --- | --- | --- |
| Single agent | record | record | record | record | record | record |
| Planner + bounded writer | record | record | record | record | record | record |
| Two scouts + writer + reviewer | record | record | record | record | record | record |

A passing test count is necessary for this exercise, but not sufficient
for production acceptance. Keep model availability and tenant pricing
as observed session facts, not claims from this example.
