# COST / EFFORT WORKSHEET — teaching template

Fill from the actual session record. Blank cells mean "not measured."

| Stage | Model selected | Requests | Input tokens | Output tokens | Wall time | Rework | Accepted? |
| --- | --- | ---: | ---: | ---: | ---: | --- | --- |
| Plan |  |  |  |  |  |  |  |
| Two independent scouts |  |  |  |  |  |  |  |
| Bounded writer |  |  |  |  |  |  |  |
| Independent review |  |  |  |  |  |  |  |

Use the account's current usage and pricing. A parallel request still
consumes work; compare accepted outcomes, rework, and elapsed time.
Never describe this blank worksheet as measured savings.
