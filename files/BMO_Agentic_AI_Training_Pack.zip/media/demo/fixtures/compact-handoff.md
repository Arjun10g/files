# COMPACT HANDOFF — instructor-authored example

Source: code inspection of the starter, not an agent transcript.

Goal: fix `delivery_fee(total_cents)` in `shipping.py` only.
Boundary: integer cents; 500 below 10000, zero at or above 10000.
Input rule: `ValueError` for negative or non-built-in-int, including bool.
Finding: `shipping.py:6` uses `> 10000`; at 10000 it returns 500.
Evidence status: code-derived prediction. Baseline tests are separate.
Fixed tests: do not change `test_shipping.py`.
Verify: `py -3 -m unittest -v test_shipping` on Windows.
Return: changed lines, actual six statuses, remaining uncertainty.
