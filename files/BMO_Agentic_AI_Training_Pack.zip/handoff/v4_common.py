"""Shared paths and data for the portable screenshot-led workshop builders."""
from pathlib import Path
import json

HERE = Path(__file__).resolve()
OUT = next((p for p in HERE.parents if (p/'teaching/demo_storyboards.json').is_file()), None)
if OUT is None:
    ROOT = next(p for p in HERE.parents if (p/'deliverables_v4').is_dir())
    OUT = ROOT/'deliverables_v4'
else:
    ROOT = OUT.parent

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

def load():
    specs = [read_json(p) for p in sorted((OUT/'slide_specs').glob('slide_*.json'))]
    demos = read_json(OUT/'teaching/demo_storyboards.json')
    if isinstance(demos, dict): demos = demos['slides']
    outline = read_json(OUT/'handoff/outline.json')
    assert len(specs) == len(demos) == len(outline) == 25
    for spec, demo, line in zip(specs, demos, outline):
        assert spec['number'] == demo['number'] == line['number']
        assert spec['title'] == demo['title'] == line['title']
        assert len(demo['steps']) >= 3
        for step in demo['steps']:
            assert (OUT/step['screenshot']).is_file(), step['screenshot']
    return specs, demos

def source_url(url, nested=False):
    for prefix in ('deliverables_v3/', 'deliverables_v4/'):
        if url.startswith(prefix):
            url = url[len(prefix):]
            return '../'+url if nested else url
    return url
