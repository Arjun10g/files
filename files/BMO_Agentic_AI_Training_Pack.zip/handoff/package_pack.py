#!/usr/bin/env python3
"""Validate and package the complete portable V4 workshop."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


SCRIPT = Path(__file__).resolve()
OUT = next((parent for parent in SCRIPT.parents
            if (parent / "teaching/demo_storyboards.json").is_file()), None)
if OUT is None:
    OUT = SCRIPT.parents[1] / "deliverables_v4"
ARCHIVE = OUT / "BMO_Agentic_AI_Training_Pack_v4.zip"

REQUIRED = (
    "START_HERE.html", "Presentation.html", "README.md",
    "BMO_Agentic_AI_VS_Code.pptx", "BMO_Agentic_AI_VS_Code.pdf",
    "teaching/demo_storyboards.json", "teaching/demo_walkthroughs.json",
    "teaching/demo-workbook.html", "teaching/BMO_Agentic_AI_Demo_Workbook.pdf",
    "demo/student_starter.zip", "demo/instructor_reference.zip",
    "media/manifest.json", "media/demo/manifest.json", "media/demos/manifest.json",
    "handoff/REBUILD.md", "handoff/WINDOWS_COPILOT_CAPTURE.html",
    "handoff/requirements.txt", "handoff/v4_common.py",
    "handoff/rebuild_demo_media.py", "handoff/rebuild_deck.py",
    "handoff/rebuild_training.py", "handoff/package_pack.py",
    "handoff/ASTRA_DEMO_PLAN.txt", "handoff/ASTRA_DEMO_PLAN.json",
    "reviews/V4_REVIEW_MANIFEST.json", "preview/contact-sheet.png",
)
EXCLUDE_NAMES = {".DS_Store", "Thumbs.db", "desktop.ini", ".gitkeep"}
EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
                ".venv", "node_modules", ".git", "tmp", "temp"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".swp", ".swo", ".tmp", ".bak"}


def validate() -> tuple[int, int]:
    missing = [name for name in REQUIRED if not (OUT / name).is_file()]
    missing += [f"slide_specs/slide_{n:02d}.json" for n in range(1, 26)
                if not (OUT / f"slide_specs/slide_{n:02d}.json").is_file()]
    missing += [f"preview/slide-{n:02d}.png" for n in range(1, 26)
                if not (OUT / f"preview/slide-{n:02d}.png").is_file()]
    missing += [f"media/demos/slide-{n:02d}-demo.mp4" for n in range(1, 26)
                if not (OUT / f"media/demos/slide-{n:02d}-demo.mp4").is_file()]
    if missing:
        raise SystemExit("Package incomplete; missing:\n" + "\n".join(missing))

    demos = json.loads((OUT / "teaching/demo_storyboards.json").read_text(encoding="utf-8"))
    if isinstance(demos, dict):
        demos = demos["slides"]
    if len(demos) != 25:
        raise SystemExit(f"Expected 25 storyboards, found {len(demos)}")
    count = 0
    for n, demo in enumerate(demos, 1):
        if demo.get("number") != n or len(demo.get("steps", [])) < 3:
            raise SystemExit(f"Storyboard {n:02d} has incorrect number or too few steps")
        for step in demo["steps"]:
            source = step.get("screenshot")
            if not source or not (OUT / source).is_file():
                raise SystemExit(f"Storyboard {n:02d} missing screenshot: {source}")
            count += 1
    return len(demos), count


def files():
    for path in sorted(OUT.rglob("*")):
        if not path.is_file() or path == ARCHIVE:
            continue
        relative = path.relative_to(OUT)
        # PPTX slide-poster PNGs are regenerated from retained hero captures.
        # Every guided frame and each clip remains in the portable archive.
        if relative.parts[:2] == ("media", "slide-posters"):
            continue
        if (path.name in EXCLUDE_NAMES or path.name.startswith("._")
                or any(part in EXCLUDE_DIRS for part in relative.parts)
                or path.suffix.lower() in EXCLUDE_SUFFIXES
                or path.suffix.lower() == ".zip" and relative.parts[0] != "demo"):
            continue
        yield path, relative


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    slides, steps = validate()
    if args.validate_only:
        print(f"Ready: {slides} slides, {steps} demo steps")
        return
    paths = list(files())
    with ZipFile(ARCHIVE, "w", ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
        for path, relative in paths:
            info = ZipInfo(relative.as_posix(), date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=ZIP_DEFLATED, compresslevel=6)
    with ZipFile(ARCHIVE) as archive:
        bad = archive.testzip()
        if bad:
            raise SystemExit(f"Archive CRC failure: {bad}")
        names = set(archive.namelist())
        absent = [name for name in REQUIRED if name not in names]
        absent += [f"media/demos/slide-{n:02d}/step-01.png" for n in range(1, 26)
                   if f"media/demos/slide-{n:02d}/step-01.png" not in names]
        if absent:
            raise SystemExit("Archive missing required files: " + ", ".join(absent))
    print(f"Packaged {len(paths)} files, {slides} slides, {steps} demo steps: {ARCHIVE}")


if __name__ == "__main__":
    main()
