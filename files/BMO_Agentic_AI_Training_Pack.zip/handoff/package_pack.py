#!/usr/bin/env python3
"""Package the complete offline training bundle with stable relative paths."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

PARENTS=Path(__file__).resolve().parents
OUT=next((p for p in PARENTS if (p/'slide_specs').is_dir() and (p/'handoff/outline.json').is_file()),None)
if OUT is None:
    ROOT=next(p for p in PARENTS if (p/'deliverables_v3/slide_specs').is_dir());OUT=ROOT/'deliverables_v3'
ZIP=OUT/'BMO_Agentic_AI_Training_Pack.zip'
SKIP={'BMO_Agentic_AI_Training_Pack.zip','.DS_Store'}
with ZipFile(ZIP,'w',ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(OUT.rglob('*')):
        if not p.is_file() or p.name in SKIP or '__pycache__' in p.parts or p.suffix=='.pyc':continue
        z.write(p,p.relative_to(OUT))
print(ZIP)
