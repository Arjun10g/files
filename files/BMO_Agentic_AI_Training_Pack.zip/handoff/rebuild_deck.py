#!/usr/bin/env python3
"""Build 25 screenshot-led slides with an embedded guided demo on every slide."""
from __future__ import annotations
import json, math, os, shutil, subprocess, tempfile
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from PIL import Image, ImageOps, ImageDraw
import pymupdf
from v4_common import OUT, load, write_json, source_url

BLUE=RGBColor.from_string('004A8C'); NAVY=RGBColor.from_string('0D2646')
INK=RGBColor.from_string('1D3144'); MUTED=RGBColor.from_string('5C7182')
PALE=RGBColor.from_string('E6F2FB'); LINE=RGBColor.from_string('B9CFDE'); WHITE=RGBColor(255,255,255)

def box(s,x,y,w,h,fill=WHITE,line=LINE):
    q=s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,Inches(x),Inches(y),Inches(w),Inches(h))
    q.fill.solid();q.fill.fore_color.rgb=fill;q.line.color.rgb=line
    q.line.width=Pt(1)
    try:q.adjustments[0]=.09
    except Exception:pass
    return q

def text(s,value,x,y,w,h,size=20,color=INK,bold=False,font='Aptos',align=PP_ALIGN.LEFT):
    q=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));tf=q.text_frame
    tf.clear();tf.word_wrap=True;tf.margin_left=tf.margin_right=Inches(.035)
    tf.margin_top=tf.margin_bottom=Inches(.025);tf.vertical_anchor=MSO_ANCHOR.MIDDLE
    for i,line in enumerate(str(value).split('\n')):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.text=line;p.font.name=font
        p.font.size=Pt(size);p.font.color.rgb=color;p.font.bold=bold;p.alignment=align
        p.space_before=p.space_after=Pt(0)
    return q

def fit_image(path,size=(1920,1080)):
    image=Image.open(path).convert('RGB');frame=Image.new('RGB',size,'#101a24')
    thumb=ImageOps.contain(image,size,Image.Resampling.LANCZOS)
    frame.paste(thumb,((size[0]-thumb.width)//2,(size[1]-thumb.height)//2))
    return frame

def notes(spec,demo):
    chunks=[spec['speaker_notes'],'TAKEAWAY: '+spec['takeaway'],
            'INTEGRATED DEMO: click the large screenshot to play the captioned MP4, or open Presentation.html and press D for copyable steps.',
            'GOAL: '+demo['goal']]
    for i,s in enumerate(demo['steps']):
        chunks.append(f"STEP {i+1}: {s['title']}\nACTION: {s.get('action','')}\n"+
                      ('EXACT PROMPT:\n'+s['prompt']+'\n' if s.get('prompt') else '')+
                      ('EXACT CODE:\n'+s['code']+'\n' if s.get('code') else '')+
                      ('COMMAND: '+s['command']+'\n' if s.get('command') else '')+
                      'CHECKPOINT: '+s.get('expected','')+'\nSCREENSHOT: '+s['screenshot']+'\nPROVENANCE: '+s.get('caption',''))
    chunks.extend(['FOLLOW-UP: '+demo.get('follow_up',''),'CAVEAT: '+spec['caveat'],
                   'EVIDENCE: code snapshots and guided clips are instructor-authored. Test results come from local execution; they are not agent/model benchmarks. Local UI captures are macOS; Windows Copilot execution requires the capture handoff.',
                   'SOURCES:\n'+'\n'.join(q['title']+' — '+source_url(q['url']) for q in spec['sources'])])
    return '\n\n'.join(chunks)

def main():
    specs,demos=load();prs=Presentation();prs.slide_width=Inches(16);prs.slide_height=Inches(9)
    poster_dir=OUT/'media/slide-posters';poster_dir.mkdir(exist_ok=True)
    for spec,demo in zip(specs,demos):
        s=prs.slides.add_slide(prs.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=WHITE
        accent=box(s,.30,.34,.09,8.0,BLUE,BLUE)
        s.shapes.add_picture(str(OUT/'media/BMO_logo.png'),Inches(14.43),Inches(.30),width=Inches(1.15))
        text(s,spec['title'],.78,.49,13.3,1.15,32 if len(spec['title'])<55 else 29,NAVY,True)
        text(s,'DEMO '+f"{spec['number']:02d}"+'  ·  CLICK THE SCREENSHOT TO PLAY',.82,1.73,9.9,.33,13,BLUE,True)
        # Large 16:9 movie poster is the screenshot itself; the PDF retains it.
        poster=poster_dir/f"slide-{spec['number']:02d}.png"
        fit_image(OUT/demo['hero']).save(poster,optimize=True)
        s.shapes.add_movie(str(OUT/demo['clip']),Inches(.81),Inches(2.16),Inches(10.0),Inches(5.625),
            poster_frame_image=str(poster),mime_type='video/mp4')
        for v in s._element.xpath('.//p:video'):v.set('fullScrn','1')
        cues=demo.get('main_cues') or [{'title':q['title'],'detail':q['action']} for q in demo['steps'][:3]]
        text(s,'TRY IT IN VS CODE',11.10,1.73,4.2,.33,13,BLUE,True)
        for i,cue in enumerate(cues[:3]):
            if isinstance(cue,str):cue={'title':cue,'detail':''}
            y=2.16+i*1.78
            box(s,11.08,y,4.25,1.60,PALE if i==0 else WHITE)
            text(s,f'{i+1:02d}',11.26,y+.13,.51,.43,18,BLUE,True)
            text(s,cue['title'],11.88,y+.08,3.19,.62,20,NAVY,True)
            text(s,cue.get('detail',''),11.33,y+.73,3.72,.69,16,INK)
        # Every slide links directly to its offline step-through.
        q=text(s,'Open detailed steps →',11.17,7.55,3.9,.33,14,BLUE,True)
        q.text_frame.paragraphs[0].runs[0].hyperlink.address=f"Presentation.html#slide-{spec['number']}/demo"
        caption=demo.get('hero_caption','Authentic VS Code capture · instructor-authored example')
        text(s,caption,.84,7.87,14.45,.27,10.3,MUTED)
        text(s,spec['section'].upper(),.82,8.40,7.5,.28,11,MUTED,True)
        text(s,f"{spec['number']:02d} / 25",14.07,8.37,1.25,.31,12,MUTED,True,align=PP_ALIGN.RIGHT)
        box(s,.82,8.24,14.55,.014,LINE,LINE)
        s.notes_slide.notes_text_frame.text=notes(spec,demo)
    pptx=OUT/'BMO_Agentic_AI_VS_Code.pptx';prs.save(pptx)
    write_json(OUT/'slide_content.json',specs)
    office=shutil.which('soffice') or '/Applications/LibreOffice.app/Contents/MacOS/soffice'
    if not Path(office).exists():
        office=str(Path(os.environ.get('PROGRAMFILES','C:/Program Files'))/'LibreOffice/program/soffice.exe')
    assert Path(office).exists(),'Install LibreOffice or add soffice to PATH'
    with tempfile.TemporaryDirectory(prefix='agentic-v4-office-') as temp:
        subprocess.run([office,'-env:UserInstallation='+Path(temp).as_uri(),'--headless','--convert-to','pdf','--outdir',str(OUT),str(pptx)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    doc=pymupdf.open(OUT/'BMO_Agentic_AI_VS_Code.pdf');assert len(doc)==25
    preview=OUT/'preview';preview.mkdir(exist_ok=True);thumbs=[]
    for i,page in enumerate(doc):
        path=preview/f'slide-{i+1:02d}.png';page.get_pixmap(matrix=pymupdf.Matrix(1.5,1.5),alpha=False).save(path)
        im=Image.open(path).convert('RGB');im.thumbnail((520,293));thumbs.append(im.copy())
    sheet=Image.new('RGB',(2600,1625),'#e7eef4');dr=ImageDraw.Draw(sheet)
    for i,im in enumerate(thumbs):
        x=(i%5)*520;y=(i//5)*325;sheet.paste(im,(x,y));dr.text((x+8,y+298),f'{i+1:02d} {specs[i]["title"][:52]}',fill='#17334c')
    sheet.save(preview/'contact-sheet.png')
    print('Built 25 screenshot-led slides, 25 embedded demos, matching PDF and previews',flush=True)

if __name__=='__main__':main()
