#!/usr/bin/env python3
"""Build the editable 25-slide training deck from independently authored specs."""
from __future__ import annotations

import json, math, os, re, shutil, subprocess, tempfile
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from PIL import Image, ImageOps, ImageDraw, ImageFont
import fitz

PARENTS = Path(__file__).resolve().parents
OUT = next((p for p in PARENTS if (p/'slide_specs').is_dir() and (p/'handoff/outline.json').is_file()), None)
if OUT is None:
    ROOT = next(p for p in PARENTS if (p/'deliverables_v3/slide_specs').is_dir())
    OUT = ROOT/'deliverables_v3'
else:
    ROOT = OUT.parent
SPECS = [json.loads(p.read_text(encoding='utf-8')) for p in sorted((OUT/'slide_specs').glob('slide_*.json'))]
OUTLINE = json.loads((OUT/'handoff/outline.json').read_text(encoding='utf-8'))
assert len(SPECS) == len(OUTLINE) == 25
assert all(a['number']==b['number'] and a['title']==b['title'] for a,b in zip(SPECS,OUTLINE))

BLUE=RGBColor(0,74,140); NAVY=RGBColor(13,38,70); SKY=RGBColor(230,242,251)
TEAL=RGBColor(0,119,129); PALE=RGBColor(245,249,252); LINE=RGBColor(185,207,222)
INK=RGBColor(29,49,68); MUTED=RGBColor(92,111,130); GREEN=RGBColor(25,128,82)
RED=RGBColor(169,51,57); WHITE=RGBColor(255,255,255); GOLD=RGBColor(226,166,42)
prs=Presentation(); prs.slide_width=Inches(16); prs.slide_height=Inches(9)
BLANK=prs.slide_layouts[6]

def rect(s,x,y,w,h,fill=WHITE,line=LINE,r=.14):
    typ=MSO_SHAPE.ROUNDED_RECTANGLE if r else MSO_SHAPE.RECTANGLE
    q=s.shapes.add_shape(typ, Inches(x), Inches(y), Inches(w), Inches(h))
    q.fill.solid(); q.fill.fore_color.rgb=fill
    q.line.color.rgb=line; q.line.width=Pt(1.1)
    if r:
        try: q.adjustments[0]=r
        except Exception: pass
    return q

def txt(s,t,x,y,w,h,size=22,color=INK,bold=False,align='left',font='Aptos',margin=.04):
    q=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h))
    tf=q.text_frame; tf.clear(); tf.word_wrap=True
    tf.margin_left=tf.margin_right=Inches(margin); tf.margin_top=Inches(.02); tf.margin_bottom=0
    tf.vertical_anchor=MSO_ANCHOR.MIDDLE
    for i,line in enumerate(str(t).split('\n')):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph()
        p.text=line; p.font.name=font; p.font.size=Pt(size); p.font.bold=bold; p.font.color.rgb=color
        p.space_before=Pt(0);p.space_after=Pt(0)
        p.alignment={'left':PP_ALIGN.LEFT,'center':PP_ALIGN.CENTER,'right':PP_ALIGN.RIGHT}[align]
    return q

def arrow(s,x1,y1,x2,y2,dashed=False,color=BLUE,width=2.7):
    l=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
    l.line.color.rgb=color;l.line.width=Pt(width)
    if dashed:
        from pptx.enum.dml import MSO_LINE_DASH_STYLE
        l.line.dash_style=MSO_LINE_DASH_STYLE.DASH
    # Chevron at the destination is an editable shape, unlike bitmap arrowheads.
    dx,dy=x2-x1,y2-y1; angle=math.degrees(math.atan2(dy,dx))
    tip=s.shapes.add_shape(MSO_SHAPE.CHEVRON, Inches(x2-.10), Inches(y2-.10), Inches(.19), Inches(.20))
    tip.rotation=angle;tip.fill.solid();tip.fill.fore_color.rgb=color;tip.line.fill.background()
    return l

def chip(s,t,x,y,w=None,fill=SKY,color=BLUE,size=15):
    w=w or max(1.0,min(3.2,len(t)*.105+.4))
    rect(s,x,y,w,.36,fill,fill,.4);txt(s,t,x+.07,y,w-.14,.34,size,color,True,'center')

def node(s,label,x,y,w,h=1.02,detail=None,fill=PALE,accent=BLUE,model=None,size=21):
    rect(s,x,y,w,h,fill,LINE,.12)
    rect(s,x,y,.08,h,accent,accent,0)
    txt(s,label,x+.22,y+.12,w-.38,.43,size,NAVY,True)
    if detail:txt(s,detail,x+.22,y+.59,w-.38,.33,15,MUTED)
    if model: chip(s,model,x+w-2.15,y+.61,1.9,WHITE,BLUE,14)

def label(s,t,x,y,w=4,h=.48,size=21,color=BLUE,bold=True):txt(s,t,x,y,w,h,size,color,bold)

def picture(s,path,x,y,w,h,contain=True):
    p=OUT/path
    if not p.exists():return
    im=Image.open(p); iw,ih=im.size
    if contain:
        f=min(w/iw,h/ih); ww=iw*f;hh=ih*f;x+=(w-ww)/2;y+=(h-hh)/2;w=ww;h=hh
    s.shapes.add_picture(str(p),Inches(x),Inches(y),Inches(w),Inches(h))

def base(d):
    s=prs.slides.add_slide(BLANK)
    s.background.fill.solid();s.background.fill.fore_color.rgb=WHITE
    rect(s,.32,.36,.10,7.91,BLUE,BLUE,0)
    # Public mark retained from source media.
    picture(s,'media/BMO_logo.png',14.52,.28,1.10,.51)
    title=d['title']; size=32 if len(title)<56 else 29
    txt(s,title,.77,.52,13.6,1.20,size,NAVY,True)
    txt(s,d['section'].upper(),.80,8.33,7,.30,12,MUTED,True)
    txt(s,f"{d['number']:02d} / 25",14.25,8.32,1.20,.30,12,MUTED,True,'right')
    rect(s,.78,8.14,14.6,.016,LINE,LINE,0)
    return s

def provenance(s,text):
    txt(s,text,.82,7.72,14.2,.29,11,MUTED)

def flow(s,items,y=3.45,x=.95,gap=.33,model=False):
    n=len(items);w=(14.1-(n-1)*gap)/n
    for i,item in enumerate(items):
        title,detail=item if isinstance(item,tuple) else (item,None)
        node(s,title,x+i*(w+gap),y,w,1.4,detail,size=19 if n>4 else 21)
        if i<n-1:arrow(s,x+(i+1)*w+i*gap+.05,y+.7,x+(i+1)*(w+gap)-.05,y+.7)

def draw_01(s,d):
    label(s,'A suggestion',1.05,2.15,4);label(s,'A goal pursued with tools',6.10,2.15,7)
    node(s,'Ask for a suggestion',1.05,3.07,3.6,1.25,'Question',fill=PALE)
    node(s,'Receive an answer',1.05,5.15,3.6,1.25,'Proposed code',fill=PALE)
    arrow(s,2.85,4.34,2.85,5.08)
    node(s,'Assign a goal',6.12,3.45,2.65,1.30,'Task + constraints',fill=SKY)
    node(s,'Inspect → Edit → Test',9.10,3.45,3.1,1.30,'Tool feedback loop',fill=SKY)
    node(s,'Review the result',12.55,3.45,2.55,1.30,'Human acceptance',fill=SKY)
    arrow(s,8.78,4.1,9.05,4.1);arrow(s,12.2,4.1,12.5,4.1)
    arrow(s,10.65,4.83,10.65,5.45,True,TEAL);txt(s,'feedback',10.9,5.02,2,.45,16,TEAL)
    arrow(s,10.65,5.45,9.75,5.45,True,TEAL)
    chip(s,'shipping.py',9.74,5.90,2.1)

def draw_02(s,d):
    label(s,'Model',1.25,2.16,3);flow(s,['Input','Model','Response'],3.07,1.25,.43)
    label(s,'Agent',1.25,5.15,3)
    rect(s,3.85,5.0,10.3,2.13,SKY,BLUE,.08)
    node(s,'Instructions',4.02,5.52,2.31,.93,fill=WHITE,size=16)
    node(s,'Task context',6.46,5.52,2.21,.93,fill=WHITE,size=16)
    node(s,'Model',8.80,5.52,1.42,.93,fill=WHITE,size=16)
    node(s,'Tools',10.35,5.52,1.39,.93,fill=WHITE,size=16)
    node(s,'Feedback',11.87,5.52,2.13,.93,fill=WHITE,size=16)
    for a,b in [(6.33,6.45),(8.67,8.79),(10.22,10.34),(11.74,11.86)]:arrow(s,a,5.98,b,5.98)
    chip(s,'Role instructions do not retrain the model',4.36,7.20,7.5,PALE,MUTED,16)

def draw_03(s,d):
    pts=[('Inspect','shipping.py + contract'),('Choose','next step'),('Act','edit shipping.py'),('Check: 4/6','authored partial snapshot'),('Revise','reject invalid inputs'),('Check: 6/6 PASS','authored reference')]
    pos=[(1.0,3.05),(4.0,3.05),(7.0,3.05),(10.0,3.05),(10.0,5.45),(5.50,5.45)]
    for i,((a,b),(x,y)) in enumerate(zip(pts,pos)):node(s,a,x,y,2.72 if i<4 else 3.5,1.20,b,fill=SKY if i in (0,5) else PALE,accent=GREEN if i==5 else BLUE,size=19)
    for i in range(3):arrow(s,pos[i][0]+2.72,3.65,pos[i+1][0]-.04,3.65)
    arrow(s,11.35,4.27,11.35,5.40,True,RED);txt(s,'invalid-input failures',11.57,4.66,3.3,.50,16,RED)
    arrow(s,9.96,6.05,9.05,6.05)
    node(s,'Stop + review',1.35,5.45,3.00,1.20,'Human acceptance',fill=SKY)
    arrow(s,5.45,6.05,4.4,6.05)
    arrow(s,10.40,6.70,10.40,7.08,True,TEAL)
    arrow(s,10.40,7.08,.76,7.08,True,TEAL)
    arrow(s,.76,7.08,.76,3.65,True,TEAL)
    txt(s,'feedback to next inspect',5.54,6.72,3.45,.30,14,TEAL,True)
    provenance(s,'3/6 → 4/6 → 6/6 are instructor-authored code snapshots, not agent runs.')

def draw_04(s,d):
    cols=[('One response','Prompt → proposed patch','Developer applies and checks'),('Fixed workflow','Preset: patch → test','Steps run in a set order'),('Adaptive agent','Inspect → act → check','Next step follows feedback')]
    for i,(a,b,c) in enumerate(cols):
        x=.95+i*5.0;rect(s,x,2.55,4.57,4.58,SKY if i==2 else PALE,LINE,.10)
        txt(s,a,x+.30,2.85,3.98,.70,24,BLUE,True)
        node(s,b,x+.32,4.03,3.9,1.22,fill=WHITE,size=19)
        txt(s,c,x+.40,5.75,3.8,.68,18,MUTED)
        if i==2:arrow(s,x+3.30,5.25,x+3.30,5.70,True,TEAL)
    chip(s,'Same task: shipping.py',5.88,7.32,4.10)

def draw_05(s,d):
    for x,title,sub,steps in [(1.0,'Small, clear task','Known file + narrow change',['One prompt','Inspect answer','Run checks']), (8.2,'Uncertain repository work','Several files or unknown cause',['Inspect','Edit + test','Revise if needed'])]:
        rect(s,x,2.54,6.65,4.72,PALE if x==1 else SKY,LINE,.10)
        txt(s,title,x+.35,2.84,5.95,.64,24,BLUE,True)
        txt(s,sub,x+.35,3.56,5.95,.45,17,MUTED)
        for i,a in enumerate(steps):node(s,a,x+.35+i*2.07,4.55,1.91,1.17,fill=WHITE,size=17)
        arrow(s,x+.72,6.18,x+5.95,6.18)
        txt(s,'Human reviews result',x+1.25,6.30,4.3,.45,17,NAVY,True,'center')

def draw_06(s,d):
    txt(s,'MODEL CHOICE',5.0,2.08,6,.42,16,MUTED,True,'center')
    txt(s,'One model',4.20,2.68,3,.45,20,BLUE,True,'center');txt(s,'Several models',9.0,2.68,3.5,.45,20,BLUE,True,'center')
    txt(s,'One agent',.85,3.75,2.4,.45,20,BLUE,True)
    txt(s,'Several agents',.85,5.88,2.65,.45,20,BLUE,True)
    for x,y,t,models in [(4.0,3.35,'Builder',['A']),(8.7,3.35,'Builder',['A / B']),(4.0,5.47,'Planner + Builder',['A','A']),(8.7,5.47,'Planner + Builder',['A','B'])]:
        rect(s,x,y,3.8,1.63,SKY,LINE,.10);txt(s,t,x+.18,y+.27,3.45,.47,19,NAVY,True,'center')
        chip(s,'Model '+ ' + '.join(models),x+.62,y+.95,2.6,WHITE,BLUE,15)
    provenance(s,'Agent roles and model selections are separate configuration decisions.')

def draw_07(s,d):
    node(s,'Goal',.95,4.05,2.10,1.12,'shipping.py',fill=SKY)
    node(s,'Orchestrator',3.52,4.05,2.62,1.12,'scope + integrate',fill=SKY)
    arrow(s,3.06,4.60,3.49,4.60)
    node(s,'Contract scout',6.78,2.55,2.55,1.15,'inspect code')
    node(s,'Test scout',6.78,5.32,2.55,1.15,'inspect tests')
    arrow(s,6.15,4.35,6.73,3.17);arrow(s,6.15,4.85,6.73,5.86)
    node(s,'Findings',10.05,4.05,2.28,1.12,'file evidence',fill=WHITE)
    arrow(s,9.34,3.10,10.00,4.36);arrow(s,9.34,5.85,10.00,4.90)
    node(s,'One writer',12.8,4.05,2.25,1.12,'patch + tests',fill=SKY)
    arrow(s,12.34,4.60,12.75,4.60)
    chip(s,'Human reviews after tests',10.28,6.55,4.48)

def draw_08(s,d):
    role=[('Planner','GPT-6 Astra','contract + plan'),('Search','GPT-6 Luna','locate code'),('Implement','GPT-6 Sol','one writer'),('Reviewer','GPT-6 Astra','diff + checks')]
    for i,(r,m,detail) in enumerate(role):
        x=.96+i*3.77;node(s,r,x,3.10,3.35,2.52,detail,fill=SKY if i in (0,3) else PALE,size=21)
        chip(s,m,x+.26,4.75,2.78,WHITE,BLUE,16)
        if i<3:arrow(s,x+3.35,4.35,x+3.72,4.35)
    chip(s,'Starting assignment · verify available models · evaluate results',3.15,6.45,9.75,PALE,MUTED,18)

def draw_09(s,d):
    node(s,'Static role mapping',.95,2.67,3.65,1.14,'same model each time')
    node(s,'Task router',5.03,3.87,2.70,1.27,'classify difficulty',fill=SKY)
    node(s,'Routine model',8.34,2.55,2.82,1.16,'run checks')
    node(s,'Capable model',8.34,5.24,2.82,1.16,'hard / persistent')
    node(s,'Human review',12.05,3.87,2.84,1.27,'accept patch',fill=SKY)
    arrow(s,7.75,4.18,8.3,3.13);arrow(s,7.75,4.84,8.3,5.82)
    arrow(s,11.18,3.13,12.0,4.29);arrow(s,11.18,5.82,12.0,4.75)
    arrow(s,9.75,3.80,9.75,5.18,True,RED)
    txt(s,'failed checks → bounded retry → escalate',5.39,6.55,7.70,.46,17,RED,True,'center')
    provenance(s,'Routing and escalation require explicit rules and supported orchestration.')

def draw_10(s,d):
    titles=['Sequential · dependent','Parallel · independent','Review · after patch']
    lanes=[['Inspect','Patch','Test'],['Contract','Tests','Findings'],['Patch + tests','Reviewer','Human accept']]
    for j,(title,items) in enumerate(zip(titles,lanes)):
        y=2.55+j*1.65;txt(s,title,.92,y,4.20,.47,20,BLUE,True)
        for i,item in enumerate(items):
            x=5.15+i*3.20;node(s,item,x,y-.09,2.75,1.09,fill=SKY if i==2 else PALE,size=18)
            if i<2 and j!=1:arrow(s,x+2.76,y+.45,x+3.12,y+.45)
        if j==1:
            # Independent reads merge into one findings node; no Contract→Tests edge.
            arrow(s,7.91,y+.20,7.91,y-.36)
            arrow(s,7.91,y-.36,11.48,y-.36)
            arrow(s,11.48,y-.36,11.48,y+.30)
            arrow(s,11.11,y+.63,11.51,y+.63)
    provenance(s,'Parallel investigation can shorten elapsed time while increasing total work.')

def draw_11(s,d):
    node(s,'Same fee contract',.95,4.03,2.66,1.25,'shipping.py',fill=SKY)
    node(s,'Boundary path',4.15,2.65,3.00,1.22,'9,999 vs 10,000')
    node(s,'Input path',4.15,5.29,3.00,1.22,'bool + negative')
    arrow(s,3.62,4.35,4.1,3.27);arrow(s,3.62,4.97,4.1,5.90)
    node(s,'Compare approaches',8.05,4.03,3.05,1.25,'evidence + alternatives',fill=SKY)
    arrow(s,7.17,3.29,8.0,4.35);arrow(s,7.17,5.89,8.0,4.93)
    node(s,'Run six tests',11.86,4.03,2.85,1.25,'then human accepts',fill=PALE)
    arrow(s,11.12,4.65,11.81,4.65)
    provenance(s,'Independent agreement is useful; tests and evidence decide correctness.')

def draw_12(s,d):
    fields=[('Goal','Check fee boundary'),('Context','Contract + two files'),('Constraints','Only shipping.py changes'),('Actions','Inspect, edit, test'),('Return','Diff summary + test result')]
    for i,(a,b) in enumerate(fields):
        x=1.0+(i%3)*4.72;y=2.63+(i//3)*1.79
        node(s,a,x,y,4.12,1.37,b,fill=SKY if i==4 else PALE,size=21)
    arrow(s,10.7,6.20,5.10,6.20,True,TEAL)
    txt(s,'Evidence returns to coordinator',5.3,6.39,6.2,.52,18,TEAL,True)

def draw_13(s,d):
    names=[('Plan call','instructions + contract'),('Edit call','files + history + tools'),('Verify call','result + response')]
    for i,(a,b) in enumerate(names):
        x=1.0+i*4.86;node(s,a,x,2.65,4.22,1.02,b,fill=SKY,size=21)
        for k,(lab,col) in enumerate([('Input',BLUE),('Generated',TEAL),('Reasoning*',GOLD)]):
            rect(s,x,3.96+k*.77,4.22,.61,RGBColor(230,242,251) if k==0 else PALE,col,.05)
            txt(s,lab,x+.23,4.0+k*.77,3.74,.51,18,NAVY,True)
    txt(s,'Count every call and agent',4.43,6.80,7.5,.56,22,BLUE,True,'center')
    provenance(s,'*Reasoning, when separately reported; do not double count generated output.')

def draw_14(s,d):
    labels=['Call 1','Call 2','Retry','Worker']
    widths=[2.05,3.45,1.62,2.85]
    for i,(a,w) in enumerate(zip(labels,widths)):
        y=2.60+i*1.10
        txt(s,a,1.0,y,2.3,.44,20,BLUE,True)
        rect(s,3.15,y,w,.55,SKY,BLUE,.05)
        txt(s,['first context','reused context + tool result','if needed','own context + handoff'][i],6.95,y,6.7,.48,18,MUTED)
    arrow(s,3.17,7.20,10.96,7.20)
    txt(s,'Total = sum across calls',11.02,6.89,3.4,.65,20,NAVY,True)

def draw_15(s,d):
    rect(s,.93,2.34,14.12,.87,SKY,BLUE,.08)
    txt(s,'HYPOTHETICAL DIRECT API · arbitrary units per 1k tokens',1.22,2.51,13.5,.43,20,BLUE,True)
    chip(s,'Strong: input 4 / output 20',1.0,3.45,6.45,PALE,NAVY,18)
    chip(s,'Worker: input 1 / output 5',8.35,3.45,6.42,PALE,NAVY,18)
    for y,name,tok,cost,bw in [(4.40,'Solo',1200,8,6.0),(5.76,'Mixed',1800,6,9.0)]:
        txt(s,name,1.05,y,1.6,.49,22,NAVY,True)
        rect(s,2.58,y+.04,bw,.40,BLUE if name=='Solo' else TEAL,BLUE if name=='Solo' else TEAL,.05)
        txt(s,f'{tok:,} tokens',2.58,y+.01,bw,.39,19,WHITE,True,'center')
        chip(s,f'{cost} units',12.42,y,2.35,SKY,BLUE,18)
    provenance(s,'Invented rates and outcomes for arithmetic only. Copilot bills in GitHub AI credits.')

def draw_16(s,d):
    items=[('Target files','shipping.py + tests'),('Compact handoff','goal + open issue'),('Filter output','status + failures'),('Bound retries','stop rule'),('Keep proof','command + result')]
    flow(s,items,3.60,.95,.28)
    chip(s,'py -3 -m unittest -v test_shipping',4.25,6.42,7.5,PALE,NAVY,18)

def draw_17(s,d):
    rows=[('Isolation','Worker history stays separate','Parent receives a bounded result'),('Summary','History is compressed','Keep decisions and test evidence'),('Caching','Repeated prefix computation reused','Context remains; charges may remain')]
    for i,(a,b,c) in enumerate(rows):
        y=2.45+i*1.63
        rect(s,1.00,y,13.95,1.30,SKY if i==0 else PALE,LINE,.08)
        txt(s,a,1.30,y+.33,2.8,.53,23,BLUE,True)
        txt(s,b,4.04,y+.14,5.1,.52,19,NAVY,True)
        txt(s,c,9.2,y+.14,5.30,.89,17,MUTED)

def scorecard(s,rows,cols,planned=True):
    x0=1.1;y0=2.65;cw=2.05;rw=3.75;rh=.69
    rect(s,x0,y0,rw,rh,BLUE,BLUE,0);txt(s,'Approach',x0+.18,y0+.08,rw-.3,.49,19,WHITE,True)
    for j,c in enumerate(cols):
        x=x0+rw+j*cw;rect(s,x,y0,cw,rh,BLUE,BLUE,0);txt(s,c,x+.08,y0+.08,cw-.15,.49,17,WHITE,True,'center')
    for i,r in enumerate(rows):
        y=y0+(i+1)*rh;rect(s,x0,y,rw,rh,SKY if i%2==0 else PALE,LINE,0);txt(s,r,x0+.17,y+.08,rw-.3,.49,18,NAVY,True)
        for j in range(len(cols)):
            x=x0+rw+j*cw;rect(s,x,y,cw,rh,WHITE if i%2==0 else PALE,LINE,0)
            txt(s,'—',x,y+.07,cw,.49,19,MUTED,False,'center')

def draw_18(s,d):
    chip(s,'PLANNED EXPERIMENT · same contract, starter, tests, permissions',1.10,2.06,13.80,SKY,BLUE,18)
    scorecard(s,['One-shot prompt','Single-model agent','Mixed-model team'],['Tokens','Spend','Time','Six tests','Rework'])
    provenance(s,'Fill only observed values; mark unavailable metrics unavailable. No model results shown.')

def draw_19(s,d):
    rect(s,.95,2.43,9.48,4.88,PALE,LINE,.08)
    picture(s,'media/screenshots/official-harness-role.png',1.17,2.64,9.05,4.42)
    for i,(a,b) in enumerate([('1  Workspace','Open the project'),('2  Integration','Select Copilot harness'),('3  Model picker','Check account access'),('4  Controls','Inspect delegation + permissions')]):
        node(s,a,10.80,2.48+i*1.19,4.13,1.01,b,fill=SKY,size=18)
    provenance(s,'UI image: official VS Code documentation asset; available controls vary by integration/account.')

def draw_20(s,d):
    code=d['visible']['example'].splitlines()
    rect(s,.96,2.27,10.54,5.20,RGBColor(25,39,56),RGBColor(25,39,56),.05)
    for i,line in enumerate(code):
        color=RGBColor(182,224,254) if line.startswith(('name:','description:','tools:')) else WHITE
        txt(s,line,1.26,2.40+i*.397,10.0,.40,18.3,color,False,font='Menlo')
    for i,(a,b) in enumerate([('Role','Planner'),('Model','Selected in Chat'),('Tools','read + search'),('Output','Brief plan')]):
        node(s,a,11.88,2.56+i*1.11,3.05,.95,b,fill=SKY,size=17)
    provenance(s,'Authored sample .github/agents/planner.agent.md; model availability and tools depend on harness.')

def draw_21(s,d):
    code=['.github/copilot-instructions.md','', '# Project rules','Edit only shipping.py for the fee task.','Preserve test_shipping.py unchanged.','Accept built-in int cents; reject bool.','Reject negatives and invalid types.','Run: py -3 -m unittest -v test_shipping','Return changed lines and actual test result.']
    rect(s,.98,2.39,10.38,4.81,RGBColor(25,39,56),RGBColor(25,39,56),.05)
    for i,line in enumerate(code):txt(s,line,1.25,2.56+i*.47,9.8,.45,18.5,WHITE if i>1 else RGBColor(182,224,254),False,font='Menlo')
    node(s,'Task brief',11.75,2.96,3.10,1.24,'current goal',fill=SKY,size=18)
    node(s,'Focused context',11.75,4.65,3.10,1.24,'two files',fill=SKY,size=18)
    provenance(s,'Authored shared-instruction example; durable rules and current task context are separate.')

def draw_22(s,d):
    label(s,'Subagent call: result returns',1.0,2.22,6.3)
    node(s,'Coordinator',1.17,3.15,2.63,1.20,'stays active',fill=SKY)
    node(s,'Worker',5.35,3.15,2.63,1.20,'bounded findings',fill=PALE)
    arrow(s,3.82,3.75,5.30,3.75);arrow(s,5.30,4.67,3.82,4.67,True,TEAL)
    txt(s,'evidence returns',3.83,4.84,3.2,.42,17,TEAL,True)
    label(s,'Conversation handoff: control moves',8.55,2.22,6.5)
    node(s,'Current agent',8.72,3.15,2.64,1.20,'completes stage',fill=SKY)
    node(s,'Next agent',12.05,3.15,2.64,1.20,'takes conversation',fill=PALE)
    arrow(s,11.38,3.75,12.0,3.75)
    rect(s,1.13,6.15,13.76,.88,PALE,LINE,.07)
    txt(s,'Example delegation: inspect shipping.py + tests; do not edit; return exact findings.',1.36,6.29,13.30,.54,18,NAVY)

def draw_23(s,d):
    node(s,'Reviewer',1.1,2.68,3.31,1.20,'read + search',fill=PALE)
    node(s,'Writer',1.1,5.03,3.31,1.20,'edit + execute',fill=SKY)
    node(s,'Tool permission',5.05,5.03,3.16,1.20,'approval if gated',fill=PALE)
    arrow(s,4.44,5.64,5.0,5.64)
    node(s,'shipping.py',8.80,5.03,2.77,1.20,'one writer',fill=SKY)
    arrow(s,8.23,5.64,8.75,5.64)
    node(s,'Human',12.10,3.72,2.62,1.20,'accept / redirect',fill=SKY)
    arrow(s,11.60,5.50,12.05,4.50)
    arrow(s,4.42,3.30,12.05,4.06)
    chip(s,'Two failed checks → stop and review',5.05,2.77,6.39,PALE,RED,17)
    provenance(s,'Tool access and approval are controls; file ownership and retry limits are workflow rules.')

def draw_24(s,d):
    chip(s,'PLANNED WORKFLOW · check model availability',1.0,2.13,9.0,SKY,BLUE,18)
    stages=[('Goal','Human','contract'),('Inspect','Researcher','GPT-6 Luna'),('Plan','Coordinator','GPT-6 Astra'),('Patch','Writer','GPT-6 Sol'),('Test','Writer','GPT-6 Sol'),('Review','Reviewer','GPT-6 Astra'),('Approve','Human','accept')]
    for i,(stage,role,model) in enumerate(stages):
        x=.95+i*2.12;node(s,stage,x,3.25,1.93,2.24,role,fill=SKY if i in (0,6) else PALE,size=17)
        chip(s,model,x+.12,4.57,1.68,WHITE,BLUE,13)
        if i<6:arrow(s,x+1.94,4.35,x+2.07,4.35)
    rect(s,2.34,6.27,11.34,.65,PALE,LINE,.05)
    txt(s,'shipping.py  ·  py -3 -m unittest -v test_shipping  ·  two failed checks → coordinator',2.54,6.34,10.95,.50,17,NAVY,True,'center')
    provenance(s,'Illustrative plan; no authenticated Windows Copilot execution is shown.')

def draw_25(s,d):
    chip(s,'MEASURE AFTER THE SAME TASK',1.07,2.13,8.1,SKY,BLUE,18)
    scorecard(s,['Single-agent baseline','Proposed team'],['Six tests','Total cost','Elapsed time','Human rework','Decision'])
    txt(s,'Keep extra roles only when measured outcomes justify them.',1.16,5.70,13.6,.78,23,NAVY,True,'center')
    provenance(s,'Planned scorecard. No benchmark winner, savings claim, or fabricated result.')

DISPATCH={1:draw_01,2:draw_02,3:draw_03,4:draw_04,5:draw_05,6:draw_06,7:draw_07,8:draw_08,9:draw_09,10:draw_10,11:draw_11,12:draw_12,13:draw_13,14:draw_14,15:draw_15,16:draw_16,17:draw_17,18:draw_18,19:draw_19,20:draw_20,21:draw_21,22:draw_22,23:draw_23,24:draw_24,25:draw_25}
for d in SPECS:
    s=base(d);DISPATCH[d['number']](s,d)
    clip={3:'boundary-walkthrough',20:'agent-file-walkthrough',24:'verification-walkthrough'}.get(d['number'])
    if clip:
        video=OUT/'media/videos'/f'{clip}.mp4'
        poster=OUT/'media/videos'/f'{clip}-poster.png'
        txt(s,'GUIDED CLIP',11.46,1.94,1.67,.35,12,MUTED,True,'right')
        s.shapes.add_movie(str(video),Inches(13.35),Inches(1.79),Inches(1.12),Inches(.63),
                           poster_frame_image=str(poster),mime_type='video/mp4')
        for video_node in s._element.xpath('.//p:video'):
            video_node.set('fullScrn','1')
    n=s.notes_slide.notes_text_frame
    if n is not None:
        n.text='\n\n'.join([d['speaker_notes'],'TAKEAWAY: '+d['takeaway'],'DEMO: '+d['demo_action'],'CAVEAT: '+d['caveat'],'SOURCES:\n'+'\n'.join(z['title']+' — '+z['url'] for z in d['sources'])])

deck=OUT/'BMO_Agentic_AI_VS_Code.pptx';prs.save(deck)
(OUT/'slide_content.json').write_text(json.dumps(SPECS,ensure_ascii=False,indent=2),encoding='utf-8')
print(deck)

# LibreOffice renders editable deck to matching PDF using an isolated profile.
with tempfile.TemporaryDirectory(prefix='agentic-ppt-') as temp:
    office=shutil.which('soffice') or '/Applications/LibreOffice.app/Contents/MacOS/soffice'
    if not Path(office).exists():
        candidate=Path(os.environ.get('PROGRAMFILES','C:/Program Files'))/'LibreOffice/program/soffice.exe'
        office=str(candidate) if candidate.exists() else office
    subprocess.run([office,'-env:UserInstallation='+Path(temp).as_uri(),'--headless','--convert-to','pdf','--outdir',str(OUT),str(deck)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
pdf=OUT/'BMO_Agentic_AI_VS_Code.pdf'
doc=fitz.open(pdf);assert len(doc)==25
prev=OUT/'preview';prev.mkdir(exist_ok=True)
thumbs=[]
for i,p in enumerate(doc):
    pix=p.get_pixmap(matrix=fitz.Matrix(1.45,1.45),alpha=False)
    path=prev/f'slide-{i+1:02d}.png';pix.save(path)
    im=Image.open(path).convert('RGB');im.thumbnail((520,293));thumbs.append(im.copy())
sheet=Image.new('RGB',(520*5,325*5),'#e7eef4');dd=ImageDraw.Draw(sheet)
for i,im in enumerate(thumbs):
    x=(i%5)*520;y=(i//5)*325;sheet.paste(im,(x,y));dd.text((x+9,y+296),f'{i+1:02d}  {SPECS[i]["title"][:53]}',fill='#17334c')
sheet.save(prev/'contact-sheet.png')
print(pdf)
