#!/usr/bin/env python3
"""Render captioned demos from genuine screenshots; no synthetic UI or agent output."""
from __future__ import annotations
import argparse, hashlib, json, shutil, subprocess, textwrap
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps
from v4_common import OUT, load, write_json

BLUE='#004a8c'; NAVY='#0d2646'; INK='#1d3144'; MUTED='#5c7182'
W,H=1920,1080
DURATION=5

def font(size, bold=False, mono=False):
    options = (['/System/Library/Fonts/Menlo.ttc','C:/Windows/Fonts/consola.ttf'] if mono else
        ['/System/Library/Fonts/Supplemental/Arial Bold.ttf' if bold else '/System/Library/Fonts/Supplemental/Arial.ttf',
         'C:/Windows/Fonts/arialbd.ttf' if bold else 'C:/Windows/Fonts/arial.ttf'])
    for p in options:
        if Path(p).is_file(): return ImageFont.truetype(p,size)
    try: return ImageFont.truetype('DejaVuSansMono.ttf' if mono else ('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf'),size)
    except OSError: return ImageFont.load_default(size=size)

def lines(draw,text,ft,width):
    result=[]
    for para in str(text).splitlines() or ['']:
        if not para: result.append(''); continue
        part=''
        for word in para.split(' '):
            candidate=(part+' '+word).strip()
            if draw.textlength(candidate,font=ft)>width and part:
                result.append(part);part=word
            else:part=candidate
        result.append(part)
    return result

def block(draw,text,x,y,width,ft,fill=INK,max_lines=None,spacing=8):
    seq=lines(draw,text,ft,width)
    clipped=max_lines is not None and len(seq)>max_lines
    if clipped: seq=seq[:max_lines];seq[-1]=seq[-1].rstrip()+' …'
    advance=ft.size+spacing
    for line in seq:draw.text((x,y),line,font=ft,fill=fill);y+=advance
    return y,clipped

def render(demo,step,idx,count,path):
    im=Image.new('RGB',(W,H),'#f3f7fa');dr=ImageDraw.Draw(im)
    dr.rectangle((0,0,W,152),fill='white')
    dr.rectangle((0,0,14,H),fill=BLUE)
    label=f"GUIDED DEMO  {demo['number']:02d}/25  ·  STEP {idx+1}/{count}"
    dr.text((48,24),label,font=font(19,True),fill=BLUE)
    title=demo['title'];ft=font(37,True)
    block(dr,title,48,61,1670,ft,NAVY,max_lines=2,spacing=3)
    logo=Image.open(OUT/'media/BMO_logo.png').convert('RGBA');logo.thumbnail((118,58))
    im.paste(logo,(1754,40),logo)
    # Preserve the source screenshot; annotations live outside the captured UI.
    source=Image.open(OUT/step['screenshot']).convert('RGB')
    box=(48,191,1262,902);sw=box[2]-box[0];sh=box[3]-box[1]
    dr.rounded_rectangle((46,189,1264,904),radius=14,fill='#15202c',outline='#b9cfde',width=2)
    shot=ImageOps.contain(source,(sw,sh),Image.Resampling.LANCZOS)
    im.paste(shot,(box[0]+(sw-shot.width)//2,box[1]+(sh-shot.height)//2))
    label=step.get('caption','Authentic VS Code capture · instructor-authored fixture')
    block(dr,label,49,925,1214,font(18),MUTED,max_lines=3,spacing=5)
    dr.rounded_rectangle((1300,190,1872,997),radius=16,fill='white',outline='#bed2e1',width=2)
    y,_=block(dr,step['title'],1326,216,520,font(29,True),BLUE,max_lines=3,spacing=5)
    y+=22
    y,_=block(dr,step.get('action',''),1326,y,520,font(23),INK,max_lines=5,spacing=7)
    sample=step.get('prompt') or step.get('code') or step.get('command') or ''
    if sample:
        y+=20;dr.text((1326,y),'EXACT EXAMPLE',font=font(16,True),fill=MUTED);y+=29
        # The offline step-through always exposes the complete copyable value.
        limit=max(4,min(11,int((790-y)/25)))
        y,clipped=block(dr,sample,1326,y,520,font(18,mono=True),NAVY,max_lines=limit,spacing=6)
        if clipped:
            y+=4;dr.text((1326,y),'Full text: open the in-slide demo',font=font(16),fill=MUTED);y+=26
    expected=step.get('expected','')
    if expected:
        y=max(y+24,788);dr.text((1326,y),'CHECKPOINT',font=font(17,True),fill=BLUE);y+=30
        block(dr,expected,1326,y,520,font(20),INK,max_lines=4,spacing=6)
    dr.text((48,1031),'SCREENSHOT WALKTHROUGH · authored examples; not an authenticated Copilot run',font=font(18,True),fill=MUTED)
    im.save(path,optimize=True)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--slides',nargs='+',type=int,help='Rebuild only these slide clips after a targeted change')
    args=parser.parse_args()
    _,demos=load(); dest=OUT/'media/demos';dest.mkdir(exist_ok=True)
    ffmpeg=shutil.which('ffmpeg');assert ffmpeg,'Install FFmpeg to rebuild guided clips'
    assets={}
    old=dest/'manifest.json'
    if old.is_file():assets={a['slide']:a for a in json.loads(old.read_text(encoding='utf-8')).get('clips',[])}
    for demo in demos:
        if args.slides and demo['number'] not in args.slides:continue
        folder=dest/f"slide-{demo['number']:02d}";folder.mkdir(exist_ok=True)
        frames=[]
        for i,step in enumerate(demo['steps']):
            frame=folder/f'step-{i+1:02d}.png';render(demo,step,i,len(demo['steps']),frame);frames.append(frame)
            step['frame']=str(frame.relative_to(OUT))
        cue=folder/'scenes.txt'
        cue.write_text(''.join(f"file '{p.name}'\nduration {DURATION}\n" for p in frames)+f"file '{frames[-1].name}'\n",encoding='utf-8')
        video=dest/f"slide-{demo['number']:02d}-demo.mp4"
        subprocess.run([ffmpeg,'-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(cue),'-vf','fps=12','-c:v','libx264','-preset','fast','-crf','24','-pix_fmt','yuv420p','-movflags','+faststart',str(video)],check=True)
        demo['clip']=str(video.relative_to(OUT));demo['poster']=str(frames[0].relative_to(OUT))
        transcript='\n\n'.join(f"STEP {i+1}: {s['title']}\n{s.get('action','')}\n{s.get('prompt') or s.get('code') or s.get('command') or ''}\nCHECKPOINT: {s.get('expected','')}\nSOURCE: {s['screenshot']}\n{s.get('caption','')}" for i,s in enumerate(demo['steps']))
        (dest/f"slide-{demo['number']:02d}-transcript.txt").write_text(transcript,encoding='utf-8')
        probe=json.loads(subprocess.check_output([shutil.which('ffprobe') or 'ffprobe','-v','error','-show_entries','format=duration','-of','json',str(video)],text=True))
        assets[demo['number']]={'slide':demo['number'],'path':str(video.relative_to(OUT)),'sha256':hashlib.sha256(video.read_bytes()).hexdigest(),'steps':len(frames),'step_duration_seconds':DURATION,'duration_seconds':float(probe['format']['duration']),'kind':'silent_captioned_walkthrough_of_authentic_screenshots','live_agent_execution':False}
        print(f"Demo {demo['number']:02d}: {len(frames)} screenshot steps",flush=True)
    write_json(OUT/'teaching/demo_storyboards.json',demos)
    write_json(dest/'manifest.json',{'disclosure':'Genuine VS Code screenshots with editorial captions outside the UI. Code states and prompts are instructor-authored. No authenticated Copilot execution is simulated.','clips':[assets[n] for n in sorted(assets)]})

if __name__=='__main__':main()
