#!/usr/bin/env python3
"""Create portable offline presentation, presenter guide, prompts, and handoff."""
import html, json, shutil, subprocess
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import letter

PARENTS=Path(__file__).resolve().parents
OUT=next((p for p in PARENTS if (p/'slide_specs').is_dir() and (p/'handoff/outline.json').is_file()),None)
if OUT is None:
    ROOT=next(p for p in PARENTS if (p/'deliverables_v3/slide_specs').is_dir());OUT=ROOT/'deliverables_v3'
else:ROOT=OUT.parent
SPECS=json.loads((OUT/'slide_content.json').read_text(encoding='utf-8'))
E=html.escape
clips={3:('boundary-walkthrough','Partial patch: invalid inputs still fail'),20:('agent-file-walkthrough','Custom agent file walkthrough'),24:('verification-walkthrough','Reference snapshot: six tests pass')}

def source_url(url, from_teaching=False):
    if url.startswith('deliverables_v3/'):
        url = url.removeprefix('deliverables_v3/')
        return '../' + url if from_teaching else url
    return url

css="""
:root{--blue:#004a8c;--navy:#0d2646;--pale:#e6f2fb;--ink:#1d3144;--muted:#5c7182}*{box-sizing:border-box}body{font-family:Arial,Helvetica,sans-serif;color:var(--ink);margin:0;background:#f3f7fa}a{color:var(--blue)}button{cursor:pointer;font:inherit}.top{background:white;border-bottom:1px solid #bfd1de;display:flex;align-items:center;gap:1rem;padding:.7rem 1.4rem;position:sticky;top:0;z-index:5}.top h1{font-size:1rem;color:var(--navy);margin:0;flex:1}.top a,.top button{border:1px solid #bfd1de;border-radius:6px;padding:.45rem .7rem;background:white;text-decoration:none;color:var(--blue)}main{max-width:1680px;margin:auto;padding:1rem;display:grid;grid-template-columns:minmax(0,3fr) minmax(300px,1fr);gap:1rem}.stage{background:#fff;border:1px solid #c7d8e5;border-radius:10px;padding:.7rem}.stage img{width:100%;display:block;aspect-ratio:16/9;object-fit:contain}.controls{display:flex;align-items:center;gap:.6rem;padding:.8rem .2rem .2rem}.controls button{border:0;border-radius:5px;background:var(--blue);color:white;padding:.55rem .9rem}.controls select{max-width:70%;padding:.5rem;flex:1}.panel{background:white;border:1px solid #c7d8e5;border-radius:10px;padding:1rem;max-height:calc(100vh - 100px);overflow:auto}.panel h2{font-size:1.25rem;color:var(--navy);margin:.1rem 0 .7rem}.panel h3{font-size:.9rem;color:var(--blue);text-transform:uppercase;letter-spacing:.04em;margin:1.2rem 0 .35rem}.panel p{line-height:1.42;margin:.35rem 0}.panel ul{padding-left:1.1rem;line-height:1.4}.eyebrow{font-size:.76rem;color:var(--muted);font-weight:bold;text-transform:uppercase}#clipbox{margin:.8rem 0;background:#edf5fb;padding:.7rem;border-radius:8px}#clipbox video{max-width:100%;width:100%;display:none}#clipbox button{background:var(--blue);color:white;border:0;padding:.5rem .7rem;border-radius:5px}.hint{font-size:.78rem;color:var(--muted)}@media(max-width:1000px){main{grid-template-columns:1fr}.panel{max-height:none}}@media print{.top,.controls,#clipbox{display:none}main{display:block}.panel{max-height:none;border:0}.stage{border:0}.stage img{max-height:7in}}
"""

data=[]
for d in SPECS:
    c=clips.get(d['number'])
    entry={k:d[k] for k in ('number','title','section','takeaway','speaker_notes','demo_action','caveat')}
    entry['sources']=[{**q,'url':source_url(q['url'])} for q in d['sources']]
    data.append(entry | {'clip':c})

json_data=json.dumps(data,ensure_ascii=False).replace('</','<\\/')
page=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BMO Agentic AI · offline presentation</title><style>{css}</style></head>
<body><header class="top"><h1>Agentic AI in VS Code · 25-slide presenter view</h1><a href="START_HERE.html">Start here</a><a href="teaching/presenter-guide.html">Presenter guide</a><button onclick="toggleFull()">Full screen</button></header>
<main><section class="stage"><img id="slide" alt=""><div class="controls"><button id="prev">← Previous</button><select id="jump" aria-label="Jump to slide"></select><button id="next">Next →</button></div><p class="hint">Use ← / → or Page Up / Page Down. Press F for full screen. All slides and clips work offline.</p></section><aside class="panel"><div class="eyebrow" id="section"></div><h2 id="title"></h2><p id="takeaway"></p><div id="clipbox" hidden><button id="playclip">Play guided clip</button><video id="video" controls preload="none"></video><p class="hint" id="clipnote"></p></div><h3>Presenter notes</h3><div id="notes"></div><h3>Demo action</h3><p id="demo"></p><h3>Accuracy note</h3><p id="caveat"></p><h3>Sources</h3><ul id="sources"></ul></aside></main>
<script>const slides={json_data};let index=0;const el=id=>document.getElementById(id);const sel=el('jump');slides.forEach((s,i)=>{{let o=document.createElement('option');o.value=i;o.textContent=String(i+1).padStart(2,'0')+' · '+s.title;sel.appendChild(o)}});function esc(t){{return t.replace(/[&<>]/g,c=>({{'&':'&amp;','<':'&lt;','>':'&gt;'}}[c]))}}function show(i){{index=Math.max(0,Math.min(24,i));let s=slides[index];el('slide').src='preview/slide-'+String(index+1).padStart(2,'0')+'.png';el('slide').alt='Slide '+(index+1)+': '+s.title;el('section').textContent=s.section+' · '+(index+1)+' / 25';el('title').textContent=s.title;el('takeaway').textContent=s.takeaway;el('notes').innerHTML=s.speaker_notes.split(/\\n\\n/).map(x=>'<p>'+esc(x)+'</p>').join('');el('demo').textContent=s.demo_action;el('caveat').textContent=s.caveat;el('sources').innerHTML=s.sources.map(x=>'<li><a href="'+x.url+'" target="_blank" rel="noopener">'+esc(x.title)+'</a></li>').join('');sel.value=index;let box=el('clipbox'),v=el('video');v.pause();v.style.display='none';v.removeAttribute('src');box.hidden=!s.clip;if(s.clip){{let key=s.clip[0];v.poster='media/videos/'+key+'-poster.png';v.src='media/videos/'+key+'.mp4';el('clipnote').textContent=s.clip[1]+' · instructor-authored still walkthrough, not a live agent run.';el('playclip').onclick=()=>{{v.style.display='block';v.play()}}}}location.hash='slide-'+(index+1)}}function toggleFull(){{if(document.fullscreenElement)document.exitFullscreen();else document.querySelector('.stage').requestFullscreen()}}el('prev').onclick=()=>show(index-1);el('next').onclick=()=>show(index+1);sel.onchange=()=>show(+sel.value);document.addEventListener('keydown',e=>{{if(['ArrowRight','PageDown'].includes(e.key))show(index+1);if(['ArrowLeft','PageUp'].includes(e.key))show(index-1);if(e.key.toLowerCase()==='f')toggleFull()}});show(Math.max(0,Math.min(24,(parseInt(location.hash.replace('#slide-',''))||1)-1)));</script></body></html>'''
(OUT/'Presentation.html').write_text(page,encoding='utf-8')

start='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Start here · Agentic AI in VS Code</title><style>'''+css+'''body{background:white}.wrap{max-width:1000px;margin:3rem auto;padding:0 1.4rem}h1{font-size:2.7rem;color:var(--navy)}h2{color:var(--blue);margin-top:2rem}.links{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:1rem}.links a{display:block;padding:1.1rem;border:1px solid #bfd1de;border-radius:10px;text-decoration:none;background:#f2f8fc;font-weight:bold}.links span{display:block;margin-top:.3rem;color:var(--muted);font-weight:normal}p,li{line-height:1.5}</style></head><body><div class="wrap"><img src="media/BMO_logo.png" alt="BMO" width="120"><h1>Agentic AI in VS Code</h1><p>A 25-slide instructor pack with an editable PowerPoint, matching PDF, offline presenter view, teaching notes, copy-ready prompts, and a six-test Python lab.</p><div class="links"><a href="Presentation.html">Open offline presentation<span>Keyboard navigation, presenter notes, and guided clips</span></a><a href="BMO_Agentic_AI_VS_Code.pptx">Download PowerPoint<span>Editable diagrams and presenter notes</span></a><a href="BMO_Agentic_AI_VS_Code.pdf">Open PDF<span>25 matching pages</span></a><a href="teaching/presenter-guide.html">Presenter guide<span>Slide notes, evidence, and demo cues</span></a><a href="teaching/copyable-prompts.html">Copyable prompts<span>Ready for the shared shipping.py exercise</span></a><a href="demo/student_starter.zip">Student starter ZIP<span>No reference answer included</span></a></div><h2>Teaching boundary</h2><p>The three lab code states are instructor-authored snapshots: starter 3/6, partial patch 4/6, reference 6/6. They are not model results. Existing local screenshots show macOS VS Code with the Local harness; official documentation images are separately attributed. The guided clips show still walkthroughs. Windows Copilot behavior, model access, permissions, billing, and delegation should be checked in the actual session.</p><h2>Run the student lab</h2><ol><li>Extract the starter ZIP and open its folder in VS Code.</li><li>Run <code>py -3 -m unittest -v test_shipping</code> on Windows with Python 3.10+.</li><li>Use the plan, implement, and review prompts. Edit only <code>shipping.py</code>; leave the six tests fixed.</li><li>Inspect the diff and rerun the checks before accepting a result.</li></ol><p><a href="README.md">Package inventory and provenance</a> · <a href="media/index.html">Media index</a></p></div></body></html>'''
(OUT/'START_HERE.html').write_text(start,encoding='utf-8')

prompts=(OUT/'demo/starter/PROMPTS.md').read_text(encoding='utf-8')
(OUT/'teaching/copyable-prompts.md').write_text(prompts,encoding='utf-8')
pre=E(prompts)
(OUT/'teaching/copyable-prompts.html').write_text(f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Copyable prompts</title><style>{css}body{{background:white}}main{{display:block;max-width:950px;margin:auto}}pre{{white-space:pre-wrap;background:#f2f8fc;padding:1.4rem;border-radius:10px;line-height:1.45;font:1rem/1.45 ui-monospace,monospace}}button{{padding:.55rem .8rem;border:0;border-radius:5px;background:#004a8c;color:white}}</style></head><body><main><p><a href="../START_HERE.html">← Start here</a></p><h1>Copyable VS Code prompts</h1><button onclick="navigator.clipboard.writeText(document.querySelector('pre').innerText)">Copy all prompts</button><pre>{pre}</pre></main></body></html>''',encoding='utf-8')

guide=['<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Presenter guide</title><style>',css,'body{background:white}.guide{max-width:1050px;margin:2rem auto;padding:1rem}.chapter{break-before:page;border-top:3px solid #004a8c;padding-top:1rem;margin-top:2rem}h1,h2{color:#0d2646}.chapter img{width:100%;max-width:690px;display:block;border:1px solid #cbdbe7}.chapter p{line-height:1.5}.refs{font-size:.9rem}</style></head><body><div class="guide"><p><a href="../START_HERE.html">← Start here</a></p><h1>Presenter guide · Agentic AI in VS Code</h1><p>25 slides in the supplied sequence. Each section below carries its authored note, live demonstration cue, caveat, and sources. Images are the rendered slides. The PowerPoint has the same notes embedded.</p><p><strong>Lab contract:</strong> Only shipping.py changes. delivery_fee accepts built-in integer cents, excluding bool; returns 500 below 10000 and 0 at or above; rejects negative and other inputs with ValueError. Windows: <code>py -3 -m unittest -v test_shipping</code>. The six fixed checks and permissions stay the same for comparison.</p>']
for d in SPECS:
    n=d['number'];guide.append(f'<section class="chapter"><p class="eyebrow">{E(d["section"])} · {n:02d} / 25</p><h2>{E(d["title"])}</h2><img src="../preview/slide-{n:02d}.png" alt="Slide {n}"><p><strong>Takeaway:</strong> {E(d["takeaway"])}</p>')
    for para in d['speaker_notes'].split('\n\n'):guide.append('<p>'+E(para)+'</p>')
    guide.append('<p><strong>Demo action:</strong> '+E(d['demo_action'])+'</p><p><strong>Accuracy note:</strong> '+E(d['caveat'])+'</p><h3>Sources</h3><ul class="refs">')
    for q in d['sources']:guide.append(f'<li><a href="{E(source_url(q["url"],from_teaching=True))}">{E(q["title"])}</a> — {E(q["supports"])}</li>')
    guide.append('</ul></section>')
guide.append('<p><a href="copyable-prompts.html">Copyable prompts</a></p></div></body></html>')
(OUT/'teaching/presenter-guide.html').write_text(''.join(guide),encoding='utf-8')

# A printable guide with selectable text, links, and one slide per section.
styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='DeckTitle',parent=styles['Title'],textColor=colors.HexColor('#0d2646'),fontSize=19,leading=23,spaceAfter=14))
styles.add(ParagraphStyle(name='DeckH',parent=styles['Heading1'],textColor=colors.HexColor('#004a8c'),fontSize=15,leading=18,spaceAfter=10))
styles.add(ParagraphStyle(name='DeckBody',parent=styles['BodyText'],fontSize=9.5,leading=13,spaceAfter=8))
styles.add(ParagraphStyle(name='DeckSmall',parent=styles['BodyText'],fontSize=8.3,leading=11,spaceAfter=5))
story=[Paragraph('Presenter guide: Agentic AI in VS Code',styles['DeckTitle']),Paragraph('25-slide instructor companion · authored snapshots, not live model results',styles['DeckBody'])]
for i,d in enumerate(SPECS):
    if i:story.append(PageBreak())
    story.append(Paragraph(f'{d["number"]:02d} / 25 · '+E(d['title']),styles['DeckH']))
    story.append(Paragraph('<b>Takeaway:</b> '+E(d['takeaway']),styles['DeckBody']))
    for para in d['speaker_notes'].split('\n\n'):story.append(Paragraph(E(para).replace('\n','<br/>'),styles['DeckBody']))
    story.append(Paragraph('<b>Demo:</b> '+E(d['demo_action']),styles['DeckBody']))
    story.append(Paragraph('<b>Caveat:</b> '+E(d['caveat']),styles['DeckBody']))
    story.append(Paragraph('<b>Sources</b>',styles['DeckSmall']))
    for q in d['sources']:story.append(Paragraph(E(q['title'])+' — '+E(source_url(q['url'])),styles['DeckSmall']))
SimpleDocTemplate(str(OUT/'teaching/presenter-guide.pdf'),pagesize=letter,rightMargin=46,leftMargin=46,topMargin=45,bottomMargin=46).build(story)

readme='''# Agentic AI in VS Code — training pack

Open `START_HERE.html` for the package index. `Presentation.html` is the offline 25-slide presenter view; arrow keys and Page Up/Down navigate. Guided clips are instructor-authored still walkthroughs. The PowerPoint is editable and carries full notes; the PDF matches its 25 slides.

## Contents

- `BMO_Agentic_AI_VS_Code.pptx` and `.pdf` — exact authorized slide order.
- `preview/slide-01.png` … `slide-25.png`, `contact-sheet.png` — rendered views.
- `slide_content.json`, `slide_specs/`, `handoff/` — authored content, references, source, and rebuild steps.
- `teaching/presenter-guide.html` and `.pdf`, `copyable-prompts.html` and `.md`.
- `demo/student_starter.zip` — student files, fixed tests, and optional VS Code agent profiles; no answer.
- `demo/instructor_reference.zip` — authored snapshots and actual local test records.
- `media/` — original screenshots, crops, posters, transcripts, and MP4s with `manifest.json` provenance.

## Evidence boundaries

Starter 3/6, partial patch 4/6, and reference 6/6 are instructor-authored snapshots, not AI performance. No authenticated Windows Copilot run, live delegated model switch, measured billing, or benchmark winner is claimed. Local screenshots were captured on macOS in the Local harness; official VS Code reference assets are labelled separately. Actual supported models, tools, permissions, and billing vary by account and integration.

## Rebuild

See `handoff/REBUILD.md`. The deck is generated from all 25 `slide_specs/slide_NN.json` files, preserving exact titles/order from `handoff/outline.json`.
'''
(OUT/'README.md').write_text(readme,encoding='utf-8')
(OUT/'handoff/REBUILD.md').write_text('''# Rebuild and provenance

Extract the training ZIP, open a terminal in the extracted folder, install Python 3.11+ and LibreOffice, then run:

```sh
python -m pip install -r handoff/requirements.txt
python handoff/rebuild_deck.py
python handoff/rebuild_training.py
python handoff/package_pack.py
```

The deck script finds LibreOffice on PATH, in the standard macOS application path, or under Windows Program Files. Add `soffice` to PATH if it is installed elsewhere. It uses an isolated LibreOffice profile to convert the editable PowerPoint into the matching PDF, then PyMuPDF renders previews. Aptos and Menlo are preferred fonts; if absent, PowerPoint/LibreOffice substitutes installed sans-serif and monospace fonts. Reinspect line wraps after rebuilding on another system.

All diagrams and code panels are editable PowerPoint shapes/text. Existing VS Code screenshots and the public logo are embedded assets with provenance in `media/manifest.json`. Rebuild uses all 25 `slide_specs/` files and the exact title sequence in `handoff/outline.json`; review reports in `reviews/` document factual and media checks. The HTML presentation and guide use local relative paths and work without network access; external source links require a connection only when opened. Authored demo snapshots and local six-test records are in `demo/`.
''',encoding='utf-8')
(OUT/'handoff/requirements.txt').write_text('python-pptx>=1.0\nPillow>=10\nPyMuPDF>=1.24\nreportlab>=4\n',encoding='utf-8')
for src,dst in [((ROOT/'scripts/build_structured_v3.py'),OUT/'handoff/rebuild_deck.py'),((ROOT/'scripts/build_training_v3.py'),OUT/'handoff/rebuild_training.py')]:
    if src.is_file() and src.resolve()!=dst.resolve():shutil.copy2(src,dst)
src=ROOT/'scripts/package_v3.py';dst=OUT/'handoff/package_pack.py'
if src.is_file() and src.resolve()!=dst.resolve():shutil.copy2(src,dst)
subprocess.run([__import__('sys').executable,str(OUT/'demo/package.py')],check=True)
print('Built offline presentation, guide, prompts, and demo ZIPs')
