# Rebuild and evidence handoff

## Open the finished pack

Extract the ZIP, then open `START_HERE.html` in a modern browser. `Presentation.html` works from `file://` without a server. It contains the 25-slide presenter view, an in-slide step-through on every slide, copyable prompts and code, image zoom, notes, and links to the silent captioned clips. The PowerPoint embeds a clip on each slide; the PDF is a static 25-page export. `teaching/demo-workbook.html` and `teaching/BMO_Agentic_AI_Demo_Workbook.pdf` preserve the full steps in readable form. Playback support in PowerPoint varies by installed version, so use the offline HTML when presenting from an unfamiliar machine.

## Requirements for a rebuild

- Python 3.11 or newer and the packages in `handoff/requirements.txt`.
- FFmpeg on `PATH` to regenerate the 25 MP4 walkthroughs. The finished pack opens and plays without FFmpeg.
- LibreOffice with `soffice` on `PATH`, in `/Applications/LibreOffice.app`, or in the default Windows `Program Files` location to regenerate the slide PDF. The finished pack opens without LibreOffice.
- A browser to view local HTML. No Playwright, browser automation, network service, account, or API key is needed to open the pack or rebuild it from the supplied screenshots.

Run these commands from the extracted pack root:

```sh
python -m pip install -r handoff/requirements.txt
python handoff/rebuild_demo_media.py
python handoff/rebuild_deck.py
python handoff/rebuild_training.py
python handoff/package_pack.py
```

On Windows, use `py -3` in place of `python` if that is your installed launcher. Run the commands in this order: the deck embeds the clips made by the media script, and the HTML builder copies all rebuild scripts into `handoff/`. The package script refuses to archive an incomplete workshop. To check readiness without writing a ZIP, run `python handoff/package_pack.py --validate-only`.

## Editable source and provenance

The pack includes all 25 `slide_specs/slide_NN.json` files, `handoff/outline.json`, `slide_content.json`, `teaching/demo_walkthroughs.json`, and the final `teaching/demo_storyboards.json`. `handoff/rebuild_*.py` and `handoff/v4_common.py` are the source builders. `media/` contains original screenshots, crops, all 115 guided frames, videos, transcripts, posters, and manifests. The separate PowerPoint render posters in `media/slide-posters/` are already embedded in the PPTX and omitted from the ZIP; `rebuild_deck.py` recreates them from the retained hero screenshots. `reviews/V4_REVIEW_MANIFEST.json` records the final verification. `handoff/ASTRA_DEMO_PLAN.txt` and `.json` retain the implementation-aligned expansion plan. The deck is generated from the 25 slide specs in exact outline order.

The delivery-fee starter, partial patch, and reference are **instructor-authored**. The local six-test runs recorded for them are genuine: 3/6, 4/6, and 6/6 respectively. They are teaching states, not runs by an AI model. The VS Code screenshots were captured on macOS; the clips assemble those screenshots with captions outside the UI. Official VS Code reference images have separate source labels. No authenticated Windows Copilot run, model switch, native delegation, live tool approval, token bill, or measured comparison is represented by these assets.

`demo/student_starter.zip` contains the broken starter, fixed tests, prompts, and optional agent files; it contains no completed `shipping.py` answer. Keep `demo/instructor_reference.zip` and the unpacked `demo/verified/` folder for instructors. The student lab itself requires Python's standard library only.

## Capture the remaining Windows Copilot evidence

Open `handoff/WINDOWS_COPILOT_CAPTURE.html` for the exact capture procedure and evidence checklist. Use a fresh extracted student starter on a signed-in Windows VS Code installation. Record the integration, selected model and tools, approval prompts, actual chat actions, diff, command output, timing, and usage fields that the tenant exposes. Leave unavailable billing or token values blank. Preserve raw screenshots and transcript exports separately, then add links and hashes to a new review record. Do not overwrite the supplied macOS capture provenance or relabel authored examples as Copilot output.

Fonts and layout can change across machines. Aptos and a monospace fallback are preferred; inspect `preview/contact-sheet.png` and all slides after regenerating the PDF. External documentation links require internet only when clicked.
