# Rebuild and provenance

Extract the training ZIP, open a terminal in the extracted folder, install Python 3.11+ and LibreOffice, then run:

```sh
python -m pip install -r handoff/requirements.txt
python handoff/rebuild_deck.py
python handoff/rebuild_training.py
python handoff/package_pack.py
```

The deck script finds LibreOffice on PATH, in the standard macOS application path, or under Windows Program Files. Add `soffice` to PATH if it is installed elsewhere. It uses an isolated LibreOffice profile to convert the editable PowerPoint into the matching PDF, then PyMuPDF renders previews. Aptos and Menlo are preferred fonts; if absent, PowerPoint/LibreOffice substitutes installed sans-serif and monospace fonts. Reinspect line wraps after rebuilding on another system.

All diagrams and code panels are editable PowerPoint shapes/text. Existing VS Code screenshots and the public logo are embedded assets with provenance in `media/manifest.json`. Rebuild uses all 25 `slide_specs/` files and the exact title sequence in `handoff/outline.json`; review reports in `reviews/` document factual and media checks. The HTML presentation and guide use local relative paths and work without network access; external source links require a connection only when opened. Authored demo snapshots and local six-test records are in `demo/`.
