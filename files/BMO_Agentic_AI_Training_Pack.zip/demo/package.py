"""Build student and instructor ZIPs with an explicit allowlist of lab files."""

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


ROOT = Path(__file__).resolve().parent
STARTER_FILES = [
    "shipping.py",
    "test_shipping.py",
    "README.md",
    "PROMPTS.md",
    ".github/agents/planner.agent.md",
    ".github/agents/builder.agent.md",
    ".github/agents/skeptic.agent.md",
    ".github/copilot-instructions.md",
]
REFERENCE_FILES = [
    "README.md",
    "run_checks.py",
    "results.json",
    "starter/shipping.py",
    "starter/test_shipping.py",
    "starter/README.md",
    "starter/PROMPTS.md",
    "starter/.github/agents/planner.agent.md",
    "starter/.github/agents/builder.agent.md",
    "starter/.github/agents/skeptic.agent.md",
    "starter/.github/copilot-instructions.md",
    "prompt_patch/shipping.py",
    "prompt_patch/test_shipping.py",
    "verified/shipping.py",
    "verified/test_shipping.py",
]


def build(archive_name, names, prefix=""):
    with ZipFile(ROOT / archive_name, "w", ZIP_DEFLATED) as archive:
        for name in names:
            source = ROOT / prefix / name
            if not source.is_file():
                raise FileNotFoundError(source)
            archive.write(source, name)


if __name__ == "__main__":
    build("student_starter.zip", STARTER_FILES, "starter")
    build("instructor_reference.zip", REFERENCE_FILES)
    print("Built student_starter.zip and instructor_reference.zip")
