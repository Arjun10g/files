"""Build student and instructor ZIPs with an explicit allowlist of lab files."""

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


ROOT = Path(__file__).resolve().parent
STARTER_FILES = [
    "shipping.py",
    "test_shipping.py",
    "README.md",
    "PROMPTS.md",
    "teaching_examples/token_cost.py",
    ".github/agents/code-scout.agent.md",
    ".github/agents/test-scout.agent.md",
    ".github/agents/shipping-planner.agent.md",
    ".github/agents/shipping-writer.agent.md",
    ".github/agents/independent-reviewer.agent.md",
    ".github/prompts/fix-shipping.prompt.md",
    ".github/prompts/parallel-scouts.prompt.md",
    ".github/copilot-instructions.md",
]
REFERENCE_FILES = [
    "README.md",
    "run_checks.py",
    "results.json",
    "starter/shipping.py",
    "starter/test_shipping.py",
    "starter/README.md",
    "starter/PROMPTS.md",
    "starter/teaching_examples/token_cost.py",
    "starter/.github/agents/code-scout.agent.md",
    "starter/.github/agents/test-scout.agent.md",
    "starter/.github/agents/shipping-planner.agent.md",
    "starter/.github/agents/shipping-writer.agent.md",
    "starter/.github/agents/independent-reviewer.agent.md",
    "starter/.github/prompts/fix-shipping.prompt.md",
    "starter/.github/prompts/parallel-scouts.prompt.md",
    "starter/.github/copilot-instructions.md",
    "prompt_patch/shipping.py",
    "prompt_patch/test_shipping.py",
    "verified/shipping.py",
    "verified/test_shipping.py",
]


def build(archive_name, names, prefix=""):
    with ZipFile(ROOT / archive_name, "w", ZIP_DEFLATED) as archive:
        for name in names:
            source = ROOT / prefix / name
            if not source.is_file():
                raise FileNotFoundError(source)
            archive.write(source, name)


if __name__ == "__main__":
    build("student_starter.zip", STARTER_FILES, "starter")
    build("instructor_reference.zip", REFERENCE_FILES)
    print("Built student_starter.zip and instructor_reference.zip")
