"""Run the same six unittest cases in each frozen demo version."""

import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
VERSIONS = ("starter", "prompt_patch", "verified")
CASE = re.compile(r"^(test_\w+) \([^)]+\) \.\.\. (ok|FAIL|ERROR)$", re.MULTILINE)


def main():
    report = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version.split()[0],
        "command": "python -m unittest -v test_shipping",
        "note": "These are real local unittest runs. prompt_patch is instructor-authored, not an AI output.",
        "versions": {},
    }
    for version in VERSIONS:
        process = subprocess.run(
            [sys.executable, "-m", "unittest", "-v", "test_shipping"],
            cwd=ROOT / version,
            text=True,
            capture_output=True,
            check=False,
        )
        observed = {name: status for name, status in CASE.findall(process.stderr)}
        if len(observed) != 6:
            raise RuntimeError(f"Expected six test lines for {version}; got {observed!r}\n{process.stderr}")
        report["versions"][version] = {
            "passed_count": sum(status == "ok" for status in observed.values()),
            "failed_count": sum(status == "FAIL" for status in observed.values()),
            "error_count": sum(status == "ERROR" for status in observed.values()),
            "exit_code": process.returncode,
            "tests": dict(sorted(observed.items())),
        }
    (ROOT / "results.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    for version, result in report["versions"].items():
        print(f"{version}: {result['passed_count']}/6 passed, {result['failed_count']} failed, {result['error_count']} errors")
    if report["versions"]["verified"]["passed_count"] != 6:
        raise SystemExit("Verified version did not pass all six tests")


if __name__ == "__main__":
    main()
