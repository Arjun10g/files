# Copy-ready Copilot prompts

Use one block at a time in a VS Code chat opened on this starter folder. Ask the agent to show its evidence. A response is a proposal until you inspect the edit and rerun the tests.

## PLAN — select Planner or use regular chat

```text
Read README.md, shipping.py, and test_shipping.py. Plan the smallest change to make delivery_fee(total_cents) satisfy the contract: 500 cents below 10000 cents, zero at 10000 or above, ValueError for negative or non-integer input including bool. Do not edit files. List which of the six tests currently fail and why; if you have not run them, say this is a prediction.
```

## IMPLEMENT — select Builder or use regular agent chat

```text
Edit only shipping.py so delivery_fee(total_cents) returns an integer 500 when 0 <= total_cents < 10000 and integer 0 when total_cents >= 10000. Raise ValueError for negative totals and every non-integer input, including bool. Do not edit the tests. On Windows, run py -3 -m unittest -v test_shipping. Report the actual six-test result and the lines changed.
```

## REVIEW — select Skeptic or use regular chat

```text
Review README.md, shipping.py, and test_shipping.py against the delivery fee contract. Look for a concrete input that still breaks the contract, especially the exact 10000-cent boundary, negative values, float, string, and bool. Give the input, expected behavior, behavior supported by the code, and the responsible line. Do not edit files. Do not say tests passed unless you saw a test run.
```

## NATIVE PARALLEL — optional, if your VS Code agent supports subagents

```text
For this small shipping.py task, ask two independent read-only subagents to review in parallel: one checks the 10000-cent boundary and money units; the other checks negative and non-integer inputs. Have each return a concrete failing example or say none found. Summarize their findings without editing files. If this chat cannot delegate subagents, say so and perform the two reviews sequentially.
```

Parallel subagents may shorten elapsed time for independent work, but they make their own model requests. Compare actual work and results rather than assuming a cost saving. [VS Code subagents documentation](https://code.visualstudio.com/docs/agents/run/subagents).
