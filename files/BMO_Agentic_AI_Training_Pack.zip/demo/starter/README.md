# Delivery fee lab

The store charges a **$5.00 delivery fee** when the cart total is **below $100.00**. Delivery is **free at $100.00 and above**. `delivery_fee(total_cents)` accepts a cart total in integer cents and returns the fee in integer cents. It raises `ValueError` for a negative total or any non-integer input, including `bool`.

## Run on Windows

1. Unzip `student_starter.zip` into a new folder and open that folder in VS Code.
2. Install Python 3.10 or newer if needed. In the VS Code terminal, check `py --version`. If `py` is unavailable, try `python --version`.
3. Run `py -3 -m unittest -v test_shipping` (or `python -m unittest -v test_shipping`). No packages need installation.
4. The starter is supposed to fail three of the six checks. Use the prompts in `PROMPTS.md` and inspect every proposed edit.

The six checks cover $99.99, exactly $100.00, $100.01, a negative total, wrong input types, and the integer return type. Run the same command after every change. A passing test suite is evidence for these six cases; it is not proof about every possible input.

The custom agents in `.github/agents/` are optional. Code Scout and Test Scout are read-only inspectors; Shipping Planner plans; Shipping Writer edits and tests; Independent Reviewer inspects the result. In VS Code Chat, select the intended harness and then an agent by name. The plain prompts in `PROMPTS.md` also work in regular agent chat. Agent features, model choices, and approvals vary by setup; check the selected agent, tools, and proposed changes before accepting them. The `.github/prompts/*.prompt.md` files and handoffs are for the VS Code Local harness.

Agent profile format and tool aliases: [VS Code custom agents](https://code.visualstudio.com/docs/agent-customization/custom-agents) and [GitHub custom agent configuration](https://docs.github.com/en/copilot/reference/custom-agents-configuration).
