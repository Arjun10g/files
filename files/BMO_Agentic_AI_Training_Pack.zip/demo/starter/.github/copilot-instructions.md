# Shipping demo project instructions

- This workspace has one production function, `shipping.delivery_fee(total_cents)`, and six fixed acceptance tests in `test_shipping.py`.
- Amounts are integer cents. An order total below 10000 cents has a 500-cent fee; a total at or above 10000 cents has a zero-cent fee.
- Reject a negative total and every value whose built-in type is not `int`, including `bool`, with `ValueError`. Return a built-in `int`.
- Change only `shipping.py` for the implementation exercise. Keep `test_shipping.py` fixed so the six results remain comparable.
- On Windows, validate from this folder with `py -3 -m unittest -v test_shipping`. On macOS or Linux, use `python3 -m unittest -v test_shipping`.
- Report observed test output separately from predictions. The starter, prompt-patch, and verified folders are instructor-authored snapshots; do not describe them as model runs.
