# Delivery fee demo project
- Python 3.10+; integer cents, built-in int only (exclude bool).
- delivery_fee: below 10000 -> 500; at or above 10000 -> 0.
- Negative or non-integer inputs raise ValueError.
- Change only shipping.py; keep test_shipping.py unchanged.
- Validate: python -m unittest -v test_shipping (Windows: py -3 ...).
- Report actual commands and results. Keep the final diff small.
