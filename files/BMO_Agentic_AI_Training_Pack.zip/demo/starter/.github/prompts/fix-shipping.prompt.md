---
name: fix-shipping
description: Run the bounded shipping implementation exercise in a Local VS Code session
agent: Shipping Writer
---
Read README.md, shipping.py, and test_shipping.py. Edit only shipping.py to satisfy every contract case: 500 integer cents below 10000, zero integer cents at or above 10000, and ValueError for negative or any non-built-in-int input including bool. Run the six unittest cases. Report the command, observed result, changed lines, and remaining uncertainty.
