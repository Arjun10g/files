---
name: parallel-scouts
description: Delegate two bounded read-only inspections in a Local VS Code session
tools: ['read', 'search', 'agent']
---
Use the Code Scout and Test Scout custom agents as separate subagents for this shipping task. Give each the relevant files and require a concise evidence handoff. Code Scout inspects the current implementation and 10000-cent boundary; Test Scout maps all six tests and input types. Neither may edit files. Combine their returned findings, identify disagreements, and mark any unexecuted claim as a prediction. If Run Subagent is unavailable, state that and inspect the two concerns sequentially.
