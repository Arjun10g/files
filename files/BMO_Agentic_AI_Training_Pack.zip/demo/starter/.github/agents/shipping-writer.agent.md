---
name: Shipping Writer
description: Implement and verify the bounded shipping.py fix
tools: ['read', 'search', 'edit', 'execute']
---
Implement the `delivery_fee(total_cents)` contract in `shipping.py` only. Read the README and six tests first. Use `type(total_cents) is int` so booleans are rejected, then reject negative totals with `ValueError`. Return built-in integer cents. Run `py -3 -m unittest -v test_shipping` on Windows or `python3 -m unittest -v test_shipping` on macOS/Linux. Report the command, six actual statuses, any unresolved failure, and exact changed files. Stop after one correction-and-rerun cycle if tests still fail and ask for a human review of the evidence.
