"""Hypothetical API arithmetic, not measured Copilot usage or prices."""

# Arbitrary units per 1,000 tokens. Input and output have different rates.
RATES = {"strong": (4, 20), "worker": (1, 5)}
ROUTES = {
    "Solo": [("strong", 1000, 200)],
    "Mixed": [("strong", 500, 100), ("worker", 1000, 200)],
}

print("HYPOTHETICAL API EXAMPLE — not measured usage or Copilot pricing")
for route, calls in ROUTES.items():
    tokens = sum(input_t + output_t for _, input_t, output_t in calls)
    cost = sum(
        (input_t * RATES[model][0] + output_t * RATES[model][1]) / 1000
        for model, input_t, output_t in calls
    )
    print(f"{route:5} | {tokens:4} tokens | {cost:g} arbitrary units")

print("More tokens can cost less; equal quality is NOT established here.")
print("Copilot billing: check the account's actual GitHub AI-credit report.")
