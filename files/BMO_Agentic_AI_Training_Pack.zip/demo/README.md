# Instructor reference: delivery fee demo

This package has three **authored snapshots** for a beginner Copilot agent lesson. They show how acceptance checks expose a tempting partial fix. No snapshot is represented as output from a live Copilot run.

| Folder | Purpose | Expected six-test result |
| --- | --- | --- |
| `starter/` | Student starting point: `>` boundary bug; missing validation | 3 pass, 3 fail |
| `prompt_patch/` | Instructor-authored one-line `>=` patch; missing validation | 4 pass, 2 fail |
| `verified/` | Complete contract implementation | 6 pass |

The only source changes across snapshots are in `shipping.py`. Every folder uses the exact same `test_shipping.py`. Run `python run_checks.py` from this folder to regenerate `results.json` from actual `unittest` runs. On Windows use `py run_checks.py` if `python` is not available. Python 3.10+ and the standard library are sufficient.

The `student_starter.zip` archive contains only the starter folder contents. Open that extracted folder as the VS Code workspace. The `instructor_reference.zip` archive contains all three snapshots, `run_checks.py`, and `results.json`; keep it away from students until after the exercise.

For a clean live run, extract a fresh `student_starter.zip`. Run the tests, ask the single IMPLEMENT prompt in `PROMPTS.md`, inspect the diff, and run tests again. Agent behavior varies; use the authored snapshots only as fixed teaching references, never as purported transcript or measured agent output.
