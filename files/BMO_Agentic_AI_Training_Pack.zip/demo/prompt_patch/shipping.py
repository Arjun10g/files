"""Delivery fee in integer cents."""


def delivery_fee(total_cents: int) -> int:
    """Return 500 cents below $100, otherwise zero cents."""
    return 0 if total_cents >= 10000 else 500
