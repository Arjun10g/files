"""Six acceptance checks shared by all three versions of the demo."""

import unittest

from shipping import delivery_fee


class DeliveryFeeTests(unittest.TestCase):
    def test_below_threshold(self):
        self.assertEqual(delivery_fee(0), 500)
        self.assertEqual(delivery_fee(9999), 500)

    def test_exact_threshold(self):
        self.assertEqual(delivery_fee(10000), 0)

    def test_above_threshold(self):
        self.assertEqual(delivery_fee(10001), 0)

    def test_negative_rejected(self):
        with self.assertRaises(ValueError):
            delivery_fee(-1)

    def test_wrong_types_rejected(self):
        problems = []
        for value in (100.5, 10000.0, "10000", True, False, None):
            try:
                delivery_fee(value)
            except ValueError:
                continue
            except Exception as error:
                problems.append(f"{value!r}: raised {type(error).__name__}")
            else:
                problems.append(f"{value!r}: no ValueError")
        self.assertEqual(problems, [])

    def test_return_type_is_int(self):
        self.assertIs(type(delivery_fee(9999)), int)


if __name__ == "__main__":
    unittest.main()
