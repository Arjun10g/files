"""Validated delivery fee in integer cents."""


def delivery_fee(total_cents: int) -> int:
    """Return 500 cents below $100, otherwise zero cents.

    Reject booleans, non-integers, and negative totals with ValueError.
    """
    if type(total_cents) is not int or total_cents < 0:
        raise ValueError("total_cents must be a non-negative integer")
    return 0 if total_cents >= 10000 else 500
