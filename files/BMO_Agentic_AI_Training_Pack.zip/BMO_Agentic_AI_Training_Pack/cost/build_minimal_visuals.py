"""Two low-text visuals for a beginner presentation."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
data = json.loads((HERE / "cost_model.json").read_text(encoding="utf-8"))
workflows = data["workflows"]
names = ["Prompt", "Sequential", "Parallel", "Adversarial"]
totals = [w["total_tokens"] / 1000 for w in workflows]
checks = [w["validation_lenses_scheduled"] for w in workflows]
inputs = [w["input_tokens"] / 1000 for w in workflows]
outputs = [w["output_tokens"] / 1000 for w in workflows]

BMO_BLUE = "#0075BE"
BMO_INK = "#003B71"
SOFT_BLUE = "#61B5E5"
GRID = "#DCE7F0"
PAPER = "#FFFFFF"
MUTED = "#566B80"

plt.rcParams.update({"font.family": "DejaVu Sans", "svg.fonttype": "none"})


def save(fig: plt.Figure, stem: str) -> None:
    fig.savefig(HERE / f"{stem}.png", dpi=180, facecolor=PAPER)
    fig.savefig(HERE / f"{stem}.svg", facecolor=PAPER)
    plt.close(fig)


# 1. Minimal Pareto-style design trade-off.
fig = plt.figure(figsize=(16, 9), facecolor=PAPER)
ax = fig.add_axes([0.13, 0.20, 0.77, 0.60], facecolor=PAPER)
ax.set_xlim(0, 25)
ax.set_ylim(-0.35, 4.55)
ax.set_xticks([0, 5, 10, 15, 20, 25])
ax.set_yticks([0, 2, 3, 4])
ax.grid(color=GRID, linewidth=1.4, zorder=0)
for spine in ax.spines.values():
    spine.set_visible(False)
ax.tick_params(axis="both", length=0, labelsize=16, colors=MUTED, pad=10)
ax.set_xlabel("Token budget (k)", fontsize=18, color=BMO_INK, labelpad=16)
ax.set_ylabel("Scheduled checks", fontsize=18, color=BMO_INK, labelpad=16)
ax.plot(totals, checks, color="#91B4D0", linewidth=3.5, linestyle=(0, (5, 4)), zorder=2)
for x, y in zip(totals, checks):
    ax.scatter(x, y, s=470, color=BMO_BLUE, edgecolor=PAPER, linewidth=3, zorder=4)

label_positions = [
    (totals[0] + 0.55, checks[0] + 0.28, "left", "bottom"),
    (totals[1] - 0.55, checks[1] + 0.30, "right", "bottom"),
    (totals[2] + 0.55, checks[2] - 0.25, "left", "top"),
    (totals[3] - 0.55, checks[3] + 0.15, "right", "bottom"),
]
for name, total, (lx, ly, ha, va) in zip(names, totals, label_positions):
    ax.text(lx, ly, f"{name}  {total:.1f}k", fontsize=18, fontweight="bold", color=BMO_INK, ha=ha, va=va)

fig.text(0.13, 0.87, "More checking uses more tokens", fontsize=34, fontweight="bold", color=BMO_INK)
fig.text(0.13, 0.075, "Illustrative scenario  •  not a benchmark", fontsize=15, color=MUTED)
save(fig, "pareto_minimal")


# 2. Optional token composition companion.
fig = plt.figure(figsize=(16, 9), facecolor=PAPER)
ax = fig.add_axes([0.22, 0.20, 0.67, 0.58], facecolor=PAPER)
ypos = list(range(3, -1, -1))
ax.barh(ypos, inputs, height=0.55, color=BMO_BLUE, label="Input", zorder=3)
ax.barh(ypos, outputs, left=inputs, height=0.55, color=SOFT_BLUE, label="Output", zorder=3)
ax.set_yticks(ypos, names)
ax.set_xlim(0, 25)
ax.set_xticks([0, 5, 10, 15, 20, 25])
ax.grid(axis="x", color=GRID, linewidth=1.4, zorder=0)
for spine in ax.spines.values():
    spine.set_visible(False)
ax.tick_params(axis="x", length=0, labelsize=16, colors=MUTED, pad=10)
ax.tick_params(axis="y", length=0, labelsize=19, colors=BMO_INK, pad=15)
ax.set_xlabel("Tokens (k)", fontsize=18, color=BMO_INK, labelpad=16)
for y, total in zip(ypos, totals):
    ax.text(total + 0.35, y, f"{total:.1f}k", va="center", ha="left", fontsize=18, fontweight="bold", color=BMO_INK)
leg = ax.legend(loc="upper center", bbox_to_anchor=(0.5, 1.13), ncol=2, frameon=False, fontsize=17)
for t in leg.get_texts():
    t.set_color(BMO_INK)
fig.text(0.13, 0.87, "Where tokens go", fontsize=34, fontweight="bold", color=BMO_INK)
fig.text(0.13, 0.075, "Illustrative scenario", fontsize=15, color=MUTED)
save(fig, "tokens_minimal")
