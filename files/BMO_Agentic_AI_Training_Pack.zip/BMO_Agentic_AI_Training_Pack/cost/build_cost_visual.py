"""Render an explicitly illustrative token/validation trade-off chart."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

HERE = Path(__file__).resolve().parent

workflows = [
    {
        "id": "direct",
        "label": "Single prompt",
        "input_tokens": 1800,
        "output_tokens": 700,
        "validation_lenses_scheduled": 0,
        "lenses": [],
        "calls": [{"step": "Draft answer", "input_tokens": 1800, "output_tokens": 700}],
    },
    {
        "id": "sequential",
        "label": "Sequential loop",
        "input_tokens": 11000,
        "output_tokens": 2900,
        "validation_lenses_scheduled": 2,
        "lenses": ["unit tests", "acceptance checklist"],
        "calls": [
            {"step": "Plan", "input_tokens": 1900, "output_tokens": 400},
            {"step": "Implement", "input_tokens": 2800, "output_tokens": 1000},
            {"step": "Interpret unit tests", "input_tokens": 3100, "output_tokens": 700},
            {"step": "Revise and check acceptance", "input_tokens": 3200, "output_tokens": 800},
        ],
    },
    {
        "id": "parallel",
        "label": "Parallel specialists",
        "input_tokens": 14600,
        "output_tokens": 4000,
        "validation_lenses_scheduled": 3,
        "lenses": ["unit tests", "alternative comparison", "acceptance checklist"],
        "calls": [
            {"step": "Plan", "input_tokens": 1900, "output_tokens": 400},
            {"step": "Implementation worker", "input_tokens": 2800, "output_tokens": 1000},
            {"step": "Alternative worker", "input_tokens": 2800, "output_tokens": 1000},
            {"step": "Compare and integrate", "input_tokens": 3600, "output_tokens": 900},
            {"step": "Interpret tests and acceptance", "input_tokens": 3500, "output_tokens": 700},
        ],
    },
    {
        "id": "adversarial",
        "label": "Adversarial review",
        "input_tokens": 17900,
        "output_tokens": 4200,
        "validation_lenses_scheduled": 4,
        "lenses": ["unit tests", "acceptance checklist", "edge-case review", "adversarial critique"],
        "calls": [
            {"step": "Plan", "input_tokens": 1900, "output_tokens": 400},
            {"step": "Implementation worker", "input_tokens": 2800, "output_tokens": 1000},
            {"step": "Independent critic", "input_tokens": 3200, "output_tokens": 600},
            {"step": "Revise against critique", "input_tokens": 3400, "output_tokens": 900},
            {"step": "Interpret tests and acceptance", "input_tokens": 3600, "output_tokens": 700},
            {"step": "Final edge-case/risk review", "input_tokens": 3000, "output_tokens": 600},
        ],
    },
]

for w in workflows:
    assert sum(c["input_tokens"] for c in w["calls"]) == w["input_tokens"]
    assert sum(c["output_tokens"] for c in w["calls"]) == w["output_tokens"]
    assert len(w["lenses"]) == w["validation_lenses_scheduled"]
    w["total_tokens"] = w["input_tokens"] + w["output_tokens"]
    w["relative_to_single_prompt"] = round(w["total_tokens"] / 2500, 2)

model = {
    "title": "Illustrative workflow token budget and scheduled verification",
    "status": "constructed teaching example; not Copilot telemetry or an accuracy benchmark",
    "as_of": "2026-10-26",
    "unit_of_work": "One hypothetical code change with increasing verification effort",
    "token_definition": "Sum of budgeted input and output tokens across model calls; excludes tools' own computation and any unobserved hidden usage.",
    "vertical_axis_definition": "Distinct verification passes scheduled in the workflow, not tests passed, actual defect detection, or answer quality.",
    "modeling_assumptions": [
        "The numbers are round teaching budgets for the same task, not measurements from a GitHub Copilot session.",
        "Separate calls can re-send context, tool results, or summaries; caching can lower billed cost without changing logical token volume.",
        "Parallel workers may shorten wall-clock time but their tokens add; integration still needs a model call.",
        "More review steps can be useful when errors are costly or independent perspectives reveal missed cases, but benefit must be checked on the actual task.",
        "Neither more tokens nor more scheduled lenses guarantees correctness.",
    ],
    "current_copilot_billing_note": "Current GitHub Copilot usage-based billing uses AI Credits, model-specific input/output/cached-token rates; legacy premium-request rules are a different, limited case.",
    "routing_example": "Use a capable model to plan and critically review a genuinely difficult change, then scope routine implementation subtasks for less expensive models where supported; verify final output. Model switching can invalidate cache, while separate focused subagent sessions have their own context.",
    "routing_rate_card_illustration": {
        "status": "price arithmetic only; identical budgeted token counts are assumed, not measured; quality equivalence is not claimed",
        "pricing_source": "https://docs.github.com/en/copilot/reference/copilot-billing/models-and-pricing",
        "models_usd_per_million_fresh_input_output": {"GPT-5.3-Codex": [1.75, 14.0], "GPT-5.4 nano": [0.20, 1.25]},
        "workflow": "adversarial",
        "all_strong": {"fresh_input_tokens": 17900, "output_tokens": 4200, "estimated_usd": 0.090125},
        "routed": {"strong_steps": ["Plan", "Independent critic", "Final edge-case/risk review"], "strong_fresh_input_tokens": 8100, "strong_output_tokens": 1600, "light_fresh_input_tokens": 9800, "light_output_tokens": 2600, "estimated_usd": 0.041785},
        "savings_percent": 53.64,
        "exclusions": "Assumes fresh input only; excludes cached-input pricing, cache writes, discounts, other charges, and any change in tokens or quality caused by routing. Actual Copilot charges should be read from usage metrics.",
    },
    "separate_local_lab_note": "The accompanying instructor-authored static code snapshots in deliverables_v2/demo/results.json pass 3/6 (starter), 4/6 (prompt patch), and 6/6 (verified) local acceptance checks. They are not outputs of the four workflow designs or measurements of agent accuracy or token use. Explain them separately from this cost chart.",
    "sources": [
        {"title": "Usage-based billing for organizations and enterprises", "url": "https://docs.github.com/en/copilot/concepts/billing-and-usage/organizations-and-enterprises/billing", "supports": "AI Credits, model and token based billing, agent sessions use more tokens"},
        {"title": "Models and pricing for GitHub Copilot", "url": "https://docs.github.com/en/copilot/reference/copilot-billing/models-and-pricing", "supports": "input, output, cached input, cache write rates and model tiers"},
        {"title": "Optimizing your AI usage", "url": "https://docs.github.com/en/copilot/tutorials/optimize-ai-usage", "supports": "capable planner, cheaper worker/subagent, reasoning token usage, cache implications, session limits"},
        {"title": "Using subagents in your IDE", "url": "https://docs.github.com/en/copilot/how-tos/copilot-in-your-ide/use-copilot-agents/use-subagents", "supports": "separate subagent context and self-contained delegation"},
        {"title": "How caching works", "url": "https://huggingface.co/docs/transformers/cache_explanation", "supports": "autoregressive generation and KV cache avoids repeated computation"},
        {"title": "NVIDIA Triton dynamic batcher", "url": "https://docs.nvidia.com/deeplearning/triton-inference-server/user-guide/docs/user_guide/batcher.html", "supports": "server-side batching can improve throughput; distinct from multi-agent parallel work"},
    ],
    "workflows": workflows,
}

HERE.mkdir(parents=True, exist_ok=True)
(HERE / "cost_model.json").write_text(json.dumps(model, indent=2) + "\n", encoding="utf-8")
with (HERE / "chart_data.csv").open("w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["workflow", "input_tokens", "output_tokens", "total_tokens", "relative_to_single_prompt", "validation_lenses_scheduled", "lenses"])
    for w in workflows:
        writer.writerow([w["label"], w["input_tokens"], w["output_tokens"], w["total_tokens"], w["relative_to_single_prompt"], w["validation_lenses_scheduled"], "; ".join(w["lenses"])])

plt.rcParams.update({"font.family": "DejaVu Sans", "svg.fonttype": "none"})
fig = plt.figure(figsize=(16, 9), dpi=180, facecolor="#F8FAFC")
ax = fig.add_axes([0.105, 0.245, 0.59, 0.54], facecolor="#FFFFFF")
ax.set_xlim(0, 25)
ax.set_ylim(-0.30, 4.65)
ax.set_xticks([0, 5, 10, 15, 20, 25])
ax.set_yticks([0, 1, 2, 3, 4])
ax.grid(axis="both", color="#E4EAF2", linewidth=1, zorder=0)
for spine in ax.spines.values():
    spine.set_visible(False)
ax.tick_params(axis="both", length=0, labelsize=14, colors="#52627A", pad=9)
ax.set_xlabel("Budgeted input + output tokens (thousands)", fontsize=15, color="#26364A", labelpad=15)
ax.set_ylabel("Scheduled verification passes", fontsize=15, color="#26364A", labelpad=15)

x = [w["total_tokens"] / 1000 for w in workflows]
y = [w["validation_lenses_scheduled"] for w in workflows]
ax.plot(x, y, color="#9AAFC8", linewidth=3, linestyle=(0, (5, 4)), zorder=2)
colors = ["#1479C9", "#12A69A", "#E9A72B", "#D35D69"]
for idx, (w, xi, yi, color) in enumerate(zip(workflows, x, y, colors)):
    ax.scatter([xi], [yi], s=340, color=color, edgecolor="white", linewidth=3, zorder=4)
    dx, dy, ha = [
        (0.55, 0.23, "left"),
        (-0.55, 0.33, "right"),
        (0.55, -0.49, "left"),
        (-0.55, 0.20, "right"),
    ][idx]
    ax.text(xi + dx, yi + dy, w["label"], color="#162944", fontsize=15, fontweight="bold", ha=ha, va="bottom", zorder=5)
    ax.text(xi + dx, yi + dy - 0.25, f"{w['total_tokens']/1000:.1f}k tokens · {w['relative_to_single_prompt']:.1f}×", color="#52627A", fontsize=11.5, ha=ha, va="bottom", zorder=5)

fig.text(0.105, 0.875, "The token trade-off in agentic work", fontsize=30, fontweight="bold", color="#112845")
fig.text(0.105, 0.827, "Illustrative Pareto view  •  same hypothetical code task  •  more review effort needs more model work", fontsize=15, color="#52627A")

panel = FancyBboxPatch((0.735, 0.205), 0.215, 0.58, boxstyle="round,pad=0.008,rounding_size=0.013", linewidth=0, facecolor="#EAF2FA", transform=fig.transFigure)
fig.add_artist(panel)
fig.text(0.758, 0.73, "WHEN TO SPEND MORE", fontsize=12, fontweight="bold", color="#1479C9")
fig.text(0.758, 0.665, "Direct prompt", fontsize=17, fontweight="bold", color="#112845")
fig.text(0.758, 0.625, "Small, clear change", fontsize=13, color="#3B4F68")
fig.text(0.758, 0.535, "Sequential / parallel", fontsize=17, fontweight="bold", color="#112845")
fig.text(0.758, 0.495, "Multi-file work and handoffs", fontsize=13, color="#3B4F68")
fig.text(0.758, 0.405, "Adversarial review", fontsize=17, fontweight="bold", color="#112845")
fig.text(0.758, 0.365, "Costly errors or blind spots", fontsize=13, color="#3B4F68")
fig.text(0.758, 0.270, "Route wisely:", fontsize=13, fontweight="bold", color="#1479C9")
fig.text(0.758, 0.237, "capable planner → scoped,", fontsize=12, color="#3B4F68")
fig.text(0.758, 0.212, "lower-cost workers", fontsize=12, color="#3B4F68")

fig.text(0.105, 0.100, "Illustrative budgets, not measured Copilot usage or an accuracy benchmark. A scheduled check is not a passed check.", fontsize=12, color="#50627A")
fig.text(0.105, 0.064, "Actual AI Credits depend on model, fresh/cached input, output, reasoning, and context. Parallel agents add tokens even when they save time.", fontsize=11.5, color="#66778A")
fig.savefig(HERE / "agentic_token_pareto.svg", bbox_inches=None, facecolor=fig.get_facecolor())
fig.savefig(HERE / "agentic_token_pareto.png", bbox_inches=None, facecolor=fig.get_facecolor())
plt.close(fig)
