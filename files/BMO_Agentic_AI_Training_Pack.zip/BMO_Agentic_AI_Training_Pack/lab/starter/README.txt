SYNTHETIC PAYMENTS VALIDATION LAB — PARTICIPANT STARTER
=======================================================

Time: 12–15 minutes. This is a training exercise, not a banking rule or
production payment component. Use synthetic inputs only.

Open THIS starter folder in VS Code on Windows. Do not open the parent
"lab" folder: that folder also contains the facilitator solution.

Prerequisites
-------------
- Python 3.10 or newer installed on Windows
- VS Code with GitHub Copilot access and the Python extension
- No separate Codex or Claude app, API key, third-party package, or network
  dependency is needed for the Python tests

PowerShell: confirm your location and run the baseline
------------------------------------------------------
PS> Get-Location
PS> py -3 --version
PS> py -3 -m unittest discover -s tests -v

If the Python launcher "py" is unavailable, use:
PS> python -m unittest discover -s tests -v

The starter baseline intentionally FAILS. It has seven test methods;
13 failures and eight errors are expected.
Read one red example for each defect; you do not need to read all output.

Before Copilot edits the file, save a comparison baseline. If this folder
is tracked by Git, you can inspect the change in VS Code Source Control.
For a folder extracted from the ZIP, run this PowerShell command instead:
PS> Copy-Item .\payments_demo\validation.py ..\validation.before.py
The copy sits outside the starter folder, so the one-file edit rule still
applies. After the edit, open both files in VS Code; right-click the first
tab and choose Select for Compare, then right-click the edited tab and
choose Compare with Selected. If the VS Code command-line tool is on PATH,
`code --diff ..\validation.before.py .\payments_demo\validation.py`
opens the same comparison.

Your task
---------
Repair ONLY payments_demo/validation.py. Keep the API and tests. Inputs:
Decimal or decimal string amounts; currency exactly CAD or USD. Reject
negative and non-finite amounts, more than two decimal places, floats,
booleans, malformed strings, and unsupported or misformatted currencies.
Invalid input raises ValueError. Valid amounts return an immutable Payment
whose Decimal amount has exactly two displayed places. Do not silently
round or change input objects.

Workflow in Copilot
-------------------
1. Open Copilot Chat / a Copilot agent session in VS Code. Select an
   available capable model for the planning pass. Model names and
   availability vary by subscription and organization.
2. Paste the PLAN prompt from prompts.txt. In the Copilot harness, you may
   prefix it with /plan to open the dedicated planning flow. Review the
   plan before implementation; choose Approve Plan Only when offered if
   you intend to switch models.
3. Review the proposed file scope and tests. For implementation, select
   an available faster/lower-cost model if your model picker offers one.
   Paste the IMPLEMENT prompt in an interactive session. Let Copilot edit
   the one code file.
4. Run the PowerShell unittest command yourself. Copy exact failures
   back to the implementer if needed.
5. Start a fresh Copilot chat/session for independent REVIEW. Paste the
   REVIEW prompt. Inspect its findings and rerun the tests after any fix.
6. In VS Code's changes/review view, inspect the diff before accepting the patch.

Optional after the core exercise: prompts.txt also contains a two-reviewer
native-delegation prompt. Use it only if your Copilot session supports
actual child tasks; inspect the child trace. Otherwise use two fresh,
sequential reviewer sessions. Neither path changes the one-file rule.

Optional custom-agent profiles are in .github/agents/: payment-planner,
payment-worker, and payment-reviewer. They are examples using documented
Copilot tool aliases, not a runtime-verified configuration for your tenant.
Check which tools actually load, select an allowed model in the UI, and
keep normal command approvals. No Local-harness handoffs are required.

Acceptance check
----------------
- All seven unittest methods pass.
- No tests changed or deleted; only validation.py changed.
- A fresh reviewer identifies no contract-breaking case.
- Your final summary includes exact test command and result.

The repository instruction file is .github/copilot-instructions.md. If your
organization disables repository instructions or custom agents, the
copy-ready prompts still work in a normal Copilot session.
