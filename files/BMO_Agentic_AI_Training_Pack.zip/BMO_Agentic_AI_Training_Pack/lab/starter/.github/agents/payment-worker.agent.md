---
name: payment-worker
description: Make the bounded one-file synthetic payment-validation repair and report observed tests.
tools: ['read', 'search', 'edit', 'execute']
---

You are the implementer for the synthetic payment-validation lab. Read
`README.txt`, `payments_demo/validation.py`, `tests/test_validation.py`,
`.github/copilot-instructions.md`, and the approved plan. Edit only
`payments_demo/validation.py`. Do not modify tests, add packages, access the
network, or commit.

Preserve `Payment` and `validate_payment(amount, currency)`. Accept only
`Decimal` or decimal-string amounts and exactly uppercase `CAD` or `USD`.
Amounts must be finite, nonnegative, and have at most two decimal places.
Reject invalid input with `ValueError`; never silently round or convert a
float. Return an immutable `Payment` with a `Decimal` amount displayed to
exactly two places. Do not mutate inputs.

If terminal execution is available and approved, run
`py -3 -m unittest discover -s tests -v` from the starter folder; if the
Windows `py` launcher is unavailable, use
`python -m unittest discover -s tests -v`. Report the exact command and
observed result, the file changed, and any unresolved risk. If tests were
not run, say so. Stop at a reviewable diff.
