"""Starter code: intentionally contains validation defects for the workshop."""

from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP


@dataclass(frozen=True)
class Payment:
    amount: Decimal
    currency: str


def validate_payment(amount: str | Decimal, currency: str) -> Payment:
    """Return a normalized synthetic payment.

    Contract for the exercise:
    - amount must be a Decimal or a decimal string (not float or bool)
    - amount must be finite, nonnegative, and have at most two decimal places
    - currency must be exactly CAD or USD (uppercase)
    - return an immutable Payment with amount expressed to two decimal places
    - invalid input raises ValueError; never silently round an input

    This starter implementation is deliberately wrong. Use the tests and
    Copilot workflow to repair it without changing the contract or tests.
    """
    parsed = Decimal(str(amount))
    rounded = parsed.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return Payment(amount=rounded, currency=currency.upper())
