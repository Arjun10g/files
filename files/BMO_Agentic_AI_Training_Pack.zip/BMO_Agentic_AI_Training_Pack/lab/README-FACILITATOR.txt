FACILITATOR PACKAGE — KEEP SOLUTION SEPARATE FROM PARTICIPANTS
===============================================================

The participant handout is participant-starter.zip. Distribute that ZIP
alone. It contains the deliberately failing starter, tests, prompts,
repository instructions, and exercise.html. Do not distribute this
whole lab folder before the exercise: solution/ contains the answer.

Exercise: 12 minutes in slide 25; ~55.5 minutes for all 28 slide cues.
The materials use fictional CAD/USD payment rules for teaching only.

Participants need Python 3.10 or newer. Expected local runs were verified
with Python 3.11:
  starter:  PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s tests -v
            exit 1; seven test methods; failures=13, errors=8
  solution: PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s tests -v
            exit 0; seven test methods; OK

On Windows PowerShell, run from inside starter or solution:
  py -3 -m unittest discover -s tests -v
If py is unavailable:
  python -m unittest discover -s tests -v

Answer check:
  - Currency must be str and exactly CAD or USD.
  - Amount must be Decimal or string, never float or bool.
  - Decimal parsing errors become ValueError.
  - A parsed amount must be finite and nonnegative.
  - Decimal exponent below -2 is rejected, even 3.000. This enforces
    "at most two decimal places" without silent rounding.
  - Valid amounts are rebuilt exactly at exponent -2 after this check;
    quantize can reject valid large inputs under a low Decimal precision.
  - The frozen Payment result preserves amount and currency fields.
  - Only payments_demo/validation.py should change during the lab.

The starter README instructs learners to save a pre-edit copy outside the
starter folder when they extracted the ZIP without Git history. That copy
lets them review a real VS Code diff while preserving the one-file rule.

The supplied tests intentionally exercise negative amounts, NaN and
infinities, extra fractional digits, currency case/whitespace and
unsupported currencies, malformed and wrong-type amounts, valid
normalization, and immutability. They are deterministic and use Python
standard library only. This is a workshop contract, not a universal
currency or financial-production policy.

The official Windows clips on slides 13, 15, 20, and 26 illustrate
Copilot UI actions from a May 2026 source. They do not depict this
synthetic lab or verify its test run. Use the local terminal for the
actual before/after evidence.
