# Copilot instructions for this workshop folder

This repository is a synthetic Python exercise. It contains no customer data and is not BMO production code or policy.

- Use Python standard library only. Keep the public API in `payments_demo/validation.py`: `Payment` and `validate_payment(amount, currency)`.
- Treat the function docstring and existing tests as the contract. Do not weaken or delete tests to make the run green.
- Scope changes to `payments_demo/validation.py` unless the user explicitly asks for something else.
- Money inputs must remain Decimal or decimal strings. Do not convert through `float`, silently round extra decimal places, or mutate an input.
- Run `py -3 -m unittest discover -s tests -v` in Windows PowerShell from this folder and report the exact result. If `py` is unavailable, use `python -m unittest discover -s tests -v`.
- Report what changed, which command ran, and any untested edge case. Never claim a test passed unless it actually ran.
