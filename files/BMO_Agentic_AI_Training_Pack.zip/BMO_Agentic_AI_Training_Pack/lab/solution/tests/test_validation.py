"""Behavioral tests: these are intentionally failing against starter code."""

import unittest
from dataclasses import FrozenInstanceError
from decimal import Decimal, localcontext

from payments_demo import Payment, validate_payment


class ValidationTests(unittest.TestCase):
    def test_valid_amounts_are_normalized_without_changing_currency(self):
        cases = [
            ("0", "CAD", Decimal("0.00")),
            ("10", "USD", Decimal("10.00")),
            ("10.5", "CAD", Decimal("10.50")),
            (Decimal("10.50"), "USD", Decimal("10.50")),
            ("1000000000000000000000000000", "CAD", Decimal("1000000000000000000000000000.00")),
        ]
        for amount, currency, expected in cases:
            with self.subTest(amount=amount, currency=currency):
                payment = validate_payment(amount, currency)
                self.assertEqual(payment, Payment(expected, currency))
                self.assertEqual(str(payment.amount), str(expected))

        with localcontext() as context:
            context.prec = 2
            payment = validate_payment("10.5", "CAD")
            self.assertEqual(str(payment.amount), "10.50")

    def test_negative_amount_is_rejected(self):
        for amount in ("-0.01", Decimal("-4.50")):
            with self.subTest(amount=amount):
                with self.assertRaises(ValueError):
                    validate_payment(amount, "CAD")

    def test_nan_and_infinity_are_rejected(self):
        for amount in ("NaN", "Infinity", "-Infinity", Decimal("NaN")):
            with self.subTest(amount=amount):
                with self.assertRaises(ValueError):
                    validate_payment(amount, "CAD")

    def test_extra_decimal_places_are_rejected_instead_of_rounded(self):
        for amount in ("1.005", "1.239", Decimal("3.000")):
            with self.subTest(amount=amount):
                with self.assertRaises(ValueError):
                    validate_payment(amount, "USD")

    def test_unsupported_or_misformatted_currency_is_rejected(self):
        for currency in ("EUR", "cad", " CAD", "USD ", "", None):
            with self.subTest(currency=currency):
                with self.assertRaises(ValueError):
                    validate_payment("2.00", currency)

    def test_float_bool_and_malformed_amounts_are_rejected(self):
        for amount in (1.25, True, "not-a-number", ""):
            with self.subTest(amount=amount):
                with self.assertRaises(ValueError):
                    validate_payment(amount, "CAD")

    def test_returned_payment_is_immutable(self):
        payment = validate_payment("1.00", "CAD")
        with self.assertRaises(FrozenInstanceError):
            payment.amount = Decimal("2.00")


if __name__ == "__main__":
    unittest.main()
