"""Reference solution for the synthetic workshop exercise."""

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation


SUPPORTED_CURRENCIES = frozenset({"CAD", "USD"})


@dataclass(frozen=True)
class Payment:
    amount: Decimal
    currency: str


def validate_payment(amount: str | Decimal, currency: str) -> Payment:
    """Validate and normalize a synthetic payment without silent rounding.

    Accept Decimal or decimal string amounts. Reject non-finite, negative, or
    more-than-two-decimal-place values. Currency must be exactly CAD or USD.
    All invalid input raises ValueError. The returned Payment is immutable.
    """
    if not isinstance(currency, str) or currency not in SUPPORTED_CURRENCIES:
        raise ValueError("currency must be CAD or USD")

    if isinstance(amount, bool) or not isinstance(amount, (str, Decimal)):
        raise ValueError("amount must be a Decimal or decimal string")

    try:
        parsed = Decimal(amount)
    except (InvalidOperation, ValueError):
        raise ValueError("amount must be a decimal number") from None

    if not parsed.is_finite():
        raise ValueError("amount must be finite")
    if parsed < 0:
        raise ValueError("amount must be nonnegative")
    parts = parsed.as_tuple()
    if parts.exponent < -2:
        raise ValueError("amount must have at most two decimal places")

    # Construct the equivalent value at exponent -2 directly. quantize()
    # can fail for valid large amounts when the caller's Decimal context has
    # less precision than the resulting coefficient.
    if not any(parts.digits):
        normalized = Decimal((parts.sign, (0,), -2))
    else:
        digits = parts.digits + (0,) * (parts.exponent + 2)
        normalized = Decimal((parts.sign, digits, -2))

    return Payment(amount=normalized, currency=currency)
