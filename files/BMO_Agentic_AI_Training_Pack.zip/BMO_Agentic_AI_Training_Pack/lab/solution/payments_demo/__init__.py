"""Synthetic payment validation exercise. No customer or bank data."""

from .validation import Payment, validate_payment

__all__ = ["Payment", "validate_payment"]
