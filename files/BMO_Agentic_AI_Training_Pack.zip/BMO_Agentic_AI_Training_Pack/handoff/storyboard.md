# V2 storyboard — from a plausible answer to a verified change

Archived source storyboard for the portable deck rebuild; production notes add evidence-specific updates in rebuild_visual.py. Prepared 2026-10-26. Supersedes the dense 28-slide narrative. Audience: developers new to AI/agents, using Windows, VS Code and their existing GitHub Copilot access. Aim for 35–45 minutes including a 6-minute exercise, leaving discussion room. No additional AI account, API, orchestration framework or package installation is necessary for the core lab.

## Production contract

Every slide has one point, one dominant visual, and ordinarily 25 or fewer authored words; 35 is the ceiling, excluding genuine UI/code, provenance and the unobtrusive footer. Titles count. Use 32–40 pt titles and 24–30 pt labels. Screenshots fill 70–85% of the usable area and are cropped around the action. No tiny screenshot collages, paragraph panels, generic robot art, or slide-length prompt blocks. Detailed explanations live in speaker notes. Do not compress the old deck into 20 dense pages.

Retain public BMO branding: real previously sourced logo with preserved proportions, white background, BMO blue accents, restrained red, large margins. Do not claim internal brand approval or BMO policy. A discreet “Developer workshop • synthetic example” footer suffices. Use editable shapes for all conceptual diagrams. Title slide is also the first teaching visual; no agenda slide consumes the first three slots.

Use authentic existing official assets where they teach the specific action. Label them “Official documentation example.” Existing macOS lab captures must remain labeled macOS and must not be presented as Windows Copilot footage. The old transaction/Decimal captures are not evidence for this new cart task. Windows Copilot recapture remains a handoff requirement until actually performed. Never manufacture terminal results, chat transcripts, agent findings, account menus, or a Windows window frame. Standalone rendered code is acceptable when labeled “Teaching example,” not screenshot.

## One task, fully specified

`delivery_fee(total_cents)` receives an amount in integer cents. Built-in `int` values are accepted; `bool`, floats, strings and `None` raise `ValueError`. Negative integers also raise `ValueError`; all invalid inputs use this single beginner-friendly error type. Return `500` below `10000`, otherwise `0`. Do not change the function name/signature or add dependencies. This is a deliberately synthetic cart rule, not a bank or payment-system policy.

Starter:

```python
def delivery_fee(total_cents):
    return 0 if total_cents > 10000 else 500
```

Reference behavior: `0→500`, `9999→500`, `10000→0`, `10001→0`, `-1→ValueError`, `True→ValueError`, `10000.0→ValueError`, `"10000"→ValueError`, `None→ValueError`. Include the full contract in the README from the beginning; do not give the simple prompt less information than the agent workflow. Suggested lab uses only Python standard-library `unittest`, so no pytest/network install is needed. Keep tests fixed during the repair exercise. A starter failure and passing reference solution must actually be executed and recorded.

## Slide 01 — Before the first token

**Visible copy:** “From answers to verified changes” / “Prefill” / “Process the input” / “Prompt + context → model”

**Visual:** Full-width stream of blue input tiles entering one large model block. Tiny code-shaped content in the input tiles establishes developer relevance. Reserve one simple output placeholder. Public BMO mark in the corner. This is an editable conceptual illustration, not a vendor performance chart.

**Speaker notes:** Introduce the workshop promise: we will fix one tiny Python function and learn where a simple prompt is enough and where a checked workflow helps. Explain tokens verbally as pieces of text, not always whole words. Prefill processes the supplied context and builds intermediate state used for generation. There can also be queuing/network delay; observed waiting before the first token is not solely prefill. This picture omits serving details and caching. Do not discuss matrices, attention complexity or hardware sizing. Source: NVIDIA inference optimization article below.

## Slide 02 — Then the answer grows

**Visible copy:** “Decode” / “Generate the next token” / “Input → first token → next token → next token”

**Visual:** Reuse slide 1 geometry, now with a large output ribbon appearing tile by tile. Beneath it, a simple timeline with “Prefill” before first output and “Decode” across the growing output. No numeric durations.

**Speaker notes:** In the simple autoregressive picture, each next token depends on preceding context and output. This explains the familiar streaming answer. The actual serving system can use optimizations such as speculative decoding; the visual teaches the basic dependency, not a literal guarantee that every engine emits only one token per hardware step. Longer answers add generated tokens. Transition: a provider can serve multiple requests together, but that is different from assigning multiple developer roles.

## Slide 03 — Many requests share the engine

**Visible copy:** “Batching” / “Request A” / “Request B” / “Request C” / “Shared compute” / “More throughput ≠ less waiting for everyone”

**Visual:** Three colored request lanes enter a wide shared compute block, then continue as three output lanes. Small vertical time slices visually group work from different requests. Use huge tiles and only these labels.

**Speaker notes:** Batching groups work across requests to use hardware efficiently. Continuous batching can admit new work as others finish. Throughput and individual latency are different metrics; load, scheduling and prompt lengths matter. We do not control Copilot’s backend scheduler here. Agent parallelism later in this talk means multiple scoped tasks, not a claim about backend batching or free execution. Source: NVIDIA chunked prefill article below.

## Slide 04 — One tiny bug

**Visible copy:** “One tiny bug” / “$99.99 → $5” / “$100.00 → free” / “Reject invalid totals”

**Visual:** Three large cart receipt cards and the actual two-line starter function at presentation size. Highlight only `>` and the exact $100 boundary. A subtle cents ruler connects 9999, 10000 and 10001.

**Speaker notes:** Show that everyone can understand the behavior without learning finance or a framework. State the full integer-cents contract, including bool exclusion and the single ValueError rule, verbally and point to the README. Python bool is an int subclass, which will become a useful review example, but do not bury the audience in type-system detail now. Ask the room verbally what happens at exactly $100. Code is instructor-authored. Demonstrate the actual failing baseline only if executed. No invented counts.

## Slide 05 — Start with one clear prompt

**Visible copy:** “Start with one clear prompt” / “Fix delivery_fee to match the README. Change only shipping.py. Return the patch.” / “A proposal to inspect”

**Visual:** A large authentic prompt/result crop when recaptured; otherwise a plainly labeled teaching prompt beside the two-line boundary patch. The patch may be an instructor-supplied example. Do not draw a fake chat frame.

**Speaker notes:** This is a strong starting point for a small, well-specified edit. Supply the same README, starter and tests for all approaches. A simple prompt can solve this task correctly; agents do not deserve extra credit for being more complicated. If Copilot returns a complete correct patch, show that result honestly. The comparison is between a returned proposal and an explicitly executed verification process. The baseline requested a patch rather than tool execution; make that distinction clear. This is a pedagogical contrast, not an experimental model benchmark.

## Slide 06 — Does the patch satisfy the contract?

**Visible copy:** “Does the patch satisfy the contract?” / “10000 → 0” / “−1 → error” / “True → error” / “Run the checks”

**Visual:** Large terminal/test result or rendered acceptance-check cards. A supplied partial patch changing only `>` to `>=` passes the boundary but fails negative/bool requirements. Label it “Instructor-supplied partial patch” if not actually generated by the recorded model.

**Speaker notes:** Use a real test run on the partial patch. Explain that fixing one visible symptom is not proof that the whole contract is satisfied. Do not claim the AI necessarily missed these checks. If the one-shot result already passes, congratulate the workflow choice and introduce the partial patch as a controlled teaching example. The learning objective is evidence, not embarrassing a model. Acceptance tests can be incomplete too, so their scope needs human review.

## Slide 07 — Give the agent a feedback loop

**Visible copy:** “Give the agent a feedback loop” / “Inspect → change → run → read → improve” / “Stop when the contract passes”

**Visual:** One large five-stage loop with a terminal result feeding back into the edit stage; a completion exit leads to a reviewed diff. Dominant full-slide visual. Clip A, 25–40 seconds, can replace the diagram area during playback.

**Speaker notes:** The important addition is the ability to use tools and respond to their outputs. One agent can inspect code, edit, run tests, observe a failure and correct the patch. Multiple agents are optional. A prompt alone may also drive tools if the chosen mode supports them, so avoid defining “one prompt” as inherently incapable of agency. For this demo ask: “Fix delivery_fee to the README contract, run the supplied unittest suite, inspect the diff, and report actual results. Change only shipping.py.” Stop when checks pass and scope is reviewed; do not loop forever.

## Slide 08 — A role is a job description

**Visible copy:** “A role is a job description” / “Planner: decide” / “Worker: implement” / “Reviewer: challenge” / “Role ≠ model ≠ separate running agent”

**Visual:** Three large role cards, each a short instruction snippet, above a shared model/runner base. One thin annotation shows that the same model can fill all roles.

**Speaker notes:** You can apply these roles with ordinary prompts in separate chats, save them as reusable custom profiles, or use supported native delegation. Naming three roles in one message does not establish three independent contexts. A saved custom agent is a configuration, not a newly trained model or proof of parallel execution. Keep one model as a supported fallback. Distinguish responsibility, model selection and execution mode before showing the UI.

## Slide 09 — Create the role in VS Code

**Visible copy:** “Create the role in VS Code” / “Open Customizations → Agents → New Agent” / “Workspace” / “Save. Select. Try.”

**Visual:** One large, genuine Customizations screenshot with at most three numbered callouts. Use the existing official `create-custom-agent-2.png` if no Windows account capture exists. Clip B shows actual creation and selection when available.

**Speaker notes:** Windows: Ctrl+Shift+P, run `Chat: Open Customizations`, select Agents, and choose New Agent beside Workspace. Alternatively `Chat: New Custom Agent` is documented. Set the intended session target/harness before creating the configuration. Save a workspace reviewer profile and select it from the Agent dropdown. The editor is documented as Preview; labels and options can vary. Use actual capture labels. Creating this file does not grant tools, model access, organization permissions or automatic delegation. Source: VS Code custom agents documentation, checked 2026-10-26.

## Slide 10 — The file is the reusable instruction

**Visible copy:** “The file is the reusable instruction” / “.github/agents/skeptic.agent.md” / “Name + purpose + instructions”

**Visual:** A giant real code/editor crop, at least 70% slide width, showing the following minimal file. No file-tree clutter.

```markdown
---
name: Skeptic
description: Check the delivery fee contract
---
Review the patch against README.md.
Do not edit files.
Return one concrete counterexample, or say none found.
```

**Speaker notes:** Header describes the profile; body directs its behavior. “Do not edit” is an instruction, not an enforced security boundary. For an actually read-only reviewer, restrict available tools through the observed, supported harness controls and verify them. Tool names and model fields differ by harness/version; do not blindly paste a stale tool list. Keep this minimal profile portable. Optional model selection belongs in the verified environment, not hard-coded brand claims on the slide. A model can still fail to follow the instructions, so inspect output and tools used.

## Slide 11 — Sequential: pass a small contract

**Visible copy:** “Sequential: pass a small contract” / “Plan → implement → review → verify” / “One change. Clear ownership.”

**Visual:** Four huge horizontal stations with the same small shipping.py file passed along. The planner hands over exactly “integer cents / threshold / errors.” Reviewer receives the diff plus README.

**Speaker notes:** Use sequential work when a step depends on the preceding result. Planner identifies the tiny scope and checks. Worker edits only shipping.py. Reviewer examines the actual patch against the contract. The responsible agent or human runs the fixed tests and reviews the final diff. Saved handoffs can be manual; do not require YAML handoff support. Keep the handoff smaller than the entire conversation. For this tiny task, a single agent may be cheaper and simpler; the pattern becomes useful as tasks become less obvious.

## Slide 12 — Parallel: split independent checks

**Visible copy:** “Parallel: split independent checks” / “Boundary reviewer” / “Input reviewer” / “Combine findings” / “One writer”

**Visual:** Two wide branches from the same frozen patch: one examines 9999/10000/10001, the other negative/type inputs. They merge into one findings list and one writer. A small real delegation trace inset only if readable and actually captured.

**Speaker notes:** These reviews are independent and read-only, so they can run concurrently. Ask one reviewer to examine thresholds and another to examine invalid inputs. The main agent combines their evidence and assigns one owner to make changes. Separate concurrent sessions or supported native subagents are actual parallel work; sequential role-playing is not. Parallel calls can reduce elapsed time for independent work but add token/context overhead, and no speedup is guaranteed. If native delegation is unavailable, demonstrate the same scopes in separate chats or perform them sequentially and say so.

## Slide 13 — Adversarial: try to break the answer

**Visible copy:** “Adversarial: try to break the answer” / ““Find an input that violates the README.”” / “True is not a cart total” / “Counterexample → regression check”

**Visual:** Oversized `True` input enters a plausible `isinstance(total_cents, int)` validation and exposes the contract mismatch. A red result becomes a green regression check after the fix. Clip C records the genuine review/fix sequence.

**Speaker notes:** Adversarial review means constructive challenge against a stated contract, not agents arguing without evidence. Python considers bool an int subclass; this contract intentionally excludes it. A clear fix is exact built-in int checking before the negative check. Show that the failing case becomes an executable regression check. If the actual reviewer finds no issue, report that truthfully; use a clearly identified instructor-provided partial patch to teach the trap. Reviewers can miss defects, and agreement is not proof.

## Slide 14 — Spend capability where judgment matters

**Visible copy:** “Spend capability where judgment matters” / “Human: own the outcome” / “Capable planner: decide + integrate” / “Lower-cost workers: bounded tasks” / “Tests + reviewed diff”

**Visual:** A large four-level responsibility pyramid; the foundation is wider than all other levels. Show one planner, two workers, and a reviewer beside the workers, with no implied recursive hierarchy. A small model-picker image may be used only if legible.

**Speaker notes:** The pyramid is responsibility, not social status or guaranteed software architecture. Use a capable model for ambiguous planning and integration; consider a lower-cost available model for scoped implementation or checks. Verify results and escalate difficult failures. Model availability and effective price depend on the organization, subscription and current product. Manual model switches with a compact handoff are sufficient; do not promise independent per-subagent routing in every harness. Using one model for all roles remains valid. For this tiny function, planning overhead may be unnecessary.

## Slide 15 — Match the workflow to the work

**Visible copy:** “Match the workflow to the work” / “One clear edit → simple prompt” / “Dependent steps → sequential” / “Independent checks → parallel” / “Risky assumption → adversarial review”

**Visual:** Four large pictogram cards; one sentence each. Highlight the relevant cart examples with icons, not extra prose. This is the decision slide that makes the technique usable tomorrow.

**Speaker notes:** A small task with clear acceptance criteria often needs one capable agent plus tests. Sequence dependent work. Parallelize only independent scopes. Add a challenger when a plausible result could hide a costly mistake. These patterns can be combined, but each extra agent should have a reason, a bounded input and a useful output. The takeaway is choosing evidence-producing work, not maximizing agent count.

## Slide 16 — More agents can mean more tokens

**Visible copy:** “More agents can mean more tokens” / “Illustrative only” / “Single prompt: 1,000 in + 250 out” / “Checked loop: 4,000 in + 800 out” / “Price depends on model + caching”

**Visual:** Two large token bars split into input/output, with repeated context visibly contributing to the checked loop. This is an arithmetic illustration, not results from this lab. No currency signs, percentages saved or measured-result styling.

**Speaker notes:** These invented round numbers explain accounting only; they are not measured Copilot usage or expected performance. Total agent tokens sum calls across planning, workers, review, retries and integration. Inputs can include repeated context and tool results; outputs may include provider-accounted reasoning tokens. Caching and current billing rules affect cost, so 4× input tokens does not automatically mean 4× the bill. A cheaper worker can still cost more overall if it causes retries. Compare total cost of a verified result, including human review/rework, not only the first model response. If real telemetry becomes available, replace the entire illustration with clearly labeled measurements and record the environment and method.

## Slide 17 — Buy useful evidence, then stop

**Visible copy:** “Buy useful evidence, then stop” / “Illustrative tradeoff—not a benchmark” / “Cost / effort →” / “Verified requirements ↑” / “Pareto frontier” / “Extra cost, no extra evidence”

**Visual:** A large conceptual Pareto chart with a stepped frontier and a clearly dominated point to its right. No numerical axes, invented quality scores or placement of brand/model logos. Label two useful points “Minimal passing workflow” and “Additional checks.”

**Speaker notes:** Pareto means one option cannot improve an axis without giving up something on the other, within the options being compared. Here the axes are resource cost and evidence from checked requirements. Passing known checks is not a universal correctness score. Some tasks need broader evidence; some do not. A larger workflow can be dominated if it costs more without satisfying more requirements or reducing relevant uncertainty. For our cart, stop once the full contract is checked and the diff is reviewed. This chart motivates measurement; it does not claim agents always occupy the best point. A fair experiment would use the same contract and acceptance suite, repeated independent runs, total tokens/time, human intervention and observed failures.

## Slide 18 — Your six-minute Windows lab

**Visible copy:** “Your six-minute Windows lab” / “Open starter” / “Run tests” / “Ask for a bounded fix” / “Challenge it” / “Review the diff”

**Visual:** One large Windows VS Code workspace screenshot when captured, with a five-step numbered path. Present a large authentic terminal pane or simple code artifact containing the commands below; keep installation detail in notes/handout.

```powershell
py -3 -m unittest -v test_shipping
```

**Speaker notes:** Prerequisites: VS Code, approved Copilot access, Python 3 and the supplied starter folder. In PowerShell use `py -3` if the Windows launcher is installed; otherwise select the installed interpreter and use its observed command. No environment activation or execution-policy changes are needed. Open only the standalone starter folder. Run the baseline and observe actual failures. Give the agent README, shipping.py and tests. Permit changes only to shipping.py. Use the Skeptic profile or a fresh review prompt, run the fixed suite again, and inspect Source Control or file comparison. Do not imply the starter is already a Git repo unless production makes it one. Have a zip/diff fallback for learners without Git.

## Slide 19 — Done means evidence

**Visible copy:** “Done means evidence” / “Contract covered” / “Tests actually run” / “Diff reviewed” / “Limits stated” / “Stop or escalate when progress stalls”

**Visual:** The final real green test output and a small reviewed patch occupy most of the slide, with four check icons. Clip D shows actual verification and diff inspection in 20–30 seconds.

**Speaker notes:** The completion report should name behavior changed, files changed, commands actually run, actual results and anything not checked. Do not count a model saying “tests should pass” as execution evidence. Confirm the full contract, not just the shown examples. Stop after completion. If work expands, files change outside scope, checks repeatedly fail or permissions block progress, pause and narrow/escalate rather than adding agents blindly. Keep these as practical controls, not a long security checklist.

## Slide 20 — Start small. Verify. Scale when useful.

**Visible copy:** “Start small. Verify. Scale when useful.” / “One clear task” / “One checked result” / “Add roles when they earn their cost”

**Visual:** The cart receipt now shows $100.00 → free with the three compact symbols from the talk: prompt, loop, team. The loop is visually central; team is optional. BMO branding remains restrained.

**Speaker notes:** Return to the opening promise. Participants can now explain a basic input/output serving picture, repair a concrete function with checks, create a reusable role, choose sequential/parallel/adversarial patterns, and discuss total effort honestly. Invite them to try a similarly bounded task in their own repository using approved access and a concrete definition of done. Do not finish on a page of references or an unsupported ROI number. References and detailed instructions remain in notes and the companion handout.

## Future Windows capture priorities (current pack has three guided macOS clips)

| Clip | Placement | Observe | Required truthful fallback |
|---|---|---|---|
| A: one-agent loop, 25–40 s | 7 | Real prompt, scoped edit, executed tests, response to result | Instructor code/test walkthrough, clearly not Copilot footage |
| B: create reviewer, 25–40 s | 9–10 | Real Windows UI → workspace .agent.md → selected profile | Official reference image plus actual file example; identify missing account capture |
| C: challenge, 25–40 s | 13 | Actual reviewer result, reproducible counterexample if found, regression result | Labeled instructor-supplied partial patch; no fake model finding |
| D: verify, 20–30 s | 19 | Actual green run, actual minimal diff, completion report | Real local terminal capture with true OS label |

Each clip needs an actual poster, legible text, captions/transcript, provenance, and a linked MP4 fallback. Label any time compression. Do not reuse old Decimal lab recordings as evidence for this task. Official product footage can illustrate UI but cannot be relabeled as this cart lab. Existing abundant screenshots are a library, not a quota: use only the handful that directly support this story. Native Windows PowerPoint playback must be tested before claiming it works.

P0 recaptures: starter + README; simple prompt result; agent test loop; create/select Skeptic; .agent.md editor; actual model picker (if shown); final tests + diff. P1: native parallel delegation trace. Preserve original images/video, environment versions, session target, selected models, capture date and edits in the manifest.

## Primary references and fact boundaries

- Prefill/decode basics: https://developer.nvidia.com/blog/mastering-llm-techniques-inference-optimization/
- Batching/serving: https://developer.nvidia.com/blog/streamlining-ai-inference-performance-and-deployment-with-nvidia-tensorrt-llm-chunked-prefill/
- Create/manage profiles: https://code.visualstudio.com/docs/agent-customization/custom-agents
- Profile schema/harness differences: https://code.visualstudio.com/docs/agents/reference/custom-agent-file-reference
- Actual delegation: https://code.visualstudio.com/docs/agents/run/subagents
- Cost and retry tradeoffs: https://code.visualstudio.com/docs/agents/guides/optimize-usage
- Model selection: https://code.visualstudio.com/docs/agent-customization/language-models

Current documentation verified 2026-10-26. Preserve existing public BMO asset source entries in the media manifest. Never promote a diagram or cost illustration to measured evidence. All cart rules, prompt examples, workflow recommendations and slide sequencing are workshop design choices, not product guarantees.

## Production coordination freeze

Root confirmed the built lab has six real tests: starter 3/6, instructor-authored partial patch 4/6, reference solution 6/6. These are measured results for authored code artifacts, not AI benchmark outcomes. Use these actual counts only with the corresponding artifact and execution evidence. Sol cost scenario JSON/chart may replace slide 16/17 artwork if every hypothetical token quantity is explicitly labeled illustrative and the actual authored-code test results are never represented as model success rates. All invalid inputs use ValueError, matching the frozen lab.
