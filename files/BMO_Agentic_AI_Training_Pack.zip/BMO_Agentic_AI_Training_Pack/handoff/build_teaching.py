"""Rebuild the HTML/PDF presenter guide from slide_content.json.

Run from this pack: python handoff/build_teaching.py
Requires reportlab only for the PDF; the HTML uses the standard library.
"""
from __future__ import annotations

import html
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / "slide_content.json").read_text(encoding="utf-8"))
OUT = ROOT / "teaching"
OUT.mkdir(exist_ok=True)

MINUTES = [1, 1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 1, 2, 2, 6, 2, 1]
CUES = [
    "Ask what happens before a streamed answer appears; introduce prefill without timing claims.",
    "Point to the growing answer; distinguish generated output tokens from supplied context.",
    "Trace three request lanes; distinguish backend batching from parallel agent tasks.",
    "Ask for the fee at exactly $100.00. Point to the full README contract, including invalid inputs.",
    "Show the one-shot proposal request from the prompt handout. Treat any returned patch as a proposal.",
    "Use the supplied instructor partial patch and its actual 4/6 test run. Ask which rules it missed.",
    "Trace inspect, edit, run, read, improve. Show the guided clip or narrate the loop.",
    "Assign Planner, Builder, and Skeptic one responsibility each. Explain that roles can share a model.",
    "Use the labeled official UI example; explain the Windows path without claiming this is an account capture.",
    "Open the bundled .github/agents/skeptic.agent.md. Show the description, instructions, and tool list.",
    "Have a planner pass the compact contract to one writer; review the resulting diff.",
    "Split threshold and invalid-input checks; one owner combines findings. State if delegation is unavailable.",
    "Ask Skeptic for a concrete counterexample. Reproduce the bool case against the partial patch.",
    "Keep the human responsible for outcome; select available models based on difficulty and local constraints.",
    "Ask which pattern the tiny cart task actually needs. Choose a workflow only for a reason.",
    "Label every token amount illustrative. Sum all calls, including retry and review context.",
    "Explain the conceptual frontier: pay for evidence the task needs and stop when it is sufficient.",
    "Run the minute-by-minute six-minute student lab below; open the standalone extracted starter folder.",
    "Show the actual 6/6 reference run and reviewed diff; distinguish it from a live Copilot completion.",
    "Return to the $100.00 boundary. Invite a similarly bounded task with a clear definition of done.",
]


def clean_note(value: str) -> str:
    value = re.sub(r"^SLIDE \d+: [^\n]+\n\n", "", value).strip()
    # Retire stale planning filenames and terminology if an old JSON remains.
    value = value.replace("delivery.py", "shipping.py")
    value = value.replace("discover -s tests -v", "-v test_shipping")
    value = value.replace("Reviewer profile", "Skeptic profile")
    return value


def rich(value: str) -> str:
    value = html.escape(value)
    value = re.sub(r"`([^`]+)`", r"<code>\1</code>", value)
    value = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", value)
    value = re.sub(r"(https?://[^\s&lt;]+)", r'<a href="\1">\1</a>', value)
    return value


def paragraphs(value: str) -> str:
    blocks = re.split(r"\n\s*\n", clean_note(value))
    return "\n".join("<p>" + rich(b).replace("\n", "<br>") + "</p>" for b in blocks if b.strip())


def elapsed_label(start: int, duration: int) -> str:
    return f"{start:02d}–{start + duration:02d} min"


clock = 0
cards = []
rows = []
for i, slide in enumerate(DATA):
    number = i + 1
    duration = MINUTES[i]
    time_label = elapsed_label(clock, duration)
    rows.append(f"<tr><td>{number:02d}</td><td><a href='#slide-{number:02d}'>{html.escape(slide['title'])}</a></td><td>{time_label}</td></tr>")
    cards.append(
        f"<section class='slide' id='slide-{number:02d}'>"
        f"<div class='slide-top'><span>SLIDE {number:02d} · {time_label}</span><span>{html.escape(slide['section'])}</span></div>"
        f"<h2>{html.escape(slide['title'])}</h2>"
        f"<p class='cue'><strong>Present:</strong> {html.escape(CUES[i])}</p>"
        f"{paragraphs(slide['notes'])}</section>"
    )
    clock += duration

assert len(DATA) == len(MINUTES) == 20 and clock == 38

STYLES = """
:root{--blue:#0075be;--navy:#003b71;--ink:#183246;--muted:#5d7383;--pale:#edf6fb;--line:#d7e4ec}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#f7fafc;color:var(--ink);font:17px/1.53 Arial,Helvetica,sans-serif}
header{background:white;border-top:7px solid var(--blue);border-bottom:1px solid var(--line)}.wrap{max-width:1040px;margin:auto;padding:26px}
h1{font-size:2.6rem;color:var(--navy);margin:.18em 0}h2{color:var(--navy);font-size:1.48rem;margin:.38em 0}h3{color:var(--navy)}a{color:#006ea9}
nav a{margin-right:1.1em}.intro{font-size:1.13rem;max-width:75ch}.box{background:white;border:1px solid var(--line);border-radius:12px;padding:20px 24px;margin:20px 0}
.box.highlight{background:var(--pale);border-left:6px solid var(--blue)}table{border-collapse:collapse;width:100%;font-size:.94rem}td,th{text-align:left;padding:7px 10px;border-bottom:1px solid var(--line)}th{color:var(--navy)}
.slide{background:white;border:1px solid var(--line);border-radius:12px;padding:23px 27px;margin:20px 0;break-inside:avoid}.slide-top{display:flex;justify-content:space-between;gap:1em;color:var(--blue);font-size:.78rem;font-weight:bold;letter-spacing:.08em;text-transform:uppercase}.cue{background:var(--pale);padding:12px 15px;border-radius:8px}
p{margin:.65em 0}code{font: .91em Consolas,Monaco,monospace;background:#edf3f6;padding:.08em .2em;border-radius:3px;overflow-wrap:anywhere}
footer{font-size:.85rem;color:var(--muted);border-top:1px solid var(--line)}@media print{body{background:white}.wrap{max-width:none}.slide,.box{box-shadow:none}a{color:var(--navy)}}
"""

html_text = f"""<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Presenter guide · Agentic AI in VS Code</title><style>{STYLES}</style></head><body>
<header><div class='wrap'><nav><a href='../START_HERE.html'>Start here</a><a href='../Presentation.html'>Presentation</a><a href='prompts.html'>Prompts</a><a href='presenter-guide.pdf'>Print PDF</a></nav><h1>Presenter guide</h1><p class='intro'>A 20-slide, 38-minute route for developers new to AI agents, including a six-minute Windows lab. Allow four more minutes for discussion for a 42-minute session.</p></div></header>
<main class='wrap'><div class='box highlight'><strong>Before presenting</strong><p>Open the extracted student starter in VS Code. Confirm Python 3.10+, run <code>py -3 -m unittest -v test_shipping</code> from that folder, and keep a pristine starter ZIP for resets. Use your organization-approved GitHub Copilot account if you plan a live agent demonstration. The supplied guided clips are real local macOS VS Code artifact walkthroughs, not authenticated Copilot footage.</p><p>Have <a href='../demo/student_starter.zip'>student_starter.zip</a>, <a href='prompts.html'>copy-ready prompts</a>, and <a href='../media/index.html'>media fallbacks</a> available. On Windows, labels and agent features can vary by installed version and harness.</p></div>
<div class='box'><h2>Run of show</h2><table><thead><tr><th>Slide</th><th>Point</th><th>Elapsed</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div>
<div class='box highlight'><h2>Six-minute lab · slide 18</h2><p><strong>Minute 0–1:</strong> Extract the starter into a new folder. Open that folder in VS Code. Read the full contract in <code>README.md</code>. Run <code>py -3 -m unittest -v test_shipping</code> and observe the baseline.</p><p><strong>Minute 1–3:</strong> Use the bounded IMPLEMENT prompt. Permit edits to <code>shipping.py</code> only. Keep <code>test_shipping.py</code> unchanged. A plain Copilot agent chat is sufficient; the saved Builder profile is optional.</p><p><strong>Minute 3–5:</strong> Use the REVIEW prompt or bundled Skeptic profile in a fresh chat. Ask for a concrete counterexample, particularly exact 10000 cents and invalid types. A clean review is a valid outcome.</p><p><strong>Minute 5–6:</strong> Rerun the unchanged six tests yourself. Compare <code>shipping.py</code> with the initial copy or a Git baseline. Report what ran, what changed and what remains unverified.</p><p>If the live agent stalls or Copilot is unavailable, use the static authored snapshots: starter 3/6, boundary patch 4/6, reference 6/6. Label them accurately. Do not count them as model runs.</p></div>
{''.join(cards)}
<div class='box'><h2>Evidence and source boundaries</h2><p>The six-test counts describe local instructor-authored code snapshots only. The token bars and Pareto figure are illustrations. The three guided clips are based on actual local macOS VS Code artifacts and have transcripts; none documents a live authenticated Copilot result. Official documentation screenshots are identified as such. The Windows Copilot recapture and an optional real usage experiment remain in <a href='../handoff/NEXT_AGENT.txt'>NEXT_AGENT.txt</a>.</p><p>Primary documentation: <a href='https://developer.nvidia.com/blog/mastering-llm-techniques-inference-optimization/'>NVIDIA inference explanation</a>, <a href='https://code.visualstudio.com/docs/agent-customization/custom-agents'>VS Code custom agents</a>, <a href='https://code.visualstudio.com/docs/agents/run/subagents'>VS Code subagents</a>, <a href='https://code.visualstudio.com/docs/agents/guides/optimize-usage'>VS Code usage guidance</a>, and <a href='https://docs.github.com/en/copilot/reference/copilot-billing/models-and-pricing'>GitHub Copilot model pricing</a>. Documentation was checked 26 October 2026.</p></div>
</main><footer><div class='wrap'>Developer workshop · Synthetic cart example · 26 October 2026</div></footer></body></html>"""
(OUT / "presenter-guide.html").write_text(html_text, encoding="utf-8")

try:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, KeepTogether
except ImportError as exc:
    raise SystemExit("HTML created; install reportlab to build PDF: " + str(exc))

BLUE = colors.HexColor("#0075BE")
NAVY = colors.HexColor("#003B71")
INK = colors.HexColor("#183246")
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="GuideTitle", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=24, leading=29, textColor=NAVY, spaceAfter=14))
styles.add(ParagraphStyle(name="GuideH2", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=14, leading=17, textColor=NAVY, spaceBefore=15, spaceAfter=7))
styles.add(ParagraphStyle(name="GuideBody", parent=styles["BodyText"], fontName="Helvetica", fontSize=9.2, leading=13.3, textColor=INK, spaceAfter=8))
styles.add(ParagraphStyle(name="GuideCue", parent=styles["GuideBody"], backColor=colors.HexColor("#EDF6FB"), borderPadding=7, spaceAfter=9))
styles.add(ParagraphStyle(name="GuideSmall", parent=styles["GuideBody"], fontSize=8.2, leading=11.5, textColor=colors.HexColor("#5D7383")))
doc = SimpleDocTemplate(str(OUT / "presenter-guide.pdf"), pagesize=letter, rightMargin=.68*inch, leftMargin=.68*inch, topMargin=.67*inch, bottomMargin=.67*inch, title="Presenter guide — Agentic AI in VS Code")
story = [Paragraph("Presenter guide", styles["GuideTitle"]), Paragraph("20 slides · 38-minute route including a six-minute Windows lab · allow four minutes for discussion", styles["GuideBody"])]
story += [Paragraph("Before presenting", styles["GuideH2"]), Paragraph("Open a fresh extracted student starter in VS Code. Confirm Python 3.10+. Run <font face='Courier'>py -3 -m unittest -v test_shipping</font> from that folder. Keep a pristine ZIP for resets. Use approved Copilot access for a live demonstration. The supplied guided clips are local macOS VS Code artifact walkthroughs, not authenticated Copilot footage.", styles["GuideBody"])]
story += [Paragraph("Six-minute lab · slide 18", styles["GuideH2"])]
lab_steps = [
    "0–1 min: Extract starter, open its folder, read README.md, run the baseline suite.",
    "1–3 min: Use IMPLEMENT. Edit shipping.py only; keep tests unchanged.",
    "3–5 min: Use REVIEW or the Skeptic profile. Seek a concrete boundary or invalid-input counterexample.",
    "5–6 min: Rerun the six tests, review the diff, report actual evidence and limits.",
]
story += [Paragraph(html.escape(t), styles["GuideBody"]) for t in lab_steps]
story += [Paragraph("Static authored snapshots: starter 3/6, boundary patch 4/6, reference 6/6. They are fallback teaching artifacts, not measured model outcomes.", styles["GuideSmall"]), PageBreak()]

for i, slide in enumerate(DATA):
    n = i + 1
    start = sum(MINUTES[:i])
    story.append(Paragraph(f"{n:02d} · {html.escape(slide['title'])} <font size='9' color='#0075BE'>({elapsed_label(start, MINUTES[i])})</font>", styles["GuideH2"]))
    story.append(Paragraph("<b>Present:</b> " + html.escape(CUES[i]), styles["GuideCue"]))
    for block in re.split(r"\n\s*\n", clean_note(slide["notes"])):
        if block.strip():
            safe = rich(block).replace("<code>", "<font face='Courier'>").replace("</code>", "</font>").replace("<br>", "<br/>")
            # ReportLab's Paragraph parser has limited hyperlink/markup support.
            safe = re.sub(r"<a href=\"[^\"]+\">([^<]+)</a>", r"\1", safe)
            story.append(Paragraph(safe.replace("\n", "<br/>"), styles["GuideBody"]))

story.append(Paragraph("Evidence boundaries", styles["GuideH2"]))
story.append(Paragraph("The test counts are local authored snapshot results. Token volumes and Pareto points are illustrative. Current guided clips show actual local macOS VS Code artifacts, not an authenticated Copilot run. See the HTML guide and media manifest for links and provenance.", styles["GuideBody"]))

def page(canvas, document):
    canvas.setStrokeColor(BLUE)
    canvas.setLineWidth(2)
    canvas.line(.68*inch, letter[1]-.42*inch, letter[0]-.68*inch, letter[1]-.42*inch)
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#5D7383"))
    canvas.drawString(.68*inch, .37*inch, "Developer workshop · synthetic example · 26 October 2026")
    canvas.drawRightString(letter[0]-.68*inch, .37*inch, str(document.page))

doc.build(story, onFirstPage=page, onLaterPages=page)
print(OUT / "presenter-guide.html")
print(OUT / "presenter-guide.pdf")
