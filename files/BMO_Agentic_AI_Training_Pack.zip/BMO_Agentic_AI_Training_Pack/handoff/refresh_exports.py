from __future__ import annotations

import html
import json
import shutil
import subprocess
import zipfile
from pathlib import Path

import pymupdf
from PIL import Image, ImageDraw, ImageFont
from pptx import Presentation

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT
source=ROOT/'build/v2/BMO_Agentic_AI_VS_Code_PDF_source.pdf'
shutil.copy2(source,OUT/'BMO_Agentic_AI_VS_Code.pdf')
data=json.loads((OUT/'slide_content.json').read_text(encoding='utf-8'))
assert len(data)==20
preview=OUT/'preview';preview.mkdir(exist_ok=True)
doc=pymupdf.open(OUT/'BMO_Agentic_AI_VS_Code.pdf');assert len(doc)==20
thumbs=[]
font=ImageFont.load_default()
for candidate in ['C:/Windows/Fonts/arial.ttf','/System/Library/Fonts/Supplemental/Arial.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']:
    if Path(candidate).is_file():
        font=ImageFont.truetype(candidate,17);break
for i,page in enumerate(doc,1):
    p=preview/f'slide-{i:02d}.png'
    page.get_pixmap(matrix=pymupdf.Matrix(1.2,1.2),alpha=False).save(p)
    im=Image.open(p).convert('RGB');im.thumbnail((480,270));thumbs.append(im)
canvas=Image.new('RGB',(2040,1530),'#DFE8EE');d=ImageDraw.Draw(canvas)
for i,im in enumerate(thumbs):
    x=15+(i%4)*510;y=15+(i//4)*302
    canvas.paste(im,(x,y));d.text((x,y+273),f'{i+1:02d}',font=font,fill='#003B71')
canvas.save(preview/'contact-all.jpg',quality=94)
for start in [0,10]:
    canvas=Image.new('RGB',(1535,1505),'#DFE8EE');d=ImageDraw.Draw(canvas)
    for j,im in enumerate(thumbs[start:start+10]):
        large=im.resize((720,405));x=20+(j%2)*760;y=10+(j//2)*290
        large.thumbnail((720,270));canvas.paste(large,(x,y));d.text((x,y+273),f'{start+j+1:02d}',font=font,fill='#003B71')
    canvas.save(preview/f'contact-{start//10+1}.jpg',quality=93)

slides=[]
for i,item in enumerate(data,1):
    slides.append({'title':item['title'],'image':f'preview/slide-{i:02d}.png','note':item['notes'],
                   'video':f"media/videos/{item['video']}.mp4" if item.get('video') else None})
encoded=json.dumps(slides,ensure_ascii=False).replace('</','<\\/')
html_doc='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Agentic AI — visual workshop</title><style>*{box-sizing:border-box}body{margin:0;background:#10283a;color:white;font:16px Arial,sans-serif}header{display:flex;gap:20px;align-items:center;padding:14px 22px;background:#003b71;height:58px}header a{color:white;text-decoration:none}#count{margin-left:auto}main{display:grid;place-items:center;padding:12px}#slide{max-width:97vw;max-height:calc(100vh - 142px);box-shadow:0 3px 24px #0007}footer{display:flex;justify-content:center;align-items:center;gap:12px;padding:8px}button{font:inherit;cursor:pointer;border:1px solid #71b6df;border-radius:5px;padding:9px 15px;background:#0075be;color:white}button:disabled{opacity:.4}#notes{padding:24px;line-height:1.65;max-width:1100px;margin:auto;white-space:pre-wrap;background:#193c55}#movie{display:none;position:fixed;inset:0;background:#000e;z-index:4;align-items:center;justify-content:center;flex-direction:column;gap:12px}video{max-width:94vw;max-height:80vh}#movie p{font-size:13px;color:#cae5f6}.hint{font-size:12px;color:#bad4e3}</style><header><a href="START_HERE.html">BMO / Visual workshop</a><span id="title"></span><span id="count"></span></header><main><img id="slide" alt="Presentation slide"></main><footer><button id="prev">← Previous</button><button id="next">Next →</button><button id="play" hidden>Play walkthrough</button><button id="toggle">Speaker notes</button><span class="hint">Arrow keys · F for full screen</span></footer><div id="notes" hidden></div><div id="movie"><video controls playsinline></video><p>Guided VS Code screenshots · instructor-authored example · actual macOS editor · not a live Copilot run</p><button id="close">Close</button></div><script>const slides=__DATA__;let i=0;const el=id=>document.getElementById(id);function show(){const s=slides[i];el('title').textContent=s.title;el('count').textContent=(i+1)+' / '+slides.length;el('slide').src=s.image;el('slide').alt='Slide '+(i+1)+': '+s.title;el('notes').textContent=s.note;el('play').hidden=!s.video;el('prev').disabled=i===0;el('next').disabled=i===slides.length-1;history.replaceState(null,'','#'+(i+1))}function step(n){i=Math.max(0,Math.min(slides.length-1,i+n));show()}el('prev').onclick=()=>step(-1);el('next').onclick=()=>step(1);el('toggle').onclick=()=>el('notes').hidden=!el('notes').hidden;el('play').onclick=()=>{const v=el('movie').querySelector('video');v.src=slides[i].video;el('movie').style.display='flex';v.play()};el('close').onclick=()=>{el('movie').querySelector('video').pause();el('movie').style.display='none'};document.addEventListener('keydown',e=>{if(e.key==='ArrowRight')step(1);if(e.key==='ArrowLeft')step(-1);if(e.key==='Escape')el('close').click();if(e.key.toLowerCase()==='f')document.documentElement.requestFullscreen?.()});i=Math.max(0,Math.min(19,(parseInt(location.hash.slice(1))||1)-1));show();</script></html>'''.replace('__DATA__',encoded)
(OUT/'Presentation.html').write_text(html_doc,encoding='utf-8')

prs=Presentation(OUT/'BMO_Agentic_AI_VS_Code.pptx');assert len(prs.slides)==20
outside=[]
for n,s in enumerate(prs.slides,1):
    for sh in s.shapes:
        if sh.left<0 or sh.top<0 or sh.left+sh.width>prs.slide_width+1000 or sh.top+sh.height>prs.slide_height+1000:outside.append((n,sh.name))
assert not outside,outside
with zipfile.ZipFile(OUT/'BMO_Agentic_AI_VS_Code.pptx') as z:
    movies=[p for p in z.namelist() if p.startswith('ppt/media/') and p.endswith('.mp4')]
    notes=[p for p in z.namelist() if p.startswith('ppt/notesSlides/notesSlide') and p.endswith('.xml')]
assert len(movies)==3 and len(notes)==20
(OUT/'VALIDATION.txt').write_text('''VISUAL EDITION — VALIDATION

20 widescreen PowerPoint slides; 20 PDF pages; speaker notes on every slide.
Three embedded H.264 guided walkthroughs (about 20 seconds each), with
standalone MP4s, real poster frames and transcripts. Video captions identify
these as guided actual VS Code screenshots of instructor-authored examples.

The same six named tests produce 3/6 for starter, 4/6 for the supplied
boundary-only patch and 6/6 for the reference. These are actual local code
results, not Copilot/model success rates. The student ZIP excludes answers.

Token quantities are explicitly illustrative budgets, not observed usage.
The conceptual Pareto slide has no numerical quality scores. Scheduled
checks on the supplementary numerical chart are not passed checks.

The native editor captures use macOS VS Code 1.143.1. The agent customization
editor uses the Local harness; Windows/Copilot actions are described in
notes and the handoff. No authenticated Copilot session was available.
Native Windows PowerPoint playback remains for the next agent to verify.

All diagrams, captions and code cards are editable PowerPoint elements.
Authentic screenshot originals and source hashes are retained. Public BMO
branding is a training draft, not an internally approved template or policy.
''',encoding='utf-8')
print(json.dumps({'slides':len(prs.slides),'pdf_pages':len(doc),'embedded_videos':len(movies),'speaker_notes':len(notes),'off_slide_shapes':outside},indent=2))
