"""Refresh the static and browser exports after rebuilding the PowerPoint."""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

import pymupdf
from PIL import Image, ImageDraw, ImageFont
from pptx import Presentation

ROOT = Path(__file__).resolve().parents[1]
STEM = 'BMO_Agentic_AI_VS_Code'
PACK = ROOT / 'BMO_Agentic_AI_Training_Pack.zip'


def libreoffice_path(given: str | None) -> str | None:
    if given:
        path = shutil.which(given) or (given if Path(given).is_file() else None)
        if not path:
            raise FileNotFoundError(f'LibreOffice executable not found: {given}')
        return path
    for name in ('libreoffice', 'soffice'):
        path = shutil.which(name)
        if path:
            return path
    for candidate in (
        '/Applications/LibreOffice.app/Contents/MacOS/soffice',
        'C:/Program Files/LibreOffice/program/soffice.exe',
        'C:/Program Files (x86)/LibreOffice/program/soffice.exe',
    ):
        if Path(candidate).is_file():
            return candidate
    return None


def select_pdf(given: str | None, office: str | None) -> Path:
    final = ROOT / f'{STEM}.pdf'
    if given:
        source = Path(given).expanduser().resolve()
        if not source.is_file():
            raise FileNotFoundError(source)
        if source != final.resolve():
            shutil.copy2(source, final)
        return final
    source_pptx = ROOT / f'{STEM}_PDF_source.pptx'
    if office:
        if not source_pptx.is_file():
            raise FileNotFoundError(source_pptx)
        with tempfile.TemporaryDirectory(prefix='bmo-pdf-') as tmp:
            subprocess.run([office, '-env:UserInstallation='+(Path(tmp)/'lo-profile').as_uri(),
                            '--headless', '--convert-to', 'pdf', '--outdir', tmp,
                            str(source_pptx)], check=True)
            rendered = Path(tmp) / f'{STEM}_PDF_source.pdf'
            if not rendered.is_file():
                raise RuntimeError('LibreOffice did not create the expected PDF')
            shutil.copy2(rendered, final)
        return final
    if final.is_file() and (not source_pptx.is_file() or final.stat().st_mtime >= source_pptx.stat().st_mtime):
        print('Using existing final PDF (no LibreOffice found).')
        return final
    raise RuntimeError('No current PDF available. Install LibreOffice or export '
                       f'{source_pptx.name} to PDF in PowerPoint and pass --pdf PATH.')


def font():
    for candidate in ('C:/Windows/Fonts/arial.ttf',
                      '/System/Library/Fonts/Supplemental/Arial.ttf',
                      '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'):
        if Path(candidate).is_file():
            return ImageFont.truetype(candidate, 18)
    return ImageFont.load_default()


def refresh(pdf: Path, repack: bool) -> dict:
    content = json.loads((ROOT / 'slide_content.json').read_text(encoding='utf-8'))
    manifest = json.loads((ROOT / 'media/manifest.json').read_text(encoding='utf-8'))
    media = {item['id']: item for item in manifest.get('items', [])}
    pptx = ROOT / f'{STEM}.pptx'
    prs = Presentation(pptx)
    if len(prs.slides) != len(content):
        raise ValueError('PowerPoint slide count differs from slide_content.json')
    if len(prs.slides) != 28:
        raise ValueError(f'Expected 28 slides, found {len(prs.slides)}')
    with zipfile.ZipFile(pptx) as package:
        movies = [name for name in package.namelist()
                  if name.startswith('ppt/media/') and name.lower().endswith('.mp4')]
    if len(movies) != 4:
        raise ValueError(f'Expected four embedded MP4s, found {len(movies)}')
    with pymupdf.open(pdf) as document:
        if len(document) != len(prs.slides):
            raise ValueError('PDF page count differs from PowerPoint slide count')
        preview = ROOT / 'preview'
        preview.mkdir(exist_ok=True)
        thumbs = []
        for index, page in enumerate(document, 1):
            path = preview / f'slide-{index:02d}.png'
            page.get_pixmap(matrix=pymupdf.Matrix(1.5, 1.5), alpha=False).save(path)
            with Image.open(path) as source:
                thumb = source.convert('RGB')
                thumb.thumbnail((480, 270))
                thumbs.append(thumb)
        for start in (0, 14):
            canvas = Image.new('RGB', (1540, 1540), '#E0E7ED')
            pen = ImageDraw.Draw(canvas)
            for offset, thumb in enumerate(thumbs[start:start + 14]):
                x = 20 + (offset % 3) * 510
                y = 15 + (offset // 3) * 302
                canvas.paste(thumb, (x, y))
                pen.text((x, y + 274), f'{start + offset + 1:02d}', fill='#003B71', font=font())
            canvas.save(preview / f'contact-{start // 14 + 1}.jpg', quality=93)

    browser_slides = []
    for index, (slide, item) in enumerate(zip(prs.slides, content), 1):
        video = item.get('video')
        video_meta = media.get(video, {}) if video else {}
        browser_slides.append({
            'title': item['title'].replace('\n', ' '),
            'image': f'preview/slide-{index:02d}.png',
            'note': slide.notes_slide.notes_text_frame.text,
            'video': f'media/videos/{video}.mp4' if video else None,
            'video_context': (video_meta.get('caption') or video_meta.get('provenance_note') or
                'Video companion; see media manifest for capture details') if video else '',
        })
    html_path = ROOT / 'Presentation.html'
    html = html_path.read_text(encoding='utf-8')
    encoded = json.dumps(browser_slides, ensure_ascii=False).replace('</', '<\\/')
    html, count = re.subn(r'const slides=.*?;let i=0;',
                          lambda _: 'const slides=' + encoded + ';let i=0;',
                          html, count=1, flags=re.DOTALL)
    if count != 1:
        raise ValueError('Could not locate browser slide data in Presentation.html')
    html = re.sub(r'<p(?: id="videoContext")?>.*?</p><button id="close">',
                  '<p id="videoContext"></p><button id="close">',
                  html, count=1, flags=re.DOTALL)
    if "el('videoContext').textContent=s.video_context" not in html:
        html = html.replace("el('play').hidden=!s.video;",
                            "el('play').hidden=!s.video;el('videoContext').textContent=s.video_context;")
    html_path.write_text(html, encoding='utf-8')

    if repack:
        with zipfile.ZipFile(PACK, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for path in sorted(ROOT.rglob('*')):
                if (not path.is_file() or path == PACK or path.name == '.DS_Store'
                        or '__pycache__' in path.parts):
                    continue
                archive.write(path, Path('BMO_Agentic_AI_Training_Pack') / path.relative_to(ROOT))
    result = {'slides': len(prs.slides), 'pdf_pages': len(browser_slides),
              'embedded_videos': len(movies), 'browser_notes': len(browser_slides),
              'repacked': repack}
    print(json.dumps(result, indent=2))
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description='Refresh PDF, preview images, browser presentation and training ZIP.')
    parser.add_argument('--pdf', metavar='PATH', help='Use a PDF exported manually from the poster-frame PowerPoint.')
    parser.add_argument('--libreoffice', metavar='EXE', help='Path to LibreOffice/soffice; otherwise auto-detected.')
    parser.add_argument('--no-repack', action='store_true', help='Leave the training ZIP untouched.')
    args = parser.parse_args()
    refresh(select_pdf(args.pdf, libreoffice_path(args.libreoffice)), not args.no_repack)


if __name__ == '__main__':
    main()
