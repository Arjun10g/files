from __future__ import annotations

import argparse
import json
import math
import subprocess
import shutil
from pathlib import Path

from PIL import Image
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT
MEDIA = OUT / 'media'
W, H = 13.333333, 7.5
BLUE, NAVY, RED = '0075BE', '003B71', 'ED1C24'
INK, MUTED, PALE, GREY, WHITE, TEAL = '162A3A', '596D7D', 'EAF4FB', 'F3F5F7', 'FFFFFF', '007E80'
FONT = 'Arial'

SRC = {
    'setup': 'https://code.visualstudio.com/docs/setup/copilot',
    'quick': 'https://code.visualstudio.com/docs/agents/quickstart',
    'loop': 'https://code.visualstudio.com/docs/agents/concepts/agents',
    'chat': 'https://code.visualstudio.com/docs/chat/chat-overview',
    'context': 'https://code.visualstudio.com/docs/chat/copilot-chat-context',
    'instructions': 'https://code.visualstudio.com/docs/agent-customization/custom-instructions',
    'models': 'https://code.visualstudio.com/docs/agent-customization/language-models',
    'harness': 'https://code.visualstudio.com/docs/agents/run/agent-harnesses',
    'plan': 'https://code.visualstudio.com/docs/agents/run/planning',
    'window': 'https://code.visualstudio.com/docs/agents/run/agents-window',
    'agents': 'https://code.visualstudio.com/docs/agent-customization/custom-agents',
    'subagents': 'https://code.visualstudio.com/docs/agents/run/subagents',
    'permissions': 'https://code.visualstudio.com/docs/agents/run/approvals',
    'security': 'https://code.visualstudio.com/docs/agents/run/security',
    'review': 'https://code.visualstudio.com/docs/agents/run/review-code-edits',
    'test': 'https://code.visualstudio.com/docs/agents/guides/test-code-with-ai',
    'recover': 'https://code.visualstudio.com/docs/agents/guides/get-agent-back-on-track',
    'sessions': 'https://code.visualstudio.com/docs/agents/run/sessions/manage-sessions',
    'cost': 'https://docs.github.com/en/copilot/reference/copilot-billing/models-and-pricing',
    'customgh': 'https://docs.github.com/en/copilot/how-tos/copilot-in-your-ide/use-copilot-agents/use-custom-agents?tool=vscode',
}

SLIDES = []


def data(title, section, kind, **kw):
    d = dict(title=title, section=section, kind=kind, **kw)
    SLIDES.append(d)
    return d


data('Agentic AI\nin VS Code', 'BMO • DEVELOPER WORKSHOP', 'cover',
     subtitle='Turn a clear goal into a verified code change.',
     note='Welcome. This workshop teaches GitHub Copilot inside VS Code, using the access participants already have. Windows instructions are primary. All lab data is synthetic. This is a training draft using public BMO branding, not a statement of internal BMO policy. Four official Windows demo excerpts illustrate UI actions; they do not show an authenticated BMO session or our lab running in Copilot.',
     sources=['quick', 'harness'])
data('By the end, you can ship one small change', '01 / ORIENT', 'journey',
     note='Ask participants to pick one recent coding task. In roughly 55–60 minutes we will make its goal explicit, choose roles, validate a patch, and review the diff. The hands-on lab takes 12 minutes; allow a few minutes for setup. The aim is accepted, evidence-backed output, not a larger number of agents.', sources=[])
data('Preflight: check the session you actually have', '01 / ORIENT', 'screen', image='agent-session-editor-select-harness-role-2',
     steps=[('Open the starter folder', 'File → Open Folder → lab/starter. Sign in with your work GitHub account.'),
            ('Select Copilot', 'Check the harness, model and permissions before the first request.'),
            ('Run the baseline', 'Terminal → New Terminal; run the unittest command in README.txt.')],
     takeaway='Missing models or controls depend on version, subscription and organization policy.',
     note='Windows setup: open the participant starter folder, not the lab parent or solution. Use Accounts → Sign in with GitHub if needed, and confirm the account has Copilot access. Check the Session Target UI control says Copilot. The screenshot is an official cropped control detail, not a full Windows desktop. In the lab run py -3 -m unittest discover -s tests -v; a failing starter is expected. If py is missing, use python. If only one model or ordinary chat is available, use the same role prompts sequentially and run tests yourself. No separate AI application or API key is needed.', sources=['setup', 'quick', 'harness'])
data('An agent acts, observes and tries again', '01 / ORIENT', 'loop', image='terminal-command-output',
     note='An agent uses a model to choose a next action, tools to inspect or change the environment, and tool results to decide what comes next. The terminal tool actually runs a test; the model can still misread its output. Human ownership sits outside the loop: set the goal, bound actions, inspect evidence, and accept the result. Ask: which component actually runs unittest?', sources=['loop'])
data('Use the smallest interaction that solves the task', '01 / ORIENT', 'choices', image='agent-session-select-harness-role',
     note='Use inline assistance for a tiny local change; Ask for explanation or repository research; /plan for uncertainty; Agent for bounded multi-step implementation. Planning effort should scale with ambiguity and consequence. The official screenshot is a control detail, not a guarantee of every menu item in each tenant. Copilot Plan invocation and UI can vary with the selected harness and client version.', sources=['chat', 'harness', 'plan'])
data('Our bug: the validator accepts bad money inputs', '02 / SPECIFY', 'screen', image='local-lab-starter', fallback='explorer-and-chat-view',
     steps=[('A tiny, inspectable API', 'validate_payment(amount, currency) returns an immutable Payment.'),
            ('A real red baseline', 'The supplied starter fails its contract tests. Read one concrete failure.'),
            ('One-file scope', 'Repair payments_demo/validation.py. Keep the API and tests unchanged.')],
     takeaway='Example: 10.5 CAD → 10.50 CAD. Reject −1, NaN and unsupported currencies.',
     note='The synthetic lab is a validation exercise, not production payment processing or BMO business rules. Open payments_demo/validation.py and tests/test_validation.py. The starter intentionally accepts invalid amounts, rounds extra precision and weakly validates currency. Payment is already a frozen dataclass; keep it immutable. The local screenshot, if available, is an actual VS Code 1.143.1 macOS capture; Windows actions are described in the handout. Baseline results are real local tests, not an AI transcript. Do not imply an agent produced these results. Expected function contract is in README.txt.', sources=[])
data('Replace “fix it” with a task contract', '02 / SPECIFY', 'contract', image='copilot-chat-view-chat-variables',
     note='Show the five elements of a useful task: outcome, context, constraints, verification and stopping point. Read the prompt aloud once; learners can copy the full version from prompts.txt. It names the file and API, specifies allowed types and errors, requires real tests and asks the agent to stop at a reviewable diff. This is an instructor-authored prompt, not a captured successful agent response. The attached context screenshot is an official UI reference.', sources=['context'])
data('Attach the code, the test and the exact failure', '02 / SPECIFY', 'screen', image='copilot-chat-view-chat-variables',
     steps=[('Choose relevant files', 'Use Add Context / # to attach validation.py and test_validation.py.'),
            ('Show the actual symptom', 'Paste one exact failing assertion and the command that produced it.'),
            ('Ask for missing context', '“Which requirement or file would change your approach?”')],
     takeaway='Keep requirements and evidence in context; remove unrelated logs and conversation history.',
     note='The official screenshot shows the context picker; available entries vary by version and extensions. Use visible Add Context controls or file drag/drop rather than memorizing a context token that might change. Do not paste a whole repository when two files and one failure are enough. Never attach credentials or real customer records. Ask the agent to cite relevant files so you can check it used the intended context.', sources=['context'])
data('Put stable project rules in one place', '02 / SPECIFY', 'screen', image='local-lab-instructions', fallback='create-instructions-file',
     steps=[('Create repository guidance', '.github/copilot-instructions.md records commands and invariants.'),
            ('Keep it short and testable', 'Use Decimal; validate finite values; preserve the API; synthetic inputs only.'),
            ('Keep the task in the prompt', 'Name allowed files and this change’s acceptance criteria per request.')],
     takeaway='Instructions guide behavior. Permissions, tests and review provide the controls.',
     note='The lab starter already contains .github/copilot-instructions.md. Open it in Explorer and show the exact unittest command. Repository-wide guidance should be concise and consistent. Avoid contradictory copies across several instruction formats. Feature discovery and instruction application can differ by harness and organization. When instruction support is disabled, use the same information in the copied role prompt. Do not describe prose instructions as a security boundary.', sources=['instructions'])
data('The responsibility pyramid', '03 / DIRECT', 'pyramid',
     note='This is a responsibility pattern. Human owner decides business correctness and acceptance. A capable planner/integrator decomposes work and reconciles findings. Bounded workers write a small patch; independent reviewers challenge it. The foundation is executable evidence: tests, diffs and relevant measurements. You can run these roles sequentially using a single Copilot chat or model. Drawing a pyramid does not create native subagents. Use one owner per output and one integration point.', sources=[])
data('Spend reasoning where it changes the result', '03 / DIRECT', 'models', image='model-dropdown-change-model-v2',
     note='Use a capable reasoning model for ambiguous requirements, architecture and consequential review; use a reliable lower-cost option for a clear, bounded patch. Examples, only if allowed in your picker: GPT-6 Astra for planning, GPT-6 Sol for a patch, GPT-6 Luna for a very mechanical task. These are examples, not a universal capability ranking. GitHub’s current model pricing lists these models, but availability and pricing depend on plan and policy. Costs include input, output, cache and orchestration requests. Compare total time, rework and accepted output. If the worker repeats the same failure or an assumption changes, bring the evidence back to the planner. The displayed model-picker screenshot is an older Local UI reference, not the current available model list.', sources=['models', 'cost'])
data('Model choice and permission are separate controls', '03 / DIRECT', 'screen', image='chat-approve-tool',
     steps=[('Model / Auto', 'Chooses reasoning within the models available to your account.'),
            ('Tools and permissions', 'Control what actions can run, and when you must approve them.'),
            ('Read each proposed action', 'Check the command, path and network target before approving.')],
     takeaway='A stronger model does not unlock a disabled feature or make a risky command safe.',
     note='The screenshot is an official approval dialog detail. Current Copilot and legacy Local labels differ. Use your tenant’s ordinary/manual permission configuration. Examine writes, installs, remote calls and shell commands. Approve only what the bounded task needs; this workshop does not require broad approval bypass. Treat repository documents, tool output and web content as data that can include misleading instructions. Use synthetic input and approved integrations. Auto is a model routing choice, not a tool permission or policy override.', sources=['permissions', 'security', 'models'])
data('Watch 1: create a session with a clear boundary', '03 / DIRECT', 'video', video='agents-window-overview',
     watch='Notice the selected folder and the separate worktree control.',
     apply='Then use /plan in Copilot: inspect files, assumptions and tests before implementation.',
     note='Play the 30-second official Windows excerpt. It is from Microsoft’s May 2026 demo and visibly uses the Copilot CLI UI, not our lab or a BMO tenant. Current Copilot control names may differ. The clip demonstrates session and worktree selection only. After the clip, show the lab PLAN prompt from prompts.txt: request a plan without edits. In current Copilot, /plan can offer Review Plan, Approve Plan Only and Implement Plan. If available, choose Approve Plan Only, select the implementation model, switch from Plan to Interactive, and submit the bounded implementation request. When these controls are absent, use a plan-only prompt then a separate implementation prompt. Do not claim the clip demonstrates this plan flow.', sources=['window', 'plan'])
data('A worker needs a compact handoff', '04 / BUILD', 'worker', image='agent-mode-select-tools',
     note='Give the worker a self-contained work item: a concrete goal, allowed files, invariants, exact checks and required return format. This improves the chance that a lower-cost model can solve it. Ask it to report files changed, commands actually run, results and unresolved assumptions. A suggested command is not evidence it ran. Do not grant more tools than needed. The screenshot is a Local-harness tool-picker reference; use the current Copilot tool controls available in the session. Full prompt lives in the lab’s prompts.txt.', sources=['permissions'])
data('Watch 2: make the task’s context explicit', '04 / BUILD', 'video', video='agents-window-session-flow',
     watch='Observe how task context appears before work begins.',
     apply='For our lab, attach only the contract, validation.py, tests and the red baseline.',
     note='Play the 30-second official Windows clip. The reference demo uses GitHub/MCP context; those integrations are not required for this workshop and are not assumed to be approved in the participant tenant. The transferable lesson is explicit context. Our exercise stays local and uses the provided files. Before the worker acts, inspect the planned one-file scope. Current Copilot writes save directly, so use a disposable branch or copy, and review the resulting file diff.', sources=['window', 'context', 'review'])
data('Role prompts and subagents are different mechanisms', '04 / BUILD', 'subagents', image='agents-window-follow-subagents-read-only-chat',
     note='Manual workflow: the human changes role/model and passes the plan, code and test evidence. Native delegation: an agent invokes an actual delegation tool and receives a separate result. Current Copilot uses task; Local uses runSubagent. Do not rely on tool names when natural-language requests suffice. The official subagent trace illustrates monitored child activity, not proof that all tenant models can independently route workers. Current GitHub and VS Code docs differ in details of model inheritance and nesting. Use only observed, supported options; a flat workflow is sufficient. Context isolation does not imply filesystem isolation. One-model sequential prompts are a valid fallback.', sources=['subagents'])
data('Parallelize review; give shared code one writer', '04 / BUILD', 'parallel', image='agents-window-new-worktree',
     note='Run correctness and edge-case reviews in parallel when the tasks are independent and reviewers can remain read-only. Keep one writer responsible for validation.py; serialize fixes and the final integration/test pass. Two agents editing the same file can conflict even when their conversation contexts are isolated. Worktrees provide a separate filesystem branch for larger independent tasks, but results still require integration review and tests. Each delegated task needs its own complete contract and expected output.', sources=['subagents', 'window'])
data('Save recurring roles as custom agents', '04 / BUILD', 'screen', image='create-custom-agent-2',
     steps=[('Open customizations', 'Choose the Copilot harness, then Chat: Open Customizations → Agents.'),
            ('Create a reviewer profile', 'Use .github/agents/*.agent.md; define role, scope and review criteria.'),
            ('Select supported tools', 'Choose read/search tools in that harness. Add a model only if available.')],
     takeaway='Optional planner, worker and reviewer profiles are included in lab/starter/.github/agents.',
     note='Current VS Code recommends the Agent Customizations editor; the screenshot shows that editor. Tool names, supported frontmatter and model behavior depend on harness. Let the UI generate valid fields, then inspect the file. Review-only instructions alone do not enforce read-only operation: choose an appropriate tool set. Do not teach Local-only YAML handoffs as a Copilot prerequisite. The lab deliberately provides normal prompts so participants do not need custom agent support. A minimal role: independently inspect validate_payment against README; return a minimal failing input, impact and evidence; do not modify files.', sources=['agents', 'customgh'])
data('Ask a skeptic for a counterexample', '05 / CHALLENGE', 'adversarial',
     note='Start a fresh reviewer context and supply the contract, code, diff and exact test output. Ask for a failing input with expected versus actual behavior, not a general approval. Decimal("NaN") parses successfully but is not valid money for this exercise. A different context or model can help surface assumptions; it does not guarantee independence or correctness. Label candidate problems as hypotheses until reproduced. To improve coverage, split domain correctness and input robustness across reviewers. Keep them read-only. In this lab, keep the supplied tests unchanged: reproduce any real finding with a direct input, fix the allowed file and re-run all tests. In a real project, add an appropriate regression test after confirming a bug.', sources=['test'])
data('Watch 3: monitor work instead of guessing', '05 / CHALLENGE', 'video', video='agents-window-agent-work',
     watch='Watch the worktree/session status as the background agent works.',
     apply='Inspect the actual tools and results. Ask a fresh reviewer to try NaN, −1 and 1.001.',
     note='Play the 29-second official Windows excerpt. The clip shows background/session work in the May 2026 Copilot CLI demo, not an adversarial review of our code. Use it to teach observability: open a running session and inspect what actually happened. The lab’s adversarial pass is performed with the REVIEW prompt and supplied tests. A candidate finding must be reproducible. A reviewer proposing Decimal("NaN") is only a hypothesis until the input is run against the implementation. Do not fabricate a reviewer answer or imply the clip found this bug.', sources=['window', 'subagents', 'test'])
data('“Done” means reproducible evidence', '05 / CHALLENGE', 'screen', image='local-lab-solution', fallback='review-changes-panel',
     steps=[('Run the exact checks', 'py -3 -m unittest discover -s tests -v → all 7 methods pass.'),
            ('Read the saved diff', 'Only validation.py changes. No test deletions or unrelated refactor.'),
            ('Check the contract yourself', 'NaN, Infinity, negatives, floats, precision and currency all behave as specified.')],
     takeaway='The solution was tested locally. Participants must run and inspect their own patch.',
     note='The reference solution has seven passing unittest methods on the actual local Python environment. Participant tests run on Windows with py -3 or python. Passing these tests is required but not a proof of every possible input: inspect the contract and relevant boundaries. Current Copilot saves file edits directly, so use Source Control or the Changes view to inspect actual diffs. Legacy Local screenshots may show Keep/Undo, but those controls are not the acceptance model for current Copilot. Existing repo-wide lint/type/build checks still apply when this method is used in a real project.', sources=['review', 'test'])
data('Optimize accepted work, not generated lines', '06 / IMPROVE', 'efficiency', image='chat-context-window-control',
     note='Use the measurement card as an instructor-authored tracking template, not claimed performance data. Track time to accepted patch, test/review rework and model usage. Keep the work item small, summarize durable decisions, start a clean session when context becomes noisy, and avoid repeating failed attempts without new evidence. A larger number of subagents can increase total usage even when the main context shrinks. Current GitHub model billing depends on tokens and model rates; follow organization budget controls and current billing docs. No fixed cost saving or productivity improvement is promised.', sources=['cost', 'sessions'])
data('When it drifts: stop, inspect, narrow and retry', '06 / IMPROVE', 'screen', image='chat-restore-checkpoint',
     steps=[('Stop and inspect first', 'Review the exact changed files and identify the first wrong assumption.'),
            ('Give one corrective fact', 'Attach the failure; restate allowed files; remove unrelated requirements.'),
            ('Recover deliberately', 'Use supported session recovery or revert a reviewed Git diff. Re-run checks.')],
     takeaway='A session checkpoint is not a substitute for Git history or external-system rollback.',
     note='The visible Restore Checkpoint image is an older Local/Chat UI reference. Current Copilot recovery and availability differ; use the controls present in the selected harness. A checkpoint or chat reset does not undo side effects such as a remote API call. Before reverting files, preserve unrelated work and inspect the target diff. If the same model fails repeatedly, return evidence to the planner, narrow the scope or try another allowed model. Missing policy-controlled features require an admin change, not a different prompt.', sources=['recover', 'review'])
data('Use the method within a clear data boundary', '06 / IMPROVE', 'screen', image='chat-approve-url',
     steps=[('Use synthetic inputs here', 'No customer data, credentials or production endpoints belong in this exercise.'),
            ('Treat fetched text as data', 'A repository file or webpage cannot authorize new actions for you.'),
            ('Keep access proportional', 'Only approved tools/integrations; no broad bypass needed for the local lab.')],
     takeaway='This training demonstrates a workflow. Apply BMO’s actual policies in your environment.',
     note='Do not invent BMO policy. The synthetic lab needs no network, third-party Python packages or external system access to run tests. The reference screenshot shows a URL approval detail and demonstrates where to inspect a proposed network action. Prompt injection can appear in source files, issue text, tool output and web content. Separate task instructions from untrusted content and verify consequential actions. Choosing a capable model does not remove these responsibilities.', sources=['security', 'permissions'])
data('Your turn: one writer, one skeptic, twelve minutes', '07 / PRACTICE', 'exercise',
     note='Allow 12 minutes. Participants work in a copy of lab/starter only; the facilitator keeps lab/solution separate. 2 minutes: run red baseline and request a plan without edits. 5 minutes: use the IMPLEMENT prompt, optionally select a lower-cost model, and restrict edits to payments_demo/validation.py. 3 minutes: use a fresh REVIEW prompt and try an adversarial input; reproduce and fix any real finding. A sound patch may have no finding. 2 minutes: run all seven methods, inspect the one-file diff and report evidence. If Copilot is not available, a pair can discuss the same contract and make the small patch manually; preserve the checks. The supplied prompts include exact commands and acceptance rules.', sources=[])
data('Watch 4: inspect the result before accepting it', '07 / PRACTICE', 'video', video='agents-window-review-changes',
     watch='Observe the browser result and the saved file diff together.',
     apply='Debrief: show your one-file diff, exact test result and one adversarial input.',
     note='Play the 30-second official Windows excerpt. It illustrates browser validation and diff review in a portfolio example; it is not the lab solution running in Copilot. Ask two participants to give a 20-second evidence report: what changed, command/result, and remaining uncertainty. The facilitator may open the separate lab/solution for discussion after participants finish. Expected solution: frozen Payment dataclass, Decimal/string input only, finite/nonnegative amount, exact uppercase CAD/USD, no silent rounding, two displayed decimals. Seven unittest methods pass locally. A screenshot or confident agent message is not enough to accept an unreviewed patch.', sources=['window', 'review'])
data('Use this check before every AI-assisted commit', '08 / TAKE AWAY', 'checklist', image='uncommitted-changes',
     note='Walk through six acceptance checks: goal and scope still correct; one owner/integration point; diff reviewed; relevant checks run and recorded; adversarial concern reproduced or resolved; data and tool permissions appropriate. Tests are not a replacement for human review, and the human remains responsible for business correctness. Never equate Keep, save, or an AI-written summary with production readiness. The official image illustrates an uncommitted change selector, not a captured lab result.', sources=['review'])
data('Take the workflow back to your next task', '08 / TAKE AWAY', 'resources',
     note='Point to the offline media index for all original-resolution screenshots and separate MP4 files. The PDF is static; clips play in PowerPoint or the offline media index. The facilitator guide and prompt cards contain Windows commands and full role prompts. Public documentation was checked on 26 October 2026. Docs may reuse older visuals, so the media manifest records capture caveats. The official Windows clips are from May 2026 Copilot CLI; the current Copilot instructions are separately verified. Native Windows PowerPoint playback has not been tested on this macOS production machine, so the MP4 fallback is supplied. BMO logo is public artwork, reproduced unmodified from a Wikimedia copy attributed to Bank of Montreal and linked to its official BMO source. Astra agents planned the workshop; Sol execution produced the artifacts.', sources=['quick', 'plan', 'subagents', 'agents', 'cost', 'review'])


def col(hexstr):
    return RGBColor.from_string(hexstr)


def rect(s, x, y, w, h, fill, line=None, radius=False):
    sh = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE,
                            Inches(x), Inches(y), Inches(w), Inches(h))
    sh.fill.solid(); sh.fill.fore_color.rgb = col(fill)
    sh.line.fill.background() if not line else None
    if line:
        sh.line.color.rgb = col(line); sh.line.width = Pt(1)
    if radius:
        sh.adjustments[0] = .12
    return sh


def txt(s, value, x, y, w, h, size=18, color=INK, bold=False, font=FONT,
        align=None, margin=0, valign=MSO_ANCHOR.TOP):
    sh = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = sh.text_frame; tf.clear(); tf.word_wrap = True
    tf.margin_left = tf.margin_right = Inches(margin)
    tf.margin_top = tf.margin_bottom = Inches(margin)
    tf.vertical_anchor = valign
    for i, line in enumerate(str(value).split('\n')):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = line; p.font.name = font; p.font.size = Pt(size)
        p.font.bold = bold; p.font.color.rgb = col(color)
        p.space_after = Pt(5); p.space_before = Pt(0)
        p.line_spacing = 1.08
        if align is not None: p.alignment = align
    return sh


def line(s, x1, y1, x2, y2, color=BLUE, width=2):
    sh = s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
    sh.line.color.rgb = col(color); sh.line.width = Pt(width)
    return sh


def pill(s, value, x, y, w, fill=PALE, color=NAVY, size=11):
    rect(s, x, y, w, .32, fill, radius=True)
    return txt(s, value, x+.07, y+.045, w-.14, .23, size, color, True)


def picture(s, path, x, y, w, h, background='1E1E1E', link=None):
    im = Image.open(path); iw, ih = im.size
    ratio = min(w / iw, h / ih); pw, ph = iw * ratio, ih * ratio
    rect(s,x,y,w,h,background)
    sh=s.shapes.add_picture(str(path), Inches(x+(w-pw)/2), Inches(y+(h-ph)/2), width=Inches(pw), height=Inches(ph))
    if link: sh.click_action.hyperlink.address=link
    return sh


def marker(s, n, x, y):
    sh=s.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x), Inches(y), Inches(.29), Inches(.29))
    sh.fill.solid();sh.fill.fore_color.rgb=col(BLUE);sh.line.fill.background()
    txt(s,str(n),x,y+.025,.29,.24,11,WHITE,True,align=PP_ALIGN.CENTER)


def get_asset(key, fallback=None):
    p=MEDIA/'screenshots'/f'{key}.png'
    if not p.exists() and fallback:
        key=fallback;p=MEDIA/'screenshots'/f'{key}.png'
    if not p.exists(): raise FileNotFoundError(p)
    return key,p


def meta_for(key):
    return next((x for x in MANIFEST.get('items',[]) if x['id']==key),{})


def image_label(key):
    m=meta_for(key)
    if m.get('caption'):
        return m['caption']
    if key.startswith('local-'):
        return 'Actual local lab capture • VS Code 1.143.1 • macOS • 26 Oct 2026'
    if key in ['chat-restore-checkpoint','chat-checkpoint-changed-files','model-dropdown-change-model-v2','chat-context-window-control','agent-mode-select-tools']:
        return 'Official reference • earlier Local / Chat UI • current Copilot steps in notes'
    os=m.get('os','')
    if 'Windows' in os:return 'Official VS Code reference • Windows • full source image retained'
    return 'Official VS Code reference • source UI detail; OS/version varies'


def source_caption(s,key,x=.55,y=6.43,w=8.78):
    label=image_label(key)
    sh=txt(s,label,x,y,w,.25,9,MUTED)
    m=meta_for(key)
    if m.get('source_page_url'):
        sh.click_action.hyperlink.address=m['source_page_url']


def header(s,d,n):
    s.background.fill.solid();s.background.fill.fore_color.rgb=col(WHITE)
    rect(s,0,0,W,.065,BLUE)
    txt(s,d['section'],.55,.26,10,.25,10,BLUE,True)
    s.shapes.add_picture(str(ROOT/'media/branding/BMO_logo.png'), Inches(11.66), Inches(.19), width=Inches(1.1))
    txt(s,d['title'],.55,.73,12.2,.70,29,NAVY,True)
    line(s,.55,7.08,12.78,7.08,'D5DFE7',.7)
    txt(s,'BMO  /  Developer enablement  /  Training draft',.55,7.19,8,.19,8,MUTED)
    txt(s,f'{n:02d} / 28',11.9,7.16,.9,.23,9,MUTED,align=PP_ALIGN.RIGHT)


def takeaway(s,t):
    rect(s,.55,6.68,12.23,.31,PALE)
    txt(s,t,.68,6.727,11.95,.24,11,NAVY,True)


def rail(s,steps,x=9.58,y=1.70,w=3.13):
    for i,(head,body) in enumerate(steps):
        yy=y+i*1.48
        marker(s,i+1,x,yy)
        txt(s,head,x+.42,yy-.01,w-.42,.61,15.5,NAVY,True)
        txt(s,body,x+.42,yy+.64,w-.42,.78,14,INK)


def screenshot(s,d):
    key,path=get_asset(d['image'],d.get('fallback'))
    picture(s,path,.55,1.60,8.78,4.75,link=meta_for(key).get('source_asset_url'))
    source_caption(s,key)
    rail(s,d['steps'])
    takeaway(s,d['takeaway'])
    return key


def small_image(s,key,x,y,w,h):
    key,path=get_asset(key)
    picture(s,path,x,y,w,h,link=meta_for(key).get('source_asset_url'))
    return key


def block(s,x,y,w,number,title,body,fill=PALE):
    rect(s,x,y,w,1.42,fill,radius=True)
    txt(s,number,x+.18,y+.18,.6,.4,15 if len(number)>2 else 22,BLUE,True)
    txt(s,title,x+.86,y+.16,w-1.03,.35,18,NAVY,True)
    txt(s,body,x+.86,y+.58,w-1.05,.65,14.5,INK)


def arrow(s,x,y,w=.35,h=.28):
    sh=s.shapes.add_shape(MSO_SHAPE.CHEVRON, Inches(x), Inches(y), Inches(w), Inches(h))
    sh.fill.solid();sh.fill.fore_color.rgb=col(BLUE);sh.line.fill.background()


def codebox(s,value,x,y,w,h,size=16):
    rect(s,x,y,w,h,'102B40',radius=True)
    return txt(s,value,x+.21,y+.19,w-.42,h-.30,size,'EAF4FB',font='Consolas')


def make_slide(prs,d,n,pdf=False):
    s=prs.slides.add_slide(prs.slide_layouts[6]); kind=d['kind']; used=[]
    if kind=='cover':
        rect(s,0,0,W,H,BLUE);rect(s,0,0,5.75,H,NAVY)
        rect(s,.55,.36,1.72,.68,WHITE,radius=True)
        s.shapes.add_picture(str(ROOT/'media/branding/BMO_logo.png'),Inches(.75),Inches(.46),width=Inches(1.31))
        txt(s,'DEVELOPER WORKSHOP',.6,1.47,5.0,.4,12,'97D5F6',True)
        txt(s,d['title'],.6,2.04,6.4,1.80,46,WHITE,True)
        txt(s,d['subtitle'],.65,4.15,4.65,1.12,24,WHITE)
        txt(s,'GitHub Copilot  •  Windows\nSynthetic Python payments lab',.65,5.63,5.1,.75,15,'C9E7F8')
        used.append(small_image(s,'agents-window-ui-annotated',6.14,1.90,6.65,4.25))
        txt(s,'PUBLIC VS CODE REFERENCE  •  REAL UI',6.2,6.35,6,.3,10,WHITE,True)
        txt(s,'26 October 2026  /  Public BMO branding · training draft',.65,7.04,10,.25,10,WHITE)
    else:
        header(s,d,n)
        if kind=='screen': used.append(screenshot(s,d))
        elif kind=='journey':
            txt(s,'One goal. Three roles. Evidence before acceptance.',.55,1.57,11.8,.65,23,INK)
            for i,(t,b) in enumerate([('SPECIFY','Make the outcome and limits explicit.'),('PLAN','Resolve uncertainty before editing.'),('BUILD','Give one worker a small contract.'),('CHALLENGE','Use a skeptic to seek a failing input.')]):
                x=.55+i*3.10
                rect(s,x,2.6,2.92,2.35,PALE,radius=True)
                txt(s,f'0{i+1}',x+.2,2.84,2.4,.48,28,BLUE,True)
                txt(s,t,x+.2,3.45,2.4,.4,18,NAVY,True)
                txt(s,b,x+.2,4.02,2.4,.75,16,INK)
            rect(s,.55,5.4,12.22,.81,NAVY,radius=True)
            txt(s,'12-minute lab',.8,5.62,2.5,.4,21,WHITE,True)
            txt(s,'Repair one file → run tests → inspect the diff → explain the evidence.',3.4,5.64,8.9,.4,17,WHITE)
            takeaway(s,'Works with one Copilot model. Additional models and native delegation are optional.')
        elif kind=='loop':
            for i,(t,b) in enumerate([('Goal','Contract + boundaries'),('Reason','Choose next action'),('Act','Read / edit / run'),('Observe','Inspect the result')]):
                x=.55+i*2.02
                rect(s,x,2.08,1.78,1.35,PALE,radius=True)
                txt(s,t,x+.13,2.27,1.52,.35,20,NAVY,True)
                txt(s,b,x+.13,2.82,1.52,.4,12.5,INK)
                if i<3:arrow(s,x+1.82,2.6,.15,.22)
            line(s,7.45,3.58,2.63,3.58,BLUE,2)
            txt(s,'Repeat only while the task still needs work',1.1,3.82,7.3,.4,17,BLUE,True)
            used.append(small_image(s,'terminal-command-output',8.95,1.98,3.82,2.58))
            txt(s,'A real tool result',9.08,4.76,3.52,.4,17,NAVY,True)
            txt(s,'The model must interpret it.\nYou must inspect the evidence.',9.08,5.25,3.4,.8,15,INK)
            block(s,.55,4.85,7.75,'YOU','Own the outcome','Set scope, review actions and decide whether the result is acceptable.')
            takeaway(s,'The terminal tool runs a test. A model’s claim that it passed is not the test result.')
        elif kind=='choices':
            for i,(t,b) in enumerate([('Tiny local edit','Use inline assistance for a focused change.'),('Understand the code','Use Ask to investigate and explain.'),('Ambiguous change','Use /plan to surface assumptions and tests.'),('Bounded implementation','Use Agent to edit, run checks and iterate.')]):
                block(s,.55+(i%2)*6.23,1.7+(i//2)*1.66,5.99,f'0{i+1}',t,b)
            used.append(small_image(s,'agent-session-select-harness-role',6.9,5.28,5.85,1.05))
            txt(s,'Current Copilot control detail',.7,5.52,5.65,.35,16,NAVY,True)
            txt(s,'Harness, model and permission choices are independent.',.7,5.96,5.6,.4,14,INK)
            takeaway(s,'A simple task needs a simple interaction; add coordination when the uncertainty justifies it.')
        elif kind=='contract':
            codebox(s,'PLAN ONLY — do not edit.\n\nRepair validate_payment in validation.py.\nRead README and tests first.\n\nUse Decimal/string input; CAD or USD;\nfinite and nonnegative; ≤ 2 decimals;\ninvalid inputs raise ValueError.\n\nKeep API and tests. Propose a minimal\npatch and exact checks. Stop for review.',.55,1.65,7.05,4.78,16)
            for i,(h,b) in enumerate([('OUTCOME','Valid input → immutable Payment'),('CONTEXT','README + function + tests + failure'),('CONSTRAINTS','One file; API and tests preserved'),('VERIFICATION','Exact unittest command and result'),('STOPPING POINT','A concrete plan before implementation')]):
                txt(s,h,7.95,1.74+i*.88,4.7,.28,11,BLUE,True)
                txt(s,b,7.95,2.08+i*.88,4.7,.43,16,INK)
            takeaway(s,'Copy-ready full prompt: lab/starter/prompts.txt • Instructor-authored example')
        elif kind=='pyramid':
            levels=[(4.0,2.0,5.33,.72,NAVY,'HUMAN OWNER','Business correctness + acceptance'),(3.12,2.85,7.09,.81,BLUE,'PLANNER / INTEGRATOR','Decompose, set contracts, reconcile'),(2.1,3.80,9.13,.91,'3B97CA','WORKERS + SKEPTICS','Bounded implementation + independent challenge'),(.95,4.85,11.43,.94,PALE,'EXECUTABLE EVIDENCE','Tests · reviewed diffs · relevant measurements')]
            for x,y,w,h,fill,t,b in levels:
                rect(s,x,y,w,h,fill,radius=True)
                tc=WHITE if fill!=PALE else NAVY
                txt(s,t,x+.16,y+.10,w-.32,.28,16,tc,True,align=PP_ALIGN.CENTER)
                txt(s,b,x+.15,y+.43,w-.3,.28,13,tc,align=PP_ALIGN.CENTER)
            pill(s,'RESPONSIBILITY PATTERN',.55,1.52,2.55)
            txt(s,'One owner per artifact. One integration point.',2.1,6.02,9.1,.4,20,NAVY,True,align=PP_ALIGN.CENTER)
            takeaway(s,'Run sequentially in Copilot first. A role name alone does not launch a separate agent.')
        elif kind=='models':
            for i,(t,b,e) in enumerate([('DIRECT','Ambiguity, architecture, consequential review','Example: GPT-6 Astra'),('BUILD','A clear patch with narrow boundaries','Example: GPT-6 Sol'),('MECHANICAL WORK','Simple, easy-to-check transformations','Example: GPT-6 Luna')]):
                y=1.76+i*1.37
                pill(s,t,.55,y,2.25)
                txt(s,b,.55,y+.43,6.0,.42,18,NAVY,True)
                txt(s,e+' — if enabled in your picker',.55,y+.88,6.0,.3,13,MUTED)
            used.append(small_image(s,'model-dropdown-change-model-v2',7.15,1.72,5.62,3.43))
            txt(s,'Picker reference uses earlier Local UI.\nModel names, rates and access change.',7.23,5.36,5.42,.75,15,MUTED)
            takeaway(s,'Escalate with new evidence after repeated failure. Measure rework, latency and usage together.')
        elif kind=='video':
            key=d['video'];vf=MEDIA/'videos'/f'{key}.mp4';poster=MEDIA/'videos'/f'{key}-poster.png'
            x,y,w,h=.55,1.58,9.35,4.92
            rect(s,x,y,w,h,'102B40')
            iw,ih=Image.open(poster).size;r=min(w/iw,h/ih);pw,ph=iw*r,ih*r
            if pdf: picture(s,poster,x,y,w,h)
            else: s.shapes.add_movie(str(vf), Inches(x+(w-pw)/2), Inches(y+(h-ph)/2), Inches(pw), Inches(ph), poster_frame_image=str(poster), mime_type='video/mp4')
            duration=video_duration_seconds(key, vf)
            pill(s,f'PLAY {duration} SEC',10.16,1.66,2.38,fill=BLUE,color=WHITE,size=13)
            txt(s,'LOOK FOR',10.17,2.27,2.4,.32,11,BLUE,True)
            txt(s,d['watch'],10.17,2.66,2.44,1.60,17,NAVY,True)
            txt(s,'APPLY IT',10.17,4.45,2.4,.32,11,BLUE,True)
            txt(s,d['apply'],10.17,4.88,2.44,1.48,14.5,INK)
            video_meta=meta_for(key)
            txt(s,video_meta.get('caption') or 'Video companion • see media manifest for capture details',.59,6.52,12,.20,9,MUTED)
            takeaway(s,f'Offline fallback: media/videos/{key}.mp4  •  Click video in PowerPoint Slide Show.')
            used.append(key)
        elif kind=='worker':
            codebox(s,'IMPLEMENT THE APPROVED PLAN\n\nAllowed file: payments_demo/validation.py\nKeep the public API and supplied tests.\nNo new packages, network calls or refactor.\n\nRun: py -3 -m unittest discover -s tests -v\n\nReturn: files changed; actual command and\nresult; unresolved questions. Stop at a\nreviewable diff. Do not commit.',.55,1.66,8.05,4.85,16)
            txt(s,'A useful return',8.94,1.82,3.85,.5,21,NAVY,True)
            for i,(h,b) in enumerate([('Changed','One allowed file'),('Verified','Command + exit/result'),('Still uncertain','A specific assumption or “none”')]):
                marker(s,i+1,8.96,2.65+i*1.08)
                txt(s,h,9.39,2.66+i*1.08,3.2,.35,17,NAVY,True)
                txt(s,b,9.39,3.08+i*1.08,3.2,.48,14.5,INK)
            takeaway(s,'“Not run” is honest. A proposed command is not a passing test.')
        elif kind=='subagents':
            block(s,.55,1.65,6.0,'A','Sequential roles','You select a role/model, pass the artifact and review the result.')
            block(s,.55,3.28,6.0,'B','Actual delegation','An available delegation tool runs a child task and returns a result.')
            used.append(small_image(s,'agents-window-follow-subagents-read-only-chat',7.1,1.65,5.67,3.95))
            txt(s,'Official subagent trace detail',7.17,5.78,5.3,.35,12,MUTED)
            txt(s,'Both paths need a clear contract and evidence.',.65,5.42,6.0,.9,22,NAVY,True)
            takeaway(s,'Native tool and model-routing behavior depends on harness, version and policy. One-model fallback works.')
        elif kind=='parallel':
            for x,y,w,h,t,b,fc in [(.55,2.0,2.25,1.1,'CONTRACT','Goal + checks',PALE),(3.25,2.0,2.25,1.1,'ONE WRITER','Small patch',PALE),(6.0,1.65,2.7,1.0,'REVIEW A','Correctness',GREY),(6.0,3.0,2.7,1.0,'REVIEW B','Input robustness',GREY),(9.25,2.0,3.52,1.1,'INTEGRATE + TEST','Resolve findings once',PALE)]:
                rect(s,x,y,w,h,fc,radius=True);txt(s,t,x+.15,y+.15,w-.3,.28,14,NAVY,True);txt(s,b,x+.15,y+.6,w-.3,.35,14,INK)
            for a,b,c,dv in [(2.8,2.55,3.25,2.55),(5.5,2.55,6,2.15),(5.5,2.55,6,3.5),(8.7,2.15,9.25,2.55),(8.7,3.5,9.25,2.55)]:line(s,a,b,c,dv,BLUE,1.8)
            used.append(small_image(s,'agents-window-new-worktree',.55,4.68,7.13,1.28))
            txt(s,'Context isolation ≠ file isolation',8.0,4.65,4.75,.55,21,NAVY,True)
            txt(s,'For independent edits, use supported worktree isolation and review the integration.',8.0,5.35,4.65,.82,15,INK)
            takeaway(s,'Good first delegation: parallel read-only reviewers. Serialize changes to the same file.')
        elif kind=='adversarial':
            txt(s,'“Find the smallest input that breaks the contract.\nShow expected vs actual behavior and its impact.”',.55,1.68,12.0,1.05,25,NAVY,True)
            examples=[('NON-FINITE',"Decimal('NaN')",'Parses successfully. Must still be rejected.'),('PRECISION',"'1.001', 'CAD'",'Reject extra decimal places. Never round silently.'),('TYPE + CURRENCY',"0.1, 'cad'",'Float and lowercase currency both violate the contract.')]
            for i,(h,c,b) in enumerate(examples):
                x=.55+i*4.16
                rect(s,x,3.18,3.91,2.35,PALE,radius=True)
                txt(s,h,x+.2,3.40,3.5,.3,11,BLUE,True)
                txt(s,c,x+.2,3.99,3.5,.45,21,NAVY,True,font='Consolas')
                txt(s,b,x+.2,4.62,3.47,.72,15,INK)
            txt(s,'Fresh context → hypothesis → try input → inspect evidence → fix if needed',.64,5.94,12.0,.45,18,NAVY,True)
            takeaway(s,'A second model offers another perspective. Evidence decides whether a finding is real.')
        elif kind=='efficiency':
            rows=[('Accepted patch time','How long until tests and review pass?'),('Rework','How many retries and missed requirements?'),('Usage','Which models, tokens and tool loops?')]
            for i,(h,b) in enumerate(rows):block(s,.55,1.7+i*1.48,7.1,str(i+1),h,b)
            used.append(small_image(s,'chat-context-window-control',8.19,1.72,4.57,3.43))
            txt(s,'A practical stop rule',8.26,5.36,4.3,.4,20,NAVY,True)
            txt(s,'Repeated failure without new evidence?\nReturn to the plan and narrow the task.',8.26,5.88,4.3,.70,15,INK)
            takeaway(s,'Measurement template, not claimed benchmark data. More agents can increase total cost.')
        elif kind=='exercise':
            for i,(m,t,b) in enumerate([('2 MIN','PLAN','Run the red baseline. Ask for a plan without edits.'),('5 MIN','IMPLEMENT','One writer edits validation.py. Keep the API and tests.'),('3 MIN','CHALLENGE','Try an adversarial input. Reproduce any real finding.'),('2 MIN','PROVE','Run all 7 methods. Inspect the diff. Report evidence.')]):
                x=.55+i*3.10
                rect(s,x,1.78,2.91,3.65,PALE,radius=True)
                txt(s,m,x+.18,2.02,2.55,.5,27,BLUE,True)
                txt(s,t,x+.18,2.83,2.55,.43,17,NAVY,True)
                txt(s,b,x+.18,3.55,2.55,1.30,18,INK)
            codebox(s,'py -3 -m unittest discover -s tests -v',.55,5.72,9.30,.66,17)
            pill(s,'7 METHODS PASS',10.13,5.88,2.65,fill=TEAL,color=WHITE,size=12)
            takeaway(s,'Open lab/starter only. Facilitator solution is separate. Full role prompts are in prompts.txt.')
        elif kind=='checklist':
            items=[('Goal','The patch still matches the contract.'),('Ownership','One writer and one integration point.'),('Diff','Only intended files changed; inspect each change.'),('Checks','Exact commands ran and results were recorded.'),('Challenge','A concrete edge case was reproduced or resolved.'),('Boundaries','Data, tools and permissions stayed appropriate.')]
            for i,(h,b) in enumerate(items):
                x=.55+(i%2)*6.23;y=1.72+(i//2)*1.42
                rect(s,x,y,5.99,1.19,PALE,radius=True)
                marker(s,'✓',x+.18,y+.21)
                txt(s,h,x+.69,y+.18,4.98,.35,18,NAVY,True)
                txt(s,b,x+.69,y+.64,4.98,.43,14.5,INK)
            takeaway(s,'You own the decision to accept the code. Saving a file is not acceptance.')
        elif kind=='resources':
            txt(s,'Your offline training pack',.55,1.63,6.1,.5,24,NAVY,True)
            for i,(h,b) in enumerate([('PowerPoint + PDF','Editable deck; static PDF for reference.'),('Media library','Full-resolution images, four MP4s and source manifest.'),('Lab + prompt cards','Starter, facilitator solution and copy-ready role prompts.')]):
                y=2.4+i*1.2
                rect(s,.55,y,7.05,1.04,PALE,radius=True)
                txt(s,str(i+1),.73,y+.19,.45,.4,22,BLUE,True)
                txt(s,h,1.35,y+.16,5.9,.35,18,NAVY,True)
                txt(s,b,1.35,y+.60,5.9,.35,14,INK)
            txt(s,'Official references',8.05,1.65,4.65,.5,22,NAVY,True)
            refs=[('Copilot setup','setup'),('Plan work','plan'),('Subagents','subagents'),('Custom agents','agents'),('Review saved changes','review'),('Models and current pricing','cost')]
            for i,(title,key) in enumerate(refs):
                sh=txt(s,'↗  '+title,8.08,2.42+i*.57,4.6,.4,16,BLUE,True)
                sh.click_action.hyperlink.address=SRC[key]
            txt(s,'Checked 26 Oct 2026\nWindows steps; source UI caveats in notes.',8.1,6.03,4.5,.58,11,MUTED)
            takeaway(s,'Next task: write a contract → plan → bounded patch → fresh challenge → evidence → review.')
        else: raise ValueError(kind)

    notes=f"SLIDE {n:02d} — {d['title'].replace(chr(10),' ')}\n\n{d['note']}\n\n"
    if d.get('sources'):
        notes+='OFFICIAL REFERENCES (checked 26 Oct 2026):\n'+'\n'.join(SRC[k] for k in d['sources'])+'\n\n'
    for key in used:
        m=meta_for(key)
        if m:
            notes+=f"MEDIA: {key}\nSource page: {m.get('source_page_url','')}\nAsset: {m.get('source_asset_url','')}\nObserved: {m.get('observed_source_date','')}\nOS: {m.get('os','')}\nHarness: {m.get('harness','')}\nNative dimensions: {m.get('width','')}x{m.get('height','')}\n"
            for field in ('caption','provenance_note','transcript'):
                if m.get(field):notes+=f"{field.replace('_',' ').title()}: {m[field]}\n"
            notes+='\n'
    if kind=='video':
        m=meta_for(d['video'])
        notes+=f"VIDEO COMPANION: media/videos/{d['video']}.mp4\n"
        notes+=(m.get('provenance_note') or 'Capture details have not been recorded; verify the media manifest before presenting.')+'\n'
        origin=m.get('source_asset_url') or m.get('source_file') or 'Local capture; see media manifest.'
        notes+=f"Source: {origin}\n"
    s.notes_slide.notes_text_frame.text=notes
    d['used_assets']=used
    return s


def video_duration_seconds(key, path):
    # The bundled manifest records the excerpt plus its title card. This keeps
    # rebuilds working on machines without ffprobe.
    meta = meta_for(key)
    if 'duration_seconds' in meta:
        return round(float(meta['duration_seconds']))
    if 'source_duration_seconds' in meta:
        return round(float(meta['source_duration_seconds']) + float(meta.get('title_card_seconds', 0)))
    probe = shutil.which('ffprobe')
    if probe:
        return round(float(subprocess.check_output([probe, '-v', 'error', '-show_entries',
            'format=duration', '-of', 'default=nw=1:nk=1', str(path)], text=True)))
    raise ValueError(f'No duration for {key} in media/manifest.json and ffprobe is unavailable')


def validate_local_video_metadata():
    for slide in SLIDES:
        if slide['kind'] != 'video':
            continue
        key = slide['video']
        meta = meta_for(key)
        if meta.get('source_asset_url') and meta.get('source_kind') != 'authenticated_copilot_lab_capture':
            continue
        required = ('source_file', 'caption', 'provenance_note', 'duration_seconds')
        missing = [field for field in required if not meta.get(field)]
        if missing:
            raise ValueError(f'Local video {key} needs manifest fields: {", ".join(missing)}')
        stale = ('official windows', 'official microsoft', 'official clip',
                 'official demo', 'may 2026', 'portfolio example', 'portfolio reference')
        if any(phrase in slide['note'].lower() for phrase in stale):
            raise ValueError(f'Local video {key} still has old reference-footage wording in its slide note')


def build(pdf=False):
    validate_local_video_metadata()
    prs=Presentation();prs.slide_width=Inches(W);prs.slide_height=Inches(H)
    prs.core_properties.title='Agentic AI in VS Code — GitHub Copilot Developer Workshop'
    prs.core_properties.subject='BMO training draft • Windows workflow • synthetic Python lab'
    prs.core_properties.author='Developer enablement'
    prs.core_properties.keywords='Agentic AI, GitHub Copilot, VS Code, BMO, training'
    for n,d in enumerate(SLIDES,1):make_slide(prs,d,n,pdf)
    path=(OUT/'BMO_Agentic_AI_VS_Code_PDF_source.pptx') if pdf else OUT/'BMO_Agentic_AI_VS_Code.pptx'
    prs.save(path)
    return path


if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Rebuild both training PowerPoints from this extracted training pack.')
    parser.parse_args()
    MANIFEST=json.loads((ROOT/'media/manifest.json').read_text(encoding='utf-8'))
    OUT.mkdir(exist_ok=True)
    assert len(SLIDES)==28
    for pdf in [False,True]:print(build(pdf))
    (OUT/'slide_content.json').write_text(json.dumps(SLIDES,indent=2,ensure_ascii=False),encoding='utf-8')
    (OUT/'official_sources.json').write_text(json.dumps(SRC,indent=2),encoding='utf-8')
