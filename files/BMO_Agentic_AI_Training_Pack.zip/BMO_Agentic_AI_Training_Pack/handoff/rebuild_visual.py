from __future__ import annotations

import json
import math
import re
import shutil
import subprocess
from pathlib import Path

from PIL import Image
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT; MEDIA=OUT/'media'
W,H=16,9
BLUE,NAVY,RED='0075BE','003B71','ED1C24'
INK,MUTED,PALE,GREY,WHITE,TEAL,AMBER='162A3A','617386','EAF4FB','F3F6F8','FFFFFF','008C87','D9971C'
FONT='Arial'

TITLES=[
 'From answers to verified changes',
 'The answer grows one token at a time',
 'Batching shares the engine',
 'One tiny bug',
 'Start with one clear request',
 'Does the patch satisfy the contract?',
 'Give the agent a feedback loop',
 'A role is a job description',
 'Create the role in VS Code',
 'Save the role. Reuse it.',
 'Sequential: pass a small contract',
 'Parallel: split independent checks',
 'Adversarial: try to break the answer',
 'Spend capability where judgment matters',
 'Match the workflow to the work',
 'More calls can mean more tokens',
 'Buy useful evidence, then stop',
 'Your six-minute VS Code lab',
 'Done means evidence',
 'Start small. Verify. Scale when useful.',
]
SOURCES={
 'inference':'https://developer.nvidia.com/blog/mastering-llm-techniques-inference-optimization/',
 'batching':'https://nvidia.github.io/TensorRT-LLM/features/paged-attention-ifb-scheduler.html',
 'agents':'https://code.visualstudio.com/docs/agent-customization/custom-agents',
 'schema':'https://code.visualstudio.com/docs/agents/reference/custom-agent-file-reference',
 'subagents':'https://code.visualstudio.com/docs/agents/run/subagents',
 'usage':'https://code.visualstudio.com/docs/agents/guides/optimize-usage',
 'models':'https://code.visualstudio.com/docs/agent-customization/language-models',
 'billing':'https://docs.github.com/en/copilot/reference/copilot-billing/models-and-pricing',
 'review':'https://code.visualstudio.com/docs/agents/run/review-code-edits',
}

def c(value):return RGBColor.from_string(value)

def box(s,x,y,w,h,fill=PALE,radius=.12,line=None):
    sh=s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE,Inches(x),Inches(y),Inches(w),Inches(h))
    sh.fill.solid();sh.fill.fore_color.rgb=c(fill)
    sh.line.fill.background()
    if line:sh.line.color.rgb=c(line);sh.line.width=Pt(1)
    if radius:sh.adjustments[0]=radius
    return sh

def text(s,value,x,y,w,h,size=26,color=INK,bold=False,font=FONT,align=None):
    sh=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h))
    tf=sh.text_frame;tf.clear();tf.word_wrap=True
    tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0
    for i,l in enumerate(str(value).split('\n')):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph()
        p.text=l;p.font.name=font;p.font.size=Pt(size);p.font.bold=bold;p.font.color.rgb=c(color)
        p.line_spacing=1.05;p.space_after=Pt(4)
        if align is not None:p.alignment=align
    return sh

def line(s,x1,y1,x2,y2,color=BLUE,width=2):
    sh=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1),Inches(y1),Inches(x2),Inches(y2))
    sh.line.color.rgb=c(color);sh.line.width=Pt(width)
    return sh

def arrow(s,x,y,w=.48,h=.42,color=BLUE):
    sh=s.shapes.add_shape(MSO_SHAPE.CHEVRON,Inches(x),Inches(y),Inches(w),Inches(h))
    sh.fill.solid();sh.fill.fore_color.rgb=c(color);sh.line.fill.background();return sh

def pill(s,value,x,y,w,color=BLUE,fill=PALE,size=14):
    box(s,x,y,w,.42,fill)
    text(s,value,x+.1,y+.07,w-.2,.28,size,color,True,align=PP_ALIGN.CENTER)

def circle(s,value,x,y,d=.55,fill=BLUE,color=WHITE,size=20):
    sh=s.shapes.add_shape(MSO_SHAPE.OVAL,Inches(x),Inches(y),Inches(d),Inches(d))
    sh.fill.solid();sh.fill.fore_color.rgb=c(fill);sh.line.fill.background()
    text(s,value,x,y+.07,d,d-.1,size,color,True,align=PP_ALIGN.CENTER)
    return sh

def image(s,path,x,y,w,h,bg=WHITE):
    iw,ih=Image.open(path).size;r=min(w/iw,h/ih);pw,ph=iw*r,ih*r
    box(s,x,y,w,h,bg,radius=0)
    return s.shapes.add_picture(str(path),Inches(x+(w-pw)/2),Inches(y+(h-ph)/2),width=Inches(pw),height=Inches(ph))

def screenshot(s,name,x=.65,y=1.8,w=14.7,h=6.35):
    p=MEDIA/'screenshots'/f'{name}.png'
    if not p.exists():raise FileNotFoundError(p)
    return image(s,p,x,y,w,h,bg='1E1E1E')

def screenshot_detail(s,name,x,y,w,h,cl=0,ct=0,cr=0,cb=0):
    p=MEDIA/'screenshots'/f'{name}.png'
    iw,ih=Image.open(p).size;cw=iw*(1-cl-cr);ch=ih*(1-ct-cb)
    r=min(w/cw,h/ch);pw,ph=cw*r,ch*r
    box(s,x,y,w,h,'1E1E1E',radius=0)
    sh=s.shapes.add_picture(str(p),Inches(x+(w-pw)/2),Inches(y+(h-ph)/2),width=Inches(pw),height=Inches(ph))
    sh.crop_left=cl;sh.crop_top=ct;sh.crop_right=cr;sh.crop_bottom=cb
    return sh

def code(s,value,x,y,w,h,size=26):
    box(s,x,y,w,h,'102B40')
    text(s,value,x+.25,y+.22,w-.5,h-.42,size,'EAF4FB',font='Consolas')

def caption(s,value):
    text(s,value,.65,8.26,14.7,.22,9,MUTED)

def header(s,n,section,title=True):
    s.background.fill.solid();s.background.fill.fore_color.rgb=c(WHITE)
    box(s,0,0,W,.065,BLUE,radius=0)
    text(s,section.upper(),.65,.29,12,.28,11,BLUE,True)
    image(s,MEDIA/'BMO_logo.png',14.18,.21,1.15,.4)
    if title:text(s,TITLES[n-1],.65,.91,14.7,.74,37,NAVY,True)
    line(s,.65,8.58,15.35,8.58,'D4E0E8',.7)
    text(s,'BMO / Developer workshop / Synthetic example',.65,8.71,12,.2,9,MUTED)
    text(s,f'{n:02d} / 20',14.35,8.68,1,.25,11,MUTED,align=PP_ALIGN.RIGHT)

def receipt(s,x,y,w,amount,fee,accent=BLUE):
    box(s,x,y,w,2.4,PALE)
    text(s,amount,x+.2,y+.28,w-.4,.7,38,NAVY,True,align=PP_ALIGN.CENTER)
    text(s,fee,x+.2,y+1.27,w-.4,.65,31,accent,True,align=PP_ALIGN.CENTER)

def node(s,x,y,w,h,title,sub=None,fill=PALE):
    box(s,x,y,w,h,fill)
    text(s,title,x+.15,y+.23,w-.3,.6,25,NAVY,True,align=PP_ALIGN.CENTER)
    if sub:text(s,sub,x+.15,y+.92,w-.3,.65,20,INK,align=PP_ALIGN.CENTER)

def movie(s,stem,x,y,w,h,pdf):
    vf=MEDIA/'videos'/f'{stem}.mp4';pf=MEDIA/'videos'/f'{stem}-poster.png'
    if not vf.exists() or not pf.exists():raise FileNotFoundError(vf)
    if pdf:image(s,pf,x,y,w,h,bg='102B40')
    else:
        iw,ih=Image.open(pf).size;r=min(w/iw,h/ih);pw,ph=iw*r,ih*r
        s.shapes.add_movie(str(vf),Inches(x+(w-pw)/2),Inches(y+(h-ph)/2),Inches(pw),Inches(ph),poster_frame_image=str(pf),mime_type='video/mp4')
    manifest=MEDIA/'manifest.json'
    duration=None
    if manifest.exists():
        for asset in json.loads(manifest.read_text(encoding='utf-8')).get('assets',[]):
            if asset.get('path','').endswith(f'/{stem}.mp4'):
                duration=asset.get('duration_seconds')
                break
    if duration is None:
        duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(vf)],text=True))
    return round(float(duration))

def source_notes():
    p=ROOT/'handoff/storyboard.md'
    content=p.read_text(encoding='utf-8')
    sections=re.split(r'^## Slide \d+ — .*$',content,flags=re.M)[1:21]
    notes=[]
    for segment in sections:
        match=re.search(r'\*\*Speaker notes:\*\*\s*(.*?)(?=\n## |\Z)',segment,flags=re.S)
        t=match.group(1).strip() if match else segment
        t=t.replace('delivery.py','shipping.py').replace('README.md','README.md')
        t=t.replace('py -3 -m unittest discover -s tests -v','py -3 -m unittest -v test_shipping')
        t=t.replace('Reviewer profile','Skeptic profile').replace('new reviewer profile','new Skeptic profile')
        notes.append(t)
    return notes

NOTES=source_notes()
NOTES[4]+='\n\nThe visible code/video is an instructor-authored patch, not an observed Copilot answer. Copy-ready one-shot teaching request: Read README.md, shipping.py and test_shipping.py. Fix the function to the full README contract. Change only shipping.py. Return the proposed patch. The IMPLEMENT prompt in the student pack additionally asks to execute tests and is therefore already a tool-using workflow. Compare these clearly instead of implying one prompt cannot be agentic.'
NOTES[5]+='\n\nActual authored snapshot results: starter 3/6 tests, boundary-only patch 4/6, reference 6/6. The same six named tests are run against every snapshot. These numbers describe these files, not measured model success rates. Tests now include zero, 9999/10000/10001, negative input, float/string/bool/None and integer return. Passing six tests is evidence within that scope, not proof for every possible input.'
NOTES[7]+='\n\nPrompt-defined role example: You are the skeptic. Read the README and current shipping.py. Do not edit. Try exactly 10000 and invalid totals. Return expected versus actual behavior, or say no finding. This role can be used in a fresh chat. Saving it as a custom agent is optional.'
NOTES[8]+='\n\nUse the bundled name Skeptic when demonstrating the provided files. The screenshot is a genuine local Agent Customizations editor showing the Builder, Planner and Skeptic files from this lab, cropped to its useful controls; the full window is retained. This screenshot uses the Local harness in macOS, without an authenticated Copilot session. Select the intended Copilot harness before creating the runtime configuration in your environment. The next Copilot-enabled agent can replace this reference with a genuine Windows capture.'
NOTES[9]+='\n\nThe actual file in this demo is .github/agents/skeptic.agent.md. It restricts tools with read/search aliases. Verify the loaded tool restrictions in the chosen harness. The guided clip is a real VS Code file walkthrough using supplied instructions; it is not live Copilot delegation.'
NOTES[12]+='\n\nKeep the six supplied lab tests unchanged. The True example is already covered by the fixed acceptance suite. In a normal project, a new real counterexample should become a regression test; here reproduce an existing case and repair only shipping.py. If the actual reviewer reports no finding, that is a valid result.'
NOTES[15]='Illustrative token accounting, not observed Copilot telemetry. The scenario sums input/output across calls: single prompt 1800+700=2500; sequential11000+2900=13900; parallel14600+4000=18600; adversarial17900+4200=22100. These are invented workflow budgets from cost/cost_model.json, not this tiny lab’s measured usage. Input includes repeated context and tool results. Billing depends on the selected model, cached/fresh tokens and current product rules. Parallelism can lower wall-clock time while increasing tokens. One prompt can already solve a small task; compare the total effort of a checked result. The supplemental numerical chart uses scheduled verification passes, not passed checks, accuracy or quality.'
NOTES[16]='This is a conceptual Pareto diagram, not a benchmark. Higher means more useful evidence against stated requirements; right means greater resource cost. A dominated point costs more for the same evidence. The frontier is schematic, without invented quality scores or numerical positions. The decision is to use the least costly workflow that satisfies the needed evidence. On this tiny function, one bounded prompt plus tests may be enough; larger tasks spanning files, tools or independent risks can justify coordination. A fair measurement would hold the full contract and test suite constant, repeat runs, and record all requests, cached/input/output tokens, elapsed time, human interventions and failures. Do not infer a causal model-performance advantage from instructor-authored snapshots.'
NOTES[17]+='\n\nUse Python 3.10+ and run py -3 -m unittest -v test_shipping from the starter folder (or python -m unittest -v test_shipping). The files are shipping.py and root-level test_shipping.py; there is no tests subfolder. Before editing, preserve shipping.before.py outside the starter folder or use an existing Git baseline. See the README for code --diff. Six-minute pacing: one minute baseline, two-minute bounded fix, two-minute fresh review, one minute tests/diff.'
NOTES[18]+='\n\nThe screenshot and guided clip show real local VS Code on macOS, the supplied reference code, and six actual passing tests. They do not show an authenticated Copilot completion. The result is deliberately compact; inspect the whole supplied contract and any remaining uncertainty before accepting. The original window image is retained in the media folder.'

SLIDE_DATA=[]

def build(pdf=False):
    prs=Presentation();prs.slide_width=Inches(W);prs.slide_height=Inches(H)
    prs.core_properties.title='Agentic AI in VS Code — From answers to verified changes'
    prs.core_properties.author='Developer enablement'
    prs.core_properties.subject='BMO public-brand training draft • visual beginner edition'
    sections=['Tokens','Tokens','Tokens','The task','One request','Check the result','The loop','Create a role','Create a role','Create a role','Patterns','Patterns','Patterns','Model balance','Choose a pattern','Cost','Cost','Try it','Evidence','Take away']
    for n in range(1,21):
        s=prs.slides.add_slide(prs.slide_layouts[6]);header(s,n,sections[n-1],title=n!=16)
        media=[];video=None
        if n==1:
            pill(s,'AGENTIC AI WITH GITHUB COPILOT',.65,1.84,4.8)
            for i,label in enumerate(['Prompt','Code','Tests']):
                box(s,.85,3.0+i*1.02,3.1,.78,PALE)
                text(s,label,1.08,3.16+i*1.02,2.6,.4,26,NAVY,True)
                arrow(s,4.15,3.17+i*1.02)
            node(s,5.0,3.0,5.3,3.0,'PREFILL','Process the input',fill=PALE)
            text(s,'Prompt + context',5.22,6.34,4.86,.5,24,BLUE,True,align=PP_ALIGN.CENTER)
            arrow(s,10.64,4.25,.66,.6)
            box(s,11.75,3.0,3.5,3.0,GREY)
            text(s,'First token…',11.95,4.15,3.1,.6,27,MUTED,True,align=PP_ALIGN.CENTER)
        elif n==2:
            node(s,.75,2.18,4.2,2.45,'PREFILL','Read context')
            arrow(s,5.23,3.08,.7,.62)
            for i,label in enumerate(['return','0','if','…']):
                box(s,6.4+i*2.12,2.91,1.82,1.16,BLUE)
                text(s,label,6.5+i*2.12,3.24,1.62,.5,27,WHITE,True,align=PP_ALIGN.CENTER)
            text(s,'DECODE',6.4,4.69,8.18,.65,34,BLUE,True,align=PP_ALIGN.CENTER)
            text(s,'Generate the next token',6.4,5.51,8.18,.55,26,INK,align=PP_ALIGN.CENTER)
            line(s,1.0,7.1,14.8,7.1,'9BB8CA',3)
            circle(s,'',5.6,6.83,.55,fill=TEAL)
            text(s,'First output',4.43,7.48,2.9,.43,20,MUTED,align=PP_ALIGN.CENTER)
        elif n==3:
            for i,(label,color) in enumerate([('A',BLUE),('B',TEAL),('C',AMBER)]):
                y=2.35+i*1.62
                text(s,'Request '+label,.85,y+.16,2.8,.6,27,NAVY,True)
                for j in range(3):box(s,3.75+j*.72,y+.10,.54,.60,color,radius=.1)
                arrow(s,6.03,y+.19,.47,.42)
                for j in range(3):box(s,11.53+j*.85,y+.10,.66,.60,color,radius=.1)
            box(s,6.85,2.13,4.1,4.75,PALE)
            text(s,'Shared\ncompute',7.17,3.45,3.46,1.55,33,NAVY,True,align=PP_ALIGN.CENTER)
            text(s,'Throughput and waiting time are different.',1.0,7.48,14,.55,27,BLUE,True,align=PP_ALIGN.CENTER)
        elif n==4:
            receipt(s,.65,2.03,4.7,'$99.99','$5 delivery')
            receipt(s,5.65,2.03,4.7,'$100.00','FREE',TEAL)
            receipt(s,10.65,2.03,4.7,'Invalid total','Reject',RED)
            code(s,'def delivery_fee(total_cents):\n    return 0 if total_cents > 10000 else 500',.65,5.28,14.7,1.65,27)
            text(s,'What happens at exactly $100?',.75,7.35,14.5,.6,29,BLUE,True,align=PP_ALIGN.CENTER)
            caption(s,'Instructor-authored starter • integer cents • full contract in README.md')
        elif n==5:
            code(s,'Match README.\nEdit shipping.py only.\nReturn the proposed patch.',.65,1.96,5.25,2.85,24)
            text(s,'A proposal\nto inspect',.8,5.0,4.9,1.55,35,BLUE,True)
            video='boundary-walkthrough';seconds=movie(s,video,6.35,1.96,9.0,5.62,pdf)
            pill(s,f'PLAY {seconds}s',12.97,7.68,2.38)
            caption(s,'Guided VS Code walkthrough • instructor-supplied patch • actual macOS capture')
        elif n==6:
            screenshot_detail(s,'demo-prompt-patch',.65,1.87,10.35,6.26,cl=.20,ct=.07,cr=.01,cb=.05);media=['demo-prompt-patch']
            text(s,'4 / 6',11.45,2.1,3.55,1.25,60,BLUE,True,align=PP_ALIGN.CENTER)
            text(s,'checks pass',11.4,3.35,3.65,.6,26,NAVY,True,align=PP_ALIGN.CENTER)
            for i,(t,color) in enumerate([('10000 → 0',TEAL),('−1 → error',RED),('True → error',RED)]):
                pill(s,t,11.43,4.48+i*.9,3.63,color=color,size=21)
            caption(s,'Actual unittest result for the supplied partial patch • this is not an AI success-rate comparison')
        elif n==7:
            labels=['Inspect','Change','Run checks','Read result']
            for i,t in enumerate(labels):
                x=.65+i*3.8
                node(s,x,2.78,3.3,1.7,t)
                if i<3:arrow(s,x+3.43,3.39,.28,.42)
            line(s,13.7,4.72,13.7,6.08,BLUE,3);line(s,13.7,6.08,5.8,6.08,BLUE,3);line(s,5.8,6.08,5.8,4.72,BLUE,3)
            text(s,'Improve',8.08,6.38,3.0,.55,29,BLUE,True,align=PP_ALIGN.CENTER)
            pill(s,'Contract passes → review the diff',.85,7.55,7.35,color=TEAL,fill='E3F3F0',size=23)
        elif n==8:
            roles=[('Planner','Decide the steps'),('Builder','Make the change'),('Skeptic','Try to break it')]
            for i,(role,task) in enumerate(roles):
                x=.65+i*5
                node(s,x,2.3,4.7,2.3,role,task)
            code(s,'“Act as the Skeptic. Read the contract.\nDo not edit. Try 10000 and True.”',1.2,5.15,13.6,1.55,26)
            text(s,'Same model. Different job.',1.0,7.28,14,.6,29,BLUE,True,align=PP_ALIGN.CENTER)
        elif n==9:
            screenshot_detail(s,'customizations-ui',.65,2.29,14.7,5.80,cl=.09,ct=.11,cr=.09,cb=.35);media=['customizations-ui']
            pill(s,'Open Customizations → Agents → New Agent',.65,1.76,11.42,size=20)
            pill(s,'Workspace',12.35,1.76,3.0,size=20)
            caption(s,'Actual macOS / Local editor detail • Windows: Ctrl+Shift+P → Chat: Open Customizations • choose Copilot in your environment')
        elif n==10:
            video='agent-file-walkthrough';seconds=movie(s,video,.65,2.2,14.7,5.88,pdf)
            text(s,'.github/agents/skeptic.agent.md',.65,1.73,11.9,.43,24,BLUE,True,font='Consolas')
            pill(s,f'PLAY {seconds}s',12.97,1.72,2.38)
            caption(s,'Actual profile file and read/search tools • guided macOS editor walkthrough • select Skeptic in your Copilot agent picker')
        elif n==11:
            for i,(title,artifact) in enumerate([('Plan','Contract'),('Implement','Patch'),('Review','Findings'),('Verify','Evidence')]):
                x=.65+i*3.8
                node(s,x,2.8,3.3,2.05,title,artifact)
                if i<3:arrow(s,x+3.43,3.6,.28,.42)
            code(s,'Integer cents. Free at 10000. Reject invalid input.\nChange shipping.py only. Run the supplied tests.',1.2,5.65,13.6,1.65,25)
            caption(s,'Sequential handoff can be manual; saved role names do not automatically launch separate agents.')
        elif n==12:
            node(s,.65,3.3,3.4,1.8,'Frozen patch')
            node(s,5.38,2.05,5.1,1.8,'Boundary reviewer','9999 · 10000 · 10001')
            node(s,5.38,4.69,5.1,1.8,'Input reviewer','−1 · True · string')
            node(s,11.75,3.3,3.6,1.8,'One writer','Combine findings')
            for a,b,d,e in [(4.05,4.2,5.38,2.95),(4.05,4.2,5.38,5.59),(10.48,2.95,11.75,4.2),(10.48,5.59,11.75,4.2)]:line(s,a,b,d,e,BLUE,3)
            pill(s,'Independent reviews. Shared contract.',3.3,7.4,9.4,size=24)
        elif n==13:
            text(s,'“Find an input that violates the README.”',.65,1.94,14.7,.75,31,NAVY,True)
            node(s,.65,3.2,3.6,2.3,'True','Not a cart total',fill='FFF0EE')
            arrow(s,4.56,4.08,.52,.5)
            code(s,'isinstance(True, int)\n        → True',5.4,3.2,5.9,2.3,27)
            arrow(s,11.65,4.08,.52,.5,color=RED)
            node(s,12.5,3.2,2.85,2.3,'Accepted?','Wrong contract',fill='FFF0EE')
            code(s,'type(total_cents) is int',3.6,6.28,8.8,1.0,30)
            caption(s,'Instructor-supplied Python type trap • the fixed six-test suite already checks bool inputs')
        elif n==14:
            for x,y,w,h,fill,title in [(4.3,2.0,7.4,1.1,NAVY,'Human: own the outcome'),(3.15,3.3,9.7,1.15,BLUE,'Capable planner: decide + integrate'),(1.95,4.65,12.1,1.15,'459FCD','Lower-cost workers: bounded tasks'),(.65,6.0,14.7,1.15,PALE,'Tests + reviewed diff')]:
                box(s,x,y,w,h,fill)
                text(s,title,x+.18,y+.31,w-.36,.6,27,WHITE if fill!=PALE else NAVY,True,align=PP_ALIGN.CENTER)
            caption(s,'Responsibility pattern • use available models; verify total cost and results')
        elif n==15:
            options=[('One clear edit','Simple prompt'),('Dependent steps','Sequential'),('Independent checks','Parallel'),('Risky assumption','Adversarial review')]
            for i,(when,how) in enumerate(options):
                x=.65+(i%2)*7.5;y=2.03+(i//2)*2.78
                box(s,x,y,7.2,2.35,PALE)
                text(s,when,x+.28,y+.34,6.64,.5,27,NAVY,True)
                text(s,'→ '+how,x+.28,y+1.19,6.64,.6,30,BLUE,True)
        elif n==16:
            image(s,OUT/'cost/tokens_minimal.png',.65,.9,14.7,7.38)
            caption(s,'Scenario only • 2.5k / 13.9k / 18.6k / 22.1k input + output tokens • totals sum multiple calls')
        elif n==17:
            # Deliberately conceptual: no invented quality numbers.
            line(s,1.45,7.12,14.55,7.12,MUTED,2);line(s,1.45,7.12,1.45,2.95,MUTED,2)
            text(s,'Useful evidence',.67,2.30,4.5,.55,24,NAVY,True)
            text(s,'Total cost / effort →',10.65,7.52,4.55,.55,24,NAVY,True)
            points=[(3.05,6.1),(6.65,4.28),(9.55,3.05)]
            for (a,b),(d,e) in zip(points,points[1:]):line(s,a,b,d,e,BLUE,3)
            for x,y in points:circle(s,'',x-.14,y-.14,.28,fill=BLUE)
            text(s,'Minimal passing\nworkflow',2.10,6.30,4.8,.90,22,NAVY,True)
            text(s,'Additional checks',7.65,2.40,6.0,.55,26,NAVY,True)
            circle(s,'×',11.93,4.0,.55,fill=RED,color=WHITE,size=23)
            line(s,6.65,4.28,11.93,4.28,'B2C3CE',1)
            text(s,'More cost.\nSame evidence.',11.10,4.92,4.1,1.15,25,RED,True)
            pill(s,'Illustrative Pareto tradeoff • not a benchmark',5.20,1.78,10.1,size=17)
        elif n==18:
            labels=['Open starter','Run tests','Bound the fix','Challenge','Review diff']
            for i,t in enumerate(labels):
                x=.65+i*3.0
                circle(s,str(i+1),x+.87,2.3,.85,size=29)
                text(s,t,x,3.53,2.7,.95,26,NAVY,True,align=PP_ALIGN.CENTER)
                if i<4:arrow(s,x+2.62,2.51,.25,.4)
            code(s,'py -3 -m unittest -v test_shipping',1.0,5.36,14.0,1.15,29)
            text(s,'Six minutes. One file. Six checks.',1.0,7.1,14,.7,31,BLUE,True,align=PP_ALIGN.CENTER)
            caption(s,'Windows command • Python 3.10+ • open the standalone starter folder • preserve a comparison baseline')
        elif n==19:
            video='verification-walkthrough';seconds=movie(s,video,.65,1.87,11.35,6.26,pdf)
            text(s,'6 / 6',12.36,2.05,2.98,1.1,50,TEAL,True,align=PP_ALIGN.CENTER)
            for i,t in enumerate(['Tests run','Diff reviewed','Limits stated']):
                circle(s,'✓',12.42,3.67+i*1.03,.45,fill=TEAL,size=17)
                text(s,t,13.04,3.71+i*1.03,2.32,.55,20,NAVY,True)
            pill(s,f'PLAY {seconds}s',12.35,7.55,3.0)
            caption(s,'Actual local code and six passing tests • guided macOS walkthrough • authored reference, not a recorded Copilot run')
        elif n==20:
            receipt(s,5.3,1.94,5.4,'$100.00','FREE',TEAL)
            for i,(title,sub) in enumerate([('One task','Clear contract'),('One loop','Checked result'),('Add roles','When useful')]):
                x=.65+i*5.0
                node(s,x,5.21,4.7,2.1,title,sub,fill=PALE if i!=1 else 'D8EFEC')
            caption(s,'Next: choose one small change in your own repository and define the evidence you need.')

        extra=''
        if media:extra+='\nMEDIA: '+', '.join(media)+'. Original files retained in media/screenshots.\n'
        if video:extra+=f'\nGUIDED VIDEO: media/videos/{video}.mp4; derived from actual VS Code screenshots with editorial guidance. This is not live authenticated Copilot footage. See the transcript and media manifest.\n'
        related={1:['inference'],2:['inference'],3:['batching'],7:['review'],8:['agents'],9:['agents'],10:['schema'],11:['agents'],12:['subagents'],14:['models','usage'],16:['billing','usage'],17:['usage']}.get(n,[])
        if related:extra+='\nPRIMARY REFERENCES (checked 26 October 2026):\n'+'\n'.join(SOURCES[k] for k in related)
        notes=f'SLIDE {n:02d}: {TITLES[n-1]}\n\n'+NOTES[n-1]+extra
        s.notes_slide.notes_text_frame.text=notes
        if not pdf:
            SLIDE_DATA.append({'number':n,'title':TITLES[n-1],'section':sections[n-1],'notes':notes,'video':video,'media':media})
    OUT.mkdir(exist_ok=True)
    (ROOT/'build/v2').mkdir(parents=True,exist_ok=True)
    path=ROOT/'build/v2/BMO_Agentic_AI_VS_Code_PDF_source.pptx' if pdf else OUT/'BMO_Agentic_AI_VS_Code.pptx'
    prs.save(path)
    print(path)

if __name__=='__main__':
    MEDIA.mkdir(exist_ok=True,parents=True)
    if not (MEDIA/'BMO_logo.png').exists():
        raise FileNotFoundError(MEDIA/'BMO_logo.png')
    build(False);build(True)
    (OUT/'slide_content.json').write_text(json.dumps(SLIDE_DATA,indent=2,ensure_ascii=False),encoding='utf-8')
    (OUT/'sources.json').write_text(json.dumps(SOURCES,indent=2),encoding='utf-8')
