BMO — AGENTIC AI IN VS CODE TRAINING PACK

Start with START_HERE.html or open BMO_Agentic_AI_VS_Code.pptx.
The deck contains 28 slides and four embedded video clips.
The PDF is a static reference. Presentation.html is an offline browser player.

For learners, distribute lab/participant-starter.zip only.
Keep lab/solution for the facilitator debrief.

Open media/index.html for full-resolution screenshots, videos and provenance.
Open facilitator/presenter-guide.html or .pdf for a 55–60 minute workshop guide.
See VALIDATION.txt for checks and media/platform limitations.

All lab data is synthetic. Public BMO branding; training draft.

NEXT AGENT WITH GITHUB COPILOT ACCESS
Read handoff/NEXT_AGENT_START_HERE.txt first.
It maps exact missing Windows Copilot captures and four real lab recordings
to the existing slides. Portable rebuild scripts are in handoff/.
