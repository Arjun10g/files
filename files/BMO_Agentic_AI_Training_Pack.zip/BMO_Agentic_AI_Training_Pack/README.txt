AGENTIC AI IN VS CODE — FROM ANSWERS TO VERIFIED CHANGES
========================================================

Start by opening START_HERE.html. It links to the 20-slide presentation,
PowerPoint, slide PDF, presenter guide, prompts, lab ZIP and media library.

Recommended 38-minute teaching route, with four minutes available for
discussion (42 minutes total): slides 1–17 introduce the ideas; slide 18 is
the six-minute Windows lab; slides 19–20 close on evidence and next steps.
The timed script is in teaching/presenter-guide.html and .pdf.

STUDENT LAB
-----------
Extract demo/student_starter.zip into a new folder and open that folder in
VS Code. Use Python 3.10 or newer. From the extracted folder run:

    py -3 -m unittest -v test_shipping

If the Windows Python launcher is unavailable, use:

    python -m unittest -v test_shipping

The core lab needs no Python package installation, additional AI account,
API key or agent framework. Existing VS Code GitHub Copilot access supports
the optional chat exercise. See PROMPTS.md inside the starter ZIP or
teaching/prompts.html. The contract is in the ZIP's README.md.

EVIDENCE AND LIMITS
-------------------
Actual local tests for three instructor-authored snapshots: starter 3/6,
partial boundary patch 4/6, reference 6/6. These are not measured model
success rates. Charts of token volume and the Pareto frontier are teaching
illustrations, not usage telemetry or an accuracy benchmark.

The three guided clips are assembled from actual local macOS VS Code files
and test output, with editorial labels and timing. They are not footage of
an authenticated GitHub Copilot session and must not be presented as
Windows Copilot evidence. Genuine official VS Code UI images are labeled
as documentation examples. See media/index.html and the media manifest.

PRESENTER FILES
---------------
Presentation.html                     Browser slide viewer
BMO_Agentic_AI_VS_Code.pptx            Editable PowerPoint, notes and video
BMO_Agentic_AI_VS_Code.pdf             Static slide PDF
teaching/presenter-guide.html/.pdf    Detailed 20-slide teaching route
teaching/prompts.html                 Copy-ready examples
demo/student_starter.zip              Standalone student exercise
demo/instructor_reference.zip         Instructor-authored reference
media/index.html                      Source media, clips, captions
handoff/NEXT_AGENT.txt                Windows recapture and measurement plan
handoff/rebuild_visual.py             Portable deck rebuild source

PowerPoint embedded playback depends on local application support; the
media library provides direct MP4 links. The PDF is static.
