# Delivery fee lab

The store charges a **$5.00 delivery fee** when the cart total is **below $100.00**. Delivery is **free at $100.00 and above**. `delivery_fee(total_cents)` accepts a cart total in integer cents and returns the fee in integer cents. It raises `ValueError` for a negative total or any non-integer input, including `bool`.

## Run on Windows

1. Unzip `student_starter.zip` into a new folder and open that folder in VS Code.
2. Install Python 3.10 or newer if needed. In the VS Code terminal, check `py --version`. If `py` is unavailable, try `python --version`.
3. Run `py -m unittest -v test_shipping` (or `python -m unittest -v test_shipping`). No packages need installation.
4. The starter is supposed to fail three of the six checks. Use the prompts in `PROMPTS.md` and inspect every proposed edit.

The six checks cover $99.99, exactly $100.00, $100.01, a negative total, wrong input types, and the integer return type. Run the same command after every change. A passing test suite is evidence for these six cases; it is not proof about every possible input.

The custom agents in `.github/agents/` are optional. In VS Code Chat, select an agent by name if your installed Copilot interface offers workspace agents. The plain prompts also work in a regular agent chat. Agent features and tool approvals can vary by VS Code setup; check the selected agent and proposed file changes before accepting them.

Agent profile format and tool aliases: [VS Code custom agents](https://code.visualstudio.com/docs/agent-customization/custom-agents) and [GitHub custom agent configuration](https://docs.github.com/en/copilot/reference/custom-agents-configuration).
