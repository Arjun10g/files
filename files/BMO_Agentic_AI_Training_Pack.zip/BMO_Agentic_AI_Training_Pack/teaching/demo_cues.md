# Delivery fee live demo cues

Use a fresh extraction of `student_starter.zip` for each live attempt. Open that folder in VS Code, run `py -m unittest -v test_shipping` on Windows, and keep the terminal visible. The contract is in `README.md`; the four copy-ready prompts are in `PROMPTS.md`.

## 1. One bounded prompt

Start with **IMPLEMENT** in regular agent chat. Show the exact request and let the agent inspect the three local files. Before accepting an edit, ask the room what should happen at exactly 10000 cents. Inspect the diff and run all six tests. Report the result you actually see; the fixed snapshots are references, not evidence of a live agent run.

## 2. Sequential roles

Reset with a fresh starter extraction. Select **Planner** and paste PLAN. Then select **Builder** and paste IMPLEMENT. Finally select **Skeptic** and paste REVIEW. The Planner and Skeptic profiles have read/search access; Builder can edit and execute. Show how each role contributes a different artifact: plan, code plus test output, and a concrete counterexample or clean review. Inspect the Builder diff and rerun tests yourself.

## 3. Optional native parallel review

On a fresh or completed attempt, paste NATIVE PARALLEL if the selected VS Code harness supports subagents. The two independent reviews cover boundary/units and input types. If delegation is unavailable, run those reviews sequentially. Avoid parallel edits to the same `shipping.py`. Parallelism can reduce elapsed time but adds model calls; do not claim a saving without measurements.

## 4. Adversarial check and fallback

Show the instructor-authored `prompt_patch/shipping.py`: its `>=` boundary fixes exactly $100.00, while validation remains absent. Ask Skeptic for an input that breaks it, then run the shared tests in `prompt_patch/` (4/6 pass). Open `verified/shipping.py` and run the same tests (6/6 pass). State that these are prepared code snapshots, not observed Copilot outputs.

## Visible evidence and timing

Allow about 3 minutes for the live prompt, 4 minutes for sequential roles, 2 minutes for parallel review, and 2 minutes for the counterexample. For a shorter talk, show `results.json` and one terminal run. Six acceptance checks make the demo bounded; they do not prove every possible input. The minimum code to show on a slide is the `if` validation and return expression in `verified/shipping.py` (about 4 lines).

Read the measured snapshot counts from `demo/results.json`. If the live agent result differs, report the live count separately. Do not assign latency, token, or dollar figures to these snapshots; no model run was measured.
