# Power Automate / Orchestration Flow Specifications

## 1. Design rule

Use flows/services for durable cross-system work. Use Power Fx for UI state and simple CRUD.

Every flow must return/persist a correlation ID and use connection references/environment variables rather than hard-coded endpoints.

---

## 2. Flow: Jira Intake Upsert

**Purpose:** Create/update canonical Intake from BIDC Jira.

### Trigger

Approved webhook/event or scheduled incremental sync.

### Steps

1. Validate source signature/authentication.
2. Normalize Jira fields into canonical schema.
3. Find Intake by `(SourceSystem, SourceKey)`.
4. Create or update allowed fields.
5. Store attachment references/metadata as permitted.
6. Write `IntakeEvent`.
7. Optionally run readiness evaluation.
8. Return canonical Intake ID.

### Failure behavior

- Persist IntegrationJob.
- Retry transient failures.
- Dead-letter invalid mappings.
- Do not create a second Intake when retrying.

---

## 3. Flow: Evaluate Intake

**Purpose:** Server-side evaluation of visibility, blockers, warnings, mappings, and readiness.

### Inputs

- Intake ID
- evaluation mode: Draft / Grooming / Submit

### Steps

1. Load Intake + answers + components + attachments.
2. Load active rules for effective date.
3. Evaluate required visible questions.
4. Evaluate policy rules.
5. Evaluate deterministic component mappings.
6. Evaluate required document categories.
7. Calculate readiness.
8. Persist RuleExecution + current gaps/recommendations.
9. Return compact result to app.

---

## 4. Flow: Request ML Recommendations

Feature-flagged.

### Steps

1. Verify model use is enabled and user/status is eligible.
2. Build minimized feature payload.
3. Call approved `ComponentRecommendationService`.
4. Validate response schema/model version.
5. Persist Recommendation records.
6. Return recommendation IDs.

### Failure behavior

ML failure must **not** block the intake. Display:

> Automated recommendations are unavailable. Continue using component mappings/catalog search.

---

## 5. Flow: Create Digital Core Intake

**Purpose:** One-click DC creation after Pod confirmation.

### Preconditions

- user is authorized Pod role
- current state is eligible
- zero blocking validation gaps
- all selected components have complete summaries
- no successful previous job for the same idempotency key

### Steps

1. Create IntegrationJob.
2. Re-run authoritative submit validation.
3. Render downstream payload.
4. Create intake through supported DC backend/API/data operation.
5. Create/associate component rows.
6. Transfer/link attachments.
7. Capture DC intake ID/number.
8. Update canonical Intake.
9. Write back to Jira.
10. Record event and complete job.

### Idempotency key

`DC_CREATE:{IntakeId}:{SubmissionRevision}`

If a downstream ID already exists for the same revision, return it rather than creating another record.

---

## 6. Flow: Jira Write-back

**Purpose:** Keep BIDC ticket current without duplicating every intake field.

Write only approved operational fields:

- canonical Intake ID
- readiness/needs-info state
- current phase
- DC intake ID
- component confirmation status/count
- integration errors requiring action
- later estimate/approval status

Use a dedicated comment only for meaningful workflow events; avoid comment spam on every edit.

---

## 7. Flow: Component Catalog Sync

**Purpose:** Refresh authoritative AppCat/component metadata.

### Schedule

Use source-appropriate cadence; daily is a reasonable starting point if ownership changes are not real-time.

### Steps

1. Pull changed components from authoritative inventory.
2. Upsert Component by AppCat ID.
3. Update owner/team and flags.
4. Mark retired records inactive; do not hard-delete historical references.
5. Record source freshness.
6. Report unresolved owners/duplicates to admin queue.

---

## 8. Flow: Notify Needs Information

**Trigger:** Intake transitions to Needs Requester Information.

Message should include:

- BIDC/intake reference
- exact blocking gaps
- link to intake/Jira
- due/SLA if applicable

Do not send the entire intake payload.

---

## 9. Flow: Estimate request — Phase 2

For each confirmed IntakeComponent:

1. Resolve owning team/contact.
2. Create estimate request record.
3. Send/route component-specific scope.
4. Track due date/status.
5. Capture estimate and assumptions.
6. Update aggregate estimate once all required responses arrive.

Avoid using email as the only record of estimate state.

---

## 10. Flow: Business approval — Phase 2

When estimate set is complete:

- build concise approval package
- route through approved approval mechanism
- capture decision/actor/time/comments
- update Jira and intake state
- on approval, create delivery-ready handoff

---

## 11. Flow: Reconciliation

Scheduled job checks:

- Intake with DCSubmitted state but no downstream ID.
- downstream ID present but canonical status not updated.
- Jira linkage missing.
- failed IntegrationJobs older than threshold.
- components with owner/catalog data older than freshness threshold.

Create exceptions rather than silently correcting authoritative business decisions.

---

## 12. Flow naming convention

Example:

```text
DCI - 01 Jira Intake Upsert
DCI - 02 Evaluate Intake
DCI - 03 ML Recommendations
DCI - 04 Create DC Intake
DCI - 05 Jira Writeback
DCI - 06 Component Catalog Sync
DCI - 07 Needs Info Notification
DCI - 08 Reconciliation
```

Use solution-aware flows, connection references, and environment variables.

