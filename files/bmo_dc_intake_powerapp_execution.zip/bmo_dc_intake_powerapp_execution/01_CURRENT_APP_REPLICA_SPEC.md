# Current Digital Core Intake Power App — Replica Specification

## 1. Goal

Create a **parity clone** of the current Power App before introducing improvements. This provides a safe baseline, allows regression testing, and separates "replication" from "optimization".

Recommended approach:

1. Export the current application and dependencies into a dedicated Power Platform solution if access is available.
2. Clone into a Development environment as `Digital Core Intake vNext`.
3. Preserve the existing user-visible behavior first.
4. Add improvements behind feature flags.
5. Run parity/UAT against the existing application.

If export access is not available, reproduce the visible behavior below and complete the parity-discovery checklist before production use.

---

## 2. Global shell

### Left navigation

Replicate these visible navigation items and ordering:

| Order | Navigation item | Baseline behavior |
|---:|---|---|
| 1 | Home | Existing landing page / announcements / entry actions; exact content to verify. |
| 2 | New Intake | Starts or resumes a new intake. |
| 3 | My Intakes | Searches intakes where current user is submitter or PM. |
| 4 | Search | Broader intake lookup; exact scope and fields to verify in tenant. |
| 5 | Dashboard | Opens or embeds current reporting experience/Power BI. |
| 6 | Feedback Survey | Opens current feedback destination. |
| 7 | Help | Opens current guidance/help content. |

### Global header

Observed elements:

- Organization branding/header.
- Application title: Digital Core Intake Portal.
- Current user/avatar.
- Share/help/settings controls supplied by Power Apps shell.
- App/version text in left rail.
- Save As Draft and Submit on intake screens.

### Navigation behavior

- Persist unsaved-change state.
- Warn before navigation if dirty unless autosave is enabled.
- `Back`, `Prev`, and `Next` must not lose entered data.
- Submitted intakes become read-only according to status/security rules.

---

## 3. New Intake — tab layout

Replicate the visible tab order exactly:

1. Main Info
2. Planning
3. DC Components
4. Note
5. Attachments

Recommended implementation: responsive vertical navigation + a single form workspace. Maintain `CurrentSection` in app state and save the Intake header before child records such as components/attachments.

---

## 4. Main Info — visible baseline

Observed fields:

| Field | Required | Control | Notes |
|---|---:|---|---|
| Cost Estimation Request Type | Yes | Dropdown/choice | Exact choice set must be exported from current app. |
| Intake Status | System | Read-only label | Observed new value similar to `DC - New Intake`. |
| Requestor/PM | Yes | Person/lookup | Current user appears pre-populated in walkthrough. |
| Project Budget (CAD) | Yes | Currency/number | Default shown as 0. Validate non-negative. |
| Business Owner | Yes | Person/lookup | Search by last/first name. |
| Project Complexity | Yes | Dropdown/choice | Exact choice set to verify. |
| Line of Business (LOB) | Yes | Dropdown/choice | Controlled taxonomy. |
| Clarity Project Number | Yes | Text/project lookup | Placeholder indicates PR-style identifier or TBD; confirm authoritative source. |
| Clarity Project Name | Yes | Text/project lookup | Prefer lookup once project source is confirmed. |
| Business Case Description | Yes | Multiline text | Preserve for narrative context, but target state adds structured requirement fields. |
| DC Bundle Release Calendar | Link | Link/action | Preserve destination from current app. |

### Main Info parity acceptance

- Required indicators match current behavior.
- Save As Draft allows incomplete data.
- Submit blocks when current mandatory fields are missing.
- Person fields resolve the same directory population as production.
- Choice values and display ordering match production.
- Currency format and decimal rules match production.

---

## 5. Planning — visible baseline

The walkthrough shows multiple subsections and questions. Reproduce the observed controls and obtain the complete list from the existing solution before final parity signoff.

### Observed planning fields/questions

- National Implementation Date — date control observed in the walkthrough.
- Is this intake related to a Coded Project?
  - Guidance observed: select Yes only when an NDA is needed to access solution/requirement documents.
- Scope / Impact section:
  - Is this intake related to DC cloud adoption?
  - Should this Intake be part of the OLBB POD?
  - Will this intake have cross impact with CDB Web, Mobile or Admin application?
  - Link/reference to list of DC Freeze AppCats.
  - Does this intake request intend changes to TIBCO components? Exact complete wording/conditional fields must be read from the solution.
  - Will this project add new volume/change existing volume to credit card API and/or new volume to TSYS?
  - Will Digital Core PM be required for the work related to the scope of this intake?
    - Guidance observed: DC PM engagement is approved based on project complexity/size.
- Team Engagement section:
  - Does intake information need to be shared with ETO Digital Core Engineering team?
  - Does intake information need to be shared with Cloud Engineering team?
  - Current guidance indicates the project separately engages these teams for estimates when applicable.
- Contacts section:
  - Digital Core Contact Who Worked on Solution Development, if any.
  - Solution Architecture Contact from Project Team — observed as required.

### Parity rule

Do not infer missing production questions from the video. Export or inspect the current form and build a complete `QuestionDefinition` inventory before production cutover.

---

## 6. DC Components — visible baseline

### Component selector

Observed behavior:

- Search by **AppCat ID or Short Name**.
- Scrollable component catalog.
- Selecting a component displays its description/details in an adjacent panel.
- `Add to DC Components list` action.
- Instructions tell the requester to include impacted Digital Core components, including related/unchanged systems that may be needed for support/testing.
- Warning indicates missed support/testing systems can affect budget/resource availability/delivery timelines.

Visible example AppCat catalog entries in the walkthrough include technologies such as Enterprise API, API Connect, Digital Core services, EBS, eForm, POSE, etc. Do not seed production from video examples; import the authoritative component inventory.

### Selected Components table

Observed columns:

| Column | Behavior |
|---|---|
| AppCat | AppCat ID + short name. |
| STO Name | Resolved owner/contact from inventory. |
| Component Change Summary | Mandatory per-component multiline input; guidance asks for anticipated summary to avoid delays. |
| Actions | Delete/remove; information/details action. |

### Replica behavior

- Prevent duplicate AppCat selection.
- Removing a component requires confirmation once a change summary exists.
- Selected component records are persisted as children of the Intake.
- STO owner is derived from the authoritative inventory, not manually typed.
- Submit must block if any selected component lacks the mandatory Component Change Summary.

---

## 7. Note — visible baseline

Observed fields:

- Additional Information (Impacts on Digital Core, Architecture Change(s), etc.) — multiline.
- Comments — multiline/add comment.
- Comments History — expandable history.

Replica requirements:

- Additional Information is part of the intake record.
- Comments are append-only events, not destructive edits to history.
- Store author and timestamp.
- Preserve ordering and audit trail.

---

## 8. Attachments — visible baseline

Observed behavior:

- Attachments tab.
- Empty state: nothing attached.
- `Attach file` action.
- Submit available after validation.

Replica requirements:

- Preserve original file name, MIME type, size, uploader, timestamp.
- Malware/security handling follows existing enterprise standard.
- Attachment delete/replace is audited.
- Target state will add required-document categories and completeness rules.

---

## 9. My Intakes — visible baseline

Observed header indicates the page searches intakes where the current user is submitter or PM.

Visible controls:

- Toggle: Show editable intakes only.
- Search by Intake number / PR Code / PR Name.
- Filter by estimation type.
- Filter by status.
- Filter by LOB.
- Implementation date Year and Month.
- Search.
- Reset All.

Visible grid columns:

- Submission Type
- Intake Number
- Intake Status
- Project Number
- Project Name

Observed archive notice indicates older intakes may be archived and accessed via a separate reporting path. Preserve current archive behavior or explicitly replace it in target state.

---

## 10. Search, Dashboard, Home, Feedback, Help

The walkthrough does not expose enough detail to reproduce these screens exactly.

Before parity signoff, record for each:

- Data source.
- Filters.
- Navigation target.
- Role visibility.
- Embedded/external URL behavior.
- Error/empty state.
- Analytics events.

Dashboard appears to involve Power BI/loading behavior. Treat the report as an external dependency unless it is included in the Power Platform solution.

---

## 11. Status model — parity discovery required

Only the new-intake state is directly visible. Extract the full production status set and transitions.

Minimum fields to capture:

- status code
- display label
- editable by requester?
- editable by Digital Pod?
- allowed next status
- entry validation
- exit validation
- notification behavior
- SLA timer behavior

Do not introduce a new lifecycle until this inventory is complete.

---

## 12. Parity-discovery checklist

A Power Platform maker/admin should inspect the existing solution and fill this table before build freeze:

| Area | Evidence to capture |
|---|---|
| App type | Canvas/custom page/model-driven composition. |
| Solution | Solution name, publisher, managed/unmanaged state. |
| Data sources | Dataverse/SharePoint/SQL/custom connector/other. |
| Tables/lists | Logical names, primary keys, relationships, ownership model. |
| Choice sets | Every option and sort order. |
| Power Fx | Screen OnVisible, submit, save, navigation, visibility, validation formulas. |
| Flows | Trigger, actions, connection references, owners, error handling. |
| Custom connectors | Base URL, auth type, operations, DLP classification. |
| Environment variables | Names and values by environment. |
| Security roles | App sharing groups, table privileges, field security. |
| Directory lookups | Connector/API used for people search. |
| Component inventory | Authoritative source and update cadence. |
| Archive | Rule and report/reopen path. |
| Notifications | Email/Teams or other notifications and templates. |
| Dashboard | Power BI workspace/report IDs and RLS. |
| Help/feedback | Exact destinations and owners. |
| Status lifecycle | Complete state machine. |

---

## 13. Replica definition of done

The clone is parity-complete when:

- All current visible pages/controls work with current production option sets.
- Existing users can complete the same happy path without retraining.
- Draft/submission behavior matches production.
- All current required validations match.
- Current component catalog and owners resolve correctly.
- Existing attachments/comments behavior matches.
- My Intakes results match for a controlled test user/data set.
- Existing flows/integrations either run unchanged or have verified equivalents.
- Role/security behavior matches.
- UAT signs off before any optimization feature is made mandatory.

