# Test and Acceptance Plan

## 1. Test stages

1. Current-state parity testing.
2. Data model/unit-level validation.
3. Rules and decision-tree tests.
4. Power App functional testing.
5. Integration testing.
6. Security/role testing.
7. Performance/delegation testing.
8. ML offline validation if enabled.
9. UAT with Requesters + Digital Pod.
10. Production smoke and reconciliation.

---

## 2. Parity test set

Create reference cases in the current app and vNext using the same safe test data.

Validate:

- Main Info required fields.
- Draft with incomplete data.
- Planning control values.
- contacts.
- component search by AppCat ID.
- component search by short name.
- component description display.
- component add/remove.
- STO owner display.
- mandatory component change summary.
- notes/comments/history.
- attachments.
- Submit validation.
- My Intakes filters/results.
- status/editability.

Document every intentional difference as either an improvement or defect.

---

## 3. Decision-tree test cases

Use table-driven tests.

Example:

| Case | Inputs | Expected visible questions |
|---|---|---|
| API response add | API + response change + add field | field details, source, backward compatibility, volume/performance as configured |
| Batch change | Batch | frequency, source/destination, file/record details |
| Unknown technical interface | Unknown | business questions + discovery flag; no forced API fields |
| No volume change | Volume = No | hide volume-detail follow-ups |

Every QuestionDefinition parent condition should have at least true/false test coverage.

---

## 4. Rules tests

For every active rule store:

- positive fixture
- negative fixture
- effective-date boundary
- conflict/priority case if relevant
- expected severity/output

Automate rules tests outside the Canvas UI where possible.

---

## 5. Readiness tests

Validate:

- draft can save at any readiness level.
- blocker prevents submit.
- warning does not behave like blocker unless configured.
- invisible questions do not count as missing.
- changing a parent answer re-evaluates child requirements.
- removing a required component/attachment immediately changes readiness.
- server submit evaluation matches client display.

---

## 6. Component tests

- duplicate component cannot be selected.
- retired component is not offered as a normal current selection.
- owner/team is current from catalog sync.
- owner freshness warning appears when configured.
- component summary is mandatory.
- structured fields render the expected downstream text.
- removal is audited.
- recommendation accept/reject is auditable.

---

## 7. Jira integration tests

- create from new Jira issue.
- update existing pre-submission issue.
- retry same webhook without duplicate Intake.
- malformed field handling.
- missing optional fields.
- unauthorized request rejected.
- write-back succeeds.
- write-back failure queues retry without losing DC state.

---

## 8. DC submission tests

- valid submission creates one and only one DC intake.
- repeat submit returns/reuses existing downstream record for same revision.
- mandatory validation error does not create partial record.
- transient downstream failure retries safely.
- permanent validation failure surfaces exact actionable message.
- components and summaries match canonical records.
- attachments/references are preserved.
- downstream ID is written to canonical Intake and Jira.

---

## 9. Security tests

For each role verify:

- record read scope
- edit scope
- submit capability
- admin configuration access
- direct table access
- attachment access
- budget/estimate field access
- audit visibility

Test privilege bypass, not just hidden buttons.

---

## 10. Performance tests

Target representative production volumes.

Test:

- My Intakes query delegability.
- component catalog search with full inventory.
- dynamic question rendering.
- readiness evaluation latency.
- recommendation service timeout behavior.
- attachment upload limits.
- concurrent users at expected peak.

Set explicit internal SLAs after measuring the current app; do not invent targets disconnected from platform/network reality.

---

## 11. ML validation — if enabled

Offline release gates should include:

- time-based holdout dataset.
- Precision@3.
- Recall@5.
- per-domain recall.
- false high-confidence review.
- recommendation volume per intake.
- component coverage.

UAT also measures:

- Pod acceptance rate.
- time saved in discovery.
- manually added components missed by model.

Do not deploy solely based on aggregate accuracy.

---

## 12. UAT scenarios

Use at least:

1. Simple known existing API change.
2. Multi-component API + business-logic change.
3. Requester does not know technical service.
4. Cloud-impacting intake.
5. TIBCO-impacting intake.
6. Cross-impact/freeze AppCat scenario.
7. Missing required artifact.
8. Complex intake needing SA/SME clarification.
9. Jira-linked intake with attachments.
10. DC submission failure/retry.

Have both experienced and less-experienced requesters test; the target is to reduce dependence on tribal knowledge.

---

## 13. Acceptance criteria for MVP

MVP is ready when:

- parity tests pass or intentional deviations are approved.
- no blocker can be bypassed through the app.
- canonical structured fields persist correctly.
- dynamic question tree behaves correctly.
- component catalog/ownership is authoritative and searchable.
- Pod can confirm components and complete structured summaries.
- one-click DC submission works through supported backend integration in non-prod.
- retries are idempotent.
- Jira/DC references reconcile.
- security roles pass UAT.
- ML can be disabled without functional loss.
- runbook and operational ownership are accepted.

