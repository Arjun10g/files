# Jira and Digital Core Integration

## 1. Integration goal

Remove manual re-keying between the BIDC Jira gate and the Digital Core intake while preserving Digital Pod grooming and final submission control.

Preferred pattern:

```mermaid
sequenceDiagram
    participant R as Requester
    participant J as BIDC Jira
    participant I as Intake Orchestration
    participant P as Power App
    participant D as Digital Pod
    participant DC as DC Backend / Current Data Source

    R->>J: Create BIDC request
    J->>I: Create/update event or scheduled sync
    I->>P: Create/update canonical Intake
    D->>P: Groom, classify, confirm components
    P->>I: Request DC submission
    I->>I: Server-side validation + idempotency check
    I->>DC: Create DC intake + components + attachments
    DC-->>I: DC intake ID/status
    I->>P: Persist success/failure
    I->>J: Write back DC intake ID/status
```

---

## 2. Do not automate the UI unless necessary

The current portal is a Power App. First discover:

- underlying Dataverse/SharePoint/SQL tables
- Power Automate flows
- custom connectors/APIs
- create/update operations

Use those supported interfaces.

Avoid Playwright/browser clicking as the primary production integration because UI control IDs, layout, authentication sessions, and timing can change independently of the business contract.

---

## 3. Jira inbound

### Trigger choices

Preferred order:

1. Jira webhook/event through approved integration.
2. Jira automation calling an approved endpoint.
3. Scheduled incremental sync by updated timestamp.
4. Manual "Import BIDC" action as fallback.

### Idempotency

Use `(SourceSystem = Jira, SourceKey = BIDC-1234)` as a unique key.

Inbound upsert rules:

- If not found: create Intake.
- If found and still pre-submission: update mapped fields where Jira is authoritative.
- If already DC-submitted: update only fields approved for post-submission synchronization; otherwise create a change event/exception.

---

## 4. Initial field mapping

The exact semantics must be confirmed with process owners before production.

| Jira/BIDC source | Canonical field | Current DC field |
|---|---|---|
| Jira key | SourceKey | External reference / note if no native field |
| Summary | Source summary | Business Case Description support text |
| Requester | Requestor | Requestor/PM, subject to role semantics |
| Project PR/Clarity code | ClarityProjectNumber | Clarity Project Number |
| Project name | ClarityProjectName | Clarity Project Name |
| Business owner | BusinessOwner | Business Owner |
| LOB/channel fields | LOB/Channel | Line of Business plus canonical metadata |
| Target release/date | NationalImplementationDate / target release | Planning/date fields |
| Description | Current/Desired behavior + narrative | Business Case Description / Additional Info |
| Attachments | IntakeAttachment | Attachments |
| Groomed components | IntakeComponent | DC Components |
| Per-component summary | RenderedChangeSummary | Component Change Summary |

Do not map Jira fields solely by display name. Record source field IDs and target logical names.

---

## 5. Jira write-back

After significant transitions, write back:

- canonical intake ID
- DC intake number once created
- readiness/blocking status
- confirmed component count
- current phase
- DC submission success/failure
- estimate/business approval status in later phase

Keep the write-back concise; Jira remains a gate/work item, not a duplicate full database.

---

## 6. DC submission adapter

Create one integration boundary called `DCCreateIntake` even if the implementation initially targets the current app's underlying tables/flows.

Input should include:

- intake header
- planning answers
- contacts
- selected components
- rendered component summaries
- attachments/references
- source key
- correlation ID

Output:

- success/failure
- DC intake ID/number
- downstream status
- validation messages
- correlation ID

This abstraction allows the current DC backend to change without rewriting the Power App.

---

## 7. Server-side pre-submit validation

Before downstream creation, re-evaluate:

- required header fields
- required visible planning questions
- blocking policy rules
- selected components
- component summaries
- required attachments
- duplicate/idempotency state
- user authorization

The Power App's client validation is convenience; server-side validation is authoritative.

---

## 8. Attachments

Options, in preferred order:

1. Pass references to an approved enterprise document store when downstream supports links.
2. Copy files through an approved connector/API.
3. Use current Power App storage mechanism when that is the authoritative intake store.

Never download files to a client and re-upload through UI automation as the normal path.

---

## 9. Error handling

All integration failures create an IntegrationJob record.

Retry only transient errors:

- timeouts
- 429/throttling
- temporary 5xx

Do not blindly retry:

- validation errors
- unauthorized/forbidden
- missing component IDs
- duplicate conflict requiring reconciliation

Provide Pod UI:

- failed job
- sanitized reason
- last attempt
- retry action where safe
- open intake button

---

## 10. Reconciliation

Scheduled reconciliation should compare:

- canonical DC intake ID/status
- downstream DC record status
- Jira linkage/status

Flag mismatches such as:

- DC record exists but canonical record lacks ID
- Jira says submitted but DC creation failed
- downstream component list differs after manual edit

Decide which system is authoritative for each field and document it explicitly.

---

## 11. Authentication

Use service-to-service credentials approved by the bank:

- Entra application/service principal if supported
- managed connection reference/service account where required
- custom connector OAuth where applicable

Never use a named employee's interactive Power App session as the automation credential.

---

## 12. Observability

Every cross-system transaction should carry a correlation ID and log:

- source key
- intake ID
- DC intake ID if created
- operation
- timestamp
- result
- latency
- retry count

Do not log full sensitive payloads when IDs/field-level telemetry are sufficient.

