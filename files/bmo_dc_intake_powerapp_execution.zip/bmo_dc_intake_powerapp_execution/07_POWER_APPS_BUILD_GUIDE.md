# Power Apps Build Guide

## 1. Build strategy

Use the current app as the parity source. Build improvements inside a dedicated solution and development environment.

Recommended solution contents:

- Canvas app: `DC Intake vNext`
- Dataverse tables/columns/choices or mapped legacy data source
- Power Automate cloud flows
- Custom connectors if required
- Environment variables
- Connection references
- Security roles
- Power BI references if owned by the solution architecture

Deploy managed solutions to Test/UAT/Prod where consistent with enterprise Power Platform ALM.

---

## 2. Screen/component structure

Suggested Canvas structure:

```text
App
├── cmpHeader
├── cmpLeftNav
├── cmpProgressTabs
├── cmpReadinessPanel
├── cmpBlockingMessages
├── scrHome
├── scrNewIntake
│   ├── conMainInfo
│   ├── conGuidedRequirement
│   ├── conPlanning
│   ├── conComponents
│   ├── conNotes
│   ├── conAttachments
│   └── conReview
├── scrMyIntakes
├── scrGroomingWorkbench
├── scrSearch
├── scrAdminTaxonomy
├── scrAdminQuestions
└── scrAdminRules
```

Use responsive containers; avoid pixel-positioning the entire application.

---

## 3. App initialization pattern

Conceptual Power Fx:

```powerfx
Concurrent(
    ClearCollect(colFeatureFlags, Filter('Feature Flags', Active = true)),
    ClearCollect(colLOB, Filter('Lines of Business', Active = true)),
    ClearCollect(colCapabilities, Filter(Capabilities, Active = true)),
    ClearCollect(colChangeTypes, SortByColumns(Filter('Change Types', Active = true), "SortOrder")),
    ClearCollect(colQuestionDefinitions, Filter('Question Definitions', Active = true))
);
Set(varUserEmail, Lower(User().Email));
Set(varCurrentSection, "MainInfo");
```

Treat this as a pattern; adapt logical table/column names after solution inspection.

---

## 4. Intake creation

Create the intake header early so child records can be saved incrementally.

Conceptual pattern:

```powerfx
If(
    IsBlank(varIntakeId),
    Set(
        varIntake,
        Patch(
            Intakes,
            Defaults(Intakes),
            {
                Status: 'Intake Status'.Draft,
                SourceSystem: "PowerApp"
            }
        )
    );
    Set(varIntakeId, varIntake.IntakeId)
)
```

For Jira-launched records, lookup by SourceKey first and reuse the existing Intake.

---

## 5. Main Info

Use EditForm where useful for simple header fields, but do not force every dynamic question into a static form.

Recommendations:

- Person fields use approved directory/Dataverse user lookup.
- Project number/name should become a lookup if authoritative project data is accessible.
- Set Requestor to current user on create, but allow authorized changes if current process supports it.
- Keep Intake Status read-only for general users.

---

## 6. Dynamic question renderer

Use a gallery over `QuestionDefinition` records whose parent conditions are satisfied.

Pseudo-pattern:

```powerfx
Filter(
    colQuestionDefinitions,
    Section = varCurrentSection &&
    (
        IsBlank(ParentQuestionId) ||
        LookUp(
            colAnswers,
            QuestionId = ParentQuestionId,
            AnswerNormalized
        ) = ParentTriggerValue
    )
)
```

Create reusable question components by answer type:

- Boolean
- Choice
- Text
- Multiline
- Date
- Number/currency
- Person

Persist answers on change or when navigating sections.

For more complex parent conditions, evaluate in a Power Automate/service layer and return visible question IDs rather than embedding a general expression interpreter in Power Fx.

---

## 7. Cascading capability taxonomy

Example:

```powerfx
Filter(Capabilities, ParentCapabilityId = drpCapabilityL1.Selected.CapabilityId && Active = true)
```

Show deeper level only after parent selection. Store the deepest confirmed node on the Intake.

---

## 8. Readiness panel

Use a server-evaluated readiness record where possible.

Client presentation:

```powerfx
"Intake Readiness — " & Text(varReadinessPercent) & "%"
```

Buttons:

```powerfx
DisplayMode = If(varBlockingGapCount = 0, DisplayMode.Edit, DisplayMode.Disabled)
```

Do not depend exclusively on the client `DisplayMode`; final submit flow revalidates server-side.

---

## 9. Component explorer

Target layout:

### Left/top

- Recommended Components gallery.
- Search AppCat catalog.
- Filter by domain/technology if useful.

### Details pane

- AppCat ID
- Short name
- description
- owning team/STO contact
- lifecycle/freeze warning
- reason/evidence if recommended

### Selected Components

Replicate current fields, then add structured summary editor.

Prevent duplicate selection:

```powerfx
If(
    IsBlank(LookUp('Intake Components', IntakeId = varIntakeId && ComponentId = galComponents.Selected.ComponentId)),
    Patch('Intake Components', Defaults('Intake Components'), {...}),
    Notify("Component already selected", NotificationType.Information)
)
```

---

## 10. Structured Component Change Summary

Do not require users to author the final downstream paragraph manually.

Store structured fields and render a deterministic summary:

```text
Current behavior: {CurrentBehavior}
Requested behavior: {RequestedBehavior}
Change type: {ChangeType}
Input impact: {InputChange}
Output impact: {OutputChange}
Dependencies: {DependencySummary}
Testing impact: {TestImpact}
Assumptions: {Assumptions}
```

Power Fx can concatenate this for preview, but consider rendering in a flow/service so the exact downstream format is centrally versioned.

---

## 11. Recommendation UI

ML or rule recommendations must be visually distinct from confirmed selections.

Recommended card fields:

- component name/AppCat
- `Recommended` / `Possible`
- confidence only if ML
- reason
- historical support count
- Accept
- Reject

Reject can optionally ask a short reason from Pod users. Do not ask ordinary requesters to reason about model behavior.

---

## 12. Save as Draft

Draft save should:

1. Patch header.
2. Save dynamic answers.
3. Save component edits.
4. Save notes.
5. Leave blocking validations as messages but not prevent draft.
6. Record event `DraftSaved`.

Use a single orchestrated save action to reduce partial state.

---

## 13. Submit

Submit action:

1. Disable button and show progress.
2. Call `ValidateIntakeForSubmission` flow/service.
3. If blockers: refresh gap panel; remain editable.
4. If valid: update status and create submission IntegrationJob.
5. If DC submission is enabled and Pod-approved: call DC adapter.
6. Display success with intake IDs.
7. Persist full event history.

Do not run a long multi-system submission purely in Power Fx if a durable flow/service can own retries and logging.

---

## 14. My Intakes and Workbench

Use delegable queries against Dataverse. Avoid loading all intakes into a collection and filtering client-side.

Indexes/search fields should support:

- Intake number
- source Jira key/PR/project number
- status
- LOB
- implementation date
- requestor/PM
- business owner

Add a separate Pod workbench for action-oriented views rather than overloading My Intakes.

---

## 15. Accessibility

- Logical tab order.
- Accessible labels for all controls.
- Do not communicate status only with color.
- Keyboard-accessible component search/selection.
- Visible error summary and per-field errors.
- Sufficient responsive behavior for approved desktop/tablet form factors.

---

## 16. Performance

- Use delegable Dataverse queries.
- Cache small reference tables only.
- Paginate/search large AppCat catalog server-side.
- Avoid repeated directory lookups on every keystroke.
- Lazy-load historical similarity only on component/discovery view.
- Do not download all historical intakes to the client.

---

## 17. Telemetry

Capture application/business telemetry through approved mechanisms:

- screen/section entered
- draft saved
- blockers encountered
- component recommendation accepted/rejected
- submit attempted/succeeded/failed
- integration failure

Do not send business-case text or attachment content to telemetry unless specifically approved.

