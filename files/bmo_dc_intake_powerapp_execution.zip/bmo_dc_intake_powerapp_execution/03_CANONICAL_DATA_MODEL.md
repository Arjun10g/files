# Canonical Data Model

## 1. Recommended persistence

Use **Dataverse** for the vNext canonical model if permitted by the platform architecture. If the current app uses another supported enterprise data source, either map the same logical model there or use Dataverse as an orchestration layer and synchronize to the legacy source.

Do not design the improved app around free-text Jira descriptions or screen controls. Design it around the logical entities below.

---

## 2. Entity relationship model

```mermaid
erDiagram
    INTAKE ||--o{ INTAKE_ANSWER : has
    INTAKE ||--o{ INTAKE_COMPONENT : affects
    INTAKE ||--o{ INTAKE_ATTACHMENT : contains
    INTAKE ||--o{ INTAKE_COMMENT : has
    INTAKE ||--o{ INTAKE_EVENT : audits
    INTAKE ||--o{ RECOMMENDATION : receives
    INTAKE ||--o{ INTEGRATION_JOB : triggers
    INTAKE }o--|| PROJECT : references
    INTAKE }o--|| CAPABILITY : classified_as
    INTAKE_COMPONENT }o--|| COMPONENT : selects
    COMPONENT }o--|| TEAM : owned_by
    QUESTION_DEFINITION ||--o{ INTAKE_ANSWER : answered_by
    RULE_DEFINITION ||--o{ RULE_EXECUTION : executes
    INTAKE ||--o{ RULE_EXECUTION : evaluated_for
    COMPONENT ||--o{ COMPONENT_MAPPING : participates
    CAPABILITY ||--o{ COMPONENT_MAPPING : maps_to
```

---

## 3. Intake

Suggested logical fields:

| Field | Type | Purpose |
|---|---|---|
| IntakeId | GUID | Primary key. |
| IntakeNumber | Text/autonumber | User-facing DC intake identifier. |
| SourceSystem | Choice | Jira, Power App direct, migration, other. |
| SourceKey | Text | Jira key or source record ID; unique with SourceSystem. |
| SubmissionType | Choice | Mirrors current submission/cost estimation type. |
| Status | Choice | Lifecycle state. |
| StatusReason | Choice/Text | Detailed reason. |
| Requestor | User/Contact | Requester/PM. |
| BusinessOwner | User/Contact | Business owner. |
| LOB | Lookup/Choice | Controlled LOB. |
| Region | Choice | CA/US/etc. |
| Channel | Lookup/Choice | BDB/BBS/assisted/etc. |
| ProjectId | Lookup | Project master record. |
| ClarityProjectNumber | Text | Current field. |
| ClarityProjectName | Text | Current field. |
| ProjectBudgetCAD | Currency | Current field. |
| ProjectComplexity | Choice | Current field. |
| BusinessCaseDescription | Multiline | Current narrative. |
| NationalImplementationDate | Date | Current planning field. |
| CapabilityId | Lookup | Deepest confirmed capability node. |
| ChangeType | Choice | New/modify/defect/retire/etc. |
| IntegrationType | Choice | API/event/batch/file/data/other. |
| CurrentBehavior | Multiline | Structured requirement. |
| DesiredBehavior | Multiline | Structured requirement. |
| KnownServiceOrApi | Text/Lookup | Optional known interface. |
| BackwardCompatibility | Choice | Yes/No/Unknown/NA. |
| DataImpact | Choice | Yes/No/Unknown. |
| VolumeImpact | Choice | Increase/decrease/no/unknown. |
| ReadinessPercent | Whole number | Derived. |
| BlockingGapCount | Whole number | Derived. |
| WarningCount | Whole number | Derived. |
| CurrentPhase | Choice | Grooming/discovery/etc. |
| CurrentOwnerTeam | Lookup | Work queue ownership. |
| CreatedOn / ModifiedOn | System | Audit. |
| SubmittedOn | DateTime | Submission. |
| DcSubmittedOn | DateTime | Downstream submission. |

Create a unique alternate key on `(SourceSystem, SourceKey)` to prevent duplicate Jira ingestion.

---

## 4. PlanningAnswer vs generic IntakeAnswer

The safest extensible pattern is a metadata-driven question system.

### QuestionDefinition

| Field | Type |
|---|---|
| QuestionId | GUID/text key |
| Section | Choice |
| QuestionText | Text |
| HelpText | Multiline |
| AnswerType | Choice: boolean/choice/date/text/number/person |
| ChoiceSetKey | Text/lookup |
| IsRequired | Boolean |
| SortOrder | Whole number |
| ParentQuestionId | Lookup nullable |
| ParentOperator | Choice |
| ParentTriggerValue | Text |
| EffectiveFrom/To | Date |
| Active | Boolean |
| PolicyReference | Text/link |

### IntakeAnswer

| Field | Type |
|---|---|
| Intake | Lookup |
| Question | Lookup |
| AnswerText | Text |
| AnswerNumber | Decimal |
| AnswerDate | Date |
| AnswerBoolean | Boolean |
| AnswerChoice | Text/lookup |
| AnswerPerson | User/Contact |
| AnsweredBy | User |
| AnsweredOn | DateTime |
| Source | Choice: requester/rule/model/Pod/import |
| Confirmed | Boolean |

This avoids adding a database column every time a planning question changes.

---

## 5. Capability taxonomy

### Capability

| Field | Purpose |
|---|---|
| CapabilityId | Key |
| Name | Display name |
| ParentCapabilityId | Tree parent |
| Level | L1/L2/L3/L4 |
| LOB | Optional association |
| Active | Lifecycle |
| SortOrder | UI |
| ExternalCode | Mapping to enterprise taxonomy if available |

Example hierarchy:

```text
Consumer Banking
└── Deposits
    └── Savings
        └── Savings Goal
```

Do not hard-code this tree in Power Fx.

---

## 6. Component inventory

### Component

| Field | Purpose |
|---|---|
| ComponentId | Internal key |
| AppCatId | Authoritative AppCat ID |
| ShortName | Search/display |
| Description | Current right-panel text |
| Domain | Controlled domain |
| Technology | Optional |
| OwningTeamId | Lookup |
| STOContact | User/contact or team contact |
| LifecycleStatus | Active/frozen/retired/etc. |
| IsFreezeAppCat | Boolean |
| CloudFlag | Boolean |
| TibcoFlag | Boolean |
| ApiFlag | Boolean |
| SourceSystem | Inventory source |
| SourceUpdatedOn | Freshness |

### Team

| Field | Purpose |
|---|---|
| TeamId | Key |
| TeamName | Display |
| TeamType | DC/Cloud/ETO/etc. |
| DistributionContact | Group/email/team endpoint |
| Active | Lifecycle |

Never rely solely on a person's name for component ownership. Store team ownership and optional contacts separately.

---

## 7. IntakeComponent

This is the most important child entity.

| Field | Purpose |
|---|---|
| IntakeComponentId | Key |
| IntakeId | Parent |
| ComponentId | AppCat/component |
| RecommendationSource | Rule/ML/manual/history |
| RecommendationConfidence | 0–1 nullable |
| RecommendationReason | Short explanation |
| ReviewDecision | Accepted/rejected/manual-added/pending |
| ReviewedBy/On | Audit |
| CurrentBehavior | Component-specific current state |
| RequestedBehavior | Component-specific target state |
| ChangeType | API/data/logic/batch/etc. |
| InputChange | Text |
| OutputChange | Text |
| DataChange | Text |
| DependencySummary | Text |
| NfrImpact | Text |
| TestImpact | Text |
| Assumptions | Text |
| OpenQuestions | Text |
| TargetRelease | Text/date |
| RenderedChangeSummary | Multiline | Deterministic downstream text. |
| OwningTeamSnapshot | Text/lookup | Ownership at time of submission. |
| EstimateAmount | Currency nullable |
| EstimateStatus | Choice |

---

## 8. Attachments

### IntakeAttachment

| Field | Purpose |
|---|---|
| IntakeAttachmentId | Key |
| IntakeId | Parent |
| DocumentCategory | SA/API spec/DFR/requirements/diagram/other |
| File | File column or approved document store reference |
| OriginalFileName | Audit |
| RequiredByRuleId | Optional reference |
| UploadedBy/On | Audit |
| CurrentVersion | Boolean/version metadata |

Avoid copying sensitive files between systems unless required. Prefer references where enterprise policy supports them.

---

## 9. Rules

### RuleDefinition

Use a constrained declarative schema rather than arbitrary code.

| Field | Purpose |
|---|---|
| RuleId | Key |
| Name | Human-readable |
| RuleType | RequireField/RequireDoc/RecommendComponent/RecommendTeam/SetWarning/SetValue |
| InputField | Canonical field/question |
| Operator | EQ/NEQ/IN/CONTAINS/GT/LT/etc. |
| CompareValue | Serialized simple value |
| OutputTarget | Field/doc/component/team/message |
| OutputValue | Value/reference |
| Severity | Blocking/Warning/Info |
| Priority | Conflict order |
| EffectiveFrom/To | Versioning |
| PolicyReference | Governance traceability |
| Active | Boolean |

For multi-condition rules, use a RuleCondition child table with `ConditionGroup` and AND/OR semantics rather than embedding executable expressions.

---

## 10. Recommendation

Store every ML/rule suggestion, including rejected ones.

| Field | Purpose |
|---|---|
| IntakeId | Parent |
| RecommendationType | Domain/component/owner/similar intake |
| TargetId | Suggested entity |
| Score | Confidence/relevance |
| Source | Rule/model/history |
| ModelVersion | If applicable |
| Explanation | Feature/rule evidence |
| Decision | Accepted/rejected/pending |
| DecisionBy/On | Human feedback |
| OverrideReason | Optional |

This table is the feedback dataset for future model improvement.

---

## 11. IntegrationJob

Persist asynchronous integration state; never hide failures inside a flow run history only.

Fields:

- JobId
- IntakeId
- JobType: JiraInbound/JiraOutbound/DCSubmit/EstimateSync/etc.
- IdempotencyKey
- State: queued/running/succeeded/failed/dead-letter
- AttemptCount
- LastAttemptOn
- ExternalRecordId
- ErrorCode
- SanitizedErrorMessage
- CorrelationId
- PayloadHash

---

## 12. Audit/event log

Create `IntakeEvent` for business-visible history:

- event type
- old/new status
- actor
- time
- comment
- source system
- correlation ID

Do not rely only on Dataverse technical auditing for operational history.

---

## 13. Status proposal for vNext

Only introduce this after mapping current statuses.

```text
Draft
Needs Requester Information
Ready for Grooming
Grooming
Discovery
Needs SME / Architecture
Components Confirmed
Ready for DC Submission
DC Submitted
Waiting for Estimates
Estimate Complete
Waiting for Business Approval
Approved
Delivery Ready
In Delivery
Closed
Cancelled
```

Map legacy statuses to these phases rather than deleting them immediately.

