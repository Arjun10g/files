# Classical ML Classification Design

## 1. Scope

ML is optional and must be removable without breaking the application. It provides **recommendations**, not approvals or mandatory routing.

If all AI/ML is blocked, deploy the rules-only system and capture structured data/Pod decisions so the training dataset exists when approval arrives.

---

## 2. ML use cases

Recommended initial use cases:

1. Hierarchical business/domain classification.
2. Multi-label Digital Core component/AppCat recommendation.
3. Historical similarity retrieval.
4. Optional owning-team recommendation when component ownership is ambiguous.

Do **not** start with:

- autonomous approval
- autonomous architecture decisions
- automatic budget/quote generation
- hidden prioritization

---

## 3. Training labels

Historical data should produce:

### Inputs

- LOB
- region/channel
- capability taxonomy if derivable
- cost estimation/request type
- complexity
- target timing
- integration type
- new/modify/defect
- planning answers
- known API/service
- structured change indicators
- optional business-case text

### Labels

- confirmed capability/domain
- confirmed AppCat IDs/components
- confirmed owning team
- final DC intake category

The component problem is **multi-label** because one intake can affect multiple components.

---

## 4. Data preparation

### Required extraction

Join historical:

- BIDC Jira item
- final DC intake
- selected AppCats/components
- ownership
- status/outcome
- timestamps

Create a durable `HistoricalIntakeTraining` table/file with one canonical row per intake plus a child list of component labels.

### Cleaning

- remove test/training tickets
- resolve duplicate Jira/DC pairs
- normalize old/new AppCat IDs
- map retired components to historical labels without forcing them as current recommendations
- remove records without reliable final component labels from supervised training
- preserve time fields for temporal validation

### Privacy/minimization

Use only fields required for classification. Avoid person names, email addresses, comments, or unrelated attachments as features.

---

## 5. Baseline model architecture

### Model A — hierarchical domain classification

Start with an interpretable baseline:

- one-hot encoded categorical features
- optional TF-IDF from short business requirement text
- logistic regression / linear classifier

Evaluate against a tree-based model for structured-only features. Keep the simpler model if performance is comparable.

### Model B — multi-label component prediction

Recommended baseline:

- one-vs-rest logistic regression for each sufficiently common component
- TF-IDF + structured categorical features
- probability calibration

For rare components, rely on deterministic mappings/catalog search and human discovery until enough labels exist.

### Alternative

Gradient-boosted trees can be used for structured features; do not select a more complex model solely because it is more sophisticated.

---

## 6. Recommendation thresholds

Example configurable policy:

| Score | UI behavior |
|---:|---|
| >= 0.85 | High-confidence recommendation, shown first. |
| 0.60–0.84 | Possible component, shown under additional candidates. |
| < 0.60 | Hidden by default; available in expanded list if needed. |

Never auto-select based on these thresholds.

If no component exceeds the minimum threshold, show:

> No reliable model recommendation. Continue with catalog search/discovery.

---

## 7. Evidence shown to Pod

For every recommendation show at least:

- component
- score/confidence
- deterministic mapping reason if any
- number of similar historical intakes
- top similar intake references where permitted
- model version

Avoid pseudo-explanations. Do not claim causal reasoning from feature importance.

---

## 8. Historical similarity without GenAI

A no-LLM approach can use:

- categorical match weighting
- TF-IDF vectors for business-case/current/desired behavior text
- cosine similarity / nearest neighbors

Return similar items with:

- Jira/DC reference
- capability
- change type
- final components
- date

Use similarity as evidence, not as proof that the same component must be used.

---

## 9. Evaluation

Split train/test by **time**, not random only, so the evaluation represents future intake behavior.

Recommended metrics:

### Domain classifier

- macro F1
- per-domain precision/recall
- confusion matrix

### Component recommender

- Precision@3
- Recall@3
- Recall@5
- mean number of recommendations
- no-recommendation rate
- acceptance rate in UAT

Business target should be framed as reducing discovery effort, not maximizing a single ML metric.

---

## 10. Human feedback loop

Capture:

- recommended component
- score
- Pod accepted/rejected
- manually added components
- override reason

Periodically create a retraining dataset from **confirmed final selections**, with governance approval.

Do not train immediately on every click; use curated model releases.

---

## 11. Model lifecycle

Each deployed model must have:

- model ID/version
- training window
- feature schema version
- taxonomy version
- evaluation report
- approval record
- deployment date
- rollback version

Monitor:

- recommendation acceptance rate
- distribution shift by LOB/capability
- components with deteriorating recall
- newly introduced AppCats not represented in training

---

## 12. Integration contract

Power App should call an abstraction such as `ComponentRecommendationService`, not a vendor-specific model directly.

Request:

```json
{
  "intakeId": "<guid>",
  "schemaVersion": "1.0",
  "features": {
    "lob": "Deposits",
    "capabilityPath": ["Deposits", "Savings", "Savings Goal"],
    "changeType": "ModifyExisting",
    "integrationType": "API",
    "responseContractChanged": true,
    "calculationChanged": true
  }
}
```

Response:

```json
{
  "modelVersion": "component-v1",
  "recommendations": [
    {
      "componentId": "<id>",
      "score": 0.91,
      "evidence": ["historical-pattern"]
    }
  ]
}
```

Persist the response before displaying it so audit does not depend on transient API output.

---

## 13. Deployment options

Choose only an internally approved hosting path. The app architecture should support:

- approved Azure ML endpoint
- approved enterprise/Fabric model service
- approved internal model API
- batch scoring into Dataverse if real-time hosting is not available

Use a custom connector or Power Automate-mediated API call with managed credentials. Do not place model secrets in Power Fx.

