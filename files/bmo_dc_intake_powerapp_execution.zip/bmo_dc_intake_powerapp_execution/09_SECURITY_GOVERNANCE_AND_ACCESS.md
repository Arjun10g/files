# Security, Governance, and Required Access

## 1. Role model

Recommended roles:

### Requester

- create BIDC-linked intake or edit allowed pre-grooming fields
- view own intakes
- respond to missing-information requests
- upload supporting documents

### Digital Pod / Intake Manager

- view/edit assigned/all in-scope intakes
- groom requirements
- accept/reject component recommendations
- add components
- confirm Component Change Summary
- submit to DC
- manage exceptions

### Component Owner / SME

Later phase:

- view assigned component scopes only
- comment/clarify
- provide estimate/assumptions

### Business Approver

- view approval package
- approve/request clarification/decline within existing governance

### Taxonomy/Rule Admin

- manage capability taxonomy
- questions
- deterministic rules
- component mappings

### Platform Admin

- solution deployment
- connections
- environment variables
- monitoring

### Auditor / Read-only

- access permitted records/history with no edit rights

---

## 2. Security implementation

If Dataverse is used:

- use Entra-backed teams/security groups where possible
- define least-privilege Dataverse security roles
- use owner/team ownership and business units only if they map cleanly to the operating model
- consider field security for budget/estimate fields
- enable auditing for business-critical entities/fields

Do not secure only at the Canvas UI level. Users must not be able to bypass UI filters via direct data access.

---

## 3. Data minimization

The intake needs project/business/technical data, but the model does not need unnecessary personal data.

For ML features exclude where possible:

- employee names
- email addresses
- free-form comments unrelated to classification
- attachment content
- approval rationale containing personal information

Use team/component IDs instead of individual names as labels.

---

## 4. DLP and connectors

Validate Power Platform DLP placement for:

- Dataverse
- Jira connector/custom connector
- HTTP/custom API connector
- Office 365/Entra directory connector
- SharePoint/document store
- Power BI
- any ML endpoint connector

Do not move the solution to production until connector combinations are permitted by the environment DLP policy.

---

## 5. Required access for replication/discovery

At minimum request:

### Power Platform

- Power Apps maker access in a non-production environment
- read/export access to the current Power App solution or owner-supported export
- Power Automate maker access
- ability to inspect connection references and environment variables
- ability to inspect current data sources/table schemas
- Dataverse customizer/system-customizer equivalent in Dev if Dataverse is used
- access to Power Platform monitoring/solution checker appropriate to role

### Current DC application/data

- read access to AppCat/component inventory source
- field/data dictionary
- current status definitions
- current integration/backend create/update interface
- non-production test records

### Jira/BIDC

- Jira project read in Dev/Test or sandbox
- issue schema/field IDs
- approved API/service integration access or connector
- webhook/automation capability if event-driven sync is chosen
- test project or test issue set

### Directory / people lookups

- approved directory connector or Graph-backed service with minimum directory-read permissions required for person search
- group membership if role-based authorization depends on Entra groups

### Reporting

- Power BI report/workspace access if Dashboard parity is required
- RLS design/roles

### ML — only if approved

- historical de-identified/approved training data
- approved compute/training environment
- approved model-serving endpoint or batch-scoring mechanism
- custom connector/API approval

---

## 6. Entra groups to request

Use organization naming standards, but conceptually create groups such as:

- `DCI-PowerApp-Requesters`
- `DCI-PowerApp-DigitalPod`
- `DCI-PowerApp-ComponentOwners`
- `DCI-PowerApp-BusinessApprovers`
- `DCI-PowerApp-TaxonomyAdmins`
- `DCI-PowerApp-PlatformAdmins`
- `DCI-PowerApp-Auditors`

Map groups to app sharing and Dataverse roles. Do not maintain manual per-user access lists unless unavoidable.

---

## 7. Service identities

Separate employee access from automation identities.

Potential service identities:

- Jira sync service
- DC submission integration service
- component inventory sync service
- ML inference service if enabled

Each should have only the scopes/actions required.

---

## 8. Secrets

- no API keys/secrets in Power Fx
- use connection references, approved secret store, managed identity/service principal where supported
- rotate credentials per enterprise policy
- do not include secrets in flow run logs or error messages

---

## 9. Audit requirements

Record at minimum:

- intake create/update/submit
- status changes
- rule-set version
- blocking rules fired
- component recommendation and human decision
- component manual add/remove
- owner snapshot at submission
- DC submission actor/job/result
- estimate/approval events in later phase
- admin changes to rules/taxonomy/mappings

---

## 10. ML governance

If ML is enabled:

- model is advisory only
- deployment requires approved model version
- human decision is stored
- low confidence defaults to manual discovery
- model failure does not block intake
- no unreviewed model output creates a downstream DC intake
- performance/drift is reviewed on a defined cadence

---

## 11. Business continuity

The application must support a degraded mode:

- if Jira sync is down, Pod can link/import later
- if ML is down, rules/catalog search continue
- if DC submission API is down, intake remains `Ready for DC Submission` and job can retry
- if reporting is down, transaction processing still works

