# Target-State UX and Operating Process

## 1. Objective

Transform the current Digital Core Intake Power App from a static form into an **intelligent, guided intake and orchestration experience** while keeping the Digital Pod as the accountable gatekeeper.

The target is not to bypass the BIDC gate. It is to make the gate faster, more consistent, and machine-readable.

---

## 2. Target journey

```mermaid
flowchart TD
    A[Requester raises BIDC Jira] --> B[Structured intake record created / linked]
    B --> C[Guided question tree]
    C --> D[Deterministic completeness + policy checks]
    D -->|Incomplete| E[Return exact missing items to requester]
    E --> C
    D -->|Ready| F[Digital Pod grooming workbench]
    F --> G[Rules / optional ML recommend domain + AppCats]
    G --> H[Pod confirms components + owners]
    H --> I[Structured Component Change Summary]
    I --> J[Preview DC intake]
    J --> K[One-click backend submission]
    K --> L[Estimate / approval orchestration]
```

---

## 3. Role-specific experience

### Requester

The requester should not need knowledge of 1,000+ Digital Core services.

Show:

- Business/project context.
- What capability is changing.
- What behavior changes.
- Known API/integration details.
- Target date/release.
- Required supporting material.
- Exact missing information.

Hide by default:

- Full AppCat inventory.
- STO owner maintenance.
- Model confidence internals.
- Internal DC routing controls.

### Digital Pod / Intake Manager

Show:

- Full canonical record.
- Readiness/gap list.
- Classification path.
- Rules fired.
- Suggested AppCats and confidence/evidence.
- Component owner information.
- Similar historical intakes.
- Component Change Summary editor.
- Exceptions and override reasons.
- Submission preview and integration status.

### Component Owner / SME

Later phase:

- Only assigned component scope.
- Component-specific change summary.
- Dependencies/assumptions.
- Estimate request and due date.
- Clarification comments.

### Admin / Taxonomy Steward

- Manage capability taxonomy.
- Manage question definitions and branching.
- Manage rule definitions.
- Manage AppCat catalog/ownership sync.
- Review unresolved mappings.
- View model drift/override analytics if ML is active.

---

## 4. Improved New Intake experience

### Step 0 — Linked request

If entered from BIDC/Jira, show the Jira key and source details. Prevent duplicate intake creation using the Jira key as an idempotency/source reference.

### Step 1 — Project context

Reuse current Main Info fields, but auto-populate where authoritative data exists:

- requestor
- business owner
- LOB
- Clarity/PR number
- project name
- target implementation/release
- budget
- complexity

Do not ask users to type values already known from Jira/project master data.

### Step 2 — Business capability

New structured fields:

- Capability L1
- Capability L2
- Capability L3
- Product/sub-capability
- Region
- Channel
- Customer/internal impact

Use cascading dropdowns driven by taxonomy tables.

### Step 3 — Change classification

Ask:

- New capability / modify existing / defect / retirement.
- API / event / batch / file / data / business rule / other.
- Existing interface/service known? Yes/No/Unknown.
- Request payload change?
- Response payload change?
- New calculation/business logic?
- New data source/data element?
- Volume change?
- Backward compatibility concern?

Questions are dynamic; only relevant branches appear.

### Step 4 — Existing Planning questions

Retain current policy and engagement questions, but pre-answer/recommend when a deterministic rule exists. Display the rule source and allow authorized Pod override.

### Step 5 — Component discovery

Replace raw catalog-first behavior with:

1. **Recommended components** — from mappings/rules and optional ML.
2. **Search full AppCat catalog** — existing behavior retained.
3. **Why recommended** — evidence/rule/history.
4. **Accept / Reject / Add**.

Never silently select a component from an ML prediction.

### Step 6 — Component Change Summary

Replace a single blank text box with a structured mini-form per component:

- Current behavior.
- Requested behavior.
- Change type.
- Input change.
- Output change.
- Data source/change.
- Dependency.
- NFR/performance impact.
- Test impact.
- Assumptions.
- Open questions.
- Target release.

Render a deterministic formatted summary for the current DC portal field if the downstream interface still expects text.

### Step 7 — Evidence/attachments

Instead of a generic attachment bucket only, add attachment categories:

- solution architecture
- API specification
- DFR/other intake-specific artifacts
- business requirements
- diagram
- estimate/supporting document
- other

Rules decide which categories are mandatory.

### Step 8 — Review

Provide a single review page:

- Readiness score.
- Blocking gaps.
- Warnings.
- Classification path.
- Components/owners.
- Required documents.
- Submission mapping preview.

Only blocking gaps prevent submission. Warnings require acknowledgement but not necessarily blocking.

---

## 5. Intake readiness

Use a deterministic score; do not make it an opaque AI score.

Example:

```text
INTAKE READINESS: 86%

Complete
✓ Requestor / business owner
✓ PR / project
✓ LOB / capability
✓ Current behavior
✓ Desired behavior
✓ Target implementation date
✓ Component selections

Blocking
✕ API contract details required

Warnings
! Backward compatibility not confirmed
! One component recommendation remains unreviewed
```

### Recommended readiness dimensions

- Project context.
- Business requirement.
- Technical change.
- Planning/governance.
- Component discovery.
- Component Change Summary.
- Required evidence.
- Contacts.

Readiness should expose `BlockingGapCount`, `WarningCount`, and per-section completeness rather than only a percentage.

---

## 6. Grooming workbench

Add a Pod-oriented queue that answers **what needs action today**.

Recommended views:

- Needs requester information.
- Ready for grooming.
- Discovery required.
- Low-confidence component mapping.
- Waiting for architecture/SME.
- Ready for DC submission.
- DC submission failed/retry.
- Waiting for estimates.
- Waiting for business approval.
- Delivery ready.

Columns:

- BIDC/Jira key.
- project.
- request type.
- LOB/capability.
- readiness.
- blocking gaps.
- age.
- current owner.
- next action.
- SLA status.

---

## 7. My Intakes improvement

Retain current filters but add:

- BIDC Jira key.
- Current phase.
- Blocking reason.
- Readiness.
- Component count.
- Estimate status.
- Business approval status.
- Last activity.

The current My Intakes page remains familiar while becoming an operational status page.

---

## 8. Dashboard improvement

Minimum operational metrics:

- New intakes by week/month.
- Median BIDC → grooming-ready time.
- Median grooming-ready → components-confirmed time.
- Median components-confirmed → DC submitted time.
- Missing-field return rate.
- Top missing fields.
- Top AppCats/domains.
- Component-owner response SLA.
- Estimate cycle time.
- Intake aging by stage.
- ML recommendation override rate if model enabled.

---

## 9. Human-control requirements

Always require human confirmation for:

- Final DC component set.
- Final component change scope.
- Business/project owner changes.
- Submitted DC intake.
- Estimate acceptance.
- Business approval.

Never let model confidence bypass mandatory governance.

---

## 10. Feature flags

Use environment/config flags so each capability can be deployed independently:

- `EnableGuidedIntake`
- `EnableReadinessEngine`
- `EnableComponentRules`
- `EnableMLRecommendations`
- `EnableHistoricalSimilarity`
- `EnableJiraSync`
- `EnableDCBackendSubmission`
- `EnableEstimateWorkflow`
- `EnableGenAIExtraction` — default false until approved.

This lets the team prove parity, then enable improvements progressively without a risky big-bang release.

