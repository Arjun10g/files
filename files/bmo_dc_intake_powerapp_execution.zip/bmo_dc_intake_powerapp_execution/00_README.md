# Digital Core Intake Power App — Execution Package

## Purpose

This package is a build-ready plan to **replicate the current Digital Core Intake Power App** observed in the walkthrough and evolve it into a standardized, rules-driven, ML-ready intake platform.

The operating constraint is intentional:

- **Phase 1 must work with no GenAI/LLM dependency.**
- The baseline can run **rules-only** if all forms of AI/ML are restricted.
- Classical ML is an **optional recommendation layer**, never a workflow authority.
- GenAI can be added later without changing the core data model or controls.

The current BIDC/Jira gate and the US Digital Pod remain control points. The target is to eliminate manual re-keying, reduce grooming cycles, improve Digital Core component discovery, and create a machine-readable Component Change Summary.

## Observed current application

The walkthrough shows a Canvas-style Power App named **Digital Core Intake Portal** with the following shell:

- Home
- New Intake
- My Intakes
- Search
- Dashboard
- Feedback Survey
- Help

The New Intake flow contains:

1. Main Info
2. Planning
3. DC Components
4. Note
5. Attachments

The application supports Save As Draft and Submit, component search by AppCat ID/short name, STO ownership display, component-specific change summaries, attachments, and intake search/filtering.

> Important: the video exposes the visible UI but not every hidden Power Fx formula, complete option set, connector, flow, validation rule, data source, or security role. This package defines a complete replica baseline from what is visible and a parity-discovery checklist for the remaining tenant-only details. A true byte-for-byte functional clone requires access to the existing Power Platform solution.

## Target state

```mermaid
flowchart LR
    A[Channel / Business] --> B[BIDC Jira Gate]
    B --> C[Canonical Intake Record]
    C --> D[Rules + Decision Tree]
    D --> E[Readiness Validation]
    E --> F[Optional ML Recommendations]
    F --> G[Digital Pod Grooming]
    G --> H[Structured Component Change Summary]
    H --> I[DC Intake Submission]
    I --> J[Component Owners / Estimates]
    J --> K[Business Approval]
    K --> L[Delivery]

    M[Capability / AppCat / Ownership Catalog] --> D
    M --> F
    N[Historical BIDC + DC Intakes] --> F
```

## Core design principles

1. **Canonical data first.** Free text is supporting information, not the source of truth.
2. **Progressive disclosure.** Users see only questions relevant to their path.
3. **Rules enforce; ML recommends; humans approve.**
4. **Unknown is a valid answer.** Never force requesters to invent technical information.
5. **Component Change Summary is structured.** It becomes the bridge to estimation and delivery.
6. **No browser automation unless all supported integrations fail.** Prefer the current Power App's underlying data/API/flow layer.
7. **All model recommendations are evidence-backed and overrideable.** Every Pod correction is captured for future learning.

## Files and recommended execution order

1. `01_CURRENT_APP_REPLICA_SPEC.md` — visible parity requirements and parity-discovery checklist.
2. `02_TARGET_STATE_UX_AND_PROCESS.md` — improved experience and operating model.
3. `03_CANONICAL_DATA_MODEL.md` — Dataverse-oriented entities, relationships, and status model.
4. `04_DECISION_TREES_AND_RULES.md` — adaptive questions, readiness, required artifacts, and routing.
5. `05_ML_CLASSIFICATION_DESIGN.md` — optional classical ML component/category recommendations.
6. `06_JIRA_AND_DC_INTEGRATION.md` — BIDC/Jira synchronization and DC submission design.
7. `07_POWER_APPS_BUILD_GUIDE.md` — solution structure, screens, components, and Power Fx patterns.
8. `08_POWER_AUTOMATE_FLOW_SPECS.md` — automation contracts and failure handling.
9. `09_SECURITY_GOVERNANCE_AND_ACCESS.md` — roles, access, audit, DLP, and required permissions.
10. `10_TEST_AND_ACCEPTANCE_PLAN.md` — parity, functional, UAT, ML, security, and regression testing.
11. `11_IMPLEMENTATION_BACKLOG_AND_ROADMAP.md` — epics, stories, sequencing, and definition of done.
12. `12_CUTOVER_AND_RUNBOOK.md` — release, migration, rollback, support, and monitoring.
13. `13_REFERENCE_CONFIGURATION.md` — sample taxonomy, rules, question metadata, and component mapping formats.

## Delivery modes

### Mode A — Rules only

Use when AI/ML is entirely blocked. The full standardized intake, adaptive tree, readiness checks, component catalog, ownership lookup, one-click DC creation, queues, and audit work without a model.

### Mode B — Rules + classical ML

Adds ranked domain/AppCat/component suggestions and historical similarity. No model output can auto-submit or auto-approve.

### Mode C — Later GenAI

Adds natural-language extraction, conversational grooming, document summarization, and drafting into the **same canonical schema**. Nothing downstream needs to be redesigned.

## Success measures

Track at least:

- BIDC creation → grooming-ready lead time.
- Average number of grooming loops.
- % returned for missing information.
- Discovery time to confirmed DC components.
- Time to identify component owners.
- Manual minutes spent re-keying Jira into DC intake.
- Component recommendation Precision@3 / Recall@5 if ML is enabled.
- Estimate turnaround time.
- Total BIDC → development-ready lead time.
- % of intakes with complete, structured Component Change Summary.

