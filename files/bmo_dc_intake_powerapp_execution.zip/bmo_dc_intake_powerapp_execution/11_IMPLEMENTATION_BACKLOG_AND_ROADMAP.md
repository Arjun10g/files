# Implementation Backlog and Roadmap

## 1. Delivery principle

Separate **parity**, **standardization**, **automation**, and **ML** so approval or failure in one area does not block the others.

Use two-week sprints as a planning frame, then re-estimate after current-solution discovery. The sequence below is more important than the calendar.

---

## 2. Phase 0 — discovery and parity baseline

### Epic 0.1 — Current solution inventory

Stories:

- Export/inspect current app solution.
- Inventory screens, controls, Power Fx, data sources, flows, connectors.
- Export choice sets/statuses/planning question list.
- Identify component inventory source.
- Identify My Intakes/Search query semantics.
- Identify Dashboard/Help/Feedback dependencies.
- Document role/security model.

Definition of done:

- `01_CURRENT_APP_REPLICA_SPEC.md` unknowns are closed or formally accepted.

### Epic 0.2 — Data/integration discovery

- Identify Jira field IDs and API/webhook options.
- Identify current DC backend create/update interface.
- Establish non-production test path.
- Create field mapping workbook/table.

---

## 3. Phase 1 — parity clone

### Epic 1.1 — Solution shell

- Create vNext solution.
- Environment variables/connection references.
- Left navigation/header.
- feature-flag framework.

### Epic 1.2 — New Intake parity

- Main Info.
- Planning.
- DC Components.
- Note/comments.
- Attachments.
- Save Draft.
- Submit validation.

### Epic 1.3 — Search parity

- My Intakes.
- Search.
- Dashboard link/embed.
- archive behavior.

Definition of done:

- Current users can execute current-state scenarios with no missing functionality.

---

## 4. Phase 2 — structured intake and decision tree

### Epic 2.1 — Canonical schema

- Create/migrate Intake entities.
- Create capability taxonomy.
- Create QuestionDefinition/IntakeAnswer.
- Create rules tables.

### Epic 2.2 — Guided intake

- Add capability wizard.
- Add change type/integration branches.
- Dynamic question renderer.
- Unknown/NA behavior.
- role-aware views.

### Epic 2.3 — Readiness engine

- Blocking/warning evaluation.
- readiness panel.
- exact gap messages.
- server-side submit evaluation.

Definition of done:

- Most incomplete requirements are caught before Pod grooming.

---

## 5. Phase 3 — component intelligence without ML

### Epic 3.1 — Component knowledge map

- Sync authoritative AppCat catalog.
- Team/STO ownership.
- capability → component mappings.
- technology/flags/freeze metadata.

### Epic 3.2 — Component discovery UX

- recommended components from rules/mappings.
- full catalog search.
- evidence/reason.
- accept/reject/add.

### Epic 3.3 — Structured Component Change Summary

- per-component editor.
- deterministic summary rendering.
- completeness rules.

Definition of done:

- Pod can move from requirement to confirmed components without a blank-screen catalog search for common cases.

---

## 6. Phase 4 — Jira and DC automation

### Epic 4.1 — Jira sync

- inbound upsert.
- source key/idempotency.
- field mapping.
- write-back.
- retry/dead-letter.

### Epic 4.2 — DC submission adapter

- backend integration.
- server-side validation.
- create intake/components.
- attachments.
- response mapping.
- reconciliation.

### Epic 4.3 — Grooming workbench

- queues.
- SLA/age.
- next action.
- integration exception queue.

Definition of done:

- A groomed BIDC request can create a DC intake without manual re-keying.

---

## 7. Phase 5 — optional classical ML

Only start once training labels/data access are approved.

### Epic 5.1 — Training dataset

- link historical BIDC to DC intake.
- normalize components.
- curate labels.
- time-based split.

### Epic 5.2 — Baseline models

- domain classifier.
- multi-label component model.
- historical similarity.

### Epic 5.3 — Human-in-loop integration

- recommendation service.
- persistence/audit.
- confidence bands.
- accept/reject feedback.
- feature flag.

Definition of done:

- model recommendations demonstrably reduce discovery effort and can be disabled instantly.

---

## 8. Phase 6 — estimate and approval orchestration

- component-specific estimate requests.
- due dates/SLAs.
- estimate aggregation.
- business approval package.
- approval capture.
- delivery handoff/subtask generation.

This is deliberately after intake standardization and DC submission automation.

---

## 9. Phase 7 — later GenAI

When approved:

- natural language → canonical field extraction.
- conversational missing-information capture.
- document extraction/summarization under approved controls.
- component-summary drafting from structured facts.
- reviewer summary.

GenAI must write into or read from the existing canonical model; it must not create a parallel process.

---

## 10. Priority backlog

### Must have for MVP

- parity clone
- canonical schema
- guided tree
- readiness blockers
- component catalog/owner sync
- deterministic component mappings
- structured component summary
- Jira link/sync
- supported DC backend submission
- audit/security

### Should have

- grooming workbench
- historical similar-intake retrieval without GenAI
- richer dashboard
- notifications/SLA

### Could have after stabilization

- classical ML recommendations
- estimate orchestration
- approval workflow
- automatic delivery tasks

---

## 11. Team dependencies

Likely required roles:

- Power Apps developer
- Power Automate/integration developer
- Power Platform admin/architect
- Digital Pod SME/product owner
- Jira admin/integration owner
- DC portal/data owner
- AppCat/inventory owner
- security/identity partner
- QA/UAT lead
- data scientist/ML engineer only for optional ML phase

---

## 12. Key risks and mitigations

| Risk | Mitigation |
|---|---|
| Current app hidden logic not visible | Export/inspect solution before final parity. |
| No supported DC backend interface | Inspect data source/flows; use supported connector; UI automation only as temporary fallback. |
| Incomplete ownership catalog | Add freshness/unresolved-owner queue and team-level ownership. |
| Taxonomy becomes hard-coded | Store as data with admin UI. |
| ML approval delayed | Rules-only product remains complete. |
| Sparse historical labels | Use mappings/search; ML only on components with sufficient examples. |
| Duplicate Jira/DC records | Alternate key + idempotent integration jobs. |
| User resistance to more fields | Progressive disclosure and prepopulation; measure question count/time. |

