# Cutover and Operational Runbook

## 1. Environment strategy

Minimum:

- Development
- Test/System Integration
- UAT
- Production

Use solutions, connection references, and environment variables. Avoid direct production edits.

---

## 2. Pre-cutover checklist

### Application

- parity/UAT approved
- feature flags reviewed
- solution checker issues resolved/accepted
- accessibility checks complete
- app shared through correct Entra groups

### Data

- taxonomy seeded
- question definitions seeded
- rules seeded/versioned
- component catalog synchronized
- owner freshness checked
- status mapping verified

### Integrations

- Jira non-prod/production credentials configured
- DC backend credentials configured
- connection references bound
- endpoints/environment variables correct
- idempotency/reconciliation tests passed

### Security

- Dataverse roles assigned
- DLP policy validated
- service identities approved
- audit enabled
- no secrets in app/flows

### Operations

- support owner named
- integration alerting enabled
- dead-letter/error queue visible
- rollback package retained
- change record/release approvals complete

---

## 3. Migration options

### Option A — no historical migration

Keep legacy intakes read-only in current/reporting system. New vNext app handles only new intakes after cutover.

Simplest and safest when historical editing is not required.

### Option B — active-only migration

Migrate only open/current-year intakes needed for operations.

Required mapping:

- legacy ID
- current status
- project fields
- comments/history as reference if necessary
- components
- attachments/references

### Option C — full history

Only if there is a clear business/regulatory need. Higher cost and reconciliation burden.

---

## 4. Parallel run

Recommended for initial cutover:

- vNext available to pilot Digital Pod users.
- execute representative live-equivalent test cases.
- compare generated DC payload to current manual entry.
- do not dual-submit to production DC system.
- after acceptance, make vNext the official creation path.

---

## 5. Production cutover sequence

1. Freeze configuration changes in current app/rules for the release window.
2. Export final backup/current solution package.
3. Deploy managed vNext solution.
4. Bind production connection references/environment variables.
5. Seed/version configuration.
6. Run component catalog sync.
7. Run smoke test with test/approved non-business record.
8. Enable Requester/Pod groups.
9. Enable Jira sync.
10. Keep DC backend submission feature flag off initially if desired.
11. Validate inbound BIDC records.
12. Enable DC submission for Pod pilot.
13. Validate one controlled end-to-end submission.
14. Enable broadly.
15. Monitor closely through the stabilization period.

---

## 6. Smoke test

Verify:

- login/role
- create/open intake
- directory lookup
- taxonomy/questions
- save draft
- component catalog search
- owner display
- structured summary
- attachment
- readiness
- Jira sync
- DC submission or dry-run preview
- My Intakes
- dashboard navigation

---

## 7. Operational monitoring

Daily during stabilization:

- failed IntegrationJobs
- Jira sync lag
- DC submission failures
- component catalog freshness
- intakes stuck in transitional states
- unusually high blocker rate
- app errors/performance

Weekly:

- top missing fields
- grooming return rate
- component owner issues
- feedback/defects
- ML acceptance/drift if enabled

---

## 8. Incident playbooks

### Jira sync unavailable

- keep Power App operational
- allow manual SourceKey/link entry for Pod if approved
- queue inbound sync/reconcile later
- do not create duplicate intake records

### ML unavailable

- disable `EnableMLRecommendations`
- rules/catalog continue normally

### Component inventory unavailable

- retain last successful snapshot
- show freshness warning
- prevent automatic assumption that stale owner is current
- allow Pod manual verification

### DC backend unavailable

- retain state `Ready for DC Submission`
- queue/retry safe transient failures
- do not fall back to browser automation without incident/change approval

### Incorrect downstream submission

- stop retries
- identify correlation ID
- follow DC system correction/cancellation process
- update canonical event log
- do not delete audit records

---

## 9. Rollback

Rollback triggers may include:

- widespread inability to save/submit
- security authorization defect
- duplicate downstream record creation
- corrupt field mapping
- unrecoverable integration failures

Rollback actions:

1. Disable Jira/DC integration feature flags.
2. Remove/limit vNext app sharing if necessary.
3. Re-enable legacy creation process.
4. Preserve all vNext data for reconciliation.
5. Revert managed solution only if needed; avoid destructive data rollback.
6. Reconcile any downstream records already created.

---

## 10. Post-cutover review

At 2 and 6 weeks, review:

- cycle-time metrics
- missing-field rates
- Pod grooming effort
- component discovery effort
- integration failures
- user feedback
- rules needing adjustment
- taxonomy gaps
- whether ML phase has enough clean labels to proceed

