# Reference Configuration Examples

These examples show how to keep behavior in data/configuration rather than hard-coded Power Fx. Replace example values with approved BMO taxonomy/policy.

---

## 1. Capability table

| CapabilityKey | ParentKey | Level | Name | Active |
|---|---|---:|---|---:|
| CONSUMER |  | 1 | Consumer Banking | 1 |
| DEPOSITS | CONSUMER | 2 | Deposits | 1 |
| SAVINGS | DEPOSITS | 3 | Savings | 1 |
| SAVINGS_GOAL | SAVINGS | 4 | Savings Goal | 1 |

---

## 2. Question definitions

| QuestionKey | Section | Text | Type | Required | Parent | Trigger | Order |
|---|---|---|---|---:|---|---|---:|
| CHANGE_TYPE | Requirement | What type of change is this? | Choice | 1 |  |  | 10 |
| INTEGRATION_TYPE | Requirement | What type of integration is affected? | Choice | 1 |  |  | 20 |
| API_EXISTING | Requirement | Is this an existing API? | Choice | 1 | INTEGRATION_TYPE | API | 30 |
| API_NAME | Requirement | API/service name, if known | Text | 0 | INTEGRATION_TYPE | API | 40 |
| API_RESP_CHANGE | Requirement | Is the response contract changing? | Boolean | 1 | INTEGRATION_TYPE | API | 50 |
| API_RESP_TYPE | Requirement | What kind of response change? | Choice | 1 | API_RESP_CHANGE | true | 60 |
| BACKWARD_COMPAT | Requirement | Has backward compatibility been assessed? | Choice | 1 | API_RESP_CHANGE | true | 70 |

---

## 3. Example current Planning question configuration

Represent current visible planning items using the same table so future questions do not require screen redesign.

| QuestionKey | Section | Type | Required | Notes |
|---|---|---|---:|---|
| NATIONAL_IMPL_DATE | Planning | Date | per current policy | National implementation date. |
| CODED_PROJECT | Planning | Boolean | per current policy | Current guidance references NDA access. |
| DC_CLOUD_ADOPTION | Planning | Boolean | per current policy | Scope/Impact. |
| OLBB_POD | Planning | Boolean | per current policy | Scope/Impact. |
| CDB_CROSS_IMPACT | Planning | Choice | per current policy | Web/Mobile/Admin cross-impact. |
| TIBCO_IMPACT | Planning | Boolean | per current policy | Exact wording to import from current solution. |
| CC_API_TSYS_VOLUME | Planning | Choice | per current policy | Credit-card API/TSYS volume. |
| DC_PM_REQUIRED | Planning | Boolean | per current policy | PM engagement question. |
| SHARE_ETO_ENGINEERING | Planning | Boolean | per current policy | Team Engagement. |
| SHARE_CLOUD_ENGINEERING | Planning | Boolean | per current policy | Team Engagement. |
| DC_SOLUTION_CONTACT | Planning | Person | 0 | Contact, if any. |
| PROJECT_SA_CONTACT | Planning | Person | 1 observed | Solution Architecture contact. |

---

## 4. Rule definition examples

| RuleKey | Type | Field/Question | Operator | Compare | Output | Severity |
|---|---|---|---|---|---|---|
| R_API_SPEC | RequireDoc | INTEGRATION_TYPE | EQ | API | API_SPEC | Warning/Blocking per approved policy |
| R_API_COMPAT | RequireAnswer | API_RESP_CHANGE | EQ | true | BACKWARD_COMPAT | Blocking |
| R_COMPONENT_SUMMARY | RequireField | SelectedComponent | EXISTS | true | ComponentChangeSummary | Blocking |
| R_CLOUD_TEAM | RecommendTeam | DC_CLOUD_ADOPTION | EQ | true | CLOUD_ENGINEERING | Info |

Policy owners must approve the actual severity and trigger values.

---

## 5. Component mapping examples

| MappingKey | Capability | Integration | Change | Component | Weight | Reason |
|---|---|---|---|---|---:|---|
| M001 | SAVINGS_GOAL | API | RESPONSE_CHANGE | SAVINGS_API | 100 | Capability API mapping |
| M002 | SAVINGS_GOAL | API | CALCULATION_CHANGE | GOAL_MGMT | 90 | Calculation ownership mapping |
| M003 | * | API | CONTRACT_CHANGE | API_PLATFORM | 60 | API contract support mapping |

These values are illustrative. Seed real mappings from validated historical/process knowledge.

---

## 6. Feature flags

| Key | Default | Description |
|---|---:|---|
| EnableGuidedIntake | 1 | Progressive structured questionnaire. |
| EnableReadinessEngine | 1 | Blocking/warning evaluation. |
| EnableComponentRules | 1 | Deterministic component mappings. |
| EnableMLRecommendations | 0 | Classical ML recommendations. |
| EnableHistoricalSimilarity | 0 | Similar prior intake retrieval. |
| EnableJiraSync | 0 by default in Dev | Jira integration. |
| EnableDCBackendSubmission | 0 until tested | Direct DC creation. |
| EnableEstimateWorkflow | 0 | Phase 2. |
| EnableGenAIExtraction | 0 | Future only. |

---

## 7. Status configuration

Keep status transitions in a configuration table where possible.

| Current | Next | Role | ValidationProfile |
|---|---|---|---|
| Draft | Needs Requester Information | Digital Pod | Grooming |
| Draft | Ready for Grooming | Requester/Pod | Grooming |
| Ready for Grooming | Grooming | Digital Pod | Grooming |
| Grooming | Discovery | Digital Pod | Discovery |
| Discovery | Components Confirmed | Digital Pod | ComponentComplete |
| Components Confirmed | Ready for DC Submission | Digital Pod | Submit |
| Ready for DC Submission | DC Submitted | Integration/Pod | Submit |

Map this proposal to the current production statuses before activation.

---

## 8. Component Change Summary render template

Example deterministic template:

```text
Component: {AppCatId} - {ComponentShortName}
Change type: {ChangeType}
Current behavior: {CurrentBehavior}
Requested behavior: {RequestedBehavior}
Input impact: {InputChange}
Output impact: {OutputChange}
Data impact: {DataChange}
Dependencies: {DependencySummary}
NFR / performance impact: {NfrImpact}
Testing impact: {TestImpact}
Assumptions: {Assumptions}
Open questions: {OpenQuestions}
Target release: {TargetRelease}
```

Omit empty optional lines if downstream formatting allows it.

---

## 9. Intake review payload example

```json
{
  "source": {
    "system": "Jira",
    "key": "BIDC-1234"
  },
  "project": {
    "clarityNumber": "PRXXXXXX",
    "name": "Example Project",
    "lob": "Example LOB"
  },
  "classification": {
    "capabilityPath": ["Deposits", "Savings", "Savings Goal"],
    "changeType": "ModifyExisting",
    "integrationType": "API"
  },
  "readiness": {
    "percent": 90,
    "blockingGaps": 1,
    "warnings": 1
  },
  "components": [
    {
      "appCatId": "<id>",
      "reviewDecision": "Accepted",
      "source": "Rule",
      "summaryComplete": true
    }
  ]
}
```

---

## 10. Admin ownership

Assign business owners for configuration families:

| Configuration | Owner |
|---|---|
| Capability taxonomy | Business/Digital Pod taxonomy steward |
| Planning questions | DC intake process owner |
| Rules | Process/governance owner |
| AppCat catalog | Component inventory owner |
| Component mappings | Digital Pod + component/domain owners |
| Status lifecycle | Intake process owner |
| Feature flags | Product/platform owner |
| ML thresholds | Model owner + Digital Pod product owner |

