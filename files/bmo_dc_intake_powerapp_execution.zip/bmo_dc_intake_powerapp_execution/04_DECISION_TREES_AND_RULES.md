# Decision Trees and Rules Engine

## 1. Why this is the Phase 1 intelligence layer

The current problem is not lack of prose. It is inconsistent classification and missing context. A decision tree lets requesters answer what they know and progressively exposes only relevant questions.

The rules engine must be deterministic, versioned, auditable, and configurable without editing Power Fx for every change.

---

## 2. High-level intake tree

```mermaid
flowchart TD
    A[Project context] --> B[Business capability]
    B --> C{Change type}
    C -->|New capability| D[New capability branch]
    C -->|Modify existing| E[Existing capability branch]
    C -->|Defect| F[Defect branch]
    C -->|Retirement| G[Retirement branch]
    D --> H{Integration type}
    E --> H
    F --> H
    G --> H
    H -->|API| I[API questions]
    H -->|Event| J[Event questions]
    H -->|Batch/File| K[Batch/File questions]
    H -->|Data/Rule| L[Data/Logic questions]
    I --> M[Scope and planning questions]
    J --> M
    K --> M
    L --> M
    M --> N[Component discovery]
    N --> O[Evidence requirements]
    O --> P[Readiness]
```

---

## 3. Business capability tree

Store in taxonomy tables, not formulas.

Example only:

```text
Consumer Banking
├── Deposits
│   ├── Savings
│   │   ├── Savings Goal
│   │   ├── Account Opening
│   │   └── Account Maintenance
│   └── Chequing
├── Payments
├── Customer
└── Authentication
```

Selection of a leaf can drive known component mappings but does not automatically select a component.

---

## 4. API branch

When `IntegrationType = API`, ask:

1. Existing API or new API?
2. API/service name known? Yes/No/Unknown.
3. Request contract changing?
4. Response contract changing?
5. Field added/modified/removed?
6. Data type/format change?
7. Business calculation added/changed?
8. New data source?
9. Existing consumers affected?
10. Backward compatibility required/known?
11. Expected volume changed?
12. Latency/performance expectation changed?
13. Authentication/authorization behavior changed?
14. Region/channel-specific behavior?

Conditional examples:

```text
IF ResponseContractChanged = Yes
THEN show ResponseChangeType, ChangedFields, BackwardCompatibility
```

```text
IF BusinessCalculationChanged = Yes
THEN show CalculationDescription, InputData, SourceSystem
```

```text
IF ExistingApiKnown = No
THEN do not require API name; flag for discovery
```

---

## 5. Batch/file branch

Ask:

- existing or new flow
- schedule/frequency
- source
- destination
- format
- record volume
- cutoff/SLA
- encryption/transfer mechanism
- failure/retry expectation
- reconciliation requirement

---

## 6. Data/business-rule branch

Ask:

- data element/rule being changed
- current definition
- target definition
- authoritative source
- calculation/transformation
- retention/privacy classification if required by existing policy
- downstream consumers known?
- history/backfill required?

---

## 7. Preserve and improve current Planning rules

Current visible planning questions remain first-class rules/answers, including:

- coded/NDA project indicator
- DC cloud adoption
- OLBB POD
- cross impact with CDB Web/Mobile/Admin
- TIBCO impact
- credit-card API/TSYS volume change
- DC PM requirement
- ETO Digital Core Engineering engagement
- Cloud Engineering engagement
- DC solution-development contact
- project Solution Architecture contact
- national implementation date

Where an answer can be inferred from authoritative metadata, pre-fill it as a recommendation and require confirmation if policy requires.

---

## 8. Example deterministic rules

The exact policy must be confirmed with process owners. These are implementation patterns, not policy claims.

### Required artifact pattern

```text
IF IntegrationType = API
AND (RequestContractChanged = Yes OR ResponseContractChanged = Yes)
THEN Require DocumentCategory = API_SPEC
SEVERITY Blocking
```

### Backward compatibility pattern

```text
IF ApiFieldRemoved = Yes OR ApiFieldTypeChanged = Yes
THEN Require Answer = BackwardCompatibility
SEVERITY Blocking
```

### Cloud engagement pattern

```text
IF SelectedComponent.CloudFlag = Yes
THEN Recommend Team = Cloud Engineering
SEVERITY Info
```

### TIBCO pattern

```text
IF Planning.TibcoImpact = Yes
THEN Recommend components WHERE TibcoFlag = Yes AND mapping matches capability
```

### Component summary pattern

```text
FOR EACH selected component
IF RenderedChangeSummary is empty
THEN block DC submission
```

### Owner freshness pattern

```text
IF Component.SourceUpdatedOn older than configured freshness threshold
THEN Warning = "Ownership requires verification"
```

---

## 9. Rules for component recommendation

Start with mappings before ML.

### ComponentMapping table

Example columns:

- CapabilityId
- IntegrationType
- ChangeType
- PlanningFlag
- ComponentId
- Weight
- MappingReason
- Effective dates

Example logic:

```text
Savings Goal + API + Response Change -> Savings API (weight 100)
Savings Goal + Calculation Change -> Goal Management (weight 90)
API Contract Change -> API management/publishing component (weight 60)
```

The UI presents these as deterministic recommendations with a reason such as:

> Recommended because this component is mapped to Savings Goal API response changes.

---

## 10. Readiness rules

### Blocking vs warning

Use two severities:

- **Blocking** — cannot submit.
- **Warning** — can submit only after explicit acknowledgement or Pod review depending on status.

### Readiness calculation

Suggested deterministic scoring:

- Required project fields: 15%
- Business capability/requirement: 20%
- Technical change: 20%
- Planning/governance: 15%
- Components: 15%
- Component summaries: 10%
- Evidence/attachments: 5%

However, **submission gating is based on blockers, not percentage**. A 95% record with one mandatory missing artifact is still blocked.

---

## 11. Rule evaluation sequence

1. Load active question metadata.
2. Resolve visible questions based on parent conditions.
3. Validate required visible questions.
4. Evaluate mandatory policy rules.
5. Evaluate deterministic component mappings.
6. Evaluate team/engagement recommendations.
7. Evaluate attachment requirements.
8. Calculate section completeness.
9. Persist RuleExecution results.
10. Present blockers/warnings/recommendations.

Do not execute rules only on the client. Re-evaluate server-side/flow-side immediately before final submission to prevent stale or manipulated state.

---

## 12. Rule versioning

Every submitted intake should record:

- RuleSetVersion
- effective timestamp
- rules fired
- overrides
- override actor/reason

When policy changes, old intakes remain explainable.

---

## 13. Admin UX for rules

Do not give admins raw formulas. Provide controlled screens for:

- activation/effective dates
- simple field/operator/value conditions
- output/action
- severity
- priority
- policy reference
- test input
- preview result

Changes should require maker/admin permission and be auditable.

