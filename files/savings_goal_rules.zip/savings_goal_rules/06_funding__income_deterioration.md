# R06 — Funding / Income Deterioration

## Business Question
Has the customer's ability to save changed?

## Inputs
- Approved recurring inflow indicators
- Payroll or funding history
- Funding frequency
- Funding amounts

## How It Is Generated
1. Establish a rolling funding baseline.
2. Compare recent inflows with the customer's historical baseline.
3. Account for normal cadence and variability.
4. Track missing expected funding events and persistent level changes.

## Example Trigger
Recurring inflow falls materially for two or more periods, or an expected recurring funding event disappears.

## Structured Outputs
- Funding stable / improving / deteriorating
- Percentage change
- Persistence count
- Funding volatility

## Why It Matters
A plan that was reasonable when created may no longer fit current cash flow.

## Implementation Notes
- Thresholds are examples only and should be versioned configuration.
- Persist rule version, input snapshot time, metrics, trigger result, severity, and reason codes.
- Require sufficient observation history before strong customer-facing escalation.
- Retain output for future inferential and predictive modeling.
