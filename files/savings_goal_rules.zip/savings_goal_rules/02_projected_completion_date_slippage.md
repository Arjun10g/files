# R02 — Projected Completion-Date Slippage

## Business Question
When will I actually finish?

## Inputs
- Current goal balance
- Remaining goal amount
- Recent net contribution history
- Target date
- Contribution frequency

## How It Is Generated
1. Estimate recent sustainable net contribution velocity over an approved rolling window.
2. Calculate remaining amount = target amount - current balance.
3. Calculate estimated periods remaining = remaining amount / estimated net contribution per period.
4. Convert periods remaining into a projected completion date.
5. Compare the projected date with the customer's target date.

## Example Trigger
Projected completion is more than 30, 60, or 90 days later than the target date.

## Structured Outputs
- Projected completion date
- Days early or late
- Severity band
- Contribution velocity used

## Why It Matters
Turns an abstract progress gap into a future consequence.

## Implementation Notes
- Thresholds are examples only and should be versioned configuration.
- Persist rule version, input snapshot time, metrics, trigger result, severity, and reason codes.
- Require sufficient observation history before strong customer-facing escalation.
- Retain output for future inferential and predictive modeling.
