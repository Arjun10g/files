# Savings Goal Rules — Initial 10-Rule Catalog

This folder packages the ten recommended initial savings-goal rules.

## Sequence

1. Goal Trajectory Gap
2. Projected Completion-Date Slippage
3. Contribution Consistency / Missed Contribution
4. Savings Velocity Change
5. Goal Withdrawal / Progress Erosion
6. Funding / Income Deterioration
7. Cash-Flow Sustainability
8. Required Contribution Gap
9. Potential Step-Up Opportunity
10. Composite Goal Health / Escalation

## Implementation principles

- Example thresholds are illustrative and should be calibrated against historical data.
- Keep all thresholds configuration-driven and versioned.
- Output structured metrics and reason codes, not only notification text.
- Log triggered and non-triggered evaluations.
- Apply data-quality, privacy, policy, and eligibility controls before customer-facing actions.
- Preserve these outputs as future engineered features for GLM, survival, forecasting, and other predictive models.
