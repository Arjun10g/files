# R05 — Goal Withdrawal / Progress Erosion

## Business Question
Is saved money repeatedly coming back out?

## Inputs
- Goal contributions
- Goal withdrawals
- Transaction timestamps
- Transaction amounts

## How It Is Generated
1. Calculate net contribution = gross contributions - withdrawals.
2. Measure withdrawal frequency and withdrawal-to-contribution ratio.
3. Identify contributions followed by withdrawals within a short period.
4. Track whether net goal flow becomes negative.

## Example Trigger
Withdrawals exceed 20% of recent contributions, repeat within a rolling window, or repeatedly reverse recent deposits.

## Structured Outputs
- Withdrawal rate
- Withdrawal-to-contribution ratio
- Net savings rate
- Reversal behavior
- Erosion severity

## Why It Matters
Gross deposits can overstate real savings progress.

## Implementation Notes
- Thresholds are examples only and should be versioned configuration.
- Persist rule version, input snapshot time, metrics, trigger result, severity, and reason codes.
- Require sufficient observation history before strong customer-facing escalation.
- Retain output for future inferential and predictive modeling.
