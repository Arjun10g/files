# R08 — Required Contribution Gap

## Business Question
What would need to change to get back on track?

## Inputs
- Target amount
- Current balance
- Remaining contribution periods
- Current planned contribution

## How It Is Generated
1. Calculate remaining amount = target amount - current balance.
2. Calculate required contribution = remaining amount / remaining contribution periods.
3. Compare required contribution with the current planned contribution.
4. Calculate the absolute and percentage contribution gap.

## Example Trigger
Required future contribution exceeds the current planned contribution by an approved materiality threshold.

## Structured Outputs
- Required contribution
- Current contribution
- Absolute gap
- Percentage gap

## Why It Matters
Moves the system from problem detection toward a concrete planning number.

## Implementation Notes
- Thresholds are examples only and should be versioned configuration.
- Persist rule version, input snapshot time, metrics, trigger result, severity, and reason codes.
- Require sufficient observation history before strong customer-facing escalation.
- Retain output for future inferential and predictive modeling.
