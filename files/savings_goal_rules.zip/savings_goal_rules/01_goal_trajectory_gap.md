# R01 — Goal Trajectory Gap

## Business Question
Am I where I should be today?

## Inputs
- Goal amount
- Starting balance
- Goal start date
- Target date
- Current goal balance

## How It Is Generated
1. Calculate elapsed time as a share of the total goal horizon.
2. Calculate expected progress using the configured baseline trajectory.
3. Calculate actual progress as current balance divided by target amount.
4. Compute trajectory gap = actual progress - expected progress.
5. Track the gap across consecutive evaluation periods so one-off noise does not trigger escalation.

## Example Trigger
Actual progress remains more than 10–15 percentage points below expected progress for two consecutive periods.

## Structured Outputs
- Health state
- Trajectory gap percentage
- Periods behind
- Gap trend: widening / stable / recovering

## Why It Matters
Foundational signal for later completion, risk, and predictive models.

## Implementation Notes
- Thresholds are examples only and should be versioned configuration.
- Persist rule version, input snapshot time, metrics, trigger result, severity, and reason codes.
- Require sufficient observation history before strong customer-facing escalation.
- Retain output for future inferential and predictive modeling.
