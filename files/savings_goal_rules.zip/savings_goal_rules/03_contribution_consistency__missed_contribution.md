# R03 — Contribution Consistency / Missed Contribution

## Business Question
Is the savings behavior breaking down?

## Inputs
- Expected contribution frequency
- Expected contribution amount
- Actual contribution dates
- Actual contribution amounts

## How It Is Generated
1. Create expected contribution windows from the customer's cadence.
2. Match observed contributions to expected windows using approved date and amount tolerances.
3. Identify missing, late, and materially partial contributions.
4. Track consecutive misses and rolling adherence rate.

## Example Trigger
One miss creates an observation; two consecutive misses create elevated risk; three or more create severe deterioration.

## Structured Outputs
- Contribution adherence rate
- Consecutive missed count
- Amount shortfall
- Consistency trend

## Why It Matters
Behavior can deteriorate before the balance clearly looks off track.

## Implementation Notes
- Thresholds are examples only and should be versioned configuration.
- Persist rule version, input snapshot time, metrics, trigger result, severity, and reason codes.
- Require sufficient observation history before strong customer-facing escalation.
- Retain output for future inferential and predictive modeling.
