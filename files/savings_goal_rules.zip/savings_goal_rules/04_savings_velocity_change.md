# R04 — Savings Velocity Change

## Business Question
Is the customer accelerating or slowing down?

## Inputs
- Historical net contributions by period
- Contribution timestamps
- Contribution frequency

## How It Is Generated
1. Calculate rolling net contribution averages.
2. Estimate a simple contribution slope or compare recent windows with earlier windows.
3. Measure direction and magnitude of change.
4. Require persistence across several periods before escalation.

## Example Trigger
Recent savings velocity falls more than 15–20% from the established baseline for multiple periods.

## Structured Outputs
- Accelerating / stable / decelerating
- Percentage velocity change
- Trend persistence
- Rolling averages

## Why It Matters
Adds a longitudinal signal rather than looking only at today's balance.

## Implementation Notes
- Thresholds are examples only and should be versioned configuration.
- Persist rule version, input snapshot time, metrics, trigger result, severity, and reason codes.
- Require sufficient observation history before strong customer-facing escalation.
- Retain output for future inferential and predictive modeling.
