# R09 — Potential Step-Up Opportunity

## Business Question
Has capacity improved enough to consider saving more?

## Inputs
- Funding trend
- Residual cash trend
- Cash-flow volatility
- Withdrawal behavior
- Current contribution
- Trajectory status
- Observation-history depth

## How It Is Generated
1. Require persistent improvement in funding or residual cash.
2. Require acceptable cash-flow stability.
3. Suppress when recent withdrawals or reversals indicate pressure.
4. Require a minimum observation history.
5. Calculate only a conservative candidate increase; never move funds automatically.

## Example Trigger
Funding or residual cash improves for three periods, volatility remains acceptable, and no withdrawal-pressure signal is active.

## Structured Outputs
- Step-up opportunity candidate
- Conservative increase range
- Eligibility reason codes
- Suppression reason codes

## Why It Matters
Makes the rules engine proactive while keeping the customer in control.

## Implementation Notes
- Thresholds are examples only and should be versioned configuration.
- Persist rule version, input snapshot time, metrics, trigger result, severity, and reason codes.
- Require sufficient observation history before strong customer-facing escalation.
- Retain output for future inferential and predictive modeling.
