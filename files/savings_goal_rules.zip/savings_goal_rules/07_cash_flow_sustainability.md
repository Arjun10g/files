# R07 — Cash-Flow Sustainability

## Business Question
Is the current savings contribution sustainable?

## Inputs
- Approved inflows
- Transaction outflows
- Recurring obligations where identifiable
- Contribution amount
- Residual cash

## How It Is Generated
1. Estimate residual cash after normal outflows and planned savings.
2. Measure both average residual cash and volatility.
3. Identify whether contributions repeatedly leave the customer near an approved low-buffer level.
4. Detect whether savings contributions are followed by reversals or withdrawals.

## Example Trigger
Savings repeatedly leaves the customer near a low-buffer threshold or is frequently followed by withdrawals.

## Structured Outputs
- Sustainable / pressured / unstable
- Estimated residual-cash buffer
- Cash-flow volatility
- Reversal indicator

## Why It Matters
Supports sustainable saving rather than maximizing transfers at the expense of liquidity.

## Implementation Notes
- Thresholds are examples only and should be versioned configuration.
- Persist rule version, input snapshot time, metrics, trigger result, severity, and reason codes.
- Require sufficient observation history before strong customer-facing escalation.
- Retain output for future inferential and predictive modeling.
