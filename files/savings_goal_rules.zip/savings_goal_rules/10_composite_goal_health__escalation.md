# R10 — Composite Goal Health / Escalation

## Business Question
What do all of the signals together tell us?

## Inputs
- Outputs from R01–R09
- Data-quality guardrails
- Policy and eligibility guardrails

## How It Is Generated
1. Combine lower-level signals using a transparent hierarchy or score.
2. Escalate when multiple independent risk signals co-occur.
3. Apply data-quality, policy, and safety suppressions before publishing a customer-facing state.
4. Preserve every contributing reason code.

## Example Trigger
Trajectory gap + decelerating savings + missed contributions + funding deterioration produces a high-risk state.

## Structured Outputs
- Healthy / Watch / Behind / At Risk / Severe Risk
- Overall severity
- Primary reasons
- Permitted next action
- Suppression state

## Why It Matters
Consolidates multiple signals into one coherent and explainable goal-health state.

## Implementation Notes
- Thresholds are examples only and should be versioned configuration.
- Persist rule version, input snapshot time, metrics, trigger result, severity, and reason codes.
- Require sufficient observation history before strong customer-facing escalation.
- Retain output for future inferential and predictive modeling.
